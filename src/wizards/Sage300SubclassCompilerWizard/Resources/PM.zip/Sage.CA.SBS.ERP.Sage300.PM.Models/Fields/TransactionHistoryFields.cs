// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of TransactionHistory Constants
    /// </summary>
    public partial class TransactionHistory
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0111";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of TransactionHistory Field Constants
        /// </summary>
        public class Fields
        {
            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for TransactionNumber
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VENDORID";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for DocumentDate
            /// </summary>
            public const string DocumentDate = "DOCDATE";

            /// <summary>
            /// Property for SourceModule
            /// </summary>
            public const string SourceModule = "MODULE";

            /// <summary>
            /// Property for DocumentType
            /// </summary>
            public const string DocumentType = "DOCTYPE";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for CostOrRevenue
            /// </summary>
            public const string CostOrRevenue = "COSTREV";

            /// <summary>
            /// Property for ReferenceDocument
            /// </summary>
            public const string ReferenceDocument = "REFDOC";

            /// <summary>
            /// Property for BatchDate
            /// </summary>
            public const string BatchDate = "DTEBTCH";

            /// <summary>
            /// Property for BatchNumber
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for BatchEntryNumber
            /// </summary>
            public const string BatchEntryNumber = "CNTENT";

            /// <summary>
            /// Property for BatchLineNumber
            /// </summary>
            public const string BatchLineNumber = "CNTLINE";

            /// <summary>
            /// Property for DocumentReference
            /// </summary>
            public const string DocumentReference = "REFERENCE";

            /// <summary>
            /// Property for DocumentDescription
            /// </summary>
            public const string DocumentDescription = "DESC";

            /// <summary>
            /// Property for PostingSequence
            /// </summary>
            public const string PostingSequence = "POSTSEQ";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CCY";

            /// <summary>
            /// Property for RateTypeCode
            /// </summary>
            public const string RateTypeCode = "RATETYPE";

            /// <summary>
            /// Property for RateOverride
            /// </summary>
            public const string RateOverride = "RATEOVER";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperator
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCALPER";

            /// <summary>
            /// Property for HasTheCostComponentBeenBill
            /// </summary>
            public const string HasTheCostComponentBeenBill = "BILLED";

            /// <summary>
            /// Property for TransactionQuantity
            /// </summary>
            public const string TransactionQuantity = "QUANTITY";

            /// <summary>
            /// Property for ConversionFactor
            /// </summary>
            public const string ConversionFactor = "CONVERSION";

            /// <summary>
            /// Property for ICUnitOfMeasure
            /// </summary>
            public const string ICUnitOfMeasure = "ICUOM";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillAmountBasedOn
            /// </summary>
            public const string BillAmountBasedOn = "FIXEDBILL";

            /// <summary>
            /// Property for TimecardExpenseType
            /// </summary>
            public const string TimecardExpenseType = "EXPTYPE";

            /// <summary>
            /// Property for UnitRate
            /// </summary>
            public const string UnitRate = "UNITRATE";

            /// <summary>
            /// Property for ExtendedAmountSource
            /// </summary>
            public const string ExtendedAmountSource = "EXTAMTSR";

            /// <summary>
            /// Property for ExtendedAmountFunctional
            /// </summary>
            public const string ExtendedAmountFunctional = "EXTAMTHM";

            /// <summary>
            /// Property for LaborType
            /// </summary>
            public const string LaborType = "LABOR";

            /// <summary>
            /// Property for LaborRate
            /// </summary>
            public const string LaborRate = "LABORRATE";

            /// <summary>
            /// Property for LaborPercentage
            /// </summary>
            public const string LaborPercentage = "LABORPER";

            /// <summary>
            /// Property for SourceLaborAmount
            /// </summary>
            public const string SourceLaborAmount = "LABORSR";

            /// <summary>
            /// Property for FunctionalLaborAmount
            /// </summary>
            public const string FunctionalLaborAmount = "LABORHM";

            /// <summary>
            /// Property for OverheadType
            /// </summary>
            public const string OverheadType = "OVERHD";

            /// <summary>
            /// Property for OverheadRate
            /// </summary>
            public const string OverheadRate = "OHEADRATE";

            /// <summary>
            /// Property for OverheadPercentage
            /// </summary>
            public const string OverheadPercentage = "HEADPER";

            /// <summary>
            /// Property for SourceOverheadAmount
            /// </summary>
            public const string SourceOverheadAmount = "OHSR";

            /// <summary>
            /// Property for FunctionalOverheadAmount
            /// </summary>
            public const string FunctionalOverheadAmount = "OHHM";

            /// <summary>
            /// Property for CostPlusPercentage
            /// </summary>
            public const string CostPlusPercentage = "COSTPLUS";

            /// <summary>
            /// Property for SourceTotalAmountExclTax
            /// </summary>
            public const string SourceTotalAmountExclTax = "TOTAMTSR";

            /// <summary>
            /// Property for FunctionalTotalAmountExclTax
            /// </summary>
            public const string FunctionalTotalAmountExclTax = "TOTAMTHM";

            /// <summary>
            /// Property for TaxAmountSource
            /// </summary>
            public const string TaxAmountSource = "TAXAMTSR";

            /// <summary>
            /// Property for TaxAmountFunctional
            /// </summary>
            public const string TaxAmountFunctional = "TAXAMTHM";

            /// <summary>
            /// Property for SourceTotalAmountIncludeTax
            /// </summary>
            public const string SourceTotalAmountIncludeTax = "TAMTSR";

            /// <summary>
            /// Property for FunctionalTotalAmountIncludeTax
            /// </summary>
            public const string FunctionalTotalAmountIncludeTax = "TAMTHM";

            /// <summary>
            /// Property for HasRevenueRecognitionBeenRun
            /// </summary>
            public const string HasRevenueRecognitionBeenRun = "RRCOMPLETE";

            /// <summary>
            /// Property for AmountReceivedSource
            /// </summary>
            public const string AmountReceivedSource = "RCPAMTSR";

            /// <summary>
            /// Property for AmountReceivedFunctional
            /// </summary>
            public const string AmountReceivedFunctional = "RCPAMTHM";

            /// <summary>
            /// Property for AmountPaidSource
            /// </summary>
            public const string AmountPaidSource = "PAYAMTSR";

            /// <summary>
            /// Property for AmountPaid
            /// </summary>
            public const string AmountPaid = "PAYAMTHM";

            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for ItemTaxClass1
            /// </summary>
            public const string ItemTaxClass1 = "TICLASS1";

            /// <summary>
            /// Property for ItemTaxClass2
            /// </summary>
            public const string ItemTaxClass2 = "TICLASS2";

            /// <summary>
            /// Property for ItemTaxClass3
            /// </summary>
            public const string ItemTaxClass3 = "TICLASS3";

            /// <summary>
            /// Property for ItemTaxClass4
            /// </summary>
            public const string ItemTaxClass4 = "TICLASS4";

            /// <summary>
            /// Property for ItemTaxClass5
            /// </summary>
            public const string ItemTaxClass5 = "TICLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TINCLUDED1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "TINCLUDED2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "TINCLUDED3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "TINCLUDED4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "TINCLUDED5";

            /// <summary>
            /// Property for TaxBase1Source
            /// </summary>
            public const string TaxBase1Source = "TAXBASES1";

            /// <summary>
            /// Property for TaxBase2Source
            /// </summary>
            public const string TaxBase2Source = "TAXBASES2";

            /// <summary>
            /// Property for TaxBase3Source
            /// </summary>
            public const string TaxBase3Source = "TAXBASES3";

            /// <summary>
            /// Property for TaxBase4Source
            /// </summary>
            public const string TaxBase4Source = "TAXBASES4";

            /// <summary>
            /// Property for TaxBase5Source
            /// </summary>
            public const string TaxBase5Source = "TAXBASES5";

            /// <summary>
            /// Property for TaxBase1Functional
            /// </summary>
            public const string TaxBase1Functional = "TAXBASEH1";

            /// <summary>
            /// Property for TaxBase2Functional
            /// </summary>
            public const string TaxBase2Functional = "TAXBASEH2";

            /// <summary>
            /// Property for TaxBase3Functional
            /// </summary>
            public const string TaxBase3Functional = "TAXBASEH3";

            /// <summary>
            /// Property for TaxBase4Functional
            /// </summary>
            public const string TaxBase4Functional = "TAXBASEH4";

            /// <summary>
            /// Property for TaxBase5Functional
            /// </summary>
            public const string TaxBase5Functional = "TAXBASEH5";

            /// <summary>
            /// Property for TaxAmount1Source
            /// </summary>
            public const string TaxAmount1Source = "TAXAMTS1";

            /// <summary>
            /// Property for TaxAmount2Source
            /// </summary>
            public const string TaxAmount2Source = "TAXAMTS2";

            /// <summary>
            /// Property for TaxAmount3Source
            /// </summary>
            public const string TaxAmount3Source = "TAXAMTS3";

            /// <summary>
            /// Property for TaxAmount4Source
            /// </summary>
            public const string TaxAmount4Source = "TAXAMTS4";

            /// <summary>
            /// Property for TaxAmount5Source
            /// </summary>
            public const string TaxAmount5Source = "TAXAMTS5";

            /// <summary>
            /// Property for TaxAmount1Functional
            /// </summary>
            public const string TaxAmount1Functional = "TAXAMTH1";

            /// <summary>
            /// Property for TaxAmount2Functional
            /// </summary>
            public const string TaxAmount2Functional = "TAXAMTH2";

            /// <summary>
            /// Property for TaxAmount3Functional
            /// </summary>
            public const string TaxAmount3Functional = "TAXAMTH3";

            /// <summary>
            /// Property for TaxAmount4Functional
            /// </summary>
            public const string TaxAmount4Functional = "TAXAMTH4";

            /// <summary>
            /// Property for TaxAmount5Functional
            /// </summary>
            public const string TaxAmount5Functional = "TAXAMTH5";

            /// <summary>
            /// Property for RecoverableTaxSource
            /// </summary>
            public const string RecoverableTaxSource = "RTAXAMTSR";

            /// <summary>
            /// Property for RecoverableTaxFunctional
            /// </summary>
            public const string RecoverableTaxFunctional = "RTAXAMTHM";

            /// <summary>
            /// Property for CostVarianceAmount
            /// </summary>
            public const string CostVarianceAmount = "CVAMT";

            /// <summary>
            /// Property for WIPCOSAccount
            /// </summary>
            public const string WIPCOSAccount = "WIPACCT";

            /// <summary>
            /// Property for TransactionAccount
            /// </summary>
            public const string TransactionAccount = "TRANACCT";

            /// <summary>
            /// Property for LaborAccount
            /// </summary>
            public const string LaborAccount = "LABORACCT";

            /// <summary>
            /// Property for OverheadAccount
            /// </summary>
            public const string OverheadAccount = "OHACCT";

            /// <summary>
            /// Property for RevenueAccount
            /// </summary>
            public const string RevenueAccount = "REVACCT";

            /// <summary>
            /// Property for CostVarianceAccount
            /// </summary>
            public const string CostVarianceAccount = "CVACCT";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for ARUnitOfMeasure
            /// </summary>
            public const string ARUnitOfMeasure = "ARUOM";

            /// <summary>
            /// Property for TransactionReference
            /// </summary>
            public const string TransactionReference = "TRANSREF";

            /// <summary>
            /// Property for CostRevenueTRANSNUM
            /// </summary>
            public const string CostRevenueTRANSNUM = "OTHERREF";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "TYPE";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "TRANSQTY";

            /// <summary>
            /// Property for RRWorksheetNumber
            /// </summary>
            public const string RRWorksheetNumber = "RRWORKID";

            /// <summary>
            /// Property for BillingWorksheetNumber
            /// </summary>
            public const string BillingWorksheetNumber = "BWWORKID";

            /// <summary>
            /// Property for SourceRetainageAmount
            /// </summary>
            public const string SourceRetainageAmount = "TAMTRETSR";

            /// <summary>
            /// Property for FunctionalRetainageAmount
            /// </summary>
            public const string FunctionalRetainageAmount = "TAMTRETHM";

            /// <summary>
            /// Property for RetainageDueDate
            /// </summary>
            public const string RetainageDueDate = "RETDUEDT";

            /// <summary>
            /// Property for OriginalDocumentNumber
            /// </summary>
            public const string OriginalDocumentNumber = "ORIGDOC";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            /// <summary>
            /// Property for DayEndSequence
            /// </summary>
            public const string DayEndSequence = "DAYENDSEQ";

            /// <summary>
            /// Property for DayEndDate
            /// </summary>
            public const string DayEndDate = "DAYENDDATE";

            /// <summary>
            /// Property for OriginalApplication
            /// </summary>
            public const string OriginalApplication = "ORIGAPP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for VALUES
            /// </summary>
            public const string VALUES = "VALUES";

            /// <summary>
            /// Property for DrillDownType
            /// </summary>
            public const string DrillDownType = "DRILLSRCTY";

            /// <summary>
            /// Property for DrillDownLink
            /// </summary>
            public const string DrillDownLink = "DRILLDWNLK";

            /// <summary>
            /// Property for DrillDownApplication
            /// </summary>
            public const string DrillDownApplication = "DRILLAPP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for EARNINGS
            /// </summary>
            public const string EARNINGS = "EARNINGS";

            /// <summary>
            /// Property for ExpensedTaxSource
            /// </summary>
            public const string ExpensedTaxSource = "EXPTAXSR";

            /// <summary>
            /// Property for ExpensedTaxFunctional
            /// </summary>
            public const string ExpensedTaxFunctional = "EXPTAXHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for COSTTYPE
            /// </summary>
            public const string COSTTYPE = "COSTTYPE";

            /// <summary>
            /// Property for AdditionalCostType
            /// </summary>
            public const string AdditionalCostType = "ADDCOST";

            /// <summary>
            /// Property for CurrentPMVersion
            /// </summary>
            public const string CurrentPMVersion = "PMVERSION";

            /// <summary>
            /// Property for AdjustmentRevenueType
            /// </summary>
            public const string AdjustmentRevenueType = "ADJREVTYPE";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for EmployeeNumber
            /// </summary>
            public const string EmployeeNumber = "STAFFCODE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LINENO
            /// </summary>
            public const string LINENO = "LINENO";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTNAME";

            /// <summary>
            /// Property for VendorName
            /// </summary>
            public const string VendorName = "VENDNAME";

            /// <summary>
            /// Property for LocationName
            /// </summary>
            public const string LocationName = "LOCNAME";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for HASOPT
            /// </summary>
            public const string HASOPT = "HASOPT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TransactionHistory Index Constants
        /// </summary>
        public class Index
        {
            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 1;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 2;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 3;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 4;

            /// <summary>
            /// Property Indexer for TransactionNumber
            /// </summary>
            public const int TransactionNumber = 5;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 6;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 7;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 8;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 9;

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 10;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 11;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 12;

            /// <summary>
            /// Property Indexer for DocumentDate
            /// </summary>
            public const int DocumentDate = 13;

            /// <summary>
            /// Property Indexer for SourceModule
            /// </summary>
            public const int SourceModule = 14;

            /// <summary>
            /// Property Indexer for DocumentType
            /// </summary>
            public const int DocumentType = 15;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 16;

            /// <summary>
            /// Property Indexer for CostOrRevenue
            /// </summary>
            public const int CostOrRevenue = 17;

            /// <summary>
            /// Property Indexer for ReferenceDocument
            /// </summary>
            public const int ReferenceDocument = 18;

            /// <summary>
            /// Property Indexer for BatchDate
            /// </summary>
            public const int BatchDate = 19;

            /// <summary>
            /// Property Indexer for BatchNumber
            /// </summary>
            public const int BatchNumber = 20;

            /// <summary>
            /// Property Indexer for BatchEntryNumber
            /// </summary>
            public const int BatchEntryNumber = 21;

            /// <summary>
            /// Property Indexer for BatchLineNumber
            /// </summary>
            public const int BatchLineNumber = 22;

            /// <summary>
            /// Property Indexer for DocumentReference
            /// </summary>
            public const int DocumentReference = 23;

            /// <summary>
            /// Property Indexer for DocumentDescription
            /// </summary>
            public const int DocumentDescription = 24;

            /// <summary>
            /// Property Indexer for PostingSequence
            /// </summary>
            public const int PostingSequence = 25;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 26;

            /// <summary>
            /// Property Indexer for RateTypeCode
            /// </summary>
            public const int RateTypeCode = 27;

            /// <summary>
            /// Property Indexer for RateOverride
            /// </summary>
            public const int RateOverride = 28;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 29;

            /// <summary>
            /// Property Indexer for RateOperator
            /// </summary>
            public const int RateOperator = 30;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 31;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 32;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 33;

            /// <summary>
            /// Property Indexer for HasTheCostComponentBeenBill
            /// </summary>
            public const int HasTheCostComponentBeenBill = 34;

            /// <summary>
            /// Property Indexer for TransactionQuantity
            /// </summary>
            public const int TransactionQuantity = 35;

            /// <summary>
            /// Property Indexer for ConversionFactor
            /// </summary>
            public const int ConversionFactor = 36;

            /// <summary>
            /// Property Indexer for ICUnitOfMeasure
            /// </summary>
            public const int ICUnitOfMeasure = 37;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 38;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 39;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 40;

            /// <summary>
            /// Property Indexer for BillAmountBasedOn
            /// </summary>
            public const int BillAmountBasedOn = 41;

            /// <summary>
            /// Property Indexer for TimecardExpenseType
            /// </summary>
            public const int TimecardExpenseType = 42;

            /// <summary>
            /// Property Indexer for UnitRate
            /// </summary>
            public const int UnitRate = 43;

            /// <summary>
            /// Property Indexer for ExtendedAmountSource
            /// </summary>
            public const int ExtendedAmountSource = 44;

            /// <summary>
            /// Property Indexer for ExtendedAmountFunctional
            /// </summary>
            public const int ExtendedAmountFunctional = 45;

            /// <summary>
            /// Property Indexer for LaborType
            /// </summary>
            public const int LaborType = 46;

            /// <summary>
            /// Property Indexer for LaborRate
            /// </summary>
            public const int LaborRate = 47;

            /// <summary>
            /// Property Indexer for LaborPercentage
            /// </summary>
            public const int LaborPercentage = 48;

            /// <summary>
            /// Property Indexer for SourceLaborAmount
            /// </summary>
            public const int SourceLaborAmount = 49;

            /// <summary>
            /// Property Indexer for FunctionalLaborAmount
            /// </summary>
            public const int FunctionalLaborAmount = 50;

            /// <summary>
            /// Property Indexer for OverheadType
            /// </summary>
            public const int OverheadType = 51;

            /// <summary>
            /// Property Indexer for OverheadRate
            /// </summary>
            public const int OverheadRate = 52;

            /// <summary>
            /// Property Indexer for OverheadPercentage
            /// </summary>
            public const int OverheadPercentage = 53;

            /// <summary>
            /// Property Indexer for SourceOverheadAmount
            /// </summary>
            public const int SourceOverheadAmount = 54;

            /// <summary>
            /// Property Indexer for FunctionalOverheadAmount
            /// </summary>
            public const int FunctionalOverheadAmount = 55;

            /// <summary>
            /// Property Indexer for CostPlusPercentage
            /// </summary>
            public const int CostPlusPercentage = 56;

            /// <summary>
            /// Property Indexer for SourceTotalAmountExclTax
            /// </summary>
            public const int SourceTotalAmountExclTax = 57;

            /// <summary>
            /// Property Indexer for FunctionalTotalAmountExclTax
            /// </summary>
            public const int FunctionalTotalAmountExclTax = 58;

            /// <summary>
            /// Property Indexer for TaxAmountSource
            /// </summary>
            public const int TaxAmountSource = 59;

            /// <summary>
            /// Property Indexer for TaxAmountFunctional
            /// </summary>
            public const int TaxAmountFunctional = 60;

            /// <summary>
            /// Property Indexer for SourceTotalAmountIncludeTax
            /// </summary>
            public const int SourceTotalAmountIncludeTax = 61;

            /// <summary>
            /// Property Indexer for FunctionalTotalAmountIncludeTax
            /// </summary>
            public const int FunctionalTotalAmountIncludeTax = 62;

            /// <summary>
            /// Property Indexer for HasRevenueRecognitionBeenRun
            /// </summary>
            public const int HasRevenueRecognitionBeenRun = 63;

            /// <summary>
            /// Property Indexer for AmountReceivedSource
            /// </summary>
            public const int AmountReceivedSource = 64;

            /// <summary>
            /// Property Indexer for AmountReceivedFunctional
            /// </summary>
            public const int AmountReceivedFunctional = 65;

            /// <summary>
            /// Property Indexer for AmountPaidSource
            /// </summary>
            public const int AmountPaidSource = 66;

            /// <summary>
            /// Property Indexer for AmountPaid
            /// </summary>
            public const int AmountPaid = 67;

            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 68;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 69;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 70;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 71;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 72;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 73;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 74;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 75;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 76;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 77;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 78;

            /// <summary>
            /// Property Indexer for ItemTaxClass1
            /// </summary>
            public const int ItemTaxClass1 = 79;

            /// <summary>
            /// Property Indexer for ItemTaxClass2
            /// </summary>
            public const int ItemTaxClass2 = 80;

            /// <summary>
            /// Property Indexer for ItemTaxClass3
            /// </summary>
            public const int ItemTaxClass3 = 81;

            /// <summary>
            /// Property Indexer for ItemTaxClass4
            /// </summary>
            public const int ItemTaxClass4 = 82;

            /// <summary>
            /// Property Indexer for ItemTaxClass5
            /// </summary>
            public const int ItemTaxClass5 = 83;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 84;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 85;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 86;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 87;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 88;

            /// <summary>
            /// Property Indexer for TaxBase1Source
            /// </summary>
            public const int TaxBase1Source = 89;

            /// <summary>
            /// Property Indexer for TaxBase2Source
            /// </summary>
            public const int TaxBase2Source = 90;

            /// <summary>
            /// Property Indexer for TaxBase3Source
            /// </summary>
            public const int TaxBase3Source = 91;

            /// <summary>
            /// Property Indexer for TaxBase4Source
            /// </summary>
            public const int TaxBase4Source = 92;

            /// <summary>
            /// Property Indexer for TaxBase5Source
            /// </summary>
            public const int TaxBase5Source = 93;

            /// <summary>
            /// Property Indexer for TaxBase1Functional
            /// </summary>
            public const int TaxBase1Functional = 94;

            /// <summary>
            /// Property Indexer for TaxBase2Functional
            /// </summary>
            public const int TaxBase2Functional = 95;

            /// <summary>
            /// Property Indexer for TaxBase3Functional
            /// </summary>
            public const int TaxBase3Functional = 96;

            /// <summary>
            /// Property Indexer for TaxBase4Functional
            /// </summary>
            public const int TaxBase4Functional = 97;

            /// <summary>
            /// Property Indexer for TaxBase5Functional
            /// </summary>
            public const int TaxBase5Functional = 98;

            /// <summary>
            /// Property Indexer for TaxAmount1Source
            /// </summary>
            public const int TaxAmount1Source = 99;

            /// <summary>
            /// Property Indexer for TaxAmount2Source
            /// </summary>
            public const int TaxAmount2Source = 100;

            /// <summary>
            /// Property Indexer for TaxAmount3Source
            /// </summary>
            public const int TaxAmount3Source = 101;

            /// <summary>
            /// Property Indexer for TaxAmount4Source
            /// </summary>
            public const int TaxAmount4Source = 102;

            /// <summary>
            /// Property Indexer for TaxAmount5Source
            /// </summary>
            public const int TaxAmount5Source = 103;

            /// <summary>
            /// Property Indexer for TaxAmount1Functional
            /// </summary>
            public const int TaxAmount1Functional = 104;

            /// <summary>
            /// Property Indexer for TaxAmount2Functional
            /// </summary>
            public const int TaxAmount2Functional = 105;

            /// <summary>
            /// Property Indexer for TaxAmount3Functional
            /// </summary>
            public const int TaxAmount3Functional = 106;

            /// <summary>
            /// Property Indexer for TaxAmount4Functional
            /// </summary>
            public const int TaxAmount4Functional = 107;

            /// <summary>
            /// Property Indexer for TaxAmount5Functional
            /// </summary>
            public const int TaxAmount5Functional = 108;

            /// <summary>
            /// Property Indexer for RecoverableTaxSource
            /// </summary>
            public const int RecoverableTaxSource = 109;

            /// <summary>
            /// Property Indexer for RecoverableTaxFunctional
            /// </summary>
            public const int RecoverableTaxFunctional = 110;

            /// <summary>
            /// Property Indexer for CostVarianceAmount
            /// </summary>
            public const int CostVarianceAmount = 111;

            /// <summary>
            /// Property Indexer for WIPCOSAccount
            /// </summary>
            public const int WIPCOSAccount = 112;

            /// <summary>
            /// Property Indexer for TransactionAccount
            /// </summary>
            public const int TransactionAccount = 113;

            /// <summary>
            /// Property Indexer for LaborAccount
            /// </summary>
            public const int LaborAccount = 114;

            /// <summary>
            /// Property Indexer for OverheadAccount
            /// </summary>
            public const int OverheadAccount = 115;

            /// <summary>
            /// Property Indexer for RevenueAccount
            /// </summary>
            public const int RevenueAccount = 116;

            /// <summary>
            /// Property Indexer for CostVarianceAccount
            /// </summary>
            public const int CostVarianceAccount = 117;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 118;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 119;

            /// <summary>
            /// Property Indexer for TransactionReference
            /// </summary>
            public const int TransactionReference = 120;

            /// <summary>
            /// Property Indexer for CostRevenueTRANSNUM
            /// </summary>
            public const int CostRevenueTRANSNUM = 121;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 122;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 123;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 124;

            /// <summary>
            /// Property Indexer for RRWorksheetNumber
            /// </summary>
            public const int RRWorksheetNumber = 125;

            /// <summary>
            /// Property Indexer for BillingWorksheetNumber
            /// </summary>
            public const int BillingWorksheetNumber = 126;

            /// <summary>
            /// Property Indexer for SourceRetainageAmount
            /// </summary>
            public const int SourceRetainageAmount = 127;

            /// <summary>
            /// Property Indexer for FunctionalRetainageAmount
            /// </summary>
            public const int FunctionalRetainageAmount = 128;

            /// <summary>
            /// Property Indexer for RetainageDueDate
            /// </summary>
            public const int RetainageDueDate = 129;

            /// <summary>
            /// Property Indexer for OriginalDocumentNumber
            /// </summary>
            public const int OriginalDocumentNumber = 130;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 131;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 132;

            /// <summary>
            /// Property Indexer for DayEndSequence
            /// </summary>
            public const int DayEndSequence = 133;

            /// <summary>
            /// Property Indexer for DayEndDate
            /// </summary>
            public const int DayEndDate = 134;

            /// <summary>
            /// Property Indexer for OriginalApplication
            /// </summary>
            public const int OriginalApplication = 135;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for VALUES
            /// </summary>
            public const int VALUES = 136;

            /// <summary>
            /// Property Indexer for DrillDownType
            /// </summary>
            public const int DrillDownType = 137;

            /// <summary>
            /// Property Indexer for DrillDownLink
            /// </summary>
            public const int DrillDownLink = 138;

            /// <summary>
            /// Property Indexer for DrillDownApplication
            /// </summary>
            public const int DrillDownApplication = 139;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for EARNINGS
            /// </summary>
            public const int EARNINGS = 140;

            /// <summary>
            /// Property Indexer for ExpensedTaxSource
            /// </summary>
            public const int ExpensedTaxSource = 141;

            /// <summary>
            /// Property Indexer for ExpensedTaxFunctional
            /// </summary>
            public const int ExpensedTaxFunctional = 142;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for COSTTYPE
            /// </summary>
            public const int COSTTYPE = 143;

            /// <summary>
            /// Property Indexer for AdditionalCostType
            /// </summary>
            public const int AdditionalCostType = 144;

            /// <summary>
            /// Property Indexer for CurrentPMVersion
            /// </summary>
            public const int CurrentPMVersion = 145;

            /// <summary>
            /// Property Indexer for AdjustmentRevenueType
            /// </summary>
            public const int AdjustmentRevenueType = 146;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 147;

            /// <summary>
            /// Property Indexer for EmployeeNumber
            /// </summary>
            public const int EmployeeNumber = 148;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LINENO
            /// </summary>
            public const int LINENO = 149;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 1001;

            /// <summary>
            /// Property Indexer for VendorName
            /// </summary>
            public const int VendorName = 1002;

            /// <summary>
            /// Property Indexer for LocationName
            /// </summary>
            public const int LocationName = 1003;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for HASOPT
            /// </summary>
            public const int HASOPT = 1004;


        }

        #endregion

    }
}