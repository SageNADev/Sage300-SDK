// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Contracts Constants
    /// </summary>
    public partial class Contracts
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0021";


        #region Properties

        /// <summary>
        /// Contains list of Contracts Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ContractUniq
            /// </summary>
            public const string ContractUniq = "CTUNIQ";

            /// <summary>
            /// Property for UnformattedContract
            /// </summary>
            public const string UnformattedContract = "CONTRACT";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for StructureCode
            /// </summary>
            public const string StructureCode = "CONTBRKID";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "FMTCONTNO";

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTOMER";

            /// <summary>
            /// Property for ContractManager
            /// </summary>
            public const string ContractManager = "MANAGER";

            /// <summary>
            /// Property for PONumber
            /// </summary>
            public const string PONumber = "PONUMBER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTACT
            /// </summary>
            public const string CONTACT = "CONTACT";

            /// <summary>
            /// Property for Telephone
            /// </summary>
            public const string Telephone = "PHONE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FAX
            /// </summary>
            public const string FAX = "FAX";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "STARTDATE";

            /// <summary>
            /// Property for OriginalEndDate
            /// </summary>
            public const string OriginalEndDate = "ORJENDDATE";

            /// <summary>
            /// Property for ProjectedEndDate
            /// </summary>
            public const string ProjectedEndDate = "CURENDDATE";

            /// <summary>
            /// Property for ClosedDate
            /// </summary>
            public const string ClosedDate = "CLOSEDDATE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for UseContractRevenueRecognition
            /// </summary>
            public const string UseContractRevenueRecognition = "USERR";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for UseTheContractOverheadInform
            /// </summary>
            public const string UseTheContractOverheadInform = "USEOVERH";

            /// <summary>
            /// Property for OverheadType
            /// </summary>
            public const string OverheadType = "OVERHEAD";

            /// <summary>
            /// Property for OverheadRate
            /// </summary>
            public const string OverheadRate = "OHEADRATE";

            /// <summary>
            /// Property for OverheadPercentage
            /// </summary>
            public const string OverheadPercentage = "HEADPER";

            /// <summary>
            /// Property for UseTheContractLaborType
            /// </summary>
            public const string UseTheContractLaborType = "USELABOR";

            /// <summary>
            /// Property for LaborType
            /// </summary>
            public const string LaborType = "LABOR";

            /// <summary>
            /// Property for LaborRate
            /// </summary>
            public const string LaborRate = "LABORRATE";

            /// <summary>
            /// Property for LaborPercentage
            /// </summary>
            public const string LaborPercentage = "LABORPER";

            /// <summary>
            /// Property for ContractStatus
            /// </summary>
            public const string ContractStatus = "STATUS";

            /// <summary>
            /// Property for UseCostPlusPercentage
            /// </summary>
            public const string UseCostPlusPercentage = "USECOSTP";

            /// <summary>
            /// Property for CostPlusPercentage
            /// </summary>
            public const string CostPlusPercentage = "COSTPLUSP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for USEPTYPE
            /// </summary>
            public const string USEPTYPE = "USEPTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PROJTYPE
            /// </summary>
            public const string PROJTYPE = "PROJTYPE";

            /// <summary>
            /// Property for NumberOfChangeOrdersToThe^
            /// </summary>
            public const string NumberOfChangeOrders = "CHANGEORD";

            /// <summary>
            /// Property for NextChangeOrderNumber
            /// </summary>
            public const string NextChangeOrderNumber = "NXTCHGORD";

            /// <summary>
            /// Property for AccountSet
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            /// <summary>
            /// Property for Template
            /// </summary>
            public const string Template = "TEMPLAT";

            /// <summary>
            /// Property for UseTheContractBillingType
            /// </summary>
            public const string UseTheContractBillingType = "USEBILL";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for Schedule
            /// </summary>
            public const string Schedule = "SCHCODE";

            /// <summary>
            /// Property for UseTheContractRetainageInfor
            /// </summary>
            public const string UseTheContractRetainageInfor = "USERETAIN";

            /// <summary>
            /// Property for ARRetainagePercentage
            /// </summary>
            public const string ARRetainagePercentage = "PERRETREC";

            /// <summary>
            /// Property for ARRetentionPeriod
            /// </summary>
            public const string ARRetentionPeriod = "RETRECD";

            /// <summary>
            /// Property for Segment1
            /// </summary>
            public const string Segment1 = "SEGMENT1";

            /// <summary>
            /// Property for Segment2
            /// </summary>
            public const string Segment2 = "SEGMENT2";

            /// <summary>
            /// Property for Segment3
            /// </summary>
            public const string Segment3 = "SEGMENT3";

            /// <summary>
            /// Property for Segment4
            /// </summary>
            public const string Segment4 = "SEGMENT4";

            /// <summary>
            /// Property for Segment5
            /// </summary>
            public const string Segment5 = "SEGMENT5";

            /// <summary>
            /// Property for ConsolidateProjectsOntoTheOn
            /// </summary>
            public const string ConsolidateProjectsOntoTheOn = "CONSOLINV";

            /// <summary>
            /// Property for FormCode
            /// </summary>
            public const string FormCode = "FORMCODE";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "NEXTNUM";

            /// <summary>
            /// Property for NumberOfDetails
            /// </summary>
            public const string NumberOfDetails = "NUMDETAILS";

            /// <summary>
            /// Property for RevenueAndCostCurrency
            /// </summary>
            public const string RevenueAndCostCurrency = "ESTBILLCCY";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "CUSTCCY";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for NumberOfNonPercentProjects
            /// </summary>
            public const string NumberOfNonPercentProjects = "ORJTIMECSR";

            /// <summary>
            /// Property for OriginalLaborCostEst
            /// </summary>
            public const string OriginalLaborCostEst = "ORJTIMECHM";

            /// <summary>
            /// Property for CurrencyLaborCostEst
            /// </summary>
            public const string CurrencyLaborCostEst = "CURTIMECHM";

            /// <summary>
            /// Property for ActualLaborCosts
            /// </summary>
            public const string ActualLaborCosts = "ACTTIMECHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJTIMEBSR
            /// </summary>
            public const string ORJTIMEBSR = "ORJTIMEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJTIMEBHM
            /// </summary>
            public const string ORJTIMEBHM = "ORJTIMEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURTIMEBSR
            /// </summary>
            public const string CURTIMEBSR = "CURTIMEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURTIMEBHM
            /// </summary>
            public const string CURTIMEBHM = "CURTIMEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTTIMEBSR
            /// </summary>
            public const string ACTTIMEBSR = "ACTTIMEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTTIMEBHM
            /// </summary>
            public const string ACTTIMEBHM = "ACTTIMEBHM";

            /// <summary>
            /// Property for OriginalLaborQtyEst
            /// </summary>
            public const string OriginalLaborQtyEst = "ORJTIMEQTY";

            /// <summary>
            /// Property for CurrencyLaborQtyEst
            /// </summary>
            public const string CurrencyLaborQtyEst = "CURTIMEQTY";

            /// <summary>
            /// Property for ActualLaborQty
            /// </summary>
            public const string ActualLaborQty = "ACTTIMEQTY";

            /// <summary>
            /// Property for LaborPercentageComplete
            /// </summary>
            public const string LaborPercentageComplete = "PERTIMEQTY";

            /// <summary>
            /// Property for OriginalMaterialEstimatedCost
            /// </summary>
            public const string OriginalMaterialEstimatedCost = "ORJMATECHM";

            /// <summary>
            /// Property for CurrentMaterialEstimatedCost
            /// </summary>
            public const string CurrentMaterialEstimatedCost = "CURMATECHM";

            /// <summary>
            /// Property for ActualMaterialCost
            /// </summary>
            public const string ActualMaterialCost = "ACTMATECHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMATEBSR
            /// </summary>
            public const string ORJMATEBSR = "ORJMATEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMATEBHM
            /// </summary>
            public const string ORJMATEBHM = "ORJMATEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMATEBSR
            /// </summary>
            public const string CURMATEBSR = "CURMATEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMATEBHM
            /// </summary>
            public const string CURMATEBHM = "CURMATEBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMATEBSR
            /// </summary>
            public const string ACTMATEBSR = "ACTMATEBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMATEBHM
            /// </summary>
            public const string ACTMATEBHM = "ACTMATEBHM";

            /// <summary>
            /// Property for OriginalMaterialQtyEst
            /// </summary>
            public const string OriginalMaterialQtyEst = "ORJMATEQTY";

            /// <summary>
            /// Property for CurrencyMaterialEst
            /// </summary>
            public const string CurrencyMaterialEst = "CURMATEQTY";

            /// <summary>
            /// Property for ActualMaterialQty
            /// </summary>
            public const string ActualMaterialQty = "ACTMATEQTY";

            /// <summary>
            /// Property for OriginalEstimatedEquipmentCost
            /// </summary>
            public const string OriginalEstimatedEquipmentCost = "ORJEQUICHM";

            /// <summary>
            /// Property for CurrencyEstimatedEquipmentCost
            /// </summary>
            public const string CurrencyEstimatedEquipmentCost = "CUREQUICHM";

            /// <summary>
            /// Property for ActualEquipmentCost
            /// </summary>
            public const string ActualEquipmentCost = "ACTEQUICHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJEQUIBSR
            /// </summary>
            public const string ORJEQUIBSR = "ORJEQUIBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJEQUIBHM
            /// </summary>
            public const string ORJEQUIBHM = "ORJEQUIBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUREQUIBSR
            /// </summary>
            public const string CUREQUIBSR = "CUREQUIBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUREQUIBHM
            /// </summary>
            public const string CUREQUIBHM = "CUREQUIBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTEQUIBSR
            /// </summary>
            public const string ACTEQUIBSR = "ACTEQUIBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTEQUIBHM
            /// </summary>
            public const string ACTEQUIBHM = "ACTEQUIBHM";

            /// <summary>
            /// Property for OriginalEquipmentQtyEst
            /// </summary>
            public const string OriginalEquipmentQtyEst = "ORJEQUIQTY";

            /// <summary>
            /// Property for CurrencyEquipmentEst
            /// </summary>
            public const string CurrencyEquipmentEst = "CUREQUIQTY";

            /// <summary>
            /// Property for ActualEquipmentQty
            /// </summary>
            public const string ActualEquipmentQty = "ACTEQUIQTY";

            /// <summary>
            /// Property for OriginalSubcontractorEstCost
            /// </summary>
            public const string OriginalSubcontractorEstCost = "ORJSUBCCHM";

            /// <summary>
            /// Property for CurrencySubcontractorEstCost
            /// </summary>
            public const string CurrencySubcontractorEstCost = "CURSUBCCHM";

            /// <summary>
            /// Property for ActualSubcontractorCost
            /// </summary>
            public const string ActualSubcontractorCost = "ACTSUBCCHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJSUBCBSR
            /// </summary>
            public const string ORJSUBCBSR = "ORJSUBCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJSUBCBHM
            /// </summary>
            public const string ORJSUBCBHM = "ORJSUBCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURSUBCBSR
            /// </summary>
            public const string CURSUBCBSR = "CURSUBCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURSUBCBHM
            /// </summary>
            public const string CURSUBCBHM = "CURSUBCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTSUBCBSR
            /// </summary>
            public const string ACTSUBCBSR = "ACTSUBCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTSUBCBHM
            /// </summary>
            public const string ACTSUBCBHM = "ACTSUBCBHM";

            /// <summary>
            /// Property for OriginalSubcontractorQtyEst
            /// </summary>
            public const string OriginalSubcontractorQtyEst = "ORJSUBCQTY";

            /// <summary>
            /// Property for CurrencySubcontractorEst
            /// </summary>
            public const string CurrencySubcontractorEst = "CURSUBCQTY";

            /// <summary>
            /// Property for ActualSubcontractorQty
            /// </summary>
            public const string ActualSubcontractorQty = "ACTSUBCQTY";

            /// <summary>
            /// Property for OriginalEstOverheadExpenseCost
            /// </summary>
            public const string OriginalEstOverheadExpenseCost = "ORJOHEXCHM";

            /// <summary>
            /// Property for CurrencyEstOverheadExpenseCost
            /// </summary>
            public const string CurrencyEstOverheadExpenseCost = "CUROHEXCHM";

            /// <summary>
            /// Property for ActualOverheadExpenseCost
            /// </summary>
            public const string ActualOverheadExpenseCost = "ACTOHEXCHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJOHEXBSR
            /// </summary>
            public const string ORJOHEXBSR = "ORJOHEXBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJOHEXBHM
            /// </summary>
            public const string ORJOHEXBHM = "ORJOHEXBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUROHEXBSR
            /// </summary>
            public const string CUROHEXBSR = "CUROHEXBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUROHEXBHM
            /// </summary>
            public const string CUROHEXBHM = "CUROHEXBHM";

            /// <summary>
            /// Property for ActualOverheadAmountBilled
            /// </summary>
            public const string ActualOverheadAmountBilled = "ACTOHEXBSR";

            /// <summary>
            /// Property for ActualOverheadBillingEst
            /// </summary>
            public const string ActualOverheadBillingEst = "ACTOHEXBHM";

            /// <summary>
            /// Property for OriginalOverheadQtyEst
            /// </summary>
            public const string OriginalOverheadQtyEst = "ORJOHEXQTY";

            /// <summary>
            /// Property for CurrencyOverheadEst
            /// </summary>
            public const string CurrencyOverheadEst = "CUROHEXQTY";

            /// <summary>
            /// Property for ActualOverheadQty
            /// </summary>
            public const string ActualOverheadQty = "ACTOHEXQTY";

            /// <summary>
            /// Property for OriginalEstMiscellaneousCost
            /// </summary>
            public const string OriginalEstMiscellaneousCost = "ORJMISCCHM";

            /// <summary>
            /// Property for CurrencyEstMiscellaneousCost
            /// </summary>
            public const string CurrencyEstMiscellaneousCost = "CURMISCCHM";

            /// <summary>
            /// Property for ActualMiscellaneousCost
            /// </summary>
            public const string ActualMiscellaneousCost = "ACTMISCCHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMISCBSR
            /// </summary>
            public const string ORJMISCBSR = "ORJMISCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJMISCBHM
            /// </summary>
            public const string ORJMISCBHM = "ORJMISCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMISCBSR
            /// </summary>
            public const string CURMISCBSR = "CURMISCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURMISCBHM
            /// </summary>
            public const string CURMISCBHM = "CURMISCBHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMISCBSR
            /// </summary>
            public const string ACTMISCBSR = "ACTMISCBSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTMISCBHM
            /// </summary>
            public const string ACTMISCBHM = "ACTMISCBHM";

            /// <summary>
            /// Property for OriginalMiscellaneousQtyEst
            /// </summary>
            public const string OriginalMiscellaneousQtyEst = "ORJMISCQTY";

            /// <summary>
            /// Property for CurrencyMiscellaneousEst
            /// </summary>
            public const string CurrencyMiscellaneousEst = "CURMISCQTY";

            /// <summary>
            /// Property for ActualMiscellaneousQty
            /// </summary>
            public const string ActualMiscellaneousQty = "ACTMISCQTY";

            /// <summary>
            /// Property for OriginalOverheadEstimate
            /// </summary>
            public const string OriginalOverheadEstimate = "ORJOHEADHM";

            /// <summary>
            /// Property for CurrentOverheadEstimate
            /// </summary>
            public const string CurrentOverheadEstimate = "CUROHEADHM";

            /// <summary>
            /// Property for ActualOverhead
            /// </summary>
            public const string ActualOverhead = "ACTOHEADHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJLABSR
            /// </summary>
            public const string ORJLABSR = "ORJLABSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ORJLABHM
            /// </summary>
            public const string ORJLABHM = "ORJLABHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURLABSR
            /// </summary>
            public const string CURLABSR = "CURLABSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CURLABHM
            /// </summary>
            public const string CURLABHM = "CURLABHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTLABSR
            /// </summary>
            public const string ACTLABSR = "ACTLABSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTLABHM
            /// </summary>
            public const string ACTLABHM = "ACTLABHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGSR
            /// </summary>
            public const string ACTCHRGSR = "ACTCHRGSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGHM
            /// </summary>
            public const string ACTCHRGHM = "ACTCHRGHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGDSR
            /// </summary>
            public const string ACTCHRGDSR = "ACTCHRGDSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ACTCHRGDHM
            /// </summary>
            public const string ACTCHRGDHM = "ACTCHRGDHM";

            /// <summary>
            /// Property for ActCostStockRetToInventory
            /// </summary>
            public const string ActCostStockRetToInventory = "ACTSTKREHM";

            /// <summary>
            /// Property for ActQtyStockRetToInventory
            /// </summary>
            public const string ActQtyStockRetToInventory = "ACTSTKRQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TARRECTSSR
            /// </summary>
            public const string TARRECTSSR = "TARRECTSSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TARRECTSHM
            /// </summary>
            public const string TARRECTSHM = "TARRECTSHM";

            /// <summary>
            /// Property for TotalAPVendorPayments
            /// </summary>
            public const string TotalAPVendorPayments = "TAPPAYMTS";

            /// <summary>
            /// Property for TotalOriginalCostEst
            /// </summary>
            public const string TotalOriginalCostEst = "TORJCOSTHM";

            /// <summary>
            /// Property for TotalCurrencyCostEst
            /// </summary>
            public const string TotalCurrencyCostEst = "TCURCOSTHM";

            /// <summary>
            /// Property for TotalActualCost
            /// </summary>
            public const string TotalActualCost = "TACTCOSTHM";

            /// <summary>
            /// Property for TotalCostRecognized
            /// </summary>
            public const string TotalCostRecognized = "TRECCOSTHM";

            /// <summary>
            /// Property for PercentTotalCost
            /// </summary>
            public const string PercentTotalCost = "PERTCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TORJREVSR
            /// </summary>
            public const string TORJREVSR = "TORJREVSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TORJREVHM
            /// </summary>
            public const string TORJREVHM = "TORJREVHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TCURREVSR
            /// </summary>
            public const string TCURREVSR = "TCURREVSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TCURREVHM
            /// </summary>
            public const string TCURREVHM = "TCURREVHM";

            /// <summary>
            /// Property for TotalActualRevenue
            /// </summary>
            public const string TotalActualRevenue = "TACTREVSR";

            /// <summary>
            /// Property for TotalActualRevenueEst
            /// </summary>
            public const string TotalActualRevenueEst = "TACTREVHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TRECREVSR
            /// </summary>
            public const string TRECREVSR = "TRECREVSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for TRECREVHM
            /// </summary>
            public const string TRECREVHM = "TRECREVHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARAMTSR
            /// </summary>
            public const string RETARAMTSR = "RETARAMTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARAMTHM
            /// </summary>
            public const string RETARAMTHM = "RETARAMTHM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARRECSR
            /// </summary>
            public const string RETARRECSR = "RETARRECSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for RETARRECHM
            /// </summary>
            public const string RETARRECHM = "RETARRECHM";

            /// <summary>
            /// Property for RetainagePayable
            /// </summary>
            public const string RetainagePayable = "RETAPAMT";

            /// <summary>
            /// Property for RetainageAmountPaidInAP
            /// </summary>
            public const string RetainageAmountPaidInAP = "RETAPPAID";

            /// <summary>
            /// Property for RecognizedLoss
            /// </summary>
            public const string RecognizedLoss = "OEAMOUNTHM";

            /// <summary>
            /// Property for RecognizedComplete
            /// </summary>
            public const string RecognizedComplete = "PCOMLETERR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FPAMOUNTSR
            /// </summary>
            public const string FPAMOUNTSR = "FPAMOUNTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FPAMOUNTHM
            /// </summary>
            public const string FPAMOUNTHM = "FPAMOUNTHM";

            /// <summary>
            /// Property for LastBillingsPercentComplete
            /// </summary>
            public const string LastBillingsPercentComplete = "LSTBILLPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BILLAMTSR
            /// </summary>
            public const string BILLAMTSR = "BILLAMTSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BILLAMTHM
            /// </summary>
            public const string BILLAMTHM = "BILLAMTHM";

            /// <summary>
            /// Property for LastCostPostingDate
            /// </summary>
            public const string LastCostPostingDate = "COSTDATE";

            /// <summary>
            /// Property for LastBillingsPostingDate
            /// </summary>
            public const string LastBillingsPostingDate = "BILLDATE";

            /// <summary>
            /// Property for LastOverheadPostingDate
            /// </summary>
            public const string LastOverheadPostingDate = "OHDATE";

            /// <summary>
            /// Property for LastChargePostingDate
            /// </summary>
            public const string LastChargePostingDate = "CHARGEDATE";

            /// <summary>
            /// Property for LastRevRecognitionPostingDa
            /// </summary>
            public const string LastRevRecognitionPostingDa = "REVRECDATE";

            /// <summary>
            /// Property for LastARReceiptPostingDate
            /// </summary>
            public const string LastARReceiptPostingDate = "ARRECDATE";

            /// <summary>
            /// Property for LastAPPaymentPostingDate
            /// </summary>
            public const string LastAPPaymentPostingDate = "APPAYDATE";

            /// <summary>
            /// Property for LastTimecardPostingDate
            /// </summary>
            public const string LastTimecardPostingDate = "TIMEDATE";

            /// <summary>
            /// Property for LastMaterialUsagePostingDate
            /// </summary>
            public const string LastMaterialUsagePostingDate = "STKTRDATE";

            /// <summary>
            /// Property for LastMaterialReturnPostingDat
            /// </summary>
            public const string LastMaterialReturnPostingDat = "STKRETDATE";

            /// <summary>
            /// Property for LastEquipmentPostingDate
            /// </summary>
            public const string LastEquipmentPostingDate = "EQUIPDATE";

            /// <summary>
            /// Property for LastPurchaseOrderDate
            /// </summary>
            public const string LastPurchaseOrderDate = "PODATE";

            /// <summary>
            /// Property for LastPOReceiptDate
            /// </summary>
            public const string LastPOReceiptDate = "PORECDATE";

            /// <summary>
            /// Property for LastPOReturnDate
            /// </summary>
            public const string LastPOReturnDate = "PORETDATE";

            /// <summary>
            /// Property for LastOEOrderDate
            /// </summary>
            public const string LastOEOrderDate = "OEORDDATE";

            /// <summary>
            /// Property for LastOEInvoiceDate
            /// </summary>
            public const string LastOEInvoiceDate = "OEINVDATE";

            /// <summary>
            /// Property for FunctionalRoundingAmount
            /// </summary>
            public const string FunctionalRoundingAmount = "FUNCRND";

            /// <summary>
            /// Property for NextTransactionNumber
            /// </summary>
            public const string NextTransactionNumber = "NEXTTRAN";

            /// <summary>
            /// Property for NumberOfOpenProjects
            /// </summary>
            public const string NumberOfOpenProjects = "OPENPROJ";

            /// <summary>
            /// Property for ContractHasBeenOpened
            /// </summary>
            public const string ContractHasBeenOpened = "OPENED";

            /// <summary>
            /// Property for ExpectedBillings
            /// </summary>
            public const string ExpectedBillings = "BILLAMT";

            /// <summary>
            /// Property for BillingsPercentComplete
            /// </summary>
            public const string BillingsPercentComplete = "PCOMPLETEB";

            /// <summary>
            /// Property for LastRevRecognitionPercentage
            /// </summary>
            public const string LastRevRecognitionPercentage = "LSTRRPER";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PRFTLOSSSR
            /// </summary>
            public const string PRFTLOSSSR = "PRFTLOSSSR";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PRFTLOSSHM
            /// </summary>
            public const string PRFTLOSSHM = "PRFTLOSSHM";

            /// <summary>
            /// Property for LastRevisedPostingDate
            /// </summary>
            public const string LastRevisedPostingDate = "REVESTDATE";

            /// <summary>
            /// Property for CurrentStartDate
            /// </summary>
            public const string CurrentStartDate = "CDATEFROM";

            /// <summary>
            /// Property for PercentageCompleteMethod
            /// </summary>
            public const string PercentageCompleteMethod = "RRMETHOD";

            /// <summary>
            /// Property for NumberOfProjects
            /// </summary>
            public const string NumberOfProjects = "NUMPROJECT";

            /// <summary>
            /// Property for CommittedPOCost
            /// </summary>
            public const string CommittedPOCost = "POCOSTHM";

            /// <summary>
            /// Property for CommittedPOOverhead
            /// </summary>
            public const string CommittedPOOverhead = "POOHHM";

            /// <summary>
            /// Property for CommittedPOLabor
            /// </summary>
            public const string CommittedPOLabor = "POLABORHM";

            /// <summary>
            /// Property for CommittedPOTotalCost
            /// </summary>
            public const string CommittedPOTotalCost = "POTCOSTHM";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CUSCONTACT
            /// </summary>
            public const string CUSCONTACT = "CUSCONTACT";

            /// <summary>
            /// Property for Position
            /// </summary>
            public const string Position = "CTACTITTLE";

            /// <summary>
            /// Property for Phone
            /// </summary>
            public const string Phone = "CTACPHONE";

            /// <summary>
            /// Property for OtherPhone
            /// </summary>
            public const string OtherPhone = "OTHERPHONE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CTACFAX
            /// </summary>
            public const string CTACFAX = "CTACFAX";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "CTACEMAIL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for USETAXGRP
            /// </summary>
            public const string USETAXGRP = "USETAXGRP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CODETAXGRP
            /// </summary>
            public const string CODETAXGRP = "CODETAXGRP";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TCLASS5";

            /// <summary>
            /// Property for CustomerTaxAuthority1
            /// </summary>
            public const string CustomerTaxAuthority1 = "TAUTH1";

            /// <summary>
            /// Property for CustomerTaxAuthority2
            /// </summary>
            public const string CustomerTaxAuthority2 = "TAUTH2";

            /// <summary>
            /// Property for CustomerTaxAuthority3
            /// </summary>
            public const string CustomerTaxAuthority3 = "TAUTH3";

            /// <summary>
            /// Property for CustomerTaxAuthority4
            /// </summary>
            public const string CustomerTaxAuthority4 = "TAUTH4";

            /// <summary>
            /// Property for CustomerTaxAuthority5
            /// </summary>
            public const string CustomerTaxAuthority5 = "TAUTH5";

            /// <summary>
            /// Property for StoredCost
            /// </summary>
            public const string StoredCost = "STRDCOSTHM";

            /// <summary>
            /// Property for StoredBillableAmount
            /// </summary>
            public const string StoredBillableAmount = "STRDBILLSR";

            /// <summary>
            /// Property for OverheadAmount
            /// </summary>
            public const string OverheadAmount = "STRDOHHM";

            /// <summary>
            /// Property for TotalStoredCost
            /// </summary>
            public const string TotalStoredCost = "STRDTCSTHM";

            /// <summary>
            /// Property for TaxExpCommittedFunc
            /// </summary>
            public const string TaxExpCommittedFunc = "TXEXPCOMHM";

            /// <summary>
            /// Property for TaxAllCommittedFunc
            /// </summary>
            public const string TaxAllCommittedFunc = "TXALLCOMHM";

            /// <summary>
            /// Property for PreviousCertificatesForPaymen
            /// </summary>
            public const string PreviousCertificatesForPaymen = "PREAIAPAY";

            /// <summary>
            /// Property for G703ColumnFFromLastAIARepo
            /// </summary>
            public const string G703ColumnFFromLastAIARepo = "PRESTORED";

            /// <summary>
            /// Property for G703ColumnIFromLastAIARepo
            /// </summary>
            public const string G703ColumnIFromLastAIARepo = "PRERETAIN";

            /// <summary>
            /// Property for InvoiceToMultipleCustomers
            /// </summary>
            public const string InvoiceToMultipleCustomers = "MULTICUST";

            /// <summary>
            /// Property for CurrencyDifferentFromThatOn
            /// </summary>
            public const string CurrencyDifferentFromThatOn = "CURVAR";

            /// <summary>
            /// Property for AllowMultipleCustomers
            /// </summary>
            public const string AllowMultipleCustomers = "BONECUST";

            /// <summary>
            /// Property for ARAccountSet
            /// </summary>
            public const string ARAccountSet = "ARACCTSET";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for Num16BitParameter
            /// </summary>
            public const string Num16BitParameter = "PARM16";

            /// <summary>
            /// Property for StringParameter
            /// </summary>
            public const string StringParameter = "PARMSTR";

            /// <summary>
            /// Property for ContractNumberIsValid
            /// </summary>
            public const string ContractNumberIsValid = "CTTVALID";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTNAME";

            /// <summary>
            /// Property for ShowProgressBarDuringPosting
            /// </summary>
            public const string ShowProgressBarDuringPosting = "BMETER";

            /// <summary>
            /// Property for DeletingContract
            /// </summary>
            public const string DeletingContract = "DELETING";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Contracts Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ContractUniq
            /// </summary>
            public const int ContractUniq = 1;

            /// <summary>
            /// Property Indexer for UnformattedContract
            /// </summary>
            public const int UnformattedContract = 2;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 4;

            /// <summary>
            /// Property Indexer for StructureCode
            /// </summary>
            public const int StructureCode = 5;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 6;

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 7;

            /// <summary>
            /// Property Indexer for ContractManager
            /// </summary>
            public const int ContractManager = 8;

            /// <summary>
            /// Property Indexer for PONumber
            /// </summary>
            public const int PONumber = 9;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTACT
            /// </summary>
            public const int CONTACT = 10;

            /// <summary>
            /// Property Indexer for Telephone
            /// </summary>
            public const int Telephone = 11;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FAX
            /// </summary>
            public const int FAX = 12;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 13;

            /// <summary>
            /// Property Indexer for OriginalEndDate
            /// </summary>
            public const int OriginalEndDate = 14;

            /// <summary>
            /// Property Indexer for ProjectedEndDate
            /// </summary>
            public const int ProjectedEndDate = 15;

            /// <summary>
            /// Property Indexer for ClosedDate
            /// </summary>
            public const int ClosedDate = 16;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 17;

            /// <summary>
            /// Property Indexer for UseContractRevenueRecognition
            /// </summary>
            public const int UseContractRevenueRecognition = 18;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 19;

            /// <summary>
            /// Property Indexer for UseTheContractOverheadInform
            /// </summary>
            public const int UseTheContractOverheadInform = 20;

            /// <summary>
            /// Property Indexer for OverheadType
            /// </summary>
            public const int OverheadType = 21;

            /// <summary>
            /// Property Indexer for OverheadRate
            /// </summary>
            public const int OverheadRate = 22;

            /// <summary>
            /// Property Indexer for OverheadPercentage
            /// </summary>
            public const int OverheadPercentage = 23;

            /// <summary>
            /// Property Indexer for UseTheContractLaborType
            /// </summary>
            public const int UseTheContractLaborType = 24;

            /// <summary>
            /// Property Indexer for LaborType
            /// </summary>
            public const int LaborType = 25;

            /// <summary>
            /// Property Indexer for LaborRate
            /// </summary>
            public const int LaborRate = 26;

            /// <summary>
            /// Property Indexer for LaborPercentage
            /// </summary>
            public const int LaborPercentage = 27;

            /// <summary>
            /// Property Indexer for ContractStatus
            /// </summary>
            public const int ContractStatus = 28;

            /// <summary>
            /// Property Indexer for UseCostPlusPercentage
            /// </summary>
            public const int UseCostPlusPercentage = 29;

            /// <summary>
            /// Property Indexer for CostPlusPercentage
            /// </summary>
            public const int CostPlusPercentage = 30;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for USEPTYPE
            /// </summary>
            public const int USEPTYPE = 31;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PROJTYPE
            /// </summary>
            public const int PROJTYPE = 32;

            /// <summary>
            /// Property Indexer for NumberOfChangeOrdersToThe^
            /// </summary>
            public const int NumberOfChangeOrders = 33;

            /// <summary>
            /// Property Indexer for NextChangeOrderNumber
            /// </summary>
            public const int NextChangeOrderNumber = 34;

            /// <summary>
            /// Property Indexer for AccountSet
            /// </summary>
            public const int AccountSet = 35;

            /// <summary>
            /// Property Indexer for Template
            /// </summary>
            public const int Template = 37;

            /// <summary>
            /// Property Indexer for UseTheContractBillingType
            /// </summary>
            public const int UseTheContractBillingType = 38;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 39;

            /// <summary>
            /// Property Indexer for Schedule
            /// </summary>
            public const int Schedule = 40;

            /// <summary>
            /// Property Indexer for UseTheContractRetainageInfor
            /// </summary>
            public const int UseTheContractRetainageInfor = 41;

            /// <summary>
            /// Property Indexer for ARRetainagePercentage
            /// </summary>
            public const int ARRetainagePercentage = 42;

            /// <summary>
            /// Property Indexer for ARRetentionPeriod
            /// </summary>
            public const int ARRetentionPeriod = 43;

            /// <summary>
            /// Property Indexer for Segment1
            /// </summary>
            public const int Segment1 = 58;

            /// <summary>
            /// Property Indexer for Segment2
            /// </summary>
            public const int Segment2 = 59;

            /// <summary>
            /// Property Indexer for Segment3
            /// </summary>
            public const int Segment3 = 60;

            /// <summary>
            /// Property Indexer for Segment4
            /// </summary>
            public const int Segment4 = 61;

            /// <summary>
            /// Property Indexer for Segment5
            /// </summary>
            public const int Segment5 = 62;

            /// <summary>
            /// Property Indexer for ConsolidateProjectsOntoTheOn
            /// </summary>
            public const int ConsolidateProjectsOntoTheOn = 63;

            /// <summary>
            /// Property Indexer for FormCode
            /// </summary>
            public const int FormCode = 64;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 65;

            /// <summary>
            /// Property Indexer for NumberOfDetails
            /// </summary>
            public const int NumberOfDetails = 66;

            /// <summary>
            /// Property Indexer for RevenueAndCostCurrency
            /// </summary>
            public const int RevenueAndCostCurrency = 67;

            /// <summary>
            /// Property Indexer for CustomerCurrency
            /// </summary>
            public const int CustomerCurrency = 68;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 69;

            /// <summary>
            /// Property Indexer for NumberOfNonPercentProjects
            /// </summary>
            public const int NumberOfNonPercentProjects = 70;

            /// <summary>
            /// Property Indexer for OriginalLaborCostEst
            /// </summary>
            public const int OriginalLaborCostEst = 71;

            /// <summary>
            /// Property Indexer for CurrencyLaborCostEst
            /// </summary>
            public const int CurrencyLaborCostEst = 73;

            /// <summary>
            /// Property Indexer for ActualLaborCosts
            /// </summary>
            public const int ActualLaborCosts = 75;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJTIMEBSR
            /// </summary>
            public const int ORJTIMEBSR = 80;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJTIMEBHM
            /// </summary>
            public const int ORJTIMEBHM = 81;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURTIMEBSR
            /// </summary>
            public const int CURTIMEBSR = 82;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURTIMEBHM
            /// </summary>
            public const int CURTIMEBHM = 83;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTTIMEBSR
            /// </summary>
            public const int ACTTIMEBSR = 84;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTTIMEBHM
            /// </summary>
            public const int ACTTIMEBHM = 85;

            /// <summary>
            /// Property Indexer for OriginalLaborQtyEst
            /// </summary>
            public const int OriginalLaborQtyEst = 90;

            /// <summary>
            /// Property Indexer for CurrencyLaborQtyEst
            /// </summary>
            public const int CurrencyLaborQtyEst = 91;

            /// <summary>
            /// Property Indexer for ActualLaborQty
            /// </summary>
            public const int ActualLaborQty = 92;

            /// <summary>
            /// Property Indexer for LaborPercentageComplete
            /// </summary>
            public const int LaborPercentageComplete = 93;

            /// <summary>
            /// Property Indexer for OriginalMaterialEstimatedCost
            /// </summary>
            public const int OriginalMaterialEstimatedCost = 95;

            /// <summary>
            /// Property Indexer for CurrentMaterialEstimatedCost
            /// </summary>
            public const int CurrentMaterialEstimatedCost = 97;

            /// <summary>
            /// Property Indexer for ActualMaterialCost
            /// </summary>
            public const int ActualMaterialCost = 99;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMATEBSR
            /// </summary>
            public const int ORJMATEBSR = 104;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMATEBHM
            /// </summary>
            public const int ORJMATEBHM = 105;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMATEBSR
            /// </summary>
            public const int CURMATEBSR = 106;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMATEBHM
            /// </summary>
            public const int CURMATEBHM = 107;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMATEBSR
            /// </summary>
            public const int ACTMATEBSR = 108;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMATEBHM
            /// </summary>
            public const int ACTMATEBHM = 109;

            /// <summary>
            /// Property Indexer for OriginalMaterialQtyEst
            /// </summary>
            public const int OriginalMaterialQtyEst = 114;

            /// <summary>
            /// Property Indexer for CurrencyMaterialEst
            /// </summary>
            public const int CurrencyMaterialEst = 115;

            /// <summary>
            /// Property Indexer for ActualMaterialQty
            /// </summary>
            public const int ActualMaterialQty = 116;

            /// <summary>
            /// Property Indexer for OriginalEstimatedEquipmentCost
            /// </summary>
            public const int OriginalEstimatedEquipmentCost = 119;

            /// <summary>
            /// Property Indexer for CurrencyEstimatedEquipmentCost
            /// </summary>
            public const int CurrencyEstimatedEquipmentCost = 121;

            /// <summary>
            /// Property Indexer for ActualEquipmentCost
            /// </summary>
            public const int ActualEquipmentCost = 123;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJEQUIBSR
            /// </summary>
            public const int ORJEQUIBSR = 128;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJEQUIBHM
            /// </summary>
            public const int ORJEQUIBHM = 129;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUREQUIBSR
            /// </summary>
            public const int CUREQUIBSR = 130;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUREQUIBHM
            /// </summary>
            public const int CUREQUIBHM = 131;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTEQUIBSR
            /// </summary>
            public const int ACTEQUIBSR = 132;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTEQUIBHM
            /// </summary>
            public const int ACTEQUIBHM = 133;

            /// <summary>
            /// Property Indexer for OriginalEquipmentQtyEst
            /// </summary>
            public const int OriginalEquipmentQtyEst = 138;

            /// <summary>
            /// Property Indexer for CurrencyEquipmentEst
            /// </summary>
            public const int CurrencyEquipmentEst = 139;

            /// <summary>
            /// Property Indexer for ActualEquipmentQty
            /// </summary>
            public const int ActualEquipmentQty = 140;

            /// <summary>
            /// Property Indexer for OriginalSubcontractorEstCost
            /// </summary>
            public const int OriginalSubcontractorEstCost = 143;

            /// <summary>
            /// Property Indexer for CurrencySubcontractorEstCost
            /// </summary>
            public const int CurrencySubcontractorEstCost = 145;

            /// <summary>
            /// Property Indexer for ActualSubcontractorCost
            /// </summary>
            public const int ActualSubcontractorCost = 147;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJSUBCBSR
            /// </summary>
            public const int ORJSUBCBSR = 152;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJSUBCBHM
            /// </summary>
            public const int ORJSUBCBHM = 153;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURSUBCBSR
            /// </summary>
            public const int CURSUBCBSR = 154;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURSUBCBHM
            /// </summary>
            public const int CURSUBCBHM = 155;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTSUBCBSR
            /// </summary>
            public const int ACTSUBCBSR = 156;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTSUBCBHM
            /// </summary>
            public const int ACTSUBCBHM = 157;

            /// <summary>
            /// Property Indexer for OriginalSubcontractorQtyEst
            /// </summary>
            public const int OriginalSubcontractorQtyEst = 162;

            /// <summary>
            /// Property Indexer for CurrencySubcontractorEst
            /// </summary>
            public const int CurrencySubcontractorEst = 163;

            /// <summary>
            /// Property Indexer for ActualSubcontractorQty
            /// </summary>
            public const int ActualSubcontractorQty = 164;

            /// <summary>
            /// Property Indexer for OriginalEstOverheadExpenseCost
            /// </summary>
            public const int OriginalEstOverheadExpenseCost = 167;

            /// <summary>
            /// Property Indexer for CurrencyEstOverheadExpenseCost
            /// </summary>
            public const int CurrencyEstOverheadExpenseCost = 169;

            /// <summary>
            /// Property Indexer for ActualOverheadExpenseCost
            /// </summary>
            public const int ActualOverheadExpenseCost = 171;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJOHEXBSR
            /// </summary>
            public const int ORJOHEXBSR = 176;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJOHEXBHM
            /// </summary>
            public const int ORJOHEXBHM = 177;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUROHEXBSR
            /// </summary>
            public const int CUROHEXBSR = 178;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUROHEXBHM
            /// </summary>
            public const int CUROHEXBHM = 179;

            /// <summary>
            /// Property Indexer for ActualOverheadAmountBilled
            /// </summary>
            public const int ActualOverheadAmountBilled = 180;

            /// <summary>
            /// Property Indexer for ActualOverheadBillingEst
            /// </summary>
            public const int ActualOverheadBillingEst = 181;

            /// <summary>
            /// Property Indexer for OriginalOverheadQtyEst
            /// </summary>
            public const int OriginalOverheadQtyEst = 186;

            /// <summary>
            /// Property Indexer for CurrencyOverheadEst
            /// </summary>
            public const int CurrencyOverheadEst = 187;

            /// <summary>
            /// Property Indexer for ActualOverheadQty
            /// </summary>
            public const int ActualOverheadQty = 188;

            /// <summary>
            /// Property Indexer for OriginalEstMiscellaneousCost
            /// </summary>
            public const int OriginalEstMiscellaneousCost = 191;

            /// <summary>
            /// Property Indexer for CurrencyEstMiscellaneousCost
            /// </summary>
            public const int CurrencyEstMiscellaneousCost = 193;

            /// <summary>
            /// Property Indexer for ActualMiscellaneousCost
            /// </summary>
            public const int ActualMiscellaneousCost = 195;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMISCBSR
            /// </summary>
            public const int ORJMISCBSR = 200;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJMISCBHM
            /// </summary>
            public const int ORJMISCBHM = 201;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMISCBSR
            /// </summary>
            public const int CURMISCBSR = 202;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURMISCBHM
            /// </summary>
            public const int CURMISCBHM = 203;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMISCBSR
            /// </summary>
            public const int ACTMISCBSR = 204;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTMISCBHM
            /// </summary>
            public const int ACTMISCBHM = 205;

            /// <summary>
            /// Property Indexer for OriginalMiscellaneousQtyEst
            /// </summary>
            public const int OriginalMiscellaneousQtyEst = 210;

            /// <summary>
            /// Property Indexer for CurrencyMiscellaneousEst
            /// </summary>
            public const int CurrencyMiscellaneousEst = 211;

            /// <summary>
            /// Property Indexer for ActualMiscellaneousQty
            /// </summary>
            public const int ActualMiscellaneousQty = 212;

            /// <summary>
            /// Property Indexer for OriginalOverheadEstimate
            /// </summary>
            public const int OriginalOverheadEstimate = 215;

            /// <summary>
            /// Property Indexer for CurrentOverheadEstimate
            /// </summary>
            public const int CurrentOverheadEstimate = 217;

            /// <summary>
            /// Property Indexer for ActualOverhead
            /// </summary>
            public const int ActualOverhead = 219;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJLABSR
            /// </summary>
            public const int ORJLABSR = 224;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ORJLABHM
            /// </summary>
            public const int ORJLABHM = 225;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURLABSR
            /// </summary>
            public const int CURLABSR = 226;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CURLABHM
            /// </summary>
            public const int CURLABHM = 227;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTLABSR
            /// </summary>
            public const int ACTLABSR = 228;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTLABHM
            /// </summary>
            public const int ACTLABHM = 229;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGSR
            /// </summary>
            public const int ACTCHRGSR = 238;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGHM
            /// </summary>
            public const int ACTCHRGHM = 239;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGDSR
            /// </summary>
            public const int ACTCHRGDSR = 240;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ACTCHRGDHM
            /// </summary>
            public const int ACTCHRGDHM = 241;

            /// <summary>
            /// Property Indexer for ActCostStockRetToInventory
            /// </summary>
            public const int ActCostStockRetToInventory = 247;

            /// <summary>
            /// Property Indexer for ActQtyStockRetToInventory
            /// </summary>
            public const int ActQtyStockRetToInventory = 248;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TARRECTSSR
            /// </summary>
            public const int TARRECTSSR = 249;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TARRECTSHM
            /// </summary>
            public const int TARRECTSHM = 250;

            /// <summary>
            /// Property Indexer for TotalAPVendorPayments
            /// </summary>
            public const int TotalAPVendorPayments = 251;

            /// <summary>
            /// Property Indexer for TotalOriginalCostEst
            /// </summary>
            public const int TotalOriginalCostEst = 253;

            /// <summary>
            /// Property Indexer for TotalCurrencyCostEst
            /// </summary>
            public const int TotalCurrencyCostEst = 255;

            /// <summary>
            /// Property Indexer for TotalActualCost
            /// </summary>
            public const int TotalActualCost = 257;

            /// <summary>
            /// Property Indexer for TotalCostRecognized
            /// </summary>
            public const int TotalCostRecognized = 259;

            /// <summary>
            /// Property Indexer for PercentTotalCost
            /// </summary>
            public const int PercentTotalCost = 260;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TORJREVSR
            /// </summary>
            public const int TORJREVSR = 262;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TORJREVHM
            /// </summary>
            public const int TORJREVHM = 263;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TCURREVSR
            /// </summary>
            public const int TCURREVSR = 264;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TCURREVHM
            /// </summary>
            public const int TCURREVHM = 265;

            /// <summary>
            /// Property Indexer for TotalActualRevenue
            /// </summary>
            public const int TotalActualRevenue = 266;

            /// <summary>
            /// Property Indexer for TotalActualRevenueEst
            /// </summary>
            public const int TotalActualRevenueEst = 267;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TRECREVSR
            /// </summary>
            public const int TRECREVSR = 268;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TRECREVHM
            /// </summary>
            public const int TRECREVHM = 269;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARAMTSR
            /// </summary>
            public const int RETARAMTSR = 272;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARAMTHM
            /// </summary>
            public const int RETARAMTHM = 273;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARRECSR
            /// </summary>
            public const int RETARRECSR = 274;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for RETARRECHM
            /// </summary>
            public const int RETARRECHM = 275;

            /// <summary>
            /// Property Indexer for RetainagePayable
            /// </summary>
            public const int RetainagePayable = 276;

            /// <summary>
            /// Property Indexer for RetainageAmountPaidInAP
            /// </summary>
            public const int RetainageAmountPaidInAP = 277;

            /// <summary>
            /// Property Indexer for RecognizedLoss
            /// </summary>
            public const int RecognizedLoss = 282;

            /// <summary>
            /// Property Indexer for RecognizedComplete
            /// </summary>
            public const int RecognizedComplete = 286;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FPAMOUNTSR
            /// </summary>
            public const int FPAMOUNTSR = 287;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FPAMOUNTHM
            /// </summary>
            public const int FPAMOUNTHM = 288;

            /// <summary>
            /// Property Indexer for LastBillingsPercentComplete
            /// </summary>
            public const int LastBillingsPercentComplete = 289;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BILLAMTSR
            /// </summary>
            public const int BILLAMTSR = 290;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BILLAMTHM
            /// </summary>
            public const int BILLAMTHM = 291;

            /// <summary>
            /// Property Indexer for LastCostPostingDate
            /// </summary>
            public const int LastCostPostingDate = 294;

            /// <summary>
            /// Property Indexer for LastBillingsPostingDate
            /// </summary>
            public const int LastBillingsPostingDate = 295;

            /// <summary>
            /// Property Indexer for LastOverheadPostingDate
            /// </summary>
            public const int LastOverheadPostingDate = 296;

            /// <summary>
            /// Property Indexer for LastChargePostingDate
            /// </summary>
            public const int LastChargePostingDate = 297;

            /// <summary>
            /// Property Indexer for LastRevRecognitionPostingDa
            /// </summary>
            public const int LastRevRecognitionPostingDa = 298;

            /// <summary>
            /// Property Indexer for LastARReceiptPostingDate
            /// </summary>
            public const int LastARReceiptPostingDate = 299;

            /// <summary>
            /// Property Indexer for LastAPPaymentPostingDate
            /// </summary>
            public const int LastAPPaymentPostingDate = 300;

            /// <summary>
            /// Property Indexer for LastTimecardPostingDate
            /// </summary>
            public const int LastTimecardPostingDate = 301;

            /// <summary>
            /// Property Indexer for LastMaterialUsagePostingDate
            /// </summary>
            public const int LastMaterialUsagePostingDate = 302;

            /// <summary>
            /// Property Indexer for LastMaterialReturnPostingDat
            /// </summary>
            public const int LastMaterialReturnPostingDat = 303;

            /// <summary>
            /// Property Indexer for LastEquipmentPostingDate
            /// </summary>
            public const int LastEquipmentPostingDate = 304;

            /// <summary>
            /// Property Indexer for LastPurchaseOrderDate
            /// </summary>
            public const int LastPurchaseOrderDate = 305;

            /// <summary>
            /// Property Indexer for LastPOReceiptDate
            /// </summary>
            public const int LastPOReceiptDate = 306;

            /// <summary>
            /// Property Indexer for LastPOReturnDate
            /// </summary>
            public const int LastPOReturnDate = 307;

            /// <summary>
            /// Property Indexer for LastOEOrderDate
            /// </summary>
            public const int LastOEOrderDate = 308;

            /// <summary>
            /// Property Indexer for LastOEInvoiceDate
            /// </summary>
            public const int LastOEInvoiceDate = 309;

            /// <summary>
            /// Property Indexer for FunctionalRoundingAmount
            /// </summary>
            public const int FunctionalRoundingAmount = 310;

            /// <summary>
            /// Property Indexer for NextTransactionNumber
            /// </summary>
            public const int NextTransactionNumber = 311;

            /// <summary>
            /// Property Indexer for NumberOfOpenProjects
            /// </summary>
            public const int NumberOfOpenProjects = 312;

            /// <summary>
            /// Property Indexer for ContractHasBeenOpened
            /// </summary>
            public const int ContractHasBeenOpened = 313;

            /// <summary>
            /// Property Indexer for ExpectedBillings
            /// </summary>
            public const int ExpectedBillings = 314;

            /// <summary>
            /// Property Indexer for BillingsPercentComplete
            /// </summary>
            public const int BillingsPercentComplete = 315;

            /// <summary>
            /// Property Indexer for LastRevRecognitionPercentage
            /// </summary>
            public const int LastRevRecognitionPercentage = 316;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PRFTLOSSSR
            /// </summary>
            public const int PRFTLOSSSR = 317;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PRFTLOSSHM
            /// </summary>
            public const int PRFTLOSSHM = 318;

            /// <summary>
            /// Property Indexer for LastRevisedPostingDate
            /// </summary>
            public const int LastRevisedPostingDate = 319;

            /// <summary>
            /// Property Indexer for CurrentStartDate
            /// </summary>
            public const int CurrentStartDate = 320;

            /// <summary>
            /// Property Indexer for PercentageCompleteMethod
            /// </summary>
            public const int PercentageCompleteMethod = 322;

            /// <summary>
            /// Property Indexer for NumberOfProjects
            /// </summary>
            public const int NumberOfProjects = 323;

            /// <summary>
            /// Property Indexer for CommittedPOCost
            /// </summary>
            public const int CommittedPOCost = 324;

            /// <summary>
            /// Property Indexer for CommittedPOOverhead
            /// </summary>
            public const int CommittedPOOverhead = 325;

            /// <summary>
            /// Property Indexer for CommittedPOLabor
            /// </summary>
            public const int CommittedPOLabor = 326;

            /// <summary>
            /// Property Indexer for CommittedPOTotalCost
            /// </summary>
            public const int CommittedPOTotalCost = 327;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 328;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CUSCONTACT
            /// </summary>
            public const int CUSCONTACT = 329;

            /// <summary>
            /// Property Indexer for Position
            /// </summary>
            public const int Position = 330;

            /// <summary>
            /// Property Indexer for Phone
            /// </summary>
            public const int Phone = 331;

            /// <summary>
            /// Property Indexer for OtherPhone
            /// </summary>
            public const int OtherPhone = 332;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CTACFAX
            /// </summary>
            public const int CTACFAX = 333;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 334;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for USETAXGRP
            /// </summary>
            public const int USETAXGRP = 335;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CODETAXGRP
            /// </summary>
            public const int CODETAXGRP = 336;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 337;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 338;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 339;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 340;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 341;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority1
            /// </summary>
            public const int CustomerTaxAuthority1 = 342;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority2
            /// </summary>
            public const int CustomerTaxAuthority2 = 343;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority3
            /// </summary>
            public const int CustomerTaxAuthority3 = 344;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority4
            /// </summary>
            public const int CustomerTaxAuthority4 = 345;

            /// <summary>
            /// Property Indexer for CustomerTaxAuthority5
            /// </summary>
            public const int CustomerTaxAuthority5 = 346;

            /// <summary>
            /// Property Indexer for StoredCost
            /// </summary>
            public const int StoredCost = 347;

            /// <summary>
            /// Property Indexer for StoredBillableAmount
            /// </summary>
            public const int StoredBillableAmount = 348;

            /// <summary>
            /// Property Indexer for OverheadAmount
            /// </summary>
            public const int OverheadAmount = 349;

            /// <summary>
            /// Property Indexer for TotalStoredCost
            /// </summary>
            public const int TotalStoredCost = 350;

            /// <summary>
            /// Property Indexer for TaxExpCommittedFunc
            /// </summary>
            public const int TaxExpCommittedFunc = 351;

            /// <summary>
            /// Property Indexer for TaxAllCommittedFunc
            /// </summary>
            public const int TaxAllCommittedFunc = 352;

            /// <summary>
            /// Property Indexer for PreviousCertificatesForPaymen
            /// </summary>
            public const int PreviousCertificatesForPaymen = 353;

            /// <summary>
            /// Property Indexer for G703ColumnFFromLastAIARepo
            /// </summary>
            public const int G703ColumnFFromLastAIARepo = 354;

            /// <summary>
            /// Property Indexer for G703ColumnIFromLastAIARepo
            /// </summary>
            public const int G703ColumnIFromLastAIARepo = 355;

            /// <summary>
            /// Property Indexer for InvoiceToMultipleCustomers
            /// </summary>
            public const int InvoiceToMultipleCustomers = 356;

            /// <summary>
            /// Property Indexer for CurrencyDifferentFromThatOn
            /// </summary>
            public const int CurrencyDifferentFromThatOn = 357;

            /// <summary>
            /// Property Indexer for AllowMultipleCustomers
            /// </summary>
            public const int AllowMultipleCustomers = 358;

            /// <summary>
            /// Property Indexer for ARAccountSet
            /// </summary>
            public const int ARAccountSet = 359;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1000;

            /// <summary>
            /// Property Indexer for Num16BitParameter
            /// </summary>
            public const int Num16BitParameter = 1001;

            /// <summary>
            /// Property Indexer for StringParameter
            /// </summary>
            public const int StringParameter = 1002;

            /// <summary>
            /// Property Indexer for ContractNumberIsValid
            /// </summary>
            public const int ContractNumberIsValid = 1006;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 1007;

            /// <summary>
            /// Property Indexer for ShowProgressBarDuringPosting
            /// </summary>
            public const int ShowProgressBarDuringPosting = 1008;

            /// <summary>
            /// Property Indexer for DeletingContract
            /// </summary>
            public const int DeletingContract = 1009;


        }

        #endregion

    }
}