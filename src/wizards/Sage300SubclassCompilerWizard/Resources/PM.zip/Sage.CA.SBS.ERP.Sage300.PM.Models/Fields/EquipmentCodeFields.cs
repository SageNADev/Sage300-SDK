// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Equipments Constants
    /// </summary>
    public partial class EquipmentCode
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0025";


        #region Properties

        /// <summary>
        /// Contains list of Equipments Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for EquipmentCode
            /// </summary>
            public const string EquipmentCodeNo = "EQUIPMENT";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for DateInactive
            /// </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Equipments Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for EquipmentCode
            /// </summary>
            public const int EquipmentCode = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 4;

            /// <summary>
            /// Property Indexer for DateInactive
            /// </summary>
            public const int DateInactive = 5;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 6;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 7;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 8;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 9;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 10;


        }

        #endregion

    }
}