// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of EmployeeDetailView Constants
    /// </summary>
    public partial class EmployeeDetailView
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0479";


        #region Properties

        /// <summary>
        /// Contains list of EmployeeDetailView Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for StaffCode
            /// </summary>
            public const string StaffCode = "STAFFCODE";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CCY";

            /// <summary>
            /// Property for PayType
            /// </summary>
            public const string PayType = "PAYTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "DESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of EmployeeDetailView Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for StaffCode
            /// </summary>
            public const int StaffCode = 1;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 2;

            /// <summary>
            /// Property Indexer for PayType
            /// </summary>
            public const int PayType = 3;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 4;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 5;


        }

        #endregion

    }
}