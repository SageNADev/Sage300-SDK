// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of BudgetDetail Constants
    /// </summary>
    public partial class BudgetDetail
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0122";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"RATETYPE", "RateType"},
                    {"RATEDATE", "RateDate"},
                    {"RATE", "Rate"},
                };
            }
        }

        #region Fields Properties

        /// <summary>
        /// Contains list of BudgetDetail Field Constants
        /// </summary>
        public class Fields
        {
            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SEQ
            /// </summary>
            public const string SEQ = "SEQ";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for LINENUM
            /// </summary>
            public const string LINENUM = "LINENUM";

            /// <summary>
            /// Property for ContractUniq
            /// </summary>
            public const string ContractUniq = "CTUNIQ";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCALYEAR";

            /// <summary>
            /// Property for BudgetSet
            /// </summary>
            public const string BudgetSet = "BUDGET";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Resource
            /// </summary>
            public const string Resource = "RESOURCE";

            /// <summary>
            /// Property for RevenueCurrency
            /// </summary>
            public const string RevenueCurrency = "REVCCY";

            /// <summary>
            /// Property for CostCurrency
            /// </summary>
            public const string CostCurrency = "COSTCCY";

            /// <summary>
            /// Property for CurrencyType
            /// </summary>
            public const string CurrencyType = "CCYTYPE";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for QuantityForPeriod1
            /// </summary>
            public const string QuantityForPeriod1 = "Q1";

            /// <summary>
            /// Property for QuantityForPeriod2
            /// </summary>
            public const string QuantityForPeriod2 = "Q2";

            /// <summary>
            /// Property for QuantityForPeriod3
            /// </summary>
            public const string QuantityForPeriod3 = "Q3";

            /// <summary>
            /// Property for QuantityForPeriod4
            /// </summary>
            public const string QuantityForPeriod4 = "Q4";

            /// <summary>
            /// Property for QuantityForPeriod5
            /// </summary>
            public const string QuantityForPeriod5 = "Q5";

            /// <summary>
            /// Property for QuantityForPeriod6
            /// </summary>
            public const string QuantityForPeriod6 = "Q6";

            /// <summary>
            /// Property for QuantityForPeriod7
            /// </summary>
            public const string QuantityForPeriod7 = "Q7";

            /// <summary>
            /// Property for QuantityForPeriod8
            /// </summary>
            public const string QuantityForPeriod8 = "Q8";

            /// <summary>
            /// Property for QuantityForPeriod9
            /// </summary>
            public const string QuantityForPeriod9 = "Q9";

            /// <summary>
            /// Property for QuantityForPeriod10
            /// </summary>
            public const string QuantityForPeriod10 = "Q10";

            /// <summary>
            /// Property for QuantityForPeriod11
            /// </summary>
            public const string QuantityForPeriod11 = "Q11";

            /// <summary>
            /// Property for QuantityForPeriod12
            /// </summary>
            public const string QuantityForPeriod12 = "Q12";

            /// <summary>
            /// Property for QuantityForPeriod13
            /// </summary>
            public const string QuantityForPeriod13 = "Q13";

            /// <summary>
            /// Property for Q14
            /// </summary>
            public const string Q14 = "Q14";

            /// <summary>
            /// Property for Q15
            /// </summary>
            public const string Q15 = "Q15";

            /// <summary>
            /// Property for TotalQuantityForTheYear
            /// </summary>
            public const string TotalQuantityForTheYear = "QTOTAL";

            /// <summary>
            /// Property for CS1
            /// </summary>
            public const string CS1 = "CS1";

            /// <summary>
            /// Property for TotalCostSourceForPeriod2
            /// </summary>
            public const string TotalCostSourceForPeriod2 = "CS2";

            /// <summary>
            /// Property for TotalCostSourceForPeriod3
            /// </summary>
            public const string TotalCostSourceForPeriod3 = "CS3";

            /// <summary>
            /// Property for TotalCostSourceForPeriod4
            /// </summary>
            public const string TotalCostSourceForPeriod4 = "CS4";

            /// <summary>
            /// Property for TotalCostSourceForPeriod5
            /// </summary>
            public const string TotalCostSourceForPeriod5 = "CS5";

            /// <summary>
            /// Property for TotalCostSourceForPeriod6
            /// </summary>
            public const string TotalCostSourceForPeriod6 = "CS6";

            /// <summary>
            /// Property for TotalCostSourceForPeriod7
            /// </summary>
            public const string TotalCostSourceForPeriod7 = "CS7";

            /// <summary>
            /// Property for TotalCostSourceForPeriod8
            /// </summary>
            public const string TotalCostSourceForPeriod8 = "CS8";

            /// <summary>
            /// Property for TotalCostSourceForPeriod9
            /// </summary>
            public const string TotalCostSourceForPeriod9 = "CS9";

            /// <summary>
            /// Property for CS10
            /// </summary>
            public const string CS10 = "CS10";

            /// <summary>
            /// Property for CS11
            /// </summary>
            public const string CS11 = "CS11";

            /// <summary>
            /// Property for CS12
            /// </summary>
            public const string CS12 = "CS12";

            /// <summary>
            /// Property for CS13
            /// </summary>
            public const string CS13 = "CS13";

            /// <summary>
            /// Property for CS14
            /// </summary>
            public const string CS14 = "CS14";

            /// <summary>
            /// Property for CS15
            /// </summary>
            public const string CS15 = "CS15";

            /// <summary>
            /// Property for TotalCostSourceForTheYear
            /// </summary>
            public const string TotalCostSourceForTheYear = "CSTOTAL";

            /// <summary>
            /// Property for CH1
            /// </summary>
            public const string CH1 = "CH1";

            /// <summary>
            /// Property for CH2
            /// </summary>
            public const string CH2 = "CH2";

            /// <summary>
            /// Property for CH3
            /// </summary>
            public const string CH3 = "CH3";

            /// <summary>
            /// Property for CH4
            /// </summary>
            public const string CH4 = "CH4";

            /// <summary>
            /// Property for CH5
            /// </summary>
            public const string CH5 = "CH5";

            /// <summary>
            /// Property for CH6
            /// </summary>
            public const string CH6 = "CH6";

            /// <summary>
            /// Property for CH7
            /// </summary>
            public const string CH7 = "CH7";

            /// <summary>
            /// Property for CH8
            /// </summary>
            public const string CH8 = "CH8";

            /// <summary>
            /// Property for CH9
            /// </summary>
            public const string CH9 = "CH9";

            /// <summary>
            /// Property for CH10
            /// </summary>
            public const string CH10 = "CH10";

            /// <summary>
            /// Property for CH11
            /// </summary>
            public const string CH11 = "CH11";

            /// <summary>
            /// Property for CH12
            /// </summary>
            public const string CH12 = "CH12";

            /// <summary>
            /// Property for CH13
            /// </summary>
            public const string CH13 = "CH13";

            /// <summary>
            /// Property for CH14
            /// </summary>
            public const string CH14 = "CH14";

            /// <summary>
            /// Property for CH15
            /// </summary>
            public const string CH15 = "CH15";

            /// <summary>
            /// Property for TotalCostFunctionalForThe
            /// </summary>
            public const string TotalCostFunctionalForThe = "CHTOTAL";

            /// <summary>
            /// Property for RS1
            /// </summary>
            public const string RS1 = "RS1";

            /// <summary>
            /// Property for RS2
            /// </summary>
            public const string RS2 = "RS2";

            /// <summary>
            /// Property for RS3
            /// </summary>
            public const string RS3 = "RS3";

            /// <summary>
            /// Property for RS4
            /// </summary>
            public const string RS4 = "RS4";

            /// <summary>
            /// Property for RS5
            /// </summary>
            public const string RS5 = "RS5";

            /// <summary>
            /// Property for RS6
            /// </summary>
            public const string RS6 = "RS6";

            /// <summary>
            /// Property for RS7
            /// </summary>
            public const string RS7 = "RS7";

            /// <summary>
            /// Property for RS8
            /// </summary>
            public const string RS8 = "RS8";

            /// <summary>
            /// Property for RS9
            /// </summary>
            public const string RS9 = "RS9";

            /// <summary>
            /// Property for RS10
            /// </summary>
            public const string RS10 = "RS10";

            /// <summary>
            /// Property for RS11
            /// </summary>
            public const string RS11 = "RS11";

            /// <summary>
            /// Property for RS12
            /// </summary>
            public const string RS12 = "RS12";

            /// <summary>
            /// Property for RS13
            /// </summary>
            public const string RS13 = "RS13";

            /// <summary>
            /// Property for RS14
            /// </summary>
            public const string RS14 = "RS14";

            /// <summary>
            /// Property for RS15
            /// </summary>
            public const string RS15 = "RS15";

            /// <summary>
            /// Property for TotalRevenueSourceForTheY
            /// </summary>
            public const string TotalRevenueSourceForTheY = "RSTOTAL";

            /// <summary>
            /// Property for RH1
            /// </summary>
            public const string RH1 = "RH1";

            /// <summary>
            /// Property for RH2
            /// </summary>
            public const string RH2 = "RH2";

            /// <summary>
            /// Property for RH3
            /// </summary>
            public const string RH3 = "RH3";

            /// <summary>
            /// Property for RH4
            /// </summary>
            public const string RH4 = "RH4";

            /// <summary>
            /// Property for RH5
            /// </summary>
            public const string RH5 = "RH5";

            /// <summary>
            /// Property for RH6
            /// </summary>
            public const string RH6 = "RH6";

            /// <summary>
            /// Property for RH7
            /// </summary>
            public const string RH7 = "RH7";

            /// <summary>
            /// Property for RH8
            /// </summary>
            public const string RH8 = "RH8";

            /// <summary>
            /// Property for RH9
            /// </summary>
            public const string RH9 = "RH9";

            /// <summary>
            /// Property for RH10
            /// </summary>
            public const string RH10 = "RH10";

            /// <summary>
            /// Property for RH11
            /// </summary>
            public const string RH11 = "RH11";

            /// <summary>
            /// Property for RH12
            /// </summary>
            public const string RH12 = "RH12";

            /// <summary>
            /// Property for RH13
            /// </summary>
            public const string RH13 = "RH13";

            /// <summary>
            /// Property for RH14
            /// </summary>
            public const string RH14 = "RH14";

            /// <summary>
            /// Property for RH15
            /// </summary>
            public const string RH15 = "RH15";

            /// <summary>
            /// Property for TotalRevenueFunctionalForT
            /// </summary>
            public const string TotalRevenueFunctionalForT = "RHTOTAL";

            /// <summary>
            /// Property for InquiryQuantityForPeriod1
            /// </summary>
            public const string InquiryQuantityForPeriod1 = "INQ1";

            /// <summary>
            /// Property for InquiryQuantityForPeriod2
            /// </summary>
            public const string InquiryQuantityForPeriod2 = "INQ2";

            /// <summary>
            /// Property for InquiryQuantityForPeriod3
            /// </summary>
            public const string InquiryQuantityForPeriod3 = "INQ3";

            /// <summary>
            /// Property for InquiryQuantityForPeriod4
            /// </summary>
            public const string InquiryQuantityForPeriod4 = "INQ4";

            /// <summary>
            /// Property for InquiryQuantityForPeriod5
            /// </summary>
            public const string InquiryQuantityForPeriod5 = "INQ5";

            /// <summary>
            /// Property for InquiryQuantityForPeriod6
            /// </summary>
            public const string InquiryQuantityForPeriod6 = "INQ6";

            /// <summary>
            /// Property for InquiryQuantityForPeriod7
            /// </summary>
            public const string InquiryQuantityForPeriod7 = "INQ7";

            /// <summary>
            /// Property for InquiryQuantityForPeriod8
            /// </summary>
            public const string InquiryQuantityForPeriod8 = "INQ8";

            /// <summary>
            /// Property for InquiryQuantityForPeriod9
            /// </summary>
            public const string InquiryQuantityForPeriod9 = "INQ9";

            /// <summary>
            /// Property for InquiryQuantityForPeriod10
            /// </summary>
            public const string InquiryQuantityForPeriod10 = "INQ10";

            /// <summary>
            /// Property for InquiryQuantityForPeriod11
            /// </summary>
            public const string InquiryQuantityForPeriod11 = "INQ11";

            /// <summary>
            /// Property for InquiryQuantityForPeriod12
            /// </summary>
            public const string InquiryQuantityForPeriod12 = "INQ12";

            /// <summary>
            /// Property for InquiryQuantityForPeriod13
            /// </summary>
            public const string InquiryQuantityForPeriod13 = "INQ13";

            /// <summary>
            /// Property for INQ14
            /// </summary>
            public const string INQ14 = "INQ14";

            /// <summary>
            /// Property for INQ15
            /// </summary>
            public const string INQ15 = "INQ15";

            /// <summary>
            /// Property for InquiryTotalQuantityForTheY
            /// </summary>
            public const string InquiryTotalQuantityForTheY = "INQTOTAL";

            /// <summary>
            /// Property for INCS1
            /// </summary>
            public const string INCS1 = "INCS1";

            /// <summary>
            /// Property for INCS2
            /// </summary>
            public const string INCS2 = "INCS2";

            /// <summary>
            /// Property for INCS3
            /// </summary>
            public const string INCS3 = "INCS3";

            /// <summary>
            /// Property for INCS4
            /// </summary>
            public const string INCS4 = "INCS4";

            /// <summary>
            /// Property for INCS5
            /// </summary>
            public const string INCS5 = "INCS5";

            /// <summary>
            /// Property for INCS6
            /// </summary>
            public const string INCS6 = "INCS6";

            /// <summary>
            /// Property for INCS7
            /// </summary>
            public const string INCS7 = "INCS7";

            /// <summary>
            /// Property for INCS8
            /// </summary>
            public const string INCS8 = "INCS8";

            /// <summary>
            /// Property for INCS9
            /// </summary>
            public const string INCS9 = "INCS9";

            /// <summary>
            /// Property for INCS10
            /// </summary>
            public const string INCS10 = "INCS10";

            /// <summary>
            /// Property for INCS11
            /// </summary>
            public const string INCS11 = "INCS11";

            /// <summary>
            /// Property for INCS12
            /// </summary>
            public const string INCS12 = "INCS12";

            /// <summary>
            /// Property for INCS13
            /// </summary>
            public const string INCS13 = "INCS13";

            /// <summary>
            /// Property for INCS14
            /// </summary>
            public const string INCS14 = "INCS14";

            /// <summary>
            /// Property for INCS15
            /// </summary>
            public const string INCS15 = "INCS15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INCSTOTAL
            /// </summary>
            public const string INCSTOTAL = "INCSTOTAL";

            /// <summary>
            /// Property for INCH1
            /// </summary>
            public const string INCH1 = "INCH1";

            /// <summary>
            /// Property for INCH2
            /// </summary>
            public const string INCH2 = "INCH2";

            /// <summary>
            /// Property for INCH3
            /// </summary>
            public const string INCH3 = "INCH3";

            /// <summary>
            /// Property for INCH4
            /// </summary>
            public const string INCH4 = "INCH4";

            /// <summary>
            /// Property for INCH5
            /// </summary>
            public const string INCH5 = "INCH5";

            /// <summary>
            /// Property for INCH6
            /// </summary>
            public const string INCH6 = "INCH6";

            /// <summary>
            /// Property for INCH7
            /// </summary>
            public const string INCH7 = "INCH7";

            /// <summary>
            /// Property for INCH8
            /// </summary>
            public const string INCH8 = "INCH8";

            /// <summary>
            /// Property for INCH9
            /// </summary>
            public const string INCH9 = "INCH9";

            /// <summary>
            /// Property for INCH10
            /// </summary>
            public const string INCH10 = "INCH10";

            /// <summary>
            /// Property for INCH11
            /// </summary>
            public const string INCH11 = "INCH11";

            /// <summary>
            /// Property for INCH12
            /// </summary>
            public const string INCH12 = "INCH12";

            /// <summary>
            /// Property for INCH13
            /// </summary>
            public const string INCH13 = "INCH13";

            /// <summary>
            /// Property for INCH14
            /// </summary>
            public const string INCH14 = "INCH14";

            /// <summary>
            /// Property for INCH15
            /// </summary>
            public const string INCH15 = "INCH15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INCHTOTAL
            /// </summary>
            public const string INCHTOTAL = "INCHTOTAL";

            /// <summary>
            /// Property for INRS1
            /// </summary>
            public const string INRS1 = "INRS1";

            /// <summary>
            /// Property for INRS2
            /// </summary>
            public const string INRS2 = "INRS2";

            /// <summary>
            /// Property for INRS3
            /// </summary>
            public const string INRS3 = "INRS3";

            /// <summary>
            /// Property for INRS4
            /// </summary>
            public const string INRS4 = "INRS4";

            /// <summary>
            /// Property for INRS5
            /// </summary>
            public const string INRS5 = "INRS5";

            /// <summary>
            /// Property for INRS6
            /// </summary>
            public const string INRS6 = "INRS6";

            /// <summary>
            /// Property for INRS7
            /// </summary>
            public const string INRS7 = "INRS7";

            /// <summary>
            /// Property for INRS8
            /// </summary>
            public const string INRS8 = "INRS8";

            /// <summary>
            /// Property for INRS9
            /// </summary>
            public const string INRS9 = "INRS9";

            /// <summary>
            /// Property for INRS10
            /// </summary>
            public const string INRS10 = "INRS10";

            /// <summary>
            /// Property for INRS11
            /// </summary>
            public const string INRS11 = "INRS11";

            /// <summary>
            /// Property for INRS12
            /// </summary>
            public const string INRS12 = "INRS12";

            /// <summary>
            /// Property for INRS13
            /// </summary>
            public const string INRS13 = "INRS13";

            /// <summary>
            /// Property for INRS14
            /// </summary>
            public const string INRS14 = "INRS14";

            /// <summary>
            /// Property for INRS15
            /// </summary>
            public const string INRS15 = "INRS15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INRSTOTAL
            /// </summary>
            public const string INRSTOTAL = "INRSTOTAL";

            /// <summary>
            /// Property for INRH1
            /// </summary>
            public const string INRH1 = "INRH1";

            /// <summary>
            /// Property for INRH2
            /// </summary>
            public const string INRH2 = "INRH2";

            /// <summary>
            /// Property for INRH3
            /// </summary>
            public const string INRH3 = "INRH3";

            /// <summary>
            /// Property for INRH4
            /// </summary>
            public const string INRH4 = "INRH4";

            /// <summary>
            /// Property for INRH5
            /// </summary>
            public const string INRH5 = "INRH5";

            /// <summary>
            /// Property for INRH6
            /// </summary>
            public const string INRH6 = "INRH6";

            /// <summary>
            /// Property for INRH7
            /// </summary>
            public const string INRH7 = "INRH7";

            /// <summary>
            /// Property for INRH8
            /// </summary>
            public const string INRH8 = "INRH8";

            /// <summary>
            /// Property for INRH9
            /// </summary>
            public const string INRH9 = "INRH9";

            /// <summary>
            /// Property for INRH10
            /// </summary>
            public const string INRH10 = "INRH10";

            /// <summary>
            /// Property for INRH11
            /// </summary>
            public const string INRH11 = "INRH11";

            /// <summary>
            /// Property for INRH12
            /// </summary>
            public const string INRH12 = "INRH12";

            /// <summary>
            /// Property for INRH13
            /// </summary>
            public const string INRH13 = "INRH13";

            /// <summary>
            /// Property for INRH14
            /// </summary>
            public const string INRH14 = "INRH14";

            /// <summary>
            /// Property for INRH15
            /// </summary>
            public const string INRH15 = "INRH15";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for INRHTOTAL
            /// </summary>
            public const string INRHTOTAL = "INRHTOTAL";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperator
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for Rate
            /// </summary>
            public const string Rate = "RATE";

            /// <summary>
            /// Property for Show
            /// </summary>
            public const string Show = "SHOW";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "SQTY";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SCOSTS
            /// </summary>
            public const string SCOSTS = "SCOSTS";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SCOSTH
            /// </summary>
            public const string SCOSTH = "SCOSTH";

            /// <summary>
            /// Property for RevenueSource
            /// </summary>
            public const string RevenueSource = "SRS";

            /// <summary>
            /// Property for RevenueFunctional
            /// </summary>
            public const string RevenueFunctional = "SRH";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "LEVEL";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "CATTYPE";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of BudgetDetail Index Constants
        /// </summary>
        public class Index
        {
            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SEQ
            /// </summary>
            public const int SEQ = 1;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for LINENUM
            /// </summary>
            public const int LINENUM = 2;

            /// <summary>
            /// Property Indexer for ContractUniq
            /// </summary>
            public const int ContractUniq = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for BudgetSet
            /// </summary>
            public const int BudgetSet = 5;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 6;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 7;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 8;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 9;

            /// <summary>
            /// Property Indexer for RevenueCurrency
            /// </summary>
            public const int RevenueCurrency = 10;

            /// <summary>
            /// Property Indexer for CostCurrency
            /// </summary>
            public const int CostCurrency = 11;

            /// <summary>
            /// Property Indexer for CurrencyType
            /// </summary>
            public const int CurrencyType = 12;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 13;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 14;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 15;

            /// <summary>
            /// Property Indexer for QuantityForPeriod1
            /// </summary>
            public const int QuantityForPeriod1 = 16;

            /// <summary>
            /// Property Indexer for QuantityForPeriod2
            /// </summary>
            public const int QuantityForPeriod2 = 17;

            /// <summary>
            /// Property Indexer for QuantityForPeriod3
            /// </summary>
            public const int QuantityForPeriod3 = 18;

            /// <summary>
            /// Property Indexer for QuantityForPeriod4
            /// </summary>
            public const int QuantityForPeriod4 = 19;

            /// <summary>
            /// Property Indexer for QuantityForPeriod5
            /// </summary>
            public const int QuantityForPeriod5 = 20;

            /// <summary>
            /// Property Indexer for QuantityForPeriod6
            /// </summary>
            public const int QuantityForPeriod6 = 21;

            /// <summary>
            /// Property Indexer for QuantityForPeriod7
            /// </summary>
            public const int QuantityForPeriod7 = 22;

            /// <summary>
            /// Property Indexer for QuantityForPeriod8
            /// </summary>
            public const int QuantityForPeriod8 = 23;

            /// <summary>
            /// Property Indexer for QuantityForPeriod9
            /// </summary>
            public const int QuantityForPeriod9 = 24;

            /// <summary>
            /// Property Indexer for QuantityForPeriod10
            /// </summary>
            public const int QuantityForPeriod10 = 25;

            /// <summary>
            /// Property Indexer for QuantityForPeriod11
            /// </summary>
            public const int QuantityForPeriod11 = 26;

            /// <summary>
            /// Property Indexer for QuantityForPeriod12
            /// </summary>
            public const int QuantityForPeriod12 = 27;

            /// <summary>
            /// Property Indexer for QuantityForPeriod13
            /// </summary>
            public const int QuantityForPeriod13 = 28;

            /// <summary>
            /// Property Indexer for Q14
            /// </summary>
            public const int Q14 = 29;

            /// <summary>
            /// Property Indexer for Q15
            /// </summary>
            public const int Q15 = 30;

            /// <summary>
            /// Property Indexer for TotalQuantityForTheYear
            /// </summary>
            public const int TotalQuantityForTheYear = 31;

            /// <summary>
            /// Property Indexer for CS1
            /// </summary>
            public const int CS1 = 32;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod2
            /// </summary>
            public const int TotalCostSourceForPeriod2 = 33;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod3
            /// </summary>
            public const int TotalCostSourceForPeriod3 = 34;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod4
            /// </summary>
            public const int TotalCostSourceForPeriod4 = 35;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod5
            /// </summary>
            public const int TotalCostSourceForPeriod5 = 36;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod6
            /// </summary>
            public const int TotalCostSourceForPeriod6 = 37;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod7
            /// </summary>
            public const int TotalCostSourceForPeriod7 = 38;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod8
            /// </summary>
            public const int TotalCostSourceForPeriod8 = 39;

            /// <summary>
            /// Property Indexer for TotalCostSourceForPeriod9
            /// </summary>
            public const int TotalCostSourceForPeriod9 = 40;

            /// <summary>
            /// Property Indexer for CS10
            /// </summary>
            public const int CS10 = 41;

            /// <summary>
            /// Property Indexer for CS11
            /// </summary>
            public const int CS11 = 42;

            /// <summary>
            /// Property Indexer for CS12
            /// </summary>
            public const int CS12 = 43;

            /// <summary>
            /// Property Indexer for CS13
            /// </summary>
            public const int CS13 = 44;

            /// <summary>
            /// Property Indexer for CS14
            /// </summary>
            public const int CS14 = 45;

            /// <summary>
            /// Property Indexer for CS15
            /// </summary>
            public const int CS15 = 46;

            /// <summary>
            /// Property Indexer for TotalCostSourceForTheYear
            /// </summary>
            public const int TotalCostSourceForTheYear = 47;

            /// <summary>
            /// Property Indexer for CH1
            /// </summary>
            public const int CH1 = 48;

            /// <summary>
            /// Property Indexer for CH2
            /// </summary>
            public const int CH2 = 49;

            /// <summary>
            /// Property Indexer for CH3
            /// </summary>
            public const int CH3 = 50;

            /// <summary>
            /// Property Indexer for CH4
            /// </summary>
            public const int CH4 = 51;

            /// <summary>
            /// Property Indexer for CH5
            /// </summary>
            public const int CH5 = 52;

            /// <summary>
            /// Property Indexer for CH6
            /// </summary>
            public const int CH6 = 53;

            /// <summary>
            /// Property Indexer for CH7
            /// </summary>
            public const int CH7 = 54;

            /// <summary>
            /// Property Indexer for CH8
            /// </summary>
            public const int CH8 = 55;

            /// <summary>
            /// Property Indexer for CH9
            /// </summary>
            public const int CH9 = 56;

            /// <summary>
            /// Property Indexer for CH10
            /// </summary>
            public const int CH10 = 57;

            /// <summary>
            /// Property Indexer for CH11
            /// </summary>
            public const int CH11 = 58;

            /// <summary>
            /// Property Indexer for CH12
            /// </summary>
            public const int CH12 = 59;

            /// <summary>
            /// Property Indexer for CH13
            /// </summary>
            public const int CH13 = 60;

            /// <summary>
            /// Property Indexer for CH14
            /// </summary>
            public const int CH14 = 61;

            /// <summary>
            /// Property Indexer for CH15
            /// </summary>
            public const int CH15 = 62;

            /// <summary>
            /// Property Indexer for TotalCostFunctionalForThe
            /// </summary>
            public const int TotalCostFunctionalForThe = 63;

            /// <summary>
            /// Property Indexer for RS1
            /// </summary>
            public const int RS1 = 64;

            /// <summary>
            /// Property Indexer for RS2
            /// </summary>
            public const int RS2 = 65;

            /// <summary>
            /// Property Indexer for RS3
            /// </summary>
            public const int RS3 = 66;

            /// <summary>
            /// Property Indexer for RS4
            /// </summary>
            public const int RS4 = 67;

            /// <summary>
            /// Property Indexer for RS5
            /// </summary>
            public const int RS5 = 68;

            /// <summary>
            /// Property Indexer for RS6
            /// </summary>
            public const int RS6 = 69;

            /// <summary>
            /// Property Indexer for RS7
            /// </summary>
            public const int RS7 = 70;

            /// <summary>
            /// Property Indexer for RS8
            /// </summary>
            public const int RS8 = 71;

            /// <summary>
            /// Property Indexer for RS9
            /// </summary>
            public const int RS9 = 72;

            /// <summary>
            /// Property Indexer for RS10
            /// </summary>
            public const int RS10 = 73;

            /// <summary>
            /// Property Indexer for RS11
            /// </summary>
            public const int RS11 = 74;

            /// <summary>
            /// Property Indexer for RS12
            /// </summary>
            public const int RS12 = 75;

            /// <summary>
            /// Property Indexer for RS13
            /// </summary>
            public const int RS13 = 76;

            /// <summary>
            /// Property Indexer for RS14
            /// </summary>
            public const int RS14 = 77;

            /// <summary>
            /// Property Indexer for RS15
            /// </summary>
            public const int RS15 = 78;

            /// <summary>
            /// Property Indexer for TotalRevenueSourceForTheY
            /// </summary>
            public const int TotalRevenueSourceForTheY = 79;

            /// <summary>
            /// Property Indexer for RH1
            /// </summary>
            public const int RH1 = 80;

            /// <summary>
            /// Property Indexer for RH2
            /// </summary>
            public const int RH2 = 81;

            /// <summary>
            /// Property Indexer for RH3
            /// </summary>
            public const int RH3 = 82;

            /// <summary>
            /// Property Indexer for RH4
            /// </summary>
            public const int RH4 = 83;

            /// <summary>
            /// Property Indexer for RH5
            /// </summary>
            public const int RH5 = 84;

            /// <summary>
            /// Property Indexer for RH6
            /// </summary>
            public const int RH6 = 85;

            /// <summary>
            /// Property Indexer for RH7
            /// </summary>
            public const int RH7 = 86;

            /// <summary>
            /// Property Indexer for RH8
            /// </summary>
            public const int RH8 = 87;

            /// <summary>
            /// Property Indexer for RH9
            /// </summary>
            public const int RH9 = 88;

            /// <summary>
            /// Property Indexer for RH10
            /// </summary>
            public const int RH10 = 89;

            /// <summary>
            /// Property Indexer for RH11
            /// </summary>
            public const int RH11 = 90;

            /// <summary>
            /// Property Indexer for RH12
            /// </summary>
            public const int RH12 = 91;

            /// <summary>
            /// Property Indexer for RH13
            /// </summary>
            public const int RH13 = 92;

            /// <summary>
            /// Property Indexer for RH14
            /// </summary>
            public const int RH14 = 93;

            /// <summary>
            /// Property Indexer for RH15
            /// </summary>
            public const int RH15 = 94;

            /// <summary>
            /// Property Indexer for TotalRevenueFunctionalForT
            /// </summary>
            public const int TotalRevenueFunctionalForT = 95;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod1
            /// </summary>
            public const int InquiryQuantityForPeriod1 = 96;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod2
            /// </summary>
            public const int InquiryQuantityForPeriod2 = 97;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod3
            /// </summary>
            public const int InquiryQuantityForPeriod3 = 98;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod4
            /// </summary>
            public const int InquiryQuantityForPeriod4 = 99;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod5
            /// </summary>
            public const int InquiryQuantityForPeriod5 = 100;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod6
            /// </summary>
            public const int InquiryQuantityForPeriod6 = 101;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod7
            /// </summary>
            public const int InquiryQuantityForPeriod7 = 102;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod8
            /// </summary>
            public const int InquiryQuantityForPeriod8 = 103;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod9
            /// </summary>
            public const int InquiryQuantityForPeriod9 = 104;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod10
            /// </summary>
            public const int InquiryQuantityForPeriod10 = 105;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod11
            /// </summary>
            public const int InquiryQuantityForPeriod11 = 106;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod12
            /// </summary>
            public const int InquiryQuantityForPeriod12 = 107;

            /// <summary>
            /// Property Indexer for InquiryQuantityForPeriod13
            /// </summary>
            public const int InquiryQuantityForPeriod13 = 108;

            /// <summary>
            /// Property Indexer for INQ14
            /// </summary>
            public const int INQ14 = 109;

            /// <summary>
            /// Property Indexer for INQ15
            /// </summary>
            public const int INQ15 = 110;

            /// <summary>
            /// Property Indexer for InquiryTotalQuantityForTheY
            /// </summary>
            public const int InquiryTotalQuantityForTheY = 111;

            /// <summary>
            /// Property Indexer for INCS1
            /// </summary>
            public const int INCS1 = 112;

            /// <summary>
            /// Property Indexer for INCS2
            /// </summary>
            public const int INCS2 = 113;

            /// <summary>
            /// Property Indexer for INCS3
            /// </summary>
            public const int INCS3 = 114;

            /// <summary>
            /// Property Indexer for INCS4
            /// </summary>
            public const int INCS4 = 115;

            /// <summary>
            /// Property Indexer for INCS5
            /// </summary>
            public const int INCS5 = 116;

            /// <summary>
            /// Property Indexer for INCS6
            /// </summary>
            public const int INCS6 = 117;

            /// <summary>
            /// Property Indexer for INCS7
            /// </summary>
            public const int INCS7 = 118;

            /// <summary>
            /// Property Indexer for INCS8
            /// </summary>
            public const int INCS8 = 119;

            /// <summary>
            /// Property Indexer for INCS9
            /// </summary>
            public const int INCS9 = 120;

            /// <summary>
            /// Property Indexer for INCS10
            /// </summary>
            public const int INCS10 = 121;

            /// <summary>
            /// Property Indexer for INCS11
            /// </summary>
            public const int INCS11 = 122;

            /// <summary>
            /// Property Indexer for INCS12
            /// </summary>
            public const int INCS12 = 123;

            /// <summary>
            /// Property Indexer for INCS13
            /// </summary>
            public const int INCS13 = 124;

            /// <summary>
            /// Property Indexer for INCS14
            /// </summary>
            public const int INCS14 = 125;

            /// <summary>
            /// Property Indexer for INCS15
            /// </summary>
            public const int INCS15 = 126;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INCSTOTAL
            /// </summary>
            public const int INCSTOTAL = 127;

            /// <summary>
            /// Property Indexer for INCH1
            /// </summary>
            public const int INCH1 = 128;

            /// <summary>
            /// Property Indexer for INCH2
            /// </summary>
            public const int INCH2 = 129;

            /// <summary>
            /// Property Indexer for INCH3
            /// </summary>
            public const int INCH3 = 130;

            /// <summary>
            /// Property Indexer for INCH4
            /// </summary>
            public const int INCH4 = 131;

            /// <summary>
            /// Property Indexer for INCH5
            /// </summary>
            public const int INCH5 = 132;

            /// <summary>
            /// Property Indexer for INCH6
            /// </summary>
            public const int INCH6 = 133;

            /// <summary>
            /// Property Indexer for INCH7
            /// </summary>
            public const int INCH7 = 134;

            /// <summary>
            /// Property Indexer for INCH8
            /// </summary>
            public const int INCH8 = 135;

            /// <summary>
            /// Property Indexer for INCH9
            /// </summary>
            public const int INCH9 = 136;

            /// <summary>
            /// Property Indexer for INCH10
            /// </summary>
            public const int INCH10 = 137;

            /// <summary>
            /// Property Indexer for INCH11
            /// </summary>
            public const int INCH11 = 138;

            /// <summary>
            /// Property Indexer for INCH12
            /// </summary>
            public const int INCH12 = 139;

            /// <summary>
            /// Property Indexer for INCH13
            /// </summary>
            public const int INCH13 = 140;

            /// <summary>
            /// Property Indexer for INCH14
            /// </summary>
            public const int INCH14 = 141;

            /// <summary>
            /// Property Indexer for INCH15
            /// </summary>
            public const int INCH15 = 142;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INCHTOTAL
            /// </summary>
            public const int INCHTOTAL = 143;

            /// <summary>
            /// Property Indexer for INRS1
            /// </summary>
            public const int INRS1 = 144;

            /// <summary>
            /// Property Indexer for INRS2
            /// </summary>
            public const int INRS2 = 145;

            /// <summary>
            /// Property Indexer for INRS3
            /// </summary>
            public const int INRS3 = 146;

            /// <summary>
            /// Property Indexer for INRS4
            /// </summary>
            public const int INRS4 = 147;

            /// <summary>
            /// Property Indexer for INRS5
            /// </summary>
            public const int INRS5 = 148;

            /// <summary>
            /// Property Indexer for INRS6
            /// </summary>
            public const int INRS6 = 149;

            /// <summary>
            /// Property Indexer for INRS7
            /// </summary>
            public const int INRS7 = 150;

            /// <summary>
            /// Property Indexer for INRS8
            /// </summary>
            public const int INRS8 = 151;

            /// <summary>
            /// Property Indexer for INRS9
            /// </summary>
            public const int INRS9 = 152;

            /// <summary>
            /// Property Indexer for INRS10
            /// </summary>
            public const int INRS10 = 153;

            /// <summary>
            /// Property Indexer for INRS11
            /// </summary>
            public const int INRS11 = 154;

            /// <summary>
            /// Property Indexer for INRS12
            /// </summary>
            public const int INRS12 = 155;

            /// <summary>
            /// Property Indexer for INRS13
            /// </summary>
            public const int INRS13 = 156;

            /// <summary>
            /// Property Indexer for INRS14
            /// </summary>
            public const int INRS14 = 157;

            /// <summary>
            /// Property Indexer for INRS15
            /// </summary>
            public const int INRS15 = 158;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INRSTOTAL
            /// </summary>
            public const int INRSTOTAL = 159;

            /// <summary>
            /// Property Indexer for INRH1
            /// </summary>
            public const int INRH1 = 160;

            /// <summary>
            /// Property Indexer for INRH2
            /// </summary>
            public const int INRH2 = 161;

            /// <summary>
            /// Property Indexer for INRH3
            /// </summary>
            public const int INRH3 = 162;

            /// <summary>
            /// Property Indexer for INRH4
            /// </summary>
            public const int INRH4 = 163;

            /// <summary>
            /// Property Indexer for INRH5
            /// </summary>
            public const int INRH5 = 164;

            /// <summary>
            /// Property Indexer for INRH6
            /// </summary>
            public const int INRH6 = 165;

            /// <summary>
            /// Property Indexer for INRH7
            /// </summary>
            public const int INRH7 = 166;

            /// <summary>
            /// Property Indexer for INRH8
            /// </summary>
            public const int INRH8 = 167;

            /// <summary>
            /// Property Indexer for INRH9
            /// </summary>
            public const int INRH9 = 168;

            /// <summary>
            /// Property Indexer for INRH10
            /// </summary>
            public const int INRH10 = 169;

            /// <summary>
            /// Property Indexer for INRH11
            /// </summary>
            public const int INRH11 = 170;

            /// <summary>
            /// Property Indexer for INRH12
            /// </summary>
            public const int INRH12 = 171;

            /// <summary>
            /// Property Indexer for INRH13
            /// </summary>
            public const int INRH13 = 172;

            /// <summary>
            /// Property Indexer for INRH14
            /// </summary>
            public const int INRH14 = 173;

            /// <summary>
            /// Property Indexer for INRH15
            /// </summary>
            public const int INRH15 = 174;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for INRHTOTAL
            /// </summary>
            public const int INRHTOTAL = 175;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 176;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 177;

            /// <summary>
            /// Property Indexer for RateOperator
            /// </summary>
            public const int RateOperator = 178;

            /// <summary>
            /// Property Indexer for Rate
            /// </summary>
            public const int Rate = 179;

            /// <summary>
            /// Property Indexer for Show
            /// </summary>
            public const int Show = 1001;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 1002;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SCOSTS
            /// </summary>
            public const int SCOSTS = 1003;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SCOSTH
            /// </summary>
            public const int SCOSTH = 1004;

            /// <summary>
            /// Property Indexer for RevenueSource
            /// </summary>
            public const int RevenueSource = 1005;

            /// <summary>
            /// Property Indexer for RevenueFunctional
            /// </summary>
            public const int RevenueFunctional = 1006;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 1007;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 1008;

        }

        #endregion

    }
}