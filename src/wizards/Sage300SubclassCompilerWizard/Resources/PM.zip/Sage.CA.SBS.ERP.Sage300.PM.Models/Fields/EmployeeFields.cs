// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of Employee Constants
    /// </summary>
    public partial class Employee
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0002";

        #region Properties

        /// <summary>
        /// Contains list of Employee Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for EmployeeNumber
            /// </summary>
            public const string EmployeeNumber = "STAFFCODE";

            /// <summary>
            /// Property for Name
            /// </summary>
            public const string Name = "NAME";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENT";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for DateInactive
            /// </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary>
            /// Property for Group
            /// </summary>
            public const string Group = "GROUP";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for UNITCOST
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for PayRate
            /// </summary>
            public const string PayRate = "PAYRATE";

            /// <summary>
            /// Property for DefaultHours
            /// </summary>
            public const string DefaultHours = "STDHOURS";

            /// <summary>
            /// Property for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for PayrollCode
            /// </summary>
            public const string PayrollCode = "PAYROLL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BILLRATE
            /// </summary>
            public const string BillRate = "BILLRATE";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CCY";

            /// <summary>
            /// Property for UserID
            /// </summary>
            public const string UserID = "USERID";

            /// <summary>
            /// Property for EMAIL1
            /// </summary>
            public const string Email1 = "EMAIL1";

            /// <summary>
            /// Property for EMAIL2
            /// </summary>
            public const string Email2 = "EMAIL2";

            /// <summary>
            /// Property for PayrollType
            /// </summary>
            public const string PayrollType = "PAYTYPE";

            /// <summary>
            /// Property for EarningsCode
            /// </summary>
            public const string EarningsCode = "EARNCODE";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STUNITCOST
            /// </summary>
            public const string TimeUnitCost = "STUNITCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STTOTCOST
            /// </summary>
            public const string TimeTotalCost = "STTOTCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STUNITBILL
            /// </summary>
            public const string TimeUnitBill = "STUNITBILL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STTOTBILL
            /// </summary>
            public const string TimeTotalBill = "STTOTBILL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for STBILLTYPE
            /// </summary>
            public const string TimeBillType = "STBILLTYPE";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SETOTCOST
            /// </summary>
            public const string ExpenseTotalCost = "SETOTCOST";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SETOTBILL
            /// </summary>
            public const string ExpenseTotalBill = "SETOTBILL";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for SEBILLTYPE
            /// </summary>
            public const string ExpenseBillType = "SEBILLTYPE";

            /// <summary>
            /// Property for NumberOfOptionalFields
            /// </summary>
            public const string NumberOfOptionalFields = "VALUES";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "INPAYROLL";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Employee Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for EmployeeNumber
            /// </summary>
            public const int EmployeeNumber = 1;

            /// <summary>
            /// Property Indexer for Name
            /// </summary>
            public const int Name = 2;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 3;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 4;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 5;

            /// <summary>
            /// Property Indexer for DateInactive
            /// </summary>
            public const int DateInactive = 6;

            /// <summary>
            /// Property Indexer for Group
            /// </summary>
            public const int Group = 7;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for UNITCOST
            /// </summary>
            public const int UnitCost = 8;

            /// <summary>
            /// Property Indexer for PayRate
            /// </summary>
            public const int PayRate = 9;

            /// <summary>
            /// Property Indexer for DefaultHours
            /// </summary>
            public const int DefaultHours = 10;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 11;

            /// <summary>
            /// Property Indexer for PayrollCode
            /// </summary>
            public const int PayrollCode = 12;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BILLRATE
            /// </summary>
            public const int BillRate = 13;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 14;

            /// <summary>
            /// Property Indexer for UserID
            /// </summary>
            public const int UserID = 15;

            /// <summary>
            /// Property Indexer for EMAIL1
            /// </summary>
            public const int Email1 = 16;

            /// <summary>
            /// Property Indexer for EMAIL2
            /// </summary>
            public const int Email2 = 17;

            /// <summary>
            /// Property Indexer for PayrollType
            /// </summary>
            public const int PayrollType = 18;

            /// <summary>
            /// Property Indexer for EarningsCode
            /// </summary>
            public const int EarningsCode = 19;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 20;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 21;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STUNITCOST
            /// </summary>
            public const int TimeUnitCost = 22;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STTOTCOST
            /// </summary>
            public const int TimeTotalCost = 23;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STUNITBILL
            /// </summary>
            public const int TimeUnitBill = 24;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STTOTBILL
            /// </summary>
            public const int TimeTotalBill = 25;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for STBILLTYPE
            /// </summary>
            public const int TimeBillType = 26;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SETOTCOST
            /// </summary>
            public const int ExpenseTotalCost = 27;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SETOTBILL
            /// </summary>
            public const int ExpenseTotalBill = 28;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for SEBILLTYPE
            /// </summary>
            public const int ExpenseBillType = 29;

            /// <summary>
            /// Property Indexer for NumberOfOptionalFields
            /// </summary>
            public const int NumberOfOptionalFields = 30;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 1000;


        }

        #endregion

    }
}