// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of TimecardTimeTotal Constants
    /// </summary>
    public partial class TimecardTimeTotal
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0115";


        #region Properties

        /// <summary>
        /// Contains list of TimecardTimeTotal Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Sequence
            /// </summary>
            public const string Sequence = "SEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTCONTNO
            /// </summary>
            public const string FMTCONTNO = "FMTCONTNO";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTRACT
            /// </summary>
            public const string CONTRACT = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for MondayHours
            /// </summary>
            public const string MondayHours = "HMON";

            /// <summary>
            /// Property for TuesdayHours
            /// </summary>
            public const string TuesdayHours = "HTUE";

            /// <summary>
            /// Property for WednesdayHours
            /// </summary>
            public const string WednesdayHours = "HWED";

            /// <summary>
            /// Property for ThursdayHours
            /// </summary>
            public const string ThursdayHours = "HTHU";

            /// <summary>
            /// Property for FridayHours
            /// </summary>
            public const string FridayHours = "HFRI";

            /// <summary>
            /// Property for SaturdayHours
            /// </summary>
            public const string SaturdayHours = "HSAT";

            /// <summary>
            /// Property for SundayHours
            /// </summary>
            public const string SundayHours = "HSUN";

            /// <summary>
            /// Property for WeeklyHours
            /// </summary>
            public const string WeeklyHours = "HWEEK";

            /// <summary>
            /// Property for NumberOfDetailsMonday
            /// </summary>
            public const string NumberOfDetailsMonday = "NLMON";

            /// <summary>
            /// Property for NumberOfDetailsTuesday
            /// </summary>
            public const string NumberOfDetailsTuesday = "NLTUE";

            /// <summary>
            /// Property for NumberOfDetailsWednesday
            /// </summary>
            public const string NumberOfDetailsWednesday = "NLWED";

            /// <summary>
            /// Property for NumberOfDetailsThursday
            /// </summary>
            public const string NumberOfDetailsThursday = "NLTHU";

            /// <summary>
            /// Property for NumberOfDetailsFriday
            /// </summary>
            public const string NumberOfDetailsFriday = "NLFRI";

            /// <summary>
            /// Property for NumberOfDetailsSaturday
            /// </summary>
            public const string NumberOfDetailsSaturday = "NLSAT";

            /// <summary>
            /// Property for NumberOfDetailsSunday
            /// </summary>
            public const string NumberOfDetailsSunday = "NLSUN";

            /// <summary>
            /// Property for DETAILNUMMonday
            /// </summary>
            public const string DETAILNUMMonday = "DMON";

            /// <summary>
            /// Property for DETAILNUMTuesday
            /// </summary>
            public const string DETAILNUMTuesday = "DTUE";

            /// <summary>
            /// Property for DETAILNUMWednesday
            /// </summary>
            public const string DETAILNUMWednesday = "DWED";

            /// <summary>
            /// Property for DETAILNUMThursday
            /// </summary>
            public const string DETAILNUMThursday = "DTHU";

            /// <summary>
            /// Property for DETAILNUMFriday
            /// </summary>
            public const string DETAILNUMFriday = "DFRI";

            /// <summary>
            /// Property for DETAILNUMSaturday
            /// </summary>
            public const string DETAILNUMSaturday = "DSAT";

            /// <summary>
            /// Property for DETAILNUMSunday
            /// </summary>
            public const string DETAILNUMSunday = "DSUN";

            /// <summary>
            /// Property for ContractStyle
            /// </summary>
            public const string ContractStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "CUSTOMER";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVTYPE";

            /// <summary>
            /// Property for EarningsCode
            /// </summary>
            public const string EarningsCode = "EARNINGS";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for CalledByPMTIMED
            /// </summary>
            public const string CalledByPMTIMED = "TIMED";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CONTDESC
            /// </summary>
            public const string CONTDESC = "CONTDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for PROJDESC
            /// </summary>
            public const string PROJDESC = "PROJDESC";

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for CATDESC
            /// </summary>
            public const string CATDESC = "CATDESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of TimecardTimeTotal Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Sequence
            /// </summary>
            public const int Sequence = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTCONTNO
            /// </summary>
            public const int FMTCONTNO = 3;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTRACT
            /// </summary>
            public const int CONTRACT = 4;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 5;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 6;

            /// <summary>
            /// Property Indexer for MondayHours
            /// </summary>
            public const int MondayHours = 7;

            /// <summary>
            /// Property Indexer for TuesdayHours
            /// </summary>
            public const int TuesdayHours = 8;

            /// <summary>
            /// Property Indexer for WednesdayHours
            /// </summary>
            public const int WednesdayHours = 9;

            /// <summary>
            /// Property Indexer for ThursdayHours
            /// </summary>
            public const int ThursdayHours = 10;

            /// <summary>
            /// Property Indexer for FridayHours
            /// </summary>
            public const int FridayHours = 11;

            /// <summary>
            /// Property Indexer for SaturdayHours
            /// </summary>
            public const int SaturdayHours = 12;

            /// <summary>
            /// Property Indexer for SundayHours
            /// </summary>
            public const int SundayHours = 13;

            /// <summary>
            /// Property Indexer for WeeklyHours
            /// </summary>
            public const int WeeklyHours = 14;

            /// <summary>
            /// Property Indexer for NumberOfDetailsMonday
            /// </summary>
            public const int NumberOfDetailsMonday = 15;

            /// <summary>
            /// Property Indexer for NumberOfDetailsTuesday
            /// </summary>
            public const int NumberOfDetailsTuesday = 16;

            /// <summary>
            /// Property Indexer for NumberOfDetailsWednesday
            /// </summary>
            public const int NumberOfDetailsWednesday = 17;

            /// <summary>
            /// Property Indexer for NumberOfDetailsThursday
            /// </summary>
            public const int NumberOfDetailsThursday = 18;

            /// <summary>
            /// Property Indexer for NumberOfDetailsFriday
            /// </summary>
            public const int NumberOfDetailsFriday = 19;

            /// <summary>
            /// Property Indexer for NumberOfDetailsSaturday
            /// </summary>
            public const int NumberOfDetailsSaturday = 20;

            /// <summary>
            /// Property Indexer for NumberOfDetailsSunday
            /// </summary>
            public const int NumberOfDetailsSunday = 21;

            /// <summary>
            /// Property Indexer for DETAILNUMMonday
            /// </summary>
            public const int DETAILNUMMonday = 22;

            /// <summary>
            /// Property Indexer for DETAILNUMTuesday
            /// </summary>
            public const int DETAILNUMTuesday = 23;

            /// <summary>
            /// Property Indexer for DETAILNUMWednesday
            /// </summary>
            public const int DETAILNUMWednesday = 24;

            /// <summary>
            /// Property Indexer for DETAILNUMThursday
            /// </summary>
            public const int DETAILNUMThursday = 25;

            /// <summary>
            /// Property Indexer for DETAILNUMFriday
            /// </summary>
            public const int DETAILNUMFriday = 26;

            /// <summary>
            /// Property Indexer for DETAILNUMSaturday
            /// </summary>
            public const int DETAILNUMSaturday = 27;

            /// <summary>
            /// Property Indexer for DETAILNUMSunday
            /// </summary>
            public const int DETAILNUMSunday = 28;

            /// <summary>
            /// Property Indexer for ContractStyle
            /// </summary>
            public const int ContractStyle = 29;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 30;

            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 31;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 32;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 33;

            /// <summary>
            /// Property Indexer for EarningsCode
            /// </summary>
            public const int EarningsCode = 34;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 1001;

            /// <summary>
            /// Property Indexer for CalledByPMTIMED
            /// </summary>
            public const int CalledByPMTIMED = 1002;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CONTDESC
            /// </summary>
            public const int CONTDESC = 1009;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for PROJDESC
            /// </summary>
            public const int PROJDESC = 1010;

            // TODO The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for CATDESC
            /// </summary>
            public const int CATDESC = 1011;


        }

        #endregion

    }
}