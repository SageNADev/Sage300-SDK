// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of SegmentCodes Constants
    /// </summary>
    public partial class SegmentCodes
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0014";


        #region Properties

        /// <summary>
        /// Contains list of SegmentCodes Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SegmentName
            /// </summary>
            public const string SegmentName = "SEGMENT";

            /// <summary>
            /// Property for SegmentCode
            /// </summary>
            public const string SegmentCode = "SEGVAL";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of SegmentCodes Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for SegmentName
            /// </summary>
            public const int SegmentName = 1;

            /// <summary>
            /// Property Indexer for SegmentCode
            /// </summary>
            public const int SegmentCode = 2;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 3;


        }

        #endregion

    }
}