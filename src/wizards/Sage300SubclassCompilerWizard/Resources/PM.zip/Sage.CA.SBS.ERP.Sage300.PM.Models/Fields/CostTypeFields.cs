// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contains list of CostTypes Constants
    /// </summary>
    public partial class CostTypes
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PM0001";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"TYPE", "CostClass"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of CostTypes Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for CostTypeCode
            /// </summary>
            public const string CostTypeCode = "COSTTYPE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for LastMaintained
            /// </summary>
            public const string LastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for DateInactive
            /// </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "TYPE";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of CostTypes Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for CostTypeCode
            /// </summary>
            public const int CostTypeCode = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for LastMaintained
            /// </summary>
            public const int LastMaintained = 4;

            /// <summary>
            /// Property Indexer for DateInactive
            /// </summary>
            public const int DateInactive = 5;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 6;


        }

        #endregion

    }
}