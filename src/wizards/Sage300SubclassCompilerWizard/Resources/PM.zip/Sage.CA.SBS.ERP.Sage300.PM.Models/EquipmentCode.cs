﻿using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for Equipments
    /// </summary>
    //[ViewModel(Id = EntityName)]
    public partial class EquipmentCode : ModelBase
    {
        /// <summary>
        /// Gets or sets EquipmentCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EquipmentCode", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.EquipmentCodeNo, Id = Index.EquipmentCode)]
        public string EquipmentCodeNo { get; set; }
        
        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EquipmentDescription", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status)]
        public Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CostTypesResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets DateInactive
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateInactive", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive)]
        public DateTime DateInactive { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber)]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString => EnumUtility.GetStringValue(Status);

        /// <summary>
        /// Gets or sets ARItemDescription
        /// </summary>
        [Display(Name = "ARItemNumberDescription", ResourceType = typeof(PMCommonResx))]
        //[ViewField(Name = Fields.ARItemDescription, Id = Index.ARItemDescription)]
        public string ARItemDescription { get; set; }
        #endregion
    }
}
