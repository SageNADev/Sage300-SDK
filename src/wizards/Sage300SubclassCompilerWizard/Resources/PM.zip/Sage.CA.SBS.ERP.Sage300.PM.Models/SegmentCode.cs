// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for SegmentCodes
    /// </summary>
    public partial class SegmentCodes : ModelBase
    {
        /// <summary>
        /// Gets or sets SegmentName
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentName", ResourceType = typeof (SegmentCodeResx))]
        [ViewField(Name = Fields.SegmentName, Id = Index.SegmentName, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentName { get; set; } //Cannot use Enum because user can add/remove in Sagement Code Setup UI

        /// <summary>
        /// Gets or sets SegmentCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode", ResourceType = typeof (SegmentCodeResx))]
        [ViewField(Name = Fields.SegmentCode, Id = Index.SegmentCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string SegmentCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Description", ResourceType = typeof (SegmentCodeResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string Description { get; set; }

        #region UI Strings

        #endregion
    }
}
