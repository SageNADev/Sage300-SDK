// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for Employee
    /// </summary>
    public partial class Employee : ModelBase
    {
        /// <summary>
        /// Gets or sets EmployeeNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "EmployeeNumber", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EmployeeNumber, Id = Index.EmployeeNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string EmployeeNumber { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Name", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Comments", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        //[Display(Name = "Status", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public ActiveStatus Status { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "LastMaintained", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets DateInactive
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "DateInactive", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateInactive { get; set; }

        /// <summary>
        /// Gets or sets Group
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Group", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Group, Id = Index.Group, FieldType = EntityFieldType.Char, Size = 10)]
        public string Group { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets UNITCOST
        /// </summary>
        //[Display(Name = "UNITCOST", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets PayRate
        /// </summary>
        //[Display(Name = "PayRate", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.PayRate, Id = Index.PayRate, FieldType = EntityFieldType.Int, Size = 2)]
        public int PayRate { get; set; }

        /// <summary>
        /// Gets or sets DefaultHours
        /// </summary>
        //[Display(Name = "DefaultHours", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.DefaultHours, Id = Index.DefaultHours, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 2)]
        public decimal DefaultHours { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        //[Display(Name = "Type", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public int Type { get; set; }

        /// <summary>
        /// Gets or sets PayrollCode
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "PayrollCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.PayrollCode, Id = Index.PayrollCode, FieldType = EntityFieldType.Char, Size = 40)]
        public string PayrollCode { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets BILLRATE
        /// </summary>
        //[Display(Name = "BILLRATE", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.BillRate, Id = Index.BillRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillRate { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Currency", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "UserID", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8C")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets EMAIL1
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "EMAIL1", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Email1, Id = Index.Email1, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email1 { get; set; }

        /// <summary>
        /// Gets or sets EMAIL2
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "EMAIL2", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Email2, Id = Index.Email2, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email2 { get; set; }

        /// <summary>
        /// Gets or sets PayrollType
        /// </summary>
        //[Display(Name = "PayrollType", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.PayrollType, Id = Index.PayrollType, FieldType = EntityFieldType.Int, Size = 2)]
        public int PayrollType { get; set; }

        /// <summary>
        /// Gets or sets EarningsCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "EarningsCode", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.EarningsCode, Id = Index.EarningsCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string EarningsCode { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ARItemNumber", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "UnitOfMeasure", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitOfMeasure { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets STUNITCOST
        /// </summary>
        //[Display(Name = "STUNITCOST", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TimeUnitCost, Id = Index.TimeUnitCost, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimeUnitCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets STTOTCOST
        /// </summary>
        //[Display(Name = "STTOTCOST", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TimeTotalCost, Id = Index.TimeTotalCost, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimeTotalCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets STUNITBILL
        /// </summary>
        //[Display(Name = "STUNITBILL", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TimeUnitBill, Id = Index.TimeUnitBill, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimeUnitBill { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets STTOTBILL
        /// </summary>
        //[Display(Name = "STTOTBILL", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TimeTotalBill, Id = Index.TimeTotalBill, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimeTotalBill { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets STBILLTYPE
        /// </summary>
        //[Display(Name = "STBILLTYPE", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.TimeBillType, Id = Index.TimeBillType, FieldType = EntityFieldType.Int, Size = 2)]
        public short TimeBillType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SETOTCOST
        /// </summary>
        //[Display(Name = "SETOTCOST", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ExpenseTotalCost, Id = Index.ExpenseTotalCost, FieldType = EntityFieldType.Int, Size = 2)]
        public short ExpenseTotalCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SETOTBILL
        /// </summary>
        //[Display(Name = "SETOTBILL", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ExpenseTotalBill, Id = Index.ExpenseTotalBill, FieldType = EntityFieldType.Int, Size = 2)]
        public short ExpenseTotalBill { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SEBILLTYPE
        /// </summary>
        //[Display(Name = "SEBILLTYPE", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.ExpenseBillType, Id = Index.ExpenseBillType, FieldType = EntityFieldType.Int, Size = 2)]
        public short ExpenseBillType { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        //[Display(Name = "NumberOfOptionalFields", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        //[Display(Name = "Description", ResourceType = typeof (EmployeeResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Int, Size = 2)]
        public short Description { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
         get { return EnumUtility.GetStringValue(Status); }
        }
        #endregion
    }
}
