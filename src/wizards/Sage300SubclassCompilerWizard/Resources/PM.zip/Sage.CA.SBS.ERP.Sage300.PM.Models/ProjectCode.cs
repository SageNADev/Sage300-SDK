// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for ProjectCode
    /// </summary>
    public partial class ProjectCode : ModelBase
    {
        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Project", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Description", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        //[Display(Name = "Status", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "LastMaintained", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets DateInactive
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "DateInactive", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateInactive { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        //[Display(Name = "ProjectType", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        //[Display(Name = "AccountingMethod", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets CostPlusPercentage
        /// </summary>
        //[Display(Name = "CostPlusPercentage", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.CostPlusPercentage, Id = Index.CostPlusPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CostPlusPercentage { get; set; }

        /// <summary>
        /// Gets or sets ClosedForBillings
        /// </summary>
        //[Display(Name = "ClosedForBillings", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.ClosedForBillings, Id = Index.ClosedForBillings, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ClosedForBillings { get; set; }

        /// <summary>
        /// Gets or sets ClosedForCost
        /// </summary>
        //[Display(Name = "ClosedForCost", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.ClosedForCost, Id = Index.ClosedForCost, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ClosedForCost { get; set; }

        /// <summary>
        /// Gets or sets RevenueType
        /// </summary>
        //[Display(Name = "RevenueType", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.RevenueType, Id = Index.RevenueType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RevenueType RevenueType { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        //[Display(Name = "BillingType", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets ARRetainagePercentage
        /// </summary>
        //[Display(Name = "ARRetainagePercentage", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.ARRetainagePercentage, Id = Index.ARRetainagePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal ARRetainagePercentage { get; set; }

        /// <summary>
        /// Gets or sets ARRetentionPeriod
        /// </summary>
        //[Display(Name = "ARRetentionPeriod", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.ARRetentionPeriod, Id = Index.ARRetentionPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public short ARRetentionPeriod { get; set; }

        /// <summary>
        /// Gets or sets OverrideGLAccountSegments
        /// </summary>
        //[Display(Name = "OverrideGLAccountSegments", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.OverrideGLAccountSegments, Id = Index.OverrideGLAccountSegments, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OverrideGLAccountSegments { get; set; }

        /// <summary>
        /// Gets or sets Segment1
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment1", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment1, Id = Index.Segment1, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode1
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode1", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode1, Id = Index.SegmentCode1, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode1 { get; set; }

        /// <summary>
        /// Gets or sets Segment2
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment2", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment2, Id = Index.Segment2, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode2
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode2", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode2, Id = Index.SegmentCode2, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode2 { get; set; }

        /// <summary>
        /// Gets or sets Segment3
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment3", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment3, Id = Index.Segment3, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode3
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode3", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode3, Id = Index.SegmentCode3, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode3 { get; set; }

        /// <summary>
        /// Gets or sets Segment4
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment4", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment4, Id = Index.Segment4, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode4
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode4", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode4, Id = Index.SegmentCode4, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode4 { get; set; }

        /// <summary>
        /// Gets or sets Segment5
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment5", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment5, Id = Index.Segment5, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode5
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode5", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode5, Id = Index.SegmentCode5, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode5 { get; set; }

        /// <summary>
        /// Gets or sets Segment6
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment6", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment6, Id = Index.Segment6, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment6 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode6
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode6", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode6, Id = Index.SegmentCode6, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode6 { get; set; }

        /// <summary>
        /// Gets or sets Segment7
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment7", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment7, Id = Index.Segment7, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment7 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode7
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode7", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode7, Id = Index.SegmentCode7, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode7 { get; set; }

        /// <summary>
        /// Gets or sets Segment8
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment8", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment8, Id = Index.Segment8, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment8 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode8
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode8", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode8, Id = Index.SegmentCode8, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode8 { get; set; }

        /// <summary>
        /// Gets or sets Segment9
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Segment9", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.Segment9, Id = Index.Segment9, FieldType = EntityFieldType.Char, Size = 6)]
        public string Segment9 { get; set; }

        /// <summary>
        /// Gets or sets SegmentCode9
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "SegmentCode9", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.SegmentCode9, Id = Index.SegmentCode9, FieldType = EntityFieldType.Char, Size = 15)]
        public string SegmentCode9 { get; set; }

        /// <summary>
        /// Gets or sets FormCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "FormCode", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.FormCode, Id = Index.FormCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FormCode { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        //[Display(Name = "NumberOfOptionalFields", ResourceType = typeof (ProjectCodeResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        #region UI Strings

        /*
        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
         get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets Project123Type string value
        /// </summary>
        public string Project123TypeString
        {
         get { return EnumUtility.GetStringValue(ProjectType); }
        }

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString
        {
         get { return EnumUtility.GetStringValue(AccountingMethod); }
        }

        /// <summary>
        /// Gets RevenueType string value
        /// </summary>
        public string RevenueTypeString
        {
         get { return EnumUtility.GetStringValue(RevenueType); }
        }

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString
        {
         get { return EnumUtility.GetStringValue(BillingType); }
        }
*/
        #endregion
    }
}
