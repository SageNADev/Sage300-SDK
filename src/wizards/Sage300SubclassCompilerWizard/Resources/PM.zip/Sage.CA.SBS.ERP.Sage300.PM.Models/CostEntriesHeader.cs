// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for CostEntriesHeaders
    /// </summary>
    public partial class CostEntriesHeaders : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCost
        /// </summary>
        [Display(Name = "TotalCost", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalCost, Id = Index.TotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCost { get; set; }

        /// <summary>
        /// Gets or sets Overhead Amount Source Currency
        /// </summary>
        [Display(Name = "OverheadAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.OverheadAmountSourceCurrency, Id = Index.OverheadAmountSourceCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Overhead Amount Home Currency
        /// </summary>
        [Display(Name = "OverheadAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.OverheadAmountHomeCurrency, Id = Index.OverheadAmountHomeCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Labor Amount Source Currency
        /// </summary>
        [Display(Name = "LaborAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.LaborAmountSourceCurrency, Id = Index.LaborAmountSourceCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LaborAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Labor Amount Home Currency
        /// </summary>
        [Display(Name = "LaborAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.LaborAmountHomeCurrency, Id = Index.LaborAmountHomeCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LaborAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Cost Amount Source Currency
        /// </summary>
        [Display(Name = "TotalCostAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalCostAmountSourceCurrency, Id = Index.TotalCostAmountSourceCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Cost Amount Home Currency
        /// </summary>
        [Display(Name = "TotalCostAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalCostAmountHomeCurrency, Id = Index.TotalCostAmountHomeCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Billable Amount Source Currency
        /// </summary>
        [Display(Name = "TotalBillableAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalBillableAmountSourceCurrency, Id = Index.TotalBillableAmountSourceCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalBillableAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Billable Amount Home Currency
        /// </summary>
        [Display(Name = "TotalBillableAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalBillableAmountHomeCurrency, Id = Index.TotalBillableAmountHomeCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalBillableAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantity
        /// </summary>
        [Display(Name = "TotalQuantity", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalQuantity, Id = Index.TotalQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal TotalQuantity { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Printed", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Printed { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus
        /// </summary>
        [Display(Name = "TransactionStatus", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionStatus TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumberOfDetails", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ICStat
        /// </summary>
        [Display(Name = "ICStat", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.ICStat, Id = Index.ICStat, FieldType = EntityFieldType.Int, Size = 2)]
        public short ICStat { get; set; }

        /// <summary>
        /// Gets or sets NumberOfMiscellaneousCosts
        /// </summary>
        [Display(Name = "NumberOfMiscellaneousCosts", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfMiscellaneousCosts, Id = Index.NumberOfMiscellaneousCosts, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfMiscellaneousCosts { get; set; }

        /// <summary>
        /// Gets or sets NumberOfTimecards
        /// </summary>
        [Display(Name = "NumberOfTimecards", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfTimecards, Id = Index.NumberOfTimecards, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfTimecards { get; set; }

        /// <summary>
        /// Gets or sets NumberOfTimeExpenses
        /// </summary>
        [Display(Name = "NumberOfTimeExpenses", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfTimeExpenses, Id = Index.NumberOfTimeExpenses, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfTimeExpenses { get; set; }

        /// <summary>
        /// Gets or sets NumberOfEquipmentUsages
        /// </summary>
        [Display(Name = "NumberOfEquipmentUsages", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfEquipmentUsages, Id = Index.NumberOfEquipmentUsages, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfEquipmentUsages { get; set; }

        /// <summary>
        /// Gets or sets NumberOfMaterialUsages
        /// </summary>
        [Display(Name = "NumberOfMaterialUsages", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfMaterialUsages, Id = Index.NumberOfMaterialUsages, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfMaterialUsages { get; set; }

        /// <summary>
        /// Gets or sets NumberOfMaterialReturns
        /// </summary>
        [Display(Name = "NumberOfMaterialReturns", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfMaterialReturns, Id = Index.NumberOfMaterialReturns, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfMaterialReturns { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCharges
        /// </summary>
        [Display(Name = "NumberOfCharges", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfCharges, Id = Index.NumberOfCharges, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfCharges { get; set; }

        /// <summary>
        /// Gets or sets CreatedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedBy", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.CreatedBy, Id = Index.CreatedBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets CreatedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedOn", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.CreatedOn, Id = Index.CreatedOn, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets CreatedAt
        /// </summary>
        [Display(Name = "CreatedAt", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.CreatedAt, Id = Index.CreatedAt, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan CreatedAt { get; set; }

        /// <summary>
        /// Gets or sets ApprovedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedBy", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.ApprovedBy, Id = Index.ApprovedBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string ApprovedBy { get; set; }

        /// <summary>
        /// Gets or sets ApprovedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedOn", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.ApprovedOn, Id = Index.ApprovedOn, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ApprovedOn { get; set; }

        /// <summary>
        /// Gets or sets ApprovedAt
        /// </summary>
        [Display(Name = "ApprovedAt", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.ApprovedAt, Id = Index.ApprovedAt, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan ApprovedAt { get; set; }

        /// <summary>
        /// Gets or sets PostedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedBy", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.PostedBy, Id = Index.PostedBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string PostedBy { get; set; }

        /// <summary>
        /// Gets or sets PostedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedOn", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.PostedOn, Id = Index.PostedOn, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostedOn { get; set; }

        /// <summary>
        /// Gets or sets PostedAt
        /// </summary>
        [Display(Name = "PostedAt", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.PostedAt, Id = Index.PostedAt, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan PostedAt { get; set; }

        /// <summary>
        /// Gets or sets GLEntryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLEntryDescription", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.GLEntryDescription, Id = Index.GLEntryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLEntryDescription { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets ShowProgressBarDuringPosting
        /// </summary>
        [Display(Name = "ShowProgressBarDuringPosting", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.ShowProgressBarDuringPosting, Id = Index.ShowProgressBarDuringPosting, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShowProgressBarDuringPosting { get; set; }
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ShowProgressBarDuringPosting ShowProgressBarDuringPosting { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        //public string FiscalPeriodString
        //{
        // get { return EnumUtility.GetStringValue(FiscalPeriod); }
        //}

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        //public string PrintedString
        //{
        // get { return EnumUtility.GetStringValue(Printed); }
        //}

        /// <summary>
        /// Gets TransactionStatus string value
        /// </summary>
        //public string TransactionStatusString
        //{
        // get { return EnumUtility.GetStringValue(TransactionStatus); }
        //}

        /// <summary>
        /// Gets ShowProgressBarDuringPosting string value
        /// </summary>
        //public string ShowProgressBarDuringPostingString
        //{
        // get { return EnumUtility.GetStringValue(ShowProgressBarDuringPosting); }
        //}

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
         get { return EnumUtility.GetStringValue(Function); }
        }

        /// <summary>
        /// Check the transaction/posting date is locked period
        /// </summary>
        public bool IsDateLocked { get; set; } = false;

        #endregion
    }
}
