// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for EmployeeDetailView
    /// </summary>
    public partial class EmployeeDetailView : ModelBase
    {
        /// <summary>
        /// Gets or sets StaffCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "StaffCode", ResourceType = typeof (EmployeeDetailViewResx))]
        [ViewField(Name = Fields.StaffCode, Id = Index.StaffCode, FieldType = EntityFieldType.Char, Size = 16)]
        public string StaffCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "CurrencyCode", ResourceType = typeof (EmployeeDetailViewResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets PayType
        /// </summary>
        //[Display(Name = "PayType", ResourceType = typeof (EmployeeDetailViewResx))]
        [ViewField(Name = Fields.PayType, Id = Index.PayType, FieldType = EntityFieldType.Int, Size = 2)]
        public short PayType { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        //[Display(Name = "BillingRate", ResourceType = typeof (EmployeeDetailViewResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "CurrencyDescription", ResourceType = typeof (EmployeeDetailViewResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        #region UI Strings

        #endregion
    }
}
