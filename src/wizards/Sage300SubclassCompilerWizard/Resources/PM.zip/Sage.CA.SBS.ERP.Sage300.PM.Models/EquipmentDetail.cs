// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for UpdateRetainageDetail
    /// </summary>
    public partial class EquipmentDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets EquipmentNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EquipmentNumber", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.EquipmentNumber, Id = Index.EquipmentNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string EquipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets FormattedContractNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedContractNumber", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.FormattedContractNumber, Id = Index.FormattedContractNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FormattedContractNumber { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets EquipmentCode (Resource)
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EquipmentCode", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.EquipmentCode, Id = Index.EquipmentCode, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string EquipmentCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EquipmentCodeDesc", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string EquipmentCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostSR
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.ExtendedCostSR, Id = Index.ExtendedCostSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCostSR { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostHM
        /// </summary>
        //[Display(Name = "ExtendedCostHM", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ExtendedCostHM, Id = Index.ExtendedCostHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCostHM { get; set; }

        /// <summary>
        /// Gets or sets OverheadType
        /// </summary>
        [ViewField(Name = Fields.OverheadType, Id = Index.OverheadType, FieldType = EntityFieldType.Int, Size = 2)]
        public OOHTYPE OverheadType { get; set; }

        /// <summary>
        /// Gets or sets OverheadRate
        /// </summary>
        [ViewField(Name = Fields.OverheadRate, Id = Index.OverheadRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OverheadPercentage
        /// </summary>
        [ViewField(Name = Fields.OverheadPercentage, Id = Index.OverheadPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OverheadPercentage { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmountSR
        /// </summary>
        [ViewField(Name = Fields.OverheadAmountSR, Id = Index.OverheadAmountSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmountSR { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmountHM
        /// </summary>
        [ViewField(Name = Fields.OverheadAmountHM, Id = Index.OverheadAmountHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmountHM { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSR
        /// </summary>
        [ViewField(Name = Fields.TotalCostSR, Id = Index.TotalCostSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSR { get; set; }

        /// <summary>
        /// Gets or sets TotalCostHM
        /// </summary>
        [ViewField(Name = Fields.TotalCostHM, Id = Index.TotalCostHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostHM { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        [Display(Name = "Comments", ResourceType = typeof(EquipmentResx))]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets OverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OverheadAccount, Id = Index.OverheadAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        [Display(Name = "OverheadAccount", ResourceType = typeof(EquipmentResx))]
        public string OverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets EquipmentAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EquipmentAccount, Id = Index.EquipmentAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        [Display(Name = "EquipmentAccount", ResourceType = typeof(EquipmentResx))]
        public string EquipmentAccount { get; set; }

        /// <summary>
        /// Gets or sets WorkInProgressAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.WorkInProgressAccount, Id = Index.WorkInProgressAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        [Display(Name = "WorkInProgressAccount", ResourceType = typeof(EquipmentResx))]
        public string WorkInProgressAccount { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillAmountBasedOn
        /// </summary>
        //[Display(Name = "BillAmountBasedOn", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.BillAmountBasedOn, Id = Index.BillAmountBasedOn, FieldType = EntityFieldType.Int, Size = 2)]
        public BillAmountBasedOn BillAmountBasedOn { get; set; }

        /// <summary>
        /// Gets or sets RevenueAndCostCurrency
        /// </summary>
        //[Display(Name = "RevenueAndCostCurrency", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.RevenueAndCostCurrency, Id = Index.RevenueAndCostCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public RevenueAndCostCurrency RevenueAndCostCurrency { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets ExtendedBillingAmountSR
        /// </summary>
        [Display(Name = "ExtendedBillingAmount", ResourceType = typeof(MaterialUsagesDetailResx))]
        [ViewField(Name = Fields.ExtendedBillingAmountSR, Id = Index.ExtendedBillingAmountSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedBillingAmountSR { get; set; }

        /// <summary>
        /// Gets or sets ExtendedBillingAmountHM
        /// </summary>
        [ViewField(Name = Fields.ExtendedBillingAmountHM, Id = Index.ExtendedBillingAmountHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedBillingAmountHM { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(EquipmentResx))]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(EquipmentResx))]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(EquipmentResx))]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(EquipmentResx))]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(EquipmentResx))]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        [Display(Name = "ContractStyle", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof(EquipmentResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        //[Display(Name = "VALUES", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets GLDetailDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GLDetailDescription, Id = Index.GLDetailDescription, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "GLDetailDescription", ResourceType = typeof(EquipmentResx))]
        public string GLDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets GLDetailReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GLDetailReference, Id = Index.GLDetailReference, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "GLDetailReference", ResourceType = typeof(EquipmentResx))]
        public string GLDetailReference { get; set; }

        /// <summary>
        /// Gets or sets GLDetailComment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.GLDetailComment, Id = Index.GLDetailComment, FieldType = EntityFieldType.Char, Size = 250)]
        [Display(Name = "GLDetailComment", ResourceType = typeof(EquipmentResx))]
        public string GLDetailComment { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public short Function { get; set; }

        /// <summary>
        /// Gets or sets EADescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EADescription, Id = Index.EADescription, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "EADescription", ResourceType = typeof(EquipmentResx))]
        public string EADescription { get; set; }

        /// <summary>
        /// Gets or sets WIPDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.WIPDescription, Id = Index.WIPDescription, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "WIPDescription", ResourceType = typeof(EquipmentResx))]
        public string WIPDescription { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "ItemDescription", ResourceType = typeof(EquipmentResx))]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets ContractDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractDescription, Id = Index.ContractDescription, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "ContractDescription", ResourceType = typeof(EquipmentResx))]
        public string ContractDescription { get; set; }

        /// <summary>
        /// Gets or sets ProjectDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProjectDescription, Id = Index.ProjectDescription, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "ProjectDescription", ResourceType = typeof(EquipmentResx))]
        public string ProjectDescription { get; set; }

        /// <summary>
        /// Gets or sets CategoryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        [Display(Name = "CategoryDescription", ResourceType = typeof(EquipmentResx))]
        public string CategoryDescription { get; set; }

        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        [ViewField(Name = Fields.HasOptionalFields, Id = Index.HasOptionalFields, FieldType = EntityFieldType.Bool, Size = 2)]
        public HASOPT HasOptionalFields { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString => EnumUtility.GetStringValue(ContractStyle);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        #endregion
    }
}
