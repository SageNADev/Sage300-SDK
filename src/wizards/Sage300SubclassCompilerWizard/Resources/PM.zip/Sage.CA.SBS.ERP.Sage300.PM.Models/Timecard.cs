// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for Timecard
    /// </summary>
    public partial class Timecard : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets TimecardNumber
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TimecardNumber", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TimecardNumber, Id = Index.TimecardNumber)]
        public string TimecardNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets EmployeeNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeNumber", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.EmployeeNumber, Id = Index.EmployeeNumber)]
        public string EmployeeNumber { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.EmployeeName, Id = Index.EmployeeName)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets StartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets EndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndDate", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.EndDate, Id = Index.EndDate)]
        public DateTime EndDate { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTSR
        /// </summary>
        [Display(Name = "EXTCOSTSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.EXTCOSTSR, Id = Index.EXTCOSTSR)]
        public decimal EXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTHM
        /// </summary>
        [Display(Name = "EXTCOSTHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.EXTCOSTHM, Id = Index.EXTCOSTHM)]
        public decimal EXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHSR
        /// </summary>
        [Display(Name = "OHSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.OHSR, Id = Index.OHSR)]
        public decimal OHSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHHM
        /// </summary>
        [Display(Name = "OHHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.OHHM, Id = Index.OHHM)]
        public decimal OHHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LABORSR
        /// </summary>
        [Display(Name = "LABORSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.LABORSR, Id = Index.LABORSR)]
        public decimal LABORSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LABORHM
        /// </summary>
        [Display(Name = "LABORHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.LABORHM, Id = Index.LABORHM)]
        public decimal LABORHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTSR
        /// </summary>
        [Display(Name = "TOTCOSTSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TOTCOSTSR, Id = Index.TOTCOSTSR)]
        public decimal TOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTHM
        /// </summary>
        [Display(Name = "TOTCOSTHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TOTCOSTHM, Id = Index.TOTCOSTHM)]
        public decimal TOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTBILLSR
        /// </summary>
        [Display(Name = "TOTBILLSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TOTBILLSR, Id = Index.TOTBILLSR)]
        public decimal TOTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTBILLHM
        /// </summary>
        [Display(Name = "TOTBILLHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TOTBILLHM, Id = Index.TOTBILLHM)]
        public decimal TOTBILLHM { get; set; }

        /// <summary>
        /// Gets or sets TotalHours
        /// </summary>
        [Display(Name = "TotalHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TotalHours, Id = Index.TotalHours)]
        public decimal TotalHours { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ETOTCOSTSR
        /// </summary>
        [Display(Name = "ETOTCOSTSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ETOTCOSTSR, Id = Index.ETOTCOSTSR)]
        public decimal ETOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ETOTCOSTHM
        /// </summary>
        [Display(Name = "ETOTCOSTHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ETOTCOSTHM, Id = Index.ETOTCOSTHM)]
        public decimal ETOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ETOTBILLSR
        /// </summary>
        [Display(Name = "ETOTBILLSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ETOTBILLSR, Id = Index.ETOTBILLSR)]
        public decimal ETOTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ETOTBILLHM
        /// </summary>
        [Display(Name = "ETOTBILLHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ETOTBILLHM, Id = Index.ETOTBILLHM)]
        public decimal ETOTBILLHM { get; set; }

        /// <summary>
        /// Gets or sets TotalExpenseQuantity
        /// </summary>
        [Display(Name = "TotalExpenseQuantity", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TotalExpenseQuantity, Id = Index.TotalExpenseQuantity)]
        public decimal TotalExpenseQuantity { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GTOTCOSTSR
        /// </summary>
        [Display(Name = "GTOTCOSTSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.GTOTCOSTSR, Id = Index.GTOTCOSTSR)]
        public decimal GTOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GTOTCOSTHM
        /// </summary>
        [Display(Name = "GTOTCOSTHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.GTOTCOSTHM, Id = Index.GTOTCOSTHM)]
        public decimal GTOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GTOTBILLSR
        /// </summary>
        [Display(Name = "GTOTBILLSR", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.GTOTBILLSR, Id = Index.GTOTBILLSR)]
        public decimal GTOTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GTOTBILLHM
        /// </summary>
        [Display(Name = "GTOTBILLHM", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.GTOTBILLHM, Id = Index.GTOTBILLHM)]
        public decimal GTOTBILLHM { get; set; }

        /// <summary>
        /// Gets or sets StaffCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StaffCurrency", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.StaffCurrency, Id = Index.StaffCurrency)]
        public string StaffCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType)]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RateOperator RateOperator { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets PrintStatus
        /// </summary>
        [Display(Name = "PrintStatus", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.PrintStatus, Id = Index.PrintStatus)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.PrintStatus PrintStatus { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus
        /// </summary>
        [Display(Name = "TransactionStatus", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.TransactionStatus TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets PayrollType
        /// </summary>
        [Display(Name = "PayrollType", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.PayrollType, Id = Index.PayrollType)]
        public Payroll PayrollType { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumberOfDetails", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails)]
        public int NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets MondayHours
        /// </summary>
        [Display(Name = "MondayHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.MondayHours, Id = Index.MondayHours)]
        public decimal MondayHours { get; set; }

        /// <summary>
        /// Gets or sets TuesdayHours
        /// </summary>
        [Display(Name = "TuesdayHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.TuesdayHours, Id = Index.TuesdayHours)]
        public decimal TuesdayHours { get; set; }

        /// <summary>
        /// Gets or sets WednesdayHours
        /// </summary>
        [Display(Name = "WednesdayHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.WednesdayHours, Id = Index.WednesdayHours)]
        public decimal WednesdayHours { get; set; }

        /// <summary>
        /// Gets or sets ThursdayHours
        /// </summary>
        [Display(Name = "ThursdayHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ThursdayHours, Id = Index.ThursdayHours)]
        public decimal ThursdayHours { get; set; }

        /// <summary>
        /// Gets or sets FridayHours
        /// </summary>
        [Display(Name = "FridayHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.FridayHours, Id = Index.FridayHours)]
        public decimal FridayHours { get; set; }

        /// <summary>
        /// Gets or sets SaturdayHours
        /// </summary>
        [Display(Name = "SaturdayHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.SaturdayHours, Id = Index.SaturdayHours)]
        public decimal SaturdayHours { get; set; }

        /// <summary>
        /// Gets or sets SundayHours
        /// </summary>
        [Display(Name = "SundayHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.SundayHours, Id = Index.SundayHours)]
        public decimal SundayHours { get; set; }

        /// <summary>
        /// Gets or sets WeeklyHours
        /// </summary>
        [Display(Name = "WeeklyHours", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.WeeklyHours, Id = Index.WeeklyHours)]
        public decimal WeeklyHours { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }
        
        /// <summary>
        /// Gets or sets CreatedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedBy", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.CreatedBy, Id = Index.CreatedBy)]
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets CreatedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedOn", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.CreatedOn, Id = Index.CreatedOn)]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets CreatedAt
        /// </summary>
        [Display(Name = "CreatedAt", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.CreatedAt, Id = Index.CreatedAt)]
        public TimeSpan CreatedAt { get; set; }

        /// <summary>
        /// Gets or sets ApprovedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedBy", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ApprovedBy, Id = Index.ApprovedBy)]
        public string ApprovedBy { get; set; }

        /// <summary>
        /// Gets or sets ApprovedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedOn", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ApprovedOn, Id = Index.ApprovedOn)]
        public DateTime ApprovedOn { get; set; }

        /// <summary>
        /// Gets or sets ApprovedAt
        /// </summary>
        [Display(Name = "ApprovedAt", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ApprovedAt, Id = Index.ApprovedAt)]
        public TimeSpan ApprovedAt { get; set; }

        /// <summary>
        /// Gets or sets PostedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedBy", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.PostedBy, Id = Index.PostedBy)]
        public string PostedBy { get; set; }

        /// <summary>
        /// Gets or sets PostedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedOn", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.PostedOn, Id = Index.PostedOn)]
        public DateTime PostedOn { get; set; }

        /// <summary>
        /// Gets or sets PostedAt
        /// </summary>
        [Display(Name = "PostedAt", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.PostedAt, Id = Index.PostedAt)]
        public TimeSpan PostedAt { get; set; }

        /// <summary>
        /// Gets or sets GLEntryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLEntryDescription", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.GLEntryDescription, Id = Index.GLEntryDescription)]
        public string GLEntryDescription { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets ShowProgressBarDuringPosting
        /// </summary>
        [Display(Name = "ShowProgressBarDuringPosting", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.ShowProgressBarDuringPosting, Id = Index.ShowProgressBarDuringPosting)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ShowProgressBarDuringPosting ShowProgressBarDuringPosting { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets USERID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "USERID", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.USERID, Id = Index.USERID)]
        public string USERID { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LSTAFF
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LSTAFF", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.LSTAFF, Id = Index.LSTAFF)]
        public string LSTAFF { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        /// <summary>
        /// Gets or sets SignonUserCanSeeThisTimecar
        /// </summary>
        [Display(Name = "SignonUserCanSeeThisTimecar", ResourceType = typeof (TimecardResx))]
        [ViewField(Name = Fields.SignonUserCanSeeThisTimecar, Id = Index.SignonUserCanSeeThisTimecar)]
        public short SignonUserCanSeeThisTimecar { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        public string FiscalPeriodString => EnumUtility.GetStringValue(FiscalPeriod);

        /// <summary>
        /// Gets RateOperator string value
        /// </summary>
        public string RateOperatorString => EnumUtility.GetStringValue(RateOperator);

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString => EnumUtility.GetStringValue(Status);

        /// <summary>
        /// Gets PrintStatus string value
        /// </summary>
        public string PrintStatusString => EnumUtility.GetStringValue(PrintStatus);

        /// <summary>
        /// Gets TransactionStatus string value
        /// </summary>
        public string TransactionStatusString => EnumUtility.GetStringValue(TransactionStatus);

        /// <summary>
        /// Gets PayrollType string value
        /// </summary>
        public string PayrollTypeString => EnumUtility.GetStringValue(PayrollType);

        /// <summary>
        /// Gets ShowProgressBarDuringPosting string value
        /// </summary>
        public string ShowProgressBarDuringPostingString => EnumUtility.GetStringValue(ShowProgressBarDuringPosting);

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString => EnumUtility.GetStringValue(Function);

        /// <summary>
        /// Company functional currency decimals
        /// </summary>
        public int FuncCurrencyDecimals { get; set; }
        #endregion
    }
}
