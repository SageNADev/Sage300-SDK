// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Process;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Process
{
    /// <summary>
    /// Partial class for TransactionPosting
    /// </summary>
    public partial class TransactionPosting : ModelBase
    {
        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof (TransactionPostingResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Process.DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets PostTheFollowingTransactions
        /// </summary>
        [Display(Name = "PostTheFollowingTransactions", ResourceType = typeof (TransactionPostingResx))]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Process.PostTheFollowingTransactions PostTheFollowingTransactions { get; set; }

        /// <summary>
        /// Gets or sets FromDocument
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDocument", ResourceType = typeof (TransactionPostingResx))]
        [ViewField(Name = Fields.FromDocument, Id = Index.FromDocument, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FromDocument { get; set; }

        /// <summary>
        /// Gets or sets ToDocument
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToDocument", ResourceType = typeof (TransactionPostingResx))]
        [ViewField(Name = Fields.ToDocument, Id = Index.ToDocument, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ToDocument { get; set; }

        /// <summary>
        /// Gets or sets Entered
        /// </summary>
        [Display(Name = "Entered", ResourceType = typeof (TransactionPostingResx))]
        [ViewField(Name = Fields.Entered, Id = Index.Entered, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Entered { get; set; }

        /// <summary>
        /// Gets or sets Approved
        /// </summary>
        [Display(Name = "Approved", ResourceType = typeof (TransactionPostingResx))]
        [ViewField(Name = Fields.Approved, Id = Index.Approved, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Approved { get; set; }

        /// <summary>
        /// Gets or sets ReadyForApproval
        /// </summary>
        [Display(Name = "ReadyForApproval", ResourceType = typeof (TransactionPostingResx))]
        [ViewField(Name = Fields.ReadyForApproval, Id = Index.ReadyForApproval, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ReadyForApproval { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        public string DocumentTypeString
        {
         get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets PostTheFollowingTransactions string value
        /// </summary>
        //public string PostTheFollowingTransactions
        //{
        // get { return EnumUtility.GetStringValue(PostTheFollowingTransactions); }
        //}


        /// <summary>
        /// Gets or sets CanPostTimecards
        /// </summary>
        public bool CanPostTimecards { get; set; }

        /// <summary>
        /// Gets or sets CanPostEquipmentUsage
        /// </summary>
        public bool CanPostEquipmentUsage { get; set; }

        /// <summary>
        /// Gets or sets CanPostCharge
        /// </summary>
        public bool CanPostCharge { get; set; }

        /// <summary>
        /// Gets or sets CanPostCosts
        /// </summary>
        public bool CanPostCosts { get; set; }

        /// <summary>
        /// Gets or sets CanPostReviseEstimates
        /// </summary>
        public bool CanPostReviseEstimates { get; set; }

        /// <summary>
        /// Gets or sets CanPostMaterialUsage
        /// </summary>
        public bool CanPostMaterialUsage { get; set; }

        /// <summary>
        /// Gets or sets CanPostMaterialReturn
        /// </summary>
        public bool CanPostMaterialReturn { get; set; }

        /// <summary>
        /// Gets or sets CanPostMaterialAllocation
        /// </summary>
        public bool CanPostMaterialAllocation { get; set; }

        #endregion
    }
}
