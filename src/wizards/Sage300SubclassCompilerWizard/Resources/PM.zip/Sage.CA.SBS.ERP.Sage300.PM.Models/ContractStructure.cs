// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for ContractStructure
    /// </summary>
    public partial class ContractStructure : ModelBase
    {
        /// <summary>
        /// Gets or sets StructureCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "StructureCode", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Description", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Prefix
        /// </summary>
        //[Display(Name = "Prefix", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Prefix, Id = Index.Prefix, FieldType = EntityFieldType.Int, Size = 2)]
        public Separator Prefix { get; set; }

        /// <summary>
        /// Gets or sets Segment1
        /// </summary>
        //[Display(Name = "Segment1", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment1, Id = Index.Segment1, FieldType = EntityFieldType.Int, Size = 2)]
        public Segment Segment1 { get; set; }

        /// <summary>
        /// Gets or sets Segment1Offset
        /// </summary>
        //[Display(Name = "Segment1Offset", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment1Offset, Id = Index.Segment1Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment1Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment1Length
        /// </summary>
        //[Display(Name = "Segment1Length", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment1Length, Id = Index.Segment1Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment1Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment1
        /// </summary>
        //[Display(Name = "ValidateSegment1", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.ValidateSegment1, Id = Index.ValidateSegment1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator1
        /// </summary>
        //[Display(Name = "SegmentSeparator1", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.SegmentSeparator1, Id = Index.SegmentSeparator1, FieldType = EntityFieldType.Int, Size = 2)]
        public Separator SegmentSeparator1 { get; set; }

        /// <summary>
        /// Gets or sets Segment2
        /// </summary>
        //[Display(Name = "Segment2", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment2, Id = Index.Segment2, FieldType = EntityFieldType.Int, Size = 2)]
        public Segment Segment2 { get; set; }

        /// <summary>
        /// Gets or sets Segment2Offset
        /// </summary>
        //[Display(Name = "Segment2Offset", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment2Offset, Id = Index.Segment2Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment2Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment2Length
        /// </summary>
        //[Display(Name = "Segment2Length", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment2Length, Id = Index.Segment2Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment2Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment2
        /// </summary>
        //[Display(Name = "ValidateSegment2", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.ValidateSegment2, Id = Index.ValidateSegment2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator2
        /// </summary>
        //[Display(Name = "SegmentSeparator2", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.SegmentSeparator2, Id = Index.SegmentSeparator2, FieldType = EntityFieldType.Int, Size = 2)]
        public Separator SegmentSeparator2 { get; set; }

        /// <summary>
        /// Gets or sets Segment3
        /// </summary>
        //[Display(Name = "Segment3", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment3, Id = Index.Segment3, FieldType = EntityFieldType.Int, Size = 2)]
        public Segment Segment3 { get; set; }

        /// <summary>
        /// Gets or sets Segment3Offset
        /// </summary>
        //[Display(Name = "Segment3Offset", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment3Offset, Id = Index.Segment3Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment3Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment3Length
        /// </summary>
        //[Display(Name = "Segment3Length", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment3Length, Id = Index.Segment3Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment3Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment3
        /// </summary>
        //[Display(Name = "ValidateSegment3", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.ValidateSegment3, Id = Index.ValidateSegment3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator3
        /// </summary>
        //[Display(Name = "SegmentSeparator3", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.SegmentSeparator3, Id = Index.SegmentSeparator3, FieldType = EntityFieldType.Int, Size = 2)]
        public Separator SegmentSeparator3 { get; set; }

        /// <summary>
        /// Gets or sets Segment4
        /// </summary>
        //[Display(Name = "Segment4", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment4, Id = Index.Segment4, FieldType = EntityFieldType.Int, Size = 2)]
        public Segment Segment4 { get; set; }

        /// <summary>
        /// Gets or sets Segment4Offset
        /// </summary>
        //[Display(Name = "Segment4Offset", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment4Offset, Id = Index.Segment4Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment4Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment4Length
        /// </summary>
        //[Display(Name = "Segment4Length", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment4Length, Id = Index.Segment4Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment4Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment4
        /// </summary>
        //[Display(Name = "ValidateSegment4", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.ValidateSegment4, Id = Index.ValidateSegment4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator4
        /// </summary>
        //[Display(Name = "SegmentSeparator4", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.SegmentSeparator4, Id = Index.SegmentSeparator4, FieldType = EntityFieldType.Int, Size = 2)]
        public Separator SegmentSeparator4 { get; set; }

        /// <summary>
        /// Gets or sets Segment5
        /// </summary>
        //[Display(Name = "Segment5", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment5, Id = Index.Segment5, FieldType = EntityFieldType.Int, Size = 2)]
        public Segment Segment5 { get; set; }

        /// <summary>
        /// Gets or sets Segment5Offset
        /// </summary>
        //[Display(Name = "Segment5Offset", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment5Offset, Id = Index.Segment5Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment5Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment5Length
        /// </summary>
        //[Display(Name = "Segment5Length", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.Segment5Length, Id = Index.Segment5Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Segment5Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment5
        /// </summary>
        //[Display(Name = "ValidateSegment5", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.ValidateSegment5, Id = Index.ValidateSegment5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator5
        /// </summary>
        //[Display(Name = "SegmentSeparator5", ResourceType = typeof (ContractStructureResx))]
        [ViewField(Name = Fields.SegmentSeparator5, Id = Index.SegmentSeparator5, FieldType = EntityFieldType.Int, Size = 2)]
        public Separator SegmentSeparator5 { get; set; }

        #region UI Strings

        /*
        /// <summary>
        /// Gets Prefix string value
        /// </summary>
        public string PrefixString
        {
         get { return EnumUtility.GetStringValue(Prefix); }
        }

        /// <summary>
        /// Gets Segment1 string value
        /// </summary>
        public string Segment1String
        {
         get { return EnumUtility.GetStringValue(Segment1); }
        }

        /// <summary>
        /// Gets SegmentSeparator1 string value
        /// </summary>
        public string SegmentSeparator1String
        {
         get { return EnumUtility.GetStringValue(SegmentSeparator1); }
        }

        /// <summary>
        /// Gets Segment2 string value
        /// </summary>
        public string Segment2String
        {
         get { return EnumUtility.GetStringValue(Segment2); }
        }

        /// <summary>
        /// Gets SegmentSeparator2 string value
        /// </summary>
        public string SegmentSeparator2String
        {
         get { return EnumUtility.GetStringValue(SegmentSeparator2); }
        }

        /// <summary>
        /// Gets Segment3 string value
        /// </summary>
        public string Segment3String
        {
         get { return EnumUtility.GetStringValue(Segment3); }
        }

        /// <summary>
        /// Gets SegmentSeparator3 string value
        /// </summary>
        public string SegmentSeparator3String
        {
         get { return EnumUtility.GetStringValue(SegmentSeparator3); }
        }

        /// <summary>
        /// Gets Segment4 string value
        /// </summary>
        public string Segment4String
        {
         get { return EnumUtility.GetStringValue(Segment4); }
        }

        /// <summary>
        /// Gets SegmentSeparator4 string value
        /// </summary>
        public string SegmentSeparator4String
        {
         get { return EnumUtility.GetStringValue(SegmentSeparator4); }
        }

        /// <summary>
        /// Gets Segment5 string value
        /// </summary>
        public string Segment5String
        {
         get { return EnumUtility.GetStringValue(Segment5); }
        }

        /// <summary>
        /// Gets SegmentSeparator5 string value
        /// </summary>
        public string SegmentSeparator5String
        {
         get { return EnumUtility.GetStringValue(SegmentSeparator5); }
        }
        */

        #endregion
    }
}
