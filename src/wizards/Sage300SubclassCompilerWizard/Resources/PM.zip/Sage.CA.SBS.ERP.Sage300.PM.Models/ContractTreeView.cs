﻿using System;
using System.Collections.Generic;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Contract Tree View Node definition
    /// </summary>
    public class TreeViewItem
    {
        /// <summary>
        /// Node id
        /// </summary>
        public string id { get; set; }

        /// <summary>
        /// Node project id
        /// </summary>
        public string projectId { get; set; } = "";

        /// <summary>
        /// Node screen url
        /// </summary>
        public string srcUrl { get; set; }

        /// <summary>
        /// Node display text
        /// </summary>
        public string text { get; set; }

        /// <summary>
        /// Node Css, format node display 
        /// </summary>
        public string spriteCssClass { get; set; }

        /// <summary>
        /// Node is expanede or not
        /// </summary>
        public bool expanded { get; set; }

        /// <summary>
        /// Context menu type
        /// </summary>
        public string menuType { get; set; } = "1";

        /// <summary>
        /// Resource Type
        /// </summary>
        public int resourceType { get; set; } = 0;

        /// <summary>
        /// Node child node items
        /// </summary>
        public List<TreeViewItem> items { get; set; }
 
    }

    public class ResourceData
    {
        public string CLineNumber { get; set; }
        public string Project { get; set; }
        public string Resource { get; set; }
        public string Comment { get; set; }
        public int Type { get; set; }
    }
}
