// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for TransactionHistory
    /// </summary>
    public partial class TransactionHistory : ModelBase
    {
        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [Key]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTRACT", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT)]
        public string CONTRACT { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [Key]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project)]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [Key]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category)]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [Key]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource)]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber
        /// </summary>
        [Key]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber)]
        public int TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained)]
        public DateTime LastMaintained { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FMTCONTNO", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO)]
        public string FMTCONTNO { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber)]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor)]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber)]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate)]
        public DateTime DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets SourceModule
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceModule", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.SourceModule, Id = Index.SourceModule)]
        public string SourceModule { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets CostOrRevenue
        /// </summary>
        [Display(Name = "CostOrRevenue", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CostOrRevenue, Id = Index.CostOrRevenue)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CostOrRevenue CostOrRevenue { get; set; }

        /// <summary>
        /// Gets or sets ReferenceDocument
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReferenceDocument", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ReferenceDocument, Id = Index.ReferenceDocument)]
        public string ReferenceDocument { get; set; }

        /// <summary>
        /// Gets or sets BatchDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchEntryNumber
        /// </summary>
        [Display(Name = "BatchEntryNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.BatchEntryNumber, Id = Index.BatchEntryNumber)]
        public decimal BatchEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchLineNumber
        /// </summary>
        [Display(Name = "BatchLineNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.BatchLineNumber, Id = Index.BatchLineNumber)]
        public decimal BatchLineNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentReference", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DocumentReference, Id = Index.DocumentReference)]
        public string DocumentReference { get; set; }

        /// <summary>
        /// Gets or sets DocumentDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDescription", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DocumentDescription, Id = Index.DocumentDescription)]
        public string DocumentDescription { get; set; }

        /// <summary>
        /// Gets or sets PostingSequence
        /// </summary>
        [Display(Name = "PostingSequence", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence)]
        public int PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode)]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateTypeCode
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateTypeCode", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RateTypeCode, Id = Index.RateTypeCode)]
        public string RateTypeCode { get; set; }

        ///// <summary>
        ///// Gets or sets RateOverride
        ///// </summary>
        //[Display(Name = "RateOverride", ResourceType = typeof (TransactionHistoryResx))]
        //[ViewField(Name = Fields.RateOverride, Id = Index.RateOverride)]
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RateOverride RateOverride { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RateOperator RateOperator { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.FiscalPeriod FiscalPeriod { get; set; }

        ///// <summary>
        ///// Gets or sets HasTheCostComponentBeenBill
        ///// </summary>
        //[Display(Name = "HasTheCostComponentBeenBill", ResourceType = typeof (TransactionHistoryResx))]
        //[ViewField(Name = Fields.HasTheCostComponentBeenBill, Id = Index.HasTheCostComponentBeenBill)]
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.HasTheCostComponentBeenBill HasTheCostComponentBeenBill { get; set; }

        /// <summary>
        /// Gets or sets TransactionQuantity
        /// </summary>
        [Display(Name = "TransactionQuantity", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity)]
        public decimal TransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactor
        /// </summary>
        [Display(Name = "ConversionFactor", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor)]
        public decimal ConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets ICUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICUnitOfMeasure", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ICUnitOfMeasure, Id = Index.ICUnitOfMeasure)]
        public string ICUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillAmountBasedOn
        /// </summary>
        [Display(Name = "BillAmountBasedOn", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.BillAmountBasedOn, Id = Index.BillAmountBasedOn)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillAmountBasedOn BillAmountBasedOn { get; set; }

        ///// <summary>
        ///// Gets or sets TimecardExpenseType
        ///// </summary>
        //[Display(Name = "TimecardExpenseType", ResourceType = typeof (TransactionHistoryResx))]
        //[ViewField(Name = Fields.TimecardExpenseType, Id = Index.TimecardExpenseType)]
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.TimecardExpenseType TimecardExpenseType { get; set; }

        /// <summary>
        /// Gets or sets UnitRate
        /// </summary>
        [Display(Name = "UnitRate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.UnitRate, Id = Index.UnitRate)]
        public decimal UnitRate { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountSource
        /// </summary>
        [Display(Name = "ExtendedAmountSource", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ExtendedAmountSource, Id = Index.ExtendedAmountSource)]
        public decimal ExtendedAmountSource { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountFunctional
        /// </summary>
        [Display(Name = "ExtendedAmountFunctional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ExtendedAmountFunctional, Id = Index.ExtendedAmountFunctional)]
        public decimal ExtendedAmountFunctional { get; set; }

        /// <summary>
        /// Gets or sets LaborType
        /// </summary>
        [Display(Name = "LaborType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.LaborType, Id = Index.LaborType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.LaborType LaborType { get; set; }

        /// <summary>
        /// Gets or sets LaborRate
        /// </summary>
        [Display(Name = "LaborRate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.LaborRate, Id = Index.LaborRate)]
        public decimal LaborRate { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentage
        /// </summary>
        [Display(Name = "LaborPercentage", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.LaborPercentage, Id = Index.LaborPercentage)]
        public decimal LaborPercentage { get; set; }

        /// <summary>
        /// Gets or sets SourceLaborAmount
        /// </summary>
        [Display(Name = "SourceLaborAmount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.SourceLaborAmount, Id = Index.SourceLaborAmount)]
        public decimal SourceLaborAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalLaborAmount
        /// </summary>
        [Display(Name = "FunctionalLaborAmount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FunctionalLaborAmount, Id = Index.FunctionalLaborAmount)]
        public decimal FunctionalLaborAmount { get; set; }

        /// <summary>
        /// Gets or sets OverheadType
        /// </summary>
        [Display(Name = "OverheadType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.OverheadType, Id = Index.OverheadType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OverheadType OverheadType { get; set; }

        /// <summary>
        /// Gets or sets OverheadRate
        /// </summary>
        [Display(Name = "OverheadRate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.OverheadRate, Id = Index.OverheadRate)]
        public decimal OverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OverheadPercentage
        /// </summary>
        [Display(Name = "OverheadPercentage", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.OverheadPercentage, Id = Index.OverheadPercentage)]
        public decimal OverheadPercentage { get; set; }

        /// <summary>
        /// Gets or sets SourceOverheadAmount
        /// </summary>
        [Display(Name = "SourceOverheadAmount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.SourceOverheadAmount, Id = Index.SourceOverheadAmount)]
        public decimal SourceOverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalOverheadAmount
        /// </summary>
        [Display(Name = "FunctionalOverheadAmount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FunctionalOverheadAmount, Id = Index.FunctionalOverheadAmount)]
        public decimal FunctionalOverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets CostPlusPercentage
        /// </summary>
        [Display(Name = "CostPlusPercentage", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CostPlusPercentage, Id = Index.CostPlusPercentage)]
        public decimal CostPlusPercentage { get; set; }

        /// <summary>
        /// Gets or sets SourceTotalAmountExclTax
        /// </summary>
        [Display(Name = "SourceTotalAmountExclTax", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.SourceTotalAmountExclTax, Id = Index.SourceTotalAmountExclTax)]
        public decimal SourceTotalAmountExclTax { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTotalAmountExclTax
        /// </summary>
        [Display(Name = "FunctionalTotalAmountExclTax", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FunctionalTotalAmountExclTax, Id = Index.FunctionalTotalAmountExclTax)]
        public decimal FunctionalTotalAmountExclTax { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountSource
        /// </summary>
        [Display(Name = "TaxAmountSource", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmountSource, Id = Index.TaxAmountSource)]
        public decimal TaxAmountSource { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountFunctional
        /// </summary>
        [Display(Name = "TaxAmountFunctional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmountFunctional, Id = Index.TaxAmountFunctional)]
        public decimal TaxAmountFunctional { get; set; }

        /// <summary>
        /// Gets or sets SourceTotalAmountIncludeTax
        /// </summary>
        [Display(Name = "SourceTotalAmountIncludeTax", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.SourceTotalAmountIncludeTax, Id = Index.SourceTotalAmountIncludeTax)]
        public decimal SourceTotalAmountIncludeTax { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTotalAmountIncludeTax
        /// </summary>
        [Display(Name = "FunctionalTotalAmountIncludeTax", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FunctionalTotalAmountIncludeTax, Id = Index.FunctionalTotalAmountIncludeTax)]
        public decimal FunctionalTotalAmountIncludeTax { get; set; }

        ///// <summary>
        ///// Gets or sets HasRevenueRecognitionBeenRun
        ///// </summary>
        //[Display(Name = "HasRevenueRecognitionBeenRun", ResourceType = typeof (TransactionHistoryResx))]
        //[ViewField(Name = Fields.HasRevenueRecognitionBeenRun, Id = Index.HasRevenueRecognitionBeenRun)]
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.HasRevenueRecognitionBeenRun HasRevenueRecognitionBeenRun { get; set; }

        /// <summary>
        /// Gets or sets AmountReceivedSource
        /// </summary>
        [Display(Name = "AmountReceivedSource", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.AmountReceivedSource, Id = Index.AmountReceivedSource)]
        public decimal AmountReceivedSource { get; set; }

        /// <summary>
        /// Gets or sets AmountReceivedFunctional
        /// </summary>
        [Display(Name = "AmountReceivedFunctional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.AmountReceivedFunctional, Id = Index.AmountReceivedFunctional)]
        public decimal AmountReceivedFunctional { get; set; }

        /// <summary>
        /// Gets or sets AmountPaidSource
        /// </summary>
        [Display(Name = "AmountPaidSource", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.AmountPaidSource, Id = Index.AmountPaidSource)]
        public decimal AmountPaidSource { get; set; }

        /// <summary>
        /// Gets or sets AmountPaid
        /// </summary>
        [Display(Name = "AmountPaid", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.AmountPaid, Id = Index.AmountPaid)]
        public decimal AmountPaid { get; set; }

        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID)]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1)]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2)]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3)]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4)]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5)]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1)]
        public short TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2)]
        public short TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3)]
        public short TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4)]
        public short TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5)]
        public short TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass1
        /// </summary>
        [Display(Name = "ItemTaxClass1", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ItemTaxClass1, Id = Index.ItemTaxClass1)]
        public short ItemTaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass2
        /// </summary>
        [Display(Name = "ItemTaxClass2", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ItemTaxClass2, Id = Index.ItemTaxClass2)]
        public short ItemTaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass3
        /// </summary>
        [Display(Name = "ItemTaxClass3", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ItemTaxClass3, Id = Index.ItemTaxClass3)]
        public short ItemTaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass4
        /// </summary>
        [Display(Name = "ItemTaxClass4", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ItemTaxClass4, Id = Index.ItemTaxClass4)]
        public short ItemTaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClass5
        /// </summary>
        [Display(Name = "ItemTaxClass5", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ItemTaxClass5, Id = Index.ItemTaxClass5)]
        public short ItemTaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1Source
        /// </summary>
        [Display(Name = "TaxBase1Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase1Source, Id = Index.TaxBase1Source)]
        public decimal TaxBase1Source { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2Source
        /// </summary>
        [Display(Name = "TaxBase2Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase2Source, Id = Index.TaxBase2Source)]
        public decimal TaxBase2Source { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3Source
        /// </summary>
        [Display(Name = "TaxBase3Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase3Source, Id = Index.TaxBase3Source)]
        public decimal TaxBase3Source { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4Source
        /// </summary>
        [Display(Name = "TaxBase4Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase4Source, Id = Index.TaxBase4Source)]
        public decimal TaxBase4Source { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5Source
        /// </summary>
        [Display(Name = "TaxBase5Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase5Source, Id = Index.TaxBase5Source)]
        public decimal TaxBase5Source { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1Functional
        /// </summary>
        [Display(Name = "TaxBase1Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase1Functional, Id = Index.TaxBase1Functional)]
        public decimal TaxBase1Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2Functional
        /// </summary>
        [Display(Name = "TaxBase2Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase2Functional, Id = Index.TaxBase2Functional)]
        public decimal TaxBase2Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3Functional
        /// </summary>
        [Display(Name = "TaxBase3Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase3Functional, Id = Index.TaxBase3Functional)]
        public decimal TaxBase3Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4Functional
        /// </summary>
        [Display(Name = "TaxBase4Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase4Functional, Id = Index.TaxBase4Functional)]
        public decimal TaxBase4Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5Functional
        /// </summary>
        [Display(Name = "TaxBase5Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxBase5Functional, Id = Index.TaxBase5Functional)]
        public decimal TaxBase5Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1Source
        /// </summary>
        [Display(Name = "TaxAmount1Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount1Source, Id = Index.TaxAmount1Source)]
        public decimal TaxAmount1Source { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2Source
        /// </summary>
        [Display(Name = "TaxAmount2Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount2Source, Id = Index.TaxAmount2Source)]
        public decimal TaxAmount2Source { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3Source
        /// </summary>
        [Display(Name = "TaxAmount3Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount3Source, Id = Index.TaxAmount3Source)]
        public decimal TaxAmount3Source { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4Source
        /// </summary>
        [Display(Name = "TaxAmount4Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount4Source, Id = Index.TaxAmount4Source)]
        public decimal TaxAmount4Source { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5Source
        /// </summary>
        [Display(Name = "TaxAmount5Source", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount5Source, Id = Index.TaxAmount5Source)]
        public decimal TaxAmount5Source { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1Functional
        /// </summary>
        [Display(Name = "TaxAmount1Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount1Functional, Id = Index.TaxAmount1Functional)]
        public decimal TaxAmount1Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2Functional
        /// </summary>
        [Display(Name = "TaxAmount2Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount2Functional, Id = Index.TaxAmount2Functional)]
        public decimal TaxAmount2Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3Functional
        /// </summary>
        [Display(Name = "TaxAmount3Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount3Functional, Id = Index.TaxAmount3Functional)]
        public decimal TaxAmount3Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4Functional
        /// </summary>
        [Display(Name = "TaxAmount4Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount4Functional, Id = Index.TaxAmount4Functional)]
        public decimal TaxAmount4Functional { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5Functional
        /// </summary>
        [Display(Name = "TaxAmount5Functional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TaxAmount5Functional, Id = Index.TaxAmount5Functional)]
        public decimal TaxAmount5Functional { get; set; }

        /// <summary>
        /// Gets or sets RecoverableTaxSource
        /// </summary>
        [Display(Name = "RecoverableTaxSource", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RecoverableTaxSource, Id = Index.RecoverableTaxSource)]
        public decimal RecoverableTaxSource { get; set; }

        /// <summary>
        /// Gets or sets RecoverableTaxFunctional
        /// </summary>
        [Display(Name = "RecoverableTaxFunctional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RecoverableTaxFunctional, Id = Index.RecoverableTaxFunctional)]
        public decimal RecoverableTaxFunctional { get; set; }

        /// <summary>
        /// Gets or sets CostVarianceAmount
        /// </summary>
        [Display(Name = "CostVarianceAmount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CostVarianceAmount, Id = Index.CostVarianceAmount)]
        public decimal CostVarianceAmount { get; set; }

        /// <summary>
        /// Gets or sets WIPCOSAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WIPCOSAccount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.WIPCOSAccount, Id = Index.WIPCOSAccount)]
        public string WIPCOSAccount { get; set; }

        /// <summary>
        /// Gets or sets TransactionAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionAccount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TransactionAccount, Id = Index.TransactionAccount)]
        public string TransactionAccount { get; set; }

        /// <summary>
        /// Gets or sets LaborAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LaborAccount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.LaborAccount, Id = Index.LaborAccount)]
        public string LaborAccount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OverheadAccount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.OverheadAccount, Id = Index.OverheadAccount)]
        public string OverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets RevenueAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueAccount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RevenueAccount, Id = Index.RevenueAccount)]
        public string RevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets CostVarianceAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostVarianceAccount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CostVarianceAccount, Id = Index.CostVarianceAccount)]
        public string CostVarianceAccount { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber)]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARUnitOfMeasure", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ARUnitOfMeasure, Id = Index.ARUnitOfMeasure)]
        public string ARUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets TransactionReference
        /// </summary>
        [Display(Name = "TransactionReference", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.TransactionReference, Id = Index.TransactionReference)]
        public int TransactionReference { get; set; }

        /// <summary>
        /// Gets or sets CostRevenueTRANSNUM
        /// </summary>
        [Display(Name = "CostRevenueTRANSNUM", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CostRevenueTRANSNUM, Id = Index.CostRevenueTRANSNUM)]
        public int CostRevenueTRANSNUM { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets RRWorksheetNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RRWorksheetNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RRWorksheetNumber, Id = Index.RRWorksheetNumber)]
        public string RRWorksheetNumber { get; set; }

        /// <summary>
        /// Gets or sets BillingWorksheetNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingWorksheetNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.BillingWorksheetNumber, Id = Index.BillingWorksheetNumber)]
        public string BillingWorksheetNumber { get; set; }

        /// <summary>
        /// Gets or sets SourceRetainageAmount
        /// </summary>
        [Display(Name = "SourceRetainageAmount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.SourceRetainageAmount, Id = Index.SourceRetainageAmount)]
        public decimal SourceRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRetainageAmount
        /// </summary>
        [Display(Name = "FunctionalRetainageAmount", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.FunctionalRetainageAmount, Id = Index.FunctionalRetainageAmount)]
        public decimal FunctionalRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageDueDate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate)]
        public DateTime RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocumentNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalDocumentNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.OriginalDocumentNumber, Id = Index.OriginalDocumentNumber)]
        public string OriginalDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets DayEndSequence
        /// </summary>
        [Display(Name = "DayEndSequence", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DayEndSequence, Id = Index.DayEndSequence)]
        public int DayEndSequence { get; set; }

        /// <summary>
        /// Gets or sets DayEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DayEndDate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DayEndDate, Id = Index.DayEndDate)]
        public DateTime DayEndDate { get; set; }

        /// <summary>
        /// Gets or sets OriginalApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalApplication", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.OriginalApplication, Id = Index.OriginalApplication)]
        public string OriginalApplication { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        [Display(Name = "VALUES", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.VALUES, Id = Index.VALUES)]
        public int VALUES { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType
        /// </summary>
        [Display(Name = "DrillDownType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType)]
        public short DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLink
        /// </summary>
        [Display(Name = "DrillDownLink", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DrillDownLink, Id = Index.DrillDownLink)]
        public decimal DrillDownLink { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DrillDownApplication", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.DrillDownApplication, Id = Index.DrillDownApplication)]
        public string DrillDownApplication { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EARNINGS
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EARNINGS", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.EARNINGS, Id = Index.EARNINGS)]
        public string EARNINGS { get; set; }

        /// <summary>
        /// Gets or sets ExpensedTaxSource
        /// </summary>
        [Display(Name = "ExpensedTaxSource", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ExpensedTaxSource, Id = Index.ExpensedTaxSource)]
        public decimal ExpensedTaxSource { get; set; }

        /// <summary>
        /// Gets or sets ExpensedTaxFunctional
        /// </summary>
        [Display(Name = "ExpensedTaxFunctional", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.ExpensedTaxFunctional, Id = Index.ExpensedTaxFunctional)]
        public decimal ExpensedTaxFunctional { get; set; }

        //// TODO The naming convention of this property has to be manually evaluated
        ///// <summary>
        ///// Gets or sets COSTTYPE
        ///// </summary>
        //[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "COSTTYPE", ResourceType = typeof (TransactionHistoryResx))]
        //[ViewField(Name = Fields.COSTTYPE, Id = Index.COSTTYPE)]
        //public string COSTTYPE { get; set; }
        ///// <summary>
        ///// Gets or sets AdditionalCostType
        ///// </summary>
        //[Display(Name = "AdditionalCostType", ResourceType = typeof (TransactionHistoryResx))]
        //[ViewField(Name = Fields.AdditionalCostType, Id = Index.AdditionalCostType)]
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AdditionalCostType AdditionalCostType { get; set; }


        /// <summary>
        /// Gets or sets CurrentPMVersion
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentPMVersion", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CurrentPMVersion, Id = Index.CurrentPMVersion)]
        public string CurrentPMVersion { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentRevenueType
        /// </summary>
        [Display(Name = "AdjustmentRevenueType", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.AdjustmentRevenueType, Id = Index.AdjustmentRevenueType)]
        public short AdjustmentRevenueType { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets EmployeeNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeNumber", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.EmployeeNumber, Id = Index.EmployeeNumber)]
        public string EmployeeNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LINENO
        /// </summary>
        [Display(Name = "LINENO", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.LINENO, Id = Index.LINENO)]
        public short LINENO { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets VendorName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets LocationName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationName", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.LocationName, Id = Index.LocationName)]
        public string LocationName { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        [Display(Name = "HASOPT", ResourceType = typeof (TransactionHistoryResx))]
        [ViewField(Name = Fields.HASOPT, Id = Index.HASOPT)]
        public Enums.HASOPT HASOPT { get; set; }

        #region UI Strings
        [Display(Name = "ContractDescription", ResourceType = typeof(PMCommonResx))]
        public string ContractDescription { get; set; }

        [Display(Name = "ProjectDescription", ResourceType = typeof(PMCommonResx))]
        public string ProjectDescription { get; set; }

        [Display(Name = "CategoryDescription", ResourceType = typeof(PMCommonResx))]
        public string CategoryDescription { get; set; }

        [Display(Name = "ResourceDescription", ResourceType = typeof(PMCommonResx))]
        public string ResourceDescription { get; set; }
        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        public string DocumentTypeString => EnumUtility.GetStringValue(DocumentType);

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        public string TransactionTypeString => EnumUtility.GetStringValue(TransactionType);

        /// <summary>
        /// Gets CostOrRevenue string value
        /// </summary>
        public string CostOrRevenueString => EnumUtility.GetStringValue(CostOrRevenue);

        ///// <summary>
        ///// Gets RateOverride string value
        ///// </summary>
        //public string RateOverrideString => EnumUtility.GetStringValue(RateOverride);

        /// <summary>
        /// Gets RateOperator string value
        /// </summary>
        public string RateOperatorString => EnumUtility.GetStringValue(RateOperator);

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        public string FiscalPeriodString => EnumUtility.GetStringValue(FiscalPeriod);

        ///// <summary>
        ///// Gets HasTheCostComponentBeenBill string value
        ///// </summary>
        //public string HasTheCostComponentBeenBillString => EnumUtility.GetStringValue(HasTheCostComponentBeenBill);

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString => EnumUtility.GetStringValue(BillingType);

        /// <summary>
        /// Gets BillAmountBasedOn string value
        /// </summary>
        public string BillAmountBasedOnString => EnumUtility.GetStringValue(BillAmountBasedOn);

        ///// <summary>
        ///// Gets TimecardExpenseType string value
        ///// </summary>
        //public string TimecardExpenseTypeString => EnumUtility.GetStringValue(TimecardExpenseType);

        /// <summary>
        /// Gets LaborType string value
        /// </summary>
        public string LaborTypeString => EnumUtility.GetStringValue(LaborType);

        /// <summary>
        /// Gets OverheadType string value
        /// </summary>
        public string OverheadTypeString => EnumUtility.GetStringValue(OverheadType);

        ///// <summary>
        ///// Gets HasRevenueRecognitionBeenRun string value
        ///// </summary>
        //public string HasRevenueRecognitionBeenRunString => EnumUtility.GetStringValue(HasRevenueRecognitionBeenRun);

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString => EnumUtility.GetStringValue(CostClass);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString => EnumUtility.GetStringValue(InvoiceType);

        ///// <summary>
        ///// Gets AdditionalCostType string value
        ///// </summary>
        //public string AdditionalCostTypeString => EnumUtility.GetStringValue(AdditionalCostType);

        /// <summary>
        /// Gets HASOPT string value
        /// </summary>
        public string HASOPTString => EnumUtility.GetStringValue(HASOPT);

        #endregion
    }
}
