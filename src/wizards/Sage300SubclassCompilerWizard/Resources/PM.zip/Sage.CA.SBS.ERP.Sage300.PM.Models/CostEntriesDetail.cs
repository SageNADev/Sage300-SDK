// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for CostEntriesDetail
    /// </summary>
    public partial class CostEntriesDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Sequence", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "DocumentNumber", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets LineType
        /// </summary>
        //[Display(Name = "LineType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FormattedContractNumber, Id = Index.FormattedContractNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FormattedContractNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "CONTRACT", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROJECT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CATEGORY
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        //[Display(Name = "CostClass", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostType CostClass { get; set; }

        /// <summary>
        /// Gets or sets ChargeCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ChargeCode", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.ChargeCode, Id = Index.ChargeCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ChargeCode { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ResourceDescription", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARUnitOfMeasure", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ARUnitOfMeasure, Id = Index.ARUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string ARUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostHM
        /// </summary>
        //[Display(Name = "ExtendedCost", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ExtendedCostHome, Id = Index.ExtendedCostHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCostHome { get; set; }

        /// <summary>
        /// Gets or sets OverheadType
        /// </summary>
        //[Display(Name = "OverheadType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.OverheadType, Id = Index.OverheadType, FieldType = EntityFieldType.Int, Size = 2)]
        public OOHTYPE OverheadType { get; set; }

        /// <summary>
        /// Gets or sets OverheadRate
        /// </summary>
        //[Display(Name = "OverheadRate", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.OverheadRate, Id = Index.OverheadRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OverheadPercentage
        /// </summary>
        //[Display(Name = "OverheadPercentage", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.OverheadPercentage, Id = Index.OverheadPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OverheadPercentage { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmount
        /// </summary>
        //[Display(Name = "OverheadAmount", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.OverheadAmount, Id = Index.OverheadAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmountHM
        /// </summary>
        //[Display(Name = "OverheadAmountHM", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.OverheadAmountHome, Id = Index.OverheadAmountHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmountHome { get; set; }

        /// <summary>
        /// Gets or sets LaborType
        /// </summary>
        //[Display(Name = "LaborType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.LaborType, Id = Index.LaborType, FieldType = EntityFieldType.Int, Size = 2)]
        public short LaborType { get; set; }

        /// <summary>
        /// Gets or sets LaborRate
        /// </summary>
        //[Display(Name = "LaborRate", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.LaborRate, Id = Index.LaborRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LaborRate { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentage
        /// </summary>
        //[Display(Name = "LaborPercentage", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.LaborPercentage, Id = Index.LaborPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LaborPercentage { get; set; }

        /// <summary>
        /// Gets or sets TransactionLaborAmountSource
        /// </summary>
        //[Display(Name = "TransactionLaborAmountSource", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TransactionLaborAmountSource, Id = Index.TransactionLaborAmountSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionLaborAmountSource { get; set; }

        /// <summary>
        /// Gets or sets TransactionLaborAmountFuncti
        /// </summary>
        //[Display(Name = "TransactionLaborAmountFuncti", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TransactionLaborAmountFuncti, Id = Index.TransactionLaborAmountFuncti, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionLaborAmountFuncti { get; set; }

        /// <summary>
        /// Gets or sets TotalCost
        /// </summary>
        //[Display(Name = "TotalCost", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TotalCost, Id = Index.TotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCostHM
        /// </summary>
        //[Display(Name = "TotalCostHM", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TotalCostAmountHome, Id = Index.TotalCostAmountHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostAmountHome { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets CostAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostAccount", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.CostAccount, Id = Index.CostAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CostAccount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "OverheadAccount", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.OverheadAccount, Id = Index.OverheadAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string OverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets LaborAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "LaborAccount", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.LaborAccount, Id = Index.LaborAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string LaborAccount { get; set; }

        /// <summary>
        /// Gets or sets WorkInProgressAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgressAccount", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.WorkInProgressAccount, Id = Index.WorkInProgressAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string WorkInProgressAccount { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets BillingAmount
        /// </summary>
        [Display(Name = "BillingAmount", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.BillingAmount, Id = Index.BillingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BillingAmount { get; set; }

        /// <summary>
        /// Gets or sets BillingAmountHM
        /// </summary>
        [ViewField(Name = Fields.BillingAmountHome, Id = Index.BillingAmountHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BillingAmountHome { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        //[Display(Name = "DetailNumber", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        //[Display(Name = "TaxAuthority1", ResourceType = typeof (CostEntriesDetailResx))]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TaxAuthority2", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TaxAuthority3", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TaxAuthority4", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TaxAuthority5", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription1
        /// </summary>
        [IgnoreExportImport]
        public string TaxAuthorityDescription1 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription2
        /// </summary>
        [IgnoreExportImport]
        public string TaxAuthorityDescription2 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription3
        /// </summary>
        [IgnoreExportImport]
        public string TaxAuthorityDescription3 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription4
        /// </summary>
        [IgnoreExportImport]
        public string TaxAuthorityDescription4 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription5
        /// </summary>
        [IgnoreExportImport]
        public string TaxAuthorityDescription5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        //[Display(Name = "TaxClass1", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        //[Display(Name = "TaxClass2", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        //[Display(Name = "TaxClass3", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        //[Display(Name = "TaxClass4", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        //[Display(Name = "TaxClass5", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription1
        /// </summary>
        [IgnoreExportImport]
        public string TaxClassDescription1 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription2
        /// </summary>
        [IgnoreExportImport]
        public string TaxClassDescription2 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription3
        /// </summary>
        [IgnoreExportImport]
        public string TaxClassDescription3 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription4
        /// </summary>
        [IgnoreExportImport]
        public string TaxClassDescription4 { get; set; }

        /// <summary>
        /// Gets or sets TaxDescription5
        /// </summary>
        [IgnoreExportImport]
        public string TaxClassDescription5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        //[Display(Name = "TaxIncluded1", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        //[Display(Name = "TaxIncluded2", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        //[Display(Name = "TaxIncluded3", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        //[Display(Name = "TaxIncluded4", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        //[Display(Name = "TaxIncluded5", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        //[Display(Name = "ContractStyle", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        //[Display(Name = "ProjectType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Customer", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets RevenueRecType
        /// </summary>
        //[Display(Name = "RevenueRecType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.RevenueRecType, Id = Index.RevenueRecType, FieldType = EntityFieldType.Int, Size = 2)]
        public RevenueRecType RevenueRecType { get; set; }

        /// <summary>
        /// Gets or sets InventoryType
        /// </summary>
        //[Display(Name = "InventoryType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.InventoryType, Id = Index.InventoryType, FieldType = EntityFieldType.Int, Size = 2)]
        public InventoryType InventoryType { get; set; }

        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        //[Display(Name = "VALUES", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets PayType
        /// </summary>
        //[Display(Name = "PayType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.PayType, Id = Index.PayType, FieldType = EntityFieldType.Int, Size = 2)]
        public short PayType { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TransactionDate", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets Expense
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Expense", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.Expense, Id = Index.Expense, FieldType = EntityFieldType.Char, Size = 16)]
        public string Expense { get; set; }

        /// <summary>
        /// Gets or sets ExpenseType
        /// </summary>
        //[Display(Name = "ExpenseType", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.ExpenseType, Id = Index.ExpenseType, FieldType = EntityFieldType.Int, Size = 2)]
        public short ExpenseType { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Location", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ICUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ICUnitOfMeasure", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.ICUnitOfMeasure, Id = Index.ICUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string ICUnitOfMeasure { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONVERSION
        /// </summary>
        //[Display(Name = "CONVERSION", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.Conversion, Id = Index.Conversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Conversion { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        //[Display(Name = "StockItem", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets CostMethod
        /// </summary>
        //[Display(Name = "CostMethod", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.CostMethod, Id = Index.CostMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short CostMethod { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "UnformattedItemNumber", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets GLDetailDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "GLDetailDescription", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.GLDetailDescription, Id = Index.GLDetailDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets GLDetailReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "GLDetailReference", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.GLDetailReference, Id = Index.GLDetailReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLDetailReference { get; set; }

        /// <summary>
        /// Gets or sets GLDetailComment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "GLDetailComment", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.GLDetailComment, Id = Index.GLDetailComment, FieldType = EntityFieldType.Char, Size = 250)]
        public string GLDetailComment { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        //[Display(Name = "Function", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public short Function { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TRANDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostAccountDescription", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.CostAccountDescription, Id = Index.CostAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CostAccountDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets WIPDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgressAccountDescription", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.WorkInProgressAccountDescription, Id = Index.WorkInProgressAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WorkInProgressAccountDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ITEMDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumberDescription", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ARItemDescription, Id = Index.ARItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ARItemDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractDescription", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ContractDescription, Id = Index.ContractDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROJDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectDescription", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.ProjectDescription, Id = Index.ProjectDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ProjectDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CATDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        //[Display(Name = "HASOPT", ResourceType = typeof (CostEntriesDetailResx))]
        [ViewField(Name = Fields.HasOptionalField, Id = Index.HasOptionalField, FieldType = EntityFieldType.Bool, Size = 2)]
        public HASOPT HasOptionalField { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets LineType string value
        /// </summary>
        public string LineTypeString
        {
         get { return EnumUtility.GetStringValue(LineType); }
        }

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString
        {
         get { return EnumUtility.GetStringValue(CostClass); }
        }

        /// <summary>
        /// Gets OverheadType string value
        /// </summary>
        public string OverheadTypeString
        {
         get { return EnumUtility.GetStringValue(OverheadType); }
        }

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString
        {
         get { return EnumUtility.GetStringValue(BillingType); }
        }

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString
        {
         get { return EnumUtility.GetStringValue(ContractStyle); }
        }

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString
        {
         get { return EnumUtility.GetStringValue(ProjectType); }
        }

        /// <summary>
        /// Gets RevenueRecType string value
        /// </summary>
        public string RevenueRecTypeString
        {
         get { return EnumUtility.GetStringValue(RevenueRecType); }
        }

        /// <summary>
        /// Gets InventoryType string value
        /// </summary>
        public string InventoryTypeString
        {
         get { return EnumUtility.GetStringValue(InventoryType); }
        }

        /// <summary>
        /// Gets HASOPT string value
        /// </summary>
        public string HASOPTString
        {
         get { return EnumUtility.GetStringValue(HasOptionalField); }
        }

        #endregion
    }
}
