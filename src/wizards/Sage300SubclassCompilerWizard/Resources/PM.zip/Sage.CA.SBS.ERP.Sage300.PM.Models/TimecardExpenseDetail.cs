// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for TimecardExpenseDetail
    /// </summary>
    public partial class TimecardExpenseDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber)]
        public short LineNumber { get; set; }

        /// <summary>
        /// Gets or sets TimecardNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TimecardNumber", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TimecardNumber, Id = Index.TimecardNumber)]
        public string TimecardNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FMTCONTNO", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO)]
        public string FMTCONTNO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTRACT", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT)]
        public string CONTRACT { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project)]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category)]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpenseCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpenseCode", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.ExpenseCode, Id = Index.ExpenseCode)]
        public string ExpenseCode { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpenseDescription", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.DESC, Id = Index.DESC)]
        public string DESC { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets ExpenseType
        /// </summary>
        [Display(Name = "ExpenseType", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.ExpenseType, Id = Index.ExpenseType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ExpenseType ExpenseType { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber)]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency)]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency)]
        public string BillingCurrency { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets UNITCOST
        /// </summary>
        [Display(Name = "UNITCOST", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.UNITCOST, Id = Index.UNITCOST)]
        public decimal UNITCOST { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTSR
        /// </summary>
        [Display(Name = "EXTCOSTSR", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.EXTCOSTSR, Id = Index.EXTCOSTSR)]
        public decimal EXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTHM
        /// </summary>
        [Display(Name = "EXTCOSTHM", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.EXTCOSTHM, Id = Index.EXTCOSTHM)]
        public decimal EXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTBILLSR
        /// </summary>
        [Display(Name = "EXTBILLSR", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.EXTBILLSR, Id = Index.EXTBILLSR)]
        public decimal EXTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets BILLRATE
        /// </summary>
        [Display(Name = "BILLRATE", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.BILLRATE, Id = Index.BILLRATE)]
        public decimal BILLRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTSR
        /// </summary>
        [Display(Name = "TOTCOSTSR", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TOTCOSTSR, Id = Index.TOTCOSTSR)]
        public decimal TOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTHM
        /// </summary>
        [Display(Name = "TOTCOSTHM", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TOTCOSTHM, Id = Index.TOTCOSTHM)]
        public decimal TOTCOSTHM { get; set; }

        /// <summary>
        /// Gets or sets TotalBillableAmount
        /// </summary>
        [Display(Name = "TotalBillableAmount", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TotalBillableAmount, Id = Index.TotalBillableAmount)]
        public decimal TotalBillableAmount { get; set; }

        /// <summary>
        /// Gets or sets EmployeeExpenseAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeExpenseAccount", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.EmployeeExpenseAccount, Id = Index.EmployeeExpenseAccount)]
        public string EmployeeExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets WorkInProgressAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgressAccount", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.WorkInProgressAccount, Id = Index.WorkInProgressAccount)]
        public string WorkInProgressAccount { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets BillAmountBasedOn
        /// </summary>
        [Display(Name = "BillAmountBasedOn", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.BillAmountBasedOn, Id = Index.BillAmountBasedOn)]
        public short BillAmountBasedOn { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1)]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2)]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3)]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4)]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5)]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1)]
        public short TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2)]
        public short TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3)]
        public short TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4)]
        public short TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5)]
        public short TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        [Display(Name = "ContractStyle", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer)]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.InvoiceType InvoiceType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        [Display(Name = "VALUES", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.VALUES, Id = Index.VALUES)]
        public int VALUES { get; set; }

        /// <summary>
        /// Gets or sets GLDetailDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailDescription", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.GLDetailDescription, Id = Index.GLDetailDescription)]
        public string GLDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets GLDetailReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailReference", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.GLDetailReference, Id = Index.GLDetailReference)]
        public string GLDetailReference { get; set; }

        /// <summary>
        /// Gets or sets GLDetailComment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailComment", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.GLDetailComment, Id = Index.GLDetailComment)]
        public string GLDetailComment { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource)]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CostClass CostClass { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RESDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESDESC", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.RESDESC, Id = Index.RESDESC)]
        public string RESDESC { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXPDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeExpenseDescription", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.EXPDESC, Id = Index.EXPDESC)]
        public string EXPDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets WIPDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WIPDESC", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.WIPDESC, Id = Index.WIPDESC)]
        public string WIPDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ITEMDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ITEMDESC", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.ITEMDESC, Id = Index.ITEMDESC)]
        public string ITEMDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTDESC", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.CONTDESC, Id = Index.CONTDESC)]
        public string CONTDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROJDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PROJDESC", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.PROJDESC, Id = Index.PROJDESC)]
        public string PROJDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CATDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CATDESC", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.CATDESC, Id = Index.CATDESC)]
        public string CATDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        [Display(Name = "HASOPT", ResourceType = typeof (TimecardExpenseDetailResx))]
        [ViewField(Name = Fields.HASOPT, Id = Index.HASOPT)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.HASOPT HASOPT { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ExpenseType string value
        /// </summary>
        public string ExpenseTypeString => EnumUtility.GetStringValue(ExpenseType);

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString => EnumUtility.GetStringValue(BillingType);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString => EnumUtility.GetStringValue(ContractStyle);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString => EnumUtility.GetStringValue(InvoiceType);

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString => EnumUtility.GetStringValue(CostClass);

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString => EnumUtility.GetStringValue(Function);

        /// <summary>
        /// Gets HASOPT string value
        /// </summary>
        public string HASOPTString => EnumUtility.GetStringValue(HASOPT);

        #endregion
    }
}
