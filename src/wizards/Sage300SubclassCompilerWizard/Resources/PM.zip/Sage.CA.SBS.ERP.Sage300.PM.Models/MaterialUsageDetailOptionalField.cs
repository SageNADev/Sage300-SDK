// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for MaterialUsageDetailOptionalField
    /// </summary>
    public partial class MaterialUsageDetailOptionalField : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUE
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VALUE", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALUE, Id = Index.VALUE, FieldType = EntityFieldType.Char, Size = 60)]
        public string VALUE { get; set; }

        /// <summary>
        /// Gets or sets DataType
        /// </summary>
        [Display(Name = "DataType", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.DataType, Id = Index.DataType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.DataType DataType { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public short Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets ValueIndex
        /// </summary>
        [Display(Name = "ValueIndex", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.ValueIndex, Id = Index.ValueIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public int ValueIndex { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFTEXT
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VALIFTEXT", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALIFTEXT, Id = Index.VALIFTEXT, FieldType = EntityFieldType.Char, Size = 60)]
        public string VALIFTEXT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFMONEY
        /// </summary>
        [Display(Name = "VALIFMONEY", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALIFMONEY, Id = Index.VALIFMONEY, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VALIFMONEY { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFNUM
        /// </summary>
        [Display(Name = "VALIFNUM", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALIFNUM, Id = Index.VALIFNUM, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal VALIFNUM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFLONG
        /// </summary>
        [Display(Name = "VALIFLONG", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALIFLONG, Id = Index.VALIFLONG, FieldType = EntityFieldType.Long, Size = 4)]
        public int VALIFLONG { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFBOOL
        /// </summary>
        [Display(Name = "VALIFBOOL", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALIFBOOL, Id = Index.VALIFBOOL, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool VALIFBOOL { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFDATE
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VALIFDATE", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALIFDATE, Id = Index.VALIFDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime VALIFDATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFTIME
        /// </summary>
        [Display(Name = "VALIFTIME", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.VALIFTIME, Id = Index.VALIFTIME, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan VALIFTIME { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (MaterialUsageResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public short Function { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets DataType string value
        /// </summary>
        public string DataTypeString
        {
         get { return EnumUtility.GetStringValue(DataType); }
        }
        /*
        /// <summary>
        /// Gets AllowBlank string value
        /// </summary>
        public string AllowBlankString
        {
         get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets Validate string value
        /// </summary>
        public string ValidateString
        {
         get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// Gets ValueSet string value
        /// </summary>
        public string ValueSetString
        {
         get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        /// Gets VALIFBOOL string value
        /// </summary>
        public string VALIFBOOLString
        {
         get { return EnumUtility.GetStringValue(VALIFBOOL); }
        }
        */
        #endregion
    }
}
