﻿// Copyright (c) 2018 Sage Software, Inc.  All rights reserved.
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum OEMiscellaneousCharges
    {
        /// <summary>
        /// Default Cost From Contract
        /// </summary>
        DefaultCostFromContract, 

        /// <summary>
        /// Default Cost From Misc. Changrs
        /// </summary>
        DefaultCostFromMiscCharges

    }
}
