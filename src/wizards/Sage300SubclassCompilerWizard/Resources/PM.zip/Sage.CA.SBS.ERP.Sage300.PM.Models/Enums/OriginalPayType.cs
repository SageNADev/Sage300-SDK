// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for OriginalPayType
    /// </summary>
    public enum OriginalPayType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(AdjustmentsResx))]
        None = 3,
        /// <summary>
        /// Gets or sets USPayroll
        /// </summary>
        [EnumValue("USPayroll", typeof(AdjustmentsResx))]
        USPayroll = 1,
        /// <summary>
        /// Gets or sets CanadianPayroll
        /// </summary>
        [EnumValue("CanadianPayroll", typeof(AdjustmentsResx))]
        CanadianPayroll = 2
    }
}