// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for RevisedOverheadType
    /// </summary>
    public enum RevisedOverheadType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(AdjustmentsResx))]
        None = 1,
        /// <summary>
        /// Gets or sets FlatRatePerUnit
        /// </summary>
        [EnumValue("FlatRatePerUnit", typeof(AdjustmentsResx))]
        FlatRatePerUnit = 2,
        /// <summary>
        /// Gets or sets PercentageOfCost
        /// </summary>
        [EnumValue("PercentageOfCost", typeof(AdjustmentsResx))]
        PercentageOfCost = 5
    }
}