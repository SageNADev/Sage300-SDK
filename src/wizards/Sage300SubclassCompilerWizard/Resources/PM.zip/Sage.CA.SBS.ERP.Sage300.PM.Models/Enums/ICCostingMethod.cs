// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ICCostingMethod
    /// </summary>
    public enum ICCostingMethod
    {
        /// <summary>
        /// Gets or sets NA
        /// </summary>
        [EnumValue("NA", typeof(AdjustmentsResx))]
        NA = 0,
        /// <summary>
        /// Gets or sets MovingAverage
        /// </summary>
        [EnumValue("MovingAverage", typeof(AdjustmentsResx))]
        MovingAverage = 1,
        /// <summary>
        /// Gets or sets FIFO
        /// </summary>
        [EnumValue("FIFO", typeof(AdjustmentsResx))]
        FIFO = 2,
        /// <summary>
        /// Gets or sets LIFO
        /// </summary>
        [EnumValue("LIFO", typeof(AdjustmentsResx))]
        LIFO = 3,
        /// <summary>
        /// Gets or sets StandardCost
        /// </summary>
        [EnumValue("StandardCost", typeof(AdjustmentsResx))]
        StandardCost = 4,
        /// <summary>
        /// Gets or sets MostRecentCost
        /// </summary>
        [EnumValue("MostRecentCost", typeof(AdjustmentsResx))]
        MostRecentCost = 5,
        /// <summary>
        /// Gets or sets UserSpecified
        /// </summary>
        [EnumValue("UserSpecified", typeof(AdjustmentsResx))]
        UserSpecified = 6
    }
}