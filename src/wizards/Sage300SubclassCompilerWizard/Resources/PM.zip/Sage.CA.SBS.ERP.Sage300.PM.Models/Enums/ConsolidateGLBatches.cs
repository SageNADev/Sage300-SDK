﻿// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum ConsolidateGLBatches
    {
        DoNotConsolidate = 1,
        ConsolidateByAccountAndFiscalPeriod,
        ConsolidateByAccountFiscalPeriodAndSource,
        ConsolidateTransactionDetailsByAccount = 9
    }
}
