// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for RevisedProjectStyle
    /// </summary>
    public enum RevisedProjectStyle
    {
        /// <summary>
        /// Gets or sets Standard
        /// </summary>
        [EnumValue("Standard", typeof(AdjustmentsResx))]
        Standard = 1,
        /// <summary>
        /// Gets or sets Basic
        /// </summary>
        [EnumValue("Basic", typeof(AdjustmentsResx))]
        Basic = 2
    }
}