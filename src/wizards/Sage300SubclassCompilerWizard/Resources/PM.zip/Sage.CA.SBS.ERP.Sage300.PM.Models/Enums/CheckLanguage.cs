// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using ValuedPartner.TU.Resources.Forms;
using ValuedPartner.TU.Models.Enums;

#endregion

namespace ValuedPartner.TU.Models.Enums
{
    /// <summary>
    /// Enum for CheckLanguage
    /// </summary>
    public enum CheckLanguage
    {
        /// <summary>
        /// Gets or sets ENG
        /// </summary>
        [EnumValue("ENG", typeof(CustomerResx))]
        ENG = 1,
        /// <summary>
        /// Gets or sets FRA
        /// </summary>
        [EnumValue("FRA", typeof(CustomerResx))]
        FRA = 2,
        /// <summary>
        /// Gets or sets ESN
        /// </summary>
        [EnumValue("ESN", typeof(CustomerResx))]
        ESN = 3,
        /// <summary>
        /// Gets or sets AUS
        /// </summary>
        [EnumValue("AUS", typeof(CustomerResx))]
        AUS = 4,
        /// <summary>
        /// Gets or sets MEX
        /// </summary>
        [EnumValue("MEX", typeof(CustomerResx))]
        MEX = 5,
        /// <summary>
        /// Gets or sets CHN
        /// </summary>
        [EnumValue("CHN", typeof(CustomerResx))]
        CHN = 6,
        /// <summary>
        /// Gets or sets CHT
        /// </summary>
        [EnumValue("CHT", typeof(CustomerResx))]
        CHT = 7
    }
}