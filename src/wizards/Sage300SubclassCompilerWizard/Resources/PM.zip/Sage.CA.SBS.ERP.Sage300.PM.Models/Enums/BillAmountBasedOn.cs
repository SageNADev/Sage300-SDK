﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum BillAmountBasedOn
    {
        /// <summary>
        /// Invoice this amount
        /// </summary>
        Amount = 1,

        /// <summary>
        /// Invoice based on exchange rate
        /// </summary>
        ExchangeRate,
    }
}
