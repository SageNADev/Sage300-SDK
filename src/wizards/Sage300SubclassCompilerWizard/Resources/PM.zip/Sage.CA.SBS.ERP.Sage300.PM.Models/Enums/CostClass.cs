// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for CostClass
    /// </summary>
    public enum CostClass
    {
        /// <summary>
        /// Gets or sets Labor
        /// </summary>
        [EnumValue("Labor", typeof(CostTypesResx))]
        Labor = 1,
        /// <summary>
        /// Gets or sets Material
        /// </summary>
        [EnumValue("Material", typeof(CostTypesResx))]
        Material = 2,
        /// <summary>
        /// Gets or sets Equipment
        /// </summary>
        [EnumValue("Equipment", typeof(CostTypesResx))]
        Equipment = 3,
        /// <summary>
        /// Gets or sets Subcontractor
        /// </summary>
        [EnumValue("Subcontractor", typeof(CostTypesResx))]
        Subcontractor = 4,
        /// <summary>
        /// Gets or sets Overhead
        /// </summary>
        [EnumValue("Overhead", typeof(CostTypesResx))]
        Overhead = 5,
        /// <summary>
        /// Gets or sets Miscellaneous
        /// </summary>
        [EnumValue("Miscellaneous", typeof(CostTypesResx))]
        Miscellaneous = 6
    }
}