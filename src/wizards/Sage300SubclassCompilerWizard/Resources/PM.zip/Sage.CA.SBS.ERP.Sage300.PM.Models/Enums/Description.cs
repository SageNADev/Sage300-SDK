// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Description
    /// </summary>
    public enum Description
    {
        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [EnumValue("Contract", typeof(BudgetDetailResx))]
        Contract = 1,
        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [EnumValue("Project", typeof(BudgetDetailResx))]
        Project = 2,
        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [EnumValue("Category", typeof(BudgetDetailResx))]
        Category = 3
    }
}