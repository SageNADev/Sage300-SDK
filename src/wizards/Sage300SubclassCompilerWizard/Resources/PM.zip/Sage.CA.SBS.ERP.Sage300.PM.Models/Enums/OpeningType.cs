// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for OpeningType
    /// </summary>
    public enum OpeningType
    {
        /// <summary>
        /// Gets or sets Actuals
        /// </summary>
        [EnumValue("Actuals", typeof(OpeningBalancesDetailResx))]
        Actuals = 1,
        /// <summary>
        /// Gets or sets Activity
        /// </summary>
        [EnumValue("Activity", typeof(OpeningBalancesDetailResx))]
        Activity = 2,
        /// <summary>
        /// Gets or sets Stored
        /// </summary>
        [EnumValue("Stored", typeof(OpeningBalancesDetailResx))]
        Stored = 3
    }
}