// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for RetainageType
    /// </summary>
    public enum RetainageType
    {
        /// <summary>
        /// Gets or sets OpeningRetainageReceivable
        /// </summary>
        [EnumValue("OpeningRetainageReceivable", typeof(UpdateRetainageResx))]
        OpeningRetainageReceivable = 1,
        /// <summary>
        /// Gets or sets OpeningRetainagePayable
        /// </summary>
        [EnumValue("OpeningRetainagePayable", typeof(UpdateRetainageResx))]
        OpeningRetainagePayable = 2,
        /// <summary>
        /// Gets or sets InvoiceRetainageReceivable
        /// </summary>
        [EnumValue("InvoiceRetainageReceivable", typeof(UpdateRetainageResx))]
        InvoiceRetainageReceivable = 3,
        /// <summary>
        /// Gets or sets InvoiceRetainagePayable
        /// </summary>
        [EnumValue("InvoiceRetainagePayable", typeof(UpdateRetainageResx))]
        InvoiceRetainagePayable = 4
    }
}