﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum ContractStatus
    {
        [EnumValue("Estimate", typeof(ContractsResx))]
        Estimate = 10,

        [EnumValue("Approved", typeof(ContractsResx))]
        Approved = 20,

        [EnumValue("Open", typeof(ContractsResx))]
        Open = 30,

        [EnumValue("Onhold", typeof(ContractsResx))]
        Onhold = 40,

        [EnumValue("Inactive", typeof(ContractsResx))]
        Inactive = 70,

        [EnumValue("Completed", typeof(ContractsResx))]
        Completed = 60,

        [EnumValue("Closed", typeof(ContractsResx))]
        Closed = 50
    }

    public enum OptionalFieldValues
    {
        [EnumValue("None", typeof(ContractsResx))]
        None = 0,

        [EnumValue("CopyTemplate", typeof(ContractsResx))]
        CopyFromTemplate = 1,

        [EnumValue("UsePJCDefaults", typeof(ContractsResx))]
        UsePJCDefaults = 2
    }
}
