// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using ValuedPartner.TU.Resources.Forms;
using ValuedPartner.TU.Models.Enums;

#endregion

namespace ValuedPartner.TU.Models.Enums
{
    /// <summary>
    /// Enum for CheckForDuplicatePos
    /// </summary>
    public enum CheckForDuplicatePos
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(CustomerResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Warning
        /// </summary>
        [EnumValue("Warning", typeof(CustomerResx))]
        Warning = 1,
        /// <summary>
        /// Gets or sets Error
        /// </summary>
        [EnumValue("Error", typeof(CustomerResx))]
        Error = 2
    }
}