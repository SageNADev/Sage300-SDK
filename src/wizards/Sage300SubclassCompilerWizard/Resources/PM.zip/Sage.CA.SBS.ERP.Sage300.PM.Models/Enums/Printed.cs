// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Printed
    /// </summary>
    public enum Printed
    {
        /// <summary>
        /// Gets or sets False
        /// </summary>
        [EnumValue("False", typeof(ChargeResx))]
        False = 0,
        /// <summary>
        /// Gets or sets True
        /// </summary>
        [EnumValue("True", typeof(ChargeResx))]
        True = 1
    }
}