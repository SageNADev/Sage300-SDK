﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum RevenueAndCostCurrency
    {
        /// <summary>
        /// Revenue and Costs in Functional Currency
        /// </summary>
        RevAndCostsFunctionalCurrency = 1,

        /// <summary>
        /// Revenue in Customer Currency
        /// </summary>
        RevInCustomerCurrency,

        /// <summary>
        /// Revenue and Costs in Customer Currency
        /// </summary>
        RevAndCostsInCustomerCurrency,
    }
}
