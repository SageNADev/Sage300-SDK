// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using ValuedPartner.TU.Resources.Forms;
using ValuedPartner.TU.Models.Enums;

#endregion

namespace ValuedPartner.TU.Models.Enums
{
    /// <summary>
    /// Enum for PercentageCompleteMethod
    /// </summary>
    public enum PercentageCompleteMethod
    {
        /// <summary>
        /// Gets or sets ClearBillingsAndWIPDuringRevenueRecognition
        /// </summary>
        [EnumValue("ClearBillingsAndWIPDuringRevenueRecognition", typeof(ContractsResx))]
        ClearBillingsAndWIPDuringRevenueRecognition = 1,
        /// <summary>
        /// Gets or sets ClearBillingsAndWIPDuringProjectClose
        /// </summary>
        [EnumValue("ClearBillingsAndWIPDuringProjectClose", typeof(ContractsResx))]
        ClearBillingsAndWIPDuringProjectClose = 0,
        /// <summary>
        /// Gets or sets FromOptions
        /// </summary>
        [EnumValue("FromOptions", typeof(ContractsResx))]
        FromOptions = 2
    }
}