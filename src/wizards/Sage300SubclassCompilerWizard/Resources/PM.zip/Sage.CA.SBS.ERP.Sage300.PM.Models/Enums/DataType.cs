﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum DataType
    {
        Text = 1,
        Date = 3,
        Time = 4,
        Number = 6,
        Integer = 8,
        YesNo= 9,
        Amount = 100
    }
}
