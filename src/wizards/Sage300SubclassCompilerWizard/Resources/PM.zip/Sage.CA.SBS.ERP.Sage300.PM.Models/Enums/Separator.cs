﻿// Copyright (c) 2022 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ProjectType
    /// </summary>
    public enum Separator
    {
        /// <summary>
        /// None
        /// </summary>
        //[EnumValue("None", typeof(ContractStructureResx))]
        None = 1,
        /// <summary>
        /// "-" Hyphen
        /// </summary>
        //[EnumValue("Hyphen", typeof(ContractStructureResx))]
        Hyphen = 2,
        /// <summary>
        /// "/" Forward Slash
        /// </summary>
        //[EnumValue("ForwardSlash", typeof(ContractStructureResx))]
        ForwardSlash = 3,
        /// <summary>
        /// "|" Back Slash
        /// </summary>
        //[EnumValue("BackSlash", typeof(ContractStructureResx))]
        BackSlash = 4,
        /// <summary>
        /// "*" Asterisk
        /// </summary>
        //[EnumValue("Asterisk", typeof(ContractStructureResx))]
        Asterisk = 5,
        /// <summary>
        /// "." Period
        /// </summary>
        //[EnumValue("Period", typeof(ContractStructureResx))]
        Period = 6,
        /// <summary>
        /// "(" Left Parenthesis
        /// </summary>
        //[EnumValue("LeftParenthesis", typeof(ContractStructureResx))]
        LeftParenthesis = 7,
        /// <summary>
        /// ")" Right Parenthesis
        /// </summary>
        //[EnumValue("RightParenthesis", typeof(ContractStructureResx))]
        RightParenthesis = 8,
        /// <summary>
        /// "#" Number Sign
        /// </summary>
        //[EnumValue("NumberSign", typeof(ContractStructureResx))]
        NumberSign = 9
    }
}