// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for OverheadType
    /// </summary>
    public enum OverheadType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(ContractsResx))]
        None = 1,
        /// <summary>
        /// Gets or sets FlatRatePerUnit
        /// </summary>
        [EnumValue("FlatRatePerUnit", typeof(ContractsResx))]
        FlatRatePerUnit = 2,
        /// <summary>
        /// Gets or sets PercentageOfCost
        /// </summary>
        [EnumValue("PercentageOfCost", typeof(ContractsResx))]
        PercentageOfCost = 5
    }
}