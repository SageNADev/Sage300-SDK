/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary> Enum for Account Set </summary>
    public enum AccountType
    {
        /// <summary> WorkInProgress </summary>
        [EnumValue("WorkInProgress", typeof(AccountSetResx))]
        WorkInProgress = 0,

        /// <summary> CostOfSales </summary>
        [EnumValue("CostOfSales", typeof(AccountSetResx))]
        CostOfSales = 1,

        /// <summary> Billings </summary>
        [EnumValue("Billings", typeof(AccountSetResx))]
        Billings = 2,

        /// <summary> Revenue </summary>
        [EnumValue("Revenue", typeof(AccountSetResx))]
        Revenue = 3,

        /// <summary> PayrollExpense </summary>
        [EnumValue("PayrollExpense", typeof(AccountSetResx))]
        PayrollExpense = 4,

        /// <summary> EmployeeExpense </summary>
        [EnumValue("EmployeeExpense", typeof(AccountSetResx))]
        EmployeeExpense = 5,

        /// <summary> Labor </summary>
        [EnumValue("Labor", typeof(AccountSetResx))]
        Labor = 6,

        /// <summary> Overhead </summary>
        [EnumValue("Overhead", typeof(AccountSetResx))]
        Overhead = 7,

        /// <summary> Equipment </summary>
        [EnumValue("Equipment", typeof(AccountSetResx))]
        Equipment = 8,

        /// <summary> Cost </summary>
        [EnumValue("Cost", typeof(AccountSetResx))]
        Cost = 9
    }
}
