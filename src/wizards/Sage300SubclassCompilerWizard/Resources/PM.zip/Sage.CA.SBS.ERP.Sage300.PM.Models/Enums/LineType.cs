// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for LineType
    /// </summary>
    public enum LineType
    {
        /// <summary>
        /// Gets or sets Unknown
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Gets or sets Miscellaneous Cost
        /// </summary>
        MiscellaneousCost = 1,

        /// <summary>
        /// Gets or sets Time
        /// </summary>
        Time = 2,

        /// <summary>
        /// Gets or sets Expense
        /// </summary>
        Expense = 3,

        /// <summary>
        /// Gets or sets Equipment
        /// </summary>
        Equipment = 4,

        /// <summary>
        /// Gets or sets Material Usage
        /// </summary>
        MaterialUsage = 5,

        /// <summary>
        /// Gets or sets Material Return
        /// </summary>
        MaterialReturn = 6,

        /// <summary>
        /// Gets or sets Charge
        /// </summary>
        Charge = 7
    }
}