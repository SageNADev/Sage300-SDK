// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for RevisedBillingType
    /// </summary>
    public enum RevisedBillingType
    {
        /// <summary>
        /// Gets or sets Billable
        /// </summary>
        [EnumValue("Billable", typeof(AdjustmentsResx))]
        Billable = 2,
        /// <summary>
        /// Gets or sets NoCharge
        /// </summary>
        [EnumValue("NoCharge", typeof(AdjustmentsResx))]
        NoCharge = 3,
        /// <summary>
        /// Gets or sets Nonbillable
        /// </summary>
        [EnumValue("Nonbillable", typeof(AdjustmentsResx))]
        Nonbillable = 1
    }
}