﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ContractStyle
    /// </summary>
    public enum ContractStyle
    {
        /// <summary>
        /// Gets or sets Standard
        /// </summary>
        [EnumValue("Standard", typeof(ContractsResx))]
        Standard = 1,
        /// <summary>
        /// Gets or sets Basic
        /// </summary>
        [EnumValue("Basic", typeof(ContractsResx))]
        Basic = 2
    }
}
