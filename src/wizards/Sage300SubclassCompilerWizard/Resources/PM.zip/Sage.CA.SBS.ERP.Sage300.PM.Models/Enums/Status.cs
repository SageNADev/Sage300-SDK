// Copyright (c) 2019 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Gets or sets New
        /// </summary>
        [EnumValue("New", typeof(OpeningBalanceResx))]
        New = 0,
        /// <summary>
        /// Gets or sets Entered
        /// </summary>
        [EnumValue("Entered", typeof(OpeningBalanceResx))]
        Entered = 10,
        /// <summary>
        /// Gets or sets Approved
        /// </summary>
        [EnumValue("Approved", typeof(OpeningBalanceResx))]
        Approved = 30,
        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("Posted", typeof(OpeningBalanceResx))]
        Posted = 40
    }
}