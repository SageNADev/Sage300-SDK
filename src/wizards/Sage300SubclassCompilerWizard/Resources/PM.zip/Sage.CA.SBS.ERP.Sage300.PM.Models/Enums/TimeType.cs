// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for TimeType
    /// </summary>
    public enum TimeType
    {
        /// <summary>
        /// Gets or sets NA
        /// </summary>
        [EnumValue("NA", typeof(AdjustmentsResx))]
        NA = 1,
        /// <summary>
        /// Gets or sets Time
        /// </summary>
        [EnumValue("Time", typeof(AdjustmentsResx))]
        Time = 2,
        /// <summary>
        /// Gets or sets Expense
        /// </summary>
        [EnumValue("Expense", typeof(AdjustmentsResx))]
        Expense = 3
    }
}