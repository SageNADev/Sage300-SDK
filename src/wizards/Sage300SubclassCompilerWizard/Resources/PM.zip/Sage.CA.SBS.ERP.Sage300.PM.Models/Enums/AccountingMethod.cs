﻿// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for AccountingMethod
    /// </summary>
    public enum AccountingMethod
    {
        /// <summary>
        /// Gets or sets CompletedProject
        /// </summary>
        [EnumValue("CompletedProject", typeof(MaterialAllocationDetailResx))]
        CompletedProject = 1,
        /// <summary>
        /// Gets or sets TotalCostPercentageComplete
        /// </summary>
        [EnumValue("TotalCostPercentageComplete", typeof(MaterialAllocationDetailResx))]
        TotalCostPercentageComplete = 2,
        /// <summary>
        /// Gets or sets LaborHoursPercentageComplete
        /// </summary>
        [EnumValue("LaborHoursPercentageComplete", typeof(MaterialAllocationDetailResx))]
        LaborHoursPercentageComplete = 3,
        /// <summary>
        /// Gets or sets BillingsAndCosts
        /// </summary>
        [EnumValue("BillingsAndCosts", typeof(MaterialAllocationDetailResx))]
        BillingsAndCosts = 4,
        /// <summary>
        /// Gets or sets ProjectPercentageComplete
        /// </summary>
        [EnumValue("ProjectPercentageComplete", typeof(MaterialAllocationDetailResx))]
        ProjectPercentageComplete = 5,
        /// <summary>
        /// Gets or sets CategoryPercentageComplete
        /// </summary>
        [EnumValue("CategoryPercentageComplete", typeof(MaterialAllocationDetailResx))]
        CategoryPercentageComplete = 6,
        /// <summary>
        /// Gets or sets AccrualBasis
        /// </summary>
        [EnumValue("AccrualBasis", typeof(MaterialAllocationDetailResx))]
        AccrualBasis = 8
    }
}