// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using ValuedPartner.TU.Resources.Forms;
using ValuedPartner.TU.Models.Enums;

#endregion

namespace ValuedPartner.TU.Models.Enums
{
    /// <summary>
    /// Enum for AdditionalCostAllocationType
    /// </summary>
    public enum AdditionalCostAllocationType
    {
        /// <summary>
        /// Gets or sets Leave
        /// </summary>
        [EnumValue("Leave", typeof(ReceiptHeaderResx))]
        Leave = 1,
        /// <summary>
        /// Gets or sets Prorate
        /// </summary>
        [EnumValue("Prorate", typeof(ReceiptHeaderResx))]
        Prorate = 2
    }
}