// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Inventory Type
    /// </summary>
    public enum InventoryType
    {
        /// <summary>
        /// Gets or sets Unknown
        /// </summary>
        Unknown = 0,
        /// <summary>
        /// Gets or sets Item
        /// </summary>
        Item = 1,
        /// <summary>
        /// Gets or sets Summary
        /// </summary>
        Summary = 2
    }
}