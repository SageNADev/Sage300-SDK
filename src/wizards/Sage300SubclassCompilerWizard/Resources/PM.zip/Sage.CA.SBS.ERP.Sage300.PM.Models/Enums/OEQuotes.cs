// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using ValuedPartner.TU.Resources.Forms;
using ValuedPartner.TU.Models.Enums;

#endregion

namespace ValuedPartner.TU.Models.Enums
{
    /// <summary>
    /// Enum for OEQuotes
    /// </summary>
    public enum OEQuotes
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(CustomerContactSelectionResx))]
        None = 0,
        /// <summary>
        /// Gets or sets X
        /// </summary>
        [EnumValue("X", typeof(CustomerContactSelectionResx))]
        X = 1
    }
}