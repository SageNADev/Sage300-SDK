﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum Legend
    {
        /// <summary>
        /// Project status legend
        /// </summary>
        [EnumValue("Legend", typeof(ProjectsResx))] 
        Legend = 0,

        /// <summary>
        /// Estimate
        /// </summary>
        [EnumValue("Estimate", typeof(ProjectsResx))] 
        Estimate = 10,

        /// <summary>
        /// Approved
        /// </summary>
        [EnumValue("Approved", typeof(ProjectsResx))]
        Approved = 20,

        /// <summary>
        /// Open
        /// </summary>
        [EnumValue("Open", typeof(ProjectsResx))]
        Open = 30,

        /// <summary>
        /// On Hold
        /// </summary>
        [EnumValue("OnHold", typeof(ProjectsResx))]
        OnHold = 40,
        /// <summary>
        /// 
        /// </summary>
        [EnumValue("Inactive", typeof(ProjectsResx))]
        Inactive = 70,
        /// <summary>
        /// Completed
        /// </summary>
        [EnumValue("Completed", typeof(ProjectsResx))]
        Completed = 60,

        /// <summary>
        /// Closed
        /// </summary>
        [EnumValue("Closed", typeof(ProjectsResx))]
        Closed = 50,
    }
}
