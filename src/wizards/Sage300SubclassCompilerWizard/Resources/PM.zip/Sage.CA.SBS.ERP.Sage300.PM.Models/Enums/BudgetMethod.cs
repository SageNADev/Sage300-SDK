// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for BudgetMethod
    /// </summary>
    public enum BudgetMethod
    {
        /// <summary>
        /// Gets or sets Fixed Amount
        /// </summary>
        [EnumValue("FixedAmount", typeof(BudgetLookupResx))]
        FixedAmount = 1,
        /// <summary>
        /// Gets or sets Spread Amount
        /// </summary>
        [EnumValue("SpreadAmount", typeof(BudgetLookupResx))]
        SpreadAmount = 2,
        /// <summary>
        /// Gets or sets Base, Percent Increase
        /// </summary>
        [EnumValue("BasePercentIncrease", typeof(BudgetLookupResx))]
        BasePercentIncrease = 3,
        /// <summary>
        /// Gets or sets Base, Amount Increase
        /// </summary>
        [EnumValue("BaseAmountIncrease", typeof(BudgetLookupResx))]
        BaseAmountIncrease = 4,
        /// <summary>
        /// Gets or sets Copy, As Is
        /// </summary>
        [EnumValue("CopyAsIs", typeof(BudgetLookupResx))]
        CopyAsIs = 5,
        /// <summary>
        /// Gets or sets Copy, Percent Increase
        /// </summary>
        [EnumValue("CopyPercentIncrease", typeof(BudgetLookupResx))]
        CopyPercentIncrease = 6,
        /// <summary>
        /// Gets or sets Copy, Amount Increase
        /// </summary>
        [EnumValue("CopyAmountIncrease", typeof(BudgetLookupResx))]
        CopyAmountIncrease = 7,
        /// <summary>
        /// Gets or sets Copy, Prorated Spread
        /// </summary>
        [EnumValue("CopyProratedSpread", typeof(BudgetLookupResx))]
        CopyProratedSpread = 8
    }
}