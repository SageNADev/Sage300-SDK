﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum ProjectStatus
    {
        [EnumValue("Estimate", typeof(ContractsResx))]
        Estimate = 10,

        [EnumValue("Approved", typeof(ContractsResx))]
        Approved = 20,

        [EnumValue("Open", typeof(ContractsResx))]
        Open = 30,

        [EnumValue("Onhold", typeof(ContractsResx))]
        Onhold = 40,

        [EnumValue("Inactive", typeof(ContractsResx))]
        Inactive = 70,

        [EnumValue("Completed", typeof(ContractsResx))]
        Completed = 60,

        [EnumValue("Closed", typeof(ContractsResx))]
        Closed = 50
    }
}
