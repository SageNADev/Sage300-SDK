// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for OriginalAccountingMethod
    /// </summary>
    public enum OriginalAccountingMethod
    {
        /// <summary>
        /// Gets or sets CompletedProject
        /// </summary>
        [EnumValue("CompletedProject", typeof(AdjustmentsResx))]
        CompletedProject = 1,
        /// <summary>
        /// Gets or sets TotalCostPercentageComplete
        /// </summary>
        [EnumValue("TotalCostPercentageComplete", typeof(AdjustmentsResx))]
        TotalCostPercentageComplete = 2,
        /// <summary>
        /// Gets or sets LaborHoursPercentageComplete
        /// </summary>
        [EnumValue("LaborHoursPercentageComplete", typeof(AdjustmentsResx))]
        LaborHoursPercentageComplete = 3,
        /// <summary>
        /// Gets or sets BillingsAndCosts
        /// </summary>
        [EnumValue("BillingsAndCosts", typeof(AdjustmentsResx))]
        BillingsAndCosts = 4,
        /// <summary>
        /// Gets or sets ProjectPercentageComplete
        /// </summary>
        [EnumValue("ProjectPercentageComplete", typeof(AdjustmentsResx))]
        ProjectPercentageComplete = 5,
        /// <summary>
        /// Gets or sets CategoryPercentageComplete
        /// </summary>
        [EnumValue("CategoryPercentageComplete", typeof(AdjustmentsResx))]
        CategoryPercentageComplete = 6,
        /// <summary>
        /// Gets or sets AccrualBasis
        /// </summary>
        [EnumValue("AccrualBasis", typeof(AdjustmentsResx))]
        AccrualBasis = 8
    }
}