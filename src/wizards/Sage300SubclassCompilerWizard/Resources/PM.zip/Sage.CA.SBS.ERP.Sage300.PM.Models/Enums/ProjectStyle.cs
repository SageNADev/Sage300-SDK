﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum ProjectStyle
    {
        /// <summary>
        /// Standard
        /// </summary>
        Standard = 1,
        
        /// <summary>
        /// Basic
        /// </summary>
        Basic,
    }
}
