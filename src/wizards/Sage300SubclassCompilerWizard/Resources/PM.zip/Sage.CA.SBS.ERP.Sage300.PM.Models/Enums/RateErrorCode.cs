﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum RateErrorCode
    {
        /// <summary>
        /// No Rate Error
        /// </summary>
        NoRateError = 0,

        /// <summary>
        /// Rate Type Is Invalid
        /// </summary>
        RateTypeIsInvalid,

        /// <summary>
        /// Rate Is Zero
        /// </summary>
        RateIsZero,

        /// <summary>
        /// Rate is Outside Spread
        /// </summary>
        RateIsOutSideSpread,

        /// <summary>
        /// No Rate Information Exists
        /// </summary>
        NoRateInformationExists,
    }
}
