// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for CostType
    /// </summary>
    public enum CostType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(OpeningBalancesDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Labor
        /// </summary>
        [EnumValue("Labor", typeof(OpeningBalancesDetailResx))]
        Labor = 1,
        /// <summary>
        /// Gets or sets Material
        /// </summary>
        [EnumValue("Material", typeof(OpeningBalancesDetailResx))]
        Material = 2,
        /// <summary>
        /// Gets or sets Equipment
        /// </summary>
        [EnumValue("Equipment", typeof(OpeningBalancesDetailResx))]
        Equipment = 3,
        /// <summary>
        /// Gets or sets Subcontractor
        /// </summary>
        [EnumValue("Subcontractor", typeof(OpeningBalancesDetailResx))]
        Subcontractor = 4,
        /// <summary>
        /// Gets or sets Overhead
        /// </summary>
        [EnumValue("Overhead", typeof(OpeningBalancesDetailResx))]
        Overhead = 5,
        /// <summary>
        /// Gets or sets Miscellaneous
        /// </summary>
        [EnumValue("Miscellaneous", typeof(OpeningBalancesDetailResx))]
        Miscellaneous = 6
    }
}