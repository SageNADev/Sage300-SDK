// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for LaborType
    /// </summary>
    public enum LaborType
    {
        /// <summary>
        /// Gets or sets Unknown
        /// </summary>
        [EnumValue("Unknown", typeof(OpeningBalancesDetailResx))]
        Unknown = 0,
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(OpeningBalancesDetailResx))]
        None = 1,
        /// <summary>
        /// Gets or sets FlatRatePerLaborHourUnit
        /// </summary>
        [EnumValue("FlatRatePerLaborHourUnit", typeof(OpeningBalancesDetailResx))]
        FlatRatePerLaborHourUnit = 2,
        /// <summary>
        /// Gets or sets PercentageOfLaborCost
        /// </summary>
        [EnumValue("PercentageOfLaborCost", typeof(OpeningBalancesDetailResx))]
        PercentageOfLaborCost = 3
    }
}