﻿// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum GLReferenceFieldNotUsed
    {
        CustomerNumber = 1,
        CustomerName,
        DocumentNumber,
        ContractNumber,
        Project,
        Category,
        ContractProjectCategory,
        TypePostingSeqDocumentNumber,
        Resource,
        PurchaseOrderNumber,
        Description,
        Reference
    }
}
