// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for InvoiceType
    /// </summary>
    public enum InvoiceType
    {
        /// <summary>
        /// Gets or sets Unknown
        /// </summary>
        [EnumValue("Unknown", typeof(OpeningBalancesDetailResx))]
        Unknown = 0,
        /// <summary>
        /// Gets or sets Item
        /// </summary>
        [EnumValue("Item", typeof(OpeningBalancesDetailResx))]
        Item = 1,
        /// <summary>
        /// Gets or sets Summary
        /// </summary>
        [EnumValue("Summary", typeof(OpeningBalancesDetailResx))]
        Summary = 2
    }
}