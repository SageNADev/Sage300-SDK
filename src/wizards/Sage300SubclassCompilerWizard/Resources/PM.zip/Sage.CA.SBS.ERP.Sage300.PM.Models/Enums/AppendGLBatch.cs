﻿// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum AppendGLBatch
    {
        CreatingANewBatch,
        AddingToAnExistingBatch,
        CreatingAndPostingANewBatch
    }
}
