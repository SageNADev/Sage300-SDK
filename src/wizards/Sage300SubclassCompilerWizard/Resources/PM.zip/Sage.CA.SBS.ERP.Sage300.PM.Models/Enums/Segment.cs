﻿// Copyright (c) 2022 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ProjectType
    /// </summary>
    public enum Segment
    {
        /// <summary>
        /// Sector
        /// </summary>
        //[EnumValue("Sector", typeof(ContractStructureResx))]
        Sector = 1,
        /// <summary>
        /// Product
        /// </summary>
        //[EnumValue("Product", typeof(ContractStructureResx))]
        Product = 2,
        /// <summary>
        /// Type
        /// </summary>
        //[EnumValue("Type", typeof(ContractStructureResx))]
        Type = 3
    }
}