// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using ValuedPartner.TU.Resources.Forms;
using ValuedPartner.TU.Models.Enums;

#endregion

namespace ValuedPartner.TU.Models.Enums
{
    /// <summary>
    /// Enum for DeliveryMethod
    /// </summary>
    public enum DeliveryMethod
    {
        /// <summary>
        /// Gets or sets Mail
        /// </summary>
        [EnumValue("Mail", typeof(CustomerResx))]
        Mail = 0,
        /// <summary>
        /// Gets or sets EmailCustomer
        /// </summary>
        [EnumValue("EmailCustomer", typeof(CustomerResx))]
        EmailCustomer = 2,
        /// <summary>
        /// Gets or sets EmailContact
        /// </summary>
        [EnumValue("EmailContact", typeof(CustomerResx))]
        EmailContact = 4,
        /// <summary>
        /// Gets or sets EmailMultipleContacts
        /// </summary>
        [EnumValue("EmailMultipleContacts", typeof(CustomerResx))]
        EmailMultipleContacts = 5
    }
}