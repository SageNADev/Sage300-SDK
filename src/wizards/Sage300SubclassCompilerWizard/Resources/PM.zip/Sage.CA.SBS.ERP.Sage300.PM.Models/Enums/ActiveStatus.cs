// Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Status when it is Active/Inactive
    /// </summary>
    public enum ActiveStatus
    {
        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("Active", typeof(CostTypesResx))]
        Active = 0,
        /// <summary>
        /// Gets or sets Inactive
        /// </summary>
        [EnumValue("Inactive", typeof(CostTypesResx))]
        Inactive = 1
    }
}