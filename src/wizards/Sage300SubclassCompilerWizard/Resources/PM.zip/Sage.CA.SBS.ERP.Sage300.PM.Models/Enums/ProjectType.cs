﻿// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ProjectType
    /// </summary>
    public enum ProjectType
    {
        /// <summary>
        /// Gets or sets TimeAndMaterials
        /// </summary>
        [EnumValue("TimeAndMaterials", typeof(MaterialAllocationDetailResx))]
        TimeAndMaterials = 1,
        /// <summary>
        /// Gets or sets FixedPrice
        /// </summary>
        [EnumValue("FixedPrice", typeof(MaterialAllocationDetailResx))]
        FixedPrice = 2,
        /// <summary>
        /// Gets or sets CostPlus
        /// </summary>
        [EnumValue("CostPlus", typeof(MaterialAllocationDetailResx))]
        CostPlus = 3
    }
}