// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for AdjustmentType
    /// </summary>
    public enum AdjustmentType
    {
        /// <summary>
        /// Gets or sets Transfer
        /// </summary>
        [EnumValue("Transfer", typeof(AdjustmentsResx))]
        Transfer = 0,
        /// <summary>
        /// Gets or sets Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof(AdjustmentsResx))]
        Adjustment = 1
    }
}