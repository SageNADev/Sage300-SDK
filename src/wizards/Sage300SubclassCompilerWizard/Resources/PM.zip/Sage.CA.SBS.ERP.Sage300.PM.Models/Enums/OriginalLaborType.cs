// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for OriginalLaborType
    /// </summary>
    public enum OriginalLaborType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(AdjustmentsResx))]
        None = 1,
        /// <summary>
        /// Gets or sets FlatRatePerLaborHourUnit
        /// </summary>
        [EnumValue("FlatRatePerLaborHourUnit", typeof(AdjustmentsResx))]
        FlatRatePerLaborHourUnit = 2,
        /// <summary>
        /// Gets or sets PercentageOfLaborCost
        /// </summary>
        [EnumValue("PercentageOfLaborCost", typeof(AdjustmentsResx))]
        PercentageOfLaborCost = 3
    }
}