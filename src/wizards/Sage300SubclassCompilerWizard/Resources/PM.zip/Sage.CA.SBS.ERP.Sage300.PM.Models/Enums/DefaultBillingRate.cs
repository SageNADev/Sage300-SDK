﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum DefaultBillingRate
    {
        /// <summary>
        /// Biliing Rate
        /// </summary>
        BillingRate = 1,

        /// <summary>
        /// Use Customer Price List
        /// </summary>
        UseCustomerPriceList,

        /// <summary>
        /// Use Specified Price List
        /// </summary>
        UseSpecifiedPriceList,
    }
}
