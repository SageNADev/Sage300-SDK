// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for CBILLTYPE
    /// </summary>
    public enum CBILLTYPE
    {
        /// <summary>
        /// Gets or sets Billable
        /// </summary>
        [EnumValue("Billable", typeof(ReviseEstimatesDetailResx))]
        Billable = 2,
        /// <summary>
        /// Gets or sets NoCharge
        /// </summary>
        [EnumValue("NoCharge", typeof(ReviseEstimatesDetailResx))]
        NoCharge = 3,
        /// <summary>
        /// Gets or sets Nonbillable
        /// </summary>
        [EnumValue("Nonbillable", typeof(ReviseEstimatesDetailResx))]
        Nonbillable = 1
    }
}