// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ActualType
    /// </summary>
    public enum ActualType
    {
        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [EnumValue("Cost", typeof(OpeningBalancesDetailResx))]
        Cost = 1,
        /// <summary>
        /// Gets or sets Revenue
        /// </summary>
        [EnumValue("Revenue", typeof(OpeningBalancesDetailResx))]
        Revenue = 2
    }
}