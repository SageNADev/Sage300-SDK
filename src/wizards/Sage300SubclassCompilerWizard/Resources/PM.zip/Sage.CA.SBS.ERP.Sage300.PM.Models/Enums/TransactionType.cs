// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("Posted", typeof(AdjustmentsResx))]
        Posted = 1,
        /// <summary>
        /// Gets or sets Discount
        /// </summary>
        [EnumValue("Discount", typeof(AdjustmentsResx))]
        Discount = 2,
        /// <summary>
        /// Gets or sets Writeoff
        /// </summary>
        [EnumValue("Writeoff", typeof(AdjustmentsResx))]
        Writeoff = 3,
        /// <summary>
        /// Gets or sets ApplyFrom
        /// </summary>
        [EnumValue("ApplyFrom", typeof(AdjustmentsResx))]
        ApplyFrom = 4,
        /// <summary>
        /// Gets or sets ApplyTo
        /// </summary>
        [EnumValue("ApplyTo", typeof(AdjustmentsResx))]
        ApplyTo = 5,
        /// <summary>
        /// Gets or sets PaymentReceiptReversal
        /// </summary>
        [EnumValue("PaymentReceiptReversal", typeof(AdjustmentsResx))]
        PaymentReceiptReversal = 6,
        /// <summary>
        /// Gets or sets RoundingMulticurrency
        /// </summary>
        [EnumValue("RoundingMulticurrency", typeof(AdjustmentsResx))]
        RoundingMulticurrency = 7,
        /// <summary>
        /// Gets or sets ExchangeGainLoss
        /// </summary>
        [EnumValue("ExchangeGainLoss", typeof(AdjustmentsResx))]
        ExchangeGainLoss = 8,
        /// <summary>
        /// Gets or sets UnrealizedExchangeGainLoss
        /// </summary>
        [EnumValue("UnrealizedExchangeGainLoss", typeof(AdjustmentsResx))]
        UnrealizedExchangeGainLoss = 9,
        /// <summary>
        /// Gets or sets Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof(AdjustmentsResx))]
        Adjustment = 10,
        /// <summary>
        /// Gets or sets ReceiptPayment
        /// </summary>
        [EnumValue("ReceiptPayment", typeof(AdjustmentsResx))]
        ReceiptPayment = 11
    }
}