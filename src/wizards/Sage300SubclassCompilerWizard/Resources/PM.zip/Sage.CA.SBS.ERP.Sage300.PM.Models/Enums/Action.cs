// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Action
    /// </summary>
    public enum Action
    {
        /// <summary>
        /// Gets or sets AddNew
        /// </summary>
        [EnumValue("AddNew", typeof(ReviseEstimatesDetailResx))]
        AddNew = 1,
        /// <summary>
        /// Gets or sets ModifyExisting
        /// </summary>
        [EnumValue("ModifyExisting", typeof(ReviseEstimatesDetailResx))]
        ModifyExisting = 2
    }
}