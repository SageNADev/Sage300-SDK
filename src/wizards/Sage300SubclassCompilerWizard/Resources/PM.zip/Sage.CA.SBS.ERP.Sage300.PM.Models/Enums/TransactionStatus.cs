// Copyright (c) 2019 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for TransactionStatus
    /// </summary>
    public enum TransactionStatus
    {
        /// <summary>
        /// Gets or sets Entered
        /// </summary>
        [EnumValue("Entered", typeof(OpeningBalanceResx))]
        Entered = 1,
        /// <summary>
        /// Gets or sets Imported
        /// </summary>
        [EnumValue("Imported", typeof(OpeningBalanceResx))]
        Imported = 2,
        /// <summary>
        /// Gets or sets Generated
        /// </summary>
        [EnumValue("Generated", typeof(OpeningBalanceResx))]
        Generated = 3,
        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("Posted", typeof(OpeningBalanceResx))]
        Posted = 4
    }
}