// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for OriginalProjectStyle
    /// </summary>
    public enum OriginalProjectStyle
    {
        /// <summary>
        /// Gets or sets Standard
        /// </summary>
        [EnumValue("Standard", typeof(AdjustmentsResx))]
        Standard = 1,
        /// <summary>
        /// Gets or sets Basic
        /// </summary>
        [EnumValue("Basic", typeof(AdjustmentsResx))]
        Basic = 2
    }
}