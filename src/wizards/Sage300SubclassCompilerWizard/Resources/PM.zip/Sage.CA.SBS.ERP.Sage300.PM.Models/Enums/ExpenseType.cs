// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ExpenseType
    /// </summary>
    public enum ExpenseType
    {
        /// <summary>
        /// Gets or sets Airfares
        /// </summary>
        [EnumValue("Airfares", typeof(TimecardExpenseDetailResx))]
        Airfares = 1,
        /// <summary>
        /// Gets or sets Accommodation
        /// </summary>
        [EnumValue("Accommodation", typeof(TimecardExpenseDetailResx))]
        Accommodation = 2,
        /// <summary>
        /// Gets or sets Meals
        /// </summary>
        [EnumValue("Meals", typeof(TimecardExpenseDetailResx))]
        Meals = 3,
        /// <summary>
        /// Gets or sets Entertainment
        /// </summary>
        [EnumValue("Entertainment", typeof(TimecardExpenseDetailResx))]
        Entertainment = 4,
        /// <summary>
        /// Gets or sets TaxiHireCar
        /// </summary>
        [EnumValue("TaxiHireCar", typeof(TimecardExpenseDetailResx))]
        TaxiHireCar = 5,
        /// <summary>
        /// Gets or sets Tolls
        /// </summary>
        [EnumValue("Tolls", typeof(TimecardExpenseDetailResx))]
        Tolls = 6,
        /// <summary>
        /// Gets or sets Telephone
        /// </summary>
        [EnumValue("Telephone", typeof(TimecardExpenseDetailResx))]
        Telephone = 7,
        /// <summary>
        /// Gets or sets Parking
        /// </summary>
        [EnumValue("Parking", typeof(TimecardExpenseDetailResx))]
        Parking = 8,
        /// <summary>
        /// Gets or sets Other
        /// </summary>
        [EnumValue("Other", typeof(TimecardExpenseDetailResx))]
        Other = 9
    }
}