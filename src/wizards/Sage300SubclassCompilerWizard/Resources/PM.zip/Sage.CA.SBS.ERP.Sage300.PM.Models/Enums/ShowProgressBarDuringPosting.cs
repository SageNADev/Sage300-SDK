// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for ShowProgressBarDuringPosting
    /// </summary>
    public enum ShowProgressBarDuringPosting
    {
        /// <summary>
        /// Gets or sets NoMeter
        /// </summary>
        [EnumValue("NoMeter", typeof(MaterialAllocationResx))]
        NoMeter = 0,
        /// <summary>
        /// Gets or sets Meter
        /// </summary>
        [EnumValue("Meter", typeof(MaterialAllocationResx))]
        Meter = 1,
        /// <summary>
        /// Gets or sets MeterButNoCancelButton
        /// </summary>
        [EnumValue("MeterButNoCancelButton", typeof(MaterialAllocationResx))]
        MeterButNoCancelButton = 2
    }
}