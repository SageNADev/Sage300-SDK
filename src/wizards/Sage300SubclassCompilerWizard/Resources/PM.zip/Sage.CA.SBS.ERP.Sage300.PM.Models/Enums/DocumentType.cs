// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType
    /// </summary>
    public enum DocumentType
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(AdjustmentsResx))]
        None = 0,
        /// <summary>
        /// Gets or sets MaterialUsage
        /// </summary>
        [EnumValue("MaterialUsage", typeof(AdjustmentsResx))]
        MaterialUsage = 7,
        /// <summary>
        /// Gets or sets MaterialReturn
        /// </summary>
        [EnumValue("MaterialReturn", typeof(AdjustmentsResx))]
        MaterialReturn = 8,
        /// <summary>
        /// Gets or sets EquipmentUsage
        /// </summary>
        [EnumValue("EquipmentUsage", typeof(AdjustmentsResx))]
        EquipmentUsage = 9,
        /// <summary>
        /// Gets or sets Timecard
        /// </summary>
        [EnumValue("Timecard", typeof(AdjustmentsResx))]
        Timecard = 10,
        /// <summary>
        /// Gets or sets Charges
        /// </summary>
        [EnumValue("Charges", typeof(AdjustmentsResx))]
        Charges = 11,
        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [EnumValue("Cost", typeof(AdjustmentsResx))]
        Cost = 24
    }
}