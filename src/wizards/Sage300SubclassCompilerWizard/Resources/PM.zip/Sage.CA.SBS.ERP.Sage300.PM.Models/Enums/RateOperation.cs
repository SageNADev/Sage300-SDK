// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for RateOperation
    /// </summary>
    public enum RateOperation
    {
        /// <summary>
        /// Gets or sets Multiply
        /// </summary>
        [EnumValue("Multiply", typeof(OpeningBalancesDetailResx))]
        Multiply = 1,
        /// <summary>
        /// Gets or sets Divide
        /// </summary>
        [EnumValue("Divide", typeof(OpeningBalancesDetailResx))]
        Divide = 2
    }
}