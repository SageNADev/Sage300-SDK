// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for PrintStatus
    /// </summary>
    public enum PrintStatus
    {
        /// <summary>
        /// Gets or sets False
        /// </summary>
        [EnumValue("False", typeof(MaterialAllocationResx))]
        False = 0,
        /// <summary>
        /// Gets or sets True
        /// </summary>
        [EnumValue("True", typeof(MaterialAllocationResx))]
        True = 1
    }
}