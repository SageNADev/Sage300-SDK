﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum RevenueType
    {
        /// <summary>
        /// Revenue
        /// </summary>
        Revenue,

        /// <summary>
        /// Deferred Revenue
        /// </summary>
        DeferredRevenue,
    }
}
