﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum Search
    {
        [EnumValue("Project", typeof(ContractsResx))]
        Project = 0,

        [EnumValue("Category", typeof(ContractsResx))]
        Category = 1
    }
}
