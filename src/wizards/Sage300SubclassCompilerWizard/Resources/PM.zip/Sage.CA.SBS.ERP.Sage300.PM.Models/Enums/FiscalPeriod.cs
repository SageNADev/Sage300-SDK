// Copyright (c) 2019 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for FiscalPeriod
    /// </summary>
    public enum FiscalPeriod
    {
        /// <summary>
        /// Gets or sets Num1
        /// </summary>
        [EnumValue("Num1", typeof(MaterialUsageResx))]
        Num1 = 1,
        /// <summary>
        /// Gets or sets Num2
        /// </summary>
        [EnumValue("Num2", typeof(MaterialUsageResx))]
        Num2 = 2,
        /// <summary>
        /// Gets or sets Num3
        /// </summary>
        [EnumValue("Num3", typeof(MaterialUsageResx))]
        Num3 = 3,
        /// <summary>
        /// Gets or sets Num4
        /// </summary>
        [EnumValue("Num4", typeof(MaterialUsageResx))]
        Num4 = 4,
        /// <summary>
        /// Gets or sets Num5
        /// </summary>
        [EnumValue("Num5", typeof(MaterialUsageResx))]
        Num5 = 5,
        /// <summary>
        /// Gets or sets Num6
        /// </summary>
        [EnumValue("Num6", typeof(MaterialUsageResx))]
        Num6 = 6,
        /// <summary>
        /// Gets or sets Num7
        /// </summary>
        [EnumValue("Num7", typeof(MaterialUsageResx))]
        Num7 = 7,
        /// <summary>
        /// Gets or sets Num8
        /// </summary>
        [EnumValue("Num8", typeof(MaterialUsageResx))]
        Num8 = 8,
        /// <summary>
        /// Gets or sets Num9
        /// </summary>
        [EnumValue("Num9", typeof(MaterialUsageResx))]
        Num9 = 9,
        /// <summary>
        /// Gets or sets Num10
        /// </summary>
        [EnumValue("Num10", typeof(MaterialUsageResx))]
        Num10 = 10,
        /// <summary>
        /// Gets or sets Num11
        /// </summary>
        [EnumValue("Num11", typeof(MaterialUsageResx))]
        Num11 = 11,
        /// <summary>
        /// Gets or sets Num12
        /// </summary>
        [EnumValue("Num12", typeof(MaterialUsageResx))]
        Num12 = 12,
        /// <summary>
        /// Gets or sets Num13
        /// </summary>
        [EnumValue("Num13", typeof(MaterialUsageResx))]
        Num13 = 13
    }
}