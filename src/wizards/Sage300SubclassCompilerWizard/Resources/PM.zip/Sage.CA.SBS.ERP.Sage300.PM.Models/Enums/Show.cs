// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Show
    /// </summary>
    public enum Show
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(BudgetDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Original
        /// </summary>
        [EnumValue("Original", typeof(BudgetDetailResx))]
        Original = 1,
        /// <summary>
        /// Gets or sets Current
        /// </summary>
        [EnumValue("Current", typeof(BudgetDetailResx))]
        Current = 2,
        /// <summary>
        /// Gets or sets Actual
        /// </summary>
        [EnumValue("Actual", typeof(BudgetDetailResx))]
        Actual = 3
    }
}