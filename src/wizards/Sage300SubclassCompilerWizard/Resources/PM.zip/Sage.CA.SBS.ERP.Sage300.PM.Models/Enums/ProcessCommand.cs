﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum ProcessCommand
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,

        /// <summary>
        /// AutoGenerateSerials
        /// </summary>
        AutoGenerateSerials = 21,

        /// <summary>
        /// AutoGenerateLots
        /// </summary>
        AutoGenerateLots,

        /// <summary>
        /// AutoAllocateSerials
        /// </summary>
        AutoAllocateSerials,

        /// <summary>
        /// AutoAllocateLots
        /// </summary>
        AutoAllocateLots,

        /// <summary>
        /// ClearSerials
        /// </summary>
        ClearSerials,

        /// <summary>
        /// ClearLots
        /// </summary>
        ClearLots,
    }
}
