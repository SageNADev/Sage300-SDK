// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using ValuedPartner.TU.Resources.Forms;
using ValuedPartner.TU.Models.Enums;

#endregion

namespace ValuedPartner.TU.Models.Enums
{
    /// <summary>
    /// Enum for Mode
    /// </summary>
    public enum Mode
    {
        /// <summary>
        /// Gets or sets NormalMode
        /// </summary>
        [EnumValue("NormalMode", typeof(CustomerResx))]
        NormalMode = 0,
        /// <summary>
        /// Gets or sets UnconditionalInsertsUpdates
        /// </summary>
        [EnumValue("UnconditionalInsertsUpdates", typeof(CustomerResx))]
        UnconditionalInsertsUpdates = 1
    }
}