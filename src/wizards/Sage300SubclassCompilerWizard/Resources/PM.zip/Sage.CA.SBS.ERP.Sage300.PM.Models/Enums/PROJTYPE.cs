// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for PROJTYPE
    /// </summary>
    public enum PROJTYPE
    {
        /// <summary>
        /// Gets or sets TimeAndMaterials
        /// </summary>
        [EnumValue("TimeAndMaterials", typeof(ContractsResx))]
        TimeAndMaterials = 1,
        /// <summary>
        /// Gets or sets FixedPrice
        /// </summary>
        [EnumValue("FixedPrice", typeof(ContractsResx))]
        FixedPrice = 2,
        /// <summary>
        /// Gets or sets CostPlus
        /// </summary>
        [EnumValue("CostPlus", typeof(ContractsResx))]
        CostPlus = 3
    }
}