// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for CostOrRevenue
    /// </summary>
    public enum CostOrRevenue
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(AdjustmentsResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [EnumValue("Cost", typeof(AdjustmentsResx))]
        Cost = 1,
        /// <summary>
        /// Gets or sets Revenue
        /// </summary>
        [EnumValue("Revenue", typeof(AdjustmentsResx))]
        Revenue = 2,
        /// <summary>
        /// Gets or sets Both
        /// </summary>
        [EnumValue("Both", typeof(AdjustmentsResx))]
        Both = 3
    }
}