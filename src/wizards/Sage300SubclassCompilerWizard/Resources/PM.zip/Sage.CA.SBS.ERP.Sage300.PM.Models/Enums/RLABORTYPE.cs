// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for RLABORTYPE
    /// </summary>
    public enum RLABORTYPE
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(ReviseEstimatesDetailResx))]
        None = 1,
        /// <summary>
        /// Gets or sets FlatRatePerLaborHourUnit
        /// </summary>
        [EnumValue("FlatRatePerLaborHourUnit", typeof(ReviseEstimatesDetailResx))]
        FlatRatePerLaborHourUnit = 2,
        /// <summary>
        /// Gets or sets PercentageOfLaborCost
        /// </summary>
        [EnumValue("PercentageOfLaborCost", typeof(ReviseEstimatesDetailResx))]
        PercentageOfLaborCost = 3
    }
}