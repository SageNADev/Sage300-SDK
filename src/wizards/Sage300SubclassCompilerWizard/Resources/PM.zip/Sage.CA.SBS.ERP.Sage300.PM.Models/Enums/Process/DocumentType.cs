// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Process
{
    /// <summary>
    /// Enum for DocumentType
    /// </summary>
    public enum DocumentType
    {
        /// <summary>
        /// Gets or sets MaterialUsage
        /// </summary>
        [EnumValue("MaterialUsage", typeof(TransactionPostingResx))]
        MaterialUsage = 1,
        /// <summary>
        /// Gets or sets MaterialReturn
        /// </summary>
        [EnumValue("MaterialReturn", typeof(TransactionPostingResx))]
        MaterialReturn = 2,
        /// <summary>
        /// Gets or sets Timecard
        /// </summary>
        [EnumValue("Timecard", typeof(TransactionPostingResx))]
        Timecard = 3,
        /// <summary>
        /// Gets or sets EquipmentUsage
        /// </summary>
        [EnumValue("EquipmentUsage", typeof(TransactionPostingResx))]
        EquipmentUsage = 4,
        /// <summary>
        /// Gets or sets Charge
        /// </summary>
        [EnumValue("Charge", typeof(TransactionPostingResx))]
        Charge = 5,
        /// <summary>
        /// Gets or sets ReviseEstimate
        /// </summary>
        [EnumValue("ReviseEstimate", typeof(TransactionPostingResx))]
        ReviseEstimate = 6,
        /// <summary>
        /// Gets or sets Costs
        /// </summary>
        [EnumValue("Costs", typeof(TransactionPostingResx))]
        Costs = 7,
        /// <summary>
        /// Gets or sets MaterialAllocation
        /// </summary>
        [EnumValue("MaterialAllocation", typeof(TransactionPostingResx))]
        MaterialAllocation = 8
    }
}