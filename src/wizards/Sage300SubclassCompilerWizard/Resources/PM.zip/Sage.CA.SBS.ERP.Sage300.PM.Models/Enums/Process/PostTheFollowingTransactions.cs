// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Process
{
    /// <summary>
    /// Enum for PostTheFollowingTransactions
    /// </summary>
    public enum PostTheFollowingTransactions
    {
        /// <summary>
        /// Gets or sets AllTransactions
        /// </summary>
        [EnumValue("AllTransactions", typeof(TransactionPostingResx))]
        AllTransactions = 1,
        /// <summary>
        /// Gets or sets Range
        /// </summary>
        [EnumValue("Range", typeof(TransactionPostingResx))]
        Range = 2,
    }
}