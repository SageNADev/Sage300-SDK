// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for RATEERR
    /// </summary>
    public enum RATEERR
    {
        /// <summary>
        /// Gets or sets NoRateError
        /// </summary>
        [EnumValue("NoRateError", typeof(ReviseEstimatesDetailResx))]
        NoRateError = 0,
        /// <summary>
        /// Gets or sets RateTypeIsInvalid
        /// </summary>
        [EnumValue("RateTypeIsInvalid", typeof(ReviseEstimatesDetailResx))]
        RateTypeIsInvalid = 1,
        /// <summary>
        /// Gets or sets RateIsZero
        /// </summary>
        [EnumValue("RateIsZero", typeof(ReviseEstimatesDetailResx))]
        RateIsZero = 2,
        /// <summary>
        /// Gets or sets RateIsOutsideSpread
        /// </summary>
        [EnumValue("RateIsOutsideSpread", typeof(ReviseEstimatesDetailResx))]
        RateIsOutsideSpread = 3,
        /// <summary>
        /// Gets or sets NoRateInformationExists
        /// </summary>
        [EnumValue("NoRateInformationExists", typeof(ReviseEstimatesDetailResx))]
        NoRateInformationExists = 4
    }
}