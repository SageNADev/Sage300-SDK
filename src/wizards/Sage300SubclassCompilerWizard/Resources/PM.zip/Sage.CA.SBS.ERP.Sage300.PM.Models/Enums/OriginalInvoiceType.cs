// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for OriginalInvoiceType
    /// </summary>
    public enum OriginalInvoiceType
    {
        /// <summary>
        /// Gets or sets Item
        /// </summary>
        [EnumValue("Item", typeof(AdjustmentsResx))]
        Item = 1,
        /// <summary>
        /// Gets or sets Summary
        /// </summary>
        [EnumValue("Summary", typeof(AdjustmentsResx))]
        Summary = 2
    }
}