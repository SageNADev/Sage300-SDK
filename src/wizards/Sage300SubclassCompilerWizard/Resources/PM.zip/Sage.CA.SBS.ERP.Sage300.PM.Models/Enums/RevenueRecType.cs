﻿// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.
#region Namespaces

#endregion


namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum RevenueRecType
    {
        /// <summary>
        /// Gets or sets Unknown
        /// </summary>
        Unknown = 0,

        /// <summary>
        /// Gets or sets Completed Project
        /// </summary>
        CompletedProject = 1,

        /// <summary>
        /// Gets or sets Total Cost Percentage Complete
        /// </summary>
        TotalCostPercentageComplete = 2,

        /// <summary>
        /// Gets or sets Labor Hours Percentage Complete
        /// </summary>
        LaborHoursPercentageComplete = 3,

        /// <summary>
        /// Gets or sets Billings and Costs
        /// </summary>
        BillingsAndCosts = 4,

        /// <summary>
        /// Gets or sets Project Percentage Complete
        /// </summary>
        ProjectPercentageComplete = 5,

        /// <summary>
        /// Gets or sets Category Percentage Complete
        /// </summary>
        CategoryPercentageComplete = 6,

        /// <summary>
        /// Gets or sets Accrual-Basis
        /// </summary>
        AccrualBasis = 8
    }
}
