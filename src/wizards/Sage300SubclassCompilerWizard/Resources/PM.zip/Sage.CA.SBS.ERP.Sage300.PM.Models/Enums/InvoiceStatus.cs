﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    public enum InvoiceStatus
    {
        /// <summary>
        /// Not Processed
        /// </summary>
        NotProcessed = 1,

        /// <summary>
        /// On Worksheet
        /// </summary>
        OnWorksheet,

        /// <summary>
        /// On Invoice
        /// </summary>
        OnInvoice,
    }
}
