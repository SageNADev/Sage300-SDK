// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for Type
    /// </summary>
    public enum Type
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(ReviseEstimatesDetailResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [EnumValue("Project", typeof(ReviseEstimatesDetailResx))]
        Project = 1,
        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [EnumValue("Category", typeof(ReviseEstimatesDetailResx))]
        Category = 2,
        /// <summary>
        /// Gets or sets ResourceCategory
        /// </summary>
        [EnumValue("ResourceCategory", typeof(ReviseEstimatesDetailResx))]
        ResourceCategory = 3
    }
}