// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Enums
{
    /// <summary>
    /// Enum for VendorExists
    /// </summary>
    public enum TransactionModule
    {
        [EnumValue("All", typeof(PMCommonResx))]
        All = 0,

        [EnumValue("PM", typeof(PMCommonResx))]
        PM = 1,

        [EnumValue("AP", typeof(PMCommonResx))]
        AP = 2,

        [EnumValue("AR", typeof(PMCommonResx))]
        AR= 3,

        [EnumValue("PO", typeof(PMCommonResx))]
        PO = 4,

        [EnumValue("OE", typeof(PMCommonResx))]
        OE = 5,

        [EnumValue("CP", typeof(PMCommonResx))]
        CP = 6,

        [EnumValue("UP", typeof(PMCommonResx))]
        UP = 7,
    }
}