// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Web;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PM.Models;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Web.Models
{
    /// <summary>
    /// Class for ContractsViewModel
    /// </summary>
    public class ContractMaintenanceViewModel : ViewModelBase<Contracts>
    {
        /// <summary>
        /// Show contracts detail screen in iFrame
        /// </summary>
        public bool ForDetail = false;
        /// <summary>
        /// GetContractStatus
        /// </summary>
        public IEnumerable<CustomSelectList> GetContractStatus => EnumUtility.GetItemsList<ContractStatus>();

        /// <summary>
        /// GetContractStyle
        /// </summary>
        public IEnumerable<CustomSelectList> GetContractStyle => EnumUtility.GetItemsList<ContractStyle>();

        /// <summary>
        /// GetAccountingMethod
        /// </summary>
        public IEnumerable<CustomSelectList> GetAccountingMethod => EnumUtility.GetItemsList<AccountingMethod>();

        /// <summary>
        /// GetOverheadType
        /// </summary>
        public IEnumerable<CustomSelectList> GetOverheadType => EnumUtility.GetItemsList<OverheadType>();

        /// <summary>
        /// GetLaborType
        /// </summary>
        public IEnumerable<CustomSelectList> GetLaborType => EnumUtility.GetItemsList<LaborType>();

        /// <summary>
        /// GetPROJTYPE
        /// </summary>
        public IEnumerable<CustomSelectList> GetPROJTYPE => EnumUtility.GetItemsList<PROJTYPE>();

        /// <summary>
        /// GetBillingType
        /// </summary>
        public IEnumerable<CustomSelectList> GetBillingType => EnumUtility.GetItemsList<BillingType>();

        /// <summary>
        /// GetRevenueAndCostCurrency
        /// </summary>
        public IEnumerable<CustomSelectList> GetRevenueAndCostCurrency => EnumUtility.GetItemsList<RevenueAndCostCurrency>();


        /// <summary>
        /// GetContractHasBeenOpened
        /// </summary>
        public IEnumerable<CustomSelectList> GetContractHasBeenOpened => EnumUtility.GetItemsList<ContractHasBeenOpened>();

        ///// <summary>
        ///// GetPercentageCompleteMethod
        ///// </summary>
        //public IEnumerable<CustomSelectList> GetPercentageCompleteMethod => EnumUtility.GetItemsList<PercentageCompleteMethod>();

        ///// <summary>
        ///// GetAllowMultipleCustomers
        ///// </summary>
        //public IEnumerable<CustomSelectList> GetAllowMultipleCustomers => EnumUtility.GetItemsList<AllowMultipleCustomers>();

        /// <summary>
        /// Get Search dropdwon list
        /// </summary>
        public IEnumerable<CustomSelectList> GetSearch => EnumUtility.GetItemsList<Search>();

        /// <summary>
        /// Get Search dropdwon list
        /// </summary>
        public IEnumerable<CustomSelectList> GetLegend => EnumUtility.GetItemsList<Legend>();

        /// <summary>
        /// Get Optional Field Values dropdwon list
        /// </summary>
        public IEnumerable<CustomSelectList> GetOptionalFieldValues => EnumUtility.GetItemsList<OptionalFieldValues>();
        
        /// <summary>
        /// Returns true if User has Modify Access
        /// </summary>
        public bool HasModifyAccess => UserAccess == null || UserAccess.SecurityType.HasFlag(SecurityType.Modify);
        
        /// <summary>
        /// Get tree view model
        /// </summary>
        public IList<TreeViewItem> TreeViewModel { get; set; }

        /// <summary>
        /// Contract amount totals
        /// </summary>
        public IList<TotalAmount> Totals { get; set; }

        /// <summary>
        /// Get Pjc options parameters
        /// </summary>
        public IList<string> PJCOptionsParameters { get; set; }

    }

    public class TotalAmount
    {
        public string AmountName { get; set;}
        public decimal OriginalEstimate { get; set; }
        public decimal CurrentEstimate { get; set; }
        public decimal Committed { get; set; }
        public decimal Actuals { get; set; }
        public decimal Recognized { get; set; }
        public decimal Stored { get; set; }

    }
}