// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for Contracts
    /// </summary>
    public partial class Contracts : ModelBase
    {
        /// <summary>
        /// Gets or sets ContractUniq
        /// </summary>
        [Key]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractUniq", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ContractUniq, Id = Index.ContractUniq, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ContractUniq { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedContract", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.UnformattedContract, Id = Index.UnformattedContract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContract { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets StructureCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StructureCode", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ContractManager
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractManager", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ContractManager, Id = Index.ContractManager, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ContractManager { get; set; }

        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTACT
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTACT", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CONTACT, Id = Index.CONTACT, FieldType = EntityFieldType.Char, Size = 60)]
        public string CONTACT { get; set; }

        /// <summary>
        /// Gets or sets Telephone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Telephone", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Telephone, Id = Index.Telephone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Telephone { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FAX
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FAX", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.FAX, Id = Index.FAX, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FAX { get; set; }

        /// <summary>
        /// Gets or sets StartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets OriginalEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalEndDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalEndDate, Id = Index.OriginalEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OriginalEndDate { get; set; }

        /// <summary>
        /// Gets or sets ProjectedEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectedEndDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ProjectedEndDate, Id = Index.ProjectedEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ProjectedEndDate { get; set; }

        /// <summary>
        /// Gets or sets ClosedDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ClosedDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ClosedDate, Id = Index.ClosedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ClosedDate { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets UseContractRevenueRecognition
        /// </summary>
        [Display(Name = "UseContractRevenueRecognition", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.UseContractRevenueRecognition, Id = Index.UseContractRevenueRecognition, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseContractRevenueRecognition { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets UseTheContractOverheadInform
        /// </summary>
        [Display(Name = "UseTheContractOverheadInform", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.UseTheContractOverheadInform, Id = Index.UseTheContractOverheadInform, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseTheContractOverheadInform { get; set; }

        /// <summary>
        /// Gets or sets OverheadType
        /// </summary>
        [Display(Name = "OverheadType", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OverheadType, Id = Index.OverheadType, FieldType = EntityFieldType.Int, Size = 2)]
        public Models.Enums.OverheadType OverheadType { get; set; }

        /// <summary>
        /// Gets or sets OverheadRate
        /// </summary>
        [Display(Name = "OverheadRate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OverheadRate, Id = Index.OverheadRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OverheadPercentage
        /// </summary>
        [Display(Name = "OverheadPercentage", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OverheadPercentage, Id = Index.OverheadPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OverheadPercentage { get; set; }

        /// <summary>
        /// Gets or sets UseTheContractLaborType
        /// </summary>
        [Display(Name = "UseTheContractLaborType", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.UseTheContractLaborType, Id = Index.UseTheContractLaborType, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseTheContractLaborType { get; set; }

        /// <summary>
        /// Gets or sets LaborType
        /// </summary>
        [Display(Name = "LaborType", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LaborType, Id = Index.LaborType, FieldType = EntityFieldType.Int, Size = 2)]
        public Models.Enums.LaborType LaborType { get; set; }

        /// <summary>
        /// Gets or sets LaborRate
        /// </summary>
        [Display(Name = "LaborRate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LaborRate, Id = Index.LaborRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LaborRate { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentage
        /// </summary>
        [Display(Name = "LaborPercentage", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LaborPercentage, Id = Index.LaborPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LaborPercentage { get; set; }

        /// <summary>
        /// Gets or sets ContractStatus
        /// </summary>
        [Display(Name = "ContractStatus", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ContractStatus, Id = Index.ContractStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public ContractStatus ContractStatus { get; set; }

        /// <summary>
        /// Gets or sets UseCostPlusPercentage
        /// </summary>
        [Display(Name = "UseCostPlusPercentage", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.UseCostPlusPercentage, Id = Index.UseCostPlusPercentage, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseCostPlusPercentage { get; set; }

        /// <summary>
        /// Gets or sets CostPlusPercentage
        /// </summary>
        [Display(Name = "CostPlusPercentage", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CostPlusPercentage, Id = Index.CostPlusPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CostPlusPercentage { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets USEPTYPE
        /// </summary>
        [Display(Name = "USEPTYPE", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.USEPTYPE, Id = Index.USEPTYPE, FieldType = EntityFieldType.Int, Size = 2)]
        public short USEPTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROJTYPE
        /// </summary>
        [Display(Name = "PROJTYPE", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.PROJTYPE, Id = Index.PROJTYPE, FieldType = EntityFieldType.Int, Size = 2)]
        public PROJTYPE PROJTYPE { get; set; }

        /// <summary>
        /// Gets or sets NumberOfChangeOrdersToThe^
        /// </summary>
        [Display(Name = "NumberOfChangeOrdersToThe^", ResourceType = typeof(ContractsResx))]
        //[ViewField(Name = Fields.NumberOfChangeOrdersToThe, Id = Index.NumberOfChangeOrdersToThe)]
        public short NumberOfChangeOrdersToThe { get; set; }

        /// <summary>
        /// Gets or sets NextChangeOrderNumber
        /// </summary>
        [Display(Name = "NextChangeOrderNumber", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NextChangeOrderNumber, Id = Index.NextChangeOrderNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextChangeOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets AccountSet
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets Template
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Template", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Template, Id = Index.Template, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Template { get; set; }

        /// <summary>
        /// Gets or sets UseTheContractBillingType
        /// </summary>
        [Display(Name = "UseTheContractBillingType", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.UseTheContractBillingType, Id = Index.UseTheContractBillingType, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseTheContractBillingType { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets Schedule
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Schedule", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Schedule, Id = Index.Schedule, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Schedule { get; set; }

        /// <summary>
        /// Gets or sets UseTheContractRetainageInfor
        /// </summary>
        [Display(Name = "UseTheContractRetainageInfor", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.UseTheContractRetainageInfor, Id = Index.UseTheContractRetainageInfor, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseTheContractRetainageInfor { get; set; }

        /// <summary>
        /// Gets or sets ARRetainagePercentage
        /// </summary>
        [Display(Name = "ARRetainagePercentage", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ARRetainagePercentage, Id = Index.ARRetainagePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal ARRetainagePercentage { get; set; }

        /// <summary>
        /// Gets or sets ARRetentionPeriod
        /// </summary>
        [Display(Name = "ARRetentionPeriod", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ARRetentionPeriod, Id = Index.ARRetentionPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public short ARRetentionPeriod { get; set; }

        /// <summary>
        /// Gets or sets Segment1
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment1", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Segment1, Id = Index.Segment1, FieldType = EntityFieldType.Char, Size = 16)]
        public string Segment1 { get; set; }

        /// <summary>
        /// Gets or sets Segment2
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment2", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Segment2, Id = Index.Segment2, FieldType = EntityFieldType.Char, Size = 16)]
        public string Segment2 { get; set; }

        /// <summary>
        /// Gets or sets Segment3
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment3", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Segment3, Id = Index.Segment3, FieldType = EntityFieldType.Char, Size = 16)]
        public string Segment3 { get; set; }

        /// <summary>
        /// Gets or sets Segment4
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment4", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Segment4, Id = Index.Segment4, FieldType = EntityFieldType.Char, Size = 16)]
        public string Segment4 { get; set; }

        /// <summary>
        /// Gets or sets Segment5
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Segment5", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Segment5, Id = Index.Segment5, FieldType = EntityFieldType.Char, Size = 16)]
        public string Segment5 { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateProjectsOntoTheOn
        /// </summary>
        [Display(Name = "ConsolidateProjectsOntoTheOn", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ConsolidateProjectsOntoTheOn, Id = Index.ConsolidateProjectsOntoTheOn, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ConsolidateProjectsOntoTheOn { get; set; }

        /// <summary>
        /// Gets or sets FormCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormCode", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.FormCode, Id = Index.FormCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FormCode { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumberOfDetails", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets RevenueAndCostCurrency
        /// </summary>
        [Display(Name = "RevenueAndCostCurrency", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RevenueAndCostCurrency, Id = Index.RevenueAndCostCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Models.Enums.RevenueAndCostCurrency RevenueAndCostCurrency { get; set; }
        
        /// <summary>
        /// Company functional currency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Company functional currency decimals
        /// </summary>
        public int FuncCurrencyDecimals { get; set; }

        /// <summary>
        /// Company functional currency decimals
        /// </summary>
        public int CustomerCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerCurrency", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        [Display(Name = "ContractStyle", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public Models.Enums.ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets NumberOfNonPercentProjects
        /// </summary>
        [Display(Name = "NumberOfNonPercentProjects", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NumberOfNonPercentProjects, Id = Index.NumberOfNonPercentProjects, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NumberOfNonPercentProjects { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborCostEst
        /// </summary>
        [Display(Name = "OriginalLaborCostEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalLaborCostEst, Id = Index.OriginalLaborCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalLaborCostEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyLaborCostEst
        /// </summary>
        [Display(Name = "CurrencyLaborCostEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyLaborCostEst, Id = Index.CurrencyLaborCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyLaborCostEst { get; set; }

        /// <summary>
        /// Gets or sets ActualLaborCosts
        /// </summary>
        [Display(Name = "ActualLaborCosts", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualLaborCosts, Id = Index.ActualLaborCosts, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualLaborCosts { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJTIMEBSR
        /// </summary>
        [Display(Name = "ORJTIMEBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJTIMEBSR, Id = Index.ORJTIMEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJTIMEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJTIMEBHM
        /// </summary>
        [Display(Name = "ORJTIMEBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJTIMEBHM, Id = Index.ORJTIMEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJTIMEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURTIMEBSR
        /// </summary>
        [Display(Name = "CURTIMEBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURTIMEBSR, Id = Index.CURTIMEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURTIMEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURTIMEBHM
        /// </summary>
        [Display(Name = "CURTIMEBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURTIMEBHM, Id = Index.CURTIMEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURTIMEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTTIMEBSR
        /// </summary>
        [Display(Name = "ACTTIMEBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTTIMEBSR, Id = Index.ACTTIMEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTTIMEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTTIMEBHM
        /// </summary>
        [Display(Name = "ACTTIMEBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTTIMEBHM, Id = Index.ACTTIMEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTTIMEBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborQtyEst
        /// </summary>
        [Display(Name = "OriginalLaborQtyEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalLaborQtyEst, Id = Index.OriginalLaborQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalLaborQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyLaborQtyEst
        /// </summary>
        [Display(Name = "CurrencyLaborQtyEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyLaborQtyEst, Id = Index.CurrencyLaborQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyLaborQtyEst { get; set; }

        /// <summary>
        /// Gets or sets ActualLaborQty
        /// </summary>
        [Display(Name = "ActualLaborQty", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualLaborQty, Id = Index.ActualLaborQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualLaborQty { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentageComplete
        /// </summary>
        [Display(Name = "LaborPercentageComplete", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LaborPercentageComplete, Id = Index.LaborPercentageComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LaborPercentageComplete { get; set; }

        /// <summary>
        /// Gets or sets OriginalMaterialEstimatedCost
        /// </summary>
        [Display(Name = "OriginalMaterialEstimatedCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalMaterialEstimatedCost, Id = Index.OriginalMaterialEstimatedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalMaterialEstimatedCost { get; set; }

        /// <summary>
        /// Gets or sets CurrentMaterialEstimatedCost
        /// </summary>
        [Display(Name = "CurrentMaterialEstimatedCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrentMaterialEstimatedCost, Id = Index.CurrentMaterialEstimatedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentMaterialEstimatedCost { get; set; }

        /// <summary>
        /// Gets or sets ActualMaterialCost
        /// </summary>
        [Display(Name = "ActualMaterialCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualMaterialCost, Id = Index.ActualMaterialCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualMaterialCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMATEBSR
        /// </summary>
        [Display(Name = "ORJMATEBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJMATEBSR, Id = Index.ORJMATEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMATEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMATEBHM
        /// </summary>
        [Display(Name = "ORJMATEBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJMATEBHM, Id = Index.ORJMATEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMATEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMATEBSR
        /// </summary>
        [Display(Name = "CURMATEBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURMATEBSR, Id = Index.CURMATEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMATEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMATEBHM
        /// </summary>
        [Display(Name = "CURMATEBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURMATEBHM, Id = Index.CURMATEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMATEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMATEBSR
        /// </summary>
        [Display(Name = "ACTMATEBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTMATEBSR, Id = Index.ACTMATEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMATEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMATEBHM
        /// </summary>
        [Display(Name = "ACTMATEBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTMATEBHM, Id = Index.ACTMATEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMATEBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalMaterialQtyEst
        /// </summary>
        [Display(Name = "OriginalMaterialQtyEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalMaterialQtyEst, Id = Index.OriginalMaterialQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalMaterialQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyMaterialEst
        /// </summary>
        [Display(Name = "CurrencyMaterialEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyMaterialEst, Id = Index.CurrencyMaterialEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyMaterialEst { get; set; }

        /// <summary>
        /// Gets or sets ActualMaterialQty
        /// </summary>
        [Display(Name = "ActualMaterialQty", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualMaterialQty, Id = Index.ActualMaterialQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualMaterialQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalEstimatedEquipmentCost
        /// </summary>
        [Display(Name = "OriginalEstimatedEquipmentCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalEstimatedEquipmentCost, Id = Index.OriginalEstimatedEquipmentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEstimatedEquipmentCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEstimatedEquipmentCost
        /// </summary>
        [Display(Name = "CurrencyEstimatedEquipmentCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyEstimatedEquipmentCost, Id = Index.CurrencyEstimatedEquipmentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyEstimatedEquipmentCost { get; set; }

        /// <summary>
        /// Gets or sets ActualEquipmentCost
        /// </summary>
        [Display(Name = "ActualEquipmentCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualEquipmentCost, Id = Index.ActualEquipmentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualEquipmentCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJEQUIBSR
        /// </summary>
        [Display(Name = "ORJEQUIBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJEQUIBSR, Id = Index.ORJEQUIBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJEQUIBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJEQUIBHM
        /// </summary>
        [Display(Name = "ORJEQUIBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJEQUIBHM, Id = Index.ORJEQUIBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJEQUIBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUREQUIBSR
        /// </summary>
        [Display(Name = "CUREQUIBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CUREQUIBSR, Id = Index.CUREQUIBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUREQUIBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUREQUIBHM
        /// </summary>
        [Display(Name = "CUREQUIBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CUREQUIBHM, Id = Index.CUREQUIBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUREQUIBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTEQUIBSR
        /// </summary>
        [Display(Name = "ACTEQUIBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTEQUIBSR, Id = Index.ACTEQUIBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTEQUIBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTEQUIBHM
        /// </summary>
        [Display(Name = "ACTEQUIBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTEQUIBHM, Id = Index.ACTEQUIBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTEQUIBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalEquipmentQtyEst
        /// </summary>
        [Display(Name = "OriginalEquipmentQtyEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalEquipmentQtyEst, Id = Index.OriginalEquipmentQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalEquipmentQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEquipmentEst
        /// </summary>
        [Display(Name = "CurrencyEquipmentEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyEquipmentEst, Id = Index.CurrencyEquipmentEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyEquipmentEst { get; set; }

        /// <summary>
        /// Gets or sets ActualEquipmentQty
        /// </summary>
        [Display(Name = "ActualEquipmentQty", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualEquipmentQty, Id = Index.ActualEquipmentQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualEquipmentQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalSubcontractorEstCost
        /// </summary>
        [Display(Name = "OriginalSubcontractorEstCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalSubcontractorEstCost, Id = Index.OriginalSubcontractorEstCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalSubcontractorEstCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencySubcontractorEstCost
        /// </summary>
        [Display(Name = "CurrencySubcontractorEstCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencySubcontractorEstCost, Id = Index.CurrencySubcontractorEstCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencySubcontractorEstCost { get; set; }

        /// <summary>
        /// Gets or sets ActualSubcontractorCost
        /// </summary>
        [Display(Name = "ActualSubcontractorCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualSubcontractorCost, Id = Index.ActualSubcontractorCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualSubcontractorCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJSUBCBSR
        /// </summary>
        [Display(Name = "ORJSUBCBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJSUBCBSR, Id = Index.ORJSUBCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJSUBCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJSUBCBHM
        /// </summary>
        [Display(Name = "ORJSUBCBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJSUBCBHM, Id = Index.ORJSUBCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJSUBCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURSUBCBSR
        /// </summary>
        [Display(Name = "CURSUBCBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURSUBCBSR, Id = Index.CURSUBCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURSUBCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURSUBCBHM
        /// </summary>
        [Display(Name = "CURSUBCBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURSUBCBHM, Id = Index.CURSUBCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURSUBCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTSUBCBSR
        /// </summary>
        [Display(Name = "ACTSUBCBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTSUBCBSR, Id = Index.ACTSUBCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTSUBCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTSUBCBHM
        /// </summary>
        [Display(Name = "ACTSUBCBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTSUBCBHM, Id = Index.ACTSUBCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTSUBCBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalSubcontractorQtyEst
        /// </summary>
        [Display(Name = "OriginalSubcontractorQtyEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalSubcontractorQtyEst, Id = Index.OriginalSubcontractorQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalSubcontractorQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencySubcontractorEst
        /// </summary>
        [Display(Name = "CurrencySubcontractorEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencySubcontractorEst, Id = Index.CurrencySubcontractorEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencySubcontractorEst { get; set; }

        /// <summary>
        /// Gets or sets ActualSubcontractorQty
        /// </summary>
        [Display(Name = "ActualSubcontractorQty", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualSubcontractorQty, Id = Index.ActualSubcontractorQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualSubcontractorQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalEstOverheadExpenseCost
        /// </summary>
        [Display(Name = "OriginalEstOverheadExpenseCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalEstOverheadExpenseCost, Id = Index.OriginalEstOverheadExpenseCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEstOverheadExpenseCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEstOverheadExpenseCost
        /// </summary>
        [Display(Name = "CurrencyEstOverheadExpenseCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyEstOverheadExpenseCost, Id = Index.CurrencyEstOverheadExpenseCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyEstOverheadExpenseCost { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadExpenseCost
        /// </summary>
        [Display(Name = "ActualOverheadExpenseCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualOverheadExpenseCost, Id = Index.ActualOverheadExpenseCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverheadExpenseCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJOHEXBSR
        /// </summary>
        [Display(Name = "ORJOHEXBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJOHEXBSR, Id = Index.ORJOHEXBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJOHEXBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJOHEXBHM
        /// </summary>
        [Display(Name = "ORJOHEXBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJOHEXBHM, Id = Index.ORJOHEXBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJOHEXBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUROHEXBSR
        /// </summary>
        [Display(Name = "CUROHEXBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CUROHEXBSR, Id = Index.CUROHEXBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUROHEXBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUROHEXBHM
        /// </summary>
        [Display(Name = "CUROHEXBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CUROHEXBHM, Id = Index.CUROHEXBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUROHEXBHM { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadAmountBilled
        /// </summary>
        [Display(Name = "ActualOverheadAmountBilled", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualOverheadAmountBilled, Id = Index.ActualOverheadAmountBilled, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverheadAmountBilled { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadBillingEst
        /// </summary>
        [Display(Name = "ActualOverheadBillingEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualOverheadBillingEst, Id = Index.ActualOverheadBillingEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverheadBillingEst { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadQtyEst
        /// </summary>
        [Display(Name = "OriginalOverheadQtyEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalOverheadQtyEst, Id = Index.OriginalOverheadQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalOverheadQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyOverheadEst
        /// </summary>
        [Display(Name = "CurrencyOverheadEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyOverheadEst, Id = Index.CurrencyOverheadEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyOverheadEst { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadQty
        /// </summary>
        [Display(Name = "ActualOverheadQty", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualOverheadQty, Id = Index.ActualOverheadQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualOverheadQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalEstMiscellaneousCost
        /// </summary>
        [Display(Name = "OriginalEstMiscellaneousCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalEstMiscellaneousCost, Id = Index.OriginalEstMiscellaneousCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEstMiscellaneousCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEstMiscellaneousCost
        /// </summary>
        [Display(Name = "CurrencyEstMiscellaneousCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyEstMiscellaneousCost, Id = Index.CurrencyEstMiscellaneousCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyEstMiscellaneousCost { get; set; }

        /// <summary>
        /// Gets or sets ActualMiscellaneousCost
        /// </summary>
        [Display(Name = "ActualMiscellaneousCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualMiscellaneousCost, Id = Index.ActualMiscellaneousCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualMiscellaneousCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMISCBSR
        /// </summary>
        [Display(Name = "ORJMISCBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJMISCBSR, Id = Index.ORJMISCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMISCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMISCBHM
        /// </summary>
        [Display(Name = "ORJMISCBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJMISCBHM, Id = Index.ORJMISCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMISCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMISCBSR
        /// </summary>
        [Display(Name = "CURMISCBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURMISCBSR, Id = Index.CURMISCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMISCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMISCBHM
        /// </summary>
        [Display(Name = "CURMISCBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURMISCBHM, Id = Index.CURMISCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMISCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMISCBSR
        /// </summary>
        [Display(Name = "ACTMISCBSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTMISCBSR, Id = Index.ACTMISCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMISCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMISCBHM
        /// </summary>
        [Display(Name = "ACTMISCBHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTMISCBHM, Id = Index.ACTMISCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMISCBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalMiscellaneousQtyEst
        /// </summary>
        [Display(Name = "OriginalMiscellaneousQtyEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalMiscellaneousQtyEst, Id = Index.OriginalMiscellaneousQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalMiscellaneousQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyMiscellaneousEst
        /// </summary>
        [Display(Name = "CurrencyMiscellaneousEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyMiscellaneousEst, Id = Index.CurrencyMiscellaneousEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyMiscellaneousEst { get; set; }

        /// <summary>
        /// Gets or sets ActualMiscellaneousQty
        /// </summary>
        [Display(Name = "ActualMiscellaneousQty", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualMiscellaneousQty, Id = Index.ActualMiscellaneousQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualMiscellaneousQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadEstimate
        /// </summary>
        [Display(Name = "OriginalOverheadEstimate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OriginalOverheadEstimate, Id = Index.OriginalOverheadEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalOverheadEstimate { get; set; }

        /// <summary>
        /// Gets or sets CurrentOverheadEstimate
        /// </summary>
        [Display(Name = "CurrentOverheadEstimate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrentOverheadEstimate, Id = Index.CurrentOverheadEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentOverheadEstimate { get; set; }

        /// <summary>
        /// Gets or sets ActualOverhead
        /// </summary>
        [Display(Name = "ActualOverhead", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActualOverhead, Id = Index.ActualOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverhead { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJLABSR
        /// </summary>
        [Display(Name = "ORJLABSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJLABSR, Id = Index.ORJLABSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJLABSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJLABHM
        /// </summary>
        [Display(Name = "ORJLABHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ORJLABHM, Id = Index.ORJLABHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJLABHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURLABSR
        /// </summary>
        [Display(Name = "CURLABSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURLABSR, Id = Index.CURLABSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURLABSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURLABHM
        /// </summary>
        [Display(Name = "CURLABHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CURLABHM, Id = Index.CURLABHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURLABHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTLABSR
        /// </summary>
        [Display(Name = "ACTLABSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTLABSR, Id = Index.ACTLABSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTLABSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTLABHM
        /// </summary>
        [Display(Name = "ACTLABHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTLABHM, Id = Index.ACTLABHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTLABHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGSR
        /// </summary>
        [Display(Name = "ACTCHRGSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTCHRGSR, Id = Index.ACTCHRGSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGHM
        /// </summary>
        [Display(Name = "ACTCHRGHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTCHRGHM, Id = Index.ACTCHRGHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGDSR
        /// </summary>
        [Display(Name = "ACTCHRGDSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTCHRGDSR, Id = Index.ACTCHRGDSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGDSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGDHM
        /// </summary>
        [Display(Name = "ACTCHRGDHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ACTCHRGDHM, Id = Index.ACTCHRGDHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGDHM { get; set; }

        /// <summary>
        /// Gets or sets ActCostStockRetToInventory
        /// </summary>
        [Display(Name = "ActCostStockRetToInventory", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActCostStockRetToInventory, Id = Index.ActCostStockRetToInventory, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActCostStockRetToInventory { get; set; }

        /// <summary>
        /// Gets or sets ActQtyStockRetToInventory
        /// </summary>
        [Display(Name = "ActQtyStockRetToInventory", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ActQtyStockRetToInventory, Id = Index.ActQtyStockRetToInventory, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActQtyStockRetToInventory { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TARRECTSSR
        /// </summary>
        [Display(Name = "TARRECTSSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TARRECTSSR, Id = Index.TARRECTSSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TARRECTSSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TARRECTSHM
        /// </summary>
        [Display(Name = "TARRECTSHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TARRECTSHM, Id = Index.TARRECTSHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TARRECTSHM { get; set; }

        /// <summary>
        /// Gets or sets TotalAPVendorPayments
        /// </summary>
        [Display(Name = "TotalAPVendorPayments", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalAPVendorPayments, Id = Index.TotalAPVendorPayments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAPVendorPayments { get; set; }

        /// <summary>
        /// Gets or sets TotalOriginalCostEst
        /// </summary>
        [Display(Name = "TotalOriginalCostEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalOriginalCostEst, Id = Index.TotalOriginalCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalOriginalCostEst { get; set; }

        /// <summary>
        /// Gets or sets TotalCurrencyCostEst
        /// </summary>
        [Display(Name = "TotalCurrencyCostEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalCurrencyCostEst, Id = Index.TotalCurrencyCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCurrencyCostEst { get; set; }

        /// <summary>
        /// Gets or sets TotalActualCost
        /// </summary>
        [Display(Name = "TotalActualCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalActualCost, Id = Index.TotalActualCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalActualCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCostRecognized
        /// </summary>
        [Display(Name = "TotalCostRecognized", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalCostRecognized, Id = Index.TotalCostRecognized, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostRecognized { get; set; }

        /// <summary>
        /// Gets or sets PercentTotalCost
        /// </summary>
        [Display(Name = "PercentTotalCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.PercentTotalCost, Id = Index.PercentTotalCost, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentTotalCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TORJREVSR
        /// </summary>
        [Display(Name = "TORJREVSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TORJREVSR, Id = Index.TORJREVSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TORJREVSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TORJREVHM
        /// </summary>
        [Display(Name = "TORJREVHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TORJREVHM, Id = Index.TORJREVHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TORJREVHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TCURREVSR
        /// </summary>
        [Display(Name = "TCURREVSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TCURREVSR, Id = Index.TCURREVSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TCURREVSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TCURREVHM
        /// </summary>
        [Display(Name = "TCURREVHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TCURREVHM, Id = Index.TCURREVHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TCURREVHM { get; set; }

        /// <summary>
        /// Gets or sets TotalActualRevenue
        /// </summary>
        [Display(Name = "TotalActualRevenue", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalActualRevenue, Id = Index.TotalActualRevenue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalActualRevenue { get; set; }

        /// <summary>
        /// Gets or sets TotalActualRevenueEst
        /// </summary>
        [Display(Name = "TotalActualRevenueEst", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalActualRevenueEst, Id = Index.TotalActualRevenueEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalActualRevenueEst { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TRECREVSR
        /// </summary>
        [Display(Name = "TRECREVSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TRECREVSR, Id = Index.TRECREVSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRECREVSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TRECREVHM
        /// </summary>
        [Display(Name = "TRECREVHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TRECREVHM, Id = Index.TRECREVHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRECREVHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARAMTSR
        /// </summary>
        [Display(Name = "RETARAMTSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RETARAMTSR, Id = Index.RETARAMTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARAMTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARAMTHM
        /// </summary>
        [Display(Name = "RETARAMTHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RETARAMTHM, Id = Index.RETARAMTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARAMTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARRECSR
        /// </summary>
        [Display(Name = "RETARRECSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RETARRECSR, Id = Index.RETARRECSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARRECSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARRECHM
        /// </summary>
        [Display(Name = "RETARRECHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RETARRECHM, Id = Index.RETARRECHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARRECHM { get; set; }

        /// <summary>
        /// Gets or sets RetainagePayable
        /// </summary>
        [Display(Name = "RetainagePayable", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RetainagePayable, Id = Index.RetainagePayable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainagePayable { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmountPaidInAP
        /// </summary>
        [Display(Name = "RetainageAmountPaidInAP", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RetainageAmountPaidInAP, Id = Index.RetainageAmountPaidInAP, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmountPaidInAP { get; set; }

        /// <summary>
        /// Gets or sets RecognizedLoss
        /// </summary>
        [Display(Name = "RecognizedLoss", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RecognizedLoss, Id = Index.RecognizedLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RecognizedLoss { get; set; }

        /// <summary>
        /// Gets or sets RecognizedComplete
        /// </summary>
        [Display(Name = "RecognizedComplete", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.RecognizedComplete, Id = Index.RecognizedComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RecognizedComplete { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FPAMOUNTSR
        /// </summary>
        [Display(Name = "FPAMOUNTSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.FPAMOUNTSR, Id = Index.FPAMOUNTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FPAMOUNTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FPAMOUNTHM
        /// </summary>
        [Display(Name = "FPAMOUNTHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.FPAMOUNTHM, Id = Index.FPAMOUNTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FPAMOUNTHM { get; set; }

        /// <summary>
        /// Gets or sets LastBillingsPercentComplete
        /// </summary>
        [Display(Name = "LastBillingsPercentComplete", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastBillingsPercentComplete, Id = Index.LastBillingsPercentComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LastBillingsPercentComplete { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets BILLAMTSR
        /// </summary>
        [Display(Name = "BILLAMTSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.BILLAMTSR, Id = Index.BILLAMTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BILLAMTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets BILLAMTHM
        /// </summary>
        [Display(Name = "BILLAMTHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.BILLAMTHM, Id = Index.BILLAMTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BILLAMTHM { get; set; }

        /// <summary>
        /// Gets or sets LastCostPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastCostPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastCostPostingDate, Id = Index.LastCostPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastCostPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastBillingsPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastBillingsPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastBillingsPostingDate, Id = Index.LastBillingsPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastBillingsPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastOverheadPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOverheadPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastOverheadPostingDate, Id = Index.LastOverheadPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastOverheadPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastChargePostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastChargePostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastChargePostingDate, Id = Index.LastChargePostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastChargePostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastRevRecognitionPostingDa
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastRevRecognitionPostingDa", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastRevRecognitionPostingDa, Id = Index.LastRevRecognitionPostingDa, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastRevRecognitionPostingDa { get; set; }

        /// <summary>
        /// Gets or sets LastARReceiptPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastARReceiptPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastARReceiptPostingDate, Id = Index.LastARReceiptPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastARReceiptPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastAPPaymentPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastAPPaymentPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastAPPaymentPostingDate, Id = Index.LastAPPaymentPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastAPPaymentPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastTimecardPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastTimecardPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastTimecardPostingDate, Id = Index.LastTimecardPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastTimecardPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastMaterialUsagePostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaterialUsagePostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastMaterialUsagePostingDate, Id = Index.LastMaterialUsagePostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaterialUsagePostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastMaterialReturnPostingDat
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaterialReturnPostingDat", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastMaterialReturnPostingDat, Id = Index.LastMaterialReturnPostingDat, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaterialReturnPostingDat { get; set; }

        /// <summary>
        /// Gets or sets LastEquipmentPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastEquipmentPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastEquipmentPostingDate, Id = Index.LastEquipmentPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastEquipmentPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastPurchaseOrderDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPurchaseOrderDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastPurchaseOrderDate, Id = Index.LastPurchaseOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPurchaseOrderDate { get; set; }

        /// <summary>
        /// Gets or sets LastPOReceiptDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPOReceiptDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastPOReceiptDate, Id = Index.LastPOReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPOReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets LastPOReturnDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPOReturnDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastPOReturnDate, Id = Index.LastPOReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPOReturnDate { get; set; }

        /// <summary>
        /// Gets or sets LastOEOrderDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOEOrderDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastOEOrderDate, Id = Index.LastOEOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastOEOrderDate { get; set; }

        /// <summary>
        /// Gets or sets LastOEInvoiceDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOEInvoiceDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastOEInvoiceDate, Id = Index.LastOEInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastOEInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRoundingAmount
        /// </summary>
        [Display(Name = "FunctionalRoundingAmount", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.FunctionalRoundingAmount, Id = Index.FunctionalRoundingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRoundingAmount { get; set; }

        /// <summary>
        /// Gets or sets NextTransactionNumber
        /// </summary>
        [Display(Name = "NextTransactionNumber", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NextTransactionNumber, Id = Index.NextTransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOpenProjects
        /// </summary>
        [Display(Name = "NumberOfOpenProjects", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NumberOfOpenProjects, Id = Index.NumberOfOpenProjects, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOpenProjects { get; set; }

        /// <summary>
        /// Gets or sets ContractHasBeenOpened
        /// </summary>
        [Display(Name = "ContractHasBeenOpened", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ContractHasBeenOpened, Id = Index.ContractHasBeenOpened, FieldType = EntityFieldType.Bool, Size = 2)]
        public Models.Enums.ContractHasBeenOpened ContractHasBeenOpened { get; set; }

        /// <summary>
        /// Gets or sets ExpectedBillings
        /// </summary>
        [Display(Name = "ExpectedBillings", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ExpectedBillings, Id = Index.ExpectedBillings, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExpectedBillings { get; set; }

        /// <summary>
        /// Gets or sets BillingsPercentComplete
        /// </summary>
        [Display(Name = "BillingsPercentComplete", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.BillingsPercentComplete, Id = Index.BillingsPercentComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingsPercentComplete { get; set; }

        /// <summary>
        /// Gets or sets LastRevRecognitionPercentage
        /// </summary>
        [Display(Name = "LastRevRecognitionPercentage", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastRevRecognitionPercentage, Id = Index.LastRevRecognitionPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LastRevRecognitionPercentage { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PRFTLOSSSR
        /// </summary>
        [Display(Name = "PRFTLOSSSR", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.PRFTLOSSSR, Id = Index.PRFTLOSSSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PRFTLOSSSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PRFTLOSSHM
        /// </summary>
        [Display(Name = "PRFTLOSSHM", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.PRFTLOSSHM, Id = Index.PRFTLOSSHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PRFTLOSSHM { get; set; }

        /// <summary>
        /// Gets or sets LastRevisedPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastRevisedPostingDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.LastRevisedPostingDate, Id = Index.LastRevisedPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastRevisedPostingDate { get; set; }

        /// <summary>
        /// Gets or sets CurrentStartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentStartDate", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrentStartDate, Id = Index.CurrentStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CurrentStartDate { get; set; }

        /// <summary>
        /// Gets or sets PercentageCompleteMethod
        /// </summary>
        //[Display(Name = "PercentageCompleteMethod", ResourceType = typeof(ContractsResx))]
        //[ViewField(Name = Fields.PercentageCompleteMethod, Id = Index.PercentageCompleteMethod, FieldType = EntityFieldType.Int, Size = 2)]
        //public Models.Enums.PercentageCompleteMethod PercentageCompleteMethod { get; set; }

        /// <summary>
        /// Gets or sets NumberOfProjects
        /// </summary>
        [Display(Name = "NumberOfProjects", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NumberOfProjects, Id = Index.NumberOfProjects, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfProjects { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOCost
        /// </summary>
        [Display(Name = "CommittedPOCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CommittedPOCost, Id = Index.CommittedPOCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOCost { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOOverhead
        /// </summary>
        [Display(Name = "CommittedPOOverhead", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CommittedPOOverhead, Id = Index.CommittedPOOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOOverhead { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOLabor
        /// </summary>
        [Display(Name = "CommittedPOLabor", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CommittedPOLabor, Id = Index.CommittedPOLabor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOLabor { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOTotalCost
        /// </summary>
        [Display(Name = "CommittedPOTotalCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CommittedPOTotalCost, Id = Index.CommittedPOTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOTotalCost { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        ///  Gets or sets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUSCONTACT
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CUSCONTACT", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CUSCONTACT, Id = Index.CUSCONTACT, FieldType = EntityFieldType.Char, Size = 60)]
        public string CUSCONTACT { get; set; }

        /// <summary>
        /// Gets or sets Position
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Position", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Position, Id = Index.Position, FieldType = EntityFieldType.Char, Size = 60)]
        public string Position { get; set; }

        /// <summary>
        /// Gets or sets Phone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Phone, Id = Index.Phone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets OtherPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OtherPhone", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OtherPhone, Id = Index.OtherPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string OtherPhone { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTACFAX
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CTACFAX", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CTACFAX, Id = Index.CTACFAX, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string CTACFAX { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 60)]
        public string Email { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets USETAXGRP
        /// </summary>
        [Display(Name = "USETAXGRP", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.USETAXGRP, Id = Index.USETAXGRP, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool USETAXGRP { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CODETAXGRP
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CODETAXGRP", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CODETAXGRP, Id = Index.CODETAXGRP, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string CODETAXGRP { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority1", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority1, Id = Index.CustomerTaxAuthority1, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority2", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority2, Id = Index.CustomerTaxAuthority2, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority3", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority3, Id = Index.CustomerTaxAuthority3, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority4", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority4, Id = Index.CustomerTaxAuthority4, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority5", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority5, Id = Index.CustomerTaxAuthority5, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets StoredCost
        /// </summary>
        [Display(Name = "StoredCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.StoredCost, Id = Index.StoredCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StoredCost { get; set; }

        /// <summary>
        /// Gets or sets StoredBillableAmount
        /// </summary>
        [Display(Name = "StoredBillableAmount", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.StoredBillableAmount, Id = Index.StoredBillableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StoredBillableAmount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmount
        /// </summary>
        [Display(Name = "OverheadAmount", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.OverheadAmount, Id = Index.OverheadAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalStoredCost
        /// </summary>
        [Display(Name = "TotalStoredCost", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TotalStoredCost, Id = Index.TotalStoredCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalStoredCost { get; set; }

        /// <summary>
        /// Gets or sets TaxExpCommittedFunc
        /// </summary>
        [Display(Name = "TaxExpCommittedFunc", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TaxExpCommittedFunc, Id = Index.TaxExpCommittedFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpCommittedFunc { get; set; }

        /// <summary>
        /// Gets or sets TaxAllCommittedFunc
        /// </summary>
        [Display(Name = "TaxAllCommittedFunc", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.TaxAllCommittedFunc, Id = Index.TaxAllCommittedFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllCommittedFunc { get; set; }

        /// <summary>
        /// Gets or sets PreviousCertificatesForPaymen
        /// </summary>
        [Display(Name = "PreviousCertificatesForPaymen", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.PreviousCertificatesForPaymen, Id = Index.PreviousCertificatesForPaymen, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreviousCertificatesForPaymen { get; set; }

        /// <summary>
        /// Gets or sets G703ColumnFFromLastAIARepo
        /// </summary>
        [Display(Name = "G703ColumnFFromLastAIARepo", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.G703ColumnFFromLastAIARepo, Id = Index.G703ColumnFFromLastAIARepo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal G703ColumnFFromLastAIARepo { get; set; }

        /// <summary>
        /// Gets or sets G703ColumnIFromLastAIARepo
        /// </summary>
        [Display(Name = "G703ColumnIFromLastAIARepo", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.G703ColumnIFromLastAIARepo, Id = Index.G703ColumnIFromLastAIARepo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal G703ColumnIFromLastAIARepo { get; set; }

        /// <summary>
        /// Gets or sets InvoiceToMultipleCustomers
        /// </summary>
        [Display(Name = "InvoiceToMultipleCustomers", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.InvoiceToMultipleCustomers, Id = Index.InvoiceToMultipleCustomers, FieldType = EntityFieldType.Int, Size = 2)]
        public short InvoiceToMultipleCustomers { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDifferentFromThatOn
        /// </summary>
        [Display(Name = "CurrencyDifferentFromThatOn", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CurrencyDifferentFromThatOn, Id = Index.CurrencyDifferentFromThatOn, FieldType = EntityFieldType.Int, Size = 2)]
        public short CurrencyDifferentFromThatOn { get; set; }

        /// <summary>
        /// Gets or sets AllowMultipleCustomers
        /// </summary>
        [Display(Name = "AllowMultipleCustomers", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.AllowMultipleCustomers, Id = Index.AllowMultipleCustomers, FieldType = EntityFieldType.Int, Size = 2)]
        public bool AllowMultipleCustomers { get; set; }

        /// <summary>
        /// Gets or sets ARAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARAccountSet", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ARAccountSet, Id = Index.ARAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ARAccountSet { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Models.Enums.Function Function { get; set; }

        /// <summary>
        /// Gets or sets Num16BitParameter
        /// </summary>
        [Display(Name = "Num16BitParameter", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.Num16BitParameter, Id = Index.Num16BitParameter, FieldType = EntityFieldType.Int, Size = 2)]
        public short Num16BitParameter { get; set; }

        /// <summary>
        /// Gets or sets StringParameter
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StringParameter", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.StringParameter, Id = Index.StringParameter, FieldType = EntityFieldType.Char, Size = 200)]
        public string StringParameter { get; set; }

        /// <summary>
        /// Gets or sets ContractNumberIsValid
        /// </summary>
        [Display(Name = "ContractNumberIsValid", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.ContractNumberIsValid, Id = Index.ContractNumberIsValid, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ContractNumberIsValid { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets ShowProgressBarDuringPosting
        /// </summary>
        //[Display(Name = "ShowProgressBarDuringPosting", ResourceType = typeof(ContractsResx))]
        //[ViewField(Name = Fields.ShowProgressBarDuringPosting, Id = Index.ShowProgressBarDuringPosting, FieldType = EntityFieldType.Int, Size = 2)]
        //public ValuedPartner.PM.Models.Enums.ShowProgressBarDuringPosting ShowProgressBarDuringPosting { get; set; }

        /// <summary>
        /// Gets or sets DeletingContract
        /// </summary>
        [Display(Name = "DeletingContract", ResourceType = typeof(ContractsResx))]
        [ViewField(Name = Fields.DeletingContract, Id = Index.DeletingContract, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DeletingContract { get; set; }

        #region UI Strings
        [Display(Name = "StructureDescription", ResourceType = typeof(ContractsResx))]
        public string StructureDescription { get; set; }

        [Display(Name = "AccountSetDescription", ResourceType = typeof(ContractsResx))]
        public string AccountSetDescription { get; set; }

        [Display(Name = "ContractManagerName", ResourceType = typeof(ContractsResx))]
        public string ContractManagerName { get; set; }

        [Display(Name = "TaxGroupDescription", ResourceType = typeof(ContractsResx))]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets OverheadType string value
        /// </summary>
        public string OverheadTypeString => EnumUtility.GetStringValue(OverheadType);

        /// <summary>
        /// Gets LaborType string value
        /// </summary>
        public string LaborTypeString => EnumUtility.GetStringValue(LaborType);

        /// <summary>
        /// Gets ContractStatus string value
        /// </summary>
        public string ContractStatusString => EnumUtility.GetStringValue(ContractStatus);

        /// <summary>
        /// Gets PROJTYPE string value
        /// </summary>
        public string PROJTYPEString => EnumUtility.GetStringValue(PROJTYPE);

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString => EnumUtility.GetStringValue(BillingType);

        /// <summary>
        /// Gets RevenueAndCostCurrency string value
        /// </summary>
        public string RevenueAndCostCurrencyString => EnumUtility.GetStringValue(RevenueAndCostCurrency);

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString => EnumUtility.GetStringValue(ContractStyle);

        /// <summary>
        /// Gets ContractHasBeenOpened string value
        /// </summary>
        public string ContractHasBeenOpenedString => EnumUtility.GetStringValue(ContractHasBeenOpened);

        /// <summary>
        /// Gets PercentageCompleteMethod string value
        /// </summary>
        //public string PercentageCompleteMethodString => EnumUtility.GetStringValue(PercentageCompleteMethod);

        /// <summary>
        /// Gets AllowMultipleCustomers string value
        /// </summary>
        //public string AllowMultipleCustomersString => EnumUtility.GetStringValue(AllowMultipleCustomers);

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString => EnumUtility.GetStringValue(Function);

        /// <summary>
        /// Gets ShowProgressBarDuringPosting string value
        /// </summary>
        //public string ShowProgressBarDuringPostingString => EnumUtility.GetStringValue(ShowProgressBarDuringPosting);

        public ProjectStatus ProjectStatus { get; set; }
        
        /// <summary>
        /// Get node level1 text from options
        /// </summary>
        public string Level1Name { get; set; }
        /// <summary>
        /// Get node level2 text from options
        /// </summary>
        public string Level2Name { get; set; }
        /// <summary>
        /// Get node level3 text from options
        /// </summary>
        public string Level3Name { get; set; }

        #endregion

        /// <summary>
        /// 
        /// </summary>
        [Display(Name = "Search", ResourceType = typeof (ContractsResx))]
        public Status Search { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [Display(Name = "Project", ResourceType = typeof(ContractsResx))]
        public string SearchValue { get; set; }
        /// <summary>
        /// 
        /// </summary>
        public Legend ProjectLegend { get; set; }

        #region Contract wizard model
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NewCustomerNumber", ResourceType = typeof (ContractsResx))]
        public string NewCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExistingContractNumber", ResourceType = typeof(ContractsResx))]
        public string ExistingContractNumber { get; set; }
        /// <summary>
        /// Gets or sets CopyEstimatesFrom
        /// </summary>
        public string CopyEstimatesFrom { get; set; } = "0";

        public string WizardContractStyle { get; set; } = "1";

        [Display(Name = "StructureCode", ResourceType = typeof(ContractsResx))]
        public string WizardStructureCode { get; set; } = "SECPRJ";

        [Display(Name = "ContractStructure", ResourceType = typeof(ContractsResx))]
        public string ContractStructure { get; set; } = "XXX-XXXX-XXX";
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Display(Name = "StructureCodeDescription", ResourceType = typeof(ContractsResx))]
        public string StructureCodeDescription { get; set; } = "Contract Number";

        [Display(Name = "SegmentSector", ResourceType = typeof(ContractsResx))]
        public string SegmentSector { get; set; }

        [Display(Name = "SegmentNumber", ResourceType = typeof(ContractsResx))]
        public string SegmentNumber { get; set; }

        [Display(Name = "SegmentType", ResourceType = typeof(ContractsResx))]
        public string SegmentType { get; set; }

        public int DefaultCustomer { get; set; } = 0;

        [Display(Name = "OptionalFields", ResourceType = typeof(ContractsResx))]
        public int OptionalFieldValue { get; set; } = 2;

        public List<contractSegment> Segments { get; set; } = new List<contractSegment>();

        #endregion
    }

    /// <summary>
    /// Contract segment model
    /// </summary>
    public class contractSegment
    {
        public int Number { get; set;}
        public string Name { get; set; }
        public int Length { get; set; }
        public string Segment { get; set; }

    }

}
