// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for MaterialReturnDetail
    /// </summary>
    public partial class MaterialReturnDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Sequence", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets MaterialReturnNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "MaterialReturnNumber", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.MaterialReturnNumber, Id = Index.MaterialReturnNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string MaterialReturnNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FormattedContractNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedContractNumber", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.FormattedContractNumber, Id = Index.FormattedContractNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FormattedContractNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "CONTRACT", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string CONTRACT { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string Resource { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets ItemUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemUnitOfMeasure", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ItemUnitOfMeasure, Id = Index.ItemUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string ItemUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Conversion
        /// </summary>
        //[Display(Name = "Conversion", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Conversion, Id = Index.Conversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Conversion { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ADJUNITCST
        /// </summary>
        //[Display(Name = "ADJUNITCST", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ADJUNITCST, Id = Index.ADJUNITCST, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ADJUNITCST { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ADJCOST
        /// </summary>
        //[Display(Name = "ADJCOST", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ADJCOST, Id = Index.ADJCOST, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ADJCOST { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COSTSEQNUM
        /// </summary>
        //[Display(Name = "COSTSEQNUM", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.COSTSEQNUM, Id = Index.COSTSEQNUM, FieldType = EntityFieldType.Long, Size = 4)]
        public int COSTSEQNUM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COSTDATE
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "COSTDATE", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.COSTDATE, Id = Index.COSTDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime COSTDATE { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCost
        /// </summary>
        //[Display(Name = "AdditionalCost", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.AdditionalCost, Id = Index.AdditionalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdditionalCost { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        //[Display(Name = "StockItem", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets CostMethod
        /// </summary>
        //[Display(Name = "CostMethod", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CostMethod, Id = Index.CostMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short CostMethod { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets UNFMTITEM
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "UNFMTITEM", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.UNFMTITEM, Id = Index.UNFMTITEM, FieldType = EntityFieldType.Char, Size = 24)]
        public string UNFMTITEM { get; set; }

        /// <summary>
        /// Gets or sets CheckBelowZero
        /// </summary>
        //[Display(Name = "CheckBelowZero", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CheckBelowZero, Id = Index.CheckBelowZero, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckBelowZero { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CostCurrency { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ExtendedCostHome
        /// </summary>
        //[Display(Name = "ExtendedCostHome", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ExtendedCostHome, Id = Index.ExtendedCostHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCostHome { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets ICAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICAccount", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ICAccount, Id = Index.ICAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ICAccount { get; set; }

        /// <summary>
        /// Gets or sets WorkInProgressAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgressAccount", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.WorkInProgressAccount, Id = Index.WorkInProgressAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string WorkInProgressAccount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "OverheadAccount", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.OverheadAccount, Id = Index.OverheadAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string OverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillAmountBasedOn
        /// </summary>
        //[Display(Name = "BillAmountBasedOn", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.BillAmountBasedOn, Id = Index.BillAmountBasedOn, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillAmountBasedOn BillAmountBasedOn { get; set; }

        /// <summary>
        /// Gets or sets RevenueAndCostCurrency
        /// </summary>
        //[Display(Name = "RevenueAndCostCurrency", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.RevenueAndCostCurrency, Id = Index.RevenueAndCostCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RevenueAndCostCurrency RevenueAndCostCurrency { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets ExtendedBillingAmount
        /// </summary>
        [Display(Name = "ExtendedBillingAmount", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ExtendedBillingAmount, Id = Index.ExtendedBillingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedBillingAmount { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTSR
        /// </summary>
        [Display(Name = "TOTCOSTSR", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TOTCOSTSR, Id = Index.TOTCOSTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTHM
        /// </summary>
        //[Display(Name = "TOTCOSTHM", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TOTCOSTHM, Id = Index.TOTCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TOTCOSTHM { get; set; }

        /// <summary>
        /// Gets or sets OverheadType
        /// </summary>
        //[Display(Name = "OverheadType", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.OverheadType, Id = Index.OverheadType, FieldType = EntityFieldType.Int, Size = 2)]
        public short OverheadType { get; set; }

        /// <summary>
        /// Gets or sets OverheadRate
        /// </summary>
        //[Display(Name = "OverheadRate", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.OverheadRate, Id = Index.OverheadRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OverheadPercentage
        /// </summary>
        //[Display(Name = "OverheadPercentage", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.OverheadPercentage, Id = Index.OverheadPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OverheadPercentage { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHSR
        /// </summary>
        //[Display(Name = "OHSR", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.OHSR, Id = Index.OHSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OHSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHHM
        /// </summary>
        //[Display(Name = "OHHM", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.OHHM, Id = Index.OHHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OHHM { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        //[Display(Name = "DetailNumber", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARUnitOfMeasure", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ARUnitOfMeasure, Id = Index.ARUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string ARUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        //[Display(Name = "TaxAuthority1", ResourceType = typeof (MaterialReturnDetailResx))]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        //[Display(Name = "TaxAuthority2", ResourceType = typeof (MaterialReturnDetailResx))]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        //[Display(Name = "TaxAuthority3", ResourceType = typeof (MaterialReturnDetailResx))]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        //[Display(Name = "TaxAuthority4", ResourceType = typeof (MaterialReturnDetailResx))]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        //[Display(Name = "TaxAuthority5", ResourceType = typeof (MaterialReturnDetailResx))]
        public string TaxAuthority5 { get; set; }
        
        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        //[Display(Name = "TaxClass1", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        //[Display(Name = "TaxClass2", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        //[Display(Name = "TaxClass3", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        //[Display(Name = "TaxClass4", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        //[Display(Name = "TaxClass5", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public short TaxClass5 { get; set; }
        
        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        //[Display(Name = "TaxIncluded1", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        //[Display(Name = "TaxIncluded2", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        //[Display(Name = "TaxIncluded3", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        //[Display(Name = "TaxIncluded4", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        //[Display(Name = "TaxIncluded5", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        //[Display(Name = "ProjectType", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        //[Display(Name = "ContractStyle", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Customer", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        //[Display(Name = "AccountingMethod", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        //[Display(Name = "InvoiceType", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.InvoiceType InvoiceType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        //[Display(Name = "VALUES", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.VALUES, Id = Index.VALUES, FieldType = EntityFieldType.Long, Size = 4)]
        public int VALUES { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        //[Display(Name = "CloseSN", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CloseSN, Id = Index.CloseSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseSN { get; set; }

        /// <summary>
        /// Gets or sets SNInterCommunicationID
        /// </summary>
        //[Display(Name = "SNInterCommunicationID", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.SNInterCommunicationID, Id = Index.SNInterCommunicationID, FieldType = EntityFieldType.Long, Size = 4)]
        public int SNInterCommunicationID { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        //[Display(Name = "PopupSN", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.PopupSN, Id = Index.PopupSN, FieldType = EntityFieldType.Int, Size = 2)]
        public short PopupSN { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        //[Display(Name = "PopupLT", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.PopupLT, Id = Index.PopupLT, FieldType = EntityFieldType.Int, Size = 2)]
        public short PopupLT { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        //[Display(Name = "CloseLT", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CloseLT, Id = Index.CloseLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseLT { get; set; }

        /// <summary>
        /// Gets or sets LTInterCommunicationID
        /// </summary>
        //[Display(Name = "LTInterCommunicationID", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.LTInterCommunicationID, Id = Index.LTInterCommunicationID, FieldType = EntityFieldType.Long, Size = 4)]
        public int LTInterCommunicationID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSN
        /// </summary>
        //[Display(Name = "ForcePopupSN", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ForcePopupSN, Id = Index.ForcePopupSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupSN { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLT
        /// </summary>
        //[Display(Name = "ForcePopupLT", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ForcePopupLT, Id = Index.ForcePopupLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupLT { get; set; }

        /// <summary>
        /// Gets or sets GenerateICSequence
        /// </summary>
        //[Display(Name = "GenerateICSequence", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.GenerateICSequence, Id = Index.GenerateICSequence, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GenerateICSequence { get; set; }

        /// <summary>
        /// Gets or sets PriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "CustomerCurrency", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets NumberOfSerials
        /// </summary>
        //[Display(Name = "NumberOfSerials", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.NumberOfSerials, Id = Index.NumberOfSerials, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfSerials { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLots
        /// </summary>
        //[Display(Name = "NumberOfLots", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.NumberOfLots, Id = Index.NumberOfLots, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLots { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        //[Display(Name = "ProcessCommand", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        //[Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        //[Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityPerLot
        /// </summary>
        //[Display(Name = "QuantityPerLot", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.QuantityPerLot, Id = Index.QuantityPerLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityPerLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateSerialFrom
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "AllocateSerialFrom", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.AllocateSerialFrom, Id = Index.AllocateSerialFrom, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateSerialFrom { get; set; }

        /// <summary>
        /// Gets or sets AllocateLotFrom
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "AllocateLotFrom", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.AllocateLotFrom, Id = Index.AllocateLotFrom, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateLotFrom { get; set; }

        /// <summary>
        /// Gets or sets MeterHandle
        /// </summary>
        //[Display(Name = "MeterHandle", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.MeterHandle, Id = Index.MeterHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public int MeterHandle { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        //[Display(Name = "Function", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ICAccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICAccountDescription", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ICAccountDescription, Id = Index.ICAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ICAccountDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets WorkInProgressAccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgressAccountDescription", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.WorkInProgressAccountDescription, Id = Index.WorkInProgressAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WorkInProgressAccountDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDescription", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ARItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemDescription", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ARItemDescription, Id = Index.ARItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ARItemDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "OHDESC", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.OHDESC, Id = Index.OHDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string OHDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        //[Display(Name = "HASOPT", ResourceType = typeof (MaterialReturnDetailResx))]
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.HASOPT HASOPT { get; set; }

        /// <summary>
        ///  Gets HasOptionalFields
        /// </summary>
        [ViewField(Name = Fields.HasOptionalFields, Id = Index.HasOptionalFields, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool HasOptionalFields { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ContractDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractDescription", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ContractDescription, Id = Index.ContractDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ProjectDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectDescription", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.ProjectDescription, Id = Index.ProjectDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ProjectDescription { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CategoryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof (MaterialReturnDetailResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString
        {
         get { return EnumUtility.GetStringValue(BillingType); }
        }

        /// <summary>
        /// Gets BillAmountBasedOn string value
        /// </summary>
        public string BillAmountBasedOnString
        {
         get { return EnumUtility.GetStringValue(BillAmountBasedOn); }
        }

        /// <summary>
        /// Gets RevenueAndCostCurrency string value
        /// </summary>
        public string RevenueAndCostCurrencyString
        {
         get { return EnumUtility.GetStringValue(RevenueAndCostCurrency); }
        }

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString
        {
         get { return EnumUtility.GetStringValue(ProjectType); }
        }

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString
        {
         get { return EnumUtility.GetStringValue(ContractStyle); }
        }

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString
        {
         get { return EnumUtility.GetStringValue(AccountingMethod); }
        }

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString
        {
         get { return EnumUtility.GetStringValue(InvoiceType); }
        }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        public string ProcessCommandString
        {
         get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
         get { return EnumUtility.GetStringValue(Function); }
        }

        /// <summary>
        /// Gets HASOPT string value
        /// </summary>
        /*public string HASOPTString
        {
         get { return EnumUtility.GetStringValue(HASOPT); }
        }*/

        #endregion
    }
}
