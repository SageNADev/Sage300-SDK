// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using DataType = Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.DataType;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for ProjectOptionalField
    /// </summary>
    public partial class ProjectOptionalField : ModelBase
    {
        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Project", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16)]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "OptionalField", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUE
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "VALUE", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALUE, Id = Index.VALUE, FieldType = EntityFieldType.Char, Size = 60)]
        public string VALUE { get; set; }

        /// <summary>
        /// Gets or sets DataType
        /// </summary>
        //[Display(Name = "DataType", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.DataType, Id = Index.DataType, FieldType = EntityFieldType.Int, Size = 2)]
        public DataType DataType { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        //[Display(Name = "Length", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public short Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        //[Display(Name = "Decimals", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public short Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        //[Display(Name = "AllowBlank", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        //[Display(Name = "Validate", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        //[Display(Name = "ValueSet", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets ValueIndex
        /// </summary>
        //[Display(Name = "ValueIndex", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.ValueIndex, Id = Index.ValueIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public int ValueIndex { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFTEXT
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "VALIFTEXT", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALIFTEXT, Id = Index.VALIFTEXT, FieldType = EntityFieldType.Char, Size = 60)]
        public string VALIFTEXT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFMONEY
        /// </summary>
        //[Display(Name = "VALIFMONEY", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALIFMONEY, Id = Index.VALIFMONEY, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VALIFMONEY { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFNUM
        /// </summary>
        //[Display(Name = "VALIFNUM", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALIFNUM, Id = Index.VALIFNUM, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal VALIFNUM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFLONG
        /// </summary>
        //[Display(Name = "VALIFLONG", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALIFLONG, Id = Index.VALIFLONG, FieldType = EntityFieldType.Long, Size = 4)]
        public int VALIFLONG { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFBOOL
        /// </summary>
        //[Display(Name = "VALIFBOOL", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALIFBOOL, Id = Index.VALIFBOOL, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool VALIFBOOL { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFDATE
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "VALIFDATE", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALIFDATE, Id = Index.VALIFDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime VALIFDATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALIFTIME
        /// </summary>
        //[Display(Name = "VALIFTIME", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.VALIFTIME, Id = Index.VALIFTIME, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan VALIFTIME { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "OptionalFieldDescription", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ValueDescription", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        //[Display(Name = "Function", ResourceType = typeof (ProjectOptionalFieldResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public short Function { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets DataType string value
        /// </summary>
        public string DataTypeString
        {
         get { return EnumUtility.GetStringValue(DataType); }
        }

        /// <summary>
        /// Gets ValueSet string value
        /// </summary>
        public string ValueSetString
        {
         get { return EnumUtility.GetStringValue(ValueSet); }
        }


        #endregion
    }
}
