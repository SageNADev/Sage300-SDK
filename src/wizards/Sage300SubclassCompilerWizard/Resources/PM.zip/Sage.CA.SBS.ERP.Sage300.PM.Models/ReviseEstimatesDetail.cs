// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for ReviseEstimatesDetail
    /// </summary>
    public partial class ReviseEstimatesDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ReviseEstimateNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReviseEstimateNumber", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.ReviseEstimateNumber, Id = Index.ReviseEstimateNumber)]
        public string ReviseEstimateNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber)]
        public int DetailNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FMTCONTNO", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO)]
        public string FMTCONTNO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTRACT", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT)]
        public string CONTRACT { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project)]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category)]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource)]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets CostType
        /// </summary>
        [Display(Name = "CostType", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CostType, Id = Index.CostType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CostType CostType { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Action
        /// </summary>
        [Display(Name = "Action", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Action, Id = Index.Action)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Action Action { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CBILLTYPE
        /// </summary>
        [Display(Name = "CBILLTYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CBILLTYPE, Id = Index.CBILLTYPE)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CBILLTYPE CBILLTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RBILLTYPE
        /// </summary>
        [Display(Name = "RBILLTYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RBILLTYPE, Id = Index.RBILLTYPE)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RBILLTYPE RBILLTYPE { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency)]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency)]
        public string BillingCurrency { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CDESC", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CDESC, Id = Index.CDESC)]
        public string CDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RDESC", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RDESC, Id = Index.RDESC)]
        public string RDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CARITEM
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CARITEM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CARITEM, Id = Index.CARITEM)]
        public string CARITEM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RARITEM
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RARITEM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RARITEM, Id = Index.RARITEM)]
        public string RARITEM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CARUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CARUOM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CARUOM, Id = Index.CARUOM)]
        public string CARUOM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RARUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RARUOM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RARUOM, Id = Index.RARUOM)]
        public string RARUOM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CICUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CICUOM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CICUOM, Id = Index.CICUOM)]
        public string CICUOM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RICUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RICUOM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RICUOM, Id = Index.RICUOM)]
        public string RICUOM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CCONV
        /// </summary>
        [Display(Name = "CCONV", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CCONV, Id = Index.CCONV)]
        public decimal CCONV { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RCONV
        /// </summary>
        [Display(Name = "RCONV", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RCONV, Id = Index.RCONV)]
        public decimal RCONV { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CQUANTITY
        /// </summary>
        [Display(Name = "CQUANTITY", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CQUANTITY, Id = Index.CQUANTITY)]
        public decimal CQUANTITY { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RQUANTITY
        /// </summary>
        [Display(Name = "RQUANTITY", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RQUANTITY, Id = Index.RQUANTITY)]
        public decimal RQUANTITY { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUNITCOST
        /// </summary>
        [Display(Name = "CUNITCOST", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CUNITCOST, Id = Index.CUNITCOST)]
        public decimal CUNITCOST { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RUNITCOST
        /// </summary>
        [Display(Name = "RUNITCOST", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RUNITCOST, Id = Index.RUNITCOST)]
        public decimal RUNITCOST { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CEXTCOSTSR
        /// </summary>
        [Display(Name = "CEXTCOSTSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CEXTCOSTSR, Id = Index.CEXTCOSTSR)]
        public decimal CEXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets REXTCOSTSR
        /// </summary>
        [Display(Name = "REXTCOSTSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.REXTCOSTSR, Id = Index.REXTCOSTSR)]
        public decimal REXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CEXTCOSTHM
        /// </summary>
        [Display(Name = "CEXTCOSTHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CEXTCOSTHM, Id = Index.CEXTCOSTHM)]
        public decimal CEXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets REXTCOSTHM
        /// </summary>
        [Display(Name = "REXTCOSTHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.REXTCOSTHM, Id = Index.REXTCOSTHM)]
        public decimal REXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CLABORTYPE
        /// </summary>
        [Display(Name = "CLABORTYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CLABORTYPE, Id = Index.CLABORTYPE)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CLABORTYPE CLABORTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RLABORTYPE
        /// </summary>
        [Display(Name = "RLABORTYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RLABORTYPE, Id = Index.RLABORTYPE)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RLABORTYPE RLABORTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CLABORRATE
        /// </summary>
        [Display(Name = "CLABORRATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CLABORRATE, Id = Index.CLABORRATE)]
        public decimal CLABORRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RLABORRATE
        /// </summary>
        [Display(Name = "RLABORRATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RLABORRATE, Id = Index.RLABORRATE)]
        public decimal RLABORRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CLABORPER
        /// </summary>
        [Display(Name = "CLABORPER", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CLABORPER, Id = Index.CLABORPER)]
        public decimal CLABORPER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RLABORPER
        /// </summary>
        [Display(Name = "RLABORPER", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RLABORPER, Id = Index.RLABORPER)]
        public decimal RLABORPER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CLABORAMT
        /// </summary>
        [Display(Name = "CLABORAMT", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CLABORAMT, Id = Index.CLABORAMT)]
        public decimal CLABORAMT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RLABORAMT
        /// </summary>
        [Display(Name = "RLABORAMT", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RLABORAMT, Id = Index.RLABORAMT)]
        public decimal RLABORAMT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COHTYPE
        /// </summary>
        [Display(Name = "COHTYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.COHTYPE, Id = Index.COHTYPE)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.COHTYPE COHTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ROHTYPE
        /// </summary>
        [Display(Name = "ROHTYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.ROHTYPE, Id = Index.ROHTYPE)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ROHTYPE ROHTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COHRATE
        /// </summary>
        [Display(Name = "COHRATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.COHRATE, Id = Index.COHRATE)]
        public decimal COHRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ROHRATE
        /// </summary>
        [Display(Name = "ROHRATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.ROHRATE, Id = Index.ROHRATE)]
        public decimal ROHRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COHPER
        /// </summary>
        [Display(Name = "COHPER", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.COHPER, Id = Index.COHPER)]
        public decimal COHPER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ROHPER
        /// </summary>
        [Display(Name = "ROHPER", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.ROHPER, Id = Index.ROHPER)]
        public decimal ROHPER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COHAMT
        /// </summary>
        [Display(Name = "COHAMT", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.COHAMT, Id = Index.COHAMT)]
        public decimal COHAMT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ROHAMT
        /// </summary>
        [Display(Name = "ROHAMT", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.ROHAMT, Id = Index.ROHAMT)]
        public decimal ROHAMT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTOTCOSTSR
        /// </summary>
        [Display(Name = "CTOTCOSTSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CTOTCOSTSR, Id = Index.CTOTCOSTSR)]
        public decimal CTOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RTOTCOSTSR
        /// </summary>
        [Display(Name = "RTOTCOSTSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RTOTCOSTSR, Id = Index.RTOTCOSTSR)]
        public decimal RTOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTOTCOSTHM
        /// </summary>
        [Display(Name = "CTOTCOSTHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CTOTCOSTHM, Id = Index.CTOTCOSTHM)]
        public decimal CTOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RTOTCOSTHM
        /// </summary>
        [Display(Name = "RTOTCOSTHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RTOTCOSTHM, Id = Index.RTOTCOSTHM)]
        public decimal RTOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CCOSTPLUSP
        /// </summary>
        [Display(Name = "CCOSTPLUSP", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CCOSTPLUSP, Id = Index.CCOSTPLUSP)]
        public decimal CCOSTPLUSP { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RCOSTPLUSP
        /// </summary>
        [Display(Name = "RCOSTPLUSP", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RCOSTPLUSP, Id = Index.RCOSTPLUSP)]
        public decimal RCOSTPLUSP { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CBILLRATE
        /// </summary>
        [Display(Name = "CBILLRATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CBILLRATE, Id = Index.CBILLRATE)]
        public decimal CBILLRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RBILLRATE
        /// </summary>
        [Display(Name = "RBILLRATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RBILLRATE, Id = Index.RBILLRATE)]
        public decimal RBILLRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CEXTBILLSR
        /// </summary>
        [Display(Name = "CEXTBILLSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CEXTBILLSR, Id = Index.CEXTBILLSR)]
        public decimal CEXTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets REXTBILLSR
        /// </summary>
        [Display(Name = "REXTBILLSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.REXTBILLSR, Id = Index.REXTBILLSR)]
        public decimal REXTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CEXTBILLHM
        /// </summary>
        [Display(Name = "CEXTBILLHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CEXTBILLHM, Id = Index.CEXTBILLHM)]
        public decimal CEXTBILLHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets REXTBILLHM
        /// </summary>
        [Display(Name = "REXTBILLHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.REXTBILLHM, Id = Index.REXTBILLHM)]
        public decimal REXTBILLHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CFPAMTSR
        /// </summary>
        [Display(Name = "CFPAMTSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CFPAMTSR, Id = Index.CFPAMTSR)]
        public decimal CFPAMTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RFPAMTSR
        /// </summary>
        [Display(Name = "RFPAMTSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RFPAMTSR, Id = Index.RFPAMTSR)]
        public decimal RFPAMTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CFPAMTHM
        /// </summary>
        [Display(Name = "CFPAMTHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CFPAMTHM, Id = Index.CFPAMTHM)]
        public decimal CFPAMTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RFPAMTHM
        /// </summary>
        [Display(Name = "RFPAMTHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RFPAMTHM, Id = Index.RFPAMTHM)]
        public decimal RFPAMTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CPROFITSR
        /// </summary>
        [Display(Name = "CPROFITSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CPROFITSR, Id = Index.CPROFITSR)]
        public decimal CPROFITSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RPROFITSR
        /// </summary>
        [Display(Name = "RPROFITSR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RPROFITSR, Id = Index.RPROFITSR)]
        public decimal RPROFITSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CPROFITHM
        /// </summary>
        [Display(Name = "CPROFITHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CPROFITHM, Id = Index.CPROFITHM)]
        public decimal CPROFITHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RPROFITHM
        /// </summary>
        [Display(Name = "RPROFITHM", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RPROFITHM, Id = Index.RPROFITHM)]
        public decimal RPROFITHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CRATETYPE
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CRATETYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CRATETYPE, Id = Index.CRATETYPE)]
        public string CRATETYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CRATEDATE
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CRATEDATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CRATEDATE, Id = Index.CRATEDATE)]
        public DateTime CRATEDATE { get; set; }

        /// <summary>
        /// Gets or sets RateOp
        /// </summary>
        [Display(Name = "RateOp", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RateOp, Id = Index.RateOp)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RateOp RateOp { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CRATE
        /// </summary>
        [Display(Name = "CRATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CRATE, Id = Index.CRATE)]
        public decimal CRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RATETYPE
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RATETYPE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RATETYPE, Id = Index.RATETYPE)]
        public string RATETYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RATEDATE
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RATEDATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RATEDATE, Id = Index.RATEDATE)]
        public DateTime RATEDATE { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RateOperation RateOperation { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RATE
        /// </summary>
        [Display(Name = "RATE", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RATE, Id = Index.RATE)]
        public decimal RATE { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        [Display(Name = "ContractStyle", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer)]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.InvoiceType InvoiceType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        [Display(Name = "VALUES", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.VALUES, Id = Index.VALUES)]
        public int VALUES { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RATEERR
        /// </summary>
        [Display(Name = "RATEERR", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RATEERR, Id = Index.RATEERR)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RATEERR RATEERR { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTDESC", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CONTDESC, Id = Index.CONTDESC)]
        public string CONTDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROJDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PROJDESC", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.PROJDESC, Id = Index.PROJDESC)]
        public string PROJDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CATDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CATDESC", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.CATDESC, Id = Index.CATDESC)]
        public string CATDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RESDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RESDESC", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.RESDESC, Id = Index.RESDESC)]
        public string RESDESC { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (ReviseEstimatesDetailResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.NumberOfOptionalFields NumberOfOptionalFields { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets CostType string value
        /// </summary>
        public string CostTypeString => EnumUtility.GetStringValue(CostType);

        /// <summary>
        /// Gets Type string value
        /// </summary>
        public string TypeString => EnumUtility.GetStringValue(Type);

        /// <summary>
        /// Gets Action string value
        /// </summary>
        public string ActionString => EnumUtility.GetStringValue(Action);

        /// <summary>
        /// Gets CBILLTYPE string value
        /// </summary>
        public string CBILLTYPEString => EnumUtility.GetStringValue(CBILLTYPE);

        /// <summary>
        /// Gets RBILLTYPE string value
        /// </summary>
        public string RBILLTYPEString => EnumUtility.GetStringValue(RBILLTYPE);

        /// <summary>
        /// Gets CLABORTYPE string value
        /// </summary>
        public string CLABORTYPEString => EnumUtility.GetStringValue(CLABORTYPE);

        /// <summary>
        /// Gets RLABORTYPE string value
        /// </summary>
        public string RLABORTYPEString => EnumUtility.GetStringValue(RLABORTYPE);

        /// <summary>
        /// Gets COHTYPE string value
        /// </summary>
        public string COHTYPEString => EnumUtility.GetStringValue(COHTYPE);

        /// <summary>
        /// Gets ROHTYPE string value
        /// </summary>
        public string ROHTYPEString => EnumUtility.GetStringValue(ROHTYPE);

        /// <summary>
        /// Gets RateOp string value
        /// </summary>
        public string RateOpString => EnumUtility.GetStringValue(RateOp);

        /// <summary>
        /// Gets RateOperation string value
        /// </summary>
        public string RateOperationString => EnumUtility.GetStringValue(RateOperation);

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString => EnumUtility.GetStringValue(ContractStyle);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString => EnumUtility.GetStringValue(InvoiceType);

        /// <summary>
        /// Gets RATEERR string value
        /// </summary>
        public string RATEERRString => EnumUtility.GetStringValue(RATEERR);

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString => EnumUtility.GetStringValue(Function);

        /// <summary>
        /// Gets NumberOfOptionalFields string value
        /// </summary>
        public string NumberOfOptionalFieldsString => EnumUtility.GetStringValue(NumberOfOptionalFields);

        #endregion
    }
}