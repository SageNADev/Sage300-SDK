// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models.Reports
{
    /// <summary>
    /// Partial class for TransactionListing
    /// </summary>
    public partial class TransactionListing : ReportBase
    {
        #region Transaction Type

        [Display(Name = "OptMaterialUsage", ResourceType = typeof(TransactionListingResx))]
        public bool OptMaterialUsage { get; set; }

        public bool IsMaterialUsageDisable { get; set; }

        [Display(Name = "OptMaterialReturns", ResourceType = typeof(TransactionListingResx))]
        public bool OptMaterialReturns { get; set; }

        public bool IsMaterialReturnsDisable { get; set; }

        [Display(Name = "OptTimecards", ResourceType = typeof(TransactionListingResx))]
        public bool OptTimecards { get; set; }

        public bool IsTimecardsDisable { get; set; }

        [Display(Name = "OptEquipmentUsage", ResourceType = typeof(TransactionListingResx))]
        public bool OptEquipmentUsage { get; set; }

        public bool IsEquipmentUsageDisable { get; set; }

        [Display(Name = "OptCharges", ResourceType = typeof(TransactionListingResx))]
        public bool OptCharges { get; set; }

        public bool IsChargesDisable { get; set; }

        [Display(Name = "OptAdjustments", ResourceType = typeof(TransactionListingResx))]
        public bool OptAdjustments { get; set; }

        public bool IsAdjustmentsDisable { get; set; }

        [Display(Name = "OptReviseEstimates", ResourceType = typeof(TransactionListingResx))]
        public bool OptReviseEstimates { get; set; }

        public bool IsReviseEstimatesDisable { get; set; }

        [Display(Name = "OptCostEntries", ResourceType = typeof(TransactionListingResx))]
        public bool OptCostEntries { get; set; }

        public bool IsCostEntriesDisable { get; set; }

        [Display(Name = "OptMaterialAllocation", ResourceType = typeof(TransactionListingResx))]
        public bool OptMaterialAllocation { get; set; }

        public bool IsMaterialAllocationDisable { get; set; }

        public string TransactionTypeChecked { get; set; }
        #endregion

        #region Include, Type,  Status CheckBoxes

        [Display(Name = "ChkReprintPreviouslyPrint", ResourceType = typeof(TransactionListingResx))]
        public bool ChkReprintPreviouslyPrint { get; set; } = true;

        [Display(Name = "ChkIncludeComments", ResourceType = typeof(TransactionListingResx))]
        public bool ChkIncludeComments { get; set; } = true;

        [Display(Name = "ChkIncludeTaxDetails", ResourceType = typeof(TransactionListingResx))]
        public bool ChkIncludeTaxDetails { get; set; } = true;

        [Display(Name = "ChkOptionalFields", ResourceType = typeof(TransactionListingResx))]
        public bool ChkOptionalFields { get; set; } = true;

        public bool IsOptionalFieldsVisible { get; set; }

        [Display(Name = "ChkSerialLot", ResourceType = typeof(TransactionListingResx))]
        public bool ChkSerialLot { get; set; } = false;
        public bool IsSerialLotVisible { get; set; }

        [Display(Name = "ChkTypeEntered", ResourceType = typeof(TransactionListingResx))]
        public bool ChkTypeEntered { get; set; } = true;

        [Display(Name = "ChkTypeImported", ResourceType = typeof(TransactionListingResx))]
        public bool ChkTypeImported { get; set; } = true;

        [Display(Name = "ChkTypeGenerated", ResourceType = typeof(TransactionListingResx))]
        public bool ChkTypeGenerated { get; set; } = true;

        [Display(Name = "ChkStatusEntered", ResourceType = typeof(TransactionListingResx))]
        public bool ChkStatusEntered { get; set; } = true;

        [Display(Name = "ChkStatusReady", ResourceType = typeof(TransactionListingResx))]
        public bool ChkStatusReady { get; set; } = true;

        [Display(Name = "ChkStatusApproved", ResourceType = typeof(TransactionListingResx))]
        public bool ChkStatusApproved { get; set; } = true;

        [Display(Name = "ChkStatusPosted", ResourceType = typeof(TransactionListingResx))]
        public bool ChkStatusPosted { get; set; } = true;

        #endregion

        public string FromNumber { get; set; }

        public string ToNumber { get; set; }

        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime FromTransactionDate { get; set; }

        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ToTransactionDate { get; set; }

        public string ViewID { get; set; }

        public string HomeCurrencyDecimals { get; set; } = "3";

        public bool IsARActive { get; set; } = true;

        public bool IsICActive { get; set; } = true;

        public bool IsGLActive { get; set; } = true;

        public bool IsPOActive { get; set; } = true;

        public bool IsARMultiCurrency { get; set; }

        public string FractQty { get; set; }

        public bool HasSNLTLicense { get; set; }

    }
}