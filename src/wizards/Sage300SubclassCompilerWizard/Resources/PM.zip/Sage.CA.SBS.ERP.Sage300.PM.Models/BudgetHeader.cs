// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for BudgetHeader
    /// </summary>
    public partial class BudgetHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets ContractUniq
        /// </summary>
        [Display(Name = "ContractUniq", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.ContractUniq, Id = Index.ContractUniq, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ContractUniq { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTRACT", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string CONTRACT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FMTCONTNO", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FMTCONTNO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets BUDUNIQ
        /// </summary>
        [Display(Name = "BUDUNIQ", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.BUDUNIQ, Id = Index.BUDUNIQ, FieldType = EntityFieldType.Long, Size = 4)]
        public int BUDUNIQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FROMPMBUDS
        /// </summary>
        [Display(Name = "FROMPMBUDS", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.FROMPMBUDS, Id = Index.FROMPMBUDS, FieldType = EntityFieldType.Int, Size = 2)]
        public short FROMPMBUDS { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets RateRecalculationChecked
        /// </summary>
        public string RateRecalculationChecked { get; set; }
    }
}
