// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for Options
    /// </summary>
    public partial class Options : ModelBase
    {
        /// <summary>
        /// Gets or sets Dummy
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Dummy", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Dummy, Id = Index.Dummy, FieldType = EntityFieldType.Int, Size = 2)]
        public short Dummy { get; set; }

        /// <summary>
        /// Gets or sets ContactName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets Telephone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Telephone", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Telephone, Id = Index.Telephone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Telephone { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FaxNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "HomeCurrency", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.HomeCurrency, Id = Index.HomeCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets DefaultOverheadType
        /// </summary>
        [Display(Name = "DefaultOverheadType", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultOverheadType, Id = Index.DefaultOverheadType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OOHTYPE DefaultOverheadType { get; set; }

        /// <summary>
        /// Gets or sets OverheadRate
        /// </summary>
        [Display(Name = "OverheadRate", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.OverheadRate, Id = Index.OverheadRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OverheadPercentage
        /// </summary>
        [Display(Name = "OverheadPercentage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.OverheadPercentage, Id = Index.OverheadPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OverheadPercentage { get; set; }

        /// <summary>
        /// Gets or sets DefaultLaborType
        /// </summary>
        [Display(Name = "DefaultLaborType", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultLaborType, Id = Index.DefaultLaborType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.LaborType DefaultLaborType { get; set; }

        /// <summary>
        /// Gets or sets LaborRate
        /// </summary>
        [Display(Name = "LaborRate", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.LaborRate, Id = Index.LaborRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LaborRate { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentage
        /// </summary>
        [Display(Name = "LaborPercentage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.LaborPercentage, Id = Index.LaborPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LaborPercentage { get; set; }

        /// <summary>
        /// Gets or sets EditImportedBatches
        /// </summary>
        [Display(Name = "EditImportedBatches", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EditImportedBatches, Id = Index.EditImportedBatches, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EditImportedBatches { get; set; }

        /// <summary>
        /// Gets or sets ForceListingOfTransactions
        /// </summary>
        [Display(Name = "ForceListingOfTransactions", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ForceListingOfTransactions, Id = Index.ForceListingOfTransactions, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForceListingOfTransactions { get; set; }

        /// <summary>
        /// Gets or sets DefaultAccountingMethod
        /// </summary>
        [Display(Name = "DefaultAccountingMethod", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultAccountingMethod, Id = Index.DefaultAccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod DefaultAccountingMethod { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PAYROLL
        /// </summary>
        [Display(Name = "PAYROLL", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.PAYROLL, Id = Index.PAYROLL, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Payroll PAYROLL { get; set; }

        /// <summary>
        /// Gets or sets CreateGLTransactions
        /// </summary>
        [Display(Name = "CreateGLTransactions", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.CreateGLTransactions, Id = Index.CreateGLTransactions, FieldType = EntityFieldType.Bool, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CreateGLTransactions CreateGLTransactions { get; set; }

        /// <summary>
        /// Gets or sets AppendGLBatch
        /// </summary>
        [Display(Name = "AppendGLBatch", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AppendGLBatch, Id = Index.AppendGLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AppendGLBatch AppendGLBatch { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateGLBatches
        /// </summary>
        [Display(Name = "ConsolidateGLBatches", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ConsolidateGLBatches, Id = Index.ConsolidateGLBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ConsolidateGLBatches ConsolidateGLBatches { get; set; }

        /// <summary>
        /// Gets or sets GLReferenceFieldNotUsed
        /// </summary>
        [Display(Name = "GLReferenceFieldNotUsed", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.GLReferenceFieldNotUsed, Id = Index.GLReferenceFieldNotUsed, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.GLReferenceFieldNotUsed GLReferenceFieldNotUsed { get; set; }

        /// <summary>
        /// Gets or sets GLDescriptionFieldNotUsed
        /// </summary>
        [Display(Name = "GLDescriptionFieldNotUsed", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.GLDescriptionFieldNotUsed, Id = Index.GLDescriptionFieldNotUsed, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.GLDescriptionFieldNotUsed GLDescriptionFieldNotUsed { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets NXTCHRGSEQ
        /// </summary>
        [Display(Name = "NXTCHRGSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NXTCHRGSEQ, Id = Index.NXTCHRGSEQ, FieldType = EntityFieldType.Long, Size = 4)]
        public int NXTCHRGSEQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets NXTEQIPSEQ
        /// </summary>
        [Display(Name = "NXTEQIPSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NXTEQIPSEQ, Id = Index.NXTEQIPSEQ, FieldType = EntityFieldType.Long, Size = 4)]
        public int NXTEQIPSEQ { get; set; }

        /// <summary>
        /// Gets or sets ReviseEstimates
        /// </summary>
        [Display(Name = "ReviseEstimates", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ReviseEstimates, Id = Index.ReviseEstimates, FieldType = EntityFieldType.Long, Size = 4)]
        public int ReviseEstimates { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets NXTCARDSEQ
        /// </summary>
        [Display(Name = "NXTCARDSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NXTCARDSEQ, Id = Index.NXTCARDSEQ, FieldType = EntityFieldType.Long, Size = 4)]
        public int NXTCARDSEQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets NXTRRSEQ
        /// </summary>
        [Display(Name = "NXTRRSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NXTRRSEQ, Id = Index.NXTRRSEQ, FieldType = EntityFieldType.Long, Size = 4)]
        public int NXTRRSEQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets NXTADJSEQ
        /// </summary>
        [Display(Name = "NXTADJSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NXTADJSEQ, Id = Index.NXTADJSEQ, FieldType = EntityFieldType.Long, Size = 4)]
        public int NXTADJSEQ { get; set; }

        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [Display(Name = "Cost", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets Invoice
        /// </summary>
        [Display(Name = "Invoice", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Invoice, Id = Index.Invoice, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal Invoice { get; set; }

        /// <summary>
        /// Gets or sets Timecard
        /// </summary>
        [Display(Name = "Timecard", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Timecard, Id = Index.Timecard, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal Timecard { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets STKABTCH
        /// </summary>
        [Display(Name = "STKABTCH", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.STKABTCH, Id = Index.STKABTCH, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal STKABTCH { get; set; }

        /// <summary>
        /// Gets or sets MaterialReturn
        /// </summary>
        [Display(Name = "MaterialReturn", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.MaterialReturn, Id = Index.MaterialReturn, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal MaterialReturn { get; set; }

        /// <summary>
        /// Gets or sets ProjectAndJobCosting
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectAndJobCosting", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ProjectAndJobCosting, Id = Index.ProjectAndJobCosting, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ProjectAndJobCosting { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets STKALLSC
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "STKALLSC", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.STKALLSC, Id = Index.STKALLSC, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string STKALLSC { get; set; }

        /// <summary>
        /// Gets or sets MaterialReturns
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MaterialReturns", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.MaterialReturns, Id = Index.MaterialReturns, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string MaterialReturns { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TIMECARDSC
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TIMECARDSC", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.TIMECARDSC, Id = Index.TIMECARDSC, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TIMECARDSC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RRSC
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RRSC", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.RRSC, Id = Index.RRSC, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RRSC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EQUIPSC
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EQUIPSC", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EQUIPSC, Id = Index.EQUIPSC, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string EQUIPSC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CHRGSC
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CHRGSC", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.CHRGSC, Id = Index.CHRGSC, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CHRGSC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ADJSC
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ADJSC", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ADJSC, Id = Index.ADJSC, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ADJSC { get; set; }

        /// <summary>
        /// Gets or sets DefaultARRetainagePercentage
        /// </summary>
        [Display(Name = "DefaultARRetainagePercentage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultARRetainagePercentage, Id = Index.DefaultARRetainagePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DefaultARRetainagePercentage { get; set; }

        /// <summary>
        /// Gets or sets DefaultARRetainageNoOfDays
        /// </summary>
        [Display(Name = "DefaultARRetainageNoOfDays", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultARRetainageNoOfDays, Id = Index.DefaultARRetainageNoOfDays, FieldType = EntityFieldType.Int, Size = 2)]
        public short DefaultARRetainageNoOfDays { get; set; }

        /// <summary>
        /// Gets or sets DefaultAPRetainagePercentage
        /// </summary>
        [Display(Name = "DefaultAPRetainagePercentage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultAPRetainagePercentage, Id = Index.DefaultAPRetainagePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DefaultAPRetainagePercentage { get; set; }

        /// <summary>
        /// Gets or sets DefaultAPRetainageNoOfDays
        /// </summary>
        [Display(Name = "DefaultAPRetainageNoOfDays", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultAPRetainageNoOfDays, Id = Index.DefaultAPRetainageNoOfDays, FieldType = EntityFieldType.Int, Size = 2)]
        public short DefaultAPRetainageNoOfDays { get; set; }

        /// <summary>
        /// Gets or sets DateLastRevenueRecognition
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastRevenueRecognition", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastRevenueRecognition, Id = Index.DateLastRevenueRecognition, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastRevenueRecognition { get; set; }

        /// <summary>
        /// Gets or sets TimeLastRevenueRecognition
        /// </summary>
        [Display(Name = "TimeLastRevenueRecognition", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.TimeLastRevenueRecognition, Id = Index.TimeLastRevenueRecognition, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan TimeLastRevenueRecognition { get; set; }

        /// <summary>
        /// Gets or sets DateLastBillingWorksheet
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastBillingWorksheet", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastBillingWorksheet, Id = Index.DateLastBillingWorksheet, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastBillingWorksheet { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaterialUsage
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastMaterialUsage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastMaterialUsage, Id = Index.DateLastMaterialUsage, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaterialUsage { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaterialReturn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastMaterialReturn", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastMaterialReturn, Id = Index.DateLastMaterialReturn, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaterialReturn { get; set; }

        /// <summary>
        /// Gets or sets DateLastTimecard
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastTimecard", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastTimecard, Id = Index.DateLastTimecard, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastTimecard { get; set; }

        /// <summary>
        /// Gets or sets DateLastCostBatchPosted
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastCostBatchPosted", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastCostBatchPosted, Id = Index.DateLastCostBatchPosted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastCostBatchPosted { get; set; }

        /// <summary>
        /// Gets or sets DateLastInvoiceBatchPosted
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastInvoiceBatchPosted", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastInvoiceBatchPosted, Id = Index.DateLastInvoiceBatchPosted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastInvoiceBatchPosted { get; set; }

        /// <summary>
        /// Gets or sets DateLastChargesPosted
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastChargesPosted", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastChargesPosted, Id = Index.DateLastChargesPosted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastChargesPosted { get; set; }

        /// <summary>
        /// Gets or sets DateLastEquipmentUsage
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastEquipmentUsage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastEquipmentUsage, Id = Index.DateLastEquipmentUsage, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastEquipmentUsage { get; set; }

        /// <summary>
        /// Gets or sets DateLastRevisedEstimatesPost
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastRevisedEstimatesPost", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DateLastRevisedEstimatesPost, Id = Index.DateLastRevisedEstimatesPost, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastRevisedEstimatesPost { get; set; }

        /// <summary>
        /// Gets or sets AllowEditOfGLCodesInAR
        /// </summary>
        [Display(Name = "AllowEditOfGLCodesInAR", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AllowEditOfGLCodesInAR, Id = Index.AllowEditOfGLCodesInAR, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowEditOfGLCodesInAR { get; set; }

        /// <summary>
        /// Gets or sets AllowEditOfGLCodesInAP
        /// </summary>
        [Display(Name = "AllowEditOfGLCodesInAP", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AllowEditOfGLCodesInAP, Id = Index.AllowEditOfGLCodesInAP, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowEditOfGLCodesInAP { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod1
        /// </summary>
        [Display(Name = "AgingPeriod1", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod2
        /// </summary>
        [Display(Name = "AgingPeriod2", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod3
        /// </summary>
        [Display(Name = "AgingPeriod3", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets Level1Name
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level1Name", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Level1Name, Id = Index.Level1Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level1Name { get; set; }

        /// <summary>
        /// Gets or sets Level2Name
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level2Name", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Level2Name, Id = Index.Level2Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level2Name { get; set; }

        /// <summary>
        /// Gets or sets Level3Name
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level3Name", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Level3Name, Id = Index.Level3Name, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level3Name { get; set; }

        /// <summary>
        /// Gets or sets DefaultContractStructure
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultContractStructure", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultContractStructure, Id = Index.DefaultContractStructure, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultContractStructure { get; set; }

        /// <summary>
        /// Gets or sets UseHypen
        /// </summary>
        [Display(Name = "UseHypen", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseHypen, Id = Index.UseHypen, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseHypen { get; set; }

        /// <summary>
        /// Gets or sets UseForwardSlash
        /// </summary>
        [Display(Name = "UseForwardSlash", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseForwardSlash, Id = Index.UseForwardSlash, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseForwardSlash { get; set; }

        /// <summary>
        /// Gets or sets UseBackSlash
        /// </summary>
        [Display(Name = "UseBackSlash", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseBackSlash, Id = Index.UseBackSlash, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseBackSlash { get; set; }

        /// <summary>
        /// Gets or sets UseAsterisk
        /// </summary>
        [Display(Name = "UseAsterisk", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseAsterisk, Id = Index.UseAsterisk, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseAsterisk { get; set; }

        /// <summary>
        /// Gets or sets UsePeriod
        /// </summary>
        [Display(Name = "UsePeriod", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UsePeriod, Id = Index.UsePeriod, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UsePeriod { get; set; }

        /// <summary>
        /// Gets or sets UseLeftParenthesis
        /// </summary>
        [Display(Name = "UseLeftParenthesis", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseLeftParenthesis, Id = Index.UseLeftParenthesis, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseLeftParenthesis { get; set; }

        /// <summary>
        /// Gets or sets UseRightParenthesis
        /// </summary>
        [Display(Name = "UseRightParenthesis", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseRightParenthesis, Id = Index.UseRightParenthesis, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseRightParenthesis { get; set; }

        /// <summary>
        /// Gets or sets UsePoundSign
        /// </summary>
        [Display(Name = "UsePoundSign", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UsePoundSign, Id = Index.UsePoundSign, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UsePoundSign { get; set; }

        /// <summary>
        /// Gets or sets TimeCardPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TimeCardPrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.TimeCardPrefix, Id = Index.TimeCardPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TimeCardPrefix { get; set; }

        /// <summary>
        /// Gets or sets TimecardNumberLength
        /// </summary>
        [Display(Name = "TimecardNumberLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.TimecardNumberLength, Id = Index.TimecardNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal TimecardNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextTimecardNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextTimecardNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextTimecardNumber, Id = Index.NextTimecardNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string NextTimecardNumber { get; set; }

        /// <summary>
        /// Gets or sets MaterialUsagePrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MaterialUsagePrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.MaterialUsagePrefix, Id = Index.MaterialUsagePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string MaterialUsagePrefix { get; set; }

        /// <summary>
        /// Gets or sets MaterialUsageNumberLength
        /// </summary>
        [Display(Name = "MaterialUsageNumberLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.MaterialUsageNumberLength, Id = Index.MaterialUsageNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal MaterialUsageNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextMaterialUsageNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextMaterialUsageNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextMaterialUsageNumber, Id = Index.NextMaterialUsageNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string NextMaterialUsageNumber { get; set; }

        /// <summary>
        /// Gets or sets MaterialReturnPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MaterialReturnPrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.MaterialReturnPrefix, Id = Index.MaterialReturnPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string MaterialReturnPrefix { get; set; }

        /// <summary>
        /// Gets or sets MaterialReturnNumberLength
        /// </summary>
        [Display(Name = "MaterialReturnNumberLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.MaterialReturnNumberLength, Id = Index.MaterialReturnNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal MaterialReturnNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextMaterialReturnsNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextMaterialReturnsNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextMaterialReturnsNumber, Id = Index.NextMaterialReturnsNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string NextMaterialReturnsNumber { get; set; }

        /// <summary>
        /// Gets or sets EquipmentUsagePrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EquipmentUsagePrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EquipmentUsagePrefix, Id = Index.EquipmentUsagePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string EquipmentUsagePrefix { get; set; }

        /// <summary>
        /// Gets or sets EquipmentUsageNumberLength
        /// </summary>
        [Display(Name = "EquipmentUsageNumberLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EquipmentUsageNumberLength, Id = Index.EquipmentUsageNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal EquipmentUsageNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextEquipmentUsageNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextEquipmentUsageNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextEquipmentUsageNumber, Id = Index.NextEquipmentUsageNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string NextEquipmentUsageNumber { get; set; }

        /// <summary>
        /// Gets or sets RevisedEstimatePrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedEstimatePrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.RevisedEstimatePrefix, Id = Index.RevisedEstimatePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RevisedEstimatePrefix { get; set; }

        /// <summary>
        /// Gets or sets RevisedEstimateNumberLength
        /// </summary>
        [Display(Name = "RevisedEstimateNumberLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.RevisedEstimateNumberLength, Id = Index.RevisedEstimateNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RevisedEstimateNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextRevisedEstimateNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextRevisedEstimateNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextRevisedEstimateNumber, Id = Index.NextRevisedEstimateNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string NextRevisedEstimateNumber { get; set; }

        /// <summary>
        /// Gets or sets ChargePrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ChargePrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ChargePrefix, Id = Index.ChargePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ChargePrefix { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TEXTADJPF
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TEXTADJPF", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.TEXTADJPF, Id = Index.TEXTADJPF, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TEXTADJPF { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumberLength
        /// </summary>
        [Display(Name = "AdjustmentNumberLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AdjustmentNumberLength, Id = Index.AdjustmentNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal AdjustmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextAdjustmentNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextAdjustmentNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextAdjustmentNumber, Id = Index.NextAdjustmentNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string NextAdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets ChargeNumberLength
        /// </summary>
        [Display(Name = "ChargeNumberLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ChargeNumberLength, Id = Index.ChargeNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal ChargeNumberLength { get; set; }

        /// <summary>
        /// Gets or sets NextChargeNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextChargeNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextChargeNumber, Id = Index.NextChargeNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string NextChargeNumber { get; set; }

        /// <summary>
        /// Gets or sets NextContractUnique
        /// </summary>
        [Display(Name = "NextContractUnique", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextContractUnique, Id = Index.NextContractUnique, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextContractUnique { get; set; }

        /// <summary>
        /// Gets or sets ARBilling
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARBilling", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ARBilling, Id = Index.ARBilling, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string ARBilling { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CNTRRSEQ
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CNTRRSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.CNTRRSEQ, Id = Index.CNTRRSEQ, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16D")]
        public string CNTRRSEQ { get; set; }

        /// <summary>
        /// Gets or sets ARBillingPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARBillingPrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ARBillingPrefix, Id = Index.ARBillingPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ARBillingPrefix { get; set; }

        /// <summary>
        /// Gets or sets RevenueRecognitionPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueRecognitionPrefix", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.RevenueRecognitionPrefix, Id = Index.RevenueRecognitionPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RevenueRecognitionPrefix { get; set; }

        /// <summary>
        /// Gets or sets ARBillingLength
        /// </summary>
        [Display(Name = "ARBillingLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ARBillingLength, Id = Index.ARBillingLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal ARBillingLength { get; set; }

        /// <summary>
        /// Gets or sets RevenueRecognitionLength
        /// </summary>
        [Display(Name = "RevenueRecognitionLength", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.RevenueRecognitionLength, Id = Index.RevenueRecognitionLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RevenueRecognitionLength { get; set; }

        /// <summary>
        /// Gets or sets AllowEditOfProjectType
        /// </summary>
        [Display(Name = "AllowEditOfProjectType", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AllowEditOfProjectType, Id = Index.AllowEditOfProjectType, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowEditOfProjectType { get; set; }

        /// <summary>
        /// Gets or sets DefaultARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultARItemNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultARItemNumber, Id = Index.DefaultARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string DefaultARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultARUnitOfMeasure", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultARUnitOfMeasure, Id = Index.DefaultARUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string DefaultARUnitOfMeasure { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PAYROLLTC
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PAYROLLTC", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.PAYROLLTC, Id = Index.PAYROLLTC, FieldType = EntityFieldType.Char, Size = 6)]
        public string PAYROLLTC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GLEQIPSEQ
        /// </summary>
        [Display(Name = "GLEQIPSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.GLEQIPSEQ, Id = Index.GLEQIPSEQ, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal GLEQIPSEQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GLCARDSEQ
        /// </summary>
        [Display(Name = "GLCARDSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.GLCARDSEQ, Id = Index.GLCARDSEQ, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal GLCARDSEQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GLRRSEQ
        /// </summary>
        [Display(Name = "GLRRSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.GLRRSEQ, Id = Index.GLRRSEQ, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal GLRRSEQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets GLADJSEQ
        /// </summary>
        [Display(Name = "GLADJSEQ", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.GLADJSEQ, Id = Index.GLADJSEQ, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal GLADJSEQ { get; set; }

        /// <summary>
        /// Gets or sets Level1NamePlural
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level1NamePlural", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Level1NamePlural, Id = Index.Level1NamePlural, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level1NamePlural { get; set; }

        /// <summary>
        /// Gets or sets Level2NamePlural
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level2NamePlural", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Level2NamePlural, Id = Index.Level2NamePlural, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level2NamePlural { get; set; }

        /// <summary>
        /// Gets or sets Level3NamePlural
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Level3NamePlural", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Level3NamePlural, Id = Index.Level3NamePlural, FieldType = EntityFieldType.Char, Size = 30)]
        public string Level3NamePlural { get; set; }

        /// <summary>
        /// Gets or sets Costs
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Costs", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Costs, Id = Index.Costs, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string Costs { get; set; }

        /// <summary>
        /// Gets or sets ReopenProjects
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReopenProjects", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ReopenProjects, Id = Index.ReopenProjects, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ReopenProjects { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Int, Size = 2)]
        public short Description { get; set; }

        /// <summary>
        /// Gets or sets DecimalsForMaterialQuantity
        /// </summary>
        [Display(Name = "DecimalsForMaterialQuantity", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DecimalsForMaterialQuantity, Id = Index.DecimalsForMaterialQuantity, FieldType = EntityFieldType.Int, Size = 2)]
        public short DecimalsForMaterialQuantity { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public short Function { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets DefaultOverheadType string value
        /// </summary>
        public string DefaultOverheadTypeString
        {
         get { return EnumUtility.GetStringValue(DefaultOverheadType); }
        }

        /// <summary>
        /// Gets DefaultLaborType string value
        /// </summary>
        public string DefaultLaborTypeString
        {
         get { return EnumUtility.GetStringValue(DefaultLaborType); }
        }

        /// <summary>
        /// Gets DefaultAccountingMethod string value
        /// </summary>
        public string DefaultAccountingMethodString
        {
         get { return EnumUtility.GetStringValue(DefaultAccountingMethod); }
        }

        /// <summary>
        /// Gets PAYROLL string value
        /// </summary>
        public string PAYROLLString
        {
         get { return EnumUtility.GetStringValue(PAYROLL); }
        }

        /// <summary>
        /// Gets CreateGLTransactions string value
        /// </summary>
        public string CreateGLTransactionsString
        {
         get { return EnumUtility.GetStringValue(CreateGLTransactions); }
        }

        /// <summary>
        /// Gets AppendGLBatch string value
        /// </summary>
        public string AppendGLBatchString
        {
         get { return EnumUtility.GetStringValue(AppendGLBatch); }
        }

        /// <summary>
        /// Gets ConsolidateGLBatches string value
        /// </summary>
        public string ConsolidateGLBatchesString
        {
         get { return EnumUtility.GetStringValue(ConsolidateGLBatches); }
        }

        /// <summary>
        /// Gets GLReferenceFieldNotUsed string value
        /// </summary>
        public string GLReferenceFieldNotUsedString
        {
         get { return EnumUtility.GetStringValue(GLReferenceFieldNotUsed); }
        }

        /// <summary>
        /// Gets GLDescriptionFieldNotUsed string value
        /// </summary>
        public string GLDescriptionFieldNotUsedString
        {
         get { return EnumUtility.GetStringValue(GLDescriptionFieldNotUsed); }
        }

        #endregion
    }
}
