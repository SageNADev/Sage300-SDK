// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for TimecardTimeDetail
    /// </summary>
    public partial class TimecardTimeDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber)]
        public short LineNumber { get; set; }

        /// <summary>
        /// Gets or sets TimecardNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TimecardNumber", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TimecardNumber, Id = Index.TimecardNumber)]
        public string TimecardNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FMTCONTNO", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO)]
        public string FMTCONTNO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTRACT", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT)]
        public string CONTRACT { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project)]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category)]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets EarningsCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EarningsCode", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.EarningsCode, Id = Index.EarningsCode)]
        public string EarningsCode { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.DESC, Id = Index.DESC)]
        public string DESC { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets TimeType
        /// </summary>
        [Display(Name = "TimeType", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TimeType, Id = Index.TimeType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.TimeType TimeType { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets StartTime
        /// </summary>
        [Display(Name = "StartTime", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.StartTime, Id = Index.StartTime)]
        public TimeSpan StartTime { get; set; }

        /// <summary>
        /// Gets or sets EndTime
        /// </summary>
        [Display(Name = "EndTime", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.EndTime, Id = Index.EndTime)]
        public TimeSpan EndTime { get; set; }

        /// <summary>
        /// Gets or sets Hours
        /// </summary>
        [Display(Name = "Hours", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Hours, Id = Index.Hours)]
        public decimal Hours { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber)]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets RevenueAndCostCurrency
        /// </summary>
        [Display(Name = "RevenueAndCostCurrency", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.RevenueAndCostCurrency, Id = Index.RevenueAndCostCurrency)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RevenueAndCostCurrency RevenueAndCostCurrency { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency)]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency)]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost)]
        public decimal UnitCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTSR
        /// </summary>
        [Display(Name = "EXTCOSTSR", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.EXTCOSTSR, Id = Index.EXTCOSTSR)]
        public decimal EXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTHM
        /// </summary>
        [Display(Name = "EXTCOSTHM", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.EXTCOSTHM, Id = Index.EXTCOSTHM)]
        public decimal EXTCOSTHM { get; set; }

        /// <summary>
        /// Gets or sets ExtendedBillingAmount
        /// </summary>
        [Display(Name = "ExtendedBillingAmount", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.ExtendedBillingAmount, Id = Index.ExtendedBillingAmount)]
        public decimal ExtendedBillingAmount { get; set; }

        /// <summary>
        /// Gets or sets LaborType
        /// </summary>
        [Display(Name = "LaborType", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LaborType, Id = Index.LaborType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.LaborType LaborType { get; set; }

        /// <summary>
        /// Gets or sets LaborRate
        /// </summary>
        [Display(Name = "LaborRate", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LaborRate, Id = Index.LaborRate)]
        public decimal LaborRate { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentage
        /// </summary>
        [Display(Name = "LaborPercentage", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LaborPercentage, Id = Index.LaborPercentage)]
        public decimal LaborPercentage { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LABORSR
        /// </summary>
        [Display(Name = "LABORSR", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LABORSR, Id = Index.LABORSR)]
        public decimal LABORSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LABORHM
        /// </summary>
        [Display(Name = "LABORHM", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LABORHM, Id = Index.LABORHM)]
        public decimal LABORHM { get; set; }

        /// <summary>
        /// Gets or sets OverheadType
        /// </summary>
        [Display(Name = "OverheadType", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.OverheadType, Id = Index.OverheadType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OverheadType OverheadType { get; set; }

        /// <summary>
        /// Gets or sets OverheadRate
        /// </summary>
        [Display(Name = "OverheadRate", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.OverheadRate, Id = Index.OverheadRate)]
        public decimal OverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OverheadPercentage
        /// </summary>
        [Display(Name = "OverheadPercentage", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.OverheadPercentage, Id = Index.OverheadPercentage)]
        public decimal OverheadPercentage { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHSR
        /// </summary>
        [Display(Name = "OHSR", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.OHSR, Id = Index.OHSR)]
        public decimal OHSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHHM
        /// </summary>
        [Display(Name = "OHHM", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.OHHM, Id = Index.OHHM)]
        public decimal OHHM { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate)]
        public decimal BillingRate { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTSR
        /// </summary>
        [Display(Name = "TOTCOSTSR", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TOTCOSTSR, Id = Index.TOTCOSTSR)]
        public decimal TOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTHM
        /// </summary>
        [Display(Name = "TOTCOSTHM", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TOTCOSTHM, Id = Index.TOTCOSTHM)]
        public decimal TOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTBILLSR
        /// </summary>
        [Display(Name = "TOTBILLSR", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TOTBILLSR, Id = Index.TOTBILLSR)]
        public decimal TOTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTBILLHM
        /// </summary>
        [Display(Name = "TOTBILLHM", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TOTBILLHM, Id = Index.TOTBILLHM)]
        public decimal TOTBILLHM { get; set; }

        /// <summary>
        /// Gets or sets PayrollAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayrollAccount", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.PayrollAccount, Id = Index.PayrollAccount)]
        public string PayrollAccount { get; set; }

        /// <summary>
        /// Gets or sets WorkInProgressAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgressAccount", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.WorkInProgressAccount, Id = Index.WorkInProgressAccount)]
        public string WorkInProgressAccount { get; set; }

        /// <summary>
        /// Gets or sets OverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OverheadAccount", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.OverheadAccount, Id = Index.OverheadAccount)]
        public string OverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets LaborAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LaborAccount", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LaborAccount, Id = Index.LaborAccount)]
        public string LaborAccount { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets BillAmountBasedOn
        /// </summary>
        [Display(Name = "BillAmountBasedOn", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.BillAmountBasedOn, Id = Index.BillAmountBasedOn)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillAmountBasedOn BillAmountBasedOn { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1)]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2)]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3)]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4)]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5)]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1)]
        public short TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2)]
        public short TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3)]
        public short TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4)]
        public short TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5)]
        public short TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        [Display(Name = "ContractStyle", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer)]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.InvoiceType InvoiceType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        [Display(Name = "VALUES", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.VALUES, Id = Index.VALUES)]
        public int VALUES { get; set; }

        /// <summary>
        /// Gets or sets GLDetailDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailDescription", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.GLDetailDescription, Id = Index.GLDetailDescription)]
        public string GLDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets GLDetailReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailReference", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.GLDetailReference, Id = Index.GLDetailReference)]
        public string GLDetailReference { get; set; }

        /// <summary>
        /// Gets or sets GLDetailComment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailComment", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.GLDetailComment, Id = Index.GLDetailComment)]
        public string GLDetailComment { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource)]
        public string Resource { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PAYRDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PAYRDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.PAYRDESC, Id = Index.PAYRDESC)]
        public string PAYRDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets WIPDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WIPDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.WIPDESC, Id = Index.WIPDESC)]
        public string WIPDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ITEMDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ITEMDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.ITEMDESC, Id = Index.ITEMDESC)]
        public string ITEMDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OHDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.OHDESC, Id = Index.OHDESC)]
        public string OHDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LABORDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LABORDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.LABORDESC, Id = Index.LABORDESC)]
        public string LABORDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets WARN
        /// </summary>
        [Display(Name = "WARN", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.WARN, Id = Index.WARN)]
        public bool WARN { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.CONTDESC, Id = Index.CONTDESC)]
        public string CONTDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROJDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PROJDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.PROJDESC, Id = Index.PROJDESC)]
        public string PROJDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CATDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CATDESC", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.CATDESC, Id = Index.CATDESC)]
        public string CATDESC { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        [Display(Name = "HASOPT", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.HASOPT, Id = Index.HASOPT)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.HASOPT HASOPT { get; set; }

        /// <summary>
        /// Gets or sets CalledByPMTIMET
        /// </summary>
        [Display(Name = "CalledByPMTIMET", ResourceType = typeof (TimecardTimeDetailResx))]
        [ViewField(Name = Fields.CalledByPMTIMET, Id = Index.CalledByPMTIMET)]
        public bool CalledByPMTIMET { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TimeType string value
        /// </summary>
        public string TimeTypeString => EnumUtility.GetStringValue(TimeType);

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString => EnumUtility.GetStringValue(BillingType);

        /// <summary>
        /// Gets RevenueAndCostCurrency string value
        /// </summary>
        public string RevenueAndCostCurrencyString => EnumUtility.GetStringValue(RevenueAndCostCurrency);

        /// <summary>
        /// Gets LaborType string value
        /// </summary>
        public string LaborTypeString => EnumUtility.GetStringValue(LaborType);

        /// <summary>
        /// Gets OverheadType string value
        /// </summary>
        public string OverheadTypeString => EnumUtility.GetStringValue(OverheadType);

        /// <summary>
        /// Gets BillAmountBasedOn string value
        /// </summary>
        public string BillAmountBasedOnString => EnumUtility.GetStringValue(BillAmountBasedOn);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString => EnumUtility.GetStringValue(ContractStyle);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString => EnumUtility.GetStringValue(InvoiceType);

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString => EnumUtility.GetStringValue(Function);

        /// <summary>
        /// Gets HASOPT string value
        /// </summary>
        public string HASOPTString => EnumUtility.GetStringValue(HASOPT);

        #endregion
    }
}
