// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for MaterialAllocationDetail
    /// </summary>
    public partial class MaterialAllocationDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets MaterialAllocationNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MaterialAllocationNumber", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.MaterialAllocationNumber, Id = Index.MaterialAllocationNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string MaterialAllocationNumber { get; set; }

        /// <summary>
        /// Gets or sets FormattedContractNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedContractNumber", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.FormattedContractNumber, Id = Index.FormattedContractNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FormattedContractNumber { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets CostMethod
        /// </summary>
        [Display(Name = "CostMethod", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.CostMethod, Id = Index.CostMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public short CostMethod { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets UOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocatedUnitOfMeasure", ResourceType = typeof(MaterialAllocationDetailResx))]
        public string AllocatedUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets AllocatedQuantity
        /// </summary>
        [Display(Name = "AllocatedQuantity", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.AllocatedQuantity, Id = Index.AllocatedQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal AllocatedQuantity { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets ExtendedBillingAmount
        /// </summary>
        [Display(Name = "ExtendedBillingAmount", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ExtendedBillingAmount, Id = Index.ExtendedBillingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedBillingAmount { get; set; }

        /// <summary>
        /// Gets or sets BillingAmountFunc
        /// </summary>
        [Display(Name = "BillingAmountFunc", ResourceType = typeof(MaterialAllocationDetailResx))]
        public decimal BillingAmountFunc { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets PercentageAllocated
        /// </summary>
        [Display(Name = "PercentageAllocated", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.PercentageAllocated, Id = Index.PercentageAllocated, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentageAllocated { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAllocatedCost
        /// </summary>
        [Display(Name = "ExtendedAllocatedCost", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ExtendedAllocatedCost, Id = Index.ExtendedAllocatedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedAllocatedCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSource
        /// </summary>
        [Display(Name = "TotalCostSource", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.TotalCostSource, Id = Index.TotalCostSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSource { get; set; }

        /// <summary>
        /// Gets or sets TotalCostFunctional
        /// </summary>
        [Display(Name = "TotalCostFunctional", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.TotalCostFunctional, Id = Index.TotalCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets StoredOverhead
        /// </summary>
        [Display(Name = "StoredOverhead", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.StoredOverhead, Id = Index.StoredOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StoredOverhead { get; set; }

        /// <summary>
        /// Gets or sets OverheadAllocated
        /// </summary>
        [Display(Name = "OverheadAllocated", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.OverheadAllocated, Id = Index.OverheadAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAllocated { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets Style
        /// </summary>
        [Display(Name = "Style", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Style, Id = Index.Style, FieldType = EntityFieldType.Int, Size = 2)]
        public short Style { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12)]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets Values
        /// </summary>
        [Display(Name = "Values", ResourceType = typeof(MaterialAllocationDetailResx))]
        public int Values { get; set; }

        /// <summary>
        /// Gets or sets StoredQuantity
        /// </summary>
        [Display(Name = "StoredQuantity", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.StoredQuantity, Id = Index.StoredQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal StoredQuantity { get; set; }

        /// <summary>
        /// Gets or sets ExtendedStoredCost
        /// </summary>
        [Display(Name = "ExtendedStoredCost", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ExtendedStoredCost, Id = Index.ExtendedStoredCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedStoredCost { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public short FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Conversion
        /// </summary>
        [Display(Name = "Conversion", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Conversion, Id = Index.Conversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Conversion { get; set; }

        /// <summary>
        /// Gets or sets StoredUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StoredUnitOfMeasure", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.StoredUnitOfMeasure, Id = Index.StoredUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string StoredUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets StoredConversionFactor
        /// </summary>
        [Display(Name = "StoredConversionFactor", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.StoredConversionFactor, Id = Index.StoredConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal StoredConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        /// <summary>
        /// Gets or sets LocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDescription", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationDescription { get; set; }

        ///// <summary>
        ///// Gets or sets HasOptionalFields
        ///// </summary>
        //[Display(Name = "HasOptionalFields", ResourceType = typeof(MaterialAllocationDetailResx))]
        //[ViewField(Name = Fields.HasOptionalFields, Id = Index.HasOptionalFields, FieldType = EntityFieldType.Bool, Size = 2)]
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.HASOPT HasOptionalFields { get; set; }

        /// <summary>
        ///  Gets HasOptionalFields
        /// </summary>
        public bool HasOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ContractDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractDescription", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ContractDescription, Id = Index.ContractDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractDescription { get; set; }

        /// <summary>
        /// Gets or sets ProjectDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectDescription", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.ProjectDescription, Id = Index.ProjectDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ProjectDescription { get; set; }

        /// <summary>
        /// Gets or sets CategoryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof(MaterialAllocationDetailResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString
        {
            get { return EnumUtility.GetStringValue(BillingType); }
        }

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString
        {
            get { return EnumUtility.GetStringValue(ProjectType); }
        }

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString
        {
            get { return EnumUtility.GetStringValue(AccountingMethod); }
        }

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString
        {
            get { return EnumUtility.GetStringValue(InvoiceType); }
        }

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
            get { return EnumUtility.GetStringValue(Function); }
        }

        ///// <summary>
        ///// Gets HASOPT string value
        ///// </summary>
        //public string HASOPTString
        //{
        //    get { return EnumUtility.GetStringValue(HasOptionalFields); }
        //}

        #endregion
    }
}
