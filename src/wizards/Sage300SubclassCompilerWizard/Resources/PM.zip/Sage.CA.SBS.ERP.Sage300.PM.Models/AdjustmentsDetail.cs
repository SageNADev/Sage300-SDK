// Copyright (c) 2022 Sage  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for AdjustmentsDetail
    /// </summary>

    public partial class AdjustmentsDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdjustmentNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.AdjustmentNumber, Id = Index.AdjustmentNumber)]
        public string AdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentType
        /// </summary>
        [Display(Name = "AdjustmentType", ResourceType = typeof (PMCommonResx))]
        [ViewField(Name = Fields.AdjustmentType, Id = Index.AdjustmentType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AdjustmentType AdjustmentType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalContract", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO)]
        public string FMTCONTNO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalContract", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT)]
        public string CONTRACT { get; set; }

        /// <summary>
        /// Gets or sets OriginalProject
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalProject", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalProject, Id = Index.OriginalProject)]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets OriginalCategory
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalCategory", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalCategory, Id = Index.OriginalCategory)]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets OriginalResource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalResource", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalResource, Id = Index.OriginalResource)]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets FromUnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromUnformattedItemNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FromUnformattedItemNumber, Id = Index.FromUnformattedItemNumber)]
        public string FromUnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CostOrRevenue
        /// </summary>
        [Display(Name = "CostOrRevenue", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.CostOrRevenue, Id = Index.CostOrRevenue)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CostOrRevenue CostOrRevenue { get; set; }

        /// <summary>
        /// Gets or sets CostNumber
        /// </summary>
        [Display(Name = "CostNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.CostNumber, Id = Index.CostNumber)]
        public int CostNumber { get; set; }

        /// <summary>
        /// Gets or sets RevenueNumber
        /// </summary>
        [Display(Name = "RevenueNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevenueNumber, Id = Index.RevenueNumber)]
        public int RevenueNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber)]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalBillingType
        /// </summary>
        [Display(Name = "OriginalBillingType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalBillingType, Id = Index.OriginalBillingType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OriginalBillingType OriginalBillingType { get; set; }

        /// <summary>
        /// Gets or sets OriginalARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalARItemNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalARItemNumber, Id = Index.OriginalARItemNumber)]
        public string OriginalARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalARUnitOfMeasure", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalARUnitOfMeasure, Id = Index.OriginalARUnitOfMeasure)]
        public string OriginalARUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets OriginalICUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalICUnitOfMeasure", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalICUnitOfMeasure, Id = Index.OriginalICUnitOfMeasure)]
        public string OriginalICUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets OriginalQuantity
        /// </summary>
        [Display(Name = "OriginalQuantity", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalQuantity, Id = Index.OriginalQuantity)]
        public decimal OriginalQuantity { get; set; }

        /// <summary>
        /// Gets or sets OriginalUnitCost
        /// </summary>
        [Display(Name = "OriginalUnitCost", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalUnitCost, Id = Index.OriginalUnitCost)]
        public decimal OriginalUnitCost { get; set; }

        /// <summary>
        /// Gets or sets OriginalBillingRate
        /// </summary>
        [Display(Name = "OriginalBillingRate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalBillingRate, Id = Index.OriginalBillingRate)]
        public decimal OriginalBillingRate { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OEXTCOSTHM
        /// </summary>
        [Display(Name = "OriginalExtendedCost", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OEXTCOSTHM, Id = Index.OEXTCOSTHM)]
        public decimal OEXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OEXTCOSTSR
        /// </summary>
        [Display(Name = "OriginalExtendedCost", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OEXTCOSTSR, Id = Index.OEXTCOSTSR)]
        public decimal OEXTCOSTSR { get; set; }

        /// <summary>
        /// Gets or sets OriginalExtendedBillingAmount
        /// </summary>
        [Display(Name = "OriginalExtendedBillingAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalExtendedBillingAmount, Id = Index.OriginalExtendedBillingAmount)]
        public decimal OriginalExtendedBillingAmount { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborType
        /// </summary>
        [Display(Name = "OriginalLaborType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalLaborType, Id = Index.OriginalLaborType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OriginalLaborType OriginalLaborType { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborRate
        /// </summary>
        [Display(Name = "OriginalLaborRate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalLaborRate, Id = Index.OriginalLaborRate)]
        public decimal OriginalLaborRate { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborPercentage
        /// </summary>
        [Display(Name = "OriginalLaborPercentage", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalLaborPercentage, Id = Index.OriginalLaborPercentage)]
        public decimal OriginalLaborPercentage { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborAmount
        /// </summary>
        [Display(Name = "OriginalLaborAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalLaborAmount, Id = Index.OriginalLaborAmount)]
        public decimal OriginalLaborAmount { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadType
        /// </summary>
        [Display(Name = "OriginalOverheadType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalOverheadType, Id = Index.OriginalOverheadType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OriginalOverheadType OriginalOverheadType { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadRate
        /// </summary>
        [Display(Name = "OriginalOverheadRate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalOverheadRate, Id = Index.OriginalOverheadRate)]
        public decimal OriginalOverheadRate { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadPercentage
        /// </summary>
        [Display(Name = "OriginalOverheadPercentage", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalOverheadPercentage, Id = Index.OriginalOverheadPercentage)]
        public decimal OriginalOverheadPercentage { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadAmount
        /// </summary>
        [Display(Name = "OriginalOverheadAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalOverheadAmount, Id = Index.OriginalOverheadAmount)]
        public decimal OriginalOverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets OriginalTotalAmount
        /// </summary>
        [Display(Name = "OriginalTotalAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalTotalAmount, Id = Index.OriginalTotalAmount)]
        public decimal OriginalTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets OriginalBillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalBillingCurrency", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalBillingCurrency, Id = Index.OriginalBillingCurrency)]
        public string OriginalBillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets OriginalProjectStyle
        /// </summary>
        [Display(Name = "OriginalProjectStyle", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalProjectStyle, Id = Index.OriginalProjectStyle)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OriginalProjectStyle OriginalProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets OriginalProjectType
        /// </summary>
        [Display(Name = "OriginalProjectType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalProjectType, Id = Index.OriginalProjectType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OriginalProjectType OriginalProjectType { get; set; }

        /// <summary>
        /// Gets or sets OriginalCustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalCustomerNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalCustomerNumber, Id = Index.OriginalCustomerNumber)]
        public string OriginalCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalAccountingMethod
        /// </summary>
        [Display(Name = "OriginalAccountingMethod", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalAccountingMethod, Id = Index.OriginalAccountingMethod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OriginalAccountingMethod OriginalAccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets OriginalInvoiceType
        /// </summary>
        [Display(Name = "OriginalInvoiceType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalInvoiceType, Id = Index.OriginalInvoiceType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OriginalInvoiceType OriginalInvoiceType { get; set; }

        /// <summary>
        /// Gets or sets FromWIPAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromWIPAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FromWIPAccount, Id = Index.FromWIPAccount)]
        public string FromWIPAccount { get; set; }

        /// <summary>
        /// Gets or sets FromTransactionAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromTransactionAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FromTransactionAccount, Id = Index.FromTransactionAccount)]
        public string FromTransactionAccount { get; set; }

        /// <summary>
        /// Gets or sets FromRevenueAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromRevenueAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FromRevenueAccount, Id = Index.FromRevenueAccount)]
        public string FromRevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets FromOverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromOverheadAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FromOverheadAccount, Id = Index.FromOverheadAccount)]
        public string FromOverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets FromLaborAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromLaborAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FromLaborAccount, Id = Index.FromLaborAccount)]
        public string FromLaborAccount { get; set; }

        /// <summary>
        /// Gets or sets FromCostVarianceAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromCostVarianceAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FromCostVarianceAccount, Id = Index.FromCostVarianceAccount)]
        public string FromCostVarianceAccount { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod)]
        public short FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor)]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets Module
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Module", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.Module, Id = Index.Module)]
        public string Module { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.DocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency)]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID)]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets TimeType
        /// </summary>
        [Display(Name = "TimeType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.TimeType, Id = Index.TimeType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.TimeType TimeType { get; set; }

        /// <summary>
        /// Gets or sets ToWIPAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToWIPAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ToWIPAccount, Id = Index.ToWIPAccount)]
        public string ToWIPAccount { get; set; }

        /// <summary>
        /// Gets or sets ToTransactionAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToTransactionAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ToTransactionAccount, Id = Index.ToTransactionAccount)]
        public string ToTransactionAccount { get; set; }

        /// <summary>
        /// Gets or sets ToRevenueAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToRevenueAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ToRevenueAccount, Id = Index.ToRevenueAccount)]
        public string ToRevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets ToOverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToOverheadAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ToOverheadAccount, Id = Index.ToOverheadAccount)]
        public string ToOverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets ToLaborAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToLaborAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ToLaborAccount, Id = Index.ToLaborAccount)]
        public string ToLaborAccount { get; set; }

        /// <summary>
        /// Gets or sets ToCostVarianceAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToCostVarianceAccount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ToCostVarianceAccount, Id = Index.ToCostVarianceAccount)]
        public string ToCostVarianceAccount { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DFMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedContract", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.DFMTCONTNO, Id = Index.DFMTCONTNO)]
        public string DFMTCONTNO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DCONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedContract", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.DCONTRACT, Id = Index.DCONTRACT)]
        public string DCONTRACT { get; set; }

        /// <summary>
        /// Gets or sets RevisedProject
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedProject", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedProject, Id = Index.RevisedProject)]
        public string RevisedProject { get; set; }

        /// <summary>
        /// Gets or sets RevisedCategory
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedCategory", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedCategory, Id = Index.RevisedCategory)]
        public string RevisedCategory { get; set; }

        /// <summary>
        /// Gets or sets CostType
        /// </summary>
        [Display(Name = "CostType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.CostType, Id = Index.CostType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CostType CostType { get; set; }

        /// <summary>
        /// Gets or sets RevisedResource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedResource", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedResource, Id = Index.RevisedResource)]
        public string RevisedResource { get; set; }

        /// <summary>
        /// Gets or sets ToUnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToUnformattedItemNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ToUnformattedItemNumber, Id = Index.ToUnformattedItemNumber)]
        public string ToUnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ICBucketType
        /// </summary>
        [Display(Name = "ICBucketType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ICBucketType, Id = Index.ICBucketType)]
        public Models.Enums.ICBucketType ICBucketType { get; set; }

        /// <summary>
        /// Gets or sets ICDocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICDocumentNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ICDocumentNumber, Id = Index.ICDocumentNumber)]
        public string ICDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets ICCostingMethod
        /// </summary>
        [Display(Name = "ICCostingMethod", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ICCostingMethod, Id = Index.ICCostingMethod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ICCostingMethod ICCostingMethod { get; set; }

        /// <summary>
        /// Gets or sets ICTransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICTransactionDate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ICTransactionDate, Id = Index.ICTransactionDate)]
        public DateTime ICTransactionDate { get; set; }

        /// <summary>
        /// Gets or sets ICLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICLocation", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ICLocation, Id = Index.ICLocation)]
        public string ICLocation { get; set; }

        /// <summary>
        /// Gets or sets RevisedBillingType
        /// </summary>
        [Display(Name = "RevisedBillingType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedBillingType, Id = Index.RevisedBillingType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RevisedBillingType RevisedBillingType { get; set; }

        /// <summary>
        /// Gets or sets RevisedARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedARItemNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedARItemNumber, Id = Index.RevisedARItemNumber)]
        public string RevisedARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets RevisedARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedARUnitOfMeasure", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedARUnitOfMeasure, Id = Index.RevisedARUnitOfMeasure)]
        public string RevisedARUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets RevisedICUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedICUnitOfMeasure", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedICUnitOfMeasure, Id = Index.RevisedICUnitOfMeasure)]
        public string RevisedICUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets RevisedQuantity
        /// </summary>
        [Display(Name = "RevisedQuantity", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedQuantity, Id = Index.RevisedQuantity)]
        public decimal RevisedQuantity { get; set; }

        /// <summary>
        /// Gets or sets RevisedUnitCost
        /// </summary>
        [Display(Name = "RevisedUnitCost", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedUnitCost, Id = Index.RevisedUnitCost)]
        public decimal RevisedUnitCost { get; set; }

        /// <summary>
        /// Gets or sets RevisedBillingRate
        /// </summary>
        [Display(Name = "RevisedBillingRate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedBillingRate, Id = Index.RevisedBillingRate)]
        public decimal RevisedBillingRate { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DEXTCOSTHM
        /// </summary>
        [Display(Name = "DEXTCOSTHM", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.DEXTCOSTHM, Id = Index.DEXTCOSTHM)]
        public decimal DEXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets DEXTCOSTSR
        /// </summary>
        [Display(Name = "DEXTCOSTSR", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.DEXTCOSTSR, Id = Index.DEXTCOSTSR)]
        public decimal DEXTCOSTSR { get; set; }

        /// <summary>
        /// Gets or sets RevisedExtendedBillingAmount
        /// </summary>
        [Display(Name = "RevisedExtendedBillingAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedExtendedBillingAmount, Id = Index.RevisedExtendedBillingAmount)]
        public decimal RevisedExtendedBillingAmount { get; set; }

        /// <summary>
        /// Gets or sets RevisedLaborType
        /// </summary>
        [Display(Name = "RevisedLaborType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedLaborType, Id = Index.RevisedLaborType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RevisedLaborType RevisedLaborType { get; set; }

        /// <summary>
        /// Gets or sets RevisedLaborRate
        /// </summary>
        [Display(Name = "RevisedLaborRate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedLaborRate, Id = Index.RevisedLaborRate)]
        public decimal RevisedLaborRate { get; set; }

        /// <summary>
        /// Gets or sets RevisedLaborPercentage
        /// </summary>
        [Display(Name = "RevisedLaborPercentage", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedLaborPercentage, Id = Index.RevisedLaborPercentage)]
        public decimal RevisedLaborPercentage { get; set; }

        /// <summary>
        /// Gets or sets RevisedLaborAmount
        /// </summary>
        [Display(Name = "RevisedLaborAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedLaborAmount, Id = Index.RevisedLaborAmount)]
        public decimal RevisedLaborAmount { get; set; }

        /// <summary>
        /// Gets or sets RevisedOverheadAmount
        /// </summary>
        [Display(Name = "RevisedOverheadAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedOverheadAmount, Id = Index.RevisedOverheadAmount)]
        public decimal RevisedOverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets RevisedOverheadType
        /// </summary>
        [Display(Name = "RevisedOverheadType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedOverheadType, Id = Index.RevisedOverheadType)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RevisedOverheadType RevisedOverheadType { get; set; }

        /// <summary>
        /// Gets or sets RevisedOverheadRate
        /// </summary>
        [Display(Name = "RevisedOverheadRate", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedOverheadRate, Id = Index.RevisedOverheadRate)]
        public decimal RevisedOverheadRate { get; set; }

        /// <summary>
        /// Gets or sets RevisedOverheadPercentage
        /// </summary>
        [Display(Name = "RevisedOverheadPercentage", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedOverheadPercentage, Id = Index.RevisedOverheadPercentage)]
        public decimal RevisedOverheadPercentage { get; set; }

        /// <summary>
        /// Gets or sets RevisedTotalAmount
        /// </summary>
        [Display(Name = "RevisedTotalAmount", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedTotalAmount, Id = Index.RevisedTotalAmount)]
        public decimal RevisedTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets RevisedBillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedBillingCurrency", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedBillingCurrency, Id = Index.RevisedBillingCurrency)]
        public string RevisedBillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets RevisedProjectStyle
        /// </summary>
        [Display(Name = "RevisedProjectStyle", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedProjectStyle, Id = Index.RevisedProjectStyle)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RevisedProjectStyle RevisedProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets RevisedProjectType
        /// </summary>
        [Display(Name = "RevisedProjectType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedProjectType, Id = Index.RevisedProjectType)]
        public Models.Enums.RevisedProjectType RevisedProjectType { get; set; }

        /// <summary>
        /// Gets or sets RevisedCustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedCustomerNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedCustomerNumber, Id = Index.RevisedCustomerNumber)]
        public string RevisedCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets RevisedAccountingMethod
        /// </summary>
        [Display(Name = "RevisedAccountingMethod", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedAccountingMethod, Id = Index.RevisedAccountingMethod)]
        public Models.Enums.RevisedAccountingMethod RevisedAccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets RevisedInvoiceType
        /// </summary>
        [Display(Name = "RevisedInvoiceType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedInvoiceType, Id = Index.RevisedInvoiceType)]
        public Enums.RevisedInvoiceType RevisedInvoiceType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets MANITEM
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MANITEM", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.MANITEM, Id = Index.MANITEM)]
        public string MANITEM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        [Display(Name = "VALUES", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.VALUES, Id = Index.VALUES)]
        public int VALUES { get; set; }

        /// <summary>
        /// Gets or sets OriginalEarningsCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalEarningsCode", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalEarningsCode, Id = Index.OriginalEarningsCode)]
        public string OriginalEarningsCode { get; set; }

        /// <summary>
        /// Gets or sets RevisedEarningsCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedEarningsCode", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedEarningsCode, Id = Index.RevisedEarningsCode)]
        public string RevisedEarningsCode { get; set; }

        /// <summary>
        /// Gets or sets OriginalPayType
        /// </summary>
        [Display(Name = "OriginalPayType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalPayType, Id = Index.OriginalPayType)]
        public Enums.OriginalPayType OriginalPayType { get; set; }

        /// <summary>
        /// Gets or sets RevisedPayType
        /// </summary>
        [Display(Name = "RevisedPayType", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedPayType, Id = Index.RevisedPayType)]
        public Enums.RevisedPayType RevisedPayType { get; set; }

        /// <summary>
        /// Gets or sets GLDetailDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailDescription", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.GLDetailDescription, Id = Index.GLDetailDescription)]
        public string GLDetailDescription { get; set; }

        /// <summary>
        /// Gets or sets GLDetailReference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailReference", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.GLDetailReference, Id = Index.GLDetailReference)]
        public string GLDetailReference { get; set; }

        /// <summary>
        /// Gets or sets GLDetailComment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLDetailComment", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.GLDetailComment, Id = Index.GLDetailComment)]
        public string GLDetailComment { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        [Display(Name = "CloseSN", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.CloseSN, Id = Index.CloseSN)]
        public bool CloseSN { get; set; }

        /// <summary>
        /// Gets or sets SNInterCommunicationID
        /// </summary>
        [Display(Name = "SNInterCommunicationID", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.SNInterCommunicationID, Id = Index.SNInterCommunicationID)]
        public int SNInterCommunicationID { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        [Display(Name = "PopupSN", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.PopupSN, Id = Index.PopupSN)]
        public short PopupSN { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        [Display(Name = "PopupLT", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.PopupLT, Id = Index.PopupLT)]
        public short PopupLT { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [Display(Name = "CloseLT", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.CloseLT, Id = Index.CloseLT)]
        public bool CloseLT { get; set; }

        /// <summary>
        /// Gets or sets LTInterCommunicationID
        /// </summary>
        [Display(Name = "LTInterCommunicationID", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.LTInterCommunicationID, Id = Index.LTInterCommunicationID)]
        public int LTInterCommunicationID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSN
        /// </summary>
        [Display(Name = "ForcePopupSN", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ForcePopupSN, Id = Index.ForcePopupSN)]
        public bool ForcePopupSN { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLT
        /// </summary>
        [Display(Name = "ForcePopupLT", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.ForcePopupLT, Id = Index.ForcePopupLT)]
        public bool ForcePopupLT { get; set; }

        /// <summary>
        /// Gets or sets GenerateICSequence
        /// </summary>
        [Display(Name = "GenerateICSequence", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.GenerateICSequence, Id = Index.GenerateICSequence)]
        public bool GenerateICSequence { get; set; }

        /// <summary>
        /// Gets or sets OriginalEmployeeNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalEmployeeNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.OriginalEmployeeNumber, Id = Index.OriginalEmployeeNumber)]
        public string OriginalEmployeeNumber { get; set; }

        /// <summary>
        /// Gets or sets RevisedEmployeeNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevisedEmployeeNumber", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.RevisedEmployeeNumber, Id = Index.RevisedEmployeeNumber)]
        public string RevisedEmployeeNumber { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        [Display(Name = "HASOPT", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.HASOPT, Id = Index.HASOPT)]
        public Enums.HASOPT HASOPT { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (AdjustmentsResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function)]
        public Enums.Function Function { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets AdjustmentType string value
        /// </summary>
        public string AdjustmentTypeString => EnumUtility.GetStringValue(AdjustmentType);

        /// <summary>
        /// Gets CostOrRevenue string value
        /// </summary>
        public string CostOrRevenueString => EnumUtility.GetStringValue(CostOrRevenue);

        /// <summary>
        /// Gets OriginalBillingType string value
        /// </summary>
        public string OriginalBillingTypeString => EnumUtility.GetStringValue(OriginalBillingType);

        /// <summary>
        /// Gets OriginalLaborType string value
        /// </summary>
        public string OriginalLaborTypeString => EnumUtility.GetStringValue(OriginalLaborType);

        /// <summary>
        /// Gets OriginalOverheadType string value
        /// </summary>
        public string OriginalOverheadTypeString => EnumUtility.GetStringValue(OriginalOverheadType);

        /// <summary>
        /// Gets OriginalProjectStyle string value
        /// </summary>
        public string OriginalProjectStyleString => EnumUtility.GetStringValue(OriginalProjectStyle);

        /// <summary>
        /// Gets OriginalProjectType string value
        /// </summary>
        public string OriginalProjectTypeString => EnumUtility.GetStringValue(OriginalProjectType);

        /// <summary>
        /// Gets OriginalAccountingMethod string value
        /// </summary>
        public string OriginalAccountingMethodString => EnumUtility.GetStringValue(OriginalAccountingMethod);

        /// <summary>
        /// Gets OriginalInvoiceType string value
        /// </summary>
        public string OriginalInvoiceTypeString => EnumUtility.GetStringValue(OriginalInvoiceType);

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        public string DocumentTypeString => EnumUtility.GetStringValue(DocumentType);

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        public string TransactionTypeString => EnumUtility.GetStringValue(TransactionType);

        /// <summary>
        /// Gets TimeType string value
        /// </summary>
        public string TimeTypeString => EnumUtility.GetStringValue(TimeType);

        /// <summary>
        /// Gets CostType string value
        /// </summary>
        public string CostTypeString => EnumUtility.GetStringValue(CostType);

        /// <summary>
        /// Gets ICBucketType string value
        /// </summary>
        public string ICBucketTypeString => EnumUtility.GetStringValue(ICBucketType);

        /// <summary>
        /// Gets ICCostingMethod string value
        /// </summary>
        public string ICCostingMethodString => EnumUtility.GetStringValue(ICCostingMethod);

        /// <summary>
        /// Gets RevisedBillingType string value
        /// </summary>
        public string RevisedBillingTypeString => EnumUtility.GetStringValue(RevisedBillingType);

        /// <summary>
        /// Gets RevisedLaborType string value
        /// </summary>
        public string RevisedLaborTypeString => EnumUtility.GetStringValue(RevisedLaborType);

        /// <summary>
        /// Gets RevisedOverheadType string value
        /// </summary>
        public string RevisedOverheadTypeString => EnumUtility.GetStringValue(RevisedOverheadType);

        /// <summary>
        /// Gets RevisedProjectStyle string value
        /// </summary>
        public string RevisedProjectStyleString => EnumUtility.GetStringValue(RevisedProjectStyle);

        /// <summary>
        /// Gets RevisedProjectType string value
        /// </summary>
        public string RevisedProjectTypeString => EnumUtility.GetStringValue(RevisedProjectType);

        /// <summary>
        /// Gets RevisedAccountingMethod string value
        /// </summary>
        public string RevisedAccountingMethodString => EnumUtility.GetStringValue(RevisedAccountingMethod);

        /// <summary>
        /// Gets RevisedInvoiceType string value
        /// </summary>
        public string RevisedInvoiceTypeString => EnumUtility.GetStringValue(RevisedInvoiceType);

        /// <summary>
        /// Gets OriginalPayType string value
        /// </summary>
        public string OriginalPayTypeString => EnumUtility.GetStringValue(OriginalPayType);

        /// <summary>
        /// Gets RevisedPayType string value
        /// </summary>
        public string RevisedPayTypeString => EnumUtility.GetStringValue(RevisedPayType);

        /// <summary>
        /// Gets HASOPT string value
        /// </summary>
        public string HASOPTString => EnumUtility.GetStringValue(HASOPT);

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString => EnumUtility.GetStringValue(Function);

        #endregion
    }
}
