// Copyright (c) 2018 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for Projects
    /// </summary>
    public partial class Projects : ModelBase
    {
        /// <summary>
        /// Gets or sets ContractUniq
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractUniq", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ContractUniq, Id = Index.ContractUniq, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ContractUniq { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets ProjectedStartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectedStartDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ProjectedStartDate, Id = Index.ProjectedStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ProjectedStartDate { get; set; }

        /// <summary>
        /// Gets or sets ProjectedEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectedEndDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ProjectedEndDate, Id = Index.ProjectedEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ProjectedEndDate { get; set; }

        /// <summary>
        /// Gets or sets CurrentEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentEndDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentEndDate, Id = Index.CurrentEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CurrentEndDate { get; set; }

        /// <summary>
        /// Gets or sets DateClosed
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateClosed", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.DateClosed, Id = Index.DateClosed, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateClosed { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets CostPlusPercentage
        /// </summary>
        [Display(Name = "CostPlusPercentage", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CostPlusPercentage, Id = Index.CostPlusPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CostPlusPercentage { get; set; }

        /// <summary>
        /// Gets or sets ClosedToBillings
        /// </summary>
        [Display(Name = "ClosedToBillings", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ClosedToBillings, Id = Index.ClosedToBillings, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ClosedToBillings { get; set; }

        /// <summary>
        /// Gets or sets ClosedToCosts
        /// </summary>
        [Display(Name = "ClosedToCosts", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ClosedToCosts, Id = Index.ClosedToCosts, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ClosedToCosts { get; set; }

        /// <summary>
        /// Gets or sets ProjectStatus
        /// </summary>
        [Display(Name = "ProjectStatus", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ProjectStatus, Id = Index.ProjectStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectStatus ProjectStatus { get; set; }

        /// <summary>
        /// Gets or sets RevenueType
        /// </summary>
        [Display(Name = "RevenueType", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RevenueType, Id = Index.RevenueType, FieldType = EntityFieldType.Int, Size = 2)]
        public RevenueType RevenueType { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets ARRetainagePercentage
        /// </summary>
        [Display(Name = "ARRetainagePercentage", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ARRetainagePercentage, Id = Index.ARRetainagePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal ARRetainagePercentage { get; set; }

        /// <summary>
        /// Gets or sets ARRetentionPeriod
        /// </summary>
        [Display(Name = "ARRetentionPeriod", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ARRetentionPeriod, Id = Index.ARRetentionPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ARRetentionPeriod { get; set; }

        /// <summary>
        /// Gets or sets Billings
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Billings", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Billings, Id = Index.Billings, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Billings { get; set; }

        /// <summary>
        /// Gets or sets DeferredRevenue
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DeferredRevenue", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.DeferredRevenue, Id = Index.DeferredRevenue, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DeferredRevenue { get; set; }

        /// <summary>
        /// Gets or sets Revenue
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Revenue", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Revenue, Id = Index.Revenue, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Revenue { get; set; }

        /// <summary>
        /// Gets or sets Profit
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Profit", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Profit, Id = Index.Profit, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Profit { get; set; }

        /// <summary>
        /// Gets or sets Loss
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Loss", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Loss, Id = Index.Loss, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Loss { get; set; }

        /// <summary>
        /// Gets or sets Gain
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Gain", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Gain, Id = Index.Gain, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Gain { get; set; }

        /// <summary>
        /// Gets or sets WorkInProgress
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgress", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.WorkInProgress, Id = Index.WorkInProgress, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string WorkInProgress { get; set; }

        /// <summary>
        /// Gets or sets CostOfSales
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostOfSales", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CostOfSales, Id = Index.CostOfSales, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CostOfSales { get; set; }

        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets FormCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormCode", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.FormCode, Id = Index.FormCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FormCode { get; set; }

        /// <summary>
        /// Gets or sets ARInvoiceType
        /// </summary>
        [Display(Name = "ARInvoiceType", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ARInvoiceType, Id = Index.ARInvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.InvoiceType ARInvoiceType { get; set; }

        /// <summary>
        /// Gets or sets OriginalExchangeRate
        /// </summary>
        [Display(Name = "OriginalExchangeRate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalExchangeRate, Id = Index.OriginalExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OriginalExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets OriginalRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalRateType", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalRateType, Id = Index.OriginalRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string OriginalRateType { get; set; }

        /// <summary>
        /// Gets or sets OriginalRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalRateDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalRateDate, Id = Index.OriginalRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime OriginalRateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RATEOP
        /// </summary>
        [Display(Name = "RATEOP", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperator RateOperator { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RevenueAndCostCurrency
        /// </summary>
        [Display(Name = "RevenueAndCostCurrency", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RevenueAndCostCurrency, Id = Index.RevenueAndCostCurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public RevenueAndCostCurrency RevenueAndCostCurrency { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets RevenueCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueCurrency", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RevenueCurrency, Id = Index.RevenueCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string RevenueCurrency { get; set; }

        /// <summary>
        /// Gets or sets InvoiceStatus
        /// </summary>
        [Display(Name = "InvoiceStatus", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.InvoiceStatus, Id = Index.InvoiceStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceStatus InvoiceStatus { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCategories
        /// </summary>
        [Display(Name = "NumberOfCategories", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.NumberOfCategories, Id = Index.NumberOfCategories, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfCategories { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborCostEst
        /// </summary>
        [Display(Name = "OriginalLaborCostEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalLaborCostEst, Id = Index.OriginalLaborCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalLaborCostEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyLaborCostEst
        /// </summary>
        [Display(Name = "CurrencyLaborCostEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyLaborCostEst, Id = Index.CurrencyLaborCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyLaborCostEst { get; set; }

        /// <summary>
        /// Gets or sets ActualLaborCosts
        /// </summary>
        [Display(Name = "ActualLaborCosts", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualLaborCosts, Id = Index.ActualLaborCosts, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualLaborCosts { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJTIMEBSR
        /// </summary>
        [Display(Name = "ORJTIMEBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJTIMEBSR, Id = Index.ORJTIMEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJTIMEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJTIMEBHM
        /// </summary>
        [Display(Name = "ORJTIMEBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJTIMEBHM, Id = Index.ORJTIMEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJTIMEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURTIMEBSR
        /// </summary>
        [Display(Name = "CURTIMEBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURTIMEBSR, Id = Index.CURTIMEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURTIMEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURTIMEBHM
        /// </summary>
        [Display(Name = "CURTIMEBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURTIMEBHM, Id = Index.CURTIMEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURTIMEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTTIMEBSR
        /// </summary>
        [Display(Name = "ACTTIMEBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTTIMEBSR, Id = Index.ACTTIMEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTTIMEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTTIMEBHM
        /// </summary>
        [Display(Name = "ACTTIMEBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTTIMEBHM, Id = Index.ACTTIMEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTTIMEBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborQtyEst
        /// </summary>
        [Display(Name = "OriginalLaborQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalLaborQtyEst, Id = Index.OriginalLaborQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalLaborQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyLaborQtyEst
        /// </summary>
        [Display(Name = "CurrencyLaborQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyLaborQtyEst, Id = Index.CurrencyLaborQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyLaborQtyEst { get; set; }

        /// <summary>
        /// Gets or sets ActualLaborQty
        /// </summary>
        [Display(Name = "ActualLaborQty", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualLaborQty, Id = Index.ActualLaborQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualLaborQty { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentageComplete
        /// </summary>
        [Display(Name = "LaborPercentageComplete", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LaborPercentageComplete, Id = Index.LaborPercentageComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LaborPercentageComplete { get; set; }

        /// <summary>
        /// Gets or sets OriginalMaterialEstimatedCost
        /// </summary>
        [Display(Name = "OriginalMaterialEstimatedCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalMaterialEstimatedCost, Id = Index.OriginalMaterialEstimatedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalMaterialEstimatedCost { get; set; }

        /// <summary>
        /// Gets or sets CurrentMaterialEstimatedCost
        /// </summary>
        [Display(Name = "CurrentMaterialEstimatedCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentMaterialEstimatedCost, Id = Index.CurrentMaterialEstimatedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentMaterialEstimatedCost { get; set; }

        /// <summary>
        /// Gets or sets ActualMaterialCost
        /// </summary>
        [Display(Name = "ActualMaterialCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualMaterialCost, Id = Index.ActualMaterialCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualMaterialCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMATEBSR
        /// </summary>
        [Display(Name = "ORJMATEBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJMATEBSR, Id = Index.ORJMATEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMATEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMATEBHM
        /// </summary>
        [Display(Name = "ORJMATEBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJMATEBHM, Id = Index.ORJMATEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMATEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMATEBSR
        /// </summary>
        [Display(Name = "CURMATEBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURMATEBSR, Id = Index.CURMATEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMATEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMATEBHM
        /// </summary>
        [Display(Name = "CURMATEBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURMATEBHM, Id = Index.CURMATEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMATEBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMATEBSR
        /// </summary>
        [Display(Name = "ACTMATEBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTMATEBSR, Id = Index.ACTMATEBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMATEBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMATEBHM
        /// </summary>
        [Display(Name = "ACTMATEBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTMATEBHM, Id = Index.ACTMATEBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMATEBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalMaterialQtyEst
        /// </summary>
        [Display(Name = "OriginalMaterialQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalMaterialQtyEst, Id = Index.OriginalMaterialQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalMaterialQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyMaterialEst
        /// </summary>
        [Display(Name = "CurrencyMaterialEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyMaterialEst, Id = Index.CurrencyMaterialEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyMaterialEst { get; set; }

        /// <summary>
        /// Gets or sets ActualMaterialQty
        /// </summary>
        [Display(Name = "ActualMaterialQty", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualMaterialQty, Id = Index.ActualMaterialQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualMaterialQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalEstimatedEquipmentCost
        /// </summary>
        [Display(Name = "OriginalEstimatedEquipmentCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalEstimatedEquipmentCost, Id = Index.OriginalEstimatedEquipmentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEstimatedEquipmentCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEstimatedEquipmentCost
        /// </summary>
        [Display(Name = "CurrencyEstimatedEquipmentCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyEstimatedEquipmentCost, Id = Index.CurrencyEstimatedEquipmentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyEstimatedEquipmentCost { get; set; }

        /// <summary>
        /// Gets or sets ActualEquipmentCost
        /// </summary>
        [Display(Name = "ActualEquipmentCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualEquipmentCost, Id = Index.ActualEquipmentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualEquipmentCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJEQUIBSR
        /// </summary>
        [Display(Name = "ORJEQUIBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJEQUIBSR, Id = Index.ORJEQUIBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJEQUIBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJEQUIBHM
        /// </summary>
        [Display(Name = "ORJEQUIBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJEQUIBHM, Id = Index.ORJEQUIBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJEQUIBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUREQUIBSR
        /// </summary>
        [Display(Name = "CUREQUIBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CUREQUIBSR, Id = Index.CUREQUIBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUREQUIBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUREQUIBHM
        /// </summary>
        [Display(Name = "CUREQUIBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CUREQUIBHM, Id = Index.CUREQUIBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUREQUIBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTEQUIBSR
        /// </summary>
        [Display(Name = "ACTEQUIBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTEQUIBSR, Id = Index.ACTEQUIBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTEQUIBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTEQUIBHM
        /// </summary>
        [Display(Name = "ACTEQUIBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTEQUIBHM, Id = Index.ACTEQUIBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTEQUIBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalEquipmentQtyEst
        /// </summary>
        [Display(Name = "OriginalEquipmentQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalEquipmentQtyEst, Id = Index.OriginalEquipmentQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalEquipmentQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEquipmentEst
        /// </summary>
        [Display(Name = "CurrencyEquipmentEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyEquipmentEst, Id = Index.CurrencyEquipmentEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyEquipmentEst { get; set; }

        /// <summary>
        /// Gets or sets ActualEquipmentQty
        /// </summary>
        [Display(Name = "ActualEquipmentQty", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualEquipmentQty, Id = Index.ActualEquipmentQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualEquipmentQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalSubcontractorEstCost
        /// </summary>
        [Display(Name = "OriginalSubcontractorEstCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalSubcontractorEstCost, Id = Index.OriginalSubcontractorEstCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalSubcontractorEstCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencySubcontractorEstCost
        /// </summary>
        [Display(Name = "CurrencySubcontractorEstCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencySubcontractorEstCost, Id = Index.CurrencySubcontractorEstCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencySubcontractorEstCost { get; set; }

        /// <summary>
        /// Gets or sets ActualSubcontractorCost
        /// </summary>
        [Display(Name = "ActualSubcontractorCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualSubcontractorCost, Id = Index.ActualSubcontractorCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualSubcontractorCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJSUBCBSR
        /// </summary>
        [Display(Name = "ORJSUBCBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJSUBCBSR, Id = Index.ORJSUBCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJSUBCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJSUBCBHM
        /// </summary>
        [Display(Name = "ORJSUBCBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJSUBCBHM, Id = Index.ORJSUBCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJSUBCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURSUBCBSR
        /// </summary>
        [Display(Name = "CURSUBCBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURSUBCBSR, Id = Index.CURSUBCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURSUBCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURSUBCBHM
        /// </summary>
        [Display(Name = "CURSUBCBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURSUBCBHM, Id = Index.CURSUBCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURSUBCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTSUBCBSR
        /// </summary>
        [Display(Name = "ACTSUBCBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTSUBCBSR, Id = Index.ACTSUBCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTSUBCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTSUBCBHM
        /// </summary>
        [Display(Name = "ACTSUBCBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTSUBCBHM, Id = Index.ACTSUBCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTSUBCBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalSubcontractorQtyEst
        /// </summary>
        [Display(Name = "OriginalSubcontractorQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalSubcontractorQtyEst, Id = Index.OriginalSubcontractorQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalSubcontractorQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencySubcontractorEst
        /// </summary>
        [Display(Name = "CurrencySubcontractorEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencySubcontractorEst, Id = Index.CurrencySubcontractorEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencySubcontractorEst { get; set; }

        /// <summary>
        /// Gets or sets ActualSubcontractorQty
        /// </summary>
        [Display(Name = "ActualSubcontractorQty", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualSubcontractorQty, Id = Index.ActualSubcontractorQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualSubcontractorQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalEstOverheadExpenseCost
        /// </summary>
        [Display(Name = "OriginalEstOverheadExpenseCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalEstOverheadExpenseCost, Id = Index.OriginalEstOverheadExpenseCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEstOverheadExpenseCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEstOverheadExpenseCost
        /// </summary>
        [Display(Name = "CurrencyEstOverheadExpenseCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyEstOverheadExpenseCost, Id = Index.CurrencyEstOverheadExpenseCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyEstOverheadExpenseCost { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadExpenseCost
        /// </summary>
        [Display(Name = "ActualOverheadExpenseCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualOverheadExpenseCost, Id = Index.ActualOverheadExpenseCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverheadExpenseCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJOHEXBSR
        /// </summary>
        [Display(Name = "ORJOHEXBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJOHEXBSR, Id = Index.ORJOHEXBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJOHEXBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJOHEXBHM
        /// </summary>
        [Display(Name = "ORJOHEXBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJOHEXBHM, Id = Index.ORJOHEXBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJOHEXBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUROHEXBSR
        /// </summary>
        [Display(Name = "CUROHEXBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CUROHEXBSR, Id = Index.CUROHEXBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUROHEXBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CUROHEXBHM
        /// </summary>
        [Display(Name = "CUROHEXBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CUROHEXBHM, Id = Index.CUROHEXBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CUROHEXBHM { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadAmountBilled
        /// </summary>
        [Display(Name = "ActualOverheadAmountBilled", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualOverheadAmountBilled, Id = Index.ActualOverheadAmountBilled, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverheadAmountBilled { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadBillingEst
        /// </summary>
        [Display(Name = "ActualOverheadBillingEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualOverheadBillingEst, Id = Index.ActualOverheadBillingEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverheadBillingEst { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadQtyEst
        /// </summary>
        [Display(Name = "OriginalOverheadQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalOverheadQtyEst, Id = Index.OriginalOverheadQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalOverheadQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyOverheadEst
        /// </summary>
        [Display(Name = "CurrencyOverheadEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyOverheadEst, Id = Index.CurrencyOverheadEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyOverheadEst { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadQty
        /// </summary>
        [Display(Name = "ActualOverheadQty", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualOverheadQty, Id = Index.ActualOverheadQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualOverheadQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalEstMiscellaneousCost
        /// </summary>
        [Display(Name = "OriginalEstMiscellaneousCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalEstMiscellaneousCost, Id = Index.OriginalEstMiscellaneousCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEstMiscellaneousCost { get; set; }

        /// <summary>
        /// Gets or sets CurrencyEstMiscellaneousCost
        /// </summary>
        [Display(Name = "CurrencyEstMiscellaneousCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyEstMiscellaneousCost, Id = Index.CurrencyEstMiscellaneousCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrencyEstMiscellaneousCost { get; set; }

        /// <summary>
        /// Gets or sets ActualMiscellaneousCost
        /// </summary>
        [Display(Name = "ActualMiscellaneousCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualMiscellaneousCost, Id = Index.ActualMiscellaneousCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualMiscellaneousCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMISCBSR
        /// </summary>
        [Display(Name = "ORJMISCBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJMISCBSR, Id = Index.ORJMISCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMISCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJMISCBHM
        /// </summary>
        [Display(Name = "ORJMISCBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJMISCBHM, Id = Index.ORJMISCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJMISCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMISCBSR
        /// </summary>
        [Display(Name = "CURMISCBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURMISCBSR, Id = Index.CURMISCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMISCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CURMISCBHM
        /// </summary>
        [Display(Name = "CURMISCBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CURMISCBHM, Id = Index.CURMISCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CURMISCBHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMISCBSR
        /// </summary>
        [Display(Name = "ACTMISCBSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTMISCBSR, Id = Index.ACTMISCBSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMISCBSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTMISCBHM
        /// </summary>
        [Display(Name = "ACTMISCBHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTMISCBHM, Id = Index.ACTMISCBHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTMISCBHM { get; set; }

        /// <summary>
        /// Gets or sets OriginalMiscellaneousQtyEst
        /// </summary>
        [Display(Name = "OriginalMiscellaneousQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalMiscellaneousQtyEst, Id = Index.OriginalMiscellaneousQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalMiscellaneousQtyEst { get; set; }

        /// <summary>
        /// Gets or sets CurrencyMiscellaneousQtyEst
        /// </summary>
        [Display(Name = "CurrencyMiscellaneousQtyEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrencyMiscellaneousQtyEst, Id = Index.CurrencyMiscellaneousQtyEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrencyMiscellaneousQtyEst { get; set; }

        /// <summary>
        /// Gets or sets ActualMiscellaneousQty
        /// </summary>
        [Display(Name = "ActualMiscellaneousQty", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualMiscellaneousQty, Id = Index.ActualMiscellaneousQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualMiscellaneousQty { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadEstimate
        /// </summary>
        [Display(Name = "OriginalOverheadEstimate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalOverheadEstimate, Id = Index.OriginalOverheadEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalOverheadEstimate { get; set; }

        /// <summary>
        /// Gets or sets CurrentOverheadEstimate
        /// </summary>
        [Display(Name = "CurrentOverheadEstimate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentOverheadEstimate, Id = Index.CurrentOverheadEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentOverheadEstimate { get; set; }

        /// <summary>
        /// Gets or sets ActualOverhead
        /// </summary>
        [Display(Name = "ActualOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualOverhead, Id = Index.ActualOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverhead { get; set; }

        /// <summary>
        /// Gets or sets OriginalLaborAmountEstimate
        /// </summary>
        [Display(Name = "OriginalLaborAmountEstimate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalLaborAmountEstimate, Id = Index.OriginalLaborAmountEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalLaborAmountEstimate { get; set; }

        /// <summary>
        /// Gets or sets CurrentLaborAmountEstimate
        /// </summary>
        [Display(Name = "CurrentLaborAmountEstimate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentLaborAmountEstimate, Id = Index.CurrentLaborAmountEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentLaborAmountEstimate { get; set; }

        /// <summary>
        /// Gets or sets ActualLaborAmount
        /// </summary>
        [Display(Name = "ActualLaborAmount", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualLaborAmount, Id = Index.ActualLaborAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualLaborAmount { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGSR
        /// </summary>
        [Display(Name = "ACTCHRGSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTCHRGSR, Id = Index.ACTCHRGSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGHM
        /// </summary>
        [Display(Name = "ACTCHRGHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTCHRGHM, Id = Index.ACTCHRGHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGDSR
        /// </summary>
        [Display(Name = "ACTCHRGDSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTCHRGDSR, Id = Index.ACTCHRGDSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGDSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ACTCHRGDHM
        /// </summary>
        [Display(Name = "ACTCHRGDHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ACTCHRGDHM, Id = Index.ACTCHRGDHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ACTCHRGDHM { get; set; }

        /// <summary>
        /// Gets or sets ActCostStockRetToInventory
        /// </summary>
        [Display(Name = "ActCostStockRetToInventory", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActCostStockRetToInventory, Id = Index.ActCostStockRetToInventory, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActCostStockRetToInventory { get; set; }

        /// <summary>
        /// Gets or sets ActQtyStockRetToInventory
        /// </summary>
        [Display(Name = "ActQtyStockRetToInventory", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActQtyStockRetToInventory, Id = Index.ActQtyStockRetToInventory, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActQtyStockRetToInventory { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TARRECTSSR
        /// </summary>
        [Display(Name = "TARRECTSSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TARRECTSSR, Id = Index.TARRECTSSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TARRECTSSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TARRECTSHM
        /// </summary>
        [Display(Name = "TARRECTSHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TARRECTSHM, Id = Index.TARRECTSHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TARRECTSHM { get; set; }

        /// <summary>
        /// Gets or sets TotalAPVendorPayments
        /// </summary>
        [Display(Name = "TotalAPVendorPayments", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TotalAPVendorPayments, Id = Index.TotalAPVendorPayments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAPVendorPayments { get; set; }

        /// <summary>
        /// Gets or sets TotalOriginalCostEst
        /// </summary>
        [Display(Name = "TotalOriginalCostEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TotalOriginalCostEst, Id = Index.TotalOriginalCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalOriginalCostEst { get; set; }

        /// <summary>
        /// Gets or sets TotalCurrencyCostEst
        /// </summary>
        [Display(Name = "TotalCurrencyCostEst", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TotalCurrencyCostEst, Id = Index.TotalCurrencyCostEst, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCurrencyCostEst { get; set; }

        /// <summary>
        /// Gets or sets TotalActualCost
        /// </summary>
        [Display(Name = "TotalActualCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TotalActualCost, Id = Index.TotalActualCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalActualCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCostRecognized
        /// </summary>
        [Display(Name = "TotalCostRecognized", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TotalCostRecognized, Id = Index.TotalCostRecognized, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostRecognized { get; set; }

        /// <summary>
        /// Gets or sets PercentTotalCost
        /// </summary>
        [Display(Name = "PercentTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PercentTotalCost, Id = Index.PercentTotalCost, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentTotalCost { get; set; }

        /// <summary>
        /// Gets or sets PercentTotalRevenue
        /// </summary>
        [Display(Name = "PercentTotalRevenue", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PercentTotalRevenue, Id = Index.PercentTotalRevenue, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentTotalRevenue { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TORJREVSR
        /// </summary>
        [Display(Name = "TORJREVSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TORJREVSR, Id = Index.TORJREVSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TORJREVSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TORJREVHM
        /// </summary>
        [Display(Name = "TORJREVHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TORJREVHM, Id = Index.TORJREVHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TORJREVHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TCURREVSR
        /// </summary>
        [Display(Name = "TCURREVSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TCURREVSR, Id = Index.TCURREVSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TCURREVSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TCURREVHM
        /// </summary>
        [Display(Name = "TCURREVHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TCURREVHM, Id = Index.TCURREVHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TCURREVHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TACTREVSR
        /// </summary>
        [Display(Name = "TACTREVSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TACTREVSR, Id = Index.TACTREVSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TACTREVSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TACTREVHM
        /// </summary>
        [Display(Name = "TACTREVHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TACTREVHM, Id = Index.TACTREVHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TACTREVHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TRECREVSR
        /// </summary>
        [Display(Name = "TRECREVSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TRECREVSR, Id = Index.TRECREVSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRECREVSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TRECREVHM
        /// </summary>
        [Display(Name = "TRECREVHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TRECREVHM, Id = Index.TRECREVHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TRECREVHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARAMTSR
        /// </summary>
        [Display(Name = "RETARAMTSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RETARAMTSR, Id = Index.RETARAMTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARAMTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARAMTHM
        /// </summary>
        [Display(Name = "RETARAMTHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RETARAMTHM, Id = Index.RETARAMTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARAMTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARRECSR
        /// </summary>
        [Display(Name = "RETARRECSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RETARRECSR, Id = Index.RETARRECSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARRECSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETARRECHM
        /// </summary>
        [Display(Name = "RETARRECHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RETARRECHM, Id = Index.RETARRECHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RETARRECHM { get; set; }

        /// <summary>
        /// Gets or sets RetainagePayable
        /// </summary>
        [Display(Name = "RetainagePayable", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RetainagePayable, Id = Index.RetainagePayable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainagePayable { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmountPaidInAP
        /// </summary>
        [Display(Name = "RetainageAmountPaidInAP", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RetainageAmountPaidInAP, Id = Index.RetainageAmountPaidInAP, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmountPaidInAP { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOQuantity
        /// </summary>
        [Display(Name = "CommittedPOQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CommittedPOQuantity, Id = Index.CommittedPOQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CommittedPOQuantity { get; set; }

        /// <summary>
        /// Gets or sets RecognizedLoss
        /// </summary>
        [Display(Name = "RecognizedLoss", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RecognizedLoss, Id = Index.RecognizedLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RecognizedLoss { get; set; }

        /// <summary>
        /// Gets or sets BillingsPercentComplete
        /// </summary>
        [Display(Name = "BillingsPercentComplete", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.BillingsPercentComplete, Id = Index.BillingsPercentComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BillingsPercentComplete { get; set; }

        /// <summary>
        /// Gets or sets RRPercentComplete
        /// </summary>
        [Display(Name = "RRPercentComplete", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RRPercentComplete, Id = Index.RRPercentComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RRPercentComplete { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FPAMOUNTSR
        /// </summary>
        [Display(Name = "FPAMOUNTSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.FPAMOUNTSR, Id = Index.FPAMOUNTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FPAMOUNTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FPAMOUNTHM
        /// </summary>
        [Display(Name = "FPAMOUNTHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.FPAMOUNTHM, Id = Index.FPAMOUNTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FPAMOUNTHM { get; set; }

        /// <summary>
        /// Gets or sets LastBillingsPercentComplete
        /// </summary>
        [Display(Name = "LastBillingsPercentComplete", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastBillingsPercentComplete, Id = Index.LastBillingsPercentComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LastBillingsPercentComplete { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets BILLAMTRSR
        /// </summary>
        [Display(Name = "BILLAMTRSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.BILLAMTRSR, Id = Index.BILLAMTRSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BILLAMTRSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets BILLAMTRHM
        /// </summary>
        [Display(Name = "BILLAMTRHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.BILLAMTRHM, Id = Index.BILLAMTRHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BILLAMTRHM { get; set; }

        /// <summary>
        /// Gets or sets LastCostPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastCostPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastCostPostingDate, Id = Index.LastCostPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastCostPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastBillingsPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastBillingsPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastBillingsPostingDate, Id = Index.LastBillingsPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastBillingsPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastOverheadPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOverheadPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastOverheadPostingDate, Id = Index.LastOverheadPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastOverheadPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastChargePostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastChargePostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastChargePostingDate, Id = Index.LastChargePostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastChargePostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastRevenueRecPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastRevenueRecPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastRevenueRecPostingDate, Id = Index.LastRevenueRecPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastRevenueRecPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastARReceiptPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastARReceiptPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastARReceiptPostingDate, Id = Index.LastARReceiptPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastARReceiptPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastAPPaymentPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastAPPaymentPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastAPPaymentPostingDate, Id = Index.LastAPPaymentPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastAPPaymentPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastTimecardPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastTimecardPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastTimecardPostingDate, Id = Index.LastTimecardPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastTimecardPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastMaterialUsagePostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaterialUsagePostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastMaterialUsagePostingDate, Id = Index.LastMaterialUsagePostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaterialUsagePostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastMaterialReturnPostingDat
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaterialReturnPostingDat", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastMaterialReturnPostingDat, Id = Index.LastMaterialReturnPostingDat, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaterialReturnPostingDat { get; set; }

        /// <summary>
        /// Gets or sets LastEquipmentPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastEquipmentPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastEquipmentPostingDate, Id = Index.LastEquipmentPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastEquipmentPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastPurchaseOrderDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPurchaseOrderDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastPurchaseOrderDate, Id = Index.LastPurchaseOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPurchaseOrderDate { get; set; }

        /// <summary>
        /// Gets or sets LastPOReceiptDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPOReceiptDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastPOReceiptDate, Id = Index.LastPOReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPOReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets LastPOReturnDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPOReturnDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastPOReturnDate, Id = Index.LastPOReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPOReturnDate { get; set; }

        /// <summary>
        /// Gets or sets LastOEInvoiceDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOEInvoiceDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastOEInvoiceDate, Id = Index.LastOEInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastOEInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets ProjectTaxTotal
        /// </summary>
        [Display(Name = "ProjectTaxTotal", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ProjectTaxTotal, Id = Index.ProjectTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ProjectTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASES1
        /// </summary>
        [Display(Name = "TAXBASES1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASES1, Id = Index.TAXBASES1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASES1 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASES2
        /// </summary>
        [Display(Name = "TAXBASES2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASES2, Id = Index.TAXBASES2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASES2 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASES3
        /// </summary>
        [Display(Name = "TAXBASES3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASES3, Id = Index.TAXBASES3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASES3 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASES4
        /// </summary>
        [Display(Name = "TAXBASES4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASES4, Id = Index.TAXBASES4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASES4 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASES5
        /// </summary>
        [Display(Name = "TAXBASES5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASES5, Id = Index.TAXBASES5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASES5 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASEH1
        /// </summary>
        [Display(Name = "TAXBASEH1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASEH1, Id = Index.TAXBASEH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASEH1 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASEH2
        /// </summary>
        [Display(Name = "TAXBASEH2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASEH2, Id = Index.TAXBASEH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASEH2 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASEH3
        /// </summary>
        [Display(Name = "TAXBASEH3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASEH3, Id = Index.TAXBASEH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASEH3 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASEH4
        /// </summary>
        [Display(Name = "TAXBASEH4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASEH4, Id = Index.TAXBASEH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASEH4 { get; set; }

        /// <summary>
        /// Gets or sets TAXBASEH5
        /// </summary>
        [Display(Name = "TAXBASEH5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXBASEH5, Id = Index.TAXBASEH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXBASEH5 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTS1
        /// </summary>
        [Display(Name = "TAXAMTS1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTS1, Id = Index.TAXAMTS1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTS1 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTS2
        /// </summary>
        [Display(Name = "TAXAMTS2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTS2, Id = Index.TAXAMTS2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTS2 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTS3
        /// </summary>
        [Display(Name = "TAXAMTS3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTS3, Id = Index.TAXAMTS3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTS3 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTS4
        /// </summary>
        [Display(Name = "TAXAMTS4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTS4, Id = Index.TAXAMTS4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTS4 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTS5
        /// </summary>
        [Display(Name = "TAXAMTS5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTS5, Id = Index.TAXAMTS5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTS5 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTH1
        /// </summary>
        [Display(Name = "TAXAMTH1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTH1, Id = Index.TAXAMTH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTH1 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTH2
        /// </summary>
        [Display(Name = "TAXAMTH2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTH2, Id = Index.TAXAMTH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTH2 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTH3
        /// </summary>
        [Display(Name = "TAXAMTH3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTH3, Id = Index.TAXAMTH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTH3 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTH4
        /// </summary>
        [Display(Name = "TAXAMTH4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTH4, Id = Index.TAXAMTH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTH4 { get; set; }

        /// <summary>
        /// Gets or sets TAXAMTH5
        /// </summary>
        [Display(Name = "TAXAMTH5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TAXAMTH5, Id = Index.TAXAMTH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TAXAMTH5 { get; set; }

        /// <summary>
        /// Gets or sets OnBillingWorksheet
        /// </summary>
        [Display(Name = "OnBillingWorksheet", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OnBillingWorksheet, Id = Index.OnBillingWorksheet, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OnBillingWorksheet { get; set; }

        /// <summary>
        /// Gets or sets ProjectHasBeenOpened
        /// </summary>
        [Display(Name = "ProjectHasBeenOpened", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ProjectHasBeenOpened, Id = Index.ProjectHasBeenOpened, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ProjectHasBeenOpened { get; set; }

        /// <summary>
        /// Gets or sets ExpectedBillings
        /// </summary>
        [Display(Name = "ExpectedBillings", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ExpectedBillings, Id = Index.ExpectedBillings, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExpectedBillings { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORATEOP
        /// </summary>
        [Display(Name = "ORATEOP", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORateOperator, Id = Index.ORateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperator ORateOperator { get; set; }

        /// <summary>
        /// Gets or sets LastRevRecognitionPercentage
        /// </summary>
        [Display(Name = "LastRevRecognitionPercentage", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastRevRecognitionPercentage, Id = Index.LastRevRecognitionPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LastRevRecognitionPercentage { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PRFTLOSSSR
        /// </summary>
        [Display(Name = "PRFTLOSSSR", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PRFTLOSSSR, Id = Index.PRFTLOSSSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PRFTLOSSSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PRFTLOSSHM
        /// </summary>
        [Display(Name = "PRFTLOSSHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PRFTLOSSHM, Id = Index.PRFTLOSSHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PRFTLOSSHM { get; set; }

        /// <summary>
        /// Gets or sets LastRevisedPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastRevisedPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastRevisedPostingDate, Id = Index.LastRevisedPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastRevisedPostingDate { get; set; }

        /// <summary>
        /// Gets or sets OnRRWorksheet
        /// </summary>
        [Display(Name = "OnRRWorksheet", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OnRRWorksheet, Id = Index.OnRRWorksheet, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OnRRWorksheet { get; set; }

        /// <summary>
        /// Gets or sets OriginalEmployeeLabor
        /// </summary>
        [Display(Name = "OriginalEmployeeLabor", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalEmployeeLabor, Id = Index.OriginalEmployeeLabor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEmployeeLabor { get; set; }

        /// <summary>
        /// Gets or sets CurrentEmployeeLabor
        /// </summary>
        [Display(Name = "CurrentEmployeeLabor", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentEmployeeLabor, Id = Index.CurrentEmployeeLabor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentEmployeeLabor { get; set; }

        /// <summary>
        /// Gets or sets ActualEmployeeLabor
        /// </summary>
        [Display(Name = "ActualEmployeeLabor", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualEmployeeLabor, Id = Index.ActualEmployeeLabor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualEmployeeLabor { get; set; }

        /// <summary>
        /// Gets or sets OriginalEmployeeOverhead
        /// </summary>
        [Display(Name = "OriginalEmployeeOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalEmployeeOverhead, Id = Index.OriginalEmployeeOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEmployeeOverhead { get; set; }

        /// <summary>
        /// Gets or sets CurrentEmployeeOverhead
        /// </summary>
        [Display(Name = "CurrentEmployeeOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentEmployeeOverhead, Id = Index.CurrentEmployeeOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentEmployeeOverhead { get; set; }

        /// <summary>
        /// Gets or sets ActualEmployeeOverhead
        /// </summary>
        [Display(Name = "ActualEmployeeOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualEmployeeOverhead, Id = Index.ActualEmployeeOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualEmployeeOverhead { get; set; }

        /// <summary>
        /// Gets or sets OriginalEquipmentOverhead
        /// </summary>
        [Display(Name = "OriginalEquipmentOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalEquipmentOverhead, Id = Index.OriginalEquipmentOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalEquipmentOverhead { get; set; }

        /// <summary>
        /// Gets or sets CurrentEquipmentOverhead
        /// </summary>
        [Display(Name = "CurrentEquipmentOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentEquipmentOverhead, Id = Index.CurrentEquipmentOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentEquipmentOverhead { get; set; }

        /// <summary>
        /// Gets or sets ActualEquipmentOverhead
        /// </summary>
        [Display(Name = "ActualEquipmentOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualEquipmentOverhead, Id = Index.ActualEquipmentOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualEquipmentOverhead { get; set; }

        /// <summary>
        /// Gets or sets OriginalSubcontractorOverhead
        /// </summary>
        [Display(Name = "OriginalSubcontractorOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalSubcontractorOverhead, Id = Index.OriginalSubcontractorOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalSubcontractorOverhead { get; set; }

        /// <summary>
        /// Gets or sets CurrentSubcontractorOverhead
        /// </summary>
        [Display(Name = "CurrentSubcontractorOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentSubcontractorOverhead, Id = Index.CurrentSubcontractorOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentSubcontractorOverhead { get; set; }

        /// <summary>
        /// Gets or sets ActualSubcontractorOverhead
        /// </summary>
        [Display(Name = "ActualSubcontractorOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualSubcontractorOverhead, Id = Index.ActualSubcontractorOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualSubcontractorOverhead { get; set; }

        /// <summary>
        /// Gets or sets OriginalOverheadOverhead
        /// </summary>
        [Display(Name = "OriginalOverheadOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalOverheadOverhead, Id = Index.OriginalOverheadOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalOverheadOverhead { get; set; }

        /// <summary>
        /// Gets or sets CurrentOverheadOverhead
        /// </summary>
        [Display(Name = "CurrentOverheadOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentOverheadOverhead, Id = Index.CurrentOverheadOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentOverheadOverhead { get; set; }

        /// <summary>
        /// Gets or sets ActualOverheadOverhead
        /// </summary>
        [Display(Name = "ActualOverheadOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualOverheadOverhead, Id = Index.ActualOverheadOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualOverheadOverhead { get; set; }

        /// <summary>
        /// Gets or sets OriginalMiscellaneousOverhead
        /// </summary>
        [Display(Name = "OriginalMiscellaneousOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalMiscellaneousOverhead, Id = Index.OriginalMiscellaneousOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalMiscellaneousOverhead { get; set; }

        /// <summary>
        /// Gets or sets CurrentMiscellaneousOverhead
        /// </summary>
        [Display(Name = "CurrentMiscellaneousOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentMiscellaneousOverhead, Id = Index.CurrentMiscellaneousOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentMiscellaneousOverhead { get; set; }

        /// <summary>
        /// Gets or sets ActualMiscellaneousOverhead
        /// </summary>
        [Display(Name = "ActualMiscellaneousOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualMiscellaneousOverhead, Id = Index.ActualMiscellaneousOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualMiscellaneousOverhead { get; set; }

        /// <summary>
        /// Gets or sets OriginalMaterialOverhead
        /// </summary>
        [Display(Name = "OriginalMaterialOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OriginalMaterialOverhead, Id = Index.OriginalMaterialOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalMaterialOverhead { get; set; }

        /// <summary>
        /// Gets or sets CurrentMaterialOverhead
        /// </summary>
        [Display(Name = "CurrentMaterialOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentMaterialOverhead, Id = Index.CurrentMaterialOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentMaterialOverhead { get; set; }

        /// <summary>
        /// Gets or sets ActualMaterialOverhead
        /// </summary>
        [Display(Name = "ActualMaterialOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualMaterialOverhead, Id = Index.ActualMaterialOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualMaterialOverhead { get; set; }

        /// <summary>
        /// Gets or sets CurrentStartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentStartDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentStartDate, Id = Index.CurrentStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CurrentStartDate { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [Display(Name = "ProjectStyle", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets CurrentBillingsARAndOnBW
        /// </summary>
        [Display(Name = "CurrentBillingsARAndOnBW", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentBillingsARAndOnBW, Id = Index.CurrentBillingsARAndOnBW, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentBillingsARAndOnBW { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOCost
        /// </summary>
        [Display(Name = "CommittedPOCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CommittedPOCost, Id = Index.CommittedPOCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOCost { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOOverhead
        /// </summary>
        [Display(Name = "CommittedPOOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CommittedPOOverhead, Id = Index.CommittedPOOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOOverhead { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOLabor
        /// </summary>
        [Display(Name = "CommittedPOLabor", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CommittedPOLabor, Id = Index.CommittedPOLabor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOLabor { get; set; }

        /// <summary>
        /// Gets or sets CommittedPOTotalCost
        /// </summary>
        [Display(Name = "CommittedPOTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CommittedPOTotalCost, Id = Index.CommittedPOTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommittedPOTotalCost { get; set; }

        /// <summary>
        /// Gets or sets POEmployeeQuantity
        /// </summary>
        [Display(Name = "POEmployeeQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POEmployeeQuantity, Id = Index.POEmployeeQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal POEmployeeQuantity { get; set; }

        /// <summary>
        /// Gets or sets POEmployeeOverhead
        /// </summary>
        [Display(Name = "POEmployeeOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POEmployeeOverhead, Id = Index.POEmployeeOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POEmployeeOverhead { get; set; }

        /// <summary>
        /// Gets or sets POEmployeeLabor
        /// </summary>
        [Display(Name = "POEmployeeLabor", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POEmployeeLabor, Id = Index.POEmployeeLabor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POEmployeeLabor { get; set; }

        /// <summary>
        /// Gets or sets POEmployeeTotalCost
        /// </summary>
        [Display(Name = "POEmployeeTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POEmployeeTotalCost, Id = Index.POEmployeeTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POEmployeeTotalCost { get; set; }

        /// <summary>
        /// Gets or sets POEquipmentQuantity
        /// </summary>
        [Display(Name = "POEquipmentQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POEquipmentQuantity, Id = Index.POEquipmentQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal POEquipmentQuantity { get; set; }

        /// <summary>
        /// Gets or sets POEquipmentOverhead
        /// </summary>
        [Display(Name = "POEquipmentOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POEquipmentOverhead, Id = Index.POEquipmentOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POEquipmentOverhead { get; set; }

        /// <summary>
        /// Gets or sets POEquipmentTotalCost
        /// </summary>
        [Display(Name = "POEquipmentTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POEquipmentTotalCost, Id = Index.POEquipmentTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POEquipmentTotalCost { get; set; }

        /// <summary>
        /// Gets or sets POSubcontractorQuantity
        /// </summary>
        [Display(Name = "POSubcontractorQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POSubcontractorQuantity, Id = Index.POSubcontractorQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal POSubcontractorQuantity { get; set; }

        /// <summary>
        /// Gets or sets POSubcontractorOverhead
        /// </summary>
        [Display(Name = "POSubcontractorOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POSubcontractorOverhead, Id = Index.POSubcontractorOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POSubcontractorOverhead { get; set; }

        /// <summary>
        /// Gets or sets POSubcontractorTotalCost
        /// </summary>
        [Display(Name = "POSubcontractorTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POSubcontractorTotalCost, Id = Index.POSubcontractorTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POSubcontractorTotalCost { get; set; }

        /// <summary>
        /// Gets or sets POOverheadQuantity
        /// </summary>
        [Display(Name = "POOverheadQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POOverheadQuantity, Id = Index.POOverheadQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal POOverheadQuantity { get; set; }

        /// <summary>
        /// Gets or sets POOverheadOverhead
        /// </summary>
        [Display(Name = "POOverheadOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POOverheadOverhead, Id = Index.POOverheadOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POOverheadOverhead { get; set; }

        /// <summary>
        /// Gets or sets POOverheadTotalCost
        /// </summary>
        [Display(Name = "POOverheadTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POOverheadTotalCost, Id = Index.POOverheadTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POOverheadTotalCost { get; set; }

        /// <summary>
        /// Gets or sets POMiscellaneousQuantity
        /// </summary>
        [Display(Name = "POMiscellaneousQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POMiscellaneousQuantity, Id = Index.POMiscellaneousQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal POMiscellaneousQuantity { get; set; }

        /// <summary>
        /// Gets or sets POMiscellaneousOverhead
        /// </summary>
        [Display(Name = "POMiscellaneousOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POMiscellaneousOverhead, Id = Index.POMiscellaneousOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POMiscellaneousOverhead { get; set; }

        /// <summary>
        /// Gets or sets POMiscellaneousTotalCost
        /// </summary>
        [Display(Name = "POMiscellaneousTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POMiscellaneousTotalCost, Id = Index.POMiscellaneousTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POMiscellaneousTotalCost { get; set; }

        /// <summary>
        /// Gets or sets POMaterialQuantity
        /// </summary>
        [Display(Name = "POMaterialQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POMaterialQuantity, Id = Index.POMaterialQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal POMaterialQuantity { get; set; }

        /// <summary>
        /// Gets or sets POMaterialOverhead
        /// </summary>
        [Display(Name = "POMaterialOverhead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POMaterialOverhead, Id = Index.POMaterialOverhead, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POMaterialOverhead { get; set; }

        /// <summary>
        /// Gets or sets POMaterialTotalCost
        /// </summary>
        [Display(Name = "POMaterialTotalCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.POMaterialTotalCost, Id = Index.POMaterialTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal POMaterialTotalCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets VALUES
        /// </summary>
        [Display(Name = "VALUES", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.VALUES, Id = Index.VALUES, FieldType = EntityFieldType.Long, Size = 4)]
        public long VALUES { get; set; }

        /// <summary>
        /// Gets or sets TransactionsHaveBeenCleared
        /// </summary>
        [Display(Name = "TransactionsHaveBeenCleared", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TransactionsHaveBeenCleared, Id = Index.TransactionsHaveBeenCleared, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType TransactionsHaveBeenCleared { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClass1
        /// </summary>
        [Display(Name = "CustomerTaxClass1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxClass1, Id = Index.CustomerTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerTaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClass2
        /// </summary>
        [Display(Name = "CustomerTaxClass2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxClass2, Id = Index.CustomerTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerTaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClass3
        /// </summary>
        [Display(Name = "CustomerTaxClass3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxClass3, Id = Index.CustomerTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerTaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClass4
        /// </summary>
        [Display(Name = "CustomerTaxClass4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxClass4, Id = Index.CustomerTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerTaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClass5
        /// </summary>
        [Display(Name = "CustomerTaxClass5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxClass5, Id = Index.CustomerTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerTaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority1", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority1, Id = Index.CustomerTaxAuthority1, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority2", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority2, Id = Index.CustomerTaxAuthority2, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority3", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority3, Id = Index.CustomerTaxAuthority3, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority4", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority4, Id = Index.CustomerTaxAuthority4, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerTaxAuthority5", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerTaxAuthority5, Id = Index.CustomerTaxAuthority5, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerTaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets LastUSPayrollPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastUSPayrollPostingDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastUSPayrollPostingDate, Id = Index.LastUSPayrollPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastUSPayrollPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastCanadianPayrollPostingDa
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastCanadianPayrollPostingDa", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastCanadianPayrollPostingDa, Id = Index.LastCanadianPayrollPostingDa, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastCanadianPayrollPostingDa { get; set; }

        /// <summary>
        /// Gets or sets StoredCost
        /// </summary>
        [Display(Name = "StoredCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.StoredCost, Id = Index.StoredCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StoredCost { get; set; }

        /// <summary>
        /// Gets or sets StoredBillableAmount
        /// </summary>
        [Display(Name = "StoredBillableAmount", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.StoredBillableAmount, Id = Index.StoredBillableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StoredBillableAmount { get; set; }

        /// <summary>
        /// Gets or sets PreviousD+E
        /// </summary>
        [Display(Name = "PreviousD+E", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PreviousDAndE, Id = Index.PreviousDAndE, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreviousDAndE { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmount
        /// </summary>
        [Display(Name = "OverheadAmount", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OverheadAmount, Id = Index.OverheadAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalStoredCost
        /// </summary>
        [Display(Name = "TotalStoredCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TotalStoredCost, Id = Index.TotalStoredCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalStoredCost { get; set; }

        /// <summary>
        /// Gets or sets TaxExpCommittedFunc
        /// </summary>
        [Display(Name = "TaxExpCommittedFunc", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxExpCommittedFunc, Id = Index.TaxExpCommittedFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpCommittedFunc { get; set; }

        /// <summary>
        /// Gets or sets TaxAllCommittedFunc
        /// </summary>
        [Display(Name = "TaxAllCommittedFunc", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.TaxAllCommittedFunc, Id = Index.TaxAllCommittedFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllCommittedFunc { get; set; }

        /// <summary>
        /// Gets or sets StoredQuantity
        /// </summary>
        [Display(Name = "StoredQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.StoredQuantity, Id = Index.StoredQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal StoredQuantity { get; set; }

        /// <summary>
        /// Gets or sets PreviousCertificatesForPaymen
        /// </summary>
        [Display(Name = "PreviousCertificatesForPaymen", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PreviousCertificatesForPaymen, Id = Index.PreviousCertificatesForPaymen, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreviousCertificatesForPaymen { get; set; }

        /// <summary>
        /// Gets or sets G703ColumnFFromLastAIARepo
        /// </summary>
        [Display(Name = "G703ColumnFFromLastAIARepo", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.G703ColumnFFromLastAIARepo, Id = Index.G703ColumnFFromLastAIARepo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal G703ColumnFFromLastAIARepo { get; set; }

        /// <summary>
        /// Gets or sets G703ColumnIFromLastAIARepo
        /// </summary>
        [Display(Name = "G703ColumnIFromLastAIARepo", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.G703ColumnIFromLastAIARepo, Id = Index.G703ColumnIFromLastAIARepo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal G703ColumnIFromLastAIARepo { get; set; }

        /// <summary>
        /// Gets or sets AccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerCurrency", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets Position
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Position", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Position, Id = Index.Position, FieldType = EntityFieldType.Char, Size = 60)]
        public string Position { get; set; }

        /// <summary>
        /// Gets or sets Phone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Phone, Id = Index.Phone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets OtherPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OtherPhone", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OtherPhone, Id = Index.OtherPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string OtherPhone { get; set; }

        /// <summary>
        /// Gets or sets Fax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Fax, Id = Index.Fax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Fax { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 60)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets InvoiceToMultipleCustomers
        /// </summary>
        [Display(Name = "InvoiceToMultipleCustomers", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.InvoiceToMultipleCustomers, Id = Index.InvoiceToMultipleCustomers, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType InvoiceToMultipleCustomers { get; set; }

        /// <summary>
        /// Gets or sets HasThisProjectBeenBilled
        /// </summary>
        [Display(Name = "HasThisProjectBeenBilled", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.HasThisProjectBeenBilled, Id = Index.HasThisProjectBeenBilled, FieldType = EntityFieldType.Int, Size = 2)]
        public int HasThisProjectBeenBilled { get; set; }

        /// <summary>
        /// Gets or sets LastOEShipmentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOEShipmentDate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.LastOEShipmentDate, Id = Index.LastOEShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastOEShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets DefaultBillingRate
        /// </summary>
        [Display(Name = "DefaultBillingRate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.DefaultBillingRate, Id = Index.DefaultBillingRate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultBillingRate DefaultBillingRate { get; set; }

        /// <summary>
        /// Gets or sets PriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets OEMiscellaneousCharges
        /// </summary>
        [Display(Name = "OEMiscellaneousCharges", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.OEMiscellaneousCharges, Id = Index.OEMiscellaneousCharges, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OEMiscellaneousCharges OEMiscellaneousCharges { get; set; }

        /// <summary>
        /// Gets or sets ARAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARAccountSet", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ARAccountSet, Id = Index.ARAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ARAccountSet { get; set; }

        /// <summary>
        /// Gets or sets UpdateCategoryCostPlus
        /// </summary>
        [Display(Name = "UpdateCategoryCostPlus", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.UpdateCategoryCostPlus, Id = Index.UpdateCategoryCostPlus, FieldType = EntityFieldType.Int, Size = 2)]
        public int UpdateCategoryCostPlus { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Function Function { get; set; }

        /// <summary>
        /// Gets or sets RateErrorCode
        /// </summary>
        [Display(Name = "RateErrorCode", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RateErrorCode, Id = Index.RateErrorCode, FieldType = EntityFieldType.Int, Size = 2)]
        public RateErrorCode RateErrorCode { get; set; }

        /// <summary>
        /// Gets or sets BillingAccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingAccountDescription", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.BillingAccountDescription, Id = Index.BillingAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillingAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets RevenueAccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueAccountDescription", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.RevenueAccountDescription, Id = Index.RevenueAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RevenueAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets WIPAccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WIPAccountDescription", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.WIPAccountDescription, Id = Index.WIPAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WIPAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets COGSAccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "COGSAccountDescription", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.COGSAccountDescription, Id = Index.COGSAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string COGSAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets CostPlusAtRead
        /// </summary>
        [Display(Name = "CostPlusAtRead", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CostPlusAtRead, Id = Index.CostPlusAtRead, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CostPlusAtRead { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets CurrentQuantityEstimate
        /// </summary>
        [Display(Name = "CurrentQuantityEstimate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentQuantityEstimate, Id = Index.CurrentQuantityEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal CurrentQuantityEstimate { get; set; }

        /// <summary>
        /// Gets or sets ActualQuantity
        /// </summary>
        [Display(Name = "ActualQuantity", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualQuantity, Id = Index.ActualQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualQuantity { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ORJCOSTHM
        /// </summary>
        [Display(Name = "ORJCOSTHM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ORJCOSTHM, Id = Index.ORJCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ORJCOSTHM { get; set; }

        /// <summary>
        /// Gets or sets CurrentCostEstimate
        /// </summary>
        [Display(Name = "CurrentCostEstimate", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CurrentCostEstimate, Id = Index.CurrentCostEstimate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentCostEstimate { get; set; }

        /// <summary>
        /// Gets or sets ActualCost
        /// </summary>
        [Display(Name = "ActualCost", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.ActualCost, Id = Index.ActualCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ActualCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SNAPCALC
        /// </summary>
        [Display(Name = "SNAPCALC", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.SNAPCALC, Id = Index.SNAPCALC, FieldType = EntityFieldType.Int, Size = 2)]
        public int SNAPCALC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SNAPOFROM
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SNAPOFROM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.SNAPOFROM, Id = Index.SNAPOFROM, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SNAPOFROM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SNAPOTO
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SNAPOTO", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.SNAPOTO, Id = Index.SNAPOTO, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SNAPOTO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SNAPCFROM
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SNAPCFROM", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.SNAPCFROM, Id = Index.SNAPCFROM, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SNAPCFROM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SNAPCTO
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SNAPCTO", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.SNAPCTO, Id = Index.SNAPCTO, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SNAPCTO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets HASOPT
        /// </summary>
        [Display(Name = "HASOPT", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.HASOPT, Id = Index.HASOPT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool HASOPT { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OPENING
        /// </summary>
        [Display(Name = "OPENING", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.Opening, Id = Index.Opening, FieldType = EntityFieldType.Int, Size = 2)]
        public Opening Opening { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets UPDATE
        /// </summary>
        [Display(Name = "UPDATE", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.UPDATE, Id = Index.UPDATE, FieldType = EntityFieldType.Int, Size = 2)]
        public int UPDATE { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof (ProjectsResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString
        {
         get { return EnumUtility.GetStringValue(ProjectType); }
        }

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString
        {
         get { return EnumUtility.GetStringValue(AccountingMethod); }
        }

        /// <summary>
        /// Gets ClosedToBillings string value
        /// </summary>
        public string ClosedToBillingsString
        {
         get { return EnumUtility.GetStringValue(ClosedToBillings); }
        }

        /// <summary>
        /// Gets ClosedToCosts string value
        /// </summary>
        public string ClosedToCostsString
        {
         get { return EnumUtility.GetStringValue(ClosedToCosts); }
        }

        /// <summary>
        /// Gets ProjectStatus string value
        /// </summary>
        public string ProjectStatusString
        {
         get { return EnumUtility.GetStringValue(ProjectStatus); }
        }

        /// <summary>
        /// Gets RevenueType string value
        /// </summary>
        public string RevenueTypeString
        {
         get { return EnumUtility.GetStringValue(RevenueType); }
        }

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString
        {
         get { return EnumUtility.GetStringValue(BillingType); }
        }

        /// <summary>
        /// Gets ARInvoiceType string value
        /// </summary>
        public string ARInvoiceTypeString
        {
         get { return EnumUtility.GetStringValue(ARInvoiceType); }
        }

        /// <summary>
        /// Gets RATEOP string value
        /// </summary>
        public string RateOperatorString
        {
         get { return EnumUtility.GetStringValue(RateOperator); }
        }

        /// <summary>
        /// Gets RevenueAndCostCurrency string value
        /// </summary>
        public string RevenueAndCostCurrencyString
        {
         get { return EnumUtility.GetStringValue(RevenueAndCostCurrency); }
        }

        /// <summary>
        /// Gets InvoiceStatus string value
        /// </summary>
        public string InvoiceStatusString
        {
         get { return EnumUtility.GetStringValue(InvoiceStatus); }
        }

        /// <summary>
        /// Gets ORATEOP string value
        /// </summary>
        public string ORateOperatorString
        {
         get { return EnumUtility.GetStringValue(RateOperator); }
        }

        /// <summary>
        /// Gets ProjectStyle string value
        /// </summary>
        public string ProjectStyleString
        {
         get { return EnumUtility.GetStringValue(ProjectStyle); }
        }

        /// <summary>
        /// Gets TransactionsHaveBeenCleared string value
        /// </summary>
        public string TransactionsHaveBeenClearedString
        {
         get { return EnumUtility.GetStringValue(TransactionsHaveBeenCleared); }
        }

        /// <summary>
        /// Gets InvoiceToMultipleCustomers string value
        /// </summary>
        public string InvoiceToMultipleCustomersString
        {
         get { return EnumUtility.GetStringValue(InvoiceToMultipleCustomers); }
        }

        /// <summary>
        /// Gets DefaultBillingRate string value
        /// </summary>
        public string DefaultBillingRateString
        {
         get { return EnumUtility.GetStringValue(DefaultBillingRate); }
        }

        /// <summary>
        /// Gets OEMiscellaneousCharges string value
        /// </summary>
        public string OEMiscellaneousChargesString
        {
         get { return EnumUtility.GetStringValue(OEMiscellaneousCharges); }
        }

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
         get { return EnumUtility.GetStringValue(Function); }
        }

        /// <summary>
        /// Gets RateErrorCode string value
        /// </summary>
        public string RateErrorCodeString
        {
         get { return EnumUtility.GetStringValue(RateErrorCode); }
        }

        /// <summary>
        /// Gets OPENING string value
        /// </summary>
        public string OpeningString
        {
         get { return EnumUtility.GetStringValue(Opening); }
        }

        #endregion
    }
}
