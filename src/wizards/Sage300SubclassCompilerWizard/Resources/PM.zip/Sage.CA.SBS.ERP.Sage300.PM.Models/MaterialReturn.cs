// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for MaterialReturn
    /// </summary>
    public partial class MaterialReturn : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets MaterialReturnNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MaterialReturnNumber", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.MaterialReturnNumber, Id = Index.MaterialReturnNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string MaterialReturnNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTSR
        /// </summary>
        [Display(Name = "EXTCOSTSR", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.EXTCOSTSR, Id = Index.EXTCOSTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets EXTCOSTHM
        /// </summary>
        [Display(Name = "EXTCOSTHM", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.EXTCOSTHM, Id = Index.EXTCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHSR
        /// </summary>
        [Display(Name = "OHSR", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.OHSR, Id = Index.OHSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OHSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OHHM
        /// </summary>
        [Display(Name = "OHHM", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.OHHM, Id = Index.OHHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OHHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTSR
        /// </summary>
        [Display(Name = "TOTCOSTSR", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.TOTCOSTSR, Id = Index.TOTCOSTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTCOSTHM
        /// </summary>
        [Display(Name = "TOTCOSTHM", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.TOTCOSTHM, Id = Index.TOTCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTBILLSR
        /// </summary>
        [Display(Name = "TOTBILLSR", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.TOTBILLSR, Id = Index.TOTBILLSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TOTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TOTBILLHM
        /// </summary>
        [Display(Name = "TOTBILLHM", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.TOTBILLHM, Id = Index.TOTBILLHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TOTBILLHM { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantity
        /// </summary>
        [Display(Name = "TotalQuantity", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.TotalQuantity, Id = Index.TotalQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal TotalQuantity { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostType
        /// </summary>
        [Display(Name = "AdditionalCostType", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.AdditionalCostType, Id = Index.AdditionalCostType, FieldType = EntityFieldType.Int, Size = 2)]
        public short AdditionalCostType { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCost
        /// </summary>
        [Display(Name = "AdditionalCost", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.AdditionalCost, Id = Index.AdditionalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdditionalCost { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetailLines
        /// </summary>
        [Display(Name = "NumberOfDetailLines", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.NumberOfDetailLines, Id = Index.NumberOfDetailLines, FieldType = EntityFieldType.Int, Size = 2)]
        public short NumberOfDetailLines { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Printed", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Printed { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus
        /// </summary>
        [Display(Name = "TransactionStatus", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumberOfDetails", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets MaterialUsageNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MaterialUsageNumber", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.MaterialUsageNumber, Id = Index.MaterialUsageNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string MaterialUsageNumber { get; set; }

        /// <summary>
        /// Gets or sets ICStatus
        /// </summary>
        [Display(Name = "ICStatus", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.ICStatus, Id = Index.ICStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ICStatus { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets CreatedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedBy", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.CreatedBy, Id = Index.CreatedBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets CreatedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedOn", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.CreatedOn, Id = Index.CreatedOn, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets CreatedAt
        /// </summary>
        [Display(Name = "CreatedAt", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.CreatedAt, Id = Index.CreatedAt, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan CreatedAt { get; set; }

        /// <summary>
        /// Gets or sets ApprovedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedBy", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.ApprovedBy, Id = Index.ApprovedBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string ApprovedBy { get; set; }

        /// <summary>
        /// Gets or sets ApprovedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedOn", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.ApprovedOn, Id = Index.ApprovedOn, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ApprovedOn { get; set; }

        /// <summary>
        /// Gets or sets ApprovedAt
        /// </summary>
        [Display(Name = "ApprovedAt", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.ApprovedAt, Id = Index.ApprovedAt, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan ApprovedAt { get; set; }

        /// <summary>
        /// Gets or sets PostedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedBy", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.PostedBy, Id = Index.PostedBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string PostedBy { get; set; }

        /// <summary>
        /// Gets or sets PostedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedOn", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.PostedOn, Id = Index.PostedOn, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostedOn { get; set; }

        /// <summary>
        /// Gets or sets PostedAt
        /// </summary>
        [Display(Name = "PostedAt", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.PostedAt, Id = Index.PostedAt, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan PostedAt { get; set; }

        /// <summary>
        /// Gets or sets ICShipmentSequenceNumber
        /// </summary>
        [Display(Name = "ICShipmentSequenceNumber", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.ICShipmentSequenceNumber, Id = Index.ICShipmentSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int ICShipmentSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets ShowProgressBarDuringPosting
        /// </summary>
        [Display(Name = "ShowProgressBarDuringPosting", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.ShowProgressBarDuringPosting, Id = Index.ShowProgressBarDuringPosting, FieldType = EntityFieldType.Int, Size = 2)]
        public short ShowProgressBarDuringPosting { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (MaterialReturnResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }
        
        #region UI Strings

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        //public string FiscalPeriodString
        //{
        // get { return EnumUtility.GetStringValue(FiscalPeriod); }
        //}

        /*
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string PrintedString
        {
         get { return EnumUtility.GetStringValue(Printed); }
        }
        */
        /// <summary>
        /// Gets TransactionStatus string value
        /// </summary>
        public string TransactionStatusString
        {
         get { return TransactionStatus.ToString(); }
        }
        /*
        /// <summary>
        /// Gets ICStatus string value
        /// </summary>
        public string ICStatusString
        {
         get { return EnumUtility.GetStringValue(ICStatus); }
        }

        /// <summary>
        /// Gets ShowProgressBarDuringPosting string value
        /// </summary>
        public string ShowProgressBarDuringPostingString
        {
         get { return EnumUtility.GetStringValue(ShowProgressBarDuringPosting); }
        }
        */
        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
         get { return EnumUtility.GetStringValue(Function); }
        }

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }


        #endregion
    }
}
