/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary> Partial model for Account Set</summary>
    public partial class AccountSet : ModelBase
    {
        /// <summary> Constructor </summary>
        public AccountSet() => Status = ActiveStatus.Active;

        /// <summary> Gets or sets AccountSetCode </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(AccountSetResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary> Gets or sets Description  </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetDesc", ResourceType = typeof(AccountSetResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary> Gets or sets Status </summary>
        [Display(Name = "Status", ResourceType = typeof(AccountSetResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public ActiveStatus Status { get; set; }

        /// <summary>Gets or sets LastMaintained </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary> Gets or sets DateInactive </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateInactive", ResourceType = typeof(AccountSetResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateInactive { get; set; }

        /// <summary> Gets or sets WorkInProgress </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorkInProgress", ResourceType = typeof(AccountSetResx))]
        [ViewField(Name = Fields.WorkInProgress, Id = Index.WorkInProgress, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string WorkInProgress { get; set; }

        /// <summary> Gets or sets CostOfSales </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostOfSales", ResourceType = typeof(AccountSetResx))]
        [ViewField(Name = Fields.CostOfSales, Id = Index.CostOfSales, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CostOfSales { get; set; }

        /// <summary> Gets or sets Billings </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Billings", ResourceType = typeof(AccountSetResx))]
        [ViewField(Name = Fields.Billings, Id = Index.Billings, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Billings { get; set; }

        /// <summary> Gets or sets DeferredRevenue </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DeferredRevenue", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.DeferredRevenue, Id = Index.DeferredRevenue, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DeferredRevenue { get; set; }

        /// <summary> Gets or sets Revenue </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Revenue", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.Revenue, Id = Index.Revenue, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Revenue { get; set; }

        /// <summary> Gets or sets PayrollExpense </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayrollExpense", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.PayrollExpense, Id = Index.PayrollExpense, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PayrollExpense { get; set; }

        /// <summary> Gets or sets Overhead </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Overhead", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.Overhead, Id = Index.Overhead, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Overhead { get; set; }

        /// <summary> Gets or sets Labor </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Labor", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.Labor, Id = Index.Labor, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Labor { get; set; }

        /// <summary> Gets or sets Equipment </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Equipment", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.Equipment, Id = Index.Equipment, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Equipment { get; set; }

        /// <summary> Gets or sets EmployeeExpense </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeExpense", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.EmployeeExpense, Id = Index.EmployeeExpense, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string EmployeeExpense { get; set; }

        /// <summary> Gets or sets Profit </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Profit", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.Profit, Id = Index.Profit, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Profit { get; set; }

        /// <summary> Gets or sets Loss </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Loss", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.Loss, Id = Index.Loss, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Loss { get; set; }

        /// <summary> Gets or sets CurrencyCode </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary> Gets or sets Cost </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Cost", ResourceType = typeof (AccountSetResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string Cost { get; set; }

        #region UI Strings
        /// <summary> Gets Status string value </summary>
        public string StatusString => EnumUtility.GetStringValue(Status);
        #endregion
    }
}
