// Copyright (c) 2022 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespaces

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for UpdateRetainageDetail
    /// </summary>
    public partial class UpdateRetainageDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets RetainageNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageNumber", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.RetainageNumber, Id = Index.RetainageNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16C")]
        public string RetainageNumber { get; set; }

        /// <summary>
        /// Gets or sets RetainageType
        /// </summary>
        [Display(Name = "RetainageType", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.RetainageType, Id = Index.RetainageType, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageType RetainageType { get; set; }

        /// <summary>
        /// Gets or sets FormattedContractNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedContractNumber", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.FormattedContractNumber, Id = Index.FormattedContractNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FormattedContractNumber { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        [Display(Name = "ContractStyle", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        [Display(Name = "Comments", ResourceType = typeof(UpdateRetainageResx))]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets Original Document Number
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalDocumentNumber", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.OriginalDocumentNumber, Id = Index.OriginalDocumentNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string OriginalDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(PMCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets ContractDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractDescription", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.ContractDescription, Id = Index.ContractDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractDescription { get; set; }

        /// <summary>
        /// Gets or sets ProjectDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectDescription", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.ProjectDescription, Id = Index.ProjectDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ProjectDescription { get; set; }

        /// <summary>
        /// Gets or sets CategoryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof(UpdateRetainageResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        ///// <summary>
        ///// Gets or sets TransactionDate
        ///// </summary>
        //[ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "TransactionDate", ResourceType = typeof(UpdateRetainageResx))]
        //public DateTime TransactionDate { get; set; }

        ///// <summary>
        ///// Gets or sets FiscalYear
        ///// </summary>
        //[StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "FiscalYear", ResourceType = typeof(UpdateRetainageResx))]
        //public string FiscalYear { get; set; }

        ///// <summary>
        ///// Gets or sets FiscalPeriod
        ///// </summary>
        //[Display(Name = "FiscalPeriod", ResourceType = typeof(UpdateRetainageResx))]
        //public short FiscalPeriod { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString => EnumUtility.GetStringValue(ContractStyle);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        #endregion
    }
}
