// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for BudgetLookup
    /// </summary>
    public partial class BudgetLookup : ModelBase
    {
        /// <summary>
        /// Gets or sets ContractUniq
        /// </summary>
        [Display(Name = "ContractUniq", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.ContractUniq, Id = Index.ContractUniq, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ContractUniq { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LINENUM
        /// </summary>
        [Display(Name = "LINENUM", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.LINENUM, Id = Index.LINENUM, FieldType = EntityFieldType.Long, Size = 4)]
        public int LINENUM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTRACT
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CONTRACT", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CONTRACT, Id = Index.CONTRACT, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24)]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets BudgetSet
        /// </summary>
        [Display(Name = "BudgetSet", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.BudgetSet, Id = Index.BudgetSet, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BudgetSet BudgetSet { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof (BudgetHeaderResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets RevenueCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueCurrency", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.RevenueCurrency, Id = Index.RevenueCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string RevenueCurrency { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets CurrencyType
        /// </summary>
        [Display(Name = "CurrencyType", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CurrencyType, Id = Index.CurrencyType, FieldType = EntityFieldType.Int, Size = 2)]
        public short CurrencyType { get; set; }

        /// <summary>
        /// Gets or sets CopyMethod
        /// </summary>
        [Display(Name = "CopyMethod", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CopyMethod, Id = Index.CopyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CopyMethod CopyMethod { get; set; }

        /// <summary>
        /// Gets or sets FixedSpreadBaseAmount
        /// </summary>
        [Display(Name = "FixedSpreadBaseAmount", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.FixedSpreadBaseAmount, Id = Index.FixedSpreadBaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal FixedSpreadBaseAmount { get; set; }

        /// <summary>
        /// Gets or sets PercentIncrease
        /// </summary>
        [Display(Name = "PercentIncrease", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.PercentIncrease, Id = Index.PercentIncrease, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentIncrease { get; set; }

        /// <summary>
        /// Gets or sets AmountIncrease
        /// </summary>
        [Display(Name = "AmountIncrease", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.AmountIncrease, Id = Index.AmountIncrease, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountIncrease { get; set; }

        /// <summary>
        /// Gets or sets CopyQuantity
        /// </summary>
        [Display(Name = "CopyQuantity", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CopyQuantity, Id = Index.CopyQuantity, FieldType = EntityFieldType.Int, Size = 2)]
        public short CopyQuantity { get; set; }

        /// <summary>
        /// Gets or sets CopyCostSource
        /// </summary>
        [Display(Name = "CopyCostSource", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CopyCostSource, Id = Index.CopyCostSource, FieldType = EntityFieldType.Int, Size = 2)]
        public short CopyCostSource { get; set; }

        /// <summary>
        /// Gets or sets CopyCostFunctional
        /// </summary>
        [Display(Name = "CopyCostFunctional", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CopyCostFunctional, Id = Index.CopyCostFunctional, FieldType = EntityFieldType.Int, Size = 2)]
        public short CopyCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets CopyRevenueSource
        /// </summary>
        [Display(Name = "CopyRevenueSource", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CopyRevenueSource, Id = Index.CopyRevenueSource, FieldType = EntityFieldType.Int, Size = 2)]
        public short CopyRevenueSource { get; set; }

        /// <summary>
        /// Gets or sets CopyRevenueFunctional
        /// </summary>
        [Display(Name = "CopyRevenueFunctional", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.CopyRevenueFunctional, Id = Index.CopyRevenueFunctional, FieldType = EntityFieldType.Int, Size = 2)]
        public short CopyRevenueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public short Function { get; set; }

        /// <summary>
        /// Gets or sets INQ1
        /// </summary>
        [Display(Name = "INQ1", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ1, Id = Index.INQ1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ1 { get; set; }

        /// <summary>
        /// Gets or sets INQ2
        /// </summary>
        [Display(Name = "INQ2", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ2, Id = Index.INQ2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ2 { get; set; }

        /// <summary>
        /// Gets or sets INQ3
        /// </summary>
        [Display(Name = "INQ3", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ3, Id = Index.INQ3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ3 { get; set; }

        /// <summary>
        /// Gets or sets INQ4
        /// </summary>
        [Display(Name = "INQ4", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ4, Id = Index.INQ4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ4 { get; set; }

        /// <summary>
        /// Gets or sets INQ5
        /// </summary>
        [Display(Name = "INQ5", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ5, Id = Index.INQ5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ5 { get; set; }

        /// <summary>
        /// Gets or sets INQ6
        /// </summary>
        [Display(Name = "INQ6", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ6, Id = Index.INQ6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ6 { get; set; }

        /// <summary>
        /// Gets or sets INQ7
        /// </summary>
        [Display(Name = "INQ7", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ7, Id = Index.INQ7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ7 { get; set; }

        /// <summary>
        /// Gets or sets INQ8
        /// </summary>
        [Display(Name = "INQ8", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ8, Id = Index.INQ8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ8 { get; set; }

        /// <summary>
        /// Gets or sets INQ9
        /// </summary>
        [Display(Name = "INQ9", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ9, Id = Index.INQ9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ9 { get; set; }

        /// <summary>
        /// Gets or sets INQ10
        /// </summary>
        [Display(Name = "INQ10", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ10, Id = Index.INQ10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ10 { get; set; }

        /// <summary>
        /// Gets or sets INQ11
        /// </summary>
        [Display(Name = "INQ11", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ11, Id = Index.INQ11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ11 { get; set; }

        /// <summary>
        /// Gets or sets INQ12
        /// </summary>
        [Display(Name = "INQ12", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ12, Id = Index.INQ12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ12 { get; set; }

        /// <summary>
        /// Gets or sets INQ13
        /// </summary>
        [Display(Name = "INQ13", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ13, Id = Index.INQ13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ13 { get; set; }

        /// <summary>
        /// Gets or sets INQ14
        /// </summary>
        [Display(Name = "INQ14", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ14, Id = Index.INQ14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ14 { get; set; }

        /// <summary>
        /// Gets or sets INQ15
        /// </summary>
        [Display(Name = "INQ15", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQ15, Id = Index.INQ15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INQTOTAL
        /// </summary>
        [Display(Name = "INQTOTAL", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INQTOTAL, Id = Index.INQTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQTOTAL { get; set; }

        /// <summary>
        /// Gets or sets INCS1
        /// </summary>
        [Display(Name = "INCS1", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS1, Id = Index.INCS1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS1 { get; set; }

        /// <summary>
        /// Gets or sets INCS2
        /// </summary>
        [Display(Name = "INCS2", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS2, Id = Index.INCS2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS2 { get; set; }

        /// <summary>
        /// Gets or sets INCS3
        /// </summary>
        [Display(Name = "INCS3", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS3, Id = Index.INCS3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS3 { get; set; }

        /// <summary>
        /// Gets or sets INCS4
        /// </summary>
        [Display(Name = "INCS4", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS4, Id = Index.INCS4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS4 { get; set; }

        /// <summary>
        /// Gets or sets INCS5
        /// </summary>
        [Display(Name = "INCS5", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS5, Id = Index.INCS5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS5 { get; set; }

        /// <summary>
        /// Gets or sets INCS6
        /// </summary>
        [Display(Name = "INCS6", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS6, Id = Index.INCS6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS6 { get; set; }

        /// <summary>
        /// Gets or sets INCS7
        /// </summary>
        [Display(Name = "INCS7", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS7, Id = Index.INCS7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS7 { get; set; }

        /// <summary>
        /// Gets or sets INCS8
        /// </summary>
        [Display(Name = "INCS8", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS8, Id = Index.INCS8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS8 { get; set; }

        /// <summary>
        /// Gets or sets INCS9
        /// </summary>
        [Display(Name = "INCS9", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS9, Id = Index.INCS9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS9 { get; set; }

        /// <summary>
        /// Gets or sets INCS10
        /// </summary>
        [Display(Name = "INCS10", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS10, Id = Index.INCS10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS10 { get; set; }

        /// <summary>
        /// Gets or sets INCS11
        /// </summary>
        [Display(Name = "INCS11", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS11, Id = Index.INCS11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS11 { get; set; }

        /// <summary>
        /// Gets or sets INCS12
        /// </summary>
        [Display(Name = "INCS12", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS12, Id = Index.INCS12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS12 { get; set; }

        /// <summary>
        /// Gets or sets INCS13
        /// </summary>
        [Display(Name = "INCS13", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS13, Id = Index.INCS13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS13 { get; set; }

        /// <summary>
        /// Gets or sets INCS14
        /// </summary>
        [Display(Name = "INCS14", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS14, Id = Index.INCS14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS14 { get; set; }

        /// <summary>
        /// Gets or sets INCS15
        /// </summary>
        [Display(Name = "INCS15", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCS15, Id = Index.INCS15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INCSTOTAL
        /// </summary>
        [Display(Name = "INCSTOTAL", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCSTOTAL, Id = Index.INCSTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCSTOTAL { get; set; }

        /// <summary>
        /// Gets or sets INCH1
        /// </summary>
        [Display(Name = "INCH1", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH1, Id = Index.INCH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH1 { get; set; }

        /// <summary>
        /// Gets or sets INCH2
        /// </summary>
        [Display(Name = "INCH2", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH2, Id = Index.INCH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH2 { get; set; }

        /// <summary>
        /// Gets or sets INCH3
        /// </summary>
        [Display(Name = "INCH3", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH3, Id = Index.INCH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH3 { get; set; }

        /// <summary>
        /// Gets or sets INCH4
        /// </summary>
        [Display(Name = "INCH4", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH4, Id = Index.INCH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH4 { get; set; }

        /// <summary>
        /// Gets or sets INCH5
        /// </summary>
        [Display(Name = "INCH5", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH5, Id = Index.INCH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH5 { get; set; }

        /// <summary>
        /// Gets or sets INCH6
        /// </summary>
        [Display(Name = "INCH6", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH6, Id = Index.INCH6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH6 { get; set; }

        /// <summary>
        /// Gets or sets INCH7
        /// </summary>
        [Display(Name = "INCH7", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH7, Id = Index.INCH7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH7 { get; set; }

        /// <summary>
        /// Gets or sets INCH8
        /// </summary>
        [Display(Name = "INCH8", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH8, Id = Index.INCH8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH8 { get; set; }

        /// <summary>
        /// Gets or sets INCH9
        /// </summary>
        [Display(Name = "INCH9", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH9, Id = Index.INCH9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH9 { get; set; }

        /// <summary>
        /// Gets or sets INCH10
        /// </summary>
        [Display(Name = "INCH10", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH10, Id = Index.INCH10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH10 { get; set; }

        /// <summary>
        /// Gets or sets INCH11
        /// </summary>
        [Display(Name = "INCH11", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH11, Id = Index.INCH11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH11 { get; set; }

        /// <summary>
        /// Gets or sets INCH12
        /// </summary>
        [Display(Name = "INCH12", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH12, Id = Index.INCH12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH12 { get; set; }

        /// <summary>
        /// Gets or sets INCH13
        /// </summary>
        [Display(Name = "INCH13", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH13, Id = Index.INCH13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH13 { get; set; }

        /// <summary>
        /// Gets or sets INCH14
        /// </summary>
        [Display(Name = "INCH14", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH14, Id = Index.INCH14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH14 { get; set; }

        /// <summary>
        /// Gets or sets INCH15
        /// </summary>
        [Display(Name = "INCH15", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCH15, Id = Index.INCH15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INCHTOTAL
        /// </summary>
        [Display(Name = "INCHTOTAL", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INCHTOTAL, Id = Index.INCHTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCHTOTAL { get; set; }

        /// <summary>
        /// Gets or sets INRS1
        /// </summary>
        [Display(Name = "INRS1", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS1, Id = Index.INRS1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS1 { get; set; }

        /// <summary>
        /// Gets or sets INRS2
        /// </summary>
        [Display(Name = "INRS2", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS2, Id = Index.INRS2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS2 { get; set; }

        /// <summary>
        /// Gets or sets INRS3
        /// </summary>
        [Display(Name = "INRS3", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS3, Id = Index.INRS3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS3 { get; set; }

        /// <summary>
        /// Gets or sets INRS4
        /// </summary>
        [Display(Name = "INRS4", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS4, Id = Index.INRS4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS4 { get; set; }

        /// <summary>
        /// Gets or sets INRS5
        /// </summary>
        [Display(Name = "INRS5", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS5, Id = Index.INRS5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS5 { get; set; }

        /// <summary>
        /// Gets or sets INRS6
        /// </summary>
        [Display(Name = "INRS6", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS6, Id = Index.INRS6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS6 { get; set; }

        /// <summary>
        /// Gets or sets INRS7
        /// </summary>
        [Display(Name = "INRS7", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS7, Id = Index.INRS7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS7 { get; set; }

        /// <summary>
        /// Gets or sets INRS8
        /// </summary>
        [Display(Name = "INRS8", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS8, Id = Index.INRS8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS8 { get; set; }

        /// <summary>
        /// Gets or sets INRS9
        /// </summary>
        [Display(Name = "INRS9", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS9, Id = Index.INRS9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS9 { get; set; }

        /// <summary>
        /// Gets or sets INRS10
        /// </summary>
        [Display(Name = "INRS10", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS10, Id = Index.INRS10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS10 { get; set; }

        /// <summary>
        /// Gets or sets INRS11
        /// </summary>
        [Display(Name = "INRS11", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS11, Id = Index.INRS11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS11 { get; set; }

        /// <summary>
        /// Gets or sets INRS12
        /// </summary>
        [Display(Name = "INRS12", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS12, Id = Index.INRS12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS12 { get; set; }

        /// <summary>
        /// Gets or sets INRS13
        /// </summary>
        [Display(Name = "INRS13", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS13, Id = Index.INRS13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS13 { get; set; }

        /// <summary>
        /// Gets or sets INRS14
        /// </summary>
        [Display(Name = "INRS14", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS14, Id = Index.INRS14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS14 { get; set; }

        /// <summary>
        /// Gets or sets INRS15
        /// </summary>
        [Display(Name = "INRS15", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRS15, Id = Index.INRS15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INRSTOTAL
        /// </summary>
        [Display(Name = "INRSTOTAL", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRSTOTAL, Id = Index.INRSTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRSTOTAL { get; set; }

        /// <summary>
        /// Gets or sets INRH1
        /// </summary>
        [Display(Name = "INRH1", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH1, Id = Index.INRH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH1 { get; set; }

        /// <summary>
        /// Gets or sets INRH2
        /// </summary>
        [Display(Name = "INRH2", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH2, Id = Index.INRH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH2 { get; set; }

        /// <summary>
        /// Gets or sets INRH3
        /// </summary>
        [Display(Name = "INRH3", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH3, Id = Index.INRH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH3 { get; set; }

        /// <summary>
        /// Gets or sets INRH4
        /// </summary>
        [Display(Name = "INRH4", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH4, Id = Index.INRH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH4 { get; set; }

        /// <summary>
        /// Gets or sets INRH5
        /// </summary>
        [Display(Name = "INRH5", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH5, Id = Index.INRH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH5 { get; set; }

        /// <summary>
        /// Gets or sets INRH6
        /// </summary>
        [Display(Name = "INRH6", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH6, Id = Index.INRH6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH6 { get; set; }

        /// <summary>
        /// Gets or sets INRH7
        /// </summary>
        [Display(Name = "INRH7", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH7, Id = Index.INRH7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH7 { get; set; }

        /// <summary>
        /// Gets or sets INRH8
        /// </summary>
        [Display(Name = "INRH8", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH8, Id = Index.INRH8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH8 { get; set; }

        /// <summary>
        /// Gets or sets INRH9
        /// </summary>
        [Display(Name = "INRH9", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH9, Id = Index.INRH9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH9 { get; set; }

        /// <summary>
        /// Gets or sets INRH10
        /// </summary>
        [Display(Name = "INRH10", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH10, Id = Index.INRH10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH10 { get; set; }

        /// <summary>
        /// Gets or sets INRH11
        /// </summary>
        [Display(Name = "INRH11", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH11, Id = Index.INRH11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH11 { get; set; }

        /// <summary>
        /// Gets or sets INRH12
        /// </summary>
        [Display(Name = "INRH12", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH12, Id = Index.INRH12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH12 { get; set; }

        /// <summary>
        /// Gets or sets INRH13
        /// </summary>
        [Display(Name = "INRH13", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH13, Id = Index.INRH13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH13 { get; set; }

        /// <summary>
        /// Gets or sets INRH14
        /// </summary>
        [Display(Name = "INRH14", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH14, Id = Index.INRH14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH14 { get; set; }

        /// <summary>
        /// Gets or sets INRH15
        /// </summary>
        [Display(Name = "INRH15", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRH15, Id = Index.INRH15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INRHTOTAL
        /// </summary>
        [Display(Name = "INRHTOTAL", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.INRHTOTAL, Id = Index.INRHTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRHTOTAL { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FMTCONTNO", ResourceType = typeof (BudgetLookupResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FMTCONTNO { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets BudgetSet string value
        /// </summary>
        public string BudgetSetString => EnumUtility.GetStringValue(BudgetSet);

        /// <summary>
        /// Gets CopyMethod string value
        /// </summary>
        public string CopyMethodString => EnumUtility.GetStringValue(CopyMethod);

        [Display(Name = "ContractDescription", ResourceType = typeof(PMCommonResx))]
        public string ContractDescription { get; set; }

        [Display(Name = "ProjectDescription", ResourceType = typeof(PMCommonResx))]
        public string ProjectDescription { get; set; }

        [Display(Name = "CategoryDescription", ResourceType = typeof(PMCommonResx))]
        public string CategoryDescription { get; set; }

        #endregion
    }
}