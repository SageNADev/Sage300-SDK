// Copyright (c) 2021 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for ReviseEstimate
    /// </summary>
    //[ViewModel(Id = EntityName)]
    public partial class ReviseEstimate : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets ReviseEstimateNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReviseEstimateNumber", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.ReviseEstimateNumber, Id = Index.ReviseEstimateNumber)]
        public string ReviseEstimateNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description)]
        public string Description { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTOTQTY
        /// </summary>
        [Display(Name = "CTOTQTY", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CTOTQTY, Id = Index.CTOTQTY)]
        public decimal CTOTQTY { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RTOTQTY
        /// </summary>
        [Display(Name = "RTOTQTY", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.RTOTQTY, Id = Index.RTOTQTY)]
        public decimal RTOTQTY { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CEXTCOSTSR
        /// </summary>
        [Display(Name = "CEXTCOSTSR", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CEXTCOSTSR, Id = Index.CEXTCOSTSR)]
        public decimal CEXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets REXTCOSTSR
        /// </summary>
        [Display(Name = "REXTCOSTSR", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.REXTCOSTSR, Id = Index.REXTCOSTSR)]
        public decimal REXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CEXTCOSTHM
        /// </summary>
        [Display(Name = "CEXTCOSTHM", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CEXTCOSTHM, Id = Index.CEXTCOSTHM)]
        public decimal CEXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets REXTCOSTHM
        /// </summary>
        [Display(Name = "REXTCOSTHM", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.REXTCOSTHM, Id = Index.REXTCOSTHM)]
        public decimal REXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTOTCOSTSR
        /// </summary>
        [Display(Name = "CTOTCOSTSR", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CTOTCOSTSR, Id = Index.CTOTCOSTSR)]
        public decimal CTOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RTOTCOSTSR
        /// </summary>
        [Display(Name = "RTOTCOSTSR", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.RTOTCOSTSR, Id = Index.RTOTCOSTSR)]
        public decimal RTOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTOTCOSTHM
        /// </summary>
        [Display(Name = "CTOTCOSTHM", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CTOTCOSTHM, Id = Index.CTOTCOSTHM)]
        public decimal CTOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RTOTCOSTHM
        /// </summary>
        [Display(Name = "RTOTCOSTHM", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.RTOTCOSTHM, Id = Index.RTOTCOSTHM)]
        public decimal RTOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTOTBILLSR
        /// </summary>
        [Display(Name = "CTOTBILLSR", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CTOTBILLSR, Id = Index.CTOTBILLSR)]
        public decimal CTOTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RTOTBILLSR
        /// </summary>
        [Display(Name = "RTOTBILLSR", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.RTOTBILLSR, Id = Index.RTOTBILLSR)]
        public decimal RTOTBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CTOTBILLHM
        /// </summary>
        [Display(Name = "CTOTBILLHM", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CTOTBILLHM, Id = Index.CTOTBILLHM)]
        public decimal CTOTBILLHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RTOTBILLHM
        /// </summary>
        [Display(Name = "RTOTBILLHM", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.RTOTBILLHM, Id = Index.RTOTBILLHM)]
        public decimal RTOTBILLHM { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Printed", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.Printed, Id = Index.Printed)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Printed Printed { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus
        /// </summary>
        [Display(Name = "TransactionStatus", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.TransactionStatus TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumberOfDetails", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails)]
        public int NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets CreatedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedBy", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CreatedBy, Id = Index.CreatedBy)]
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets CreatedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedOn", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CreatedOn, Id = Index.CreatedOn)]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets CreatedAt
        /// </summary>
        [Display(Name = "CreatedAt", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.CreatedAt, Id = Index.CreatedAt)]
        public TimeSpan CreatedAt { get; set; }

        /// <summary>
        /// Gets or sets ApprovedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedBy", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.ApprovedBy, Id = Index.ApprovedBy)]
        public string ApprovedBy { get; set; }

        /// <summary>
        /// Gets or sets ApprovedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedOn", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.ApprovedOn, Id = Index.ApprovedOn)]
        public DateTime ApprovedOn { get; set; }

        /// <summary>
        /// Gets or sets ApprovedAt
        /// </summary>
        [Display(Name = "ApprovedAt", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.ApprovedAt, Id = Index.ApprovedAt)]
        public TimeSpan ApprovedAt { get; set; }

        /// <summary>
        /// Gets or sets PostedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedBy", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.PostedBy, Id = Index.PostedBy)]
        public string PostedBy { get; set; }

        /// <summary>
        /// Gets or sets PostedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedOn", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.PostedOn, Id = Index.PostedOn)]
        public DateTime PostedOn { get; set; }

        /// <summary>
        /// Gets or sets PostedAt
        /// </summary>
        [Display(Name = "PostedAt", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.PostedAt, Id = Index.PostedAt)]
        public TimeSpan PostedAt { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets ShowProgressBarDuringPosting
        /// </summary>
        [Display(Name = "ShowProgressBarDuringPosting", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.ShowProgressBarDuringPosting, Id = Index.ShowProgressBarDuringPosting)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ShowProgressBarDuringPosting ShowProgressBarDuringPosting { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (ReviseEstimateResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        public string FiscalPeriodString
        {
         get { return EnumUtility.GetStringValue(FiscalPeriod); }
        }

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
         get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string PrintedString
        {
         get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// Gets TransactionStatus string value
        /// </summary>
        public string TransactionStatusString
        {
         get { return EnumUtility.GetStringValue(TransactionStatus); }
        }

        /// <summary>
        /// Gets ShowProgressBarDuringPosting string value
        /// </summary>
        public string ShowProgressBarDuringPostingString
        {
         get { return EnumUtility.GetStringValue(ShowProgressBarDuringPosting); }
        }

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
         get { return EnumUtility.GetStringValue(Function); }
        }

        #endregion
    }
}
