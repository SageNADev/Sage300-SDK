// Copyright (c) 2021 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for CostEntriesHeaders
    /// </summary>
    [ViewModel(Id = EntityName)]
    public partial class ReviseEstimates : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (CostEntriesHeaderResx))]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber)]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets TotalCost
        /// </summary>
        [Display(Name = "TotalCost", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalCost, Id = Index.TotalCost)]
        public decimal TotalCost { get; set; }

        /// <summary>
        /// Gets or sets Overhead Amount Source Currency
        /// </summary>
        [Display(Name = "OverheadAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.OverheadAmountSourceCurrency, Id = Index.OverheadAmountSourceCurrency)]
        public decimal OverheadAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Overhead Amount Home Currency
        /// </summary>
        [Display(Name = "OverheadAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.OverheadAmountHomeCurrency, Id = Index.OverheadAmountHomeCurrency)]
        public decimal OverheadAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Labor Amount Source Currency
        /// </summary>
        [Display(Name = "LaborAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.LaborAmountSourceCurrency, Id = Index.LaborAmountSourceCurrency)]
        public decimal LaborAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Labor Amount Home Currency
        /// </summary>
        [Display(Name = "LaborAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.LaborAmountHomeCurrency, Id = Index.LaborAmountHomeCurrency)]
        public decimal LaborAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Cost Amount Source Currency
        /// </summary>
        [Display(Name = "TotalCostAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalCostAmountSourceCurrency, Id = Index.TotalCostAmountSourceCurrency)]
        public decimal TotalCostAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Cost Amount Home Currency
        /// </summary>
        [Display(Name = "TotalCostAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalCostAmountHomeCurrency, Id = Index.TotalCostAmountHomeCurrency)]
        public decimal TotalCostAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Billable Amount Source Currency
        /// </summary>
        [Display(Name = "TotalBillableAmountSourceCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalBillableAmountSourceCurrency, Id = Index.TotalBillableAmountSourceCurrency)]
        public decimal TotalBillableAmountSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Billable Amount Home Currency
        /// </summary>
        [Display(Name = "TotalBillableAmountHomeCurrency", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalBillableAmountHomeCurrency, Id = Index.TotalBillableAmountHomeCurrency)]
        public decimal TotalBillableAmountHomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantity
        /// </summary>
        [Display(Name = "TotalQuantity", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TotalQuantity, Id = Index.TotalQuantity)]
        public decimal TotalQuantity { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Printed", ResourceType = typeof (CostEntriesHeaderResx))]
        public bool Printed { get; set; }

        /// <summary>
        /// Gets or sets TransactionStatus
        /// </summary>
        [Display(Name = "TransactionStatus", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.TransactionStatus, Id = Index.TransactionStatus)]
        public TransactionStatus TransactionStatus { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumberOfDetails", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails)]
        public int NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields)]
        public int NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ICStat
        /// </summary>
        [Display(Name = "ICStat", ResourceType = typeof (CostEntriesHeaderResx))]
        public short ICStat { get; set; }

        /// <summary>
        /// Gets or sets NumberOfMiscellaneousCosts
        /// </summary>
        [Display(Name = "NumberOfMiscellaneousCosts", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NumberOfMiscellaneousCosts { get; set; }

        /// <summary>
        /// Gets or sets NumberOfTimecards
        /// </summary>
        [Display(Name = "NumberOfTimecards", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NumberOfTimecards { get; set; }

        /// <summary>
        /// Gets or sets NumberOfTimeExpenses
        /// </summary>
        [Display(Name = "NumberOfTimeExpenses", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NumberOfTimeExpenses { get; set; }

        /// <summary>
        /// Gets or sets NumberOfEquipmentUsages
        /// </summary>
        [Display(Name = "NumberOfEquipmentUsages", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NumberOfEquipmentUsages { get; set; }

        /// <summary>
        /// Gets or sets NumberOfMaterialUsages
        /// </summary>
        [Display(Name = "NumberOfMaterialUsages", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NumberOfMaterialUsages { get; set; }

        /// <summary>
        /// Gets or sets NumberOfMaterialReturns
        /// </summary>
        [Display(Name = "NumberOfMaterialReturns", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NumberOfMaterialReturns { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCharges
        /// </summary>
        [Display(Name = "NumberOfCharges", ResourceType = typeof (CostEntriesHeaderResx))]
        public int NumberOfCharges { get; set; }

        /// <summary>
        /// Gets or sets CreatedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedBy", ResourceType = typeof (CostEntriesHeaderResx))]
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets CreatedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedOn", ResourceType = typeof (CostEntriesHeaderResx))]
        public DateTime CreatedOn { get; set; }

        /// <summary>
        /// Gets or sets CreatedAt
        /// </summary>
        [Display(Name = "CreatedAt", ResourceType = typeof (CostEntriesHeaderResx))]
        public TimeSpan CreatedAt { get; set; }

        /// <summary>
        /// Gets or sets ApprovedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedBy", ResourceType = typeof (CostEntriesHeaderResx))]
        public string ApprovedBy { get; set; }

        /// <summary>
        /// Gets or sets ApprovedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApprovedOn", ResourceType = typeof (CostEntriesHeaderResx))]
        public DateTime ApprovedOn { get; set; }

        /// <summary>
        /// Gets or sets ApprovedAt
        /// </summary>
        [Display(Name = "ApprovedAt", ResourceType = typeof (CostEntriesHeaderResx))]
        public TimeSpan ApprovedAt { get; set; }

        /// <summary>
        /// Gets or sets PostedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedBy", ResourceType = typeof (CostEntriesHeaderResx))]
        public string PostedBy { get; set; }

        /// <summary>
        /// Gets or sets PostedOn
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostedOn", ResourceType = typeof (CostEntriesHeaderResx))]
        public DateTime PostedOn { get; set; }

        /// <summary>
        /// Gets or sets PostedAt
        /// </summary>
        [Display(Name = "PostedAt", ResourceType = typeof (CostEntriesHeaderResx))]
        public TimeSpan PostedAt { get; set; }

        /// <summary>
        /// Gets or sets GLEntryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLEntryDescription", ResourceType = typeof (CostEntriesHeaderResx))]
        public string GLEntryDescription { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof (CostEntriesHeaderResx))]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof (CostEntriesHeaderResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets ShowProgressBarDuringPosting
        /// </summary>
        [Display(Name = "ShowProgressBarDuringPosting", ResourceType = typeof (CostEntriesHeaderResx))]
        public int ShowProgressBarDuringPosting { get; set; }
        //public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ShowProgressBarDuringPosting ShowProgressBarDuringPosting { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (CostEntriesHeaderResx))]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        //public string FiscalPeriodString
        //{
        // get { return EnumUtility.GetStringValue(FiscalPeriod); }
        //}

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        //public string PrintedString
        //{
        // get { return EnumUtility.GetStringValue(Printed); }
        //}

        /// <summary>
        /// Gets TransactionStatus string value
        /// </summary>
        //public string TransactionStatusString
        //{
        // get { return EnumUtility.GetStringValue(TransactionStatus); }
        //}

        /// <summary>
        /// Gets ShowProgressBarDuringPosting string value
        /// </summary>
        //public string ShowProgressBarDuringPostingString
        //{
        // get { return EnumUtility.GetStringValue(ShowProgressBarDuringPosting); }
        //}

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
         get { return EnumUtility.GetStringValue(Function); }
        }

        /// <summary>
        /// Check the transaction/posting date is locked period
        /// </summary>
        public bool IsDateLocked { get; set; } = false;

        #endregion
    }
}
