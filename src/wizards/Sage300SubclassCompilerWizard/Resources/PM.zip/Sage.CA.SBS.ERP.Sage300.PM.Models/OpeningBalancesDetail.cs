// Copyright (c) 2020 Valued Partner  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for OpeningBalancesDetail
    /// </summary>
    public partial class OpeningBalancesDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Sequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Sequence", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int Sequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets OpeningType
        /// </summary>
        [Display(Name = "OpeningType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OpeningType, Id = Index.OpeningType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OpeningType OpeningType { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTCONTNO
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.FMTCONTNO, Id = Index.FMTCONTNO, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FMTCONTNO { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets ActualType
        /// </summary>
        [Display(Name = "ActualType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ActualType, Id = Index.ActualType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ActualType ActualType { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets CostType
        /// </summary>
        [Display(Name = "CostType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.CostType, Id = Index.CostType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.CostType CostType { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Customer", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerCurrency", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string RateDate { get; set; }

        /// <summary>
        /// Gets or sets Rate
        /// </summary>
        [Display(Name = "Rate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Rate, Id = Index.Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Rate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets OriginalQuantity
        /// </summary>
        [Display(Name = "OriginalQuantity", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OriginalQuantity, Id = Index.OriginalQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal OriginalQuantity { get; set; }

        /// <summary>
        /// Gets or sets ActualQuantity
        /// </summary>
        [Display(Name = "ActualQuantity", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ActualQuantity, Id = Index.ActualQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal ActualQuantity { get; set; }

        /// <summary>
        /// Gets or sets OriginalARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalARItemNumber", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OriginalARItemNumber, Id = Index.OriginalARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string OriginalARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalARUnitOfMeasure", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OriginalARUnitOfMeasure, Id = Index.OriginalARUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string OriginalARUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets OriginalUnitCost
        /// </summary>
        [Display(Name = "OriginalUnitCost", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OriginalUnitCost, Id = Index.OriginalUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OriginalUnitCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OEXTCOSTSR
        /// </summary>
        [Display(Name = "OEXTCOSTSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OEXTCOSTSR, Id = Index.OEXTCOSTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OEXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OEXTCOSTHM
        /// </summary>
        [Display(Name = "OEXTCOSTHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OEXTCOSTHM, Id = Index.OEXTCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OEXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets AEXTCOSTSR
        /// </summary>
        [Display(Name = "AEXTCOSTSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.AEXTCOSTSR, Id = Index.AEXTCOSTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AEXTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets AEXTCOSTHM
        /// </summary>
        [Display(Name = "AEXTCOSTHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.AEXTCOSTHM, Id = Index.AEXTCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AEXTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OOHTYPE
        /// </summary>
        [Display(Name = "OOHTYPE", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OOHTYPE, Id = Index.OOHTYPE, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.OOHTYPE OOHTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OOHRATE
        /// </summary>
        [Display(Name = "OOHRATE", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OOHRATE, Id = Index.OOHRATE, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OOHRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OOHPER
        /// </summary>
        [Display(Name = "OOHPER", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OOHPER, Id = Index.OOHPER, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal OOHPER { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OOHSR
        /// </summary>
        [Display(Name = "OOHSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OOHSR, Id = Index.OOHSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OOHSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OOHHM
        /// </summary>
        [Display(Name = "OOHHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OOHHM, Id = Index.OOHHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OOHHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets AOHSR
        /// </summary>
        [Display(Name = "AOHSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.AOHSR, Id = Index.AOHSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AOHSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets AOHHM
        /// </summary>
        [Display(Name = "AOHHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.AOHHM, Id = Index.AOHHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AOHHM { get; set; }

        /// <summary>
        /// Gets or sets LaborType
        /// </summary>
        [Display(Name = "LaborType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LaborType, Id = Index.LaborType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.LaborType LaborType { get; set; }

        /// <summary>
        /// Gets or sets LaborRate
        /// </summary>
        [Display(Name = "LaborRate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LaborRate, Id = Index.LaborRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LaborRate { get; set; }

        /// <summary>
        /// Gets or sets LaborPercentage
        /// </summary>
        [Display(Name = "LaborPercentage", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LaborPercentage, Id = Index.LaborPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LaborPercentage { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OLABORSR
        /// </summary>
        [Display(Name = "OLABORSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OLABORSR, Id = Index.OLABORSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OLABORSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OLABORHM
        /// </summary>
        [Display(Name = "OLABORHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OLABORHM, Id = Index.OLABORHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OLABORHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ALABORSR
        /// </summary>
        [Display(Name = "ALABORSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ALABORSR, Id = Index.ALABORSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ALABORSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ALABORHM
        /// </summary>
        [Display(Name = "ALABORHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ALABORHM, Id = Index.ALABORHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ALABORHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OTOTCOSTSR
        /// </summary>
        [Display(Name = "OTOTCOSTSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OTOTCOSTSR, Id = Index.OTOTCOSTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OTOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OTOTCOSTHM
        /// </summary>
        [Display(Name = "OTOTCOSTHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OTOTCOSTHM, Id = Index.OTOTCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OTOTCOSTHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ATOTCOSTSR
        /// </summary>
        [Display(Name = "ATOTCOSTSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ATOTCOSTSR, Id = Index.ATOTCOSTSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ATOTCOSTSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ATOTCOSTHM
        /// </summary>
        [Display(Name = "ATOTCOSTHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ATOTCOSTHM, Id = Index.ATOTCOSTHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ATOTCOSTHM { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets OriginalBillingRate
        /// </summary>
        [Display(Name = "OriginalBillingRate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OriginalBillingRate, Id = Index.OriginalBillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OriginalBillingRate { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OBILLSR
        /// </summary>
        [Display(Name = "OBILLSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OBILLSR, Id = Index.OBILLSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OBILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OBILLHM
        /// </summary>
        [Display(Name = "OBILLHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OBILLHM, Id = Index.OBILLHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OBILLHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ABILLSR
        /// </summary>
        [Display(Name = "ABILLSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ABILLSR, Id = Index.ABILLSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ABILLSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets ABILLHM
        /// </summary>
        [Display(Name = "ABILLHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ABILLHM, Id = Index.ABILLHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ABILLHM { get; set; }

        /// <summary>
        /// Gets or sets RemainingToBeBilled
        /// </summary>
        [Display(Name = "RemainingToBeBilled", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.RemainingToBeBilled, Id = Index.RemainingToBeBilled, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingToBeBilled { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OPROFITSR
        /// </summary>
        [Display(Name = "OPROFITSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OPROFITSR, Id = Index.OPROFITSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OPROFITSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets OPROFITHM
        /// </summary>
        [Display(Name = "OPROFITHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OPROFITHM, Id = Index.OPROFITHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OPROFITHM { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets APROFITSR
        /// </summary>
        [Display(Name = "APROFITSR", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.APROFITSR, Id = Index.APROFITSR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal APROFITSR { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets APROFITHM
        /// </summary>
        [Display(Name = "APROFITHM", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.APROFITHM, Id = Index.APROFITHM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal APROFITHM { get; set; }

        /// <summary>
        /// Gets or sets TotalARCustomerReceipts
        /// </summary>
        [Display(Name = "TotalARCustomerReceipts", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.TotalARCustomerReceipts, Id = Index.TotalARCustomerReceipts, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalARCustomerReceipts { get; set; }

        /// <summary>
        /// Gets or sets LastARReceiptPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastARReceiptPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastARReceiptPostingDate, Id = Index.LastARReceiptPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastARReceiptPostingDate { get; set; }

        /// <summary>
        /// Gets or sets TotalAPVendorPayments
        /// </summary>
        [Display(Name = "TotalAPVendorPayments", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.TotalAPVendorPayments, Id = Index.TotalAPVendorPayments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAPVendorPayments { get; set; }

        /// <summary>
        /// Gets or sets LastAPPaymentPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastAPPaymentPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastAPPaymentPostingDate, Id = Index.LastAPPaymentPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastAPPaymentPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastCostPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastCostPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastCostPostingDate, Id = Index.LastCostPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastCostPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastBillingsPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastBillingsPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastBillingsPostingDate, Id = Index.LastBillingsPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastBillingsPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastRevRecognitionPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastRevRecognitionPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastRevRecognitionPostingDate, Id = Index.LastRevRecognitionPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastRevRecognitionPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastRevisedPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastRevisedPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastRevisedPostingDate, Id = Index.LastRevisedPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastRevisedPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastBillingsPercentComplete
        /// </summary>
        [Display(Name = "LastBillingsPercentComplete", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastBillingsPercentComplete, Id = Index.LastBillingsPercentComplete, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LastBillingsPercentComplete { get; set; }

        /// <summary>
        /// Gets or sets LastPurchaseOrderDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPurchaseOrderDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastPurchaseOrderDate, Id = Index.LastPurchaseOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastPurchaseOrderDate { get; set; }

        /// <summary>
        /// Gets or sets LastPOReceiptDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPOReceiptDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastPOReceiptDate, Id = Index.LastPOReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastPOReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets LastPOReturnDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPOReturnDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastPOReturnDate, Id = Index.LastPOReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastPOReturnDate { get; set; }

        /// <summary>
        /// Gets or sets LastCanadianPayrollPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastCanadianPayrollPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastCanadianPayrollPostingDate, Id = Index.LastCanadianPayrollPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastCanadianPayrollPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LastUSPayrollPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastUSPayrollPostingDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastUSPayrollPostingDate, Id = Index.LastUSPayrollPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastUSPayrollPostingDate { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [Display(Name = "ProjectStyle", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets Reversed
        /// </summary>
        [Display(Name = "Reversed", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Reversed, Id = Index.Reversed, FieldType = EntityFieldType.Int, Size = 2)]
        public short Reversed { get; set; }

        /// <summary>
        /// Gets or sets StoredQuantity
        /// </summary>
        [Display(Name = "StoredQuantity", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.StoredQuantity, Id = Index.StoredQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal StoredQuantity { get; set; }

        /// <summary>
        /// Gets or sets StoredCost
        /// </summary>
        [Display(Name = "StoredCost", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.StoredCost, Id = Index.StoredCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StoredCost { get; set; }

        /// <summary>
        /// Gets or sets StoredBillableAmount
        /// </summary>
        [Display(Name = "StoredBillableAmount", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.StoredBillableAmount, Id = Index.StoredBillableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StoredBillableAmount { get; set; }

        /// <summary>
        /// Gets or sets PreviousCompletedWork
        /// </summary>
        [Display(Name = "PreviousCompletedWork", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.PreviousCompletedWork, Id = Index.PreviousCompletedWork, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreviousCompletedWork { get; set; }

        /// <summary>
        /// Gets or sets OverheadAmount
        /// </summary>
        [Display(Name = "OverheadAmount", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.OverheadAmount, Id = Index.OverheadAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalStoredCost
        /// </summary>
        [Display(Name = "TotalStoredCost", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.TotalStoredCost, Id = Index.TotalStoredCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalStoredCost { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COHTYPE
        /// </summary>
        [Display(Name = "COHTYPE", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.COHTYPE, Id = Index.COHTYPE, FieldType = EntityFieldType.Int, Size = 2)]
        public short COHTYPE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COHRATE
        /// </summary>
        [Display(Name = "COHRATE", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.COHRATE, Id = Index.COHRATE, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal COHRATE { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets COHPER
        /// </summary>
        [Display(Name = "COHPER", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.COHPER, Id = Index.COHPER, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal COHPER { get; set; }

        /// <summary>
        /// Gets or sets UseAIAReport
        /// </summary>
        [Display(Name = "UseAIAReport", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.UseAIAReport, Id = Index.UseAIAReport, FieldType = EntityFieldType.Int, Size = 2)]
        public bool UseAIAReport { get; set; }

        /// <summary>
        /// Gets or sets PreviousCertificatesForPayment
        /// </summary>
        [Display(Name = "PreviousCertificatesForPayment", ResourceType = typeof (OpeningBalancesDetailResx))]
        //[ViewField(Name = Fields.PreviousCertificatesForPayment, Id = Index.PreviousCertificatesForPayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreviousCertificatesForPayment { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public short FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets G703ColumnFFromLastAIARepo
        /// </summary>
        [Display(Name = "G703ColumnFFromLastAIARepo", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.G703ColumnFFromLastAIARepo, Id = Index.G703ColumnFFromLastAIARepo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal G703ColumnFFromLastAIARepo { get; set; }

        /// <summary>
        /// Gets or sets G703ColumnIFromLastAIARepo
        /// </summary>
        [Display(Name = "G703ColumnIFromLastAIARepo", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.G703ColumnIFromLastAIARepo, Id = Index.G703ColumnIFromLastAIARepo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal G703ColumnIFromLastAIARepo { get; set; }

        /// <summary>
        /// Gets or sets LastOEShipmentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOEShipmentDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastOEShipmentDate, Id = Index.LastOEShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastOEShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets LastOEInvoiceDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastOEInvoiceDate", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.LastOEInvoiceDate, Id = Index.LastOEInvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastOEInvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Function Function { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CONTDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractDescription", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.CONTDESC, Id = Index.CONTDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string CONTDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets PROJDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectDescription", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.PROJDESC, Id = Index.PROJDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string PROJDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets CATDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.CATDESC, Id = Index.CATDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string CATDESC { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RESDESC
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ResourceDescription", ResourceType = typeof (OpeningBalancesDetailResx))]
        [ViewField(Name = Fields.RESDESC, Id = Index.RESDESC, FieldType = EntityFieldType.Char, Size = 60)]
        public string RESDESC { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets OpeningType string value
        /// </summary>
        public string OpeningTypeString
        {
         get { return EnumUtility.GetStringValue(OpeningType); }
        }

        /// <summary>
        /// Gets ActualType string value
        /// </summary>
        public string ActualTypeString
        {
         get { return EnumUtility.GetStringValue(ActualType); }
        }

        /// <summary>
        /// Gets CostType string value
        /// </summary>
        public string CostTypeString
        {
         get { return EnumUtility.GetStringValue(CostType); }
        }

        /// <summary>
        /// Gets RateOperation string value
        /// </summary>
        public string RateOperationString
        {
         get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets OOHTYPE string value
        /// </summary>
        public string OOHTYPEString
        {
         get { return EnumUtility.GetStringValue(OOHTYPE); }
        }

        /// <summary>
        /// Gets LaborType string value
        /// </summary>
        public string LaborTypeString
        {
         get { return EnumUtility.GetStringValue(LaborType); }
        }

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString
        {
         get { return EnumUtility.GetStringValue(BillingType); }
        }

        /// <summary>
        /// Gets ProjectStyle string value
        /// </summary>
        public string ProjectStyleString
        {
         get { return EnumUtility.GetStringValue(ProjectStyle); }
        }

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString
        {
         get { return EnumUtility.GetStringValue(ProjectType); }
        }

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString
        {
         get { return EnumUtility.GetStringValue(AccountingMethod); }
        }

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString
        {
         get { return EnumUtility.GetStringValue(InvoiceType); }
        }

        /// <summary>
        /// Gets Function string value
        /// </summary>
        public string FunctionString
        {
         get { return EnumUtility.GetStringValue(Function); }
        }

        #endregion
    }
}
