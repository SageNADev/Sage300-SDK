// Copyright (c) 2023 Sage.CA.SBS.ERP.Sage300  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PM.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PM.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PM.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PM.Models
{
    /// <summary>
    /// Partial class for BudgetDetail
    /// </summary>
    public partial class BudgetDetail : ModelBase
    {
        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SEQ
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SEQ", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.SEQ, Id = Index.SEQ, FieldType = EntityFieldType.Long, Size = 4)]
        public int SEQ { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets LINENUM
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LINENUM", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.LINENUM, Id = Index.LINENUM, FieldType = EntityFieldType.Long, Size = 4)]
        public int LINENUM { get; set; }

        /// <summary>
        /// Gets or sets ContractUniq
        /// </summary>
        [Display(Name = "ContractUniq", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.ContractUniq, Id = Index.ContractUniq, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ContractUniq { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets BudgetSet
        /// </summary>
        [Display(Name = "BudgetSet", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.BudgetSet, Id = Index.BudgetSet, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.BudgetSet BudgetSet { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24)]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets RevenueCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueCurrency", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RevenueCurrency, Id = Index.RevenueCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string RevenueCurrency { get; set; }

        /// <summary>
        /// Gets or sets CostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostCurrency", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CostCurrency, Id = Index.CostCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CostCurrency { get; set; }

        /// <summary>
        /// Gets or sets CurrencyType
        /// </summary>
        [Display(Name = "CurrencyType", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CurrencyType, Id = Index.CurrencyType, FieldType = EntityFieldType.Int, Size = 2)]
        public short CurrencyType { get; set; }

        /// <summary>
        /// Gets or sets ContractStyle
        /// </summary>
        [Display(Name = "ContractStyle", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.ContractStyle, Id = Index.ContractStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ContractStyle ContractStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod1
        /// </summary>
        [Display(Name = "QuantityForPeriod1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod1, Id = Index.QuantityForPeriod1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod2
        /// </summary>
        [Display(Name = "QuantityForPeriod2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod2, Id = Index.QuantityForPeriod2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod3
        /// </summary>
        [Display(Name = "QuantityForPeriod3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod3, Id = Index.QuantityForPeriod3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod4
        /// </summary>
        [Display(Name = "QuantityForPeriod4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod4, Id = Index.QuantityForPeriod4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod4 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod5
        /// </summary>
        [Display(Name = "QuantityForPeriod5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod5, Id = Index.QuantityForPeriod5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod5 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod6
        /// </summary>
        [Display(Name = "QuantityForPeriod6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod6, Id = Index.QuantityForPeriod6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod6 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod7
        /// </summary>
        [Display(Name = "QuantityForPeriod7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod7, Id = Index.QuantityForPeriod7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod7 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod8
        /// </summary>
        [Display(Name = "QuantityForPeriod8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod8, Id = Index.QuantityForPeriod8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod8 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod9
        /// </summary>
        [Display(Name = "QuantityForPeriod9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod9, Id = Index.QuantityForPeriod9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod9 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod10
        /// </summary>
        [Display(Name = "QuantityForPeriod10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod10, Id = Index.QuantityForPeriod10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod10 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod11
        /// </summary>
        [Display(Name = "QuantityForPeriod11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod11, Id = Index.QuantityForPeriod11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod11 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod12
        /// </summary>
        [Display(Name = "QuantityForPeriod12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod12, Id = Index.QuantityForPeriod12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod12 { get; set; }

        /// <summary>
        /// Gets or sets QuantityForPeriod13
        /// </summary>
        [Display(Name = "QuantityForPeriod13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.QuantityForPeriod13, Id = Index.QuantityForPeriod13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal QuantityForPeriod13 { get; set; }

        /// <summary>
        /// Gets or sets Q14
        /// </summary>
        [Display(Name = "Q14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Q14, Id = Index.Q14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Q14 { get; set; }

        /// <summary>
        /// Gets or sets Q15
        /// </summary>
        [Display(Name = "Q15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Q15, Id = Index.Q15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Q15 { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantityForTheYear
        /// </summary>
        [Display(Name = "TotalQuantityForTheYear", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalQuantityForTheYear, Id = Index.TotalQuantityForTheYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal TotalQuantityForTheYear { get; set; }

        /// <summary>
        /// Gets or sets CS1
        /// </summary>
        [Display(Name = "CS1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CS1, Id = Index.CS1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CS1 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod2
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod2, Id = Index.TotalCostSourceForPeriod2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod3
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod3, Id = Index.TotalCostSourceForPeriod3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod4
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod4, Id = Index.TotalCostSourceForPeriod4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod4 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod5
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod5, Id = Index.TotalCostSourceForPeriod5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod5 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod6
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod6, Id = Index.TotalCostSourceForPeriod6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod6 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod7
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod7, Id = Index.TotalCostSourceForPeriod7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod7 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod8
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod8, Id = Index.TotalCostSourceForPeriod8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod8 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForPeriod9
        /// </summary>
        [Display(Name = "TotalCostSourceForPeriod9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForPeriod9, Id = Index.TotalCostSourceForPeriod9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForPeriod9 { get; set; }

        /// <summary>
        /// Gets or sets CS10
        /// </summary>
        [Display(Name = "CS10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CS10, Id = Index.CS10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CS10 { get; set; }

        /// <summary>
        /// Gets or sets CS11
        /// </summary>
        [Display(Name = "CS11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CS11, Id = Index.CS11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CS11 { get; set; }

        /// <summary>
        /// Gets or sets CS12
        /// </summary>
        [Display(Name = "CS12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CS12, Id = Index.CS12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CS12 { get; set; }

        /// <summary>
        /// Gets or sets CS13
        /// </summary>
        [Display(Name = "CS13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CS13, Id = Index.CS13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CS13 { get; set; }

        /// <summary>
        /// Gets or sets CS14
        /// </summary>
        [Display(Name = "CS14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CS14, Id = Index.CS14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CS14 { get; set; }

        /// <summary>
        /// Gets or sets CS15
        /// </summary>
        [Display(Name = "CS15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CS15, Id = Index.CS15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CS15 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostSourceForTheYear
        /// </summary>
        [Display(Name = "TotalCostSourceForTheYear", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostSourceForTheYear, Id = Index.TotalCostSourceForTheYear, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostSourceForTheYear { get; set; }

        /// <summary>
        /// Gets or sets CH1
        /// </summary>
        [Display(Name = "CH1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH1, Id = Index.CH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH1 { get; set; }

        /// <summary>
        /// Gets or sets CH2
        /// </summary>
        [Display(Name = "CH2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH2, Id = Index.CH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH2 { get; set; }

        /// <summary>
        /// Gets or sets CH3
        /// </summary>
        [Display(Name = "CH3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH3, Id = Index.CH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH3 { get; set; }

        /// <summary>
        /// Gets or sets CH4
        /// </summary>
        [Display(Name = "CH4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH4, Id = Index.CH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH4 { get; set; }

        /// <summary>
        /// Gets or sets CH5
        /// </summary>
        [Display(Name = "CH5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH5, Id = Index.CH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH5 { get; set; }

        /// <summary>
        /// Gets or sets CH6
        /// </summary>
        [Display(Name = "CH6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH6, Id = Index.CH6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH6 { get; set; }

        /// <summary>
        /// Gets or sets CH7
        /// </summary>
        [Display(Name = "CH7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH7, Id = Index.CH7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH7 { get; set; }

        /// <summary>
        /// Gets or sets CH8
        /// </summary>
        [Display(Name = "CH8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH8, Id = Index.CH8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH8 { get; set; }

        /// <summary>
        /// Gets or sets CH9
        /// </summary>
        [Display(Name = "CH9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH9, Id = Index.CH9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH9 { get; set; }

        /// <summary>
        /// Gets or sets CH10
        /// </summary>
        [Display(Name = "CH10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH10, Id = Index.CH10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH10 { get; set; }

        /// <summary>
        /// Gets or sets CH11
        /// </summary>
        [Display(Name = "CH11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH11, Id = Index.CH11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH11 { get; set; }

        /// <summary>
        /// Gets or sets CH12
        /// </summary>
        [Display(Name = "CH12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH12, Id = Index.CH12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH12 { get; set; }

        /// <summary>
        /// Gets or sets CH13
        /// </summary>
        [Display(Name = "CH13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH13, Id = Index.CH13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH13 { get; set; }

        /// <summary>
        /// Gets or sets CH14
        /// </summary>
        [Display(Name = "CH14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH14, Id = Index.CH14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH14 { get; set; }

        /// <summary>
        /// Gets or sets CH15
        /// </summary>
        [Display(Name = "CH15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CH15, Id = Index.CH15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CH15 { get; set; }

        /// <summary>
        /// Gets or sets TotalCostFunctionalForThe
        /// </summary>
        [Display(Name = "TotalCostFunctionalForThe", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalCostFunctionalForThe, Id = Index.TotalCostFunctionalForThe, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostFunctionalForThe { get; set; }

        /// <summary>
        /// Gets or sets RS1
        /// </summary>
        [Display(Name = "RS1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS1, Id = Index.RS1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS1 { get; set; }

        /// <summary>
        /// Gets or sets RS2
        /// </summary>
        [Display(Name = "RS2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS2, Id = Index.RS2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS2 { get; set; }

        /// <summary>
        /// Gets or sets RS3
        /// </summary>
        [Display(Name = "RS3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS3, Id = Index.RS3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS3 { get; set; }

        /// <summary>
        /// Gets or sets RS4
        /// </summary>
        [Display(Name = "RS4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS4, Id = Index.RS4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS4 { get; set; }

        /// <summary>
        /// Gets or sets RS5
        /// </summary>
        [Display(Name = "RS5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS5, Id = Index.RS5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS5 { get; set; }

        /// <summary>
        /// Gets or sets RS6
        /// </summary>
        [Display(Name = "RS6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS6, Id = Index.RS6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS6 { get; set; }

        /// <summary>
        /// Gets or sets RS7
        /// </summary>
        [Display(Name = "RS7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS7, Id = Index.RS7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS7 { get; set; }

        /// <summary>
        /// Gets or sets RS8
        /// </summary>
        [Display(Name = "RS8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS8, Id = Index.RS8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS8 { get; set; }

        /// <summary>
        /// Gets or sets RS9
        /// </summary>
        [Display(Name = "RS9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS9, Id = Index.RS9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS9 { get; set; }

        /// <summary>
        /// Gets or sets RS10
        /// </summary>
        [Display(Name = "RS10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS10, Id = Index.RS10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS10 { get; set; }

        /// <summary>
        /// Gets or sets RS11
        /// </summary>
        [Display(Name = "RS11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS11, Id = Index.RS11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS11 { get; set; }

        /// <summary>
        /// Gets or sets RS12
        /// </summary>
        [Display(Name = "RS12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS12, Id = Index.RS12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS12 { get; set; }

        /// <summary>
        /// Gets or sets RS13
        /// </summary>
        [Display(Name = "RS13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS13, Id = Index.RS13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS13 { get; set; }

        /// <summary>
        /// Gets or sets RS14
        /// </summary>
        [Display(Name = "RS14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS14, Id = Index.RS14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS14 { get; set; }

        /// <summary>
        /// Gets or sets RS15
        /// </summary>
        [Display(Name = "RS15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RS15, Id = Index.RS15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RS15 { get; set; }

        /// <summary>
        /// Gets or sets TotalRevenueSourceForTheY
        /// </summary>
        [Display(Name = "TotalRevenueSourceForTheY", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalRevenueSourceForTheY, Id = Index.TotalRevenueSourceForTheY, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRevenueSourceForTheY { get; set; }

        /// <summary>
        /// Gets or sets RH1
        /// </summary>
        [Display(Name = "RH1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH1, Id = Index.RH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH1 { get; set; }

        /// <summary>
        /// Gets or sets RH2
        /// </summary>
        [Display(Name = "RH2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH2, Id = Index.RH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH2 { get; set; }

        /// <summary>
        /// Gets or sets RH3
        /// </summary>
        [Display(Name = "RH3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH3, Id = Index.RH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH3 { get; set; }

        /// <summary>
        /// Gets or sets RH4
        /// </summary>
        [Display(Name = "RH4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH4, Id = Index.RH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH4 { get; set; }

        /// <summary>
        /// Gets or sets RH5
        /// </summary>
        [Display(Name = "RH5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH5, Id = Index.RH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH5 { get; set; }

        /// <summary>
        /// Gets or sets RH6
        /// </summary>
        [Display(Name = "RH6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH6, Id = Index.RH6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH6 { get; set; }

        /// <summary>
        /// Gets or sets RH7
        /// </summary>
        [Display(Name = "RH7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH7, Id = Index.RH7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH7 { get; set; }

        /// <summary>
        /// Gets or sets RH8
        /// </summary>
        [Display(Name = "RH8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH8, Id = Index.RH8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH8 { get; set; }

        /// <summary>
        /// Gets or sets RH9
        /// </summary>
        [Display(Name = "RH9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH9, Id = Index.RH9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH9 { get; set; }

        /// <summary>
        /// Gets or sets RH10
        /// </summary>
        [Display(Name = "RH10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH10, Id = Index.RH10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH10 { get; set; }

        /// <summary>
        /// Gets or sets RH11
        /// </summary>
        [Display(Name = "RH11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH11, Id = Index.RH11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH11 { get; set; }

        /// <summary>
        /// Gets or sets RH12
        /// </summary>
        [Display(Name = "RH12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH12, Id = Index.RH12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH12 { get; set; }

        /// <summary>
        /// Gets or sets RH13
        /// </summary>
        [Display(Name = "RH13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH13, Id = Index.RH13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH13 { get; set; }

        /// <summary>
        /// Gets or sets RH14
        /// </summary>
        [Display(Name = "RH14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH14, Id = Index.RH14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH14 { get; set; }

        /// <summary>
        /// Gets or sets RH15
        /// </summary>
        [Display(Name = "RH15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RH15, Id = Index.RH15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RH15 { get; set; }

        /// <summary>
        /// Gets or sets TotalRevenueFunctionalForT
        /// </summary>
        [Display(Name = "TotalRevenueFunctionalForT", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.TotalRevenueFunctionalForT, Id = Index.TotalRevenueFunctionalForT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRevenueFunctionalForT { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod1
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod1, Id = Index.InquiryQuantityForPeriod1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod2
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod2, Id = Index.InquiryQuantityForPeriod2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod3
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod3, Id = Index.InquiryQuantityForPeriod3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod4
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod4, Id = Index.InquiryQuantityForPeriod4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod4 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod5
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod5, Id = Index.InquiryQuantityForPeriod5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod5 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod6
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod6, Id = Index.InquiryQuantityForPeriod6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod6 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod7
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod7, Id = Index.InquiryQuantityForPeriod7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod7 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod8
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod8, Id = Index.InquiryQuantityForPeriod8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod8 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod9
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod9, Id = Index.InquiryQuantityForPeriod9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod9 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod10
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod10, Id = Index.InquiryQuantityForPeriod10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod10 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod11
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod11, Id = Index.InquiryQuantityForPeriod11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod11 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod12
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod12, Id = Index.InquiryQuantityForPeriod12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod12 { get; set; }

        /// <summary>
        /// Gets or sets InquiryQuantityForPeriod13
        /// </summary>
        [Display(Name = "InquiryQuantityForPeriod13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryQuantityForPeriod13, Id = Index.InquiryQuantityForPeriod13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryQuantityForPeriod13 { get; set; }

        /// <summary>
        /// Gets or sets INQ14
        /// </summary>
        [Display(Name = "INQ14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INQ14, Id = Index.INQ14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ14 { get; set; }

        /// <summary>
        /// Gets or sets INQ15
        /// </summary>
        [Display(Name = "INQ15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INQ15, Id = Index.INQ15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal INQ15 { get; set; }

        /// <summary>
        /// Gets or sets InquiryTotalQuantityForTheY
        /// </summary>
        [Display(Name = "InquiryTotalQuantityForTheY", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.InquiryTotalQuantityForTheY, Id = Index.InquiryTotalQuantityForTheY, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal InquiryTotalQuantityForTheY { get; set; }

        /// <summary>
        /// Gets or sets INCS1
        /// </summary>
        [Display(Name = "INCS1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS1, Id = Index.INCS1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS1 { get; set; }

        /// <summary>
        /// Gets or sets INCS2
        /// </summary>
        [Display(Name = "INCS2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS2, Id = Index.INCS2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS2 { get; set; }

        /// <summary>
        /// Gets or sets INCS3
        /// </summary>
        [Display(Name = "INCS3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS3, Id = Index.INCS3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS3 { get; set; }

        /// <summary>
        /// Gets or sets INCS4
        /// </summary>
        [Display(Name = "INCS4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS4, Id = Index.INCS4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS4 { get; set; }

        /// <summary>
        /// Gets or sets INCS5
        /// </summary>
        [Display(Name = "INCS5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS5, Id = Index.INCS5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS5 { get; set; }

        /// <summary>
        /// Gets or sets INCS6
        /// </summary>
        [Display(Name = "INCS6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS6, Id = Index.INCS6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS6 { get; set; }

        /// <summary>
        /// Gets or sets INCS7
        /// </summary>
        [Display(Name = "INCS7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS7, Id = Index.INCS7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS7 { get; set; }

        /// <summary>
        /// Gets or sets INCS8
        /// </summary>
        [Display(Name = "INCS8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS8, Id = Index.INCS8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS8 { get; set; }

        /// <summary>
        /// Gets or sets INCS9
        /// </summary>
        [Display(Name = "INCS9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS9, Id = Index.INCS9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS9 { get; set; }

        /// <summary>
        /// Gets or sets INCS10
        /// </summary>
        [Display(Name = "INCS10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS10, Id = Index.INCS10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS10 { get; set; }

        /// <summary>
        /// Gets or sets INCS11
        /// </summary>
        [Display(Name = "INCS11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS11, Id = Index.INCS11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS11 { get; set; }

        /// <summary>
        /// Gets or sets INCS12
        /// </summary>
        [Display(Name = "INCS12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS12, Id = Index.INCS12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS12 { get; set; }

        /// <summary>
        /// Gets or sets INCS13
        /// </summary>
        [Display(Name = "INCS13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS13, Id = Index.INCS13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS13 { get; set; }

        /// <summary>
        /// Gets or sets INCS14
        /// </summary>
        [Display(Name = "INCS14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS14, Id = Index.INCS14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS14 { get; set; }

        /// <summary>
        /// Gets or sets INCS15
        /// </summary>
        [Display(Name = "INCS15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCS15, Id = Index.INCS15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCS15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INCSTOTAL
        /// </summary>
        [Display(Name = "INCSTOTAL", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCSTOTAL, Id = Index.INCSTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCSTOTAL { get; set; }

        /// <summary>
        /// Gets or sets INCH1
        /// </summary>
        [Display(Name = "INCH1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH1, Id = Index.INCH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH1 { get; set; }

        /// <summary>
        /// Gets or sets INCH2
        /// </summary>
        [Display(Name = "INCH2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH2, Id = Index.INCH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH2 { get; set; }

        /// <summary>
        /// Gets or sets INCH3
        /// </summary>
        [Display(Name = "INCH3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH3, Id = Index.INCH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH3 { get; set; }

        /// <summary>
        /// Gets or sets INCH4
        /// </summary>
        [Display(Name = "INCH4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH4, Id = Index.INCH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH4 { get; set; }

        /// <summary>
        /// Gets or sets INCH5
        /// </summary>
        [Display(Name = "INCH5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH5, Id = Index.INCH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH5 { get; set; }

        /// <summary>
        /// Gets or sets INCH6
        /// </summary>
        [Display(Name = "INCH6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH6, Id = Index.INCH6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH6 { get; set; }

        /// <summary>
        /// Gets or sets INCH7
        /// </summary>
        [Display(Name = "INCH7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH7, Id = Index.INCH7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH7 { get; set; }

        /// <summary>
        /// Gets or sets INCH8
        /// </summary>
        [Display(Name = "INCH8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH8, Id = Index.INCH8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH8 { get; set; }

        /// <summary>
        /// Gets or sets INCH9
        /// </summary>
        [Display(Name = "INCH9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH9, Id = Index.INCH9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH9 { get; set; }

        /// <summary>
        /// Gets or sets INCH10
        /// </summary>
        [Display(Name = "INCH10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH10, Id = Index.INCH10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH10 { get; set; }

        /// <summary>
        /// Gets or sets INCH11
        /// </summary>
        [Display(Name = "INCH11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH11, Id = Index.INCH11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH11 { get; set; }

        /// <summary>
        /// Gets or sets INCH12
        /// </summary>
        [Display(Name = "INCH12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH12, Id = Index.INCH12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH12 { get; set; }

        /// <summary>
        /// Gets or sets INCH13
        /// </summary>
        [Display(Name = "INCH13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH13, Id = Index.INCH13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH13 { get; set; }

        /// <summary>
        /// Gets or sets INCH14
        /// </summary>
        [Display(Name = "INCH14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH14, Id = Index.INCH14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH14 { get; set; }

        /// <summary>
        /// Gets or sets INCH15
        /// </summary>
        [Display(Name = "INCH15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCH15, Id = Index.INCH15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCH15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INCHTOTAL
        /// </summary>
        [Display(Name = "INCHTOTAL", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INCHTOTAL, Id = Index.INCHTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INCHTOTAL { get; set; }

        /// <summary>
        /// Gets or sets INRS1
        /// </summary>
        [Display(Name = "INRS1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS1, Id = Index.INRS1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS1 { get; set; }

        /// <summary>
        /// Gets or sets INRS2
        /// </summary>
        [Display(Name = "INRS2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS2, Id = Index.INRS2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS2 { get; set; }

        /// <summary>
        /// Gets or sets INRS3
        /// </summary>
        [Display(Name = "INRS3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS3, Id = Index.INRS3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS3 { get; set; }

        /// <summary>
        /// Gets or sets INRS4
        /// </summary>
        [Display(Name = "INRS4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS4, Id = Index.INRS4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS4 { get; set; }

        /// <summary>
        /// Gets or sets INRS5
        /// </summary>
        [Display(Name = "INRS5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS5, Id = Index.INRS5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS5 { get; set; }

        /// <summary>
        /// Gets or sets INRS6
        /// </summary>
        [Display(Name = "INRS6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS6, Id = Index.INRS6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS6 { get; set; }

        /// <summary>
        /// Gets or sets INRS7
        /// </summary>
        [Display(Name = "INRS7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS7, Id = Index.INRS7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS7 { get; set; }

        /// <summary>
        /// Gets or sets INRS8
        /// </summary>
        [Display(Name = "INRS8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS8, Id = Index.INRS8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS8 { get; set; }

        /// <summary>
        /// Gets or sets INRS9
        /// </summary>
        [Display(Name = "INRS9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS9, Id = Index.INRS9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS9 { get; set; }

        /// <summary>
        /// Gets or sets INRS10
        /// </summary>
        [Display(Name = "INRS10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS10, Id = Index.INRS10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS10 { get; set; }

        /// <summary>
        /// Gets or sets INRS11
        /// </summary>
        [Display(Name = "INRS11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS11, Id = Index.INRS11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS11 { get; set; }

        /// <summary>
        /// Gets or sets INRS12
        /// </summary>
        [Display(Name = "INRS12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS12, Id = Index.INRS12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS12 { get; set; }

        /// <summary>
        /// Gets or sets INRS13
        /// </summary>
        [Display(Name = "INRS13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS13, Id = Index.INRS13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS13 { get; set; }

        /// <summary>
        /// Gets or sets INRS14
        /// </summary>
        [Display(Name = "INRS14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS14, Id = Index.INRS14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS14 { get; set; }

        /// <summary>
        /// Gets or sets INRS15
        /// </summary>
        [Display(Name = "INRS15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRS15, Id = Index.INRS15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRS15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INRSTOTAL
        /// </summary>
        [Display(Name = "INRSTOTAL", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRSTOTAL, Id = Index.INRSTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRSTOTAL { get; set; }

        /// <summary>
        /// Gets or sets INRH1
        /// </summary>
        [Display(Name = "INRH1", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH1, Id = Index.INRH1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH1 { get; set; }

        /// <summary>
        /// Gets or sets INRH2
        /// </summary>
        [Display(Name = "INRH2", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH2, Id = Index.INRH2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH2 { get; set; }

        /// <summary>
        /// Gets or sets INRH3
        /// </summary>
        [Display(Name = "INRH3", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH3, Id = Index.INRH3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH3 { get; set; }

        /// <summary>
        /// Gets or sets INRH4
        /// </summary>
        [Display(Name = "INRH4", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH4, Id = Index.INRH4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH4 { get; set; }

        /// <summary>
        /// Gets or sets INRH5
        /// </summary>
        [Display(Name = "INRH5", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH5, Id = Index.INRH5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH5 { get; set; }

        /// <summary>
        /// Gets or sets INRH6
        /// </summary>
        [Display(Name = "INRH6", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH6, Id = Index.INRH6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH6 { get; set; }

        /// <summary>
        /// Gets or sets INRH7
        /// </summary>
        [Display(Name = "INRH7", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH7, Id = Index.INRH7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH7 { get; set; }

        /// <summary>
        /// Gets or sets INRH8
        /// </summary>
        [Display(Name = "INRH8", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH8, Id = Index.INRH8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH8 { get; set; }

        /// <summary>
        /// Gets or sets INRH9
        /// </summary>
        [Display(Name = "INRH9", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH9, Id = Index.INRH9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH9 { get; set; }

        /// <summary>
        /// Gets or sets INRH10
        /// </summary>
        [Display(Name = "INRH10", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH10, Id = Index.INRH10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH10 { get; set; }

        /// <summary>
        /// Gets or sets INRH11
        /// </summary>
        [Display(Name = "INRH11", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH11, Id = Index.INRH11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH11 { get; set; }

        /// <summary>
        /// Gets or sets INRH12
        /// </summary>
        [Display(Name = "INRH12", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH12, Id = Index.INRH12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH12 { get; set; }

        /// <summary>
        /// Gets or sets INRH13
        /// </summary>
        [Display(Name = "INRH13", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH13, Id = Index.INRH13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH13 { get; set; }

        /// <summary>
        /// Gets or sets INRH14
        /// </summary>
        [Display(Name = "INRH14", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH14, Id = Index.INRH14, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH14 { get; set; }

        /// <summary>
        /// Gets or sets INRH15
        /// </summary>
        [Display(Name = "INRH15", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRH15, Id = Index.INRH15, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRH15 { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INRHTOTAL
        /// </summary>
        [Display(Name = "INRHTOTAL", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.INRHTOTAL, Id = Index.INRHTOTAL, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal INRHTOTAL { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.RateOperator RateOperator { get; set; }

        /// <summary>
        /// Gets or sets Rate
        /// </summary>
        [Display(Name = "Rate", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Rate, Id = Index.Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal Rate { get; set; }

        /// <summary>
        /// Gets or sets Show
        /// </summary>
        [Display(Name = "Show", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Show, Id = Index.Show, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Show Show { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SCOSTS
        /// </summary>
        [Display(Name = "SCOSTS", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.SCOSTS, Id = Index.SCOSTS, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SCOSTS { get; set; }

        // TODO The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets SCOSTH
        /// </summary>
        [Display(Name = "SCOSTH", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.SCOSTH, Id = Index.SCOSTH, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SCOSTH { get; set; }

        /// <summary>
        /// Gets or sets RevenueSource
        /// </summary>
        [Display(Name = "RevenueSource", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RevenueSource, Id = Index.RevenueSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RevenueSource { get; set; }

        /// <summary>
        /// Gets or sets RevenueFunctional
        /// </summary>
        [Display(Name = "RevenueFunctional", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.RevenueFunctional, Id = Index.RevenueFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RevenueFunctional { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.PM.Models.Enums.Description Description { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof (BudgetDetailResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public short CostClass { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets BudgetSet string value
        /// </summary>
        public string BudgetSetString => EnumUtility.GetStringValue(BudgetSet);

        /// <summary>
        /// Gets ContractStyle string value
        /// </summary>
        public string ContractStyleString => EnumUtility.GetStringValue(ContractStyle);

        /// <summary>
        /// Gets ProjectType string value
        /// </summary>
        public string ProjectTypeString => EnumUtility.GetStringValue(ProjectType);

        /// <summary>
        /// Gets AccountingMethod string value
        /// </summary>
        public string AccountingMethodString => EnumUtility.GetStringValue(AccountingMethod);

        /// <summary>
        /// Gets RateOperator string value
        /// </summary>
        public string RateOperatorString => EnumUtility.GetStringValue(RateOperator);

        /// <summary>
        /// Gets Show string value
        /// </summary>
        public string ShowString => EnumUtility.GetStringValue(Show);

        /// <summary>
        /// Gets Description string value
        /// </summary>
        public string DescriptionString => EnumUtility.GetStringValue(Description);

        #endregion
    }
}
