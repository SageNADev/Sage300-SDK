// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for PriceListTaxAuthority
    /// </summary>
    public partial class PriceListTaxAuthority : ModelBase
    {
        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets PriceListCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PriceListCode", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PriceListCode, Id = Index.PriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceListCode { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthority", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludedInPrice
        /// </summary>
        [Display(Name = "TaxIncludedInPrice", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.TaxIncludedInPrice, Id = Index.TaxIncludedInPrice, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxIncludedinPrice TaxIncludedInPrice { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClass
        /// </summary>
        [Display(Name = "CustTaxClass", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CustomerTaxClass, Id = Index.CustomerTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerTaxClass { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxClassDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerTaxClassDescription", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.CustomerTaxClassDescription, Id = Index.CustomerTaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerTaxClassDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.TaxAuthorityDescription, Id = Index.TaxAuthorityDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber - Unique key for grid rows
        /// </summary>
        [IgnoreExportImport]
        [IsMvcSpecific]
        public long SerialNumber { get; set; }
    }
}
