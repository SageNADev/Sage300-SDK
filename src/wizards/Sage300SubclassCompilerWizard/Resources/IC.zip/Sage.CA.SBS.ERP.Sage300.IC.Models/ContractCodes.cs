﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contract Codes Class
    /// </summary>
    public class ContractCodes : ModelBase
    {
        /// <summary>
        /// Gets and Sets ContractCode
        /// </summary>
        [Display(Name = "ContractCode", ResourceType = typeof(ICCommonResx))]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets and Sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets and Sets ContractCode
        /// </summary>
        public long Days { get; set; }

        /// <summary>
        /// Gets and Sets ContractCode
        /// </summary>
        public long EffectiveDays { get; set; }

        /// <summary>
        /// Gets and Sets ContractCode
        /// </summary>
        public LifetimeContract1 LifeTimeContract { get; set; }
    }
}
