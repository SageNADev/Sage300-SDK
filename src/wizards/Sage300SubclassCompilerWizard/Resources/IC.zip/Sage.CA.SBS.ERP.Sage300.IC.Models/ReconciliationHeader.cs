// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for ReconciliationHeader
	/// </summary>
	public partial class ReconciliationHeader : ModelBase
	{

        /// <summary>
        /// 
        /// </summary>
	    public ReconciliationHeader()
	    {
	        Serials = new EnumerableResponse<SerialReconciliationDetail>();
	        Lots = new EnumerableResponse<LotReconciliationDetail>();
	    }

		/// <summary>
		/// Gets or sets SequenceNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal SequenceNumber { get; set; }

		/// <summary>
		/// Gets or sets DocumentNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string DocumentNumber { get; set; }

		/// <summary>
		/// Gets or sets ItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ItemNumber { get; set; }

		/// <summary>
		/// Gets or sets Location
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string Location { get; set; }

		/// <summary>
		/// Gets or sets TransactionDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime TransactionDate { get; set; }

		/// <summary>
		/// Gets or sets TransactionType
		/// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciliationTransactionType TransactionType { get; set; }

		/// <summary>
		/// Gets or sets StockUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StockUnitOfMeasure", ResourceType = typeof(SerialLotReconciliationsResx))]
		[ViewField(Name = Fields.StockUnitOfMeasure, Id = Index.StockUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
		public string StockUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets Quantity
		/// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal Quantity { get; set; }

		/// <summary>
		/// Gets or sets SerialQuantity
		/// </summary>
        [Display(Name = "SerialQuantity", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
		public long SerialQuantity { get; set; }

		/// <summary>
		/// Gets or sets LotQuantity
		/// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal LotQuantity { get; set; }

		/// <summary>
		/// Gets or sets ApplyToInvoiceNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApplyToInvoiceNumber", ResourceType = typeof(SerialLotReconciliationsResx))]
		[ViewField(Name = Fields.ApplyToInvoiceNumber, Id = Index.ApplyToInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string ApplyToInvoiceNumber { get; set; }

		/// <summary>
		/// Gets or sets Cost
		/// </summary>
        [Display(Name = "Cost", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal Cost { get; set; }

		/// <summary>
		/// Gets or sets SerialLotQuantityToProcess
		/// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal SerialLotQuantityToProcess { get; set; }

		/// <summary>
		/// Gets or sets NumberOfLotsToGenerate
		/// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal NumberOfLotsToGenerate { get; set; }

		/// <summary>
		/// Gets or sets QuantityperLot
		/// </summary>
		[Display(Name = "QuantityperLot", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityperLot { get; set; }

		/// <summary>
		/// Gets or sets ProcessCommand
		/// </summary>
		[Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
		public ProcessCommand ProcessCommand { get; set; }

		/// <summary>
		/// Gets or sets AllocateFromSerial
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "AllocateFromSerial", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
		public string AllocateFromSerial { get; set; }

		/// <summary>
		/// Gets or sets AllocateFromLot
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "AllocateFromLot", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
		public string AllocateFromLot { get; set; }

		/// <summary>
		/// Gets or sets SerialLotWindowHandle
		/// </summary>
		[Display(Name = "SerialLotWindowHandle", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
		public long SerialLotWindowHandle { get; set; }

        /// <summary>
        /// Gets or sets HeaderExists
        /// </summary>
        public bool HeaderExists { get; set; }

        /// <summary>
        /// Gets or sets Serials
        /// </summary>
        public EnumerableResponse<SerialReconciliationDetail> Serials { get; set; }

        /// <summary>
        /// Gets or sets Lots
        /// </summary>
        public EnumerableResponse<LotReconciliationDetail> Lots { get; set; }
		#region UI Strings

		/// <summary>
		/// Gets TransactionType string value
		/// </summary>
		public string TransactionTypeString
		{
			get { return EnumUtility.GetStringValue(TransactionType); }
		}

		/// <summary>
		/// Gets ProcessCommand string value
		/// </summary>
		public string ProcessCommandString
		{
			get { return EnumUtility.GetStringValue(ProcessCommand); }
		}

		#endregion
	}
}
