// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for ICDrillDownDriver
	/// </summary>
	public partial class ICDrillDownDriver : ModelBase
	{
		/// <summary>
		/// Gets or sets DrilldownApplicationCode
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]		
		[ViewField(Name = Fields.DrilldownApplicationCode, Id = Index.DrilldownApplicationCode, FieldType = EntityFieldType.Char, Size = 2)]
		public string DrilldownApplicationCode { get; set; }

		/// <summary>
		/// Gets or sets DrilldownTransactionType </summary>		
		[ViewField(Name = Fields.DrilldownTransactionType, Id = Index.DrilldownTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
		public int DrilldownTransactionType { get; set; }

		/// <summary>
		/// Gets or sets DrilldownLink
		/// </summary>	
		[ViewField(Name = Fields.DrilldownLink, Id = Index.DrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal DrilldownLink { get; set; }

		/// <summary>
		/// Gets or sets DrilldownType
		/// </summary>		
		[ViewField(Name = Fields.DrilldownType, Id = Index.DrilldownType, FieldType = EntityFieldType.Int, Size = 2)]
		public DrilldownType DrilldownType { get; set; }

		/// <summary>
		/// Gets or sets RotoIDOfUIobject
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]		
		public string RotoIdOfUIobject { get; set; }

		/// <summary>
		/// Gets or sets Parameters
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]		
		[ViewField(Name = Fields.Parameters, Id = Index.Parameters, FieldType = EntityFieldType.Char, Size = 250)]
		public string Parameters { get; set; }

		/// <summary>
		/// Gets or sets DocumentKey
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]		
		[ViewField(Name = Fields.DocumentKey, Id = Index.DocumentKey, FieldType = EntityFieldType.Char, Size = 40)]
		public string DocumentKey { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets DrilldownType string value
		/// </summary>
		public string DrilldownTypeString
		{
			get { return EnumUtility.GetStringValue(DrilldownType); }
		}

		#endregion
	}
}
