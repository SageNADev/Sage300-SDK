// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for Restart
	/// </summary>
	public partial class Restart : ModelBase
	{
		/// <summary>
		/// Gets or sets Key
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Key, Id = Index.Key, FieldType = EntityFieldType.Char, Size = 50)]
		public string Key { get; set; }

		/// <summary>
		/// Gets or sets UserID
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8)]
		public string UserID { get; set; }

		/// <summary>
		/// Gets or sets DataBlock1
		/// </summary>
		[ViewField(Name = Fields.DataBlock1, Id = Index.DataBlock1, FieldType = EntityFieldType.Byte, Size = 255)]
		public byte[] DataBlock1 { get; set; }

	}
}
