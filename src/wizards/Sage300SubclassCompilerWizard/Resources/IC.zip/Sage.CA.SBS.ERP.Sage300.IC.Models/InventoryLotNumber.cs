// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for InventoryLotNumber
    /// </summary>
    public partial class InventoryLotNumber : ModelBase
    {
        public InventoryLotNumber()
        {
            OptionalFieldLot = new EnumerableResponse<LotOptionalField>();
        }
        /// <summary>
        /// Gets or sets UnformattedLotNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnformattedLotNumber, Id = Index.UnformattedLotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string UnformattedLotNumber { get; set; }

        /// <summary>
        /// Gets or sets Unformatted ItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets QuantityAvailable
        /// </summary>		 
        [Display(Name = "QuantityAvailable", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityAvailable, Id = Index.QuantityAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityAvailable { get; set; }

        /// <summary>
        /// Gets or sets QuantityOnorder
        /// </summary>		 
        [ViewField(Name = Fields.QuantityOnorder, Id = Index.QuantityOnorder, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOnorder { get; set; }

        /// <summary>
        /// Gets or sets StockDate
        /// </summary>
        [ValidateDateFormatAllowNullAttribute(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StockDate, Id = Index.StockDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? StockDate { get; set; }

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [ValidateDateFormatAllowNullAttribute(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets QuarantineReleaseDate
        /// </summary>
        [ValidateDateFormatAllowNullAttribute(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.QuarantineReleaseDate, Id = Index.QuarantineReleaseDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? QuarantineReleaseDate { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets QuantityLevel
        /// </summary>		 
        [ViewField(Name = Fields.QuantityLevel, Id = Index.QuantityLevel, FieldType = EntityFieldType.Int, Size = 2)]
        public QuantityLevel QuantityLevel { get; set; }

        /// <summary>
        /// Gets or sets QuantityForCosting
        /// </summary>		 
        [ViewField(Name = Fields.QuantityForCosting, Id = Index.QuantityForCosting, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityForCosting { get; set; }

        /// <summary>
        /// Gets or sets CostForCosting
        /// </summary>
        [ViewField(Name = Fields.CostForCosting, Id = Index.CostForCosting, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostForCosting { get; set; }

        /// <summary>
        /// Gets or sets Recalled
        /// </summary>		 
        [ViewField(Name = Fields.Recalled, Id = Index.Recalled, FieldType = EntityFieldType.Bool, Size = 2)]
        public Recalled Recalled { get; set; }

        /// <summary>
        /// Gets or sets DateRecalled
        /// </summary>
        [ValidateDateFormatAllowNullAttribute(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateRecalled, Id = Index.DateRecalled, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateRecalled { get; set; }

        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>		 
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod1InUse
        /// </summary>		 
        [ViewField(Name = Fields.ContractPeriod1InUse, Id = Index.ContractPeriod1InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod1InUse ContractPeriod1InUse { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod1ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod1ExpiryDate, Id = Index.ContractPeriod1ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod1ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod1EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod1EffectiveDate, Id = Index.ContractPeriod1EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod1EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod1Lifetime
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod1Lifetime, Id = Index.ContractPeriod1Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod1Lifetime ContractPeriod1Lifetime { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod2InUse
        /// </summary>               
        [ViewField(Name = Fields.ContractPeriod2InUse, Id = Index.ContractPeriod2InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod2InUse ContractPeriod2InUse { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod2ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod2ExpiryDate, Id = Index.ContractPeriod2ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod2ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod2EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod2EffectiveDate, Id = Index.ContractPeriod2EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod2EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod2Lifetime
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod2Lifetime, Id = Index.ContractPeriod2Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod2Lifetime ContractPeriod2Lifetime { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod3InUse
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod3InUse, Id = Index.ContractPeriod3InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod3InUse ContractPeriod3InUse { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod3ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod3ExpiryDate, Id = Index.ContractPeriod3ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod3ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod3EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod3EffectiveDate, Id = Index.ContractPeriod3EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod3EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod3Lifetime
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod3Lifetime, Id = Index.ContractPeriod3Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod3Lifetime ContractPeriod3Lifetime { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod4InUse
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod4InUse, Id = Index.ContractPeriod4InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod4InUse ContractPeriod4InUse { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod4ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod4ExpiryDate, Id = Index.ContractPeriod4ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod4ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod4EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod4EffectiveDate, Id = Index.ContractPeriod4EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod4EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod4Lifetime
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod4Lifetime, Id = Index.ContractPeriod4Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod4Lifetime ContractPeriod4Lifetime { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod5InUse
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod5InUse, Id = Index.ContractPeriod5InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod5InUse ContractPeriod5InUse { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod5ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod5ExpiryDate, Id = Index.ContractPeriod5ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod5ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod5EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod5EffectiveDate, Id = Index.ContractPeriod5EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ContractPeriod5EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod5Lifetime
        /// </summary>
        [ViewField(Name = Fields.ContractPeriod5Lifetime, Id = Index.ContractPeriod5Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public ContractPeriod5Lifetime ContractPeriod5Lifetime { get; set; }

        /// <summary>
        /// Gets or sets LotOnQuarantine
        /// </summary>
        [Display(Name = "QUARANTINEDON", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.LotOnQuarantine, Id = Index.LotOnQuarantine, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotOnQuarantine { get; set; }

        /// <summary>
        /// Gets or sets DateQuarantineed
        /// </summary>
        [ValidateDateFormatAllowNullAttribute(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateQuarantineed, Id = Index.DateQuarantineed, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateQuarantineed { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Finder.Status Status { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod1Description, Id = Index.ContractPeriod1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractPeriod1Description { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod2Description, Id = Index.ContractPeriod2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractPeriod2Description { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod3Description, Id = Index.ContractPeriod3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractPeriod3Description { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod4Description, Id = Index.ContractPeriod4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractPeriod4Description { get; set; }

        /// <summary>
        /// Gets or sets ContractPeriod5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContractPeriod5Description, Id = Index.ContractPeriod5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractPeriod5Description { get; set; }

        /// <summary>
        /// Gets or sets QuantityShippable
        /// </summary>
        [ViewField(Name = Fields.QuantityShippable, Id = Index.QuantityShippable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShippable { get; set; }

        /// <summary>
        /// Gets or sets AssetUnitCost
        /// </summary>
        [ViewField(Name = Fields.AssetUnitCost, Id = Index.AssetUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AssetUnitCost { get; set; }

        /// <summary>
        /// Gets or sets UpdatedbyUI
        /// </summary>
        [ViewField(Name = Fields.UpdatedbyUI, Id = Index.UpdatedbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
        public UpdatedByUI UpdatedbyUI { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrencyDecimals
        /// </summary>
        [ViewField(Name = Fields.HomeCurrencyDecimals, Id = Index.HomeCurrencyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int HomeCurrencyDecimals { get; set; }


        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        public EnumerableResponse<LotOptionalField> OptionalFieldLot { get; set; }



        #region UI Strings

        /// <summary>
        /// Gets QuantityLevel string value
        /// </summary>
        public string QuantityLevelString
        {
            get { return EnumUtility.GetStringValue(QuantityLevel); }
        }



        /// <summary>
        /// Gets ContractPeriod1InUse string value
        /// </summary>
        public string ContractPeriod1InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod1InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod1Lifetime string value
        /// </summary>
        public string ContractPeriod1LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod1Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod2InUse string value
        /// </summary>
        public string ContractPeriod2InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod2InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod2Lifetime string value
        /// </summary>
        public string ContractPeriod2LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod2Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod3InUse string value
        /// </summary>
        public string ContractPeriod3InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod3InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod3Lifetime string value
        /// </summary>
        public string ContractPeriod3LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod3Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod4InUse string value
        /// </summary>
        public string ContractPeriod4InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod4InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod4Lifetime string value
        /// </summary>
        public string ContractPeriod4LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod4Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod5InUse string value
        /// </summary>
        public string ContractPeriod5InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod5InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod5Lifetime string value
        /// </summary>
        public string ContractPeriod5LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod5Lifetime); }
        }


        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }


        /// <summary>
        /// Gets UpdatedbyUI string value
        /// </summary>
        public string UpdatedbyUIString
        {
            get { return EnumUtility.GetStringValue(UpdatedbyUI); }
        }


        /// <summary>
        /// Gets Recalled string value
        /// </summary>
        public string RecalledString
        {
            get { return EnumUtility.GetStringValue(Recalled); }
        }

        #endregion

        #region Grid UI properties

        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        public string FormattedItemNumber { get; set; }
        
        
        [Display(Name = "UOM", ResourceType = typeof(LotNumberResx))]
        public string Uom { get; set; }

        #endregion


    }
}
