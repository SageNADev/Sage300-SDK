// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Partial class for Receipt OptionalField
     /// </summary>
     public partial class ReceiptOptionalField : ModelBase
     {
          /// <summary>
          /// Gets or sets SequenceNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))] 
          [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long SequenceNumber {get; set;}

          /// <summary>
          /// Gets or sets OptionalField
          /// </summary>
          [Key]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalField", ResourceType = typeof(ICCommonResx))]   
          [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string OptionalField {get; set;}

          /// <summary>
          /// Gets or sets Value
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Value", ResourceType = typeof(ICCommonResx))]   
          [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
          public string Value {get; set;}

          /// <summary>
          /// Gets or sets Type
          /// </summary>
          [Display(Name = "Type", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
          public Enums.Type Type { get; set; }

          /// <summary>
          /// Gets or sets Length
          /// </summary>
          [Display(Name = "Length", ResourceType = typeof(ICCommonResx))] 
          [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
          public int Length {get; set;}

          /// <summary>
          /// Gets or sets Decimals
          /// </summary>
          [Display(Name = "Decimals", ResourceType = typeof(ICCommonResx))]  
          [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
          public int Decimals {get; set;}

          /// <summary>
          /// Gets or sets AllowBlank
          /// </summary>
          [Display(Name = "AllowBlank", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
          public Enums.AllowBlank AllowBlank { get; set; }

          /// <summary>
          /// Gets or sets Validate
          /// </summary>
          [Display(Name = "Validate", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
          public Enums.Validate Validate { get; set; }

          /// <summary>
          /// Gets or sets ValueSet
          /// </summary>
          [Display(Name = "ValueSet", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
          public Enums.ValueSet ValueSet { get; set; }

          /// <summary>
          /// Gets or sets TypedValueFieldIndex
          /// </summary>
          [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
          public long TypedValueFieldIndex {get; set;}

          /// <summary>
          /// Gets or sets TextValue
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "TextValue", ResourceType = typeof(ICCommonResx))] 
          [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
          public string TextValue {get; set;}

          /// <summary>
          /// Gets or sets AmountValue
          /// </summary>
          [Display(Name = "AmountValue", ResourceType = typeof(ICCommonResx))]  
          [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal AmountValue {get; set;}

          /// <summary>
          /// Gets or sets NumberValue
          /// </summary>
          [Display(Name = "NumberValue", ResourceType = typeof(ICCommonResx))]           
          [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal NumberValue {get; set;}

          /// <summary>
          /// Gets or sets IntegerValue
          /// </summary>
          [Display(Name = "IntegerValue", ResourceType = typeof(ICCommonResx))]                
          [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
          public long IntegerValue {get; set;}

          /// <summary>
          /// Gets or sets YesNoValue
          /// </summary>
          [Display(Name = "YesNoValue", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
          public Enums.YesNoValue YesNoValue { get; set; }

          /// <summary>
          /// Gets or sets DateValue
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DateValue", ResourceType = typeof(ICCommonResx))]  
          [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime? DateValue {get; set;}

          /// <summary>
          /// Gets or sets TimeValue
          /// </summary>
          [Display(Name = "TimeValue", ResourceType = typeof(ICCommonResx))]            
          [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
          public DateTime? TimeValue { get; set; }

          /// <summary>
          /// Gets or sets OptionalFieldDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalFieldDescription", ResourceType = typeof(ICCommonResx))]            
          [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string OptionalFieldDescription {get; set;}

          /// <summary>
          /// Gets or sets ValueDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ValueDescription", ResourceType = typeof(ICCommonResx))]            
          [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string ValueDescription {get; set;}

          /// <summary>
          /// Gets or sets Line Number.
          /// </summary>
          [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
          // [IgnoreExportImport]
          public int LineNumber { get; set; }
     }
}
