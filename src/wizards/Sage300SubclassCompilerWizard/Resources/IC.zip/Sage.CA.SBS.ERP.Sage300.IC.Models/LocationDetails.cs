/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for Location Details
    /// </summary>
    public partial class LocationDetail : ModelBase
    {

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets PickingSequence 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PickingSequence", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
        public string PickingSequence { get; set; }

        /// <summary>
        /// Gets or sets Allowed 
        /// </summary>
        [Display(Name = "Allowed", ResourceType = typeof(LocationDetailsResx))]
        [ViewField(Name = Fields.Allowed, Id = Index.Allowed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Allowed Allowed { get; set; }

        /// <summary>
        /// Gets or sets DateLocationActivated 
        /// </summary>
        [Display(Name = "DateLocationActivated", ResourceType = typeof(LocationDetailsResx))]
        [ViewField(Name = Fields.DateLocationActivated, Id = Index.DateLocationActivated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLocationActivated { get; set; }

        /// <summary>
        /// Gets or sets InUse 
        /// </summary>
        [Display(Name = "InUse", ResourceType = typeof(LocationDetailsResx))]
        [ViewField(Name = Fields.InUse, Id = Index.InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public Allowed InUse { get; set; }

        /// <summary>
        /// Gets or sets DateLastUsed 
        /// </summary>
        [Display(Name = "DateLastUsed", ResourceType = typeof(LocationDetailsResx))]
        [ViewField(Name = Fields.DateLastUsed, Id = Index.DateLastUsed, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastUsed { get; set; }

        /// <summary>
        /// Gets or sets QuantityonHandLastDayEnd 
        /// </summary>
        [Display(Name = "QuantityonHandLastDayEnd", ResourceType = typeof(LocationDetailsResx))]
        [ViewField(Name = Fields.QuantityonHandLastDayEnd, Id = Index.QuantityonHandLastDayEnd, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityonHandLastDayEnd { get; set; }

        /// <summary>
        /// Gets or sets QuantityonPOrO 
        /// </summary>
        [Display(Name = "QuantityonPO", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityonPOrO, Id = Index.QuantityonPOrO, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityonPOrO { get; set; }

        /// <summary>
        /// Gets or sets QuantityonSOrO 
        /// </summary>
        [Display(Name = "QuantityonSO", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityonSOrO, Id = Index.QuantityonSOrO, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityonSOrO { get; set; }

        /// <summary>
        /// Gets or sets QuantityNotinCostFile 
        /// </summary>
        [Display(Name = "QuantityNotInCostFile", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityNotinCostFile, Id = Index.QuantityNotinCostFile, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityNotinCostFile { get; set; }

        /// <summary>
        /// Gets or sets QuantityShippedNotCosted 
        /// </summary>
        [Display(Name = "QuantityShippedNotCosted", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityShippedNotCosted, Id = Index.QuantityShippedNotCosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShippedNotCosted { get; set; }

        /// <summary>
        /// Gets or sets QuantityReceivedNotCosted 
        /// </summary>
        [Display(Name = "QuantityReceivedNotCosted", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityReceivedNotCosted, Id = Index.QuantityReceivedNotCosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReceivedNotCosted { get; set; }

        /// <summary>
        /// Gets or sets QuantityAdjustedNotCosted 
        /// </summary>
        [Display(Name = "QuantityAdjustedNotCosted", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityAdjustedNotCosted, Id = Index.QuantityAdjustedNotCosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityAdjustedNotCosted { get; set; }

        /// <summary>
        /// Gets or sets NumberofUncontestedTransactions 
        /// </summary>
        [Display(Name = "NumberofUncontestedTransactions", ResourceType = typeof(LocationDetailsResx))]
        [ViewField(Name = Fields.NumberofUncontestedTransactions, Id = Index.NumberofUncontestedTransactions, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofUncontestedTransactions { get; set; }

        /// <summary>
        /// Gets or sets TotalCost 
        /// </summary>
        [Display(Name = "TotalCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TotalCost, Id = Index.TotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCost { get; set; }

        /// <summary>
        /// Gets or sets CostNotinCostFile 
        /// </summary>
        [Display(Name = "CostNotinCostFile", ResourceType = typeof(LocationDetailsResx))]
        [ViewField(Name = Fields.CostNotinCostFile, Id = Index.CostNotinCostFile, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostNotinCostFile { get; set; }

        /// <summary>
        /// Gets or sets CostUnitofMeasure 
        /// </summary>
        [Display(Name = "CostUnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostUnitofMeasure, Id = Index.CostUnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string CostUnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets CostUnitConversionFactor 
        /// </summary>
        [Display(Name = "CostUnitConversionFactor", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostUnitConversionFactor, Id = Index.CostUnitConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CostUnitConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets StandardCost 
        /// </summary>
        [Display(Name = "StandardCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StandardCost, Id = Index.StandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? StandardCost { get; set; }

        /// <summary>
        /// Gets or sets LastStandardCost 
        /// </summary>
        [Display(Name = "LastStandardCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LastStandardCost, Id = Index.LastStandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? LastStandardCost { get; set; }

        /// <summary>
        /// Gets or sets LastStandardCostDate 
        /// </summary>
        [Display(Name = "LastStandardCostDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LastStandardCostDate, Id = Index.LastStandardCostDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastStandardCostDate { get; set; }

        /// <summary>
        /// Gets or sets LastShipmentDate 
        /// </summary>
        [Display(Name = "LastShipmentDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LastShipmentDate, Id = Index.LastShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastShipmentDate { get; set; }

        /// <summary>
        /// Gets or sets AverageDaysToShip 
        /// </summary>
        [Display(Name = "AverageDaysToShip", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AverageDaysToShip, Id = Index.AverageDaysToShip, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal AverageDaysToShip { get; set; }

        /// <summary>
        /// Gets or sets AverageUnitsShipped 
        /// </summary>
        [Display(Name = "AverageUnitsShipped", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AverageUnitsShipped, Id = Index.AverageUnitsShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal AverageUnitsShipped { get; set; }

        /// <summary>
        /// Gets or sets ShipmentsUsedInCalculation 
        /// </summary>
        [Display(Name = "ShipmentsUsedInCalculation", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ShipmentsUsedInCalculation, Id = Index.ShipmentsUsedInCalculation, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentsUsedInCalculation { get; set; }

        /// <summary>
        /// Gets or sets LastReceiptDate 
        /// </summary>
        [Display(Name = "LastReceiptDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LastReceiptDate, Id = Index.LastReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets MostRecentCost 
        /// </summary>
        [Display(Name = "MostRecentCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.MostRecentCost, Id = Index.MostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? MostRecentCost { get; set; }

        /// <summary>
        /// Gets or sets UserDefinedCost1 
        /// </summary>
        [Display(Name = "UserDefinedCost1", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UserDefinedCost1, Id = Index.UserDefinedCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? UserDefinedCost1 { get; set; }

        /// <summary>
        /// Gets or sets UserDefinedCost2 
        /// </summary>
        [Display(Name = "UserDefinedCost2", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UserDefinedCost2, Id = Index.UserDefinedCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? UserDefinedCost2 { get; set; }

        /// <summary>
        /// Gets or sets LastUnitCost 
        /// </summary>
        [Display(Name = "LastUnitCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LastUnitCost, Id = Index.LastUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? LastUnitCost { get; set; }

        /// <summary>
        /// Gets or sets QuantityCommitted 
        /// </summary>
        [Display(Name = "QuantityCommitted", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityCommitted, Id = Index.QuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityCommitted { get; set; }

        /// <summary>
        /// Gets or sets LastAllocatedSerial 
        /// </summary>
        [StringLength(70, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastAllocatedSerial", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LastAllocatedSerial, Id = Index.LastAllocatedSerial, FieldType = EntityFieldType.Char, Size = 70)]
        public string LastAllocatedSerial { get; set; }

        /// <summary>
        /// Gets or sets LastAllocatedLot 
        /// </summary>
        [StringLength(70, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastAllocatedLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LastAllocatedLot, Id = Index.LastAllocatedLot, FieldType = EntityFieldType.Char, Size = 70)]
        public string LastAllocatedLot { get; set; }

        /// <summary>
        /// Gets or sets LeadTimeSIA 
        /// </summary>
        [Display(Name = "LeadTimeSIA", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LeadTimeSIA, Id = Index.LeadTimeSIA, FieldType = EntityFieldType.Int, Size = 2)]
        public int? LeadTimeSIA { get; set; }

        /// <summary>
        /// Gets or sets InventoryMinimumSIA 
        /// </summary>
        [Display(Name = "InventoryMinimumSIA", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InventoryMinimumSIA, Id = Index.InventoryMinimumSIA, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal? InventoryMinimumSIA { get; set; }

        /// <summary>
        /// Gets or sets QuantityAvailabletoShip 
        /// </summary>
        [Display(Name = "QuantityAvailableToShip", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityAvailabletoShip, Id = Index.QuantityAvailabletoShip, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityAvailabletoShip { get; set; }

        /// <summary>
        /// Gets or sets AccountSetCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets QuantityonHand 
        /// </summary>
        [Display(Name = "QuantityonHand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityonHand, Id = Index.QuantityonHand, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityonHand { get; set; }

        /// <summary>
        /// Gets or sets AverageCost 
        /// </summary>
        [Display(Name = "AverageCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AverageCost, Id = Index.AverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AverageCost { get; set; }

        /// <summary>
        /// Gets or sets CostingMethod 
        /// </summary>
        [Display(Name = "CostingMethod", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostingMethod, Id = Index.CostingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public CostingMethod CostingMethod { get; set; }

        /// <summary>
        /// Gets or sets Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets CheckItemExistence 
        /// </summary>
        [Display(Name = "CheckItemExistence", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
        public Allowed CheckItemExistence { get; set; }

        /// <summary>
        /// To get integer value for unique id for grid
        /// </summary>
        [Display(Name = "SerialNumber", ResourceType = typeof(ICCommonResx))]
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets or sets OldCostUnitofMeasure 
        /// Get the old property, to calculate the cost depending on Cost unit of measure
        /// </summary>
        [IgnoreExportImport]
        public string OldCostUnitofMeasure { get; set; }

        /// <summary>
        /// Gets Allowed string value
        /// </summary>
        [IgnoreExportImport]
        public string AllowedString
        {
            get { return EnumUtility.GetStringValue(Allowed); }
        }

        /// <summary>
        /// Gets In Use string value
        /// </summary>
        [IgnoreExportImport]
        public string InUseString
        {
            get { return EnumUtility.GetStringValue(InUse); }
        }

        /// <summary>
        /// Gets CostingMethod string value
        /// </summary>
        [IgnoreExportImport]
        public string CostingMethodString
        {
            get { return EnumUtility.GetStringValue(CostingMethod); }
        }

        #endregion
    }
}
