// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for WarrantyCode
    /// </summary>
    public partial class WarrantyCode : ModelBase
    {

        /// <summary>
        /// CustomerInquiryViewModel
        /// </summary>
        public WarrantyCode()
        {
            WarrantyCodeData = new EnumerableResponse<WarrantyCodes>();
        }
        #region Public Properties

        /// <summary>
        /// Gets or sets WarrantyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Warranty, Id = Index.Warranty, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Warranty { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Period1Days
        /// </summary>
        [Display(Name = "Period1Days", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period1Days, Id = Index.Period1Days, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period1Days { get; set; }

        /// <summary>
        /// Gets or sets Period1EffectiveDays
        /// </summary>
        [Display(Name = "Period1EffectiveDays", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period1EffectiveDays, Id = Index.Period1EffectiveDays, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period1EffectiveDays { get; set; }

        /// <summary>
        /// Gets or sets Period1IsLifetime
        /// </summary>
           [Display(Name = "Period1isLifetime", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period1IsLifetime, Id = Index.Period1IsLifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public Period1IsLifetime Period1IsLifetime { get; set; }

        /// <summary>
        /// Gets or sets Period1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period1Description", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period1Description, Id = Index.Period1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Period1Description { get; set; }

        /// <summary>
        /// Gets or sets Period2Days
        /// </summary>
           [Display(Name = "Period2Days", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period2Days, Id = Index.Period2Days, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period2Days { get; set; }

        /// <summary>
        /// Gets or sets Period2EffectiveDays
        /// </summary>
           [Display(Name = "Period1Days", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period2EffectiveDays, Id = Index.Period2EffectiveDays, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period2EffectiveDays { get; set; }

        /// <summary>
        /// Gets or sets Period2IsLifetime
        /// </summary>
            [Display(Name = "Period2isLifetime", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period2IsLifetime, Id = Index.Period2IsLifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public Period1IsLifetime Period2IsLifetime { get; set; }

        /// <summary>
        /// Gets or sets Period2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period2Description", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period2Description, Id = Index.Period2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Period2Description { get; set; }

        /// <summary>
        /// Gets or sets Period3Days
        /// </summary>
        [Display(Name = "Period3Days", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period3Days, Id = Index.Period3Days, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period3Days { get; set; }

        /// <summary>
        /// Gets or sets Period3EffectiveDays
        /// </summary>
           [Display(Name = "Period3EffectiveDays", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period3EffectiveDays, Id = Index.Period3EffectiveDays, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period3EffectiveDays { get; set; }

        /// <summary>
        /// Gets or sets Period3IsLifetime
        /// </summary>
          [Display(Name = "Period3isLifetime", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period3IsLifetime, Id = Index.Period3IsLifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public Period1IsLifetime Period3IsLifetime { get; set; }

        /// <summary>
        /// Gets or sets Period3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period3Description", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period3Description, Id = Index.Period3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Period3Description { get; set; }

        /// <summary>
        /// Gets or sets Period4Days
        /// </summary>
      [Display(Name = "Period4Days", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period4Days, Id = Index.Period4Days, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period4Days { get; set; }

        /// <summary>
        /// Gets or sets Period4EffectiveDays
        /// </summary>
         [Display(Name = "Period4EffectiveDays", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period4EffectiveDays, Id = Index.Period4EffectiveDays, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period4EffectiveDays { get; set; }

        /// <summary>
        /// Gets or sets Period4IsLifetime
        /// </summary>
       [Display(Name = "Period4isLifetime", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period4IsLifetime, Id = Index.Period4IsLifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public Period1IsLifetime Period4IsLifetime { get; set; }

        /// <summary>
        /// Gets or sets Period4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period4Description", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period4Description, Id = Index.Period4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Period4Description { get; set; }

        /// <summary>
        /// Gets or sets Period5Days
        /// </summary>
             [Display(Name = "Period5Days", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period5Days, Id = Index.Period5Days, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period5Days { get; set; }

        /// <summary>
        /// Gets or sets Period5EffectiveDays
        /// </summary>
       [Display(Name = "Period5EffectiveDays", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period5EffectiveDays, Id = Index.Period5EffectiveDays, FieldType = EntityFieldType.Long, Size = 4)]
        public long Period5EffectiveDays { get; set; }

        /// <summary>
        /// Gets or sets Period5IsLifetime
        /// </summary>
           [Display(Name = "Period5isLifetime", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period5IsLifetime, Id = Index.Period5IsLifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public Period1IsLifetime Period5IsLifetime { get; set; }

        /// <summary>
        /// Gets or sets Period5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period5Description", ResourceType = typeof(WarrantyCodesResx))]
        [ViewField(Name = Fields.Period5Description, Id = Index.Period5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Period5Description { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Period1IsLifetime string value
        /// </summary>
        public string Period1IsLifetimeString
        {
            get { return EnumUtility.GetStringValue(Period1IsLifetime); }
        }

        /// <summary>
        /// Gets Period2IsLifetime string value
        /// </summary>
        public string Period2IsLifetimeString
        {
            get { return EnumUtility.GetStringValue(Period2IsLifetime); }
        }

        /// <summary>
        /// Gets Period3IsLifetime string value
        /// </summary>
        public string Period3IsLifetimeString
        {
            get { return EnumUtility.GetStringValue(Period3IsLifetime); }
        }

        /// <summary>
        /// Gets Period4IsLifetime string value
        /// </summary>
        public string Period4IsLifetimeString
        {
            get { return EnumUtility.GetStringValue(Period4IsLifetime); }
        }

        /// <summary>
        /// Gets Period5IsLifetime string value
        /// </summary>
        public string Period5IsLifetimeString
        {
            get { return EnumUtility.GetStringValue(Period5IsLifetime); }
        }

        /// <summary>
        /// Gets or sets LifetimeContract1
        /// </summary>
        [Display(Name = "LifeTime", ResourceType = typeof(ICCommonResx))]
        public Period1IsLifetime PeriodIsLifetimes { get; set; }


        /// <summary>
        /// Gets or sets Days
        /// </summary>
        [Display(Name = "WarrantyDays", ResourceType = typeof(WarrantyCodesResx))]
        public long Days { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDays
        /// </summary>
        [Display(Name = "EffectiveDays", ResourceType = typeof(WarrantyCodesResx))]
        public long EffectiveDays { get; set; }
        /// <summary>
        /// Get or Set ContractCodeData List
        /// </summary>
        public EnumerableResponse<WarrantyCodes> WarrantyCodeData { get; set; }

        #endregion

        #endregion
    }
}

