// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ShipmentDetailLotNumber
    /// </summary>
    public partial class ShipmentDetailLotNumber : ModelBase
    {
        #region ShipmentDetailLotNumber model properties

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LotNumber", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpiryDate", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets TransactionQuantity
        /// </summary>
        [Display(Name = "TransactionQuantity", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotQuantityInStockingUOM
        /// </summary>
        [Display(Name = "LotQuantityInStockingUOM", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.LotQuantityInStockingUOM, Id = Index.LotQuantityInStockingUOM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantityInStockingUOM { get; set; }

        #endregion
    }
}
