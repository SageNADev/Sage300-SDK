// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ItemPricing
    /// </summary>
    public partial class ItemPricing : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ItemPricing" /> class.
        /// </summary>
        public ItemPricing()
        {
            ItemPricingDetails = new EnumerableResponse<ItemPricingDetail>();
            PriceListTaxAuthorities = new EnumerableResponse<PriceListTaxAuthority>();
            PricingPriceChecks = new EnumerableResponse<PricingPriceCheck>();
            BasePriceUnitsOfMeasures = new EnumerableResponse<ItemPricingDetail>();
            SalePriceUnitsOfMeasures = new EnumerableResponse<ItemPricingDetail>();
        }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        
        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CurrencyCode", ResourceType = typeof (ICCommonResx))]
        public string CurrencyCodeDescription { get; set; }
        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets PriceListCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PriceListCode", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.PriceListCode, Id = Index.PriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceListCode { get; set; }

        /// <summary>
        /// Gets or sets PriceListCode
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PriceListCode", ResourceType = typeof(ICCommonResx))]
        public string PriceListCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets DecimalsInPrice
        /// </summary>
        [Display(Name = "DecimalsInPrice", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DecimalsInPrice, Id = Index.DecimalsInPrice, FieldType = EntityFieldType.Int, Size = 2)]
        public DecimalsinPrice DecimalsInPrice { get; set; }

        /// <summary>
        /// Gets or sets MarkupCost
        /// </summary>
        [Display(Name = "MarkupCost", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.MarkupCost, Id = Index.MarkupCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal MarkupCost { get; set; }

        /// <summary>
        /// Gets or sets MarkupUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "MarkupUnitOfMeasure", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.MarkupUnitOfMeasure, Id = Index.MarkupUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string MarkupUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets MarkupConversionFactor
        /// </summary>
        [Display(Name = "MarkupConversionFactor", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.MarkupConversionFactor, Id = Index.MarkupConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal MarkupConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets SellingPriceBasedon
        /// </summary>
        [Display(Name = "SellingPriceBasedon", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.SellingPriceBasedon, Id = Index.SellingPriceBasedon, FieldType = EntityFieldType.Int, Size = 2)]
        public SellingPriceBasedon SellingPriceBasedon { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupPriceby
        /// </summary>
        [Display(Name = "DiscountOrMarkupPriceBy", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupPriceby, Id = Index.DiscountMarkupPriceby, FieldType = EntityFieldType.Int, Size = 2)]
        public DiscountMarkupPriceby DiscountMarkupPriceby { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupPercentage1
        /// </summary>
        [Display(Name = "DiscountOrMarkupPercentage1", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupPercentage1, Id = Index.DiscountMarkupPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountMarkupPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupPercentage2
        /// </summary>
        [Display(Name = "DiscountOrMarkupPercentage2", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupPercentage2, Id = Index.DiscountMarkupPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountMarkupPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupPercentage3
        /// </summary>
        [Display(Name = "DiscountOrMarkupPercentage3", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupPercentage3, Id = Index.DiscountMarkupPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountMarkupPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupPercentage4
        /// </summary>
        [Display(Name = "DiscountOrMarkupPercentage4", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupPercentage4, Id = Index.DiscountMarkupPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountMarkupPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupPercentage5
        /// </summary>
        [Display(Name = "DiscountOrMarkupPercentage5", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupPercentage5, Id = Index.DiscountMarkupPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountMarkupPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets PriceDeterminedby
        /// </summary>
        [Display(Name = "PriceDeterminedBy", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.PriceDeterminedby, Id = Index.PriceDeterminedby, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceDeterminedby PriceDeterminedby { get; set; }

        /// <summary>
        /// Gets or sets QuantityLevel1
        /// </summary>
        [Display(Name = "QuantityLevel1", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.QuantityLevel1, Id = Index.QuantityLevel1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityLevel1 { get; set; }

        /// <summary>
        /// Gets or sets QuantityLevel2
        /// </summary>
        [Display(Name = "QuantityLevel2", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.QuantityLevel2, Id = Index.QuantityLevel2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityLevel2 { get; set; }

        /// <summary>
        /// Gets or sets QuantityLevel3
        /// </summary>
        [Display(Name = "QuantityLevel3", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.QuantityLevel3, Id = Index.QuantityLevel3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityLevel3 { get; set; }

        /// <summary>
        /// Gets or sets QuantityLevel4
        /// </summary>
        [Display(Name = "QuantityLevel4", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.QuantityLevel4, Id = Index.QuantityLevel4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityLevel4 { get; set; }

        /// <summary>
        /// Gets or sets QuantityLevel5
        /// </summary>
        [Display(Name = "QuantityLevel5", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.QuantityLevel5, Id = Index.QuantityLevel5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityLevel5 { get; set; }

        /// <summary>
        /// Gets or sets MarkupFactor
        /// </summary>
        [Display(Name = "MarkupFactor", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.MarkupFactor, Id = Index.MarkupFactor, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal MarkupFactor { get; set; }

        /// <summary>
        /// Gets or sets LastMarkupCostChangeDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "LastMarkupCostChangeDate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.LastMarkupCostChangeDate, Id = Index.LastMarkupCostChangeDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMarkupCostChangeDate { get; set; }

        /// <summary>
        /// Gets or sets PreviousMarkupCost
        /// </summary>
        [Display(Name = "PreviousMarkupCost", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PreviousMarkupCost, Id = Index.PreviousMarkupCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PreviousMarkupCost { get; set; }

        /// <summary>
        /// Gets or sets LastExchangeRateChangeDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "LastExchangeRateChangeDate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.LastExchangeRateChangeDate, Id = Index.LastExchangeRateChangeDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastExchangeRateChangeDate { get; set; }

        /// <summary>
        /// Gets or sets PreviousExchangeRate
        /// </summary>
        [Display(Name = "PreviousExchangeRate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PreviousExchangeRate, Id = Index.PreviousExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PreviousExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RoundingMethod
        /// </summary>
        [Display(Name = "RoundingMethod", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.RoundingMethod, Id = Index.RoundingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public RoundingMethod RoundingMethod { get; set; }

        /// <summary>
        /// Gets or sets RoundToaMultipleof
        /// </summary>
        [Display(Name = "RoundtoaMultipleof", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.RoundToaMultipleof, Id = Index.RoundToaMultipleof, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal RoundToaMultipleof { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupAmount1
        /// </summary>
        [Display(Name = "DiscountOrMarkupAmount1", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupAmount1, Id = Index.DiscountMarkupAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal DiscountMarkupAmount1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupAmount2
        /// </summary>
        [Display(Name = "DiscountOrMarkupAmount2", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupAmount2, Id = Index.DiscountMarkupAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal DiscountMarkupAmount2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupAmount3
        /// </summary>
        [Display(Name = "DiscountOrMarkupAmount3", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupAmount3, Id = Index.DiscountMarkupAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal DiscountMarkupAmount3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupAmount4
        /// </summary>
        [Display(Name = "DiscountOrMarkupAmount4", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupAmount4, Id = Index.DiscountMarkupAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal DiscountMarkupAmount4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountMarkupAmount5
        /// </summary>
        [Display(Name = "DiscountOrMarkupAmount5", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DiscountMarkupAmount5, Id = Index.DiscountMarkupAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal DiscountMarkupAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PriceBy
        /// </summary>
        [Display(Name = "PriceBy", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.PriceBy, Id = Index.PriceBy, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceBy PriceBy { get; set; }

        /// <summary>
        /// Gets or sets MarkupWeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "MarkupWeightUnitOfMeasure", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.MarkupWeightUnitOfMeasure, Id = Index.MarkupWeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string MarkupWeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightLevel1
        /// </summary>
        [Display(Name = "WeightLevel1", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.WeightLevel1, Id = Index.WeightLevel1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal WeightLevel1 { get; set; }

        /// <summary>
        /// Gets or sets WeightLevel2
        /// </summary>
        [Display(Name = "WeightLevel2", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.WeightLevel2, Id = Index.WeightLevel2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal WeightLevel2 { get; set; }

        /// <summary>
        /// Gets or sets WeightLevel3
        /// </summary>
        [Display(Name = "WeightLevel3", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.WeightLevel3, Id = Index.WeightLevel3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal WeightLevel3 { get; set; }

        /// <summary>
        /// Gets or sets WeightLevel4
        /// </summary>
        [Display(Name = "WeightLevel4", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.WeightLevel4, Id = Index.WeightLevel4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal WeightLevel4 { get; set; }

        /// <summary>
        /// Gets or sets WeightLevel5
        /// </summary>
        [Display(Name = "WeightLevel5", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.WeightLevel5, Id = Index.WeightLevel5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal WeightLevel5 { get; set; }

        /// <summary>
        /// Gets or sets PriceCheckType
        /// </summary>
        [Display(Name = "PriceCheckType", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.PriceCheckType, Id = Index.PriceCheckType, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceCheckType PriceCheckType { get; set; }

        /// <summary>
        /// Gets or sets Check
        /// </summary>
        [Display(Name = "Check", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.Check, Id = Index.Check, FieldType = EntityFieldType.Int, Size = 2)]
        public Check Check { get; set; }

        /// <summary>
        /// Gets or sets CheckBase
        /// </summary>
        [Display(Name = "CheckBase", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.CheckBase, Id = Index.CheckBase, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckBase CheckBase { get; set; }

        /// <summary>
        /// Gets or sets CostMarginBase
        /// </summary>
        [Display(Name = "CostMarginBase", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.CostMarginBase, Id = Index.CostMarginBase, FieldType = EntityFieldType.Int, Size = 2)]
        public CostMarginBase CostMarginBase { get; set; }

        /// <summary>
        /// Gets or sets DefaultBaseUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DefaultBaseUnit", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.DefaultBaseUnit, Id = Index.DefaultBaseUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string DefaultBaseUnit { get; set; }

        /// <summary>
        /// Gets or sets DefaultBaseWeightUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DefaultBaseWeightUnit", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.DefaultBaseWeightUnit, Id = Index.DefaultBaseWeightUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string DefaultBaseWeightUnit { get; set; }

        /// <summary>
        /// Gets or sets DefaultSaleUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DefaultSaleUnit", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.DefaultSaleUnit, Id = Index.DefaultSaleUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string DefaultSaleUnit { get; set; }

        /// <summary>
        /// Gets or sets DefaultSaleWeightUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DefaultSaleWeightUnit", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.DefaultSaleWeightUnit, Id = Index.DefaultSaleWeightUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string DefaultSaleWeightUnit { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem StockItem { get; set; }

        /// <summary>
        /// Gets or sets BasePrice
        /// </summary>
        [Display(Name = "BasePrice", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BasePrice, Id = Index.BasePrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BasePrice { get; set; }

        /// <summary>
        /// Gets or sets PricingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PricingUnitOfMeasure", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PricingUnitOfMeasure, Id = Index.PricingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string PricingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets PricingWeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PricingWeightUnitOfMeasure", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PricingWeightUnitOfMeasure, Id = Index.PricingWeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string PricingWeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets BaseConversionFactor
        /// </summary>
        [Display(Name = "BaseConversionFactor", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseConversionFactor, Id = Index.BaseConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BaseConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets SalePrice
        /// </summary>
        [Display(Name = "SalePrice", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SalePrice, Id = Index.SalePrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal SalePrice { get; set; }

        /// <summary>
        /// Gets or sets SaleUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SaleUnitOfMeasure", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleUnitOfMeasure, Id = Index.SaleUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string SaleUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets SaleWeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SaleWeightUnitOfMeasure", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleWeightUnitOfMeasure, Id = Index.SaleWeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string SaleWeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets SaleConversionFactor
        /// </summary>
        [Display(Name = "SaleConversionFactor", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleConversionFactor, Id = Index.SaleConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal SaleConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets SaleStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SaleStartDate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleStartDate, Id = Index.SaleStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? SaleStartDate { get; set; }

        /// <summary>
        /// Gets or sets SaleEndDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SaleEndDate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleEndDate, Id = Index.SaleEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? SaleEndDate { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets StockingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StockingUnitOfMeasure", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.StockingUnitOfMeasure, Id = Index.StockingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string StockingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets BasePriceType
        /// </summary>
        [Display(Name = "BasePriceType", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BasePriceType, Id = Index.BasePriceType, FieldType = EntityFieldType.Int, Size = 2)]
        public BasePriceType BasePriceType { get; set; }

        /// <summary>
        /// Gets or sets DefaultBasePriceUsing
        /// </summary>
        [Display(Name = "DefaultBasePriceUsing", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.DefaultBasePriceUsing, Id = Index.DefaultBasePriceUsing, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultBasePriceUsing DefaultBasePriceUsing { get; set; }

        /// <summary>
        /// Gets or sets BaseLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BaseLocation", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseLocation, Id = Index.BaseLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BaseLocation { get; set; }

        /// <summary>
        /// Gets or sets BaseCostBase
        /// </summary>
        [Display(Name = "BaseCostBase", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseCostBase, Id = Index.BaseCostBase, FieldType = EntityFieldType.Int, Size = 2)]
        public BaseCostBase BaseCostBase { get; set; }

        /// <summary>
        /// Gets or sets BasePercentage
        /// </summary>
        [Display(Name = "BasePercentage", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BasePercentage, Id = Index.BasePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal BasePercentage { get; set; }

        /// <summary>
        /// Gets or sets BaseAmount
        /// </summary>
        [Display(Name = "BaseAmount", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseAmount, Id = Index.BaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BaseAmount { get; set; }

        /// <summary>
        /// Gets or sets BaseRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BaseRateType", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseRateType, Id = Index.BaseRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BaseRateType { get; set; }

        /// <summary>
        /// Gets or sets BaseRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "BaseRateDate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseRateDate, Id = Index.BaseRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BaseRateDate { get; set; }

        /// <summary>
        /// Gets or sets BaseExchangeRate
        /// </summary>
        [Display(Name = "BaseExchangeRate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseExchangeRate, Id = Index.BaseExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BaseExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets BaseRateOperator
        /// </summary>
        [Display(Name = "BaseRateOperator", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseRateOperator, Id = Index.BaseRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BaseRateOperator BaseRateOperator { get; set; }

        /// <summary>
        /// Gets or sets BaseRateOveridden
        /// </summary>
        [Display(Name = "BaseRateOveridden", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.BaseRateOveridden, Id = Index.BaseRateOveridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public BaseRateOveridden BaseRateOveridden { get; set; }

        /// <summary>
        /// Gets or sets SalePriceType
        /// </summary>
        [Display(Name = "SalePriceType", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SalePriceType, Id = Index.SalePriceType, FieldType = EntityFieldType.Int, Size = 2)]
        public SalePriceType SalePriceType { get; set; }

        /// <summary>
        /// Gets or sets DefaultSalePriceUsing
        /// </summary>
        [Display(Name = "DefaultSalePriceUsing", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.DefaultSalePriceUsing, Id = Index.DefaultSalePriceUsing, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultSalePriceUsing DefaultSalePriceUsing { get; set; }

        /// <summary>
        /// Gets or sets SaleLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SaleLocation", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleLocation, Id = Index.SaleLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SaleLocation { get; set; }

        /// <summary>
        /// Gets or sets SaleCostBase
        /// </summary>
        [Display(Name = "SaleCostBase", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleCostBase, Id = Index.SaleCostBase, FieldType = EntityFieldType.Int, Size = 2)]
        public SaleCostBase SaleCostBase { get; set; }

        /// <summary>
        /// Gets or sets SalePercentage
        /// </summary>
        [Display(Name = "SalePercentage", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SalePercentage, Id = Index.SalePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalePercentage { get; set; }

        /// <summary>
        /// Gets or sets SaleAmount
        /// </summary>
        [Display(Name = "SaleAmount", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleAmount, Id = Index.SaleAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal SaleAmount { get; set; }

        /// <summary>
        /// Gets or sets SaleRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SaleRateType", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleRateType, Id = Index.SaleRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SaleRateType { get; set; }

        /// <summary>
        /// Gets or sets SaleRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "SaleRateDate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleRateDate, Id = Index.SaleRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SaleRateDate { get; set; }

        /// <summary>
        /// Gets or sets SaleExchangeRate
        /// </summary>
        [Display(Name = "SaleExchangeRate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleExchangeRate, Id = Index.SaleExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal SaleExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets SaleRateOperator
        /// </summary>
        [Display(Name = "SaleRateOperator", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleRateOperator, Id = Index.SaleRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public SaleRateOperator SaleRateOperator { get; set; }

        /// <summary>
        /// Gets or sets SaleRateOveridden
        /// </summary>
        [Display(Name = "SaleRateOveridden", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.SaleRateOveridden, Id = Index.SaleRateOveridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public SaleRateOveridden SaleRateOveridden { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets CheckItemExistence
        /// </summary>
        [Display(Name = "CheckItemExistence", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
        public CheckItemExistence CheckItemExistence { get; set; }

        /// <summary>
        /// Gets or sets CalcBaseExchRateExists
        /// </summary>
        [Display(Name = "CalcBaseExchRateExists", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.CalcBaseExchRateExists, Id = Index.CalcBaseExchRateExists, FieldType = EntityFieldType.Int, Size = 2)]
        public CalcBaseExchRateExists CalcBaseExchRateExists { get; set; }

        /// <summary>
        /// Gets or sets CalcSaleExchRateExists
        /// </summary>
        [Display(Name = "CalcSaleExchRateExists", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.CalcSaleExchRateExists, Id = Index.CalcSaleExchRateExists, FieldType = EntityFieldType.Int, Size = 2)]
        public CalcSaleExchRateExists CalcSaleExchRateExists { get; set; }

        /// <summary>
        /// Gets or sets ItemLocationCostAllowable
        /// </summary>
        [Display(Name = "ItemLocationCostAllowable", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.ItemLocationCostAllowable, Id = Index.ItemLocationCostAllowable, FieldType = EntityFieldType.Bool, Size = 2)]
        public ItemLocationCostAllowable ItemLocationCostAllowable { get; set; }

        /// <summary>
        /// Gets or sets PriceListStartDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceListStartDate", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.PriceListStartDate, Id = Index.PriceListStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PriceListStartDate { get; set; }

        /// <summary>
        /// Gets or sets PriceListEndDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceListEndDate", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.PriceListEndDate, Id = Index.PriceListEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PriceListEndDate { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        [IgnoreExportImport]
        [IsMvcSpecific]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        [IgnoreExportImport]
        [IsMvcSpecific]
        public short SessionWarnDays { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber - Unique key for grid rows
        /// </summary>
        [IgnoreExportImport]
        [IsMvcSpecific]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Item Pricing Details
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ItemPricingDetail> ItemPricingDetails { get; set; }

        /// <summary>
        /// Gets or sets PriceListTax Authorities
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<PriceListTaxAuthority> PriceListTaxAuthorities { get; set; }

        /// <summary>
        /// Gets or sets PricingPriceChecks
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<PricingPriceCheck> PricingPriceChecks { get; set; }

        /// <summary>
        /// To get the string of PriceBy property
        /// </summary>
        [IgnoreExportImport]
        public string PriceByString
        {
            get { return EnumUtility.GetStringValue(PriceBy); }
        }


        /// <summary>
        /// To get the string of BasePriceType property
        /// </summary>
        [IgnoreExportImport]
        public string BasePriceTypeString
        {
            get { return EnumUtility.GetStringValue(BasePriceType); }
        }

        /// <summary>
        /// To get the string of SalePriceType property
        /// </summary>
        [IgnoreExportImport]
        public string SalePriceTypeString
        {
            get { return EnumUtility.GetStringValue(SalePriceType); }
        }

        /// <summary>
        /// To get the string of SellingPriceBasedon property
        /// </summary>
        [IgnoreExportImport]
        public string SellingPriceBasedonString
        {
            get { return EnumUtility.GetStringValue(SellingPriceBasedon); }
        }

        /// <summary>
        /// To get the string of DiscountMarkupPriceby property
        /// </summary>
        [IgnoreExportImport]
        public string DiscountMarkupPricebyString
        {
            get { return EnumUtility.GetStringValue(DiscountMarkupPriceby); }
        }

        /// <summary>
        /// To get the string of PriceDeterminedby property
        /// </summary>
        [IgnoreExportImport]
        public string PriceDeterminedbyString
        {
            get { return EnumUtility.GetStringValue(PriceDeterminedby); }
        }

        /// <summary>
        /// To get the string of RoundingMethod property
        /// </summary>
        [IgnoreExportImport]
        public string RoundingMethodString
        {
            get { return EnumUtility.GetStringValue(RoundingMethod); }
        }

        /// <summary>
        /// To get the string of PriceCheckType property
        /// </summary>
        [IgnoreExportImport]
        public string PriceCheckTypeString
        {
            get { return EnumUtility.GetStringValue(PriceCheckType); }
        }

        /// <summary>
        /// To get the string of Check property
        /// </summary>
        [IgnoreExportImport]
        public string CheckString
        {
            get { return EnumUtility.GetStringValue(Check); }
        }

        /// <summary>
        /// To get the string of CheckBase property
        /// </summary>
        [IgnoreExportImport]
        public string CheckBaseString
        {
            get { return EnumUtility.GetStringValue(CheckBase); }
        }

        /// <summary>
        /// To get the string of CostMarginBase property
        /// </summary>
        [IgnoreExportImport]
        public string CostMarginBaseString
        {
            get { return EnumUtility.GetStringValue(CostMarginBase); }
        }

        /// <summary>
        /// To get the string of StockItem property
        /// </summary>
        [IgnoreExportImport]
        public string StockItemString
        {
            get { return EnumUtility.GetStringValue(StockItem); }
        }

        /// <summary>
        /// To get the string of DefaultBasePriceUsing property
        /// </summary>
        [IgnoreExportImport]
        public string DefaultBasePriceUsingString
        {
            get { return EnumUtility.GetStringValue(DefaultBasePriceUsing); }
        }

        /// <summary>
        /// To get the string of BaseCostBase property
        /// </summary>
        [IgnoreExportImport]
        public string BaseCostBaseString
        {
            get { return EnumUtility.GetStringValue(BaseCostBase); }
        }

        /// <summary>
        /// To get the string of BaseRateOperator property
        /// </summary>
        [IgnoreExportImport]
        public string BaseRateOperatorString
        {
            get { return EnumUtility.GetStringValue(BaseRateOperator); }
        }

        /// <summary>
        /// To get the string of BaseRateOveridden property
        /// </summary>
        [IgnoreExportImport]
        public string BaseRateOveriddenString
        {
            get { return EnumUtility.GetStringValue(BaseRateOveridden); }
        }

        /// <summary>
        /// To get the string of DefaultSalePriceUsing property
        /// </summary>
        [IgnoreExportImport]
        public string DefaultSalePriceUsingString
        {
            get { return EnumUtility.GetStringValue(DefaultSalePriceUsing); }
        }

        /// <summary>
        /// To get the string of SaleCostBase property
        /// </summary>
        [IgnoreExportImport]
        public string SaleCostBaseString
        {
            get { return EnumUtility.GetStringValue(SaleCostBase); }
        }

        /// <summary>
        /// To get the string of SaleRateOperator property
        /// </summary>
        [IgnoreExportImport]
        public string SaleRateOperatorString
        {
            get { return EnumUtility.GetStringValue(SaleRateOperator); }
        }

        /// <summary>
        /// To get the string of SaleRateOveridden property
        /// </summary>
        [IgnoreExportImport]
        public string SaleRateOveriddenString
        {
            get { return EnumUtility.GetStringValue(SaleRateOveridden); }
        }

        /// <summary>
        /// To get the string of ProcessCommand property
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// To get the string of CheckItemExistence property
        /// </summary>
        [IgnoreExportImport]
        public string CheckItemExistenceString
        {
            get { return EnumUtility.GetStringValue(CheckItemExistence); }
        }

        /// <summary>
        /// To get the string of CalcBaseExchRateExists property
        /// </summary>
        [IgnoreExportImport]
        public string CalcBaseExchRateExistsString
        {
            get { return EnumUtility.GetStringValue(CalcBaseExchRateExists); }
        }

        /// <summary>
        /// To get the string of CalcSaleExchRateExists property
        /// </summary>
        [IgnoreExportImport]
        public string CalcSaleExchRateExistsString
        {
            get { return EnumUtility.GetStringValue(CalcSaleExchRateExists); }
        }

        /// <summary>
        /// To get the string of ItemLocationCostAllowable property
        /// </summary>
        [IgnoreExportImport]
        public string ItemLocationCostAllowableString
        {
            get { return EnumUtility.GetStringValue(ItemLocationCostAllowable); }
        }

        /// <summary>
        /// Gets or sets Base Price Units Of Measures
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ItemPricingDetail> BasePriceUnitsOfMeasures { get; set; }

        /// <summary>
        /// Gets or sets Sale Price Units Of Measures
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ItemPricingDetail> SalePriceUnitsOfMeasures { get; set; }
    }
}
