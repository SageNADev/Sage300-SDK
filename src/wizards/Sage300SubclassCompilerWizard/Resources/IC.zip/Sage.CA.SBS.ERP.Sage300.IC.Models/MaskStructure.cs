﻿// Copyright (c) 2026 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.GLIntegration;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Model class for MaskStructure 
    /// </summary>
    public partial class MaskStructure : ModelBase
    {
        #region Constructor
        public MaskStructure()
        {
        }
        #endregion

        #region Public Properties

        /// <summary>
        /// Gets or sets StructureCode
        /// /// </summary>
        [Key]
        [Display(ResourceType =typeof(MaskStructureResx), Name =nameof(MaskStructureResx.StructureCode))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets Mask Type
        /// </summary>
        [ViewField(Name = Fields.MaskType, Id = Index.MaskType, FieldType = EntityFieldType.Int, Size = 2)]
        public string MaskType { get; set; }

        /// <summary> 
        /// Gets or sets Description
        ///</summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Prefix
        /// </summary>
        [Display(ResourceType = typeof(MaskStructureResx), Name = nameof(MaskStructureResx.Prefix))]
        [ViewField(Name = Fields.Prefix, Id = Index.Prefix, FieldType = EntityFieldType.Int, Size = 2)]
        public MaskStructureSeparator Prefix { get; set; }

        /// <summary>
        /// Gets or sets Segment Type 1
        /// </summary>
        [ViewField(Name = Fields.SegmentType1, Id = Index.SegmentType1, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentType1 { get; set; }

        /// <summary>
        /// Gets or sets Segment Type 2
        /// </summary>
        [ViewField(Name = Fields.SegmentType2, Id = Index.SegmentType2, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentType2 { get; set; }

        /// <summary>
        /// Gets or sets Segment Type 3
        /// </summary>
        [ViewField(Name = Fields.SegmentType3, Id = Index.SegmentType3, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentType3 { get; set; }

        /// <summary>
        /// Gets or sets Segment Type 4
        /// </summary>
        [ViewField(Name = Fields.SegmentType4, Id = Index.SegmentType4, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentType4 { get; set; }

        /// <summary>
        /// Gets or sets Segment Type 5
        /// </summary>
        [ViewField(Name = Fields.SegmentType5, Id = Index.SegmentType5, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentType5 { get; set; }

        /// <summary>
        /// Gets or sets Segment Length 1
        /// </summary>
        [ViewField(Name = Fields.SegmentLength1, Id = Index.SegmentLength1, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentLength1 { get; set; }

        /// <summary>
        /// Gets or sets Segment Length 2
        /// </summary>
        [ViewField(Name = Fields.SegmentLength2, Id = Index.SegmentLength2, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentLength2 { get; set; }

        /// <summary>
        /// Gets or sets Segment Length 3
        /// </summary>
        [ViewField(Name = Fields.SegmentLength3, Id = Index.SegmentLength3, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentLength3 { get; set; }

        /// <summary>
        /// Gets or sets Segment Length 4
        /// </summary>
        [ViewField(Name = Fields.SegmentLength4, Id = Index.SegmentLength4, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentLength4 { get; set; }

        /// <summary>
        /// Gets or sets Segment Length 5
        /// </summary>
        [ViewField(Name = Fields.SegmentLength5, Id = Index.SegmentLength5, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentLength5 { get; set; }

        /// <summary>
        /// Gets or sets Segment Separator 1
        /// </summary>
        [ViewField(Name = Fields.SegmentSeparator1, Id = Index.SegmentSeparator1, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentSeparator1 { get; set; }

        /// <summary>
        /// Gets or sets Segment Separator 2
        /// </summary>
        [ViewField(Name = Fields.SegmentSeparator2, Id = Index.SegmentSeparator2, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentSeparator2 { get; set; }

        /// <summary>
        /// Gets or sets Segment Separator 3
        /// </summary>
        [ViewField(Name = Fields.SegmentSeparator3, Id = Index.SegmentSeparator3, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentSeparator3 { get; set; }

        /// <summary>
        /// Gets or sets Segment Separator 4
        /// </summary>
        [ViewField(Name = Fields.SegmentSeparator4, Id = Index.SegmentSeparator4, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentSeparator4 { get; set; }

        /// <summary>
        /// Gets or sets Segment Separator 5
        /// </summary>
        [ViewField(Name = Fields.SegmentSeparator5, Id = Index.SegmentSeparator5, FieldType = EntityFieldType.Int, Size = 2)]
        public int SegmentSeparator5 { get; set; }

        /// <summary>
        /// Gets or sets Increment 1
        /// </summary>
        [ViewField(Name = Fields.Increment1, Id = Index.Increment1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Increment1 { get; set; }

        /// <summary>
        /// Gets or sets Increment 2
        /// </summary>
        [ViewField(Name = Fields.Increment2, Id = Index.Increment2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Increment2 { get; set; }

        /// <summary>
        /// Gets or sets Increment 3
        /// </summary>
        [ViewField(Name = Fields.Increment3, Id = Index.Increment3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Increment3 { get; set; }

        /// <summary>
        /// Gets or sets Increment 4
        /// </summary>
        [ViewField(Name = Fields.Increment4, Id = Index.Increment4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Increment4 { get; set; }

        /// <summary>
        /// Gets or sets Increment 5
        /// </summary>
        [ViewField(Name = Fields.Increment5, Id = Index.Increment5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Increment5 { get; set; }

        /// <summary>
        /// Gets or sets Mask Structure
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.MaskStructureValue, Id = Index.MaskStructureValue, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string MaskStructureValue { get; set; }

        /// <summary>
        /// Gets or sets Mask Length
        /// </summary>
        [ViewField(Name = Fields.MaskLength, Id = Index.MaskLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int MaskLength { get; set; }

        /// <summary>
        /// Gets or sets Is Structure Code Used
        /// </summary>
        [ViewField(Name = Fields.InUse, Id = Index.InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InUse { get; set; }

        public List<CustomSelectList> PrefixSeparators { get; set; }
        public List<CustomSelectList> SegmentSeparators { get; set; }

        #endregion
    }
}
