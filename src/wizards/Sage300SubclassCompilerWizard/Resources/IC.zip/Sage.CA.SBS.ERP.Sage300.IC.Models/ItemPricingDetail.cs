// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ItemPricingDetail
    /// </summary>
    public partial class ItemPricingDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets PriceListCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PriceListCode", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PriceListCode, Id = Index.PriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceListCode { get; set; }

        /// <summary>
        /// Gets or sets PriceDetailType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PriceDetailType", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.PriceDetailType, Id = Index.PriceDetailType, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceDetailType PriceDetailType { get; set; }

        /// <summary>
        /// Gets or sets QuantityUnit
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "QuantityUnit", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.QuantityUnit, Id = Index.QuantityUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string QuantityUnit { get; set; }

        /// <summary>
        /// Gets or sets WeightUnit
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "WeightUnit", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.WeightUnit, Id = Index.WeightUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string WeightUnit { get; set; }

        /// <summary>
        /// Gets or sets UnitPrice
        /// </summary>
        [Display(Name = "UnitPrice", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.UnitPrice, Id = Index.UnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactor
        /// </summary>
        [Display(Name = "ConversionFactor", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets SaleStart
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "SaleStart", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.SaleStart, Id = Index.SaleStart, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? SaleStart { get; set; }

        /// <summary>
        /// Gets or sets SaleEnd
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "SaleEnd", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.SaleEnd, Id = Index.SaleEnd, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? SaleEnd { get; set; }

        /// <summary>
        /// Gets or sets LastPriceChangeDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "LastPriceChangeDate", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.LastPriceChangeDate, Id = Index.LastPriceChangeDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPriceChangeDate { get; set; }

        /// <summary>
        /// Gets or sets PreviousPrice
        /// </summary>
        [Display(Name = "PreviousPrice", ResourceType = typeof (ItemPricingResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PreviousPrice, Id = Index.PreviousPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PreviousPrice { get; set; }

        /// <summary>
        /// Gets or sets DefaultUnit
        /// </summary>
        [Display(Name = "DefaultUnit", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.DefaultUnit, Id = Index.DefaultUnit, FieldType = EntityFieldType.Bool, Size = 2)]
        public DefaultUnit DefaultUnit { get; set; }

        /// <summary>
        /// To get the string value of the TaxIncluded property
        /// </summary>
        [IgnoreExportImport]
        public string DefaultUnitString
        {
            get { return EnumUtility.GetStringValue(DefaultUnit); }
        }

        /// <summary>
        /// Gets or sets SerialNumber - Unique key for grid rows
        /// </summary>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitsOfMeasure
        /// </summary>
        [IgnoreExportImport]
        public string UnitsOfMeasure { get; set; }

    }
}
