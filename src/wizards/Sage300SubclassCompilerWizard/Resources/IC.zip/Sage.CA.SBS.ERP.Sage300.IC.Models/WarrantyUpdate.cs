// Copyright (c) 2026 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Class for WarrantyUpdate
    /// </summary>
    public class WarrantyUpdate : ModelBase
    {
        /// <summary>
        /// Gets or sets the Period
        /// </summary>
        public int Period { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether Lifetime
        /// </summary>
        public bool Lifetime { get; set; }

        /// <summary>
        /// Gets or sets the IsLifetime
        /// </summary>
        public Period1IsLifetime IsLifetime { get; set; }

        /// <summary>
        /// Gets or sets the StartDate
        /// </summary>
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or sets the EndDate
        /// </summary>
        public DateTime? EndDate { get; set; }
    }
}
