/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for KittingItemComponent
    /// </summary>
    public partial class KittingItemComponent : ModelBase
    {
        #region Properties
        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets KittingNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "KittingNumber", ResourceType = typeof(KittingItemsResx))]
        [ViewField(Name = Fields.KittingNumber, Id = Index.KittingNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string KittingNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ComponentItemNumber, Id = Index.ComponentItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ComponentItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal? UnitCost { get; set; }

        /// <summary>
        /// Gets or sets UserSpecifiedCost
        /// </summary>
        [Display(Name = "UserSpecifiedCost", ResourceType = typeof(KittingItemsResx))]
        [ViewField(Name = Fields.UserSpecifiedCost, Id = Index.UserSpecifiedCost, FieldType = EntityFieldType.Bool, Size = 2)]
        public UserSpecifiedCost UserSpecifiedCost { get; set; }

        /// <summary>
        /// Gets or sets Sellable
        /// </summary>
        [Display(Name = "Sellable", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Sellable, Id = Index.Sellable, FieldType = EntityFieldType.Bool, Size = 2)]
        public Sellable Sellable { get; set; }

        /// <summary>
        /// Gets or Sets ComponentItemDescription 
        /// To display the description
        /// </summary>
        public string ComponentItemDescription { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets FormattedComponentItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(ICCommonResx))]
        public string FormattedComponentItemNumber { get; set; }

        #endregion
    }
}
