﻿// Copyright (c) 2026 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for SerialLotGeneration
    /// </summary>
    public partial class SerialLotGeneration : ModelBase
    {
        /// <summary>
        /// Gets or sets the sequence number that uniquely identifies the record.
        /// </summary>
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets the line number associated with the receipt detail.
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets the stock date for the receipt.
        /// </summary>
        public string StockDate { get; set; }

        /// <summary>
        /// Gets or sets the next serial number to be generated.
        /// </summary>
        public string NextSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether serial numbers are automatically allocated from a source.
        /// </summary>
        public bool SAutoAllocFrom { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether lot numbers are automatically allocated from a source.
        /// </summary>
        public bool LAutoAllocFrom { get; set; }

        /// <summary>
        /// Gets or sets the serial number used for automatic allocation.
        /// </summary>
        public string AutoAllocSerialNo { get; set; }

        /// <summary>
        /// Gets or sets the lot number used for automatic allocation.
        /// </summary>
        public string AutoAllocLotNo { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        public string SUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        public string LUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets the total number of serial numbers required.
        /// </summary>
        public int SerialNoRequired { get; set; }

        /// <summary>
        /// Gets or sets the number of serial numbers already generated.
        /// </summary>
        public int SerialNoGenerated { get; set; }

        /// <summary>
        /// Gets or sets the number of serial numbers remaining to be generated.
        /// </summary>
        public int SerialNoRemaining { get; set; }

        /// <summary>
        /// Gets or sets the Extension cost for serial numbers.
        /// </summary>
        public decimal SExtensionCost { get; set; }

        /// <summary>
        /// Gets or sets the adjusted cost for serial numbers.
        /// </summary>
        public int SAdjustedCost { get; set; }

        /// <summary>
        /// Gets or sets the remaining cost for serial numbers.
        /// </summary>
        public int SRemainingCost { get; set; }

        /// <summary>
        /// Gets or sets the assigned remaining cost for serial numbers.
        /// </summary>
        public int SAssignedRemainingCost { get; set; }

        /// <summary>
        /// Gets or sets the extension cost for lot numbers.
        /// </summary>
        public decimal LExtensionCost { get; set; }

        /// <summary>
        /// Gets or sets the adjusted cost for lot numbers.
        /// </summary>
        public int LAdjustedCost { get; set; }

        /// <summary>
        /// Gets or sets the remaining cost for lot numbers.
        /// </summary>
        public int LRemainingCost { get; set; }

        /// <summary>
        /// Gets or sets the assigned remaining cost for lot numbers.
        /// </summary>
        public int LAssignedRemainingCost { get; set; }

        /// <summary>
        /// Gets or sets the assigned unit of measure for serial numbers.
        /// </summary>
        public string SAssignedUOM { get; set; }

        /// <summary>
        /// Gets or sets the assigned unit of measure for lot numbers.
        /// </summary>
        public string LAssignedUOM { get; set; }

        /// <summary>
        /// Gets or sets the quantity assigned for serial numbers.
        /// </summary>
        public int SQTYAssigned { get; set; }

        /// <summary>
        /// Gets or sets the quantity assigned for lot numbers.
        /// </summary>
        public int LQTYAssigned { get; set; }

        /// <summary>
        /// Gets or sets the assigned cost for serial numbers.
        /// </summary>
        public int SAssignedCost { get; set; }

        /// <summary>
        /// Gets or sets the assigned cost for lot numbers.
        /// </summary>
        public int LAssignedCost { get; set; }

        /// <summary>
        /// Gets or sets the total number of lot numbers required.
        /// </summary>
        [Column(TypeName = "decimal(18,4)")]
        public decimal LotNoRequired { get; set; }

        /// <summary>
        /// Gets or sets the number of lot numbers already generated.
        /// </summary>
        [Column(TypeName = "decimal(18,4)")]
        public decimal LotNoGenerated { get; set; }

        /// <summary>
        /// Gets or sets the number of lot numbers remaining to be generated.
        /// </summary>
        [Column(TypeName = "decimal(18,4)")]
        public decimal LotNoRemaining { get; set; }

        /// <summary>
        /// Gets or sets the next lot number to be generated.
        /// </summary>
        public string NextLotNumber { get; set; }

        /// <summary>
        /// Gets or sets the make value (purpose defined by business logic).
        /// </summary>
        public int Make { get; set; }

        /// <summary>
        /// Gets or sets the number of items each lot has.
        /// </summary>
        public int EachLotHas { get; set; }
    }
}
