/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.GLIntegration;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Class for G/L Reference Integration
    /// </summary>
    public partial class GLReferenceIntegration : BaseGLReferenceIntegration
    {
        /// <summary>
        /// Gets or sets Source Transaction Type
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(Resources.ICCommonResx))]
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public SourceTransactionType SourceTransactionType { get; set; }

        /// <summary>
        /// Gets or sets Separator 
        /// </summary>
        [Display(Name = "SegmentSeparator", ResourceType = typeof(Resources.Forms.GLIntegrationResx))]
        //[ViewField(Name = Fields.Separator, Id = Index.Separator, FieldType = EntityFieldType.Int, Size = 2)]
        public new Separator Separator { get; set; }

        //The following properties don't have display attribute as it is not mapped to UI controls directly//

        /// <summary>
        /// Gets or sets Included Segment 1
        /// </summary>
        public IncludedSegment IncludedSegment1 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 2
        /// </summary>
        public IncludedSegment IncludedSegment2 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 3
        /// </summary>
        public IncludedSegment IncludedSegment3 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 4
        /// </summary>
        public IncludedSegment IncludedSegment4 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 5
        /// </summary>
        public IncludedSegment IncludedSegment5 { get; set; }

        #region override UI properties
        
        //The following properties don't have display attribute as it is not mapped to UI controls directly

        /// <summary>
        /// Gets or sets Source Transaction Type Value 
        /// </summary>
        public override int SourceTransactionTypeValue
        {
            get { return Convert.ToInt32(SourceTransactionType); }
            set { SourceTransactionType = (SourceTransactionType)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 1 Value 
        /// </summary>
        public override int IncludedSegment1Value
        {
            get { return Convert.ToInt32(IncludedSegment1); }
            set { IncludedSegment1 = (IncludedSegment)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 2 Value 
        /// </summary>
        public override int IncludedSegment2Value
        {
            get { return Convert.ToInt32(IncludedSegment2); }
            set { IncludedSegment2 = (IncludedSegment)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 3 Value 
        /// </summary>
        public override int IncludedSegment3Value
        {
            get { return Convert.ToInt32(IncludedSegment3); }
            set { IncludedSegment3 = (IncludedSegment)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 4 Value 
        /// </summary>
        public override int IncludedSegment4Value
        {
            get { return Convert.ToInt32(IncludedSegment4); }
            set { IncludedSegment4 = (IncludedSegment)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 5 Value 
        /// </summary>
        public override int IncludedSegment5Value
        {
            get { return Convert.ToInt32(IncludedSegment5); }
            set { IncludedSegment5 = (IncludedSegment)value; }
        }

        #endregion
    }
}
