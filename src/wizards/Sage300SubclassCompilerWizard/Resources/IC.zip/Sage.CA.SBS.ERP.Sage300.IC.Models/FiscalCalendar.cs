// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
//using Sage.CA.SBS.ERP.Sage300.OE.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Partial class for FiscalCalendar
     /// </summary>
     public partial class FiscalCalendar : ModelBase
     {
          /// <summary>
          /// Gets or sets FiscalYear
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
          public string FiscalYear {get; set;}

          /// <summary>
          /// Gets or sets NumberOfFiscalPeriods
          /// </summary>
          [ViewField(Name = Fields.NumberOfFiscalPeriods, Id = Index.NumberOfFiscalPeriods, FieldType = EntityFieldType.Int, Size = 2)]
          public NumberOfFiscalPeriods NumberOfFiscalPeriods {get; set;}

          /// <summary>
          /// Gets or sets Quarterwith4Periods
          /// </summary>
          [ViewField(Name = Fields.Quarterwith4Periods, Id = Index.Quarterwith4Periods, FieldType = EntityFieldType.Int, Size = 2)]
          public Quarterwith4Periods Quarterwith4Periods {get; set;}

          /// <summary>
          /// Gets or sets Active
          /// </summary>
          [ViewField(Name = Fields.Active, Id = Index.Active, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool Active {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod1StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod1StartDate, Id = Index.FiscalPeriod1StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod1StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod2StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod2StartDate, Id = Index.FiscalPeriod2StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod2StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod3StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod3StartDate, Id = Index.FiscalPeriod3StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod3StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod4StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod4StartDate, Id = Index.FiscalPeriod4StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod4StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod5StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod5StartDate, Id = Index.FiscalPeriod5StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod5StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod6StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod6StartDate, Id = Index.FiscalPeriod6StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod6StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod7StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod7StartDate, Id = Index.FiscalPeriod7StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod7StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod8StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod8StartDate, Id = Index.FiscalPeriod8StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod8StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod9StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod9StartDate, Id = Index.FiscalPeriod9StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod9StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod10StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod10StartDate, Id = Index.FiscalPeriod10StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod10StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod11StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod11StartDate, Id = Index.FiscalPeriod11StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod11StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod12StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod12StartDate, Id = Index.FiscalPeriod12StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod12StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod13StartDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod13StartDate, Id = Index.FiscalPeriod13StartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod13StartDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod1EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod1EndDate, Id = Index.FiscalPeriod1EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod1EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod2EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod2EndDate, Id = Index.FiscalPeriod2EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod2EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod3EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod3EndDate, Id = Index.FiscalPeriod3EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod3EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod4EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod4EndDate, Id = Index.FiscalPeriod4EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod4EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod5EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod5EndDate, Id = Index.FiscalPeriod5EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod5EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod6EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod6EndDate, Id = Index.FiscalPeriod6EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod6EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod7EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod7EndDate, Id = Index.FiscalPeriod7EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod7EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod8EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod8EndDate, Id = Index.FiscalPeriod8EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod8EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod9EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod9EndDate, Id = Index.FiscalPeriod9EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod9EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod10EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod10EndDate, Id = Index.FiscalPeriod10EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod10EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod11EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod11EndDate, Id = Index.FiscalPeriod11EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod11EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod12EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod12EndDate, Id = Index.FiscalPeriod12EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod12EndDate {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod13EndDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalPeriod13EndDate, Id = Index.FiscalPeriod13EndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime FiscalPeriod13EndDate {get; set;}

          /// <summary>
          /// Gets or sets AdjustmentPeriodStatus
          /// </summary>
          [ViewField(Name = Fields.AdjustmentPeriodStatus, Id = Index.AdjustmentPeriodStatus, FieldType = EntityFieldType.Int, Size = 2)]
          public AdjustmentPeriodStatus AdjustmentPeriodStatus {get; set;}

          /// <summary>
          /// Gets or sets ClosingPeriodStatus
          /// </summary>
          [ViewField(Name = Fields.ClosingPeriodStatus, Id = Index.ClosingPeriodStatus, FieldType = EntityFieldType.Int, Size = 2)]
          public ClosingPeriodStatus ClosingPeriodStatus {get; set;}

          /// <summary>
          /// Gets or sets Command
          /// </summary>
          [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
          public Command Command {get; set;}

          ///// <summary>
          ///// Gets or sets Command
          ///// </summary>
          //public string Index { get; set; }

          /// <summary>
          /// Gets or sets Application
          /// </summary>
          [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Application, Id = Index.Application, FieldType = EntityFieldType.Char, Size = 2)]
          public string Application {get; set;}

          /// <summary>
          /// Gets or sets Open
          /// </summary>
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Open, Id = Index.Open, FieldType = EntityFieldType.Char, Size = 30)]
          public string Open {get; set;}

     }
}
