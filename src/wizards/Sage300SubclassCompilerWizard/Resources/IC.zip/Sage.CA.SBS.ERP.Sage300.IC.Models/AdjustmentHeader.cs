// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for AdjustmentHeader
    /// </summary>
    public partial class AdjustmentHeader : ModelBase
    {
        #region Constructor

        /// <summary>
        /// Adjustment Header Constructor 
        /// </summary>
        public AdjustmentHeader()
        {
            AdjustmentHeaderOptionalFields = new EnumerableResponse<AdjustmentHeaderOptionalField>();
            AdjustmentDetails = new EnumerableResponse<AdjustmentDetail>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdjustmentNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AdjustmentNumber, Id = Index.AdjustmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string AdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdjustmentDate", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.AdjustmentDate, Id = Index.AdjustmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime AdjustmentDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets ICUniqueDocumentNumber
        /// </summary>
        [Display(Name = "ICUniqueDocumentNumber", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.ICUniqueDocumentNumber, Id = Index.ICUniqueDocumentNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICUniqueDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordStatus
        /// </summary>
        [Display(Name = "RecordStatus", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.RecordStatus, Id = Index.RecordStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public RecordStatus RecordStatus { get; set; }

        /// <summary>
        /// Gets or sets RecordDeleted
        /// </summary>
        [Display(Name = "RecordDeleted", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.RecordDeleted, Id = Index.RecordDeleted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordDeleted RecordDeleted { get; set; }

        /// <summary>
        /// Gets or sets NextDetailLineNumber
        /// </summary>
        [Display(Name = "NextDetailLineNumber", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.NextDetailLineNumber, Id = Index.NextDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordPrinted
        /// </summary>
        [Display(Name = "RecordPrinted", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.RecordPrinted, Id = Index.RecordPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordPrinted RecordPrinted { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets PMAdjustmentNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMAdjustmentNumber", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.PMAdjustmentNumber, Id = Index.PMAdjustmentNumber, FieldType = EntityFieldType.Char, Size = 16)]
        public string PMAdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets PostSequenceNumber
        /// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long PostSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessCommandLocation", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.ProcessCommandLocation, Id = Index.ProcessCommandLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ProcessCommandLocation { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets FromPhysicalInventory
        /// </summary>
        [Display(Name = "FromPhysicalInventory", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.FromPhysicalInventory, Id = Index.FromPhysicalInventory, FieldType = EntityFieldType.Bool, Size = 2)]
        public FromPhysicalInventory FromPhysicalInventory { get; set; }

        /// <summary>
        ///  Gets or sets AdjustmentHeaderOptionalFields
        /// </summary>
        public EnumerableResponse<AdjustmentHeaderOptionalField> AdjustmentHeaderOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentDetails
        /// </summary>
        public EnumerableResponse<AdjustmentDetail> AdjustmentDetails { get; set; }

        /// <summary>
        /// To get the string of Record Status property
        /// </summary>
        public string RecordStatusFinder
        {
            get { return EnumUtility.GetStringValue(RecordStatus); }
        }

        /// <summary>
        /// Gets or sets NotDefaulted
        /// </summary>
        public bool NotDefaulted { get; set; }

        /// <summary>
        /// Gets or sets HeaderExists
        /// </summary>
        public bool HeaderExists { get; set; }

        #endregion

        #region User Defined

        /// <summary>
        /// String value of RecordDeleted
        /// </summary>
        public string RecordDeletedString
        {
            get { return EnumUtility.GetStringValue(RecordDeleted); }
        }

        /// <summary>
        /// String value of RecordPrinted
        /// </summary>
        public string RecordPrintedString
        {
            get { return EnumUtility.GetStringValue(RecordPrinted); }
        }

        /// <summary>
        /// String value of ProcessCommand
        /// </summary>
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// String value of FromPhysicalInventory
        /// </summary>
        public string FromPhysicalInventoryString
        {
            get { return EnumUtility.GetStringValue(FromPhysicalInventory); }
        }

        /// <summary>
        /// String value of Job Related
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        public string FiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(FiscalPeriod); }
        }
        #endregion
    }
}
