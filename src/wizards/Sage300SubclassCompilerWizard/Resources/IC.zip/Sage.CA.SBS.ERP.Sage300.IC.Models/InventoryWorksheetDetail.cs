// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Partial class for InventoryWorksheetDetail
     /// </summary>
     public partial class InventoryWorksheetDetail : ModelBase
     {
          /// <summary>
          /// Gets or sets Location
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string Location {get; set;}

          /// <summary>
          /// Gets or sets SortCode
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "SortCode", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
          [ViewField(Name = Fields.SortCode, Id = Index.SortCode, FieldType = EntityFieldType.Char, Size = 60)]
          public string SortCode {get; set;}

          /// <summary>
          /// Gets or sets ItemNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ItemNumber {get; set;}

          /// <summary>
          /// Gets or sets UnitOfMeasure
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
          public string UnitOfMeasure {get; set;}

          /// <summary>
          /// Gets or sets QuantityCounted
          /// </summary>
          [Display(Name = "QuantityCounted", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.QuantityCounted, Id = Index.QuantityCounted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public string QuantityCounted { get; set; }

          /// <summary>
          /// Gets or sets ConversionFactor
          /// </summary>
          [Display(Name = "ConversionFactor", ResourceType = typeof(ICCommonResx))]
          [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal ConversionFactor {get; set;}
     }
}
