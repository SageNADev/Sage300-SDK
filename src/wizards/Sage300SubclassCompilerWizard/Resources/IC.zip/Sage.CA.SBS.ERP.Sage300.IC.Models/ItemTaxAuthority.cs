// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Usings

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class ItemTaxAuthority : ModelBase
    {

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Authority", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets PurchaseTaxClass 
        /// </summary>
        [Display(Name = "PurchaseTaxClass", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PurchaseTaxClass, Id = Index.PurchaseTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int PurchaseTaxClass { get; set; }

        /// <summary>
        /// Gets or sets SalesTaxClass 
        /// </summary>
        [Display(Name = "SalesTaxClass", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SalesTaxClass, Id = Index.SalesTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesTaxClass { get; set; }

        /// <summary>
        /// Gets or sets PurchaseTaxClassDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PurchaseTaxClassDesc", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.PurchaseTaxClassDescription, Id = Index.PurchaseTaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PurchaseTaxClassDescription { get; set; }

        /// <summary>
        /// Gets or sets SalesTaxClassDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalesTaxClassDesc", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.SalesTaxClassDescription, Id = Index.SalesTaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SalesTaxClassDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TaxAuthorityDescription, Id = Index.TaxAuthorityDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }
    }
}
