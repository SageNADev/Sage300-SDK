// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Usings

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Class for Customer Item Number
    /// </summary>
    public partial class CustomerItemNumber : ModelBase
    {

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets CustomersItemNumber 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustItemNo", ResourceType = typeof(CustomerDetailsResx))]
        [ViewField(Name = Fields.CustomersItemNumber, Id = Index.CustomersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CustomersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomersItemDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustItemDesc", ResourceType = typeof(CustomerDetailsResx))]
        [ViewField(Name = Fields.CustomersItemDescription, Id = Index.CustomersItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomersItemDescription { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Comments 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets Instructions 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Instructions", ResourceType = typeof(CustomerDetailsResx))]
        [ViewField(Name = Fields.Instructions, Id = Index.Instructions, FieldType = EntityFieldType.Char, Size = 80)]
        public string Instructions { get; set; }

        /// <summary>
        /// Gets or sets FmtItemNumber 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FmtItemNumber, Id = Index.FmtItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FmtItemNumber { get; set; }

        /// <summary>
        /// Gets or sets IsValidCustomer
        /// </summary>
        public bool IsValidCustomer { get; set; }
    }
}
