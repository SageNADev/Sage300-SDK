// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System.ComponentModel.DataAnnotations;

#endregion Namespace


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for StockTransactionInquirySumm
    /// </summary>
    public partial class StockTransactionInquirySummary : ModelBase
    {
        /// <summary>
        /// Gets or sets FromItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FromItemNumber, Id = Index.FromItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string FromItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ToItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ToItemNumber, Id = Index.ToItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ToItemNumber { get; set; }

        /// <summary>
        /// Gets or sets FromAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FromAccountSet, Id = Index.FromAccountSet, FieldType = EntityFieldType.Char, Size = 6)]
        public string FromAccountSet { get; set; }

        /// <summary>
        /// Gets or sets ToAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ToAccountSet, Id = Index.ToAccountSet, FieldType = EntityFieldType.Char, Size = 6)]
        public string ToAccountSet { get; set; }

        /// <summary>
        /// Gets or sets FromLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FromLocation, Id = Index.FromLocation, FieldType = EntityFieldType.Char, Size = 6)]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets ToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ToLocation, Id = Index.ToLocation, FieldType = EntityFieldType.Char, Size = 6)]
        public string ToLocation { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets UnitsOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitsOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitsOfMeasure, Id = Index.UnitsOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitsOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets OpeningQuantity
        /// </summary>
        [ViewField(Name = Fields.OpeningQuantity, Id = Index.OpeningQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OpeningQuantity { get; set; }

        /// <summary>
        /// Gets or sets OpeningTotalCost
        /// </summary>
        [ViewField(Name = Fields.OpeningTotalCost, Id = Index.OpeningTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OpeningTotalCost { get; set; }

        /// <summary>
        /// Gets or sets OpeningAverageCost
        /// </summary>
        [ViewField(Name = Fields.OpeningAverageCost, Id = Index.OpeningAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OpeningAverageCost { get; set; }

        /// <summary>
        /// Gets or sets ReceiptQuantity
        /// </summary>
        [ViewField(Name = Fields.ReceiptQuantity, Id = Index.ReceiptQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ReceiptQuantity { get; set; }

        /// <summary>
        /// Gets or sets ReceiptTotalCost
        /// </summary>
        [ViewField(Name = Fields.ReceiptTotalCost, Id = Index.ReceiptTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReceiptTotalCost { get; set; }

        /// <summary>
        /// Gets or sets ReceiptAverageCost
        /// </summary>
        [ViewField(Name = Fields.ReceiptAverageCost, Id = Index.ReceiptAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReceiptAverageCost { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCount
        /// </summary>
        [ViewField(Name = Fields.ReceiptCount, Id = Index.ReceiptCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReceiptCount { get; set; }

        /// <summary>
        /// Gets or sets ReturnQuantity
        /// </summary>
        [ViewField(Name = Fields.ReturnQuantity, Id = Index.ReturnQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ReturnQuantity { get; set; }

        /// <summary>
        /// Gets or sets ReturnTotalCost
        /// </summary>
        [ViewField(Name = Fields.ReturnTotalCost, Id = Index.ReturnTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReturnTotalCost { get; set; }

        /// <summary>
        /// Gets or sets ReturnAverageCost
        /// </summary>
        [ViewField(Name = Fields.ReturnAverageCost, Id = Index.ReturnAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReturnAverageCost { get; set; }

        /// <summary>
        /// Gets or sets ReturnCount
        /// </summary>
        [ViewField(Name = Fields.ReturnCount, Id = Index.ReturnCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReturnCount { get; set; }

        /// <summary>
        /// Gets or sets SalesQuantity
        /// </summary>
        [ViewField(Name = Fields.SalesQuantity, Id = Index.SalesQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SalesQuantity { get; set; }

        /// <summary>
        /// Gets or sets SalesTotalCost
        /// </summary>
        [ViewField(Name = Fields.SalesTotalCost, Id = Index.SalesTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SalesTotalCost { get; set; }

        /// <summary>
        /// Gets or sets SalesAverageCost
        /// </summary>
        [ViewField(Name = Fields.SalesAverageCost, Id = Index.SalesAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SalesAverageCost { get; set; }

        /// <summary>
        /// Gets or sets SalesCount
        /// </summary>
        [ViewField(Name = Fields.SalesCount, Id = Index.SalesCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesCount { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentsQuantity
        /// </summary>
        [ViewField(Name = Fields.AdjustmentsQuantity, Id = Index.AdjustmentsQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal AdjustmentsQuantity { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentsTotalCost
        /// </summary>
        [ViewField(Name = Fields.AdjustmentsTotalCost, Id = Index.AdjustmentsTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustmentsTotalCost { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentsAverageCost
        /// </summary>
        [ViewField(Name = Fields.AdjustmentsAverageCost, Id = Index.AdjustmentsAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustmentsAverageCost { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentsCount
        /// </summary>
        [ViewField(Name = Fields.AdjustmentsCount, Id = Index.AdjustmentsCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int AdjustmentsCount { get; set; }

        /// <summary>
        /// Gets or sets TransfersQuantity
        /// </summary>
        [ViewField(Name = Fields.TransfersQuantity, Id = Index.TransfersQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TransfersQuantity { get; set; }

        /// <summary>
        /// Gets or sets TransfersTotalCost
        /// </summary>
        [ViewField(Name = Fields.TransfersTotalCost, Id = Index.TransfersTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransfersTotalCost { get; set; }

        /// <summary>
        /// Gets or sets TransfersAverageCost
        /// </summary>
        [ViewField(Name = Fields.TransfersAverageCost, Id = Index.TransfersAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransfersAverageCost { get; set; }

        /// <summary>
        /// Gets or sets TransfersCount
        /// </summary>
        [ViewField(Name = Fields.TransfersCount, Id = Index.TransfersCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransfersCount { get; set; }

        /// <summary>
        /// Gets or sets AssembliesQuantity
        /// </summary>
        [ViewField(Name = Fields.AssembliesQuantity, Id = Index.AssembliesQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal AssembliesQuantity { get; set; }

        /// <summary>
        /// Gets or sets AssembliesTotalCost
        /// </summary>
        [ViewField(Name = Fields.AssembliesTotalCost, Id = Index.AssembliesTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AssembliesTotalCost { get; set; }

        /// <summary>
        /// Gets or sets AssembliesAverageCost
        /// </summary>
        [ViewField(Name = Fields.AssembliesAverageCost, Id = Index.AssembliesAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AssembliesAverageCost { get; set; }

        /// <summary>
        /// Gets or sets AssembliesCount
        /// </summary>
        [ViewField(Name = Fields.AssembliesCount, Id = Index.AssembliesCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int AssembliesCount { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageQuantity
        /// </summary>
        [ViewField(Name = Fields.InternalUsageQuantity, Id = Index.InternalUsageQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal InternalUsageQuantity { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageTotalCost
        /// </summary>
        [ViewField(Name = Fields.InternalUsageTotalCost, Id = Index.InternalUsageTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InternalUsageTotalCost { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageAverageCost
        /// </summary>
        [ViewField(Name = Fields.InternalUsageAverageCost, Id = Index.InternalUsageAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InternalUsageAverageCost { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageCount
        /// </summary>
        [ViewField(Name = Fields.InternalUsageCount, Id = Index.InternalUsageCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int InternalUsageCount { get; set; }

        /// <summary>
        /// Gets or sets ClosingQuantity
        /// </summary>
        [ViewField(Name = Fields.ClosingQuantity, Id = Index.ClosingQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ClosingQuantity { get; set; }

        /// <summary>
        /// Gets or sets ClosingTotalCost
        /// </summary>
        [ViewField(Name = Fields.ClosingTotalCost, Id = Index.ClosingTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClosingTotalCost { get; set; }

        /// <summary>
        /// Gets or sets ClosingAverageCost
        /// </summary>
        [ViewField(Name = Fields.ClosingAverageCost, Id = Index.ClosingAverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClosingAverageCost { get; set; }

        /// <summary>
        /// Gets or sets StockTransactions
        /// </summary>
        public EnumerableResponse<StockTransactionGridItem> StockTransactions { get; set; }
    }

    /// <summary>
    /// Class Stock Transaction Grid
    /// </summary>
    public class StockTransactionGridItem : ModelBase
    {
        /// <summary>
        /// Gets or sets Statistics
        /// </summary>
        public string Type { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        public decimal? Quantity { get; set; }

        /// <summary>
        /// Gets or sets TotalCost
        /// </summary>
        public decimal TotalCost { get; set; }

        /// <summary>
        /// Gets or sets AverageCost
        /// </summary>
        public decimal AverageCost { get; set; }

        /// <summary>
        /// Gets or sets Decimals precision
        /// </summary>
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets UnitofMeasure 
        /// </summary>
        public string UnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        public string Category { get; set; }
    }
}
