// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for Label
	/// </summary>
	public partial class Label : ModelBase
	{
		/// <summary>
		/// Gets or sets ReceiptNumber
		/// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(ICCommonResx))]
	    [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
	    public string ReceiptNumber { get; set; }

		/// <summary>
		/// Gets or sets SequenceNumber
		/// </summary>
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

		/// <summary>
		/// Gets or sets LineNumber
		/// </summary>
		[ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int LineNumber { get; set; }

		/// <summary>
		/// Gets or sets ItemNumber
		/// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
	    [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
	    public string ItemNumber { get; set; }

		/// <summary>
		/// Gets or sets Location
		/// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
		public string Location { get; set; }

		/// <summary>
		/// Gets or sets NumberOfLabels
		/// </summary>
	    [ViewField(Name = Fields.NumberOfLabels, Id = Index.NumberOfLabels, FieldType = EntityFieldType.Int, Size = 2)]
	    public int NumberOfLabels { get; set; }

		/// <summary>
		/// Gets or sets Printed
		/// </summary>
		[ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
		public Printed Printed { get; set; }

		#region UI Strings
		/// <summary>
		/// Gets Printed string value
		/// </summary>
		public string PrintedString
		{
			get { return EnumUtility.GetStringValue(Printed); }
		}
		#endregion
	}
}
