// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for CurrentTransactionsInquiry For SalesOrder
    /// </summary>
    public partial class POCurrentTransactionsInquiry : ModelBase
    {
        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets HeaderSequence
        /// </summary>
        [ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal HeaderSequence { get; set; }

        /// <summary>
        /// Gets or sets LineSequence
        /// </summary>
        [ViewField(Name = Fields.LineSequence, Id = Index.LineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineSequence { get; set; }

        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [Display(Name = "PONumber", ResourceType = typeof(ICCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber
        /// </summary>
        [Display(Name = "VendorNumber", ResourceType = typeof(ICCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorName
        /// </summary>
        [Display(Name = "VendorName", ResourceType = typeof(ICCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets ExpectedArrivalDate
        /// </summary>
        [Display(Name = "ExpectedArrivalDate", ResourceType = typeof(ICCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpectedArrivalDate, Id = Index.ExpectedArrivalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedArrivalDate { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets QtyOrdered
        /// </summary>
        [ViewField(Name = Fields.QtyOrdered, Id = Index.QtyOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyOrdered { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Display(Name = "UnitsOfMeasure", ResourceType = typeof(ICCommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets QtyReceived
        /// </summary>
        [ViewField(Name = Fields.QtyReceived, Id = Index.QtyReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyReceived { get; set; }

        /// <summary>
        /// Gets or sets QtyOutstanding
        /// </summary>
        [ViewField(Name = Fields.QtyOutstanding, Id = Index.QtyOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyOutstanding { get; set; }

        /// <summary>
        /// Gets or sets PoAccessRight
        /// </summary>
        public bool PoAccessRight { get; set; }

    }

}
