// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Partial class for Receipt Detail OptionalField
     /// </summary>
    public partial class ReceiptDetailOptionalField : ReceiptOptionalField
     {
          ///// <summary>
          ///// Gets or sets LineNumber
          ///// </summary>
          //[Key]
          //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          //[Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]           
          //public new int LineNumber {get; set;}
     }
}
