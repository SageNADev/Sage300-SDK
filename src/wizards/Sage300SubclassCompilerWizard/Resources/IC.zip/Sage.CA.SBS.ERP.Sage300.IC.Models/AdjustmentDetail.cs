// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for AdjustmentDetail
    /// </summary>
    public partial class AdjustmentDetail : ModelBase
    {
        #region Constructor

        /// <summary>
        /// AdjustmentDetail Constructor 
        /// </summary>
        public AdjustmentDetail()
        {
            AdjustmentDetailOptionalFields = new EnumerableResponse<AdjustmentDetailOptionalField>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets DynamicDetailAttributes
        /// </summary>
        [IgnoreExportImport]
        public IDictionary<string, object> DynamicDetailAttributes { get; set; }

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactor
        /// </summary>
        [Display(Name = "ConversionFactor", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets CostAdjustment
        /// </summary>
        [Display(Name = "CostAdjustment", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.CostAdjustment, Id = Index.CostAdjustment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostAdjustment { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentWriteOffAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdjustmentWriteOffAccount", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.AdjustmentWriteOffAccount, Id = Index.AdjustmentWriteOffAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AdjustmentWriteOffAccount { get; set; }

        /// <summary>
        /// Gets or sets OriginalWriteOffAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalWriteOffAccount", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.OriginalWriteOffAccount, Id = Index.OriginalWriteOffAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string OriginalWriteOffAccount { get; set; }

        /// <summary>
        /// Gets or sets CostingMethod
        /// </summary>
        [Display(Name = "CostingMethod", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostingMethod, Id = Index.CostingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public int CostingMethod { get; set; }

        /// <summary>
        /// Gets or sets BucketType
        /// </summary>
        [Display(Name = "BucketType", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.BucketType, Id = Index.BucketType, FieldType = EntityFieldType.Int, Size = 2)]
        public BucketType BucketType { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CostDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostDate", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.CostDate, Id = Index.CostDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? CostDate { get; set; }

        /// <summary>
        /// Gets or sets CostingSequenceNumber
        /// </summary>
        [Display(Name = "CostingSequenceNumber", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.CostingSequenceNumber, Id = Index.CostingSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Display(Name = "DetailLineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets PMContract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMContract", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMContract, Id = Index.PMContract, FieldType = EntityFieldType.Char, Size = 16)]
        public string PMContract { get; set; }

        /// <summary>
        /// Gets or sets PMProject
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMProject", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMProject, Id = Index.PMProject, FieldType = EntityFieldType.Char, Size = 16)]
        public string PMProject { get; set; }

        /// <summary>
        /// Gets or sets PMCategory
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMCategory", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMCategory, Id = Index.PMCategory, FieldType = EntityFieldType.Char, Size = 16)]
        public string PMCategory { get; set; }

        /// <summary>
        /// Gets or sets PMOverheadAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMOHacct", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMOverheadAccount, Id = Index.PMOverheadAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PMOverheadAccount { get; set; }

        /// <summary>
        /// Gets or sets PMOverheadAmount
        /// </summary>
        [Display(Name = "PMOHAmt", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMOverheadAmount, Id = Index.PMOverheadAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PMOverheadAmount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets NumberOfSerials
        /// </summary>
        [Display(Name = "NumberOfSerials", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.NumberOfSerials, Id = Index.NumberOfSerials, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfSerials { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets SerialsCost
        /// </summary>
        [Display(Name = "SerialsCost", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.SerialsCost, Id = Index.SerialsCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SerialsCost { get; set; }

        /// <summary>
        /// Gets or sets LotsCost
        /// </summary>
        [Display(Name = "LotsCost", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.LotsCost, Id = Index.LotsCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LotsCost { get; set; }

        /// <summary>
        /// Gets or sets AverageCost
        /// </summary>
        [Display(Name = "AverageCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AverageCost, Id = Index.AverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AverageCost { get; set; }

        /// <summary>
        /// Gets or sets CostUOM
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostUOM", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.CostUOM, Id = Index.CostUOM, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string CostUOM { get; set; }

        /// <summary>
        /// Gets or sets RevisionListLineNumber
        /// </summary>
        [Display(Name = "RevisionListLineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.RevisionListLineNumber, Id = Index.RevisionListLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int RevisionListLineNumber { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [Display(Name = "InterprocessCommID", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSN
        /// </summary>
        [Display(Name = "ForcePopupSN", ResourceType = typeof(AdjustmentResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.ForcePopupSN, Id = Index.ForcePopupSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupSN { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        [Display(Name = "PopupSN", ResourceType = typeof(AdjustmentResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.PopupSN, Id = Index.PopupSN, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupSN { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        [Display(Name = "CloseSN", ResourceType = typeof(AdjustmentResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.CloseSN, Id = Index.CloseSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseSN { get; set; }

        /// <summary>
        /// Gets or sets LTSetID
        /// </summary>
        [Display(Name = "LTSetID", ResourceType = typeof(AdjustmentResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.LTSetID, Id = Index.LTSetID, FieldType = EntityFieldType.Long, Size = 4)]
        public long LTSetID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLT
        /// </summary>
        [Display(Name = "ForcePopupLT", ResourceType = typeof(AdjustmentResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.ForcePopupLT, Id = Index.ForcePopupLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupLT { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        [Display(Name = "PopupLT", ResourceType = typeof(AdjustmentResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.PopupLT, Id = Index.PopupLT, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupLT { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [Display(Name = "CloseLT", ResourceType = typeof(AdjustmentResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.CloseLT, Id = Index.CloseLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseLT { get; set; }

        /// <summary>
        /// Gets or sets Un formatted ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessCommandLocation", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.ProcessCommandLocation, Id = Index.ProcessCommandLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ProcessCommandLocation { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandSortCode
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessCommandSortCode", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.ProcessCommandSortCode, Id = Index.ProcessCommandSortCode, FieldType = EntityFieldType.Char, Size = 60)]
        public string ProcessCommandSortCode { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessCommandItemNumber", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.ProcessCommandItemNumber, Id = Index.ProcessCommandItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ProcessCommandItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityperLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentDetailOptionalFields
        /// </summary>
        public EnumerableResponse<AdjustmentDetailOptionalField> AdjustmentDetailOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentDetailLotNumber
        /// </summary>
        [IgnoreExportImport]
        public AdjustmentDetailLotNumber AdjustmentDetailLotNumber { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentDetailSerialNumber
        /// </summary>
        [IgnoreExportImport]
        public AdjustmentDetailSerialNumber AdjustmentDetailSerialNumber { get; set; }

        #endregion

        #region Grid UI logic

        /// <summary>
        /// Gets or sets AccountDescription
        /// </summary>
        [IgnoreExportImport]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets ItemNumberNonEditable
        /// </summary>
        [IgnoreExportImport]
        public bool ItemNumberNonEditable { get; set; }

        /// <summary>
        /// Gets OptionalFieldString 
        /// </summary>
        [IgnoreExportImport]
        public string OptionalFieldString
        {
            get
            {
                return OptionalFields > 0 ? CommonResx.Yes : CommonResx.No;
            }
        }

        #endregion
    }
}
