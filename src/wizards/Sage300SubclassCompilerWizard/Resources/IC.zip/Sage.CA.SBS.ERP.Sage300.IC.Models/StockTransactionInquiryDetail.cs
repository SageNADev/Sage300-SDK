// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for StockTransactionInquiryDetail
    /// </summary>
    public partial class StockTransactionInquiryDetail : ModelBase
    {
        /// <summary>
        /// Constructor Stock Transaction Inquiry Detail
        /// </summary>
        public StockTransactionInquiryDetail()
        {
            StockTransactionDetailItems = new EnumerableResponse<StockTransactionInquiryDetail>();
        }

        /// <summary>
        /// Gets or sets AccountSetCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DayEndNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DayEndNumber, Id = Index.DayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionSequence", ResourceType = typeof(TransactionHistoryInquiryResx))]
        [ViewField(Name = Fields.TransactionSequence, Id = Index.TransactionSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionSequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionTypes TransactionType { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets TransactionQuantity
        /// </summary>
        [Display(Name = "TransactionQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactor
        /// </summary>
        [Display(Name = "ConversionFactor", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets TransactionCost
        /// </summary>
        [Display(Name = "TransactionCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionCost, Id = Index.TransactionCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionCost { get; set; }

        /// <summary>
        /// Gets or sets QuantityInStockingUom
        /// </summary>
        [ViewField(Name = Fields.QuantityInStockingUom, Id = Index.QuantityInStockingUom, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityInStockingUom { get; set; }

        /// <summary>
        /// Gets or sets OptionalAmount
        /// </summary>
        [ViewField(Name = Fields.OptionalAmount, Id = Index.OptionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OptionalAmount { get; set; }

        /// <summary>
        /// Gets or sets Application
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TitleApp", ResourceType = typeof(StockTransactionsInquiryResx))]
        [ViewField(Name = Fields.Application, Id = Index.Application, FieldType = EntityFieldType.Char, Size = 2)]
        public string Application { get; set; }

        /// <summary>
        /// Gets or sets StockUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StockUnit, Id = Index.StockUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string StockUnit { get; set; }

        /// <summary>
        /// Gets or sets DefaultPriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultPriceList", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DefaultPriceList, Id = Index.DefaultPriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultPriceList { get; set; }

        /// <summary>
        /// Gets or sets TotalCost
        /// </summary>
        [Display(Name = "TotalCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TotalCost, Id = Index.TotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCost { get; set; }

        /// <summary>
        /// Gets or sets RecentCost
        /// </summary>
        [ViewField(Name = Fields.RecentCost, Id = Index.RecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal RecentCost { get; set; }

        /// <summary>
        /// Gets or sets Cost1Name
        /// </summary>
        [ViewField(Name = Fields.Cost1Name, Id = Index.Cost1Name, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost1Name { get; set; }

        /// <summary>
        /// Gets or sets Cost2Name
        /// </summary>
        [ViewField(Name = Fields.Cost2Name, Id = Index.Cost2Name, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost2Name { get; set; }

        /// <summary>
        /// Gets or sets LastCost
        /// </summary>
        [ViewField(Name = Fields.LastCost, Id = Index.LastCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LastCost { get; set; }

        /// <summary>
        /// Gets or sets StandardCost
        /// </summary>
        [ViewField(Name = Fields.StandardCost, Id = Index.StandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal StandardCost { get; set; }

        /// <summary>
        /// Gets or sets CostUnit
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CostUnit, Id = Index.CostUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string CostUnit { get; set; }

        /// <summary>
        /// Gets or sets CostConversion
        /// </summary>
        [ViewField(Name = Fields.CostConversion, Id = Index.CostConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CostConversion { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantity
        /// </summary>
        [Display(Name = "TotalQuantity", ResourceType = typeof(StockTransactionsInquiryResx))]
        [ViewField(Name = Fields.TotalQuantity, Id = Index.TotalQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalQuantity { get; set; }

        /// <summary>
        /// Gets or sets PriceListCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceListCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PriceListCode, Id = Index.PriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceListCode { get; set; }

        /// <summary>
        /// Gets or sets DecimalsInPrice
        /// </summary>
        [ViewField(Name = Fields.DecimalsInPrice, Id = Index.DecimalsInPrice, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalsInPrice { get; set; }

        /// <summary>
        /// Gets or sets BasePrice
        /// </summary>
        [Display(Name = "BasePrice", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.BasePrice, Id = Index.BasePrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BasePrice { get; set; }

        /// <summary>
        /// Gets or sets PricingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PricingUnitOfMeasure, Id = Index.PricingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string PricingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets BaseConversionFactor
        /// </summary>
        [ViewField(Name = Fields.BaseConversionFactor, Id = Index.BaseConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BaseConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailComponentNumber
        /// </summary>
        [ViewField(Name = Fields.DetailComponentNumber, Id = Index.DetailComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DetailComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets FormattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string FormattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        #region UI Parameters (Required for the Stock Transaction Details Filter)

        /// <summary>
        /// Gets or sets FromAccountSetCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
        public string FromAccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets FromLocation
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets FromItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        public string FromItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ToAccountSetCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
        public string ToAccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets ToLocation
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        public string ToLocation { get; set; }

        /// <summary>
        /// Gets or sets ToItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        public string ToItemNumber { get; set; }

        #endregion
        
        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        public string TransactionTypeText { get; set; }

        /// <summary>
        /// Collection of StockTransactionInquiry Detail
        /// </summary>
        public EnumerableResponse<StockTransactionInquiryDetail> StockTransactionDetailItems { get; set; }
    }
}
