// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A Partial class for InventoryWorksheet
    /// </summary>
    public partial class InventoryWorksheet : ModelBase
    {
        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets WorksheetStatus
        /// </summary>
        [Display(Name = "WorksheetStatus", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.WorksheetStatus, Id = Index.WorksheetStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public WorksheetStatus WorksheetStatus { get; set; }

        /// <summary>
        /// Gets WorkSheet Status Description
        /// </summary>
        [IgnoreExportImport]
        public string WorksheetStatusDescription
        {
            get { return EnumUtility.GetStringValue(WorksheetStatus); }
        }

        /// <summary>
        /// Gets or sets DateCreated
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCreated", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.DateCreated, Id = Index.DateCreated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets WorksheetComment
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WorksheetComment", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.WorksheetComment, Id = Index.WorksheetComment, FieldType = EntityFieldType.Char, Size = 60)]
        public string WorksheetComment { get; set; }

        /// <summary>
        /// Gets or sets SortOrder
        /// </summary>
        [Display(Name = "SortOrder", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.SortOrder, Id = Index.SortOrder, FieldType = EntityFieldType.Int, Size = 2)]
        public SortOrder SortOrder { get; set; }

        /// <summary>
        /// Gets or sets SortOrderDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SortOrderDescription", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.SortOrderDescription, Id = Index.SortOrderDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SortOrderDescription { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber
        /// </summary>
        [Display(Name = "SegmentNo", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SegmentNumber, Id = Index.SegmentNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public SegmentNumber SegmentNumber { get; set; }
      
        /// <summary>
        /// Gets or sets SegmentDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentDescription", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.SegmentDescription, Id = Index.SegmentDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SegmentDescription { get; set; }

        /// <summary>
        /// Gets or sets FromCode
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromCode", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.FromCode, Id = Index.FromCode, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-24C")]
        public string FromCode { get; set; }

        /// <summary>
        /// Gets or sets ToCode
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToCode", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.ToCode, Id = Index.ToCode, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-24C")]
        public string ToCode { get; set; }

        /// <summary>
        /// Gets or sets FromAccountSetCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromAccountSetCode", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.FromAccountSetCode, Id = Index.FromAccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string FromAccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets ToAccountSetCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToAccountSetCode", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.ToAccountSetCode, Id = Index.ToAccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ToAccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }
     
        /// <summary>
        /// Gets or sets ProcessAction
        /// </summary>
        [Display(Name = "ProcessAction", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.ProcessAction, Id = Index.ProcessAction, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessAction { get; set; }
      
        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }
      
        /// <summary>
        /// Gets Process Command Description
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandDescription
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets the property Sort Order
        /// </summary>
        [IgnoreExportImport]
        public string SortOrderName
        {
            get { return EnumUtility.GetStringValue(SortOrder); }
        }

        /// <summary>
        /// Gets the Segment Number Name.
        /// </summary>
        [IgnoreExportImport]
        public string SegmentNumberName
        {
            get { return EnumUtility.GetStringValue(SegmentNumber); }
        }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12)]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets WorksheetOptionalField collection.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<WorksheetOptionalField> WorksheetOptionalField { get; set; }

        /// <summary>
        /// Gets or sets InventoryWorksheetHeader collection
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InventoryWorksheetHeader> InventoryWorksheetHeader { get; set; }

        /// <summary>
        /// Gets or sets InventoryWorksheetHeader
        /// </summary>
        [IgnoreExportImport]
        public InventoryWorksheetHeader InventoryWorksheetHeaderGrid { get; set; }

        /// <summary>
        /// Gets or sets InventoryWorksheetDetail collection
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InventoryWorksheetDetail> InventoryWorksheetDetail { get; set; }
    }
}
