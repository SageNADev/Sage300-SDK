// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for CurrentTransactionsInquiryfor
    /// </summary>
    public partial class SOCurrentTransactionsInquiry : ModelBase
    {
        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderUniquifier
        /// </summary>
        [ViewField(Name = Fields.OrderUniquifier, Id = Index.OrderUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal OrderUniquifier { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [Display(Name = "OrderNumber", ResourceType = typeof(ICCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(ICCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [Display(Name = "CustomerName", ResourceType = typeof(ICCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets ExpectedShipDate
        /// </summary>
        [Display(Name = "ExpectedShipDate", ResourceType = typeof(ICCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpectedShipDate, Id = Index.ExpectedShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedShipDate { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets OriginalQuantityOrdered
        /// </summary>
        [ViewField(Name = Fields.OriginalQuantityOrdered, Id = Index.OriginalQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OriginalQuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Display(Name = "UnitsOfMeasure", ResourceType = typeof(ICCommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets QuantityShipped
        /// </summary>
        [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShipped { get; set; }

        /// <summary>
        /// Gets or sets QuantityOutstanding
        /// </summary>
        [ViewField(Name = Fields.QuantityOutstanding, Id = Index.QuantityOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOutstanding { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets or sets OeAccessRight
        /// </summary>
        public bool OeAccessRight { get; set; }

        #endregion
    }
}
