// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class ItemStructure : ModelBase
    {
        /// <summary>
        /// Gets or sets StructureCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StructureCode", ResourceType = typeof(ItemStructuresResx))]
        [Key]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Prefix 
        /// </summary>
        [Display(Name = "Prefix", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Prefix, Id = Index.Prefix, FieldType = EntityFieldType.Int, Size = 2)]
        public string Prefix { get; set; }

        /// <summary>
        /// Gets or sets Segment1 
        /// </summary>
        [Display(Name = "Segment1", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment1, Id = Index.Segment1, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment1 { get; set; }
  
        /// <summary>
        /// Gets or sets Segment1Offset 
        /// </summary>
        [Display(Name = "Segment1Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment1Offset, Id = Index.Segment1Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment1Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment1Length 
        /// </summary>
        [Display(Name = "Segment1Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment1Length, Id = Index.Segment1Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment1Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment1 
        /// </summary>
        [Display(Name = "ValidateSegment1", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment1, Id = Index.ValidateSegment1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator1 
        /// </summary>
        [Display(Name = "SegmentSeparator1", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator1, Id = Index.SegmentSeparator1, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator1 { get; set; }

        /// <summary>
        /// Gets or sets Segment2 
        /// </summary>
        [Display(Name = "Segment2", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment2, Id = Index.Segment2, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment2 { get; set; }

        /// <summary>
        /// Gets or sets Segment2Offset 
        /// </summary>
        [Display(Name = "Segment2Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment2Offset, Id = Index.Segment2Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment2Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment2Length 
        /// </summary>
        [Display(Name = "Segment2Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment2Length, Id = Index.Segment2Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment2Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment2 
        /// </summary>
        [Display(Name = "ValidateSegment2", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment2, Id = Index.ValidateSegment2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator2 
        /// </summary>
        [Display(Name = "SegmentSeparator2", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator2, Id = Index.SegmentSeparator2, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator2 { get; set; }

        /// <summary>
        /// Gets or sets Segment3 
        /// </summary>
        [Display(Name = "Segment3", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment3, Id = Index.Segment3, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment3 { get; set; }

        /// <summary>
        /// Gets or sets Segment3Offset 
        /// </summary>
        [Display(Name = "Segment3Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment3Offset, Id = Index.Segment3Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment3Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment3Length 
        /// </summary>
        [Display(Name = "Segment3Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment3Length, Id = Index.Segment3Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment3Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment3 
        /// </summary>
        [Display(Name = "ValidateSegment3", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment3, Id = Index.ValidateSegment3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator3 
        /// </summary>
        [Display(Name = "SegmentSeparator3", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator3, Id = Index.SegmentSeparator3, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator3 { get; set; }

        /// <summary>
        /// Gets or sets Segment4 
        /// </summary>
        [Display(Name = "Segment4", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment4, Id = Index.Segment4, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment4 { get; set; }

        /// <summary>
        /// Gets or sets Segment4Offset 
        /// </summary>
        [Display(Name = "Segment4Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment4Offset, Id = Index.Segment4Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment4Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment4Length 
        /// </summary>
        [Display(Name = "Segment4Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment4Length, Id = Index.Segment4Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment4Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment4 
        /// </summary>
        [Display(Name = "ValidateSegment4", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment4, Id = Index.ValidateSegment4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator4 
        /// </summary>
        [Display(Name = "SegmentSeparator4", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator4, Id = Index.SegmentSeparator4, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator4 { get; set; }

        /// <summary>
        /// Gets or sets Segment5 
        /// </summary>
        [Display(Name = "Segment5", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment5, Id = Index.Segment5, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment5 { get; set; }

        /// <summary>
        /// Gets or sets Segment5Offset 
        /// </summary>
        [Display(Name = "Segment5Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment5Offset, Id = Index.Segment5Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment5Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment5Length 
        /// </summary>
        [Display(Name = "Segment5Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment5Length, Id = Index.Segment5Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment5Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment5 
        /// </summary>
        [Display(Name = "ValidateSegment5", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment5, Id = Index.ValidateSegment5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator5 
        /// </summary>
        [Display(Name = "SegmentSeparator5", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator5, Id = Index.SegmentSeparator5, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator5 { get; set; }

        /// <summary>
        /// Gets or sets Segment6 
        /// </summary>
        [Display(Name = "Segment6", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment6, Id = Index.Segment6, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment6 { get; set; }

        /// <summary>
        /// Gets or sets Segment6Offset 
        /// </summary>
        [Display(Name = "Segment6Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment6Offset, Id = Index.Segment6Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment6Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment6Length 
        /// </summary>
        [Display(Name = "Segment6Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment6Length, Id = Index.Segment6Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment6Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment6 
        /// </summary>
        [Display(Name = "ValidateSegment6", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment6, Id = Index.ValidateSegment6, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment6 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator6 
        /// </summary>
        [Display(Name = "SegmentSeparator6", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator6, Id = Index.SegmentSeparator6, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator6 { get; set; }

        /// <summary>
        /// Gets or sets Segment7 
        /// </summary>
        [Display(Name = "Segment7", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment7, Id = Index.Segment7, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment7 { get; set; }

        /// <summary>
        /// Gets or sets Segment7Offset 
        /// </summary>
        [Display(Name = "Segment7Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment7Offset, Id = Index.Segment7Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment7Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment7Length 
        /// </summary>
        [Display(Name = "Segment7Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment7Length, Id = Index.Segment7Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment7Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment7 
        /// </summary>
        [Display(Name = "ValidateSegment7", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment7, Id = Index.ValidateSegment7, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment7 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator7 
        /// </summary>
        [Display(Name = "SegmentSeparator7", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator7, Id = Index.SegmentSeparator7, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator7 { get; set; }

        /// <summary>
        /// Gets or sets Segment8 
        /// </summary>
        [Display(Name = "Segment8", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment8, Id = Index.Segment8, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment8 { get; set; }

        /// <summary>
        /// Gets or sets Segment8Offset 
        /// </summary>
        [Display(Name = "Segment8Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment8Offset, Id = Index.Segment8Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment8Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment8Length 
        /// </summary>
        [Display(Name = "Segment8Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment8Length, Id = Index.Segment8Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment8Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment8 
        /// </summary>
        [Display(Name = "ValidateSegment8", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment8, Id = Index.ValidateSegment8, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment8 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator8 
        /// </summary>
        [Display(Name = "SegmentSeparator8", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator8, Id = Index.SegmentSeparator8, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator8 { get; set; }

        /// <summary>
        /// Gets or sets Segment9 
        /// </summary>
        [Display(Name = "Segment9", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment9, Id = Index.Segment9, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment9 { get; set; }

        /// <summary>
        /// Gets or sets Segment9Offset 
        /// </summary>
        [Display(Name = "Segment9Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment9Offset, Id = Index.Segment9Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment9Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment9Length 
        /// </summary>
        [Display(Name = "Segment9Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment9Length, Id = Index.Segment9Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment9Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment9 
        /// </summary>
        [Display(Name = "ValidateSegment9", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment9, Id = Index.ValidateSegment9, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment9 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator9 
        /// </summary>
        [Display(Name = "SegmentSeparator9", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator9, Id = Index.SegmentSeparator9, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator9 { get; set; }

        /// <summary>
        /// Gets or sets Segment10 
        /// </summary>
        [Display(Name = "Segment10", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment10, Id = Index.Segment10, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment10 { get; set; }

        /// <summary>
        /// Gets or sets Segment10Offset 
        /// </summary>
        [Display(Name = "Segment10Offset", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment10Offset, Id = Index.Segment10Offset, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment10Offset { get; set; }

        /// <summary>
        /// Gets or sets Segment10Length 
        /// </summary>
        [Display(Name = "Segment10Length", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.Segment10Length, Id = Index.Segment10Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Segment10Length { get; set; }

        /// <summary>
        /// Gets or sets ValidateSegment10 
        /// </summary>
        [Display(Name = "ValidateSegment10", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.ValidateSegment10, Id = Index.ValidateSegment10, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ValidateSegment10 { get; set; }

        /// <summary>
        /// Gets or sets SegmentSeparator10 
        /// </summary>
        [Display(Name = "SegmentSeparator10", ResourceType = typeof(ItemStructuresResx))]
        [ViewField(Name = Fields.SegmentSeparator10, Id = Index.SegmentSeparator10, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentSeparator10 { get; set; }

        /// <summary>
        /// Gets Prefix Enum Value
        /// </summary>
        public string PrefixEnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(Prefix)); }
        }

        /// <summary>
        /// Gets SegmentSeparator1 Enum Value
        /// </summary>
        public string SegmentSeparator1EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator1)); }
        }

        /// <summary>
        /// Gets SegmentSeparator2 Enum Value
        /// </summary>
        public string SegmentSeparator2EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator2)); }
        }

        /// <summary>
        /// Gets SegmentSeparator3 Enum Value
        /// </summary>
        public string SegmentSeparator3EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator3)); }
        }
        /// <summary>
        /// Gets SegmentSeparator4 Enum Value
        /// </summary>
        public string SegmentSeparator4EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator4)); }
        }
        /// <summary>
        /// Gets SegmentSeparator5 Enum Value
        /// </summary>
        public string SegmentSeparator5EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator5)); }
        }
        /// <summary>
        /// Gets SegmentSeparator6 Enum Value
        /// </summary>
        public string SegmentSeparator6EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator6)); }
        }
        /// <summary>
        /// Gets SegmentSeparator7 Enum Value
        /// </summary>
        public string SegmentSeparator7EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator7)); }
        }
        /// <summary>
        /// Gets SegmentSeparator8 Enum Value
        /// </summary>
        public string SegmentSeparator8EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator8)); }
        }
        /// <summary>
        /// Gets SegmentSeparator9 Enum Value
        /// </summary>
        public string SegmentSeparator9EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator9)); }
        }
        /// <summary>
        /// Gets SegmentSeparator10 Enum Value
        /// </summary>
        public string SegmentSeparator10EnumValue
        {
            get { return EnumUtility.GetStringValue((Prefix)Convert.ToInt32(SegmentSeparator10)); }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment1", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment1String
        {
            get
            {
                if (ValidateSegment1)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment2", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment2String
        {
            get
            {
                if (ValidateSegment2)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment3", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment3String
        {
            get
            {
                if (ValidateSegment3)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment4", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment4String
        {
            get
            {
                if (ValidateSegment4)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment5", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment5String
        {
            get
            {
                if (ValidateSegment5)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment6", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment6String
        {
            get
            {
                if (ValidateSegment6)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment7", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment7String
        {
            get
            {
                if (ValidateSegment7)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment8", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment8String
        {
            get
            {
                if (ValidateSegment8)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment9", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment9String
        {
            get
            {
                if (ValidateSegment9)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
        /// <summary>
        /// Checkbox : Get terms override 
        /// </summary>
        [Display(Name = "ValidateSegment10", ResourceType = typeof(ItemStructuresResx))]
        public string ValidateSegment10String
        {
            get
            {
                if (ValidateSegment10)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                return EnumUtility.GetStringValue(BooleanType.False);

            }
        }
    }
}
