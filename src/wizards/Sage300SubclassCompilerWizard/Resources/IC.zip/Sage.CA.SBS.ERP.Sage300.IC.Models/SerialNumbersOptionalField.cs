﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class SerialNumbersOptionalField : ModelBase
    {
    }
}
