// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Usings

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class ItemUnitOfMeasure : ModelBase
    {

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(UnitsOfMeasureResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Conversion 
        /// </summary>
        [Display(Name = "Conversion", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.Conversion, Id = Index.Conversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Conversion { get; set; }

        /// <summary>
        /// Gets or sets Factor 
        /// </summary>
        [Display(Name = "Factor", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.Factor, Id = Index.Factor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Factor { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets StockingUnitOfMeasure 
        /// </summary>
        public Validate StockingUnitOfMeasure { get; set; }

        /// <summary>
        /// To get the string value of the TaxIncluded property
        /// </summary>
        public string StockingUnitOfMeasureString
        {
            get { return EnumUtility.GetStringValue(StockingUnitOfMeasure); }
        }

    }
}
