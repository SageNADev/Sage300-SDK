// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class VendorItemNumber : ModelBase
    {
        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorType 
        /// </summary>
        [Key]
        [Display(Name = "VendorType", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.VendorType, Id = Index.VendorType, FieldType = EntityFieldType.Int, Size = 2)]
        public VendorType VendorType { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets VendorItemId 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorItemNumber", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.VendorItemId, Id = Index.VendorItemId, FieldType = EntityFieldType.Char, Size = 24)]
        public string VendorItemId { get; set; }

        /// <summary>
        /// Gets or sets VendorContact 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorContact", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.VendorContact, Id = Index.VendorContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorContact { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorCurrency", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.VendorCurrency, Id = Index.VendorCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string VendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets VendorCost 
        /// </summary>
        [Display(Name = "VendorCost", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.VendorCost, Id = Index.VendorCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal VendorCost { get; set; }

        /// <summary>
        /// Gets or sets VendorExists 
        /// </summary>
        [Display(Name = "VendorExists", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool VendorExists { get; set; }

        /// <summary>
        /// Gets or sets CostUnitConvFactor 
        /// </summary>
        [Display(Name = "CostUnitConversionFactor", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.CostUnitConvFactor, Id = Index.CostUnitConvFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CostUnitConvFactor { get; set; }

        /// <summary>
        /// Gets or sets CostUnit 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostUnit", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.CostUnit, Id = Index.CostUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string CostUnit { get; set; }

        /// <summary>
        /// Gets or sets OrderMinimumSia 
        /// </summary>
        [Display(Name = "OrderMinimumSIA", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.OrderMinimumSia, Id = Index.OrderMinimumSia, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OrderMinimumSia { get; set; }

        /// <summary>
        /// Gets or sets PreferredVendorSia 
        /// </summary>
        [Display(Name = "PreferredVendorSIA", ResourceType = typeof(VendorDetailsResx))]
        [ViewField(Name = Fields.PreferredVendorSia, Id = Index.PreferredVendorSia, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem PreferredVendorSia { get; set; }

       
        #region Properties for finder

        /// <summary>
        /// Gets the VendorType string
        /// </summary>
        public string VendorTypeString
        {
            get { return EnumUtility.GetStringValue(VendorType); }
        }

        /// <summary>
        /// Gets VendorExists String
        /// </summary>
        public string VendorExistsString
        {
            get
            {
                if (VendorExists == false)
                {
                    return EnumUtility.GetStringValue(BooleanType.False);
                }
                return EnumUtility.GetStringValue(BooleanType.True);
            }
        }

        /// <summary>
        /// Gets the PreferredVendorSia string
        /// </summary>
        public string PreferredVendorSiaString
        {
            get { return EnumUtility.GetStringValue(PreferredVendorSia); }
        }

        #endregion

    }
}
