// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for RecallReleaseDetail
    /// </summary>
    public partial class LotRecallReleaseDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Display(Name = "DetailLineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailLineNumber { get; set; }

        #region UI Strings

        #endregion
    }
}
