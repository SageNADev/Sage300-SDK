// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ManufacturersItem
    /// </summary>
    public partial class ManufacturersItem : ModelBase
    {
        /// <summary>
        /// Gets or Sets Serial Number
        /// </summary>
        /// <value>The serial number</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemDescription", ResourceType = typeof(ManufacturersItemResx))]
        [ViewField(Name = Fields.ManufacturersItemDescription, Id = Index.ManufacturersItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ManufacturersItemDescription { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitsOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets FormattedItemNumber
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FormattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ForWMS
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ForWMS", ResourceType = typeof(ManufacturersItemResx))]
        [ViewField(Name = Fields.ForWMS, Id = Index.ForWMS, FieldType = EntityFieldType.Char, Size = 80)]
        public string ForWMS { get; set; }

        /// <summary>
        /// Gets or sets CheckItemExistence
        /// </summary>
        [Display(Name = "CheckItemExistence", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
        public CheckItemExistence CheckItemExistence { get; set; }

        /// <summary>
        /// Gets CheckItemExistenceString
        /// </summary>
        public string CheckItemExistenceString
        {
            get { return EnumUtility.GetStringValue(CheckItemExistence); }
        }

    }
}
