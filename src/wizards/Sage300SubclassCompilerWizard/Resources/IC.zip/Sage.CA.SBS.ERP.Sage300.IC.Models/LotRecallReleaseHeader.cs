// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for RecallReleaseHeader
    /// </summary>
    public partial class LotRecallReleaseHeader : ModelBase
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="OptionalFieldHeader" /> class.
        /// </summary>
        public LotRecallReleaseHeader()
        {
            RecallReleaseDetail = new EnumerableResponse<LotRecallReleaseDetail>();
        }

        /// <summary>
        /// Gets or sets OptFields
        /// </summary>
        /// <value>The optional fields.</value>
        public EnumerableResponse<LotRecallReleaseDetail> RecallReleaseDetail { get; set; }

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LotNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryType
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public EntryTypeLotRecall EntryType { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets RecallNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecallNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.RecallNumber, Id = Index.RecallNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string RecallNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets NextDetailLineNumber
        /// </summary>
        [Display(Name = "NextDetailLineNumber", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.NextDetailLineNumber, Id = Index.NextDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordPrinted
        /// </summary>
        [Display(Name = "RecordPrinted", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.RecordPrinted, Id = Index.RecordPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordPrinted RecordPrinted { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets EntryType string value
        /// </summary>
        public string EntryTypeString
        {
            get { return EnumUtility.GetStringValue(EntryType); }
        }

        /// <summary>
        /// Gets RecordPrinted string value
        /// </summary>
        public string RecordPrintedString
        {
            get { return EnumUtility.GetStringValue(RecordPrinted); }
        }

        #endregion
    }
}
