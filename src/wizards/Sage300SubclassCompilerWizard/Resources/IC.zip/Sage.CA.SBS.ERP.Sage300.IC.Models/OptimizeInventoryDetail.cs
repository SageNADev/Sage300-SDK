// Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>IC0306 calculated Optimize Inventory result.</summary>
    public partial class OptimizeInventoryDetail : ModelBase
    {
        [Key, StringLength(8)]
        [ViewField(Name = Fields.RunId, Id = Index.RunId, FieldType = EntityFieldType.Char, Size = 8)]
        public string RunId { get; set; }

        [Key, StringLength(24)]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        [Key, StringLength(6)]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FormattedItemNumber { get; set; }
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6)]
        public string Category { get; set; }
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6)]
        public string AccountSet { get; set; }
        [ViewField(Name = Fields.StockingUnit, Id = Index.StockingUnit, FieldType = EntityFieldType.Char, Size = 10)]
        public string StockingUnit { get; set; }
        [ViewField(Name = Fields.MostRecentCost, Id = Index.MostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal MostRecentCost { get; set; }
        [ViewField(Name = Fields.Seasonal, Id = Index.Seasonal, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Seasonal { get; set; }
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string VendorNumber { get; set; }
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }
        [ViewField(Name = Fields.VendorItemNumber, Id = Index.VendorItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string VendorItemNumber { get; set; }
        [ViewField(Name = Fields.VendorCost, Id = Index.VendorCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal VendorCost { get; set; }
        [ViewField(Name = Fields.MinimumOrderQuantity, Id = Index.MinimumOrderQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal MinimumOrderQuantity { get; set; }
        [ViewField(Name = Fields.QuantityOnHand, Id = Index.QuantityOnHand, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOnHand { get; set; }
        [ViewField(Name = Fields.QuantityOnPurchaseOrder, Id = Index.QuantityOnPurchaseOrder, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOnPurchaseOrder { get; set; }
        [ViewField(Name = Fields.QuantityOnSalesOrder, Id = Index.QuantityOnSalesOrder, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOnSalesOrder { get; set; }
        [ViewField(Name = Fields.QuantityAvailable, Id = Index.QuantityAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityAvailable { get; set; }
        [ViewField(Name = Fields.UnitsShipped, Id = Index.UnitsShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitsShipped { get; set; }
        [ViewField(Name = Fields.LastReceiptDate, Id = Index.LastReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastReceiptDate { get; set; }
        [ViewField(Name = Fields.LeadTime, Id = Index.LeadTime, FieldType = EntityFieldType.Int, Size = 2)]
        public int LeadTime { get; set; }
        [ViewField(Name = Fields.MinimumRequiredQuantity, Id = Index.MinimumRequiredQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal MinimumRequiredQuantity { get; set; }

        [ViewField(Name = Fields.SalesPeriod01, Id = Index.SalesPeriod01, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod01 { get; set; }
        [ViewField(Name = Fields.SalesPeriod02, Id = Index.SalesPeriod02, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod02 { get; set; }
        [ViewField(Name = Fields.SalesPeriod03, Id = Index.SalesPeriod03, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod03 { get; set; }
        [ViewField(Name = Fields.SalesPeriod04, Id = Index.SalesPeriod04, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod04 { get; set; }
        [ViewField(Name = Fields.SalesPeriod05, Id = Index.SalesPeriod05, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod05 { get; set; }
        [ViewField(Name = Fields.SalesPeriod06, Id = Index.SalesPeriod06, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod06 { get; set; }
        [ViewField(Name = Fields.SalesPeriod07, Id = Index.SalesPeriod07, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod07 { get; set; }
        [ViewField(Name = Fields.SalesPeriod08, Id = Index.SalesPeriod08, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod08 { get; set; }
        [ViewField(Name = Fields.SalesPeriod09, Id = Index.SalesPeriod09, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod09 { get; set; }
        [ViewField(Name = Fields.SalesPeriod10, Id = Index.SalesPeriod10, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod10 { get; set; }
        [ViewField(Name = Fields.SalesPeriod11, Id = Index.SalesPeriod11, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod11 { get; set; }
        [ViewField(Name = Fields.SalesPeriod12, Id = Index.SalesPeriod12, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod12 { get; set; }
        [ViewField(Name = Fields.SalesPeriod13, Id = Index.SalesPeriod13, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesPeriod13 { get; set; }

        [ViewField(Name = Fields.WeightedAverageSales, Id = Index.WeightedAverageSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal WeightedAverageSales { get; set; }
        [ViewField(Name = Fields.SalesTrend, Id = Index.SalesTrend, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal SalesTrend { get; set; }
        [ViewField(Name = Fields.CurrentMinimumLevel, Id = Index.CurrentMinimumLevel, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal CurrentMinimumLevel { get; set; }
        [ViewField(Name = Fields.CurrentMaximumLevel, Id = Index.CurrentMaximumLevel, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal CurrentMaximumLevel { get; set; }
        [ViewField(Name = Fields.CalculatedMinimumLevel, Id = Index.CalculatedMinimumLevel, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal CalculatedMinimumLevel { get; set; }
        [ViewField(Name = Fields.CalculatedMaximumLevel, Id = Index.CalculatedMaximumLevel, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal CalculatedMaximumLevel { get; set; }
        [ViewField(Name = Fields.AdjustedMinimumLevel, Id = Index.AdjustedMinimumLevel, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal AdjustedMinimumLevel { get; set; }
        [ViewField(Name = Fields.AdjustedMaximumLevel, Id = Index.AdjustedMaximumLevel, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)] public decimal AdjustedMaximumLevel { get; set; }
        [ViewField(Name = Fields.QuantityAvailableValue, Id = Index.QuantityAvailableValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)] public decimal QuantityAvailableValue { get; set; }
        [ViewField(Name = Fields.CurrentMinimumValue, Id = Index.CurrentMinimumValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)] public decimal CurrentMinimumValue { get; set; }
        [ViewField(Name = Fields.CurrentMaximumValue, Id = Index.CurrentMaximumValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)] public decimal CurrentMaximumValue { get; set; }
        [ViewField(Name = Fields.AdjustedMinimumValue, Id = Index.AdjustedMinimumValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)] public decimal AdjustedMinimumValue { get; set; }
        [ViewField(Name = Fields.AdjustedMaximumValue, Id = Index.AdjustedMaximumValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)] public decimal AdjustedMaximumValue { get; set; }
        [ViewField(Name = Fields.MinimumValueVariance, Id = Index.MinimumValueVariance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)] public decimal MinimumValueVariance { get; set; }
        [ViewField(Name = Fields.MaximumValueVariance, Id = Index.MaximumValueVariance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)] public decimal MaximumValueVariance { get; set; }
        [ViewField(Name = Fields.Update, Id = Index.Update, FieldType = EntityFieldType.Bool, Size = 2)] public bool Update { get; set; }
    }
}
