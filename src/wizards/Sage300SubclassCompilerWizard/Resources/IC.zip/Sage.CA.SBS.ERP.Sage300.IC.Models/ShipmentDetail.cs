// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{  
    /// <summary>
    /// Partial class for ShipmentDetail
    /// </summary>
    public partial class ShipmentDetail : ModelBase
    {
        #region Constructor

        /// <summary>
        /// Shipment Details Constructor
        /// </summary>
        public ShipmentDetail()
        {
            ShipmentDetailOptionalFields = new EnumerableResponse<ShipmentDetailOptionalField>();
        }

        #endregion

        #region ShipmentDetail model properties.

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactor
        /// </summary>
        [Display(Name = "ConversionFactor", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets PriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets UnitPrice
        /// </summary>
        [Display(Name = "UnitPrice", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitPrice, Id = Index.UnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// Gets or sets ExtendedPrice
        /// </summary>
        [Display(Name = "ExtendedPrice", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.ExtendedPrice, Id = Index.ExtendedPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedPrice { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets SerialNumbers
        /// </summary>
        [Display(Name = "SerialNumbers", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialNumbers, Id = Index.SerialNumbers, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialNumbers { get; set; }

        /// <summary>
        /// Gets or sets SerialNumberUniquifier
        /// </summary>
        [Display(Name = "SerialNumberUniquifier", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.SerialNumberUniquifier, Id = Index.SerialNumberUniquifier, FieldType = EntityFieldType.Int, Size = 2)]
        public int SerialNumberUniquifier { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets PMContract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMContract", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMContract, Id = Index.PMContract, FieldType = EntityFieldType.Char, Size = 16)]
        public string PMContract { get; set; }

        /// <summary>
        /// Gets or sets PMProject
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMProject", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMProject, Id = Index.PMProject, FieldType = EntityFieldType.Char, Size = 16)]
        public string PMProject { get; set; }

        /// <summary>
        /// Gets or sets PMCategory
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMCategory", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMCategory, Id = Index.PMCategory, FieldType = EntityFieldType.Char, Size = 16)]
        public string PMCategory { get; set; }

        /// <summary>
        /// Gets or sets PMDetail
        /// </summary>
        [Display(Name = "PMDetail", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PMDetail, Id = Index.PMDetail, FieldType = EntityFieldType.Long, Size = 4)]
        public long PMDetail { get; set; }

        /// <summary>
        /// Gets or sets PMWIPAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PMWIPAccount", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.PMWIPAccount, Id = Index.PMWIPAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PMWIPAccount { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerItemNumber", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.CustomerItemNumber, Id = Index.CustomerItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string CustomerItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Display(Name = "DetailLineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets GLControlAmountShipment
        /// </summary>
        [Display(Name = "GLControlAmountShipment", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.GLControlAmountShipment, Id = Index.GLControlAmountShipment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal GLControlAmountShipment { get; set; }

        /// <summary>
        /// Gets or sets GLCostVarianceShipment
        /// </summary>
        [Display(Name = "GLCostVarianceShipment", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.GLCostVarianceShipment, Id = Index.GLCostVarianceShipment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal GLCostVarianceShipment { get; set; }

        /// <summary>
        /// Gets or sets GLControlAmountShipmentRet
        /// </summary>
        [Display(Name = "GLControlAmountShipmentRet", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.GLControlAmountShipmentRet, Id = Index.GLControlAmountShipmentRet, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal GLControlAmountShipmentRet { get; set; }

        /// <summary>
        /// Gets or sets GLCostVarianceShipmentRetu
        /// </summary>
        [Display(Name = "GLCostVarianceShipmentRetu", ResourceType = typeof(ShipmentResx))]
        [ViewField(Name = Fields.GLCostVarianceShipmentRetu, Id = Index.GLCostVarianceShipmentRetu, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal GLCostVarianceShipmentRetu { get; set; }

        /// <summary>
        /// Gets or sets NumberOfSerials
        /// </summary>
         [Display(Name = "NumberOfSerials", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.NumberOfSerials, Id = Index.NumberOfSerials, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfSerials { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Display(Name = "Function", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public int Function { get; set; }

        /// <summary>
        /// Gets or sets RevisionListLineNumber
        /// </summary>
        [Display(Name = "RevisionListLineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.RevisionListLineNumber, Id = Index.RevisionListLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int RevisionListLineNumber { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [Display(Name = "InterprocessCommID", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSN
        /// </summary>
        [Display(Name = "ForcePopupSN", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.ForcePopupSN, Id = Index.ForcePopupSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupSN { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        [Display(Name = "PopupSN", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.PopupSN, Id = Index.PopupSN, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupSN { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        [Display(Name = "CloseSN", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.CloseSN, Id = Index.CloseSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseSN { get; set; }

        /// <summary>
        /// Gets or sets LTSetID
        /// </summary>
        [Display(Name = "LTSetID", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.LTSetID, Id = Index.LTSetID, FieldType = EntityFieldType.Long, Size = 4)]
        public long LTSetID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLT
        /// </summary>
        [Display(Name = "ForcePopupLT", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.ForcePopupLT, Id = Index.ForcePopupLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupLT { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        [Display(Name = "PopupLT", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.PopupLT, Id = Index.PopupLT, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupLT { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [Display(Name = "CloseLT", ResourceType = typeof(AdjustmentResx))]
        [ViewField(Name = Fields.CloseLT, Id = Index.CloseLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseLT { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityperLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets EntryType
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public int EntryType { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        #endregion

        #region UI Strings


        [IgnoreExportImport]
        public IDictionary<string, object> DynamicDetailAttributes { get; set; }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        [IgnoreExportImport]
        public DecimalsinPrice UnitPriceDecimalsInPrice { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDetailOptionalFields
        /// </summary>
        public EnumerableResponse<ShipmentDetailOptionalField> ShipmentDetailOptionalFields { get; set; }

        /// <summary>
        /// Gets OptionalFieldString 
        /// </summary>
        [IgnoreExportImport]
        public string OptionalFieldString
        {
            get
            {
                return OptionalFields > 0 ? CommonResx.Yes : CommonResx.No;
            }
        }

        /// <summary>
        /// Gets and Sets NegativeQuantityConfirmed
        /// </summary>
        [IgnoreExportImport]
        public bool NegativeQuantityConfirmed { get; set; }
        #endregion
    }
}
