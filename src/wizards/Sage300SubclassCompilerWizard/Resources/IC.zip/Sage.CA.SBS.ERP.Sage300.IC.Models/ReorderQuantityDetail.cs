// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
using System.Threading;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ReorderQuantityDetail
    /// </summary>
    public partial class ReorderQuantityDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets PeriodStart
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodStart", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.PeriodStart, Id = Index.PeriodStart, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodStart { get; set; }

        /// <summary>
        /// Gets or sets MinimumQuantity
        /// </summary>
        [Display(Name = "MinimumQuantity", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.MinimumQuantity, Id = Index.MinimumQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal MinimumQuantity { get; set; }

        /// <summary>
        /// Gets or sets MaximumQuantity
        /// </summary>
        [Display(Name = "MaximumQuantity", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.MaximumQuantity, Id = Index.MaximumQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal MaximumQuantity { get; set; }

        /// <summary>
        /// Gets or sets ReorderQuantity
        /// </summary>
        [Display(Name = "ReorderQuantity", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.ReorderQuantity, Id = Index.ReorderQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ReorderQuantity { get; set; }

        /// <summary>
        /// Gets or sets ProjectedSalesQty
        /// </summary>
        [Display(Name = "ProjectedSalesQty", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.ProjectedSalesQty, Id = Index.ProjectedSalesQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ProjectedSalesQty { get; set; }

        /// <summary>
        /// Gets or sets PeriodEnd
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PeriodEnd", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.PeriodEnd, Id = Index.PeriodEnd, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PeriodEnd { get; set; }

        /// <summary>
        /// Gets or sets ReorderFor
        /// </summary>
        [Display(Name = "ReorderFor", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.ReorderFor, Id = Index.ReorderFor, FieldType = EntityFieldType.Int, Size = 2)]
        public ReorderFor ReorderFor { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ReorderFor string value
        /// </summary>
        [IgnoreExportImport]
        public string ReorderForString
        {
            get { return EnumUtility.GetStringValue(ReorderFor); }
        }

        /// <summary>
        ///Gets or sets SerialNumber
        /// </summary>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        /// <summary>
        ///Gets or sets Period Start
        /// </summary>
        [IgnoreExportImport]
        public string PeriodStartString
        {
            get
            {
                return String.Concat(PeriodStart.Month,Thread.CurrentThread.CurrentUICulture.DateTimeFormat.DateSeparator, PeriodStart.Day);
            }
        }

        #endregion
    }
}
