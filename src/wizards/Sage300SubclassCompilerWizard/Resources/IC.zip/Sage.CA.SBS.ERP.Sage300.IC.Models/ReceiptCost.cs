// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Partial class for ReceiptCost
     /// </summary>
     public partial class ReceiptCost : ModelBase
     {
          /// <summary>
          /// Gets or sets ItemNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ItemNumber {get; set;}

          /// <summary>
          /// Gets or sets Location
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string Location {get; set;}

          /// <summary>
          /// Gets or sets TransactionDate
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          // ReSharper disable once LocalizableElement
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime TransactionDate {get; set;}

          /// <summary>
          /// Gets or sets SequenceNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long SequenceNumber {get; set;}

          /// <summary>
          /// Gets or sets Reference
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
          public string Reference {get; set;}

          /// <summary>
          /// Gets or sets DocumentNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
          public string DocumentNumber {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int LineNumber {get; set;}

          /// <summary>
          /// Gets or sets OriginalQuantity
          /// </summary>
          [ViewField(Name = Fields.OriginalQuantity, Id = Index.OriginalQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal OriginalQuantity {get; set;}

          /// <summary>
          /// Gets or sets OriginalCost
          /// </summary>
          [ViewField(Name = Fields.OriginalCost, Id = Index.OriginalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal OriginalCost {get; set;}

          /// <summary>
          /// Gets or sets QuantityShipped
          /// </summary>
          [ViewField(Name = Fields.QuantityShipped, Id = Index.QuantityShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityShipped {get; set;}

          /// <summary>
          /// Gets or sets ShippedCost
          /// </summary>
          [ViewField(Name = Fields.ShippedCost, Id = Index.ShippedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal ShippedCost {get; set;}

          /// <summary>
          /// Gets or sets QuantityAvailable
          /// </summary>
          [ViewField(Name = Fields.QuantityAvailable, Id = Index.QuantityAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityAvailable {get; set;}

          /// <summary>
          /// Gets or sets AvailableCost
          /// </summary>
          [ViewField(Name = Fields.AvailableCost, Id = Index.AvailableCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal AvailableCost {get; set;}

          /// <summary>
          /// Gets or sets FormattedItemNumber
          /// </summary>
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
          public string FormattedItemNumber {get; set;}

          /// <summary>
          /// Gets or sets AccountSetCode
          /// </summary>
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6)]
          public string AccountSetCode {get; set;}

          /// <summary>
          /// Gets or sets AccountSetDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.AccountSetDescription, Id = Index.AccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string AccountSetDescription {get; set;}

          /// <summary>
          /// Gets or sets ItemDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string ItemDescription {get; set;}

          /// <summary>
          /// Gets or sets LocationDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string LocationDescription {get; set;}

          #region UI properties

          /// <summary>
          /// Gets or sets the OffsetQuantityAvailable
          /// </summary>
          public decimal OffsetQuantityAvailable { get; set; }

          /// <summary>
          /// Gets or sets the OffsetCost
          /// </summary>
          public decimal OffsetCost { get; set; }

          /// <summary>
          /// Gets or sets the NotCostedQuantityReceived
          /// </summary>
          public decimal QuantityReceivedNotCosted { get; set; }

          /// <summary>
          /// Gets or sets the NotCostedQuantityShipped
          /// </summary>
          public decimal QuantityShippedNotCosted { get; set; }

          /// <summary>
          /// Gets or sets the NotCostedQuantityAvailable
          /// </summary>
          public decimal QuantityAvailableNotCosted { get; set; }

          #endregion
     }
}
