// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ReorderQuantity
    /// </summary>
    public partial class ReorderQuantity : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReorderQuantity"/> class.
        /// </summary>
        public ReorderQuantity()
        {
            ReorderQuantityOptField = new EnumerableResponse<ReorderQuantityOptField>();
            ReorderQuantityDetail = new EnumerableResponse<ReorderQuantityDetail>();
        }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]        
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ReorderFor
        /// </summary>
        [Display(Name = "ReorderFor", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.ReorderFor, Id = Index.ReorderFor, FieldType = EntityFieldType.Int, Size = 2)]
        public ReorderFor ReorderFor { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumberOfDetails", ResourceType = typeof(ReorderQuantityResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets FormattedItemNumber
        /// </summary>
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FormattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets CheckItemExistence
        /// </summary>
        [Display(Name = "CheckItemExistence", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
        public CheckItemExistence CheckItemExistence { get; set; }

        /// <summary>
        /// Gets or sets ReorderQuantitiesOptField collection.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReorderQuantityOptField> ReorderQuantityOptField { get; set; }

        /// <summary>
        /// Gets or sets ReorderQuantityDetail collection.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReorderQuantityDetail> ReorderQuantityDetail { get; set; }

        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        [IgnoreExportImport]
        public bool IsNewRecord { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ReorderFor string value
        /// </summary>
        [IgnoreExportImport]
        public string ReorderForString
        {
            get { return EnumUtility.GetStringValue(ReorderFor); }
        }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets CheckItemExistence string value
        /// </summary>
        [IgnoreExportImport]
        public string CheckItemExistenceString
        {
            get { return EnumUtility.GetStringValue(CheckItemExistence); }
        }

        /// <summary>
        /// Gets or sets UnFormattedItemNumber
        /// </summary>
        [IgnoreExportImport]
        public string UnFormattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets IsOptinalFieldLoaded
        /// </summary>
        [IgnoreExportImport]
        public bool IsOptinalFieldLoaded { get; set; }

        #endregion
    }
}
