// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for LotNumberHistory
    /// </summary>
    public partial class LotNumberHistory : ModelBase
    {
        /// <summary>
        /// Gets or sets UnformattedLotNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedLotNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.UnformattedLotNumber, Id = Index.UnformattedLotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string UnformattedLotNumber { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DayEndNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DayEndNumber, Id = Index.DayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionSequence", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.TransactionSequence, Id = Index.TransactionSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionSequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ComponentNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2)]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public LotNumberHistoryTransType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets TransactionQuantity
        /// </summary>
        [Display(Name = "TransactionQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TransactionQuantity { get; set; }

        /// <summary>
        /// Gets or sets TransactionUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionUnitOfMeasure", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.TransactionUnitOfMeasure, Id = Index.TransactionUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string TransactionUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets TransactionconversionFactor
        /// </summary>
        [Display(Name = "TransactionconversionFactor", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.TransactionconversionFactor, Id = Index.TransactionconversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal TransactionconversionFactor { get; set; }

        /// <summary>
        /// Gets or sets StockQuantity
        /// </summary>
        [Display(Name = "StockQuantity", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.StockQuantity, Id = Index.StockQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal StockQuantity { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets WarrantyCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WARRANTYCODE", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyCode, Id = Index.WarrantyCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string WarrantyCode { get; set; }

        /// <summary>
        /// Gets or sets CustomerVendorNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerVendorNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.CustomerVendorNumber, Id = Index.CustomerVendorNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets Recalled
        /// </summary>
        [Display(Name = "Recalled", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.Recalled, Id = Index.Recalled, FieldType = EntityFieldType.Bool, Size = 2)]
        public Recalled Recalled { get; set; }

        /// <summary>
        /// Gets or sets DateRecalled
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateRecalled", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.DateRecalled, Id = Index.DateRecalled, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateRecalled { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod1IsInUse
        /// </summary>
        [Display(Name = "WarrantyPeriod1IsInUse", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod1IsInUse, Id = Index.WarrantyPeriod1IsInUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod1IsInUse { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod1ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DAYS1", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod1ExpiryDate, Id = Index.WarrantyPeriod1ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod1ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod1EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EffectDAYS1", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod1EffectiveDate, Id = Index.WarrantyPeriod1EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod1EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod1Lifetime
        /// </summary>
        [Display(Name = "LIFEWARR1", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod1Lifetime, Id = Index.WarrantyPeriod1Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod1Lifetime { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod2IsInUse
        /// </summary>
        [Display(Name = "WarrantyPeriod2IsInUse", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod2IsInUse, Id = Index.WarrantyPeriod2IsInUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod2IsInUse { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod2ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DAYS2", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod2ExpiryDate, Id = Index.WarrantyPeriod2ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod2ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod2EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EffectDAYS2", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod2EffectiveDate, Id = Index.WarrantyPeriod2EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod2EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod2Lifetime
        /// </summary>
        [Display(Name = "LIFEWARR2", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod2Lifetime, Id = Index.WarrantyPeriod2Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod2Lifetime { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod3IsInUse
        /// </summary>
        [Display(Name = "WarrantyPeriod3IsInUse", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod3IsInUse, Id = Index.WarrantyPeriod3IsInUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod3IsInUse { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod3ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DAYS3", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod3ExpiryDate, Id = Index.WarrantyPeriod3ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod3ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod3EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EffectDAYS3", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod3EffectiveDate, Id = Index.WarrantyPeriod3EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod3EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod3Lifetime
        /// </summary>
        [Display(Name = "LIFEWARR3", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod3Lifetime, Id = Index.WarrantyPeriod3Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod3Lifetime { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod4IsInUse
        /// </summary>
        [Display(Name = "WarrantyPeriod4IsInUse", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod4IsInUse, Id = Index.WarrantyPeriod4IsInUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod4IsInUse { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod4ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DAYS4", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod4ExpiryDate, Id = Index.WarrantyPeriod4ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod4ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod4EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EffectDAYS4", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod4EffectiveDate, Id = Index.WarrantyPeriod4EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod4EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod4Lifetime
        /// </summary>
        [Display(Name = "LIFEWARR4", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod4Lifetime, Id = Index.WarrantyPeriod4Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod4Lifetime { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod5IsInUse
        /// </summary>
        [Display(Name = "WarrantyPeriod5IsInUse", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod5IsInUse, Id = Index.WarrantyPeriod5IsInUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod5IsInUse { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod5ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DAYS5", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod5ExpiryDate, Id = Index.WarrantyPeriod5ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod5ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod5EffectiveDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EffectDAYS5", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod5EffectiveDate, Id = Index.WarrantyPeriod5EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime WarrantyPeriod5EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod5Lifetime
        /// </summary>
        [Display(Name = "LIFEWARR5", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod5Lifetime, Id = Index.WarrantyPeriod5Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank WarrantyPeriod5Lifetime { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType
        /// </summary>
        [Display(Name = "DrillDownType", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber
        /// </summary>
        [Display(Name = "DrillDownLinkNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets WarrantyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WARRANTYDESC", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyDescription, Id = Index.WarrantyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string WarrantyDescription { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WarrantyPeriod1Description", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod1Description, Id = Index.WarrantyPeriod1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string WarrantyPeriod1Description { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WarrantyPeriod2Description", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod2Description, Id = Index.WarrantyPeriod2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string WarrantyPeriod2Description { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WarrantyPeriod3Description", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod3Description, Id = Index.WarrantyPeriod3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string WarrantyPeriod3Description { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WarrantyPeriod4Description", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod4Description, Id = Index.WarrantyPeriod4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string WarrantyPeriod4Description { get; set; }

        /// <summary>
        /// Gets or sets WarrantyPeriod5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WarrantyPeriod5Description", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.WarrantyPeriod5Description, Id = Index.WarrantyPeriod5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string WarrantyPeriod5Description { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public LotNumberHistoryStatus Status { get; set; }

        /// <summary>
        /// Gets or sets OEInvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OEInvoiceNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.OEInvoiceNumber, Id = Index.OEInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string OEInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets POInvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "POInvoiceNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.POInvoiceNumber, Id = Index.POInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string POInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets POCreditNoteNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "POCreditNoteNumber", ResourceType = typeof(LotNumberResx))]
        [ViewField(Name = Fields.POCreditNoteNumber, Id = Index.POCreditNoteNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string POCreditNoteNumber { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Gets Recalled string value
        /// </summary>
        public string RecalledString
        {
            get { return EnumUtility.GetStringValue(Recalled); }
        }

        /// <summary>
        /// Gets WarrantyPeriod1IsInUse string value
        /// </summary>
        public string WarrantyPeriod1IsInUseString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod1IsInUse); }
        }

        /// <summary>
        /// Gets WarrantyPeriod1Lifetime string value
        /// </summary>
        public string WarrantyPeriod1LifetimeString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod1Lifetime); }
        }

        /// <summary>
        /// Gets WarrantyPeriod2IsInUse string value
        /// </summary>
        public string WarrantyPeriod2IsInUseString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod2IsInUse); }
        }

        /// <summary>
        /// Gets WarrantyPeriod2Lifetime string value
        /// </summary>
        public string WarrantyPeriod2LifetimeString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod2Lifetime); }
        }

        /// <summary>
        /// Gets WarrantyPeriod3IsInUse string value
        /// </summary>
        public string WarrantyPeriod3IsInUseString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod3IsInUse); }
        }

        /// <summary>
        /// Gets WarrantyPeriod3Lifetime string value
        /// </summary>
        public string WarrantyPeriod3LifetimeString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod3Lifetime); }
        }

        /// <summary>
        /// Gets WarrantyPeriod4IsInUse string value
        /// </summary>
        public string WarrantyPeriod4IsInUseString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod4IsInUse); }
        }

        /// <summary>
        /// Gets WarrantyPeriod4Lifetime string value
        /// </summary>
        public string WarrantyPeriod4LifetimeString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod4Lifetime); }
        }

        /// <summary>
        /// Gets WarrantyPeriod5IsInUse string value
        /// </summary>
        public string WarrantyPeriod5IsInUseString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod5IsInUse); }
        }

        /// <summary>
        /// Gets WarrantyPeriod5Lifetime string value
        /// </summary>
        public string WarrantyPeriod5LifetimeString
        {
            get { return EnumUtility.GetStringValue(WarrantyPeriod5Lifetime); }
        }

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Get or Set CustomerNumber and Name
        /// </summary>
        [IgnoreExportImport]
        public string CustomerNumberAndName { get; set; }

        /// <summary>
        /// Get or Set VendorNumber and Name
        /// </summary>
        [IgnoreExportImport]
        public string VendorNumberAndName { get; set; }

        #endregion
    }
}
