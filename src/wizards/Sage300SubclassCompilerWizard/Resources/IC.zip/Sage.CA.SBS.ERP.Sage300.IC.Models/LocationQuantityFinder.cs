// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Status = Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Status;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for LocationQuantitie
	/// </summary>
	public partial class LocationQuantityFinder : ModelBase
	{
		
		/// <summary>
		/// Gets or sets ITEMNO
		/// </summary>
		[Key]
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        public string ItemNumber { get; set; }

		
		/// <summary>
		/// Gets or sets LOCATION
		/// </summary>
		[Key]
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LOCATION, Id = Index.LOCATION, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string LOCATION { get; set; }

		/// <summary>
		/// Gets or sets LOCATION2
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
		//[Display(Name = "Generated", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.LOCATION2, Id = Index.LOCATION2, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string LOCATION2 { get; set; }


	    /// <summary>
	    /// Gets or sets DESC
	    /// </summary>
	    [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]

	    [Display(Name = "Name", ResourceType = typeof (ICCommonResx))]
	    [ViewField(Name = Fields.DESC, Id = Index.DESC, FieldType = EntityFieldType.Char, Size = 60)]
	    public string DESC { get; set; }

	    /// <summary>
		/// Gets or sets AddressLine1
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
		public string AddressLine1 { get; set; }

		/// <summary>
		/// Gets or sets AddressLine2
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
		public string AddressLine2 { get; set; }

		/// <summary>
		/// Gets or sets AddressLine3
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
		public string AddressLine3 { get; set; }

		/// <summary>
		/// Gets or sets AddressLine4
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
		public string AddressLine4 { get; set; }

		/// <summary>
		/// Gets or sets City
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
	   [Display(Name = "Generated", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
		public string City { get; set; }

		/// <summary>
		/// Gets or sets State
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Char, Size = 30)]
		public string State { get; set; }

		/// <summary>
		/// Gets or sets ZipPostalCode
		/// </summary>
		[StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZIPPostal", ResourceType = typeof(CommonResx))]
		[ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20C")]
		public string ZipPostalCode { get; set; }

		/// <summary>
		/// Gets or sets Country
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
		public string Country { get; set; }

		/// <summary>
		/// Gets or sets PhoneNumber
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PhoneNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string PhoneNumber { get; set; }

		/// <summary>
		/// Gets or sets FaxNumber
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FaxNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string FaxNumber { get; set; }

		/// <summary>
		/// Gets or sets Contact
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
		public string Contact { get; set; }

		/// <summary>
		/// Gets or sets SegmentOverride
		/// </summary> 
         [Display(Name = "SegmentOverride", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentOverride, Id = Index.SegmentOverride, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool SegmentOverride { get; set; }

		/// <summary>
		/// Gets or sets DateLastMaintained
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastMaintained", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateLastMaintained { get; set; }

		/// <summary>
		/// Gets or sets Status
		/// </summary> 
         [Display(Name = "Status", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
		public Status Status { get; set; }

		/// <summary>
		/// Gets or sets DateInactive
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateInactive", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateInactive { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber1
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]

        [Display(Name = "SegmentNumber1", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber1, Id = Index.SegmentNumber1, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber1 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue1
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]

        [Display(Name = "SegmentValue1", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue1, Id = Index.SegmentValue1, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue1 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber2
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]



        [Display(Name = "SegmentNumber2", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber2, Id = Index.SegmentNumber2, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber2 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue2
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]



        [Display(Name = "SegmentValue2", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue2, Id = Index.SegmentValue2, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue2 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber3
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]



        [Display(Name = "SegmentNumber3", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber3, Id = Index.SegmentNumber3, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber3 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue3
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentValue3", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue3, Id = Index.SegmentValue3, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue3 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber4
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentNumber4", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber4, Id = Index.SegmentNumber4, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber4 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue4
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentValue4", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue4, Id = Index.SegmentValue4, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue4 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber5
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentNumber5", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber5, Id = Index.SegmentNumber5, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber5 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue5
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]  
        [Display(Name = "SegmentValue5", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue5, Id = Index.SegmentValue5, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue5 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber6
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber6", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber6, Id = Index.SegmentNumber6, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber6 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue6
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentValue6", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue6, Id = Index.SegmentValue6, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue6 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber7
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentNumber7", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber7, Id = Index.SegmentNumber7, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber7 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue7
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentValue7", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue7, Id = Index.SegmentValue7, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue7 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber8
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentNumber8", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber8, Id = Index.SegmentNumber8, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber8 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue8
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SegmentValue8", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue8, Id = Index.SegmentValue8, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue8 { get; set; }

		/// <summary>
		/// Gets or sets SegmentNumber9
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentNumber9", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentNumber9, Id = Index.SegmentNumber9, FieldType = EntityFieldType.Char, Size = 6)]
		public string SegmentNumber9 { get; set; }

		/// <summary>
		/// Gets or sets SegmentValue9
		/// </summary>
		[StringLength(15, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        [Display(Name = "SegmentValue9", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.SegmentValue9, Id = Index.SegmentValue9, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
		public string SegmentValue9 { get; set; }

		/// <summary>
		/// Gets or sets LocationEmail
		/// </summary>
		[StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]  
        [Display(Name = "LocationEmail", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.LocationEmail, Id = Index.LocationEmail, FieldType = EntityFieldType.Char, Size = 50)]
		public string LocationEmail { get; set; }

		/// <summary>
		/// Gets or sets ContactPhone
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactPhone", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string ContactPhone { get; set; }

		/// <summary>
		/// Gets or sets ContactFax
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactFax", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string ContactFax { get; set; }

		/// <summary>
		/// Gets or sets ContactEmail
		/// </summary>
		[StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactEmail", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
		public string ContactEmail { get; set; }

		/// <summary>
		/// Gets or sets LocationType
		/// </summary>
        [Display(Name = "LocType", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.LocationType, Id = Index.LocationType, FieldType = EntityFieldType.Int, Size = 2)]
		public LocationType LocationType { get; set; }
		/// <summary>
		/// Gets or sets ITEMNO2
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		//[Display(Name = "Generated", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.ITEMNO2, Id = Index.ITEMNO2, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ITEMNO2 { get; set; }

		/// <summary>
		/// Gets or sets LOCATION3
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		//[Display(Name = "Generated", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.LOCATION3, Id = Index.LOCATION3, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string LOCATION3 { get; set; }

		/// <summary>
		/// Gets or sets PickingSequence
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PickingSequence", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
		public string PickingSequence { get; set; }

		/// <summary>
		/// Gets or sets Allowed
		/// </summary> 
        [Display(Name = "Allowed", ResourceType = typeof(LocationsResx))]
		[ViewField(Name = Fields.Allowed, Id = Index.Allowed, FieldType = EntityFieldType.Bool, Size = 2)]
		public Allowed Allowed { get; set; }

		/// <summary>
		/// Gets or sets DateLocationActivated
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLocationActivated", ResourceType = typeof(LocationDetailsResx))]
		[ViewField(Name = Fields.DateLocationActivated, Id = Index.DateLocationActivated, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateLocationActivated { get; set; }

		/// <summary>
		/// Gets or sets InUse
		/// </summary> 
        [Display(Name = "InUse", ResourceType = typeof(LocationDetailsResx))]
		[ViewField(Name = Fields.InUse, Id = Index.InUse, FieldType = EntityFieldType.Bool, Size = 2)]
		public InUse InUse { get; set; }

		/// <summary>
		/// Gets or sets DateLastUsed
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastUsed", ResourceType = typeof(LocationDetailsResx))]
		[ViewField(Name = Fields.DateLastUsed, Id = Index.DateLastUsed, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateLastUsed { get; set; }

		/// <summary>
		/// Gets or sets QuantityonHandLastDayEnd
		/// </summary> 
        [Display(Name = "QuantityonHandLastDayEnd", ResourceType = typeof(LocationDetailsResx))]
		[ViewField(Name = Fields.QuantityonHandLastDayEnd, Id = Index.QuantityonHandLastDayEnd, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityonHandLastDayEnd { get; set; }

		/// <summary>
		/// Gets or sets QuantityonPO
		/// </summary> 
        [Display(Name = "QuantityonPO", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityonPO, Id = Index.QuantityonPO, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityonPO { get; set; }

	    /// <summary>
	    /// Gets or sets QuantityonSO
	    /// </summary> 
	    [Display(Name = "QuantityonSO", ResourceType = typeof(ICCommonResx))]
	    [ViewField(Name = Fields.QuantityonSO, Id = Index.QuantityonSO, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
	    public decimal QuantityonSO { get; set; }

	    /// <summary>
		/// Gets or sets QuantityNotInCostFile
		/// </summary>
        [Display(Name = "QuantityNotInCostFile", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityNotInCostFile, Id = Index.QuantityNotInCostFile, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityNotInCostFile { get; set; }

		/// <summary>
		/// Gets or sets QuantityShippedNotCosted
		/// </summary>
        [Display(Name = "QuantityShippedNotCosted", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityShippedNotCosted, Id = Index.QuantityShippedNotCosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityShippedNotCosted { get; set; }

		/// <summary>
		/// Gets or sets QuantityReceivedNotCosted
		/// </summary>
        [Display(Name = "QuantityReceivedNotCosted", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityReceivedNotCosted, Id = Index.QuantityReceivedNotCosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityReceivedNotCosted { get; set; }

		/// <summary>
		/// Gets or sets QuantityAdjustedNotCosted
		/// </summary>
        [Display(Name = "QuantityAdjustedNotCosted", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityAdjustedNotCosted, Id = Index.QuantityAdjustedNotCosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityAdjustedNotCosted { get; set; }

		/// <summary>
		/// Gets or sets NumberOfUncostedTransactions
		/// </summary> 
        [Display(Name = "NumberOfUncostedTransactions", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.NumberOfUncostedTransactions, Id = Index.NumberOfUncostedTransactions, FieldType = EntityFieldType.Long, Size = 4)]
		public long NumberOfUncostedTransactions { get; set; }

		/// <summary>
		/// Gets or sets TotalCost
		/// </summary> 
        [Display(Name = "TotalCost", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.TotalCost, Id = Index.TotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal TotalCost { get; set; }

		/// <summary>
		/// Gets or sets CostNotInCostFile
		/// </summary> 
        [Display(Name = "CostNotInCostFile", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CostNotInCostFile, Id = Index.CostNotInCostFile, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal CostNotInCostFile { get; set; }

		/// <summary>
		/// Gets or sets CostUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]

        [Display(Name = "CostUnitOfMeasure", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CostUnitOfMeasure, Id = Index.CostUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
		public string CostUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets CostUnitConversionFactor
		/// </summary>  
        [Display(Name = "CostUnitConversionFactor", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CostUnitConversionFactor, Id = Index.CostUnitConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal CostUnitConversionFactor { get; set; }

		/// <summary>
		/// Gets or sets StandardCost
		/// </summary> 
        [Display(Name = "StandardCost", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.StandardCost, Id = Index.StandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal StandardCost { get; set; }

		/// <summary>
		/// Gets or sets LastStandardCost
		/// </summary> 
        [Display(Name = "LastStandardCost", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LastStandardCost, Id = Index.LastStandardCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal LastStandardCost { get; set; }

		/// <summary>
		/// Gets or sets LastStandardCostDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastStandardCostDate", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LastStandardCostDate, Id = Index.LastStandardCostDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime LastStandardCostDate { get; set; }

		/// <summary>
		/// Gets or sets LastShipmentDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [Display(Name = "LastShipmentDate", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LastShipmentDate, Id = Index.LastShipmentDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime LastShipmentDate { get; set; }

		/// <summary>
		/// Gets or sets AverageDaysToShip
		/// </summary> 
        [Display(Name = "AverageDaysToShip", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AverageDaysToShip, Id = Index.AverageDaysToShip, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal AverageDaysToShip { get; set; }

		/// <summary>
		/// Gets or sets AverageUnitsShipped
		/// </summary>  
        [Display(Name = "AverageUnitsShipped", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AverageUnitsShipped, Id = Index.AverageUnitsShipped, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal AverageUnitsShipped { get; set; }

		/// <summary>
		/// Gets or sets ShipmentsUsedInCalculation
		/// </summary> 
        [Display(Name = "ShipmentsUsedInCalculation", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ShipmentsUsedInCalculation, Id = Index.ShipmentsUsedInCalculation, FieldType = EntityFieldType.Int, Size = 2)]
		public int ShipmentsUsedInCalculation { get; set; }

		/// <summary>
		/// Gets or sets LastReceiptDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastReceiptDate", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LastReceiptDate, Id = Index.LastReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime LastReceiptDate { get; set; }

		/// <summary>
		/// Gets or sets MostRecentCost
		/// </summary>
        [Display(Name = "MostRecentCost", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.MostRecentCost, Id = Index.MostRecentCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal MostRecentCost { get; set; }

		/// <summary>
		/// Gets or sets UserDefinedCost1
		/// </summary>
        [Display(Name = "UserDefinedCost1", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.UserDefinedCost1, Id = Index.UserDefinedCost1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UserDefinedCost1 { get; set; }

		/// <summary>
		/// Gets or sets UserDefinedCost2
		/// </summary>
        [Display(Name = "UserDefinedCost2", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.UserDefinedCost2, Id = Index.UserDefinedCost2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UserDefinedCost2 { get; set; }

		/// <summary>
		/// Gets or sets LastUnitCost
		/// </summary>
        [Display(Name = "LastUnitCost", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LastUnitCost, Id = Index.LastUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal LastUnitCost { get; set; }

		/// <summary>
		/// Gets or sets QuantityCommitted
		/// </summary>
        [Display(Name = "QuantityCommitted", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityCommitted, Id = Index.QuantityCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityCommitted { get; set; }

		/// <summary>
		/// Gets or sets LastAllocatedSerial
		/// </summary>
		[StringLength(70, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastAllocatedSerial", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LastAllocatedSerial, Id = Index.LastAllocatedSerial, FieldType = EntityFieldType.Char, Size = 70)]
		public string LastAllocatedSerial { get; set; }

		/// <summary>
		/// Gets or sets LastAllocatedLot
		/// </summary>
		[StringLength(70, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastAllocatedLot", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LastAllocatedLot, Id = Index.LastAllocatedLot, FieldType = EntityFieldType.Char, Size = 70)]
		public string LastAllocatedLot { get; set; }

		/// <summary>
		/// Gets or sets LeadTimeSIA
		/// </summary>
       // [Display(Name = "LeadTimeSIA", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.LeadTimeSIA, Id = Index.LeadTimeSIA, FieldType = EntityFieldType.Int, Size = 2)]
		public int LeadTimeSIA { get; set; }

		/// <summary>
		/// Gets or sets InventoryMinimumSIA
		/// </summary>
       // [Display(Name = "InventoryMinimumSIA", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.InventoryMinimumSIA, Id = Index.InventoryMinimumSIA, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal InventoryMinimumSIA { get; set; }

		/// <summary>
		/// Gets or sets QuantityAvailableToShip
		/// </summary>
        [Display(Name = "QuantityAvailableToShip", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityAvailableToShip, Id = Index.QuantityAvailableToShip, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityAvailableToShip { get; set; }

		/// <summary>
		/// Gets or sets AccountSetCode
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string AccountSetCode { get; set; }

		/// <summary>
		/// Gets or sets QuantityonHand
		/// </summary>
        [Display(Name = "QuantityonHand", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QuantityonHand, Id = Index.QuantityonHand, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityonHand { get; set; }

		/// <summary>
		/// Gets or sets AverageCost
		/// </summary>
        [Display(Name = "AverageCost", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.AverageCost, Id = Index.AverageCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal AverageCost { get; set; }

		/// <summary>
		/// Gets or sets CostingMethod
		/// </summary>
        [Display(Name = "CostingMethod", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CostingMethod, Id = Index.CostingMethod, FieldType = EntityFieldType.Int, Size = 2)]
		public CostingMethod CostingMethod { get; set; }

		
		/// <summary>
		/// Gets or sets LOCDESC
		/// </summary>
		//[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		//[Display(Name = "LOCDESC", ResourceType = typeof (ICCommonResx))]
		//[ViewField(Name = Fields.LOCDESC, Id = Index.LOCDESC, FieldType = EntityFieldType.Char, Size = 60)]
		//public string LOCDESC { get; set; }

		/// <summary>
		/// Gets or sets CheckItemExistence
		/// </summary>
        [Display(Name = "CheckItemExistence", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
		public CheckItemExistence CheckItemExistence { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Status string value
		/// </summary>
		public string StatusString
		{
			get { return EnumUtility.GetStringValue(Status); }
		}

		/// <summary>
		/// Gets LocationType string value
		/// </summary>
		public string LocationTypeString
		{
			get { return EnumUtility.GetStringValue(LocationType); }
		}

		/// <summary>
		/// Gets Allowed string value
		/// </summary>
		public string AllowedString
		{
			get { return EnumUtility.GetStringValue(Allowed); }
		}

		/// <summary>
		/// Gets InUse string value
		/// </summary>
		public string InUseString
		{
			get { return EnumUtility.GetStringValue(InUse); }
		}

		/// <summary>
		/// Gets CostingMethod string value
		/// </summary>
		public string CostingMethodString
		{
			get { return EnumUtility.GetStringValue(CostingMethod); }
		}

		/// <summary>
		/// Gets CheckItemExistence string value
		/// </summary>
		public string CheckItemExistenceString
		{
			get { return EnumUtility.GetStringValue(CheckItemExistence); }
		}
        
        /// <summary>
        /// Gets or sets the segment override string.
        /// </summary>
        public string SegmentOverrideString
        {
            get
            {
                if (SegmentOverride)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                else
                {
                    return EnumUtility.GetStringValue(BooleanType.False);
                }
            }
        }
		#endregion
	}
}
