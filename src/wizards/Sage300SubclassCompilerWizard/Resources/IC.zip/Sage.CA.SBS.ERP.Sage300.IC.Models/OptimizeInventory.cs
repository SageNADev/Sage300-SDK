// Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>IC0307 Optimize Inventory criteria and run state.</summary>
    public partial class OptimizeInventory : ModelBase
    {
        public OptimizeInventory()
        {
            Details = new EnumerableResponse<OptimizeInventoryDetail>
            {
                Items = new List<OptimizeInventoryDetail>()
            };
        }

        [Key]
        [StringLength(8)]
        [ViewField(Name = Fields.RunId, Id = Index.RunId, FieldType = EntityFieldType.Char, Size = 8)]
        public string RunId { get; set; }

        [StringLength(250)]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        [StringLength(24)]
        [ViewField(Name = Fields.FromItemNumber, Id = Index.FromItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FromItemNumber { get; set; }

        [StringLength(24)]
        [ViewField(Name = Fields.ToItemNumber, Id = Index.ToItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ToItemNumber { get; set; }

        [StringLength(6)]
        [ViewField(Name = Fields.FromCategory, Id = Index.FromCategory, FieldType = EntityFieldType.Char, Size = 6)]
        public string FromCategory { get; set; }

        [StringLength(6)]
        [ViewField(Name = Fields.ToCategory, Id = Index.ToCategory, FieldType = EntityFieldType.Char, Size = 6)]
        public string ToCategory { get; set; }

        [StringLength(6)]
        [ViewField(Name = Fields.FromAccountSet, Id = Index.FromAccountSet, FieldType = EntityFieldType.Char, Size = 6)]
        public string FromAccountSet { get; set; }

        [StringLength(6)]
        [ViewField(Name = Fields.ToAccountSet, Id = Index.ToAccountSet, FieldType = EntityFieldType.Char, Size = 6)]
        public string ToAccountSet { get; set; }

        [StringLength(12)]
        [ViewField(Name = Fields.FromVendorNumber, Id = Index.FromVendorNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string FromVendorNumber { get; set; }

        [StringLength(12)]
        [ViewField(Name = Fields.ToVendorNumber, Id = Index.ToVendorNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string ToVendorNumber { get; set; }

        [StringLength(4)]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4)]
        public string Year { get; set; }

        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Int, Size = 2)]
        public int Period { get; set; }

        [StringLength(6)]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        [ViewField(Name = Fields.SalesPeriods, Id = Index.SalesPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public int SalesPeriods { get; set; }

        public EnumerableResponse<OptimizeInventoryDetail> Details { get; set; }
        public int DisplayFilter { get; set; }
        public bool Summary { get; set; }
        public bool HasResults { get; set; }
        public bool HasSelectedRows { get; set; }
        public decimal CurrentMinimumTotal { get; set; }
        public decimal AdjustedMinimumTotal { get; set; }
        public decimal MinimumVarianceTotal { get; set; }
        public decimal CurrentMaximumTotal { get; set; }
        public decimal AdjustedMaximumTotal { get; set; }
        public decimal MaximumVarianceTotal { get; set; }
        public decimal QuantityAvailableValueTotal { get; set; }
        public decimal ToOptimalMinimumTotal { get; set; }
        public decimal ToOptimalMaximumTotal { get; set; }
    }
}
