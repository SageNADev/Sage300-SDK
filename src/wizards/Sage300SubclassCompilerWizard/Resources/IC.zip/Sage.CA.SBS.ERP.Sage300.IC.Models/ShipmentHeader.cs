// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ShipmentHeader
    /// </summary>
    public partial class ShipmentHeader : ModelBase
    {
        #region Constructor

        /// <summary>
        /// This constructor initializes ShipmentDetails
        /// </summary>
        public ShipmentHeader()
        {
            ShipmentDetails = new EnumerableResponse<ShipmentDetail>();
            ShipmentOptionalFields = new EnumerableResponse<ShipmentOptionalField>();
        }

        #endregion

        #region ShipmentHeader model properties

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ShipDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ShipDate", ResourceType = typeof (ShipmentResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipDate, Id = Index.ShipDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ShipDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets EntryType
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public EntryType EntryType { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SourceCurrency", ResourceType = typeof (ShipmentResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceCurrency, Id = Index.SourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets PriceList
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets RateOverride
        /// </summary>
        [Display(Name = "RateOverride", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.RateOverride, Id = Index.RateOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverride RateOverride { get; set; }

        /// <summary>
        /// Gets or sets SerialNumberUniquifier
        /// </summary>
        [Display(Name = "SerialNumberUniquifier", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.SerialNumberUniquifier, Id = Index.SerialNumberUniquifier, FieldType = EntityFieldType.Int, Size = 2)]
        public int SerialNumberUniquifier { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ICUniqueDocumentNumber
        /// </summary>
        [Display(Name = "ICUniqueDocumentNumber", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.ICUniqueDocumentNumber, Id = Index.ICUniqueDocumentNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICUniqueDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordStatus
        /// </summary>
        [Display(Name = "RecordStatus", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.RecordStatus, Id = Index.RecordStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public RecordStatus RecordStatus { get; set; }

        /// <summary>
        /// Gets or sets RecordDeleted
        /// </summary>
        [Display(Name = "RecordDeleted", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.RecordDeleted, Id = Index.RecordDeleted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordDeleted RecordDeleted { get; set; }

        /// <summary>
        /// Gets or sets NextDetailLineNumber
        /// </summary>
        [Display(Name = "NextDetailLineNumber", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.NextDetailLineNumber, Id = Index.NextDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordPrinted
        /// </summary>
        [Display(Name = "RecordPrinted", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.RecordPrinted, Id = Index.RecordPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordPrinted RecordPrinted { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [Display(Name = "PostingDate", ResourceType = typeof (ShipmentResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets CustomerExists
        /// </summary>
        [Display(Name = "CustomerExists", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.CustomerExists, Id = Index.CustomerExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public CustomerExists CustomerExists { get; set; }

        /// <summary>
        /// Gets or sets PostSequenceNumber
        /// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof (ShipmentResx))]
        [ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long PostSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }
        
        #endregion

        #region UI Strings

        /// <summary>
        /// Gets Home currency 
        /// </summary>
        /// <value>The Home currency .</value>
        [IgnoreExportImport]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets ShipmentDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ShipmentDetail> ShipmentDetails { get; set; }

        /// <summary>
        /// Gets or sets ShipmentOptionalFields
        /// </summary>
        public EnumerableResponse<ShipmentOptionalField> ShipmentOptionalFields { get; set; }

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        public string FiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(FiscalPeriod); }
        }

        /// <summary>
        /// Gets EntryType string value
        /// </summary>
        public string EntryTypeString
        {
            get { return EnumUtility.GetStringValue(EntryType); }
        }

        /// <summary>
        /// Gets RateOperation string value
        /// </summary>
        public string RateOperationString
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets RateOverride string value
        /// </summary>
        public string RateOverrideString
        {
            get { return EnumUtility.GetStringValue(RateOverride); }
        }

        /// <summary>
        /// Gets JobRelated string value
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets RecordStatus string value
        /// </summary>
        public string RecordStatusString
        {
            get { return EnumUtility.GetStringValue(RecordStatus); }
        }

        /// <summary>
        /// Gets RecordDeleted string value
        /// </summary>
        public string RecordDeletedString
        {
            get { return EnumUtility.GetStringValue(RecordDeleted); }
        }

        /// <summary>
        /// Gets RecordPrinted string value
        /// </summary>
        public string RecordPrintedString
        {
            get { return EnumUtility.GetStringValue(RecordPrinted); }
        }

        /// <summary>
        /// Gets CustomerExists string value
        /// </summary>
        public string CustomerExistsString
        {
            get { return EnumUtility.GetStringValue(CustomerExists); }
        }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets or sets HeaderExists
        /// </summary>
        public bool HeaderExists { get; set; }

        #endregion
    }
}
