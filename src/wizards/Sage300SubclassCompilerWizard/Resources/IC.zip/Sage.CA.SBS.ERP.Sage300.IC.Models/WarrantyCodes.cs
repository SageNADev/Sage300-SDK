﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    //// <summary>
    ///  Class for ContractCode
    /// </summary>
    public class WarrantyCodes : ModelBase
    {

        /// <summary>
        /// Gets and Sets WarrantyCode
        /// </summary>
        [Display(Name = "WarrantyCode", ResourceType = typeof(WarrantyCodesResx))]
        public string WarrantyCode { get; set; }

        /// <summary>
        /// Gets and Sets Description
        /// </summary>
        public string Description { get; set; }

        /// <summary>
        /// Gets and Sets Days
        /// </summary>
        public long Days { get; set; }

        /// <summary>
        /// Gets and Sets EffectiveDays
        /// </summary>
        public long EffectiveDays { get; set; }

        /// <summary>
        /// Gets and Sets PeriodIsLifetimes
        /// </summary>
        public Period1IsLifetime PeriodIsLifetimes { get; set; }
    }
}
