// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of properties for SalesStatistic
    /// </summary>
    public partial class SalesStatistic : ModelBase
    {
        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Year
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Int, Size = 2)]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets SalesAmount
        /// </summary>
        [Display(Name = "SalesAmount", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SalesAmount, Id = Index.SalesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SalesAmount { get; set; }

        /// <summary>
        /// Gets or sets SalesCount
        /// </summary>
        [Display(Name = "SalesCount", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SalesCount, Id = Index.SalesCount, FieldType = EntityFieldType.Long, Size = 4)]
        public decimal SalesCount { get; set; }

        /// <summary>
        /// Gets or sets SalesQuantity
        /// </summary>
        [Display(Name = "SalesQuantity", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SalesQuantity, Id = Index.SalesQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SalesQuantity { get; set; }

        /// <summary>
        /// Gets or sets CostOfGoodsSold
        /// </summary>
        [Display(Name = "CostOfGoodsSold", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CostOfGoodsSold, Id = Index.CostOfGoodsSold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostOfGoodsSold { get; set; }

        /// <summary>
        /// Gets or sets SalesReturnAmount
        /// </summary>
        [Display(Name = "SalesReturnAmount", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SalesReturnAmount, Id = Index.SalesReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SalesReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets SalesReturnCount
        /// </summary>
        [Display(Name = "SalesReturnCount", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SalesReturnCount, Id = Index.SalesReturnCount, FieldType = EntityFieldType.Long, Size = 4)]
        public decimal SalesReturnCount { get; set; }

        /// <summary>
        /// Gets or sets SalesReturnQuantity
        /// </summary>
        [Display(Name = "SalesReturnQuantity", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.SalesReturnQuantity, Id = Index.SalesReturnQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SalesReturnQuantity { get; set; }

        /// <summary>
        /// Gets or sets CostOfGoodsReturned
        /// </summary>
        [Display(Name = "CostOfGoodsReturned", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.CostOfGoodsReturned, Id = Index.CostOfGoodsReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostOfGoodsReturned { get; set; }

        /// <summary>
        /// Gets or sets GrossMargin
        /// </summary>
        [Display(Name = "GrossMargin", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.GrossMargin, Id = Index.GrossMargin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal GrossMargin { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets LocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDescription", ResourceType = typeof(SalesStatisticsResx))]
        [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationDescription { get; set; }

        /// <summary>
        /// Gets or sets StockingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StockingUnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StockingUnitOfMeasure, Id = Index.StockingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string StockingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets SaleStatisticsData
        /// </summary>
        public EnumerableResponse<SalesStatisticGrid> SaleStatistics { get; set; }
    }

    /// <summary>
    /// Sales Statistics grid Data 
    /// </summary>
    public class SalesStatisticGrid : ModelBase
    {
        /// <summary>
        /// Gets or sets Statistics
        /// </summary>
        public string Statistics { get; set; }

        /// <summary>
        /// Gets or sets StatisticsDescription
        /// </summary>
        public string StatisticsDesc { get; set; }

        /// <summary>
        /// Gets or sets Return       
        /// </summary>
        public decimal? Return { get; set; }

        /// <summary>
        /// Gets or sets Sale
        /// </summary>
        public decimal Sale { get; set; }

        /// <summary>
        /// Gets or sets StockingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string StockingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets IsSaleEditable 
        /// </summary>
        public bool IsSaleEditable { get; set; }

        /// <summary>
        /// Gets or sets IsReturnEditable
        /// </summary>
        public bool IsReturnEditable { get; set; }

        /// <summary>
        /// Gets or sets precision
        /// </summary>
        public int Decimals { get; set; }
    }
}
