﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region NameSpaces

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{

    /// <summary>
    /// Classes for LotNumberInquiry
    /// </summary>
    public class LotNumberInquiry : ModelBase
    {
        /// <summary>
        /// Constant for char 'Z'
        /// </summary>
        private const char Z = 'Z';

        /// <summary>
        /// Constant Char for 'z'
        /// </summary>
        private const char z = 'z';

        /// <summary>
        /// Integer constant for LotNumberLength
        /// </summary>
        private const int LotNumberLength = 40;

        /// <summary>
        /// Integer constant for ItemNumberRecurringLength
        /// </summary>
        private const int ItemNumberRecurringLength = 24;

        /// <summary>
        /// Integer constant for LocationNumberLength
        /// </summary>
        private const int LocationNumberLength = 6;

        /// <summary>
        /// Gets or sets the property of FromLotNumber
        /// </summary>
        [StringLength(LotNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LotNumber", ResourceType = typeof(ICCommonResx))]
        public string FromLotNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of ToLotNumber
        /// </summary>
        [StringLength(LotNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLotNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of ItemNumberFrom
        /// </summary>
        [StringLength(ItemNumberRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        public string FromItemNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of ItemNumberTo
        /// </summary>
        [StringLength(ItemNumberRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToItemNumber { get; set; }

        /// <summary>
        /// Gets or sets the LocationFrom
        /// </summary>
        [StringLength(LocationNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets the LocationTo
        /// </summary>
        [StringLength(LocationNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLocation { get; set; }

        /// <summary>
        /// From Stock Date
        /// </summary>
        [Display(Name = "StockDate", ResourceType = typeof(ICCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromStockDate { get; set; }

        /// <summary>
        /// To Stock Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToStockDate { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        public SerialLotTransactionStatus Status { get; set; }

        /// <summary>
        /// Gets or sets an EnumerableResponse of objects of type <see cref="InventoryLotNumbers" />
        /// </summary>
        public EnumerableResponse<InventoryLotNumber> InventoryLotNumbers { get; set; }

        #region Constructor

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public LotNumberInquiry()
        {
            ToItemNumber = CommonUtil.Repeat(Z, ItemNumberRecurringLength);
            ToLotNumber = CommonUtil.Repeat(z, LotNumberLength);
            ToLocation = CommonUtil.Repeat(Z, LocationNumberLength);
        }

        #endregion
    }
}