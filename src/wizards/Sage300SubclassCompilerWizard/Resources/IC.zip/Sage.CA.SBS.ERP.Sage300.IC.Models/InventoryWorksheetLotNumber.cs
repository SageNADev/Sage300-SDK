// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Partial class for InventoryWorksheetLotNumber
     /// </summary>
     public partial class InventoryWorksheetLotNumber : ModelBase
     {
          /// <summary>
          /// Gets or sets Location
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string Location {get; set;}

          /// <summary>
          /// Gets or sets SortCode
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.SortCode, Id = Index.SortCode, FieldType = EntityFieldType.Char, Size = 60)]
          public string SortCode {get; set;}

          /// <summary>
          /// Gets or sets UnformattedItemNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string UnformattedItemNumber {get; set;}

          /// <summary>
          /// Gets or sets LotNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string LotNumber {get; set;}

          /// <summary>
          /// Gets or sets ExpiryDate
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime ExpiryDate {get; set;}

          /// <summary>
          /// Gets or sets TransactionQuantity
          /// </summary>
          [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal TransactionQuantity {get; set;}

          /// <summary>
          /// Gets or sets LotQuantityInStockingUom
          /// </summary>
          [ViewField(Name = Fields.LotQuantityInStockingUom, Id = Index.LotQuantityInStockingUom, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal LotQuantityInStockingUom { get; set; }

          /// <summary>
          /// Gets or sets LotCost
          /// </summary>
          [ViewField(Name = Fields.LotCost, Id = Index.LotCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal LotCost {get; set;}
     }
}
