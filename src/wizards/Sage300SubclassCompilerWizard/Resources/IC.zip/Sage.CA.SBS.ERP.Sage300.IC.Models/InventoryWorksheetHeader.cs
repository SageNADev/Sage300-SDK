// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for InventoryWorksheetHeader
    /// </summary>
    public partial class InventoryWorksheetHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets SortCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SortCode", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.SortCode, Id = Index.SortCode, FieldType = EntityFieldType.Char, Size = 60)]
        public string SortCode { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets PickingSequence
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PickingSequence", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PickingSequence, Id = Index.PickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
        public string PickingSequence { get; set; }

        /// <summary>
        /// Gets or sets QuantityonHand
        /// </summary>
        [Display(Name = "QuantityonHand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityonHand, Id = Index.QuantityonHand, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityonHand { get; set; }

        /// <summary>
        /// Gets or sets QuantityCounted
        /// </summary>
        [Display(Name = "QuantityCounted", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityCounted, Id = Index.QuantityCounted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public string QuantityCounted { get; set; }

        /// <summary>
        /// Gets or sets QuantityVariance
        /// </summary>
        [Display(Name = "QuantityVariance", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityVariance, Id = Index.QuantityVariance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityVariance { get; set; }

        /// <summary>
        /// Gets or sets StockingUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StockingUnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StockingUnitOfMeasure, Id = Index.StockingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string StockingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets EstimatedUnitCost
        /// </summary>
        [Display(Name = "EstUnitCost", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.EstimatedUnitCost, Id = Index.EstimatedUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal EstimatedUnitCost { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentUnitCost
        /// </summary>
        [Display(Name = "AdjUnitCost", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.AdjustmentUnitCost, Id = Index.AdjustmentUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public string AdjustmentUnitCost { get; set; }

        /// <summary>
        /// Gets or sets CostVariance
        /// </summary>
        [Display(Name = "CostVariance", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostVariance, Id = Index.CostVariance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostVariance { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public WorksheetHeaderStatus Status { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldString 
        /// </summary>
        [IgnoreExportImport]
        public string OptionalFieldString { get; set; }

        /// <summary>
        /// Gets or sets SerialQty
        /// </summary>
        [Display(Name = "NumberofSerials", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.SerialQty, Id = Index.SerialQty, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQty { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets SerialsCost
        /// </summary>
        [Display(Name = "SerialsCost", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.SerialsCost, Id = Index.SerialsCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SerialsCost { get; set; }

        /// <summary>
        /// Gets or sets LotsCost
        /// </summary>
        [Display(Name = "LotsCost", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.LotsCost, Id = Index.LotsCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LotsCost { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [Display(Name = "InterprocessCommID", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommID { get; set; }

        /// <summary>
        /// Gets or sets NumSerial
        /// </summary>
        [Display(Name = "NumberofSerials", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.NumSerial, Id = Index.NumSerial, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumSerial { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSn
        /// </summary>
        [Display(Name = "ForcePopupSn", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.ForcePopupSn, Id = Index.ForcePopupSn, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupSn { get; set; }

        /// <summary>
        /// Gets or sets PopupSn
        /// </summary>
        [Display(Name = "PopupSn", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.PopupSn, Id = Index.PopupSn, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupSn { get; set; }

        /// <summary>
        /// Gets or sets CloseSn
        /// </summary>
        [Display(Name = "CloseSn", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.CloseSn, Id = Index.CloseSn, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseSn { get; set; }

        /// <summary>
        /// Gets or sets LtSetID
        /// </summary>
        [Display(Name = "LtSetID", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.LtSetID, Id = Index.LtSetID, FieldType = EntityFieldType.Long, Size = 4)]
        public long LtSetID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLt
        /// </summary>
        [Display(Name = "ForcePopupLt", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.ForcePopupLt, Id = Index.ForcePopupLt, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupLt { get; set; }

        /// <summary>
        /// Gets or sets PopupLt
        /// </summary>
        [Display(Name = "PopupLt", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.PopupLt, Id = Index.PopupLt, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupLt { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [Display(Name = "CloseLt", ResourceType = typeof(PhysicalInventoryQuantitiesResx))]
        [ViewField(Name = Fields.CloseLt, Id = Index.CloseLt, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseLt { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public WorksheetHeaderProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityperLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        /// <summary>
        /// Gets or sets WorksheetDetailOptionalField collection.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<WorksheetDetailOptionalField> WorksheetDetailOptionalField { get; set; }

        /// <summary>
        /// Gets the Status options
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> StatusList
        {
            get
            {
                var statusOptions = EnumUtility.GetItemsList<WorksheetHeaderStatus>().ToList();
                statusOptions.RemoveRange(3, 5);
                statusOptions.RemoveRange(0, 1);
                return statusOptions;
            }
        }

        /// <summary>
        /// Gets the Status options for Item Not Active
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> ItemnotActiveList
        {
            get
            {
                var statusOptions = EnumUtility.GetItemsList<WorksheetHeaderStatus>().ToList();
                statusOptions.RemoveRange(3, 4);
                statusOptions.RemoveRange(0, 1);
                return statusOptions;
            }
        }

        /// <summary>
        /// Gets the Status options for Item doesnot Exist
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> ItemdoesnotExistList
        {
            get
            {
                var statusOptions = EnumUtility.GetItemsList<WorksheetHeaderStatus>().ToList();
                statusOptions.RemoveRange(4, 4);
                statusOptions.RemoveRange(0, 1);
                return statusOptions;
            }
        }

        /// <summary>
        /// Gets the Status options for Non-Stock Item
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> NonStockItemList
        {
            get
            {
                var statusOptions = EnumUtility.GetItemsList<WorksheetHeaderStatus>().ToList();
                statusOptions.RemoveRange(5, 3);
                statusOptions.RemoveRange(3, 1);
                statusOptions.RemoveRange(0, 1);
                return statusOptions;
            }
        }

        /// <summary>
        /// Gets the Status options for Item Not Allowed at Location
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> ItemNotAllowedatLocationList
        {
            get
            {
                var statusOptions = EnumUtility.GetItemsList<WorksheetHeaderStatus>().ToList();
                statusOptions.RemoveRange(6, 2);
                statusOptions.RemoveRange(3, 2);
                statusOptions.RemoveRange(0, 1);
                return statusOptions;
            }
        }

        /// <summary>
        /// Gets the Status options for Insufficient Quantity
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> InsufficientQuantityList
        {
            get
            {
                var statusOptions = EnumUtility.GetItemsList<WorksheetHeaderStatus>().ToList();
                statusOptions.RemoveRange(7, 1);
                statusOptions.RemoveRange(3, 3);
                statusOptions.RemoveRange(0, 1);
                return statusOptions;
            }
        }
    }
}
