// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for InventorySerialNumber
	/// </summary>
	public partial class InventorySerialNumber : ModelBase
	{
		/// <summary>
		/// Gets or sets UnformattedSerialNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "SerialNumber", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.UnformattedSerialNumber, Id = Index.UnformattedSerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string UnformattedSerialNumber { get; set; }

		/// <summary>
		/// Gets or sets UnformattedItemNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string UnformattedItemNumber { get; set; }

		/// <summary>
		/// Gets or sets Location
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Location", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string Location { get; set; }

		/// <summary>
		/// Gets or sets Location Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "LocationDesc", ResourceType = typeof(ICCommonResx))]
		public string LocationDesc { get; set; }

		/// <summary>
		/// Gets or sets Status
		/// </summary>
		[Display(Name = "Status", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
		public InventorySerialNumberStatus Status { get; set; }

		/// <summary>
		/// Gets or sets StockDate
		/// </summary>
		//[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "StockDate", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.StockDate, Id = Index.StockDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime StockDate { get; set; }

		/// <summary>
		/// Gets or sets ExpiryDate
		/// </summary>
		//[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ExpiryDate", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ExpiryDate { get; set; }

		/// <summary>
		/// Gets or sets SerialNumber
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "SerialNumber", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string SerialNumber { get; set; }

		/// <summary>
		/// Gets or sets ItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
		public string ItemNumber { get; set; }

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
		public string ItemDescription { get; set; }

		/// <summary>
		/// Gets or sets ReserveForOrder
		/// </summary>
		[Display(Name = "ReserveForOrder", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ReserveForOrder, Id = Index.ReserveForOrder, FieldType = EntityFieldType.Bool, Size = 2)]
		public AllowBlank ReserveForOrder { get; set; }

		/// <summary>
		/// Gets or sets StockedForCosting
		/// </summary>
        [Display(Name = "stockedforCosting", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.StockedForCosting, Id = Index.StockedForCosting, FieldType = EntityFieldType.Int, Size = 2)]
		public int StockedForCosting { get; set; }

		/// <summary>
		/// Gets or sets CostForCosting
		/// </summary>
        [Display(Name = "CostForCosting", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.CostForCosting, Id = Index.CostForCosting, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal CostForCosting { get; set; }

		/// <summary>
		/// Gets or sets TotalCost
		/// </summary>
		[Display(Name = "TotalCost", ResourceType = typeof(ICCommonResx))]
		public decimal TotalCost { get; set; }

		/// <summary>
		/// Gets or sets ContractCode
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ContractCode", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ContractCode { get; set; }

		/// <summary>
		/// Gets or sets OptionalFields
		/// </summary>
		[Display(Name = "OptionalFields", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
		public long OptionalFields { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod1InUse
		/// </summary>
        [Display(Name = "ContractPeriod1InUse", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod1InUse, Id = Index.ContractPeriod1InUse, FieldType = EntityFieldType.Bool, Size = 2)]
		public AllowBlank ContractPeriod1InUse { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod1ExpiryDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod1ExpiryDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod1ExpiryDate, Id = Index.ContractPeriod1ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod1ExpiryDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod1EffectiveDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod1EffectiveDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod1EffectiveDate, Id = Index.ContractPeriod1EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod1EffectiveDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod1Lifetime
		/// </summary>
        [Display(Name = "ContractPeriod1Lifetime", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod1Lifetime, Id = Index.ContractPeriod1Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod1Lifetime { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod2InUse
		/// </summary>
        [Display(Name = "ContractPeriod2InUse", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod2InUse, Id = Index.ContractPeriod2InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod2InUse { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod2ExpiryDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod2ExpiryDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod2ExpiryDate, Id = Index.ContractPeriod2ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod2ExpiryDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod2EffectiveDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod2EffectiveDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod2EffectiveDate, Id = Index.ContractPeriod2EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod2EffectiveDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod2Lifetime
		/// </summary>
        [Display(Name = "ContractPeriod2Lifetime", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod2Lifetime, Id = Index.ContractPeriod2Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod2Lifetime { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod3InUse
		/// </summary>
        [Display(Name = "ContractPeriod3InUse", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod3InUse, Id = Index.ContractPeriod3InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod3InUse { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod3ExpiryDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod3ExpiryDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod3ExpiryDate, Id = Index.ContractPeriod3ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod3ExpiryDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod3EffectiveDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod3EffectiveDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod3EffectiveDate, Id = Index.ContractPeriod3EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod3EffectiveDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod3Lifetime
		/// </summary>
        [Display(Name = "ContractPeriod3Lifetime", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod3Lifetime, Id = Index.ContractPeriod3Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod3Lifetime { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod4InUse
		/// </summary>
        [Display(Name = "ContractPeriod4InUse", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod4InUse, Id = Index.ContractPeriod4InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod4InUse { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod4ExpiryDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod4ExpiryDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod4ExpiryDate, Id = Index.ContractPeriod4ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod4ExpiryDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod4EffectiveDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod4EffectiveDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod4EffectiveDate, Id = Index.ContractPeriod4EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod4EffectiveDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod4Lifetime
		/// </summary>
        [Display(Name = "ContractPeriod4Lifetime", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod4Lifetime, Id = Index.ContractPeriod4Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod4Lifetime { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod5InUse
		/// </summary>
        [Display(Name = "ContractPeriod5InUse", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod5InUse, Id = Index.ContractPeriod5InUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod5InUse { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod5ExpiryDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod5ExpiryDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod5ExpiryDate, Id = Index.ContractPeriod5ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod5ExpiryDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod5EffectiveDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod5EffectiveDate", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod5EffectiveDate, Id = Index.ContractPeriod5EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ContractPeriod5EffectiveDate { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod5Lifetime
		/// </summary>
        [Display(Name = "ContractPeriod5Lifetime", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.ContractPeriod5Lifetime, Id = Index.ContractPeriod5Lifetime, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank ContractPeriod5Lifetime { get; set; }

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Description", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod1Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod1Description", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod1Description, Id = Index.ContractPeriod1Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string ContractPeriod1Description { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod2Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod2Description", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod2Description, Id = Index.ContractPeriod2Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string ContractPeriod2Description { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod3Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod3Description", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod3Description, Id = Index.ContractPeriod3Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string ContractPeriod3Description { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod4Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod4Description", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod4Description, Id = Index.ContractPeriod4Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string ContractPeriod4Description { get; set; }

		/// <summary>
		/// Gets or sets ContractPeriod5Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractPeriod5Description", ResourceType = typeof(InventorySerialNumberResx))]
		[ViewField(Name = Fields.ContractPeriod5Description, Id = Index.ContractPeriod5Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string ContractPeriod5Description { get; set; }

		/// <summary>
		/// Gets or sets UpdatedbyUI
		/// </summary>
        [Display(Name = "UpdatedbyUI", ResourceType = typeof(InventorySerialNumberResx))]
        [ViewField(Name = Fields.UpdatedbyUI, Id = Index.UpdatedbyUI, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank UpdatedbyUI { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Status string value
		/// </summary>
		public string StatusString
		{
			get { return EnumUtility.GetStringValue(Status); }
		}

		/// <summary>
		/// Gets ReserveForOrder string value
		/// </summary>
		public string ReserveForOrderString
		{
			get { return EnumUtility.GetStringValue(ReserveForOrder); }
		}

		/// <summary>
		/// Gets ContractPeriod1InUse string value
		/// </summary>
		public string ContractPeriod1InUseString
		{
			get { return EnumUtility.GetStringValue(ContractPeriod1InUse); }
		}

        /// <summary>
        /// Gets ContractPeriod1Lifetime string value
        /// </summary>
        public string ContractPeriod1LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod1Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod2InUse string value
        /// </summary>
        public string ContractPeriod2InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod2InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod2Lifetime string value
        /// </summary>
        public string ContractPeriod2LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod2Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod3InUse string value
        /// </summary>
        public string ContractPeriod3InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod3InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod3Lifetime string value
        /// </summary>
        public string ContractPeriod3LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod3Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod4InUse string value
        /// </summary>
        public string ContractPeriod4InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod4InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod4Lifetime string value
        /// </summary>
        public string ContractPeriod4LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod4Lifetime); }
        }

        /// <summary>
        /// Gets ContractPeriod5InUse string value
        /// </summary>
        public string ContractPeriod5InUseString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod5InUse); }
        }

        /// <summary>
        /// Gets ContractPeriod5Lifetime string value
        /// </summary>
        public string ContractPeriod5LifetimeString
        {
            get { return EnumUtility.GetStringValue(ContractPeriod5Lifetime); }
        }

        /// <summary>
        /// Gets UpdatedbyUI string value
        /// </summary>
        public string UpdatedbyUIString
        {
            get { return EnumUtility.GetStringValue(UpdatedbyUI); }
        }

        #region Grid UI properties

        #endregion

        #endregion
    }
}
