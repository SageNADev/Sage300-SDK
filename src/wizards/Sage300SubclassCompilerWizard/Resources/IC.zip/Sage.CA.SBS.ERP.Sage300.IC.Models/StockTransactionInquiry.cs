﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for StockTransactionInquiry
    /// </summary>
    public class StockTransactionInquiry : ModelBase
    {
        /// <summary>
        /// Default Character
        /// </summary>
        private const char Z = 'Z';

        /// <summary>
        /// ItemNoToRecurringLength
        /// </summary>
        private const int ItemNoToRecurringLength = 24;

        /// <summary>
        /// RecurringLength
        /// </summary>
        private const int RecurringLength = 6;

        /// <summary>
        /// Constructor Stock Transaction Inquiry
        /// </summary>
        public StockTransactionInquiry()
        {
            ToItemno = CommonUtil.Repeat(Z, ItemNoToRecurringLength);
            ToAccountSetCode = CommonUtil.Repeat(Z, RecurringLength);
            ToLocation = CommonUtil.Repeat(Z, RecurringLength);
        }

        /// <summary>
        /// Gets or sets FromItemno
        /// </summary>
        [Display(Name = "Item", ResourceType = typeof(ICCommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromItemno { get; set; }

        /// <summary>
        /// Gets or sets ToItemno
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToItemno { get; set; }

        /// <summary>
        /// Gets or sets FromAccountSetCode
        /// </summary>
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromAccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets ToAccountSetCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToAccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets FromLocation
        /// </summary>
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets ToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLocation { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Display(Name = "AsAtYearPeriod", ResourceType = typeof(ICCommonResx))]
        [Range(typeof(Decimal), "1000", "9999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Range(typeof(Decimal), "1", "99", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or Sets the Currency Decimal - Required to display the Decimal values
        /// </summary>
        public string CurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets From unformatted Itemno
        /// </summary>
        public string FromUnFormattedItemNo { get; set; }

        /// <summary>
        /// Gets or sets To Unformatted Itemno
        /// </summary>
        public string ToUnFormattedItemNo { get; set; }

    }
}