// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Separator Right Brace
    /// </summary>
    public enum SeparatorRightBrace
    {
        /// <summary>
        /// Right Brace 
        /// </summary>
        RightBrace = 1,
    }
}