// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Separator Back Slash
    /// </summary>
    public enum SeparatorBackSlash
    {
        /// <summary>
        /// Back Slash
        /// </summary>
        BackSlash = 1,
    }
}