// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace References

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for EntryType
    /// </summary>
    public enum EntryTypeLotRecall
    {
        #region EntryType enums

        /// <summary>
        /// Gets or sets Shipment
        /// </summary>
        [EnumValue("Recall", typeof (LotRecallsReleasesResx))] Recall = 1,

        /// <summary>
        /// Gets or sets Return
        /// </summary>
        [EnumValue("Release", typeof(LotRecallsReleasesResx))]
        Release = 2,

        #endregion
    }
}
