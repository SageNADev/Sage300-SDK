﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ReceiptProcessCommand
    /// </summary>
    public enum ReceiptProcessCommand
    {
        /// <summary>
        /// Gets or sets NothingtoProcess 
        /// </summary>
        [EnumValue("NothingToProcess", typeof(ICCommonResx))]
        NothingToProcess = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(ICCommonResx))]
        InsertOptionalFields = 1,

        /// <summary>
        /// Gets or sets AllocateSerialNumbers (PROCESSCMD=21)
        /// </summary>
        AllocateSerialNumbers = 21,

        /// <summary>
        /// Gets or sets GenerateLotNumbers (PROCESSCMD=22)
        /// </summary>
        GenerateLotNumbers = 22,

    }
}
