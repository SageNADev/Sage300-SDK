// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Serials by Enum
    /// </summary>
    public enum SortSerialsby
    {
        /// <summary>
        /// Serial Number 
        /// </summary>
        [EnumValue("SerialNumber", typeof(ICCommonResx), 0)]
        SerialNumber = 1,

        /// <summary>
        /// Stock Date 
        /// </summary>
        [EnumValue("StockDate", typeof(ICCommonResx), 0)]
        StockDate = 2,

        /// <summary>
        /// ExpiryDate 
        /// </summary>
        [EnumValue("ExpiryDate", typeof(ICCommonResx), 0)]
        ExpiryDate = 3,
    }
}