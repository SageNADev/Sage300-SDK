// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Serials by Enum
    /// </summary>
    public enum SortSerialsby
    {
        /// <summary>
        /// Serial Number 
        /// </summary>
        SerialNumber = 1,

        /// <summary>
        /// Stock Date 
        /// </summary>
        StockDate = 2,

        /// <summary>
        /// ExpiryDate 
        /// </summary>
        ExpiryDate = 3,
    }
}