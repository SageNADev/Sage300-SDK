// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Serials by Enum
    /// </summary>
    public enum SortSerialsby
    {
        /// <summary>
        /// Serial Number 
        /// </summary>
        [EnumValue("SerialNumber", typeof(OptionsResx), 0)]
        SerialNumber = 1,

        /// <summary>
        /// Stock Date 
        /// </summary>
        [EnumValue("StockDate", typeof(OptionsResx), 0)]
        StockDate = 2,

        /// <summary>
        /// ExpiryDate 
        /// </summary>
        [EnumValue("ExpiryDate", typeof(OptionsResx), 0)]
        ExpiryDate = 3,
    }
}