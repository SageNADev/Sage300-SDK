// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for QuantityLevel
    /// </summary>
    public enum QuantityLevel
    {
        /// <summary>
        /// Gets or sets QuantityZero
        /// </summary>		 
        [EnumValue("QuantityZero", typeof(QuarantineReportResx))]
        QuantityZero = 0,

        /// <summary>
        /// Gets or sets QuantityAboveZero
        /// </summary>		 
        [EnumValue("QuantityAboveZero", typeof(QuarantineReportResx))]
        QuantityAboveZero = 1,

        /// <summary>
        /// Gets or sets QuantityBelowZero
        /// </summary>		 
        [EnumValue("QuantityBelowZero", typeof(QuarantineReportResx))]
        QuantityBelowZero = -1
    }
}
