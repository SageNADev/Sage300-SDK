// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum Separator Left Parenthesis
    /// </summary>
    public enum SeparatorLeftParenthesis
    {
        /// <summary>
        /// Left Parenthesis
        /// </summary>
        LeftParenthesis = 1,
    }
}