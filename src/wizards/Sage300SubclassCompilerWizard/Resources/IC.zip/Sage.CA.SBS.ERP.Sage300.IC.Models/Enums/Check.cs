// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Check 
    /// </summary>
    public enum Check
    {
        /// <summary>
        /// Gets or sets UnitPrice 
        /// </summary>	
        [EnumValue("UnitPrice", typeof(ICCommonResx))]
        UnitPrice = 1,

        /// <summary>
        /// Gets or sets SalesMargin 
        /// </summary>	
        [EnumValue("SalesMargin", typeof(ICCommonResx))]
        SalesMargin = 2,
    }
}
