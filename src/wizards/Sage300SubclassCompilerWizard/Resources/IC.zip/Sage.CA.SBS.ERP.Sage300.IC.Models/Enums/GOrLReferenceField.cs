// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Enum for G Or L Reference Field
    /// </summary>
    public enum GOrLReferenceField
    {
        /// <summary>
        /// Document Number
        /// </summary>
        DocumentNumber = 1,

        /// <summary>
        /// Reference Number
        /// </summary>
        ReferenceNumber = 2,

        /// <summary>
        /// Source Code Or DayEnd Number Or Entry Number
        /// </summary>
        SourceCodeOrDayEndNumberOrEntryNumber = 3,

        /// <summary>
        /// Header Description
        /// </summary>
        HeaderDescription = 4,

        /// <summary>
        /// Customer Or Vendor Number
        /// </summary>
        CustomerOrVendorNumber = 5,

        /// <summary>
        /// Customer Or Vendor Name
        /// </summary>
        CustomerOrVendorName = 6,
    }
}