// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Finder
{
	/// <summary>
	/// Enum for Status
	/// </summary>
	public enum Status
	{
		/// <summary>
		/// Gets or sets NotAvailable
		/// </summary>		 
        [EnumValue("NotAvailable", typeof(ICCommonResx))]
		NotAvailable = 0,

		/// <summary>
		/// Gets or sets Available
		/// </summary>		 
        [EnumValue("Available", typeof(ICCommonResx))]
		Available = 1
	}
}
