
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Finder
{
    /// <summary>
    /// Enum for CostingMethod 
    /// </summary>
    public enum CostingMethod
    {
        /// <summary>
        /// Gets or sets MarkupCost 
        /// </summary>	
        [EnumValue("MarkupCost", typeof(ICCommonResx))]
        MarkupCost = 1,
        /// <summary>
        /// Gets or sets StandardCost 
        /// </summary>	
        [EnumValue("StandardCost", typeof(ICCommonResx))]
        StandardCost = 2,
        /// <summary>
        /// Gets or sets MostRecentCost 
        /// </summary>	
        [EnumValue("MostRecentCost", typeof(ICCommonResx))]
        MostRecentCost = 3,
        /// <summary>
        /// Gets or sets AverageCost 
        /// </summary>	
        [EnumValue("AverageCost", typeof(ICCommonResx))]
        AverageCost = 4,
        /// <summary>
        /// Gets or sets LastUnitCost 
        /// </summary>	
        [EnumValue("LastUnitCost", typeof(ICCommonResx))]
        LastUnitCost = 5,
        /// <summary>
        /// Gets or sets Landed 
        /// </summary>	
        [EnumValue("Landed", typeof(ICCommonResx))]
        Landed = 6,
    }
}
