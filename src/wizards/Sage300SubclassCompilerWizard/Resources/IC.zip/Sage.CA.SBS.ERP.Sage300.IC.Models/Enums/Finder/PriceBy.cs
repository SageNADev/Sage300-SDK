 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Finder
{
	/// <summary>
    /// Enum for PriceBy 
    /// </summary>
	public enum PriceBy 
	{
			/// <summary>
		/// Gets or sets CategoryCode 
		/// </summary>	
        [EnumValue("CategoryCode", typeof(ICCommonResx))]
        CategoryCode = 1,
		/// <summary>
		/// Gets or sets ItemNumber 
		/// </summary>	
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 2,
	}
}
