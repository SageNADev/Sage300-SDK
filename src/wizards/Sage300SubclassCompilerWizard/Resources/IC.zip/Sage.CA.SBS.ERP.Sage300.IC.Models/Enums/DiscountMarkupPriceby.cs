// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for DiscountMarkupPriceby
     /// </summary>
    public enum DiscountMarkupPriceby
    {
        /// <summary>
        /// Gets or sets Percentage
        /// </summary>
        [EnumValue("Percentag", typeof(ICCommonResx))]
        Percentage = 1,

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [EnumValue("Amount", typeof(ICCommonResx))]
        Amount = 2,
    }
}
