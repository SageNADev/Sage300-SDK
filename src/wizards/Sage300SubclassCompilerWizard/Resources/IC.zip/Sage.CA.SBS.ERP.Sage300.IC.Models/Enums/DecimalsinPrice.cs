/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for DecimalsinPrice 
    /// </summary>
    public enum DecimalsinPrice
    {
        /// <summary>
        /// Gets or sets Num0 
        /// </summary>	
        [EnumValue("DecimalPlaces_Num0", typeof(EnumerationsResx))]
        Num0 = 0,

        /// <summary>
        /// Gets or sets Num1 
        /// </summary>	
        [EnumValue("Num1", typeof(EnumerationsResx))]
        Num1 = 1,

        /// <summary>
        /// Gets or sets Num2 
        /// </summary>	
        [EnumValue("Num2", typeof(EnumerationsResx))]
        Num2 = 2,

        /// <summary>
        /// Gets or sets Num3 
        /// </summary>	
        [EnumValue("Num3", typeof(EnumerationsResx))]
        Num3 = 3,

        /// <summary>
        /// Gets or sets Num4 
        /// </summary>	
        [EnumValue("Num4", typeof(EnumerationsResx))]
        Num4 = 4,

        /// <summary>
        /// Gets or sets Num5 
        /// </summary>	
        [EnumValue("Num5", typeof(EnumerationsResx))]
        Num5 = 5,

        /// <summary>
        /// Gets or sets Num6 
        /// </summary>	
        [EnumValue("Num6", typeof(EnumerationsResx))]
        Num6 = 6
    }
}
