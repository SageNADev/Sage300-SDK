﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Location 
    /// </summary>
    public enum Location
    {
        /// <summary>
        /// Gets or sets Items 
        /// </summary>	
       [EnumValue("Items", typeof(OptionalFieldsResx))]
        Items = 0,

        /// <summary>
        /// Gets or sets ReorderQuantities 
        /// </summary>	
        [EnumValue("ReorderQuantities", typeof(OptionalFieldsResx))]
        ReorderQuantities = 1,

        /// <summary>
        /// Gets or sets Receipts 
        /// </summary>	
        [EnumValue("Receipts", typeof(OptionalFieldsResx))]
        Receipts = 2,

        /// <summary>
        /// Gets or sets ReceiptDetails 
        /// </summary>	
        [EnumValue("ReceiptDetails", typeof(OptionalFieldsResx))]
        ReceiptDetails = 3,

        /// <summary>
        /// Gets or sets Shipments 
        /// </summary>	
        [EnumValue("Shipments", typeof(OptionalFieldsResx))]
        Shipments = 4,

        /// <summary>
        /// Gets or sets ShipmentDetails 
        /// </summary>	
        [EnumValue("ShipmentDetails", typeof(OptionalFieldsResx))]
        ShipmentDetails = 5,

        /// <summary>
        /// Gets or sets Adjustments 
        /// </summary>	
        [EnumValue("Adjustments", typeof(OptionalFieldsResx))]
        Adjustments = 6,

        /// <summary>
        /// Gets or sets AdjustmentDetails 
        /// </summary>	
        [EnumValue("AdjustmentDetails", typeof(OptionalFieldsResx))]
        AdjustmentDetails = 7,

        /// <summary>
        /// Gets or sets Transfers 
        /// </summary>	
        [EnumValue("Transfers", typeof(OptionalFieldsResx))]
        Transfers = 8,

        /// <summary>
        /// Gets or sets TransferDetails 
        /// </summary>	
        [EnumValue("TransferDetails", typeof(OptionalFieldsResx))]
        TransferDetails = 9,

        /// <summary>
        /// Gets or sets Assemblies 
        /// </summary>	
       [EnumValue("Assemblies", typeof(OptionalFieldsResx))]
        Assemblies = 10,

        /// <summary>
        /// Gets or sets InternalUsage 
        /// </summary>	
        [EnumValue("InternalUsage", typeof(OptionalFieldsResx))]
        InternalUsage = 11,

        /// <summary>
        /// Gets or sets InternalUsageDetails 
        /// </summary>	
        [EnumValue("InternalUsageDetails", typeof(OptionalFieldsResx))]
        InternalUsageDetails = 12,

        ///// <summary>
        ///// Gets or sets ItemSerials 
        ///// </summary>	
        //[EnumValue("ItemSerials", typeof(OptionalFieldsResx))]
        //ItemSerials = 13,

        /// <summary>
        /// Gets or sets ItemLots 
        /// </summary>	
        [EnumValue("ItemLots", typeof(OptionalFieldsResx))]
        ItemLots = 14,
    }
}
