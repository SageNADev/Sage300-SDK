// Copyright (c) 2022 SAMLTD  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ReserveForOrder
    /// </summary>
    public enum ReserveForOrder
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        [EnumValue("No", typeof(CommonResx))]
        No = 0,
        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1
    }
}