// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for Included Segment
     /// </summary>
     public enum IncludedSegment
     {
          /// <summary>
          /// Gets or sets None
          /// </summary>
         [EnumValue("None", typeof(ICCommonResx), 1)] 
         None = 0,
          /// <summary>
          /// Gets or sets Adjustment Number
          /// </summary>
        [EnumValue("AdjustmentNumber", typeof(ICCommonResx), 2)]
         AdjustmentNumber = 1,
          /// <summary>
          /// Gets or sets Adjustment Type
          /// </summary>
         [EnumValue("AdjustmentType", typeof(ICCommonResx), 3)] 
         AdjustmentType = 2,
          /// <summary>
          /// Gets or sets Assembly Number
          /// </summary>
         [EnumValue("AssemblyNumber", typeof(ICCommonResx), 4)] 
         AssemblyNumber = 3,
          /// <summary>
          /// Gets or sets BOM Number
          /// </summary>
          [EnumValue("BOMNumber", typeof(ICCommonResx), 5)]
         BOMNumber = 4,
          /// <summary>
          /// Gets or sets Category
          /// </summary>
         [EnumValue("Category", typeof(ICCommonResx), 6)] 
         Category = 5,
          /// <summary>
          /// Gets or sets Comment
          /// </summary>
         [EnumValue("Comment", typeof(ICCommonResx), 7)]
         Comment = 6,
          /// <summary>
          /// Gets or sets Contact Name
          /// </summary>
        [EnumValue("ContactName", typeof(ICCommonResx), 8)]  
         ContactName = 7,
          /// <summary>
          /// Gets or sets Contract
          /// </summary>
        [EnumValue("Contract", typeof(ICCommonResx), 9)]
        Contract = 8,
          /// <summary>
          /// Gets or sets Customer Name
          /// </summary>
         [EnumValue("CustomerName", typeof(ICCommonResx), 10)] 
         CustomerName = 9,
          /// <summary>
          /// Gets or sets Customer Number
          /// </summary>
         [EnumValue("CustomerNumber", typeof(ICCommonResx), 11)] 
         CustomerNumber = 10,
          /// <summary>
          /// Gets or sets Day End Number
          /// </summary>
         [EnumValue("DayEndNumber", typeof(ICCommonResx), 12)]
         DayEndNumber = 11,
          /// <summary>
          /// Gets or sets Description
          /// </summary>
         [EnumValue("Description", typeof(ICCommonResx), 13)] 
         Description = 12,
          /// <summary>
          /// Gets or sets Detail Description
          /// </summary>
        [EnumValue("DetailDescription", typeof(ICCommonResx), 14)]  
         DetailDescription = 13,
          /// <summary>
          /// Gets or sets Document Number
          /// </summary>
         [EnumValue("DocumentNumber", typeof(ICCommonResx), 15)] 
         DocumentNumber = 34,
          /// <summary>
          /// Gets or sets Document Type
          /// </summary>
         [EnumValue("DocumentType", typeof(ICCommonResx), 16)] 
         DocumentType = 14,
          /// <summary>
          /// Gets or sets Entry Number
          /// </summary>
         [EnumValue("EntryNumber", typeof(ICCommonResx), 17)] 
         EntryNumber = 15,
          /// <summary>
          /// Gets or sets Entry Type
          /// </summary>
         [EnumValue("EntryType", typeof(ICCommonResx), 18)] 
         EntryType = 16,
          /// <summary>
          /// Gets or sets From Location
          /// </summary>
         [EnumValue("FromLocation", typeof(ICCommonResx), 19)] 
         FromLocation = 17,
          /// <summary>
          /// Gets or sets From Location Name
          /// </summary>
         [EnumValue("FromLocationName", typeof(ICCommonResx), 20)] 
         FromLocationName = 18,
          /// <summary>
          /// Gets or sets GIT Location
          /// </summary>
         [EnumValue("GITLocation", typeof(ICCommonResx), 21)] 
         GITLocation = 19,
          /// <summary>
          /// Gets or sets GIT Location Name
          /// </summary>
         [EnumValue("GITLocationName", typeof(ICCommonResx), 22)] 
         GITLocationName = 20,
          /// <summary>
          /// Gets or sets Item Number
          /// </summary>
         [EnumValue("ItemNumber", typeof(ICCommonResx), 23)] 
         ItemNumber = 21,
          /// <summary>
          /// Gets or sets Location
          /// </summary>
         [EnumValue("Location", typeof(ICCommonResx), 24)] 
         Location = 22,
          /// <summary>
          /// Gets or sets Location Name
          /// </summary>
         [EnumValue("LocationName", typeof(ICCommonResx), 25)] 
         LocationName = 23,
          /// <summary>
          /// Gets or sets Manufacturers Item Number
          /// </summary>
         [EnumValue("ManItemNumber", typeof(ICCommonResx), 26)]
         ManufacturersItemNumber = 24,
          /// <summary>
          /// Gets or sets Purchase Order Number
          /// </summary>
         [EnumValue("PurchaseOrderNumber", typeof(ICCommonResx), 27)] 
         PurchaseOrderNumber = 25,
          /// <summary>
          /// Gets or sets Project
          /// </summary>
         [EnumValue("Project", typeof(ICCommonResx), 28)] 
         Project = 26,
          /// <summary>
          /// Gets or sets Receipt Number
          /// </summary>
        [EnumValue("ReceiptNumber", typeof(ICCommonResx), 29)]  
         ReceiptNumber = 27,
          /// <summary>
          /// Gets or sets Reference
          /// </summary>
         [EnumValue("Reference", typeof(ICCommonResx), 30)] 
         Reference = 28,
          /// <summary>
          /// Gets or sets Shipment Number
          /// </summary>
         [EnumValue("ShipmentNumber", typeof(ICCommonResx), 31)] 
         ShipmentNumber = 29,
          /// <summary>
          /// Gets or sets Source Code
          /// </summary>
         [EnumValue("SourceCode", typeof(ICCommonResx), 32)] 
         SourceCode = 30,
          /// <summary>
          /// Gets or sets ToLocation
          /// </summary>
         [EnumValue("ToLocation", typeof(ICCommonResx), 33)] 
         ToLocation = 31,
          /// <summary>
          /// Gets or sets To Location Name
          /// </summary>
         [EnumValue("ToLocationName", typeof(ICCommonResx), 34)] 
         ToLocationName = 32,
          /// <summary>
          /// Gets or sets Transaction Type
          /// </summary>
         [EnumValue("TransactionType", typeof(ICCommonResx), 35)] 
         TransactionType = 33,
          /// <summary>
          /// Gets or sets Unformatted Item Number
          /// </summary>
         [EnumValue("UnformattedItemNumber", typeof(ICCommonResx), 36)] 
         UnformattedItemNumber = 35,
          /// <summary>
          /// Gets or sets Vendor Name
          /// </summary>
         [EnumValue("VendorName", typeof(ICCommonResx), 37)] 
         VendorName = 36,
          /// <summary>
          /// Gets or sets Vendor Number
          /// </summary>
         [EnumValue("VendorNumber", typeof(ICCommonResx), 38)] 
         VendorNumber = 37,
          /// <summary>
          /// Gets or sets Internal Usage Number
          /// </summary>
         [EnumValue("InternalUsageNumber", typeof(ICCommonResx), 39)] 
         InternalUsageNumber = 39,
     }
}
