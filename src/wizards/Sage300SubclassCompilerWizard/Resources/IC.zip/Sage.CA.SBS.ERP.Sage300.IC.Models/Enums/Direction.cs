// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for Direction
	/// </summary>
	public enum Direction
	{
		/// <summary>
		/// Gets or sets Increase
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Increase", typeof(ICCommonResx))]
		Increase = 1,

		/// <summary>
		/// Gets or sets Decrease
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Decrease", typeof(ICCommonResx))]
		Decrease = 2
	}
}
