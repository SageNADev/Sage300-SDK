﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for TransactionTypes
    /// </summary>
    public enum TransactionTypes
    {
        #region TransactionTypes Enums

        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [EnumValue("Receipt", typeof (TransactionHistoryInquiryResx))] Receipt = 1,

        /// <summary>
        /// Gets or sets ReceiptAdjustment
        /// </summary>
        [EnumValue("ReceiptAdjustment", typeof (TransactionHistoryInquiryResx))] ReceiptAdjustment = 2,

        /// <summary>
        /// Gets or sets ReceiptReturn
        /// </summary>
        [EnumValue("ReceiptReturn", typeof (TransactionHistoryInquiryResx))] ReceiptReturn = 3,

        /// <summary>
        /// Gets or sets Shipment
        /// </summary>
        [EnumValue("Shipment", typeof (TransactionHistoryInquiryResx))] Shipment = 4,

        /// <summary>
        /// Gets or sets ShipmentReturn
        /// </summary>
        [EnumValue("ShipmentReturn", typeof (TransactionHistoryInquiryResx))] ShipmentReturn = 5,

        /// <summary>
        /// Gets or sets AdjustmentQuantityIncrease
        /// </summary>
        [EnumValue("AdjustmentQuantityIncrease", typeof (TransactionHistoryInquiryResx))] AdjustmentQuantityIncrease = 6,

        /// <summary>
        /// Gets or sets AdjustmentQuantityDecrease
        /// </summary>
        [EnumValue("AdjustmentQuantityDecrease", typeof (TransactionHistoryInquiryResx))] AdjustmentQuantityDecrease = 7,

        /// <summary>
        /// Gets or sets AdjustmentCostIncrease
        /// </summary>
        [EnumValue("AdjustmentCostIncrease", typeof (TransactionHistoryInquiryResx))] AdjustmentCostIncrease = 8,

        /// <summary>
        /// Gets or sets AdjustmentCostDecrease
        /// </summary>
        [EnumValue("AdjustmentCostDecrease", typeof (TransactionHistoryInquiryResx))] AdjustmentCostDecrease = 9,

        /// <summary>
        /// Gets or sets AdjustmentBothIncrease
        /// </summary>
        [EnumValue("AdjustmentBothIncrease", typeof (TransactionHistoryInquiryResx))] AdjustmentBothIncrease = 10,

        /// <summary>
        /// Gets or sets AdjustmentBothDecrease
        /// </summary>
        [EnumValue("AdjustmentBothDecrease", typeof (TransactionHistoryInquiryResx))] AdjustmentBothDecrease = 11,

        /// <summary>
        /// Gets or sets StockTransferFrom
        /// </summary>
        [EnumValue("StockTransferFrom", typeof (TransactionHistoryInquiryResx))] StockTransferFrom = 12,

        /// <summary>
        /// Gets or sets StockTransferTo
        /// </summary>
        [EnumValue("StockTransferTo", typeof (TransactionHistoryInquiryResx))] StockTransferTo = 13,

        /// <summary>
        /// Gets or sets MasterItemAssembly
        /// </summary>
        [EnumValue("MasterItemAssembly", typeof (TransactionHistoryInquiryResx))] MasterItemAssembly = 14,

        /// <summary>
        /// Gets or sets ComponentItemAssembly
        /// </summary>
        [EnumValue("ComponentItemAssembly", typeof (TransactionHistoryInquiryResx))] ComponentItemAssembly = 15,

        /// <summary>
        /// Gets or sets Invoice
        /// </summary>
        [EnumValue("Invoice", typeof (TransactionHistoryInquiryResx))] Invoice = 16,

        /// <summary>
        /// Gets or sets CreditNote
        /// </summary>
        [EnumValue("CreditNote", typeof (TransactionHistoryInquiryResx))] CreditNote = 17,

        /// <summary>
        /// Gets or sets DebitNote
        /// </summary>
        [EnumValue("DebitNote", typeof (TransactionHistoryInquiryResx))] DebitNote = 18,

        /// <summary>
        /// Gets or sets ShipmentAdjustment
        /// </summary>
        [EnumValue("ShipmentAdjustment", typeof (TransactionHistoryInquiryResx))] ShipmentAdjustment = 19,

        /// <summary>
        /// Gets or sets InternalUsage
        /// </summary>
        [EnumValue("InternalUsage", typeof (TransactionHistoryInquiryResx))] InternalUsage = 20

        #endregion
    }
}
