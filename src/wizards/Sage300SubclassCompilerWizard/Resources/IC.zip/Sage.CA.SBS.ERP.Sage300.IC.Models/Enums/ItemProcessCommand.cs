﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand
    /// </summary>
    public enum ItemProcessCommand
    {
        /// <summary>
        /// Gets or sets NothingtoProcess 
        /// </summary>
        [EnumValue("NothingToProcess", typeof(ICCommonResx))]
        NothingToProcess = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(ICCommonResx))]
        InsertOptionalFields = 1,

        /// <summary>
        /// Gets or sets InsertItemSerialOptionalFields 
        /// </summary>
        [EnumValue("InsertItemSerialOptionalFields", typeof(ICCommonResx))]
        InsertItemSerialOptionalFields = 6,
        /// <summary>
        /// Gets or sets InsertItemLotOptionalFields 
        /// </summary>
        [EnumValue("InsertItemLotOptionalFields", typeof(ICCommonResx))]
        InsertItemLotOptionalFields = 7,

    }
}

