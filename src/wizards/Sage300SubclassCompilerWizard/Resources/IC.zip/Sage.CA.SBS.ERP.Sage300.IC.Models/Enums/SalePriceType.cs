// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for SalePriceType
    /// </summary>
    public enum SalePriceType
    {
        /// <summary>
        /// Gets or sets SalePriceForSingleUnitOfMeasure
        /// </summary>
        [EnumValue("SalePriceForSingle", typeof(ItemPricingResx))]
        SalePriceForSingleUnitOfMeasure = 1,

        /// <summary>
        /// Gets or sets SalePriceForMultipleUnitsOfMeasure
        /// </summary>
        [EnumValue("SalePriceForMultiple", typeof(ItemPricingResx))]
        SalePriceForMultipleUnitsOfMeasure = 2,

        /// <summary>
        /// Gets or sets SalePriceCalculatedUsingaCost
        /// </summary>
        [EnumValue("SalePriceCalc", typeof(ItemPricingResx))]
        SalePriceCalculatedUsingaCost = 3,
    }
}
