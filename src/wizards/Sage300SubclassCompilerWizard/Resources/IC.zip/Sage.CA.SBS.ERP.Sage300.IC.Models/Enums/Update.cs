// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for Update
	/// </summary>
	public enum Update
	{
		/// <summary>
		/// Gets or sets Components
		/// </summary>
        [EnumValue("Components", typeof(UpdateBillsOfMaterialResx))]
		Components = 1,

		/// <summary>
		/// Gets or sets Cost
		/// </summary>
        [EnumValue("Cost", typeof(UpdateBillsOfMaterialResx))]
		Cost = 2
	}
}
