﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for InternalUsageProcessCommand
    /// </summary>
    public enum InternalUsageProcessCommand
    {
        /// <summary>
        /// Gets or sets NothingToProcess
        /// </summary>
        [EnumValue("NothingToProcess", typeof(ICCommonResx))]
        NothingToProcess = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(ICCommonResx))]
        InsertOptionalFields = 1
    }
}
