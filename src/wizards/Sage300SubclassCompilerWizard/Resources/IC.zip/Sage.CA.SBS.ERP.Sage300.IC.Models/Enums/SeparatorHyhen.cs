// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum Separator Hyhen
    /// </summary>
    public enum SeparatorHyhen
    {
        /// <summary>
        /// Hyphen
        /// </summary>
        Hyphen = 1,
    }
}