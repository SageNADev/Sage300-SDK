// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
#endregion


namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Append to G Or L Batch
    /// </summary>
    public enum AppendToGOrLBatch
    {
        /// <summary>
        /// Adding to an Existing Batch
        /// </summary>
        [EnumValue("AddingToAnExistingBatch", typeof(GLIntegrationResx), 1)]
        AddingtoanExistingBatch = 1,

        /// <summary>
        /// Creating a New Batch
        /// </summary>
        [EnumValue("CreateNewBatch", typeof(GLIntegrationResx), 2)]
        CreatingaNewBatch = 0,

        /// <summary>
        /// Creating and Posting a New Batch
        /// </summary>
        [EnumValue("CreatePostNewBatch", typeof(GLIntegrationResx), 3)]
        CreatingandPostingaNewBatch = 2,
    }
}