﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum LotNumberHistoryTransType
    {
        #region enums

        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [EnumValue("Receipt", typeof(ICCommonResx))]
        Receipt = 1,

        /// <summary>
        /// Gets or sets ReceiptAdjustment
        /// </summary>
        [EnumValue("ReceiptAdjustment", typeof(SerialNumberResx))]
        ReceiptAdjustment = 2,

        /// <summary>
        /// Gets or sets ReceiptReturn
        /// </summary>
        [EnumValue("ReceiptReturn", typeof(SerialNumberResx))]
        ReceiptReturn = 3,

        /// <summary>
        /// Gets or sets Shipment
        /// </summary>
        [EnumValue("Shipment", typeof(ICCommonResx))]
        Shipment = 4,

        /// <summary>
        /// Gets or sets ShipmentReturn
        /// </summary>
        [EnumValue("ShipmentReturn", typeof(SerialNumberResx))]
        ShipmentReturn = 5,

        /// <summary>
        /// Gets or sets AdjustmentQuantityIncrease
        /// </summary>
        [EnumValue("AdjustmentQuantityIncrease", typeof(SerialNumberResx))]
        AdjustmentQuantityIncrease = 6,

        /// <summary>
        /// Gets or sets AdjustmentQuantityDecrease
        /// </summary>
        [EnumValue("AdjustmentQuantityDecrease", typeof(SerialNumberResx))]
        AdjustmentQuantityDecrease = 7,

        /// <summary>
        /// Gets or sets AdjustmentCostIncrease
        /// </summary>
        [EnumValue("AdjustmentCostIncrease", typeof(SerialNumberResx))]
        AdjustmentCostIncrease = 8,

        /// <summary>
        /// Gets or sets AdjustmentCostDecrease
        /// </summary>
        [EnumValue("AdjustmentCostDecrease", typeof(SerialNumberResx))]
        AdjustmentCostDecrease = 9,

        /// <summary>
        /// Gets or sets AdjustmentBothIncrease
        /// </summary>
        [EnumValue("AdjustmentBothIncrease", typeof(SerialNumberResx))]
        AdjustmentBothIncrease = 10,

        /// <summary>
        /// Gets or sets AdjustmentBothDecrease
        /// </summary>
        [EnumValue("AdjustmentBothDecrease", typeof(SerialNumberResx))]
        AdjustmentBothDecrease = 11,

        /// <summary>
        /// Gets or sets StockTransferFrom
        /// </summary>
        [EnumValue("StockTransferFrom", typeof(SerialNumberResx))]
        StockTransferFrom = 12,

        /// <summary>
        /// Gets or sets StockTransferTo
        /// </summary>
        [EnumValue("StockTransferTo", typeof(SerialNumberResx))]
        StockTransferTo = 13,

        /// <summary>
        /// Gets or sets MasterItemAssembly
        /// </summary>
        [EnumValue("MasterItemAssembly", typeof(SerialNumberResx))]
        MasterItemAssembly = 14,

        /// <summary>
        /// Gets or sets ComponentItemAssembly
        /// </summary>
        [EnumValue("ComponentItemAssembly", typeof(SerialNumberResx))]
        ComponentItemAssembly = 15,

        /// <summary>
        /// Gets or sets Invoice
        /// </summary>
        [EnumValue("Invoice", typeof(SerialNumberResx))]
        Invoice = 16,

        /// <summary>
        /// Gets or sets CreditNote
        /// </summary>
        [EnumValue("CreditNote", typeof(SerialNumberResx))]
        CreditNote = 17,

        /// <summary>
        /// Gets or sets DebitNote
        /// </summary>
        [EnumValue("DebitNote", typeof(SerialNumberResx))]
        DebitNote = 18,

        /// <summary>
        /// Gets or sets ShipmentAdjustment
        /// </summary>
        [EnumValue("ShipmentAdjustment", typeof(SerialNumberResx))]
        ShipmentAdjustment = 19,

        /// <summary>
        /// Gets or sets InternalUsage
        /// </summary>
        [EnumValue("InternalUsage", typeof(ICCommonResx))]
        InternalUsage = 20,

        /// <summary>
        /// Gets or sets LotRecall
        /// </summary>
        [EnumValue("LotRecall", typeof(LotNumberResx))]
        LotRecall = 100,

        /// <summary>
        /// Gets or sets LotRecallRelease
        /// </summary>
        [EnumValue("LotRecallRelease", typeof(LotNumberResx))]
        LotRecallRelease = 111,

        /// <summary>
        /// Gets or sets LotCombine
        /// </summary>
        [EnumValue("LotCombine", typeof(LotNumberResx))]
        LotCombine = 112,

        /// <summary>
        /// Gets or sets LotSplit
        /// </summary>
        [EnumValue("LotSplit", typeof(LotNumberResx))]
        LotSplit = 113,

        /// <summary>
        /// Gets or sets LotReceipt
        /// </summary>
        [EnumValue("LotReceipt", typeof(LotNumberResx))]
        LotReceipt = 114,

        /// <summary>
        /// Gets or sets LotShipment
        /// </summary>
        [EnumValue("LotShipment", typeof(LotNumberResx))]
        LotShipment = 115,

        /// <summary>
        /// Gets or sets LotOEInvoice
        /// </summary>
        [EnumValue("LotOEInvoice", typeof(LotNumberResx))]
        LotOEInvoice = 118,

        /// <summary>
        /// Gets or sets LotPOInvoice
        /// </summary>
        [EnumValue("LotPOInvoice", typeof(LotNumberResx))]
        LotPOInvoice = 119

        #endregion
    }
}   