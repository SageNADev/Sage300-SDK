// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{

    #region Public Enum ContractPeriod3 Lifetime

    /// <summary>
    /// Enum for Contract Period3Lifetime
    /// </summary>
    public enum ContractPeriod3Lifetime
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        [EnumValue("No", typeof (EnumerationsResx))] No = 0,

        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [EnumValue("Yes", typeof (EnumerationsResx))] Yes = 1
    }

    #endregion
}
