// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Statistics Period
    /// </summary>
    public enum StatisticsPeriod
    {
        /// <summary>
        /// Weekly 
        /// </summary>
        [EnumValue("Weekly", typeof (ICCommonResx))] Weekly = 1,

        /// <summary>
        /// SevenDays 
        /// </summary>
        [EnumValue("SevenDays", typeof (ICCommonResx))] SevenDays = 2,

        /// <summary>
        /// Biweekly 
        /// </summary>
        [EnumValue("Biweekly", typeof (ICCommonResx))] Biweekly = 3,

        /// <summary>
        /// FourWeeks 
        /// </summary>
        [EnumValue("FourWeeks", typeof (ICCommonResx))] FourWeeks = 4,

        /// <summary>
        /// Monthly 
        /// </summary>
        [EnumValue("Monthly", typeof (ICCommonResx))] Monthly = 5,

        /// <summary>
        /// Bimonthly 
        /// </summary>
        [EnumValue("Bimonthly", typeof (ICCommonResx))] Bimonthly = 6,

        /// <summary>
        /// Quarterly 
        /// </summary>
        [EnumValue("Quarterly", typeof (ICCommonResx))] Quarterly = 7,

        /// <summary>
        /// Semiannually 
        /// </summary>
        [EnumValue("Semiannually", typeof (ICCommonResx))] Semiannually = 8,

        /// <summary>
        /// Annually 
        /// </summary>
        [EnumValue("Annually", typeof (ICCommonResx))] Annually = 9,

        /// <summary>
        /// FiscalPeriod 
        /// </summary>
        [EnumValue("FiscalPeriod", typeof (CommonResx))] FiscalPeriod = 10,
    }
}