// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for BasePriceType
     /// </summary>
    public enum BasePriceType
    {
        /// <summary>
        /// Gets or sets BasePriceForSingleUnitOfMeasure
        /// </summary>
        [EnumValue("BasePriceForSingle", typeof(ItemPricingResx))]
        BasePriceForSingleUnitOfMeasure = 1,

        /// <summary>
        /// Gets or sets BasePriceForMultipleUnitsOfMeasure
        /// </summary>
        [EnumValue("BasePriceForMultiple", typeof(ItemPricingResx))]
        BasePriceForMultipleUnitsOfMeasure = 2,

        /// <summary>
        /// Gets or sets BasePriceCalculatedUsingaCost
        /// </summary>
        [EnumValue("BasePriceCalc", typeof(ItemPricingResx))]
        BasePriceCalculatedUsingaCost = 3,
    }
}
