// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum ReconciliationTransactionType
    {
        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [EnumValue("Receipt", typeof(ICCommonResx))]
        Receipt = 0,

        /// <summary>
        /// Gets or sets Shipment
        /// </summary>
        [EnumValue("Shipment", typeof(ICCommonResx))]
        Shipment = 1,

        /// <summary>
        /// Gets or sets OEInvoice
        /// </summary>
        [EnumValue("OEInvoice", typeof(SerialLotReconciliationsResx))]
        OEInvoice = 2,

        /// <summary>
        /// Gets or sets POInvoice
        /// </summary>
        [EnumValue("POInvoice", typeof(SerialLotReconciliationsResx))]
        POInvoice = 3
    }
}
