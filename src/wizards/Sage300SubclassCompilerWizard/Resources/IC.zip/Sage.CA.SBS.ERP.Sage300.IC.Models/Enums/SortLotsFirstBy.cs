// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for SortLotsFirstBy
    /// </summary>
    public enum SortLotsFirstBy
    {
        /// <summary>
        /// Gets or sets Earliest
        /// </summary>
        [EnumValue("Earliest", typeof(OptionsResx))]
        Earliest = 1,
        /// <summary>
        /// Gets or sets Latest
        /// </summary>
        [EnumValue("Latest", typeof(OptionsResx))]
        Latest = 2
    }
}