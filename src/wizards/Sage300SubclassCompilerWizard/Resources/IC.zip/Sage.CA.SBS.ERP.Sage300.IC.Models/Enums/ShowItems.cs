// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
    /// <summary>
    /// Enum for ShowItems
    /// </summary>
    public enum ShowItems
    {
        /// <summary>
        /// Gets or sets AllItemsFromInventoryList
        /// </summary>
        [EnumValue("AllItemsFromInventoryList", typeof(GenerateInventoryWorksheetResx))]
        AllItemsFromInventoryList = 1,

        /// <summary>
        /// Gets or sets ItemsFromLocationOnly
        /// </summary>
        [EnumValue("ItemsFromLocationOnly", typeof(GenerateInventoryWorksheetResx))]
        ItemsFromLocationOnly = 2,

        /// <summary>
        /// Gets or sets InUseItemsOnly
        /// </summary>
        [EnumValue("InUseItemsOnly", typeof(GenerateInventoryWorksheetResx))]
        InUseItemsOnly = 3
    }
}
