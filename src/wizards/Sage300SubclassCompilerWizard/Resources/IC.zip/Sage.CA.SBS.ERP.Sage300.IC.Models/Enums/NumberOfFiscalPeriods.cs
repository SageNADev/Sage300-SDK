// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for NumberOfFiscalPeriods
     /// </summary>
     public enum NumberOfFiscalPeriods
     {
          /// <summary>
          /// Gets or sets Num12
          /// </summary>
          Num12 = 12,
          /// <summary>
          /// Gets or sets Num13
          /// </summary>
          Num13 = 13,
     }
}
