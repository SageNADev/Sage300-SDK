// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Separator Left Bracket
    /// </summary>
    public enum SeparatorLeftBracket
    {
        /// <summary>
        /// Left Bracket
        /// </summary>
        LeftBracket = 1,
    }
}