// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for Using
	/// </summary>
	public enum Using
	{
		/// <summary>
		/// Gets or sets Amount
		/// </summary>
        [EnumValue("Amount", typeof(UpdateBillsOfMaterialResx))]
		Amount = 1,

		/// <summary>
		/// Gets or sets Percentage
		/// </summary>
        [EnumValue("Percentage", typeof(UpdateBillsOfMaterialResx))]
		Percentage = 2
	}
}
