 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
    /// Enum for Allowed 
    /// </summary>
	public enum Allowed 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        [EnumValue("No", typeof(EnumerationsResx))]
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>
        [EnumValue("Yes", typeof(EnumerationsResx))]	
        Yes = 1,
	}
}
