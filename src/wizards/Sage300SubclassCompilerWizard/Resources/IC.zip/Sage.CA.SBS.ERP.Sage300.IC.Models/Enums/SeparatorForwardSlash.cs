// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Enum for Separator Forward Slash
    /// </summary>
    public enum SeparatorForwardSlash
    {
        /// <summary>
        /// Or Forward Slash
        /// </summary>
        OrForwardSlash = 1,
    }
}