// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum AssembliesTransactionType
    {
        /// <summary>
        /// Gets or sets Assembly
        /// </summary>
        [EnumValue("Assembly", typeof(ICCommonResx))]
        Assembly = 1,

        /// <summary>
        /// Gets or sets Disassembly
        /// </summary>
        [EnumValue("Disassembly", typeof(ICCommonResx))]
        Disassembly = 2
    }
}
