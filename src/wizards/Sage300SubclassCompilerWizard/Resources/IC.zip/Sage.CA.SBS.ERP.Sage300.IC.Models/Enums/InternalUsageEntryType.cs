// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for EntryType
    /// </summary>
    public enum InternalUsageEntryType
    {
        /// <summary>
        /// Gets or sets InternalUsage
        /// </summary>
        [EnumValue("InternalUsage", typeof(ICCommonResx))]
        InternalUsage = 1,

        /// <summary>
        /// Gets or sets Return
        /// </summary>
        [EnumValue("Return", typeof(ICCommonResx))]
        Return = 2
    }
}
