// /* Copyright (c) 1994-2026 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Lots by
    /// </summary>
    public enum SortLotsby
    {
        /// <summary>
        /// Lot Number
        /// </summary>
        [EnumValue("LotNumber", typeof(ICCommonResx), 0)]
        LotNumber = 1,

        /// <summary>
        /// Stock Date
        /// </summary>
        [EnumValue("StockDate", typeof(ICCommonResx), 0)]
        StockDate = 2,

        /// <summary>
        /// Expiry Date
        /// </summary>
        [EnumValue("ExpiryDate", typeof(ICCommonResx), 0)]
        ExpiryDate = 3,
    }
}