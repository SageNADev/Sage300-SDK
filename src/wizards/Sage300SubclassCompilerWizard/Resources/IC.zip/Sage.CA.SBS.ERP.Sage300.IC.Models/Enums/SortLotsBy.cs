// /* Copyright (c) 1994-2026 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Lots by
    /// </summary>
    public enum SortLotsby
    {
        /// <summary>
        /// Lot Number
        /// </summary>
        [EnumValue("LotNumber", typeof(OptionsResx), 0)]
        LotNumber = 1,

        /// <summary>
        /// Stock Date
        /// </summary>
        [EnumValue("StockDate", typeof(OptionsResx), 0)]
        StockDate = 2,

        /// <summary>
        /// Expiry Date
        /// </summary>
        [EnumValue("ExpiryDate", typeof(OptionsResx), 0)]
        ExpiryDate = 3,
    }
}