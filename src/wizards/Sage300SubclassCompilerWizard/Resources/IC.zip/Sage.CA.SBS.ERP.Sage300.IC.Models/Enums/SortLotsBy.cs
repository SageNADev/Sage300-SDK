// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Lots by
    /// </summary>
    public enum SortLotsby
    {
        /// <summary>
        /// Lot Number 
        /// </summary>
        LotNumber = 1,

        /// <summary>
        /// Stock Date 
        /// </summary>
        StockDate = 2,

        /// <summary>
        /// Expiry Date 
        /// </summary>
        ExpiryDate = 3,
    }
}