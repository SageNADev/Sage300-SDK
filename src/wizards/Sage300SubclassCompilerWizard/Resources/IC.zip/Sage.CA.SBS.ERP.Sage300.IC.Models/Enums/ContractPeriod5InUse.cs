// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{

    #region Public Enum ContractPeriod5 InUse

    /// <summary>
    /// Enum for ContractPeriod5 InUse
    /// </summary>
    public enum ContractPeriod5InUse
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        [EnumValue("No", typeof (EnumerationsResx))] No = 0,

        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [EnumValue("Yes", typeof (EnumerationsResx))] Yes = 1
    }

    #endregion
}
