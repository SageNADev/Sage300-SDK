// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for SegmentNumber
    /// </summary>
    public enum SegmentNumber
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(EnumerationsResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [EnumValue("Category", typeof(ICCommonResx))]
        Category = 1,

        /// <summary>
        /// Gets or sets Style
        /// </summary>
        [EnumValue("Style", typeof(ReorderReportResx))]
        Style = 2,

        /// <summary>
        /// Gets or sets Color
        /// </summary>
        [EnumValue("Color", typeof(InventoryWorksheetResx))]
        Color = 3,

        /// <summary>
        /// Gets or sets Model
        /// </summary>
        [EnumValue("Model", typeof(ReorderReportResx))]
        Model = 4,

        /// <summary>
        /// Gets or sets Series
        /// </summary>
        [EnumValue("Series", typeof(ReorderReportResx))]
        Series = 5,

        /// <summary>
        /// Gets or sets Long
        /// </summary>
        [EnumValue("Long", typeof(ReorderReportResx))]
        Long = 6,
    }
}
