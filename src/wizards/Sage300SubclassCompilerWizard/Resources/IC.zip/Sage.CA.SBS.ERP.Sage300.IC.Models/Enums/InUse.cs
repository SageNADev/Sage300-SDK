// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for InUse
	/// </summary>
	public enum InUse
	{
		/// <summary>
		/// Gets or sets No
		/// </summary>
        [EnumValue("No", typeof(EnumerationsResx))]
		No = 1,

		/// <summary>
		/// Gets or sets Yes
		/// </summary>
        [EnumValue("Yes", typeof(EnumerationsResx))]
		Yes = 0
	}
}
