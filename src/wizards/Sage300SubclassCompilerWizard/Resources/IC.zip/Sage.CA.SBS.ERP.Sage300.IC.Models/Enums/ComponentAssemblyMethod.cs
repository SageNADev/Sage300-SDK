// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for ComponentAssemblyMethod
	/// </summary>
	public enum ComponentAssemblyMethod
	{
		/// <summary>
		/// Gets or sets None
		/// </summary>
		[EnumValue("None", typeof(ICCommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets AllComponentMasterItems
		/// </summary>
        [EnumValue("AllComponentMasterItems", typeof(AssembliesDisassembliesResx))]
		AllComponentMasterItems = 1,

		/// <summary>
		/// Gets or sets ComponentMasterItemswithInsufficientQuantity
		/// </summary>
        [EnumValue("ComponentMasterItemswithInsufficientQuantity", typeof(AssembliesDisassembliesResx))]
		ComponentMasterItemswithInsufficientQuantity = 2
	}
}
