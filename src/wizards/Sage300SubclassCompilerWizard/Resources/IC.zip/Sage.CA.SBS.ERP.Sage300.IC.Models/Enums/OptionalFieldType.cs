﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Type 
    /// </summary>
    public enum OptionalFieldType
    {
        /// <summary>
        /// Gets or sets Text 
        /// </summary>
        [EnumValue("Text", typeof(ICCommonResx))]
        Text = 1,
        /// <summary>
        /// Gets or sets Amount 
        /// </summary>
        [EnumValue("Amount", typeof(ICCommonResx))]
        Amount = 100,
        /// <summary>
        /// Gets or sets Number 
        /// </summary>
         [EnumValue("Number", typeof(ICCommonResx))]
        Number = 6,
        /// <summary>
        /// Gets or sets Integer 
        /// </summary>
        [EnumValue("Integer", typeof(ICCommonResx))]
        Integer = 8,
        /// <summary>
        /// Gets or sets YesOrNo 
        /// </summary>
       [EnumValue("YesOrNo", typeof(ICCommonResx))]
        YesOrNo = 9,
        /// <summary>
        /// Gets or sets Date 
        /// </summary>
        [EnumValue("Date", typeof(CommonResx))]
        Date = 3,
        /// <summary>
        /// Gets or sets Time 
        /// </summary>
        [EnumValue("Time", typeof(ICCommonResx))]
        Time = 4,
    }
}
