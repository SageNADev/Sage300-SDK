// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for SerialNumbers
    /// </summary>
    public enum SerialNumbers
    {
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("No", typeof(EnumerationsResx))]
        No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("Yes", typeof(EnumerationsResx))]
        Yes = 1
    }
}
