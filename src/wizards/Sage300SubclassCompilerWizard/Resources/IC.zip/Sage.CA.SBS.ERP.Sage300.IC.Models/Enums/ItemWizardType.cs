﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Item Wizard Enum
    /// </summary>
    public enum ItemWizardType
    {
        /// <summary>
        /// The welcome
        /// </summary>
        Welcome = 0,

        /// <summary>
        /// The item basic
        /// </summary>
        ItemBasic = 1,

        /// <summary>
        /// The item unit
        /// </summary>
        ItemUnit = 2,

        /// <summary>
        /// The items taxes
        /// </summary>
        ItemsTaxes = 3,

        /// <summary>
        /// The serial number options
        /// </summary>
        SerialNumberOptions = 4,

        /// <summary>
        /// The lotnumber options
        /// </summary>
        LotnumberOptions = 5,

        /// <summary>
        /// The location details
        /// </summary>
        LocationDetails = 6,

        /// <summary>
        /// The vendor details
        /// </summary>
        VendorDetails = 7,

        /// <summary>
        /// The item pricing
        /// </summary>
        ItemPricing = 8,

        /// <summary>
        /// The item contract pricing
        /// </summary>
        ItemContractPricing = 9,

        /// <summary>
        /// The manufacturers item
        /// </summary>
        ManufacturersItem = 10,

        /// <summary>
        /// The customer item number
        /// </summary>
        CustomerItemNumber = 11,

        /// <summary>
        /// The bill of materials
        /// </summary>
        BillOfMaterials = 12,

        /// <summary>
        /// The kitting items
        /// </summary>
        KittingItems = 13,

        /// <summary>
        /// The reorder quantities
        /// </summary>
        ReorderQuantities = 14,

        /// <summary>
        /// The add itemlist information
        /// </summary>
        AddItemSummary = 15,

        /// <summary>
        /// The add item completed
        /// </summary>
        AddItemCompleted = 16,
    }
}