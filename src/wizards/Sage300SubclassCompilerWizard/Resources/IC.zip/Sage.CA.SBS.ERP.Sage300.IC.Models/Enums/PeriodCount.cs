﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for PeriodCount
    /// </summary>
    public enum PeriodCount
    {
        /// <summary>
        /// Gets Bimonthly
        /// </summary>
        Bimonthly = 6,

        /// <summary>
        /// Gets Weekly
        /// </summary>
        Weekly = 53,

        /// <summary>
        /// Gets Sevendays
        /// </summary>
        Sevendays = 53,

        /// <summary>
        /// Gets Semiannually
        /// </summary>
        Semiannually = 2,

        /// <summary>
        /// Gets Quarterly
        /// </summary>
        Quarterly = 4,

        /// <summary>
        /// Gets Monthly
        /// </summary>
        Monthly = 12,

        /// <summary>
        /// Gets Fourweeks
        /// </summary>
        Fourweeks = 14,

        /// <summary>
        /// Gets Biweekly
        /// </summary>
        Biweekly = 27,

        /// <summary>
        /// Gets Semiannually
        /// </summary>
        Annually = 1,

    }
}
