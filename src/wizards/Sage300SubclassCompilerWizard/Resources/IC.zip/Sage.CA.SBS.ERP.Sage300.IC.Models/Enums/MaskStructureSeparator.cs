// Copyright (c) 2026 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Separator
    /// </summary>
    public enum MaskStructureSeparator
    {
        
        /// <summary>
        /// None
        /// </summary>
        [EnumValue("None", typeof(CommonResx))]
        None = 1,
        /// <summary>
        /// "-" Hyphen
        /// </summary>
        [EnumValue("SymbolHyphen", typeof(CommonResx))]
        Hyphen = 2,
        /// <summary>
        /// "/" Forward Slash
        /// </summary>
        [EnumValue("SymbolForwardSlash", typeof(CommonResx))]
        ForwardSlash = 3,
        /// <summary>
        /// "|" Back Slash
        /// </summary>
        [EnumValue("SymbolBackslash", typeof(CommonResx))]
        BackSlash = 4,
        /// <summary>
        /// "*" Asterisk
        /// </summary>
        [EnumValue("SymbolAsterisk", typeof(CommonResx))]
        Asterisk = 5,
        /// <summary>
        /// "." Period
        /// </summary>
        [EnumValue("SymbolPeriod", typeof(CommonResx))]
        Period = 6,
        /// <summary>
        /// "(" Left Parenthesis
        /// </summary>
        [EnumValue("SymbolLeftParenthesis", typeof(CommonResx))]
        LeftParenthesis = 7,

        /// <summary>
        /// ")" Right Parenthesis
        /// </summary>
        [EnumValue("SymbolRightParenthesis", typeof(CommonResx))]
        RightParenthesis = 8,
        /// <summary>
        /// "#" Number Sign
        /// </summary>
        [EnumValue("SymbolNumberSign", typeof(CommonResx))]
        NumberSign = 9,
        /// <summary>
        /// "[" Left Bracket
        /// </summary>
        [EnumValue("LeftBracket", typeof(MaskStructureResx))]
        LeftBracket = 10,
        /// <summary>
        /// "]" Right Bracket
        /// </summary>
        [EnumValue("RightBracket", typeof(MaskStructureResx))]
        RightBracket = 11,
        /// <summary>
        /// "{" Left Brace
        /// </summary>

        [EnumValue("SymbolLeftBracket", typeof(CommonResx))]
        LeftBrace = 12,
        /// <summary>
        /// "}" Right Brace
        /// </summary>
        [EnumValue("SymbolRightBracket", typeof(CommonResx))]
        RightBrace = 13,

     

    }
}

