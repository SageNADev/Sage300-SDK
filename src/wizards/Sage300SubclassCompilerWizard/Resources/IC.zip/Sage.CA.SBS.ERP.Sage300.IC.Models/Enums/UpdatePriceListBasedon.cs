// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for UpdatePriceListBasedon
	/// </summary>
	public enum UpdatePriceListBasedon
	{
		/// <summary>
		/// Gets or sets Percentage
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Percentag", typeof(ICCommonResx))]
		Percentage = 1,

		/// <summary>
		/// Gets or sets Amount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Amount", typeof(ICCommonResx))]
		Amount = 2,

		/// <summary>
		/// Gets or sets Markup
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Markup", typeof(ICCommonResx))]
		Markup = 3,

		/// <summary>
		/// Gets or sets Margin
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("Margin", typeof(ICCommonResx))]
		Margin = 4,

		/// <summary>
		/// Gets or sets ExchangeRate
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ExchangeRate", typeof(ICCommonResx))]
		ExchangeRate = 5
	}
}
