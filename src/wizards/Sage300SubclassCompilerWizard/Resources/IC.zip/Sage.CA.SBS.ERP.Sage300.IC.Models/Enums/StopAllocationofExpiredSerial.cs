// /* Copyright (c) 1994-2026 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    public enum StopAllocationofExpiredSerial
    {
        [EnumValue("None", typeof(ICCommonResx), 0)]
        None = 0,

        [EnumValue("Warning", typeof(ICCommonResx), 1)]
        Warning = 1,

        [EnumValue("Error", typeof(ICCommonResx), 2)]
        Error = 2
    }
}