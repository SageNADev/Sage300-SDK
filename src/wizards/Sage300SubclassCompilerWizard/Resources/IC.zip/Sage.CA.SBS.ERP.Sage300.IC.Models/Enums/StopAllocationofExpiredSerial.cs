// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Stop Allocation of Expired Seria
    /// </summary>
    public enum StopAllocationofExpiredSerial
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,

        /// <summary>
        /// Warning
        /// </summary>
        Warning = 1,

        /// <summary>
        /// Error
        /// </summary>
        Error = 2,
    }
}