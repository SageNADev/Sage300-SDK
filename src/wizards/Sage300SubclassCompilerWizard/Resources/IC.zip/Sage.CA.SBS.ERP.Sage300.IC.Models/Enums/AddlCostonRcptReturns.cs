// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Add costing recipt returns
    /// </summary>
    public enum AddlCostonRcptReturns
    {
        /// <summary>
        /// Leave
        /// </summary>
        [EnumValue("Leave", typeof (ICCommonResx))] Leave = 1,

        /// <summary>
        /// Prorate
        /// </summary>
        [EnumValue("Prorate", typeof (ICCommonResx))] Prorate = 2,
    }
}