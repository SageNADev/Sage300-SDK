// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    ///Enum for Statistics Calendar
    /// </summary>
    public enum StatisticsCalendar
    {
        /// <summary>
        /// Calendar Year 
        /// </summary>
        [EnumValue("CalendarYear", typeof (ICCommonResx))] CalendarYear = 1,

        /// <summary>
        /// Fiscal Year 
        /// </summary>
        [EnumValue("FiscalYear", typeof (CommonResx))] FiscalYear = 2,
    }
}