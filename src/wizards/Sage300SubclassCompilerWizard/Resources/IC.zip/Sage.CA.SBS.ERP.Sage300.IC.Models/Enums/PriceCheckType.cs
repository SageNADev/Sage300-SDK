// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for PriceCheckType 
    /// </summary>
    public enum PriceCheckType
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(ICCommonResx))]
        None = 0,

        /// <summary>
        /// Gets or sets Warning 
        /// </summary>	
        [EnumValue("Warning", typeof(ICCommonResx))]
        Warning = 1,

        /// <summary>
        /// Gets or sets Error 
        /// </summary>	
        [EnumValue("Error", typeof(ICCommonResx))]
        Error = 2,

        /// <summary>
        /// Gets or sets Approval 
        /// </summary>	
        [EnumValue("Approval", typeof(ICCommonResx))]
        Approval = 3,
    }
}
