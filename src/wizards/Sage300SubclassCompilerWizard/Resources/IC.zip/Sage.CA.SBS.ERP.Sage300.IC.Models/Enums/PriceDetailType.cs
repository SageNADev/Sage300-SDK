// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for PriceDetailType
     /// </summary>
     public enum PriceDetailType
     {
          /// <summary>
          /// Gets or sets BasePriceQuantity
          /// </summary>
          BasePriceQuantity = 1,
          /// <summary>
          /// Gets or sets SalePriceQuantity
          /// </summary>
          SalePriceQuantity = 2,
          /// <summary>
          /// Gets or sets BasePriceWeight
          /// </summary>
          BasePriceWeight = 3,
          /// <summary>
          /// Gets or sets SalePriceWeight
          /// </summary>
          SalePriceWeight = 4,
          /// <summary>
          /// Gets or sets BasePriceUsingCost
          /// </summary>
          BasePriceUsingCost = 5,
          /// <summary>
          /// Gets or sets SalePriceUsingCost
          /// </summary>
          SalePriceUsingCost = 6,
     }
}
