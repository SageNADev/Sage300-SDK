// /* Copyright (c) 1994-2026 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Serials First by
    /// </summary>
    public enum SortSerialsFirstby
    {
        /// <summary>
        /// Earliest 
        /// </summary>
        [EnumValue("Earliest", typeof(OptionsResx), 0)]
        Earliest = 1,

        /// <summary>
        /// Latest
        /// </summary>
        [EnumValue("Latest", typeof(OptionsResx), 0)]
        Latest = 2,
    }
}