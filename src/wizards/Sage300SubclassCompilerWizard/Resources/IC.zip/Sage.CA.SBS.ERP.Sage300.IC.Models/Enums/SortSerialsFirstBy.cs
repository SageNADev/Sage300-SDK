// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Serials First by
    /// </summary>
    public enum SortSerialsFirstby
    {
        /// <summary>
        /// Earliest 
        /// </summary>
        Earliest = 1,

        /// <summary>
        /// Latest
        /// </summary>
        Latest = 2,
    }
}