﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand
    /// </summary>
    public enum ProcessCommand
    {
        /// <summary>
        /// Gets or sets NothingtoProcess 
        /// </summary>
        [EnumValue("NothingToProcess", typeof(ICCommonResx))]
        NothingToProcess = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(ICCommonResx))]
        InsertOptionalFields = 1,

        /// <summary>
        /// Gets or sets DefaultAndTranferOptionalFields
        /// </summary>
        DefaultAndTranferOptionalFields = 2,
        /// <summary>
        /// Gets or sets DefaultOptFieldsDuringRecordGeneration
        /// </summary>
        [EnumValue("DefaultOptFieldsDuringRecordGeneration", typeof(InventoryWorksheetResx))]
        DefaultOptFieldsDuringRecordGeneration = 3,

        /// <summary>
        /// Gets or sets InsertItemSerialOptionalFields 
        /// </summary>
        [EnumValue("InsertItemSerialOptionalFields", typeof(ICCommonResx))]
        InsertItemSerialOptionalFields = 6,
        /// <summary>
        /// Gets or sets InsertItemLotOptionalFields 
        /// </summary>
        [EnumValue("InsertItemLotOptionalFields", typeof(ICCommonResx))]
        InsertItemLotOptionalFields = 7,

        /// <summary>
        /// Gets or sets AutogenerateSerials
        /// </summary>
        AutogenerateSerials = 21,
        /// <summary>
        /// Gets or sets AutogenerateLots
        /// </summary>
        AutogenerateLots = 22,
        /// <summary>
        /// Gets or sets AutoallocateSerials
        /// </summary>
        AutoallocateSerials = 23,
        /// <summary>
        /// Gets or sets AutoallocateLots
        /// </summary>
        AutoallocateLots = 24,
        /// <summary>
        /// Gets or sets ClearSerials
        /// </summary>
        ClearSerials = 25,
        /// <summary>
        /// Gets or sets ClearLots
        /// </summary>
        ClearLots = 26,
        /// <summary>
        /// Gets or sets PostSerialsLotsToICInventory
        /// </summary>
        PostSerialsLotsToICInventory = 31,
    }
}
