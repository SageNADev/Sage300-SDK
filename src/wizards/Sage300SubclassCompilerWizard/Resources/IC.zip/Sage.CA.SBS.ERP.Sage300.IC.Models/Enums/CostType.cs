// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for CostType
	/// </summary>
	public enum CostType
	{
		/// <summary>
		/// Gets or sets FixedCost
		/// </summary>
        [EnumValue("FixedCost", typeof(UpdateBillsOfMaterialResx))]
		FixedCost = 1,

		/// <summary>
		/// Gets or sets VariableCost
		/// </summary>
        [EnumValue("VariableCost", typeof(UpdateBillsOfMaterialResx))]
		VariableCost = 2
	}
}
