// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for ComponentType
	/// </summary>
	public enum ComponentType
	{
		/// <summary>
		/// Gets or sets Replace
		/// </summary>
        [EnumValue("Replace", typeof(UpdateBillsOfMaterialResx))]
		Replace = 1,

		/// <summary>
		/// Gets or sets Add
		/// </summary>
        [EnumValue("Add", typeof(UpdateBillsOfMaterialResx))]
		Add = 2,

		/// <summary>
		/// Gets or sets Remove
		/// </summary>
        [EnumValue("Remove", typeof(UpdateBillsOfMaterialResx))]
		Remove = 3
	}
}
