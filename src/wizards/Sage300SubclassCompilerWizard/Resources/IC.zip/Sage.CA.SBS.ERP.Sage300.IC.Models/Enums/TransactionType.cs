// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// Gets or sets QuantityIncrease
        /// </summary>
        [EnumValue("QuantityIncrease", typeof(AdjustmentResx))]
        QuantityIncrease = 1,
        /// <summary>
        /// Gets or sets QuantityDecrease
        /// </summary>
        [EnumValue("QuantityDecrease", typeof(AdjustmentResx))]
        QuantityDecrease = 2,
        /// <summary>
        /// Gets or sets CostIncrease
        /// </summary>
        [EnumValue("CostIncrease", typeof(AdjustmentResx))]
        CostIncrease = 3,
        /// <summary>
        /// Gets or sets CostDecrease
        /// </summary>
        [EnumValue("CostDecrease", typeof(AdjustmentResx))]
        CostDecrease = 4,
        /// <summary>
        /// Gets or sets BothIncrease
        /// </summary>
        [EnumValue("BothIncrease", typeof(AdjustmentResx))]
        BothIncrease = 5,
        /// <summary>
        /// Gets or sets BothDecrease
        /// </summary>
        [EnumValue("BothDecrease", typeof(AdjustmentResx))]
        BothDecrease = 6,
    }
}
