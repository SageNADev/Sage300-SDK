// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for CostOrMarginBase 
    /// </summary>
    public enum CostOrMarginBase
    {
        /// <summary>
        /// Gets or sets MarkupCost 
        /// </summary>	
        [EnumValue("MarkupCost", typeof(ICCommonResx))]
        MarkupCost = 1,

        /// <summary>
        /// Gets or sets StandardCost 
        /// </summary>	
        [EnumValue("StandardCost", typeof(ICCommonResx))]
        StandardCost = 2,

        /// <summary>
        /// Gets or sets MostRecentCost 
        /// </summary>	
        [EnumValue("MostRecentCost", typeof(ICCommonResx))]
        MostRecentCost = 3,

        /// <summary>
        /// Gets or sets AverageCost 
        /// </summary>	
        [EnumValue("AverageCost", typeof(ICCommonResx))]
        AverageCost = 4,

        /// <summary>
        /// Gets or sets LastCost 
        /// </summary>	
        [EnumValue("LastCost", typeof(ICCommonResx))]
        LastCost = 5,

        /// <summary>
        /// Gets or sets Cost1Name
        /// </summary>
        Cost1Name = 6,

        /// <summary>
        /// Gets or sets Cost2Name
        /// </summary>
        Cost2Name = 7,
    }
}
