// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Consolidate G/L batch
    /// </summary>
    public enum ConsolidateGOrLBatch
    {
        /// <summary>
        /// Donot consolidate
        /// </summary>
        [EnumValue("DoNotConsolidate", typeof(GLIntegrationResx), 1)]        
        DoNotConsolidate = 1,

        /// <summary>
        /// Consolidate Transaction Details by Account
        /// </summary>
        [EnumValue("ConsolidateTransDetByAcc", typeof(GLIntegrationResx), 2)]
        ConsolidateTransactionDetailsbyAccount = 9,

        /// <summary>
        /// Consolidate by Account and Fiscal Period
        /// </summary>
        [EnumValue("ConsolidateByAccandFisc", typeof(GLIntegrationResx), 3)]
        ConsolidatebyAccountandFiscalPeriod = 2,

        /// <summary>
        /// Consolidate by Account Fiscal Period and Source
        /// </summary>
        [EnumValue("ConsolidatebyAccFiscandSource", typeof(GLIntegrationResx), 4)]
        ConsolidatebyAccountFiscalPeriodandSource = 3,
    }
}