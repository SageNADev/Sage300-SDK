 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
    /// Enum for PriceType 
    /// </summary>
	public enum PriceType 
	{
			/// <summary>
		/// Gets or sets CustomerType 
		/// </summary>	
        [EnumValue("CustomerType", typeof(ICCommonResx))]
        CustomerType = 1,
		/// <summary>
		/// Gets or sets DiscountPercentage 
		/// </summary>	
        [EnumValue("DiscountPercentage", typeof(ICCommonResx))]
        DiscountPercentage = 2,
		/// <summary>
		/// Gets or sets DiscountAmount 
		/// </summary>	
        [EnumValue("DiscountAmount", typeof(ICCommonResx))]
        DiscountAmount = 3,
		/// <summary>
		/// Gets or sets CostPlusaPercentage 
		/// </summary>	
        [EnumValue("CostPlusaPercentage", typeof(ICCommonResx))]
        CostPlusaPercentage = 4,
		/// <summary>
		/// Gets or sets CostPlusFixedAmount 
		/// </summary>	
        [EnumValue("CostPlusFixedAmount", typeof(ICCommonResx))]
        CostPlusFixedAmount = 5,
		/// <summary>
		/// Gets or sets FixedPrice 
		/// </summary>	
        [EnumValue("FixedPrice", typeof(ICCommonResx))]
        FixedPrice = 6,
	}
}
