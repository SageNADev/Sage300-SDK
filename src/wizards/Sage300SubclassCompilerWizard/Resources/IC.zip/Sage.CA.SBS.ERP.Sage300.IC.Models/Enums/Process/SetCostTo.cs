// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for SetCostTo
	/// </summary>
	public enum SetCostTo
	{
		/// <summary>
		/// Gets or sets StandardCost
		/// </summary>
        [EnumValue("StandardCost", typeof(ICCommonResx))]
		StandardCost = 0,

		/// <summary>
		/// Gets or sets MostRecentCost
		/// </summary>
        [EnumValue("MostRecentCost", typeof(ICCommonResx))]
		MostRecentCost = 1,

		/// <summary>
		/// Gets or sets LastUnitCost
		/// </summary>
        [EnumValue("LastUnitCost", typeof(ICCommonResx))]
		LastUnitCost = 2,
	}
}
