// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for DefaultCalculateRateExists
	/// </summary>
	public enum DefaultCalculateRateExists
	{
		/// <summary>
		/// Gets or sets Ratedoesnotexist
		/// </summary>
        [EnumValue("Ratedoesnotexist", typeof(CopyItemPricingResx))]
		Ratedoesnotexist = 0,

		/// <summary>
		/// Gets or sets Rateexists
		/// </summary>
        [EnumValue("Rateexists", typeof(CopyItemPricingResx))]
		Rateexists = 1,

		/// <summary>
		/// Gets or sets RateIscalculated
		/// </summary>
        [EnumValue("RateIscalculated", typeof(CopyItemPricingResx))]
		RateIscalculated = 2
	}
}
