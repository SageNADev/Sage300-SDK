// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for DefaultCalculateRateOperator
	/// </summary>
	public enum DefaultCalculateRateOperator
	{
		/// <summary>
		/// Gets or sets Multiply
		/// </summary>
        [EnumValue("Multiply", typeof(EnumerationsResx))]
		Multiply = 1,

		/// <summary>
		/// Gets or sets Divide
		/// </summary>
        [EnumValue("Divide", typeof(EnumerationsResx))]
		Divide = 2
	}
}
