// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for CreatePriceListBasedon
	/// </summary>
	public enum CreatePriceListBasedon
	{
		/// <summary>
		/// Gets or sets Percentage
		/// </summary>
        [EnumValue("Percentag", typeof(ICCommonResx))]
		Percentage = 1,

		/// <summary>
		/// Gets or sets ExchangeRate
		/// </summary>
        [EnumValue("ExchangeRate", typeof(ICCommonResx))]
		ExchangeRate = 2
	}
}
