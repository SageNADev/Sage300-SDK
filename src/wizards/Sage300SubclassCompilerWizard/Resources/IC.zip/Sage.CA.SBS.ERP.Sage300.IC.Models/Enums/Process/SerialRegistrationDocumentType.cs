// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for DocumentType
	/// </summary>
	public enum SerialRegistrationDocumentType
	{
		/// <summary>
		/// Gets or sets ICShipment
		/// </summary>
        [EnumValue("DocumenttypeICShipment", typeof(SerialRegistrationResx))]
		ICShipment = 1,

		/// <summary>
		/// Gets or sets OEShipment
		/// </summary>
        [EnumValue("DocumenttypeOEShipment", typeof(SerialRegistrationResx))]
		OEShipment = 2,

		/// <summary>
		/// Gets or sets OEInvoice
		/// </summary>
        [EnumValue("DocumenttypeOEInvoice", typeof(SerialRegistrationResx))]
		OEInvoice = 3,

		/// <summary>
		/// Gets or sets OEDebitNote
		/// </summary>
        [EnumValue("DocumenttypeOEDebitNote", typeof(SerialRegistrationResx))]
		OEDebitNote = 4,

		/// <summary>
		/// Gets or sets SerialOEInvoice
		/// </summary>
        [EnumValue("SerialOEInvoice", typeof(SerialRegistrationResx))]
		SerialOEInvoice = 5,

		/// <summary>
		/// Gets or sets SerialShipment
		/// </summary>
        [EnumValue("SerialShipment", typeof(SerialRegistrationResx))]
		SerialShipment = 6
	}
}
