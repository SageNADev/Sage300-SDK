// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for AdjustFor
	/// </summary>
	public enum AdjustFor
	{
		/// <summary>
		/// Gets or sets TotalCostToZeroForItemswithZeroQuantities
		/// </summary>
        [EnumValue("TotalCostToZeroForItemswithZeroQuantities", typeof(ProcessAdjustmentsResx), 1)]
		TotalCostToZeroForItemswithZeroQuantities = 0,

		/// <summary>
		/// Gets or sets TotalQuantityToZeroForItemswithZeroTotalCost
		/// </summary>
        [EnumValue("TotalQuantityToZeroForItemswithZeroTotalCost", typeof(ProcessAdjustmentsResx), 2)]
		TotalQuantityToZeroForItemswithZeroTotalCost = 1,

		/// <summary>
		/// Gets or sets TotalCostForItemswithNonZeroQuantitiesAndZeroTotalCost
		/// </summary>
        [EnumValue("TotalCostForItemswithNonZeroQuantitiesAndZeroTotalCost", typeof(ProcessAdjustmentsResx), 3)]
		TotalCostForItemswithNonZeroQuantitiesAndZeroTotalCost = 2
	}
}
