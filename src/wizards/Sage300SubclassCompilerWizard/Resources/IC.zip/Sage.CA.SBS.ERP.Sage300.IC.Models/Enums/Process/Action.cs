// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for Action
	/// </summary>
	public enum Action
	{
		/// <summary>
		/// Gets or sets None
		/// </summary>
		[EnumValue("None", typeof(CommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets GenerateAdjustment
		/// </summary>
        [EnumValue("GenerateAdjustment", typeof(ProcessAdjustmentsResx))]
		GenerateAdjustment = 1
	}
}
