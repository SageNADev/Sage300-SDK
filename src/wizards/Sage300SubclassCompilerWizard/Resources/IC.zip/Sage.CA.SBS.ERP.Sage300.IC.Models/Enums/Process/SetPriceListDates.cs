// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for SetPriceListDates
	/// </summary>
	public enum SetPriceListDates
	{
		/// <summary>
		/// Gets or sets CopyExistingDates
		/// </summary>
        [EnumValue("CopyExistingDates", typeof(CopyItemPricingResx))]
		CopyExistingDates = 0,

		/// <summary>
		/// Gets or sets UseSpecifiedDates
		/// </summary>
        [EnumValue("UseSpecifiedDates", typeof(CopyItemPricingResx))]
		UseSpecifiedDates = 1
	}
}
