// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for Period5IsLifetime
	/// </summary>
	public enum Period5IsLifetime
    {
        #region Period5IsLifetime enum
        
        /// <summary>
		/// Gets or sets No
		/// </summary>
		[EnumValue("No", typeof(CommonResx))]
		No = 0,

		/// <summary>
		/// Gets or sets Yes
		/// </summary>
		[EnumValue("Yes", typeof(CommonResx))]
		Yes = 1

        #endregion
    }
}
