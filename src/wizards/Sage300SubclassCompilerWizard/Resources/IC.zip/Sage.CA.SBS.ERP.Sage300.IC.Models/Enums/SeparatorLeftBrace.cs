// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Separator Left Brace
    /// </summary>
    public enum SeparatorLeftBrace
    {
        /// <summary>
        /// Left Brace
        /// </summary>
        LeftBrace = 1,
    }
}