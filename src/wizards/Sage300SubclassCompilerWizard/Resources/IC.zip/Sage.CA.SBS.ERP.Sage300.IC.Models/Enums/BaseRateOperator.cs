// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for BaseRateOperator
    /// </summary>
    public enum BaseRateOperator
    {
        /// <summary>
        /// Gets or sets Multiply
        /// </summary>
        [EnumValue("Multiply", typeof(ItemPricingResx))]
        Multiply = 1,

        /// <summary>
        /// Gets or sets Divide
        /// </summary>
        [EnumValue("Divide", typeof(ItemPricingResx))]
        Divide = 2,
    }
}
