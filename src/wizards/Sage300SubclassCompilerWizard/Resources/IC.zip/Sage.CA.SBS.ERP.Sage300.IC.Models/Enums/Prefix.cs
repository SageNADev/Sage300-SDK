﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Prefix 
    /// </summary>
    public enum Prefix
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>
        [EnumValue("None", typeof (ICCommonResx))] None = 1,

        /// <summary>
        /// Gets or sets Hyphen 
        /// </summary>	
        [EnumValue("ItemSeparatorHyphen", typeof (ICCommonResx))] Hyphen = 2,

        /// <summary>
        /// Gets or sets OrForwardSlash 
        /// </summary>	
        [EnumValue("ItemSeparatorForwardSlash", typeof (ICCommonResx))] OrForwardSlash = 3,

        /// <summary>
        /// Gets or sets \BackSlash 
        /// </summary>	
        [EnumValue("ItemSeparatorBackSlash", typeof (ICCommonResx))] BackSlash = 4,

        /// <summary>
        /// Gets or sets *Asterisk 
        /// </summary>	
        [EnumValue("ItemSeparatorAsterisk", typeof (ICCommonResx))] Asterisk = 5,

        /// <summary>
        /// Gets or sets Period 
        /// </summary>	
        [EnumValue("ItemSeparatorPeriod", typeof (ICCommonResx))] Period = 6,

        /// <summary>
        /// Gets or sets LeftParenthesis 
        /// </summary>	
        [EnumValue("ItemSeparatorLeftParenthesis", typeof (ICCommonResx))] LeftParenthesis = 7,

        /// <summary>
        /// Gets or sets RightParenthesis 
        /// </summary>	
        [EnumValue("ItemSeparatorRightParenthesis", typeof (ICCommonResx))] RightParenthesis = 8,

        /// <summary>
        /// Gets or sets #NumberSign 
        /// </summary>	
        [EnumValue("ItemSeparatorNumberSign", typeof (ICCommonResx))] NumberSign = 9,
    }
}