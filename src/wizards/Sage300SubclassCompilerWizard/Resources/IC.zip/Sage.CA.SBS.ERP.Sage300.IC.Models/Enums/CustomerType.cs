
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for CustomerType 
    /// </summary>
    public enum CustomerType
    {
        /// <summary>
        /// Gets or sets Base 
        /// </summary>	
        [EnumValue("Base", typeof(ICCommonResx))]
        Base = 1,
        /// <summary>
        /// Gets or sets A 
        /// </summary>	
        [EnumValue("A", typeof(ICCommonResx))]
        A = 2,
        /// <summary>
        /// Gets or sets B 
        /// </summary>	
        [EnumValue("B", typeof(ICCommonResx))]
        B = 3,
        /// <summary>
        /// Gets or sets C 
        /// </summary>	
        [EnumValue("C", typeof(ICCommonResx))]
        C = 4,
        /// <summary>
        /// Gets or sets D 
        /// </summary>	
        [EnumValue("D", typeof(ICCommonResx))]
        D = 5,
        /// <summary>
        /// Gets or sets E 
        /// </summary>	
        [EnumValue("E", typeof(ICCommonResx))]
        E = 6,
    }
}
