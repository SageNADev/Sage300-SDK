// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for SellingPriceBasedon 
    /// </summary>
    public enum SellingPriceBasedon
    {
        /// <summary>
        /// Gets or sets Discount 
        /// </summary>
        [EnumValue("Discount", typeof (ICCommonResx))] 
        Discount = 1,

        /// <summary>
        /// Gets or sets MarkuponMarkupCost 
        /// </summary>	
        [EnumValue("MarkuponMarkupCost", typeof (ICCommonResx))] 
        MarkuponMarkupCost = 2,

        /// <summary>
        /// Gets or sets MarkuponStandardCost 
        /// </summary>	
        [EnumValue("MarkuponStandardCost", typeof (ICCommonResx))] 
        MarkuponStandardCost = 3,

        /// <summary>
        /// Gets or sets MarkuponMostRecentCost 
        /// </summary>	
        [EnumValue("MarkuponMostRecentCost", typeof (ICCommonResx))]
        MarkuponMostRecentCost = 4,

        /// <summary>
        /// Gets or sets MarkuponAverageCost 
        /// </summary>	
        [EnumValue("MarkuponAverageCost", typeof (ICCommonResx))]
        MarkuponAverageCost = 5,

        /// <summary>
        /// Gets or sets MarkuponLastCost 
        /// </summary>	
        [EnumValue("MarkuponLastCost", typeof (ICCommonResx))] 
        MarkuponLastCost = 6,

        /// <summary>
        /// Gets or sets Cost1Name
        /// </summary>	
        Cost1Name = 7,

        /// <summary>
        /// Gets or sets Cost2Name 
        /// </summary>	
        Cost2Name = 8,

    }
}
