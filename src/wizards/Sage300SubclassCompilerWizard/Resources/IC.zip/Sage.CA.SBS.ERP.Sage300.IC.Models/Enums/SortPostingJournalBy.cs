// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Sort Posting Journal By
    /// </summary>
    public enum SortPostingJournalBy
    {
        /// <summary>
        /// Day End Number
        /// </summary>
        DayEndNumber = 0,

        /// <summary>
        /// Transaction Date 
        /// </summary>
        TransactionDate = 1,

        /// <summary>
        /// Expiry Date 
        /// </summary>
        DocumentNumber = 2,
    }
}