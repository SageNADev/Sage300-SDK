// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for BaseCostBase
    /// </summary>
    public enum BaseCostBase
    {
        /// <summary>
        /// Gets or sets StandardCost
        /// </summary>
        [EnumValue("StandardCost", typeof (ICCommonResx))] 
        StandardCost = 1,

        /// <summary>
        /// Gets or sets MostRecentCost
        /// </summary>
        [EnumValue("MostRecentCost", typeof (ICCommonResx))] 
        MostRecentCost = 2,

        /// <summary>
        /// Gets or sets AverageCost
        /// </summary>
        [EnumValue("AverageCost", typeof (ICCommonResx))]
        AverageCost = 3,

        /// <summary>
        /// Gets or sets LastUnitCost
        /// </summary>
        [EnumValue("LastUnitCost", typeof (ICCommonResx))] 
        LastUnitCost = 4,

      }
}
