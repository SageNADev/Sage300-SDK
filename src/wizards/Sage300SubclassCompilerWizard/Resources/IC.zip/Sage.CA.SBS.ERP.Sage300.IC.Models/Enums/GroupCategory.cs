// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for GroupCategory 
    /// </summary>
    public enum GroupCategory
    {
        /// <summary>
        /// Gets or sets CashandCashEquivalents 
        /// </summary>	
        CashandCashEquivalents = 10,

        /// <summary>
        /// Gets or sets AccountsReceivable 
        /// </summary>	
        AccountsReceivable = 20,

        /// <summary>
        /// Gets or sets Inventory 
        /// </summary>	
        Inventory = 30,

        /// <summary>
        /// Gets or sets OtherCurrentAssets 
        /// </summary>	
        OtherCurrentAssets = 40,

        /// <summary>
        /// Gets or sets FixedAssets 
        /// </summary>	
        FixedAssets = 50,

        /// <summary>
        /// Gets or sets AccumulatedDepreciation 
        /// </summary>	
        AccumulatedDepreciation = 60,

        /// <summary>
        /// Gets or sets OtherAssets 
        /// </summary>	
        OtherAssets = 70,

        /// <summary>
        /// Gets or sets AccountsPayable 
        /// </summary>	
        AccountsPayable = 80,

        /// <summary>
        /// Gets or sets OtherCurrentLiabilities 
        /// </summary>	
        OtherCurrentLiabilities = 90,

        /// <summary>
        /// Gets or sets LongTermLiabilities 
        /// </summary>	
        LongTermLiabilities = 100,

        /// <summary>
        /// Gets or sets OtherLiabilities 
        /// </summary>	
        OtherLiabilities = 110,

        /// <summary>
        /// Gets or sets ShareCapital 
        /// </summary>	
        ShareCapital = 120,

        /// <summary>
        /// Gets or sets ShareholdersEquity 
        /// </summary>	
        ShareholdersEquity = 130,

        /// <summary>
        /// Gets or sets Revenue 
        /// </summary>	
        Revenue = 140,

        /// <summary>
        /// Gets or sets CostofSales 
        /// </summary>	
        CostofSales = 150,

        /// <summary>
        /// Gets or sets OtherRevenue 
        /// </summary>	
        OtherRevenue = 160,

        /// <summary>
        /// Gets or sets OtherExpenses 
        /// </summary>	
        OtherExpenses = 170,

        /// <summary>
        /// Gets or sets DepreciationExpense 
        /// </summary>	
        DepreciationExpense = 180,

        /// <summary>
        /// Gets or sets GainsOrLosses 
        /// </summary>	
        GainsOrLosses = 190,

        /// <summary>
        /// Gets or sets InterestExpense 
        /// </summary>	
        InterestExpense = 200,

        /// <summary>
        /// Gets or sets IncomeTaxes 
        /// </summary>	
        IncomeTaxes = 210,
    }
}