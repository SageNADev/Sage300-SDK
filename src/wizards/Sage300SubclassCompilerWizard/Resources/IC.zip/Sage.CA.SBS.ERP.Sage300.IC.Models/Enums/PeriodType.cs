// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Period Type
    /// </summary>
    public enum PeriodType
    {
        /// <summary>
        /// Seven Days
        /// </summary>
        [EnumValue("SevenDays", typeof (OptionsResx))] SevenDays = 1,

        /// <summary>
        /// Weekly
        /// </summary>
        [EnumValue("Weekly", typeof (OptionsResx))] Weekly = 2,

        /// <summary>
        /// Monthly
        /// </summary>
        [EnumValue("Monthly", typeof (ICCommonResx))] Monthly = 3,
    }
}