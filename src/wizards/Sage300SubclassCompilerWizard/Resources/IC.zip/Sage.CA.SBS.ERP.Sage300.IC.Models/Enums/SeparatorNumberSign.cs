// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    ///Enum for Separator Number Sign
    /// </summary>
    public enum SeparatorNumberSign
    {
        /// <summary>
        /// NumberSign 
        /// </summary>
        NumberSign = 1,
    }
}