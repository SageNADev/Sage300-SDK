﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Serial & Lot Number List, sort by Enum
    /// </summary>
    public enum SerialLotListSortBy
    {
        #region SortBy enum

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [EnumValue("SerialNumber", typeof (ICCommonResx))] SerialNumber = 0,

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [EnumValue("LotNumber", typeof (ICCommonResx))] LotNumber = 1,

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [EnumValue("ItemNumber", typeof (ICCommonResx))] ItemNumber = 2,

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [EnumValue("Location", typeof (ICCommonResx))] Location = 3,

        #endregion
    }
}