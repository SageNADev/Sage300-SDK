﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// EachItem Enum
    /// </summary>
    public enum EachItem
    {
        /// <summary>
        /// Gets or sets  Received
        /// </summary>
          [EnumValue("ItemRECEIVED", typeof(ItemLabelResx))]
          Received = 0,

        /// <summary>
          /// Gets or sets  On File
        /// </summary>
        [EnumValue("ItemONFILE", typeof(ItemLabelResx))]
         OnFile= 1,

        /// <summary>
        /// Gets or sets In Stock
        /// </summary>
        [EnumValue("ItemINSTOCK", typeof(ItemLabelResx))]
        InStock= 2,

        /// <summary>
        /// Gets or sets NonStock 
        /// </summary>
        [EnumValue("ItemNONSTOCK", typeof(ItemLabelResx))]
        NonStock = 3,

       

    }
}
