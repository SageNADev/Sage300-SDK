﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum for ReportType
    /// </summary>
    public enum SerialLotListReportType
    {
        #region ReportType enum

        /// <summary>
        /// Report Format Summary
        /// </summary>
        [EnumValue("Summary", typeof (ICCommonResx))] Summary = 0,

        /// <summary>
        /// Report Format Detail
        /// </summary>
        [EnumValue("Detail1", typeof (ICCommonResx))] Detail = 1,

        #endregion
    }
}
