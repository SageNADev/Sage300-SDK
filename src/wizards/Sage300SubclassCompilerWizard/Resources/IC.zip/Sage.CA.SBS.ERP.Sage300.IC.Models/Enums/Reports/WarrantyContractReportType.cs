﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Warranty Contract Report Type Enum
    /// </summary>
    public enum WarrantyContractReportType
    {
        #region Report Type enum

        /// <summary>
        /// Gets or sets WarrantySummary
        /// </summary>
        [EnumValue("WarrantySummary", typeof (WarrantyContractListReportResx))] WarrantySummary = 0,

        /// <summary>
        /// Gets or sets ContractSummary
        /// </summary>
        [EnumValue("ContractSummary", typeof (WarrantyContractListReportResx))] ContractSummary = 1,

        /// <summary>
        ///  Gets or sets ItemSummary
        /// </summary>
        [EnumValue("ItemSummary", typeof (WarrantyContractListReportResx))] ItemSummary = 2,

        #endregion
    }
}
