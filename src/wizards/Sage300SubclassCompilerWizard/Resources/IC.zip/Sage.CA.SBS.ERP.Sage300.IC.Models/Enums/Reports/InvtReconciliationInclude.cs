﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Inventory Reconciliation Include enum
    /// </summary>
    public enum InvtReconciliationInclude
    {
        #region Enum for Include

        /// <summary>
        ///  Gets or sets All Units Measure
        /// </summary>
        [EnumValue("AllUnitsMeasure", typeof(InventoryReconciliationResx))]
        AllUnitsMeasure = 1,

        /// <summary>
        ///  Gets or sets Stocking Unit Only 
        /// </summary>
        [EnumValue("StockingUnitOnly", typeof(InventoryReconciliationResx))]
        StockingUnitOnly = 0

        #endregion
    }
}
