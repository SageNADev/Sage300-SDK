﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// PrintLoc Enum
    /// </summary>
    public enum PrintLoc
    {
        /// <summary>
        /// Gets or sets SeparateLocations
        /// </summary>
        [EnumValue("ValCboprintSeparateLoc", typeof(InventoryMovementReportResx))]
        SeparateLocations = 0,

        /// <summary>
        /// Gets or sets ItemsbyLocation
        /// </summary>
        [EnumValue("ValCboprintItemsbyLoc", typeof(InventoryMovementReportResx))]
        ItemsbyLocation = 1,

        /// <summary>
        /// Gets or sets ConsolidatedLocations
        /// </summary>
        [EnumValue("ValCboprintConsolLoc", typeof(InventoryMovementReportResx))]
        ConsolidatedLocations = 2,
    }
}

