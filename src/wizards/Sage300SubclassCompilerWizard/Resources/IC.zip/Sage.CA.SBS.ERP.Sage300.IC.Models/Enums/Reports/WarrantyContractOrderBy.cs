﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Warranty Contract Order By Enum
    /// </summary>
    public enum WarrantyContractOrderBy
    {
        #region orderBy enum

        /// <summary>
        /// Gets or sets ItemNumbers
        /// </summary>
        [EnumValue("ItemNumbers", typeof (WarrantyContractListReportResx))] ItemNumbers = 0,

        /// <summary>
        /// Gets or sets SerialNumbers
        /// </summary>
        [EnumValue("SerialNumbers", typeof (ICCommonResx))] SerialNumbers = 1,

        /// <summary>
        /// Gets or sets LotNumbers
        /// </summary>
        [EnumValue("LotNumbers", typeof (ICCommonResx))] LotNumbers = 2,

        #endregion
    }
}
