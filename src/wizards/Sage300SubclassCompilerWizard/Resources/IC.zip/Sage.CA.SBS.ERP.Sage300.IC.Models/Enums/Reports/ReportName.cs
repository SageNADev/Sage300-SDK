// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum for ReportName which gets the all reports name in the BinShelf Screen
    /// </summary>
    public enum ReportName
    {

        /// <summary>
        /// Gets or sets ICBINSH1
        /// </summary>
        
        ICBINSH1 = 0,

    }
}
