﻿
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    public enum Use
    {
        /// <summary>
        /// Gets or sets Transaction Costs
        /// </summary>
        [EnumValue("ValCboLocationDetailCosts", typeof(ItemValuationReportResx))]
        LocationDetailCosts = 0,

        /// <summary>
        /// Gets or sets Transaction Costs
        /// </summary>
        [EnumValue("ValCboTransactionCosts", typeof(ItemValuationReportResx))]
        TransactionCosts = 1,

    }
}
