﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Serial & Lot Number Enum for Print
    /// </summary>
    public enum SerialLotListPrint
    {
        #region Print enum

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [EnumValue("SerialNumber", typeof (ICCommonResx))] SerialNumber = 0,

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [EnumValue("LotNumber", typeof (ICCommonResx))] LotNumber = 1,

        #endregion
    }
}
