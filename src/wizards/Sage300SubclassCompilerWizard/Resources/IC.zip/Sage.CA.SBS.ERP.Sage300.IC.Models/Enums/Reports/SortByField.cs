﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Sort By Field Enum
    /// </summary>
    public enum SortByField
    {
        /// <summary>
        /// Gets or sets Vendor Number
        /// </summary>
        [EnumValue("VendorNumber", typeof(ICCommonResx))]
        VendorNumber = 1,

        /// <summary>
        /// Gets or sets Item Number
        /// </summary>
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 2,

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [EnumValue("Category", typeof(ICCommonResx))]
        Category = 3,

        /// <summary>
        /// Gets or sets Item Segment
        /// </summary>
        [EnumValue("ItemSegment", typeof(ICCommonResx))]
        ItemSegment = 4,

        /// <summary>
        /// Gets or sets Items Color
        /// </summary>
        [EnumValue("ItemsColor", typeof(ReorderReportResx))]
        ItemsColor = 5,

        /// <summary>
        /// Gets or sets Dangerous Item
        /// </summary>
        [EnumValue("DangerousItem", typeof(ReorderReportResx))]
        DangerousItem = 6,

        /// <summary>
        /// Gets or sets Extended Warranty Available
        /// </summary>
        [EnumValue("ExtendedWarrantyAvailable", typeof(ReorderReportResx))]
        ExtendedWarrantyAvailable = 7,

        /// <summary>
        /// Gets or sets Item Type
        /// </summary>
        [EnumValue("ItemType", typeof(ReorderReportResx))]
        ItemType = 8,

        /// <summary>
        /// Gets or sets Item Lead Type
        /// </summary>
        [EnumValue("ItemLeadType", typeof(ReorderReportResx))]
        ItemLeadType = 9,

        /// <summary>
        /// Gets or sets Manufacturer
        /// </summary>
        [EnumValue("Manufacturer", typeof(ReorderReportResx))]
        Manufacturer = 10,

        /// <summary>
        /// Gets or sets Manufacturer Number
        /// </summary>
        [EnumValue("ManufacturerNumber", typeof(ReorderReportResx))]
        ManufacturerNumber = 11,

        /// <summary>
        /// Gets or sets New Item
        /// </summary>
        [EnumValue("NewItem", typeof(ReorderReportResx))]
        NewItem = 12,

        /// <summary>
        /// Gets or sets Price 
        /// </summary>
        [EnumValue("Price", typeof(ReorderReportResx))]
        Price = 13,

        /// <summary>
        /// Gets or sets Item Procurement
        /// </summary>
        [EnumValue("ItemProcurement", typeof(ReorderReportResx))]
        ItemProcurement = 14,

        /// <summary>
        /// Gets or sets Item Size
        /// </summary>
        [EnumValue("ItemSize", typeof(ReorderReportResx))]
        ItemSize = 15,

        /// <summary>
        /// Gets or sets Item Volume
        /// </summary>
        [EnumValue("ItemVolume", typeof(ReorderReportResx))]
        ItemVolume = 16,

        /// <summary>
        /// Gets or sets Warranty
        /// </summary>
        [EnumValue("Warranty", typeof(ICCommonResx))]
        Warranty = 17,

        /// <summary>
        /// Gets or sets Warranty Period
        /// </summary>
        [EnumValue("WarrantyPeriod", typeof(ReorderReportResx))]
        WarrantyPeriod = 18,
    }
}
