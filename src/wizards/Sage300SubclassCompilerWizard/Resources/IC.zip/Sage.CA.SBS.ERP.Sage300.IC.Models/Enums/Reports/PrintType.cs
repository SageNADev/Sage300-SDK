﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Report Type Enum
    /// </summary>
    public enum PrintType
    {
        /// <summary>
        /// Gets or sets Transaction
        /// </summary>
        [EnumValue("CbprintCostsQty", typeof(StockTransactionReportResx))]
        CostsAndQuantity = 0,

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [EnumValue("CbprintQty", typeof(StockTransactionReportResx))]
        QuantitiesOnly = 1,

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [EnumValue("CbprintCosts", typeof(StockTransactionReportResx))]
        CostsOnly = 2,
    }
}
