﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum Warranty Contract Sort By
    /// </summary>
    public enum WarrantyContractSortBy
    {
        #region Sortby enum

        /// <summary>
        ///  Gets or sets Location 
        /// </summary>
        [EnumValue("Location", typeof (ICCommonResx))] Location = 0,

        /// <summary>
        ///  Gets or sets SoldDate 
        /// </summary>
        [EnumValue("SoldDate", typeof (ICCommonResx))] SoldDate = 1,

        /// <summary>
        ///  Gets or sets StockDate 
        /// </summary>
        [EnumValue("StockDate", typeof (ICCommonResx))] StockDate = 2,

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [EnumValue("ExpiryDate", typeof (ICCommonResx))] ExpiryDate = 3,

        /// <summary>
        /// Gets or sets WarrantyExpiryDate
        /// </summary>
        [EnumValue("WarrantyExpiryDate", typeof (WarrantyContractListReportResx))] WarrantyExpiryDate = 4,

        /// <summary>
        /// Gets or sets ContractExpiryDate
        /// </summary>
        [EnumValue("ContractExpiryDate", typeof (WarrantyContractListReportResx))] ContractExpiryDate = 5

        #endregion
    }
}
