﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Warranty Contract Use Enum
    /// </summary>
    public enum WarrantyContractUse
    {
        #region Use enum

        /// <summary>
        /// Gets or sets LatestWarrContExpiryDate
        /// </summary>
        [EnumValue("LatestWarrantyContractExpiryDate", typeof (WarrantyContractListReportResx))] LatestWarrContExpiryDate = 0,

        /// <summary>
        /// Gets or sets EarliestWarrContExpiryDate
        /// </summary>
        [EnumValue("EarliestWarrantyContractExpiryDate", typeof (WarrantyContractListReportResx))] EarliestWarrContExpiryDate = 1,

        #endregion
    }
}
