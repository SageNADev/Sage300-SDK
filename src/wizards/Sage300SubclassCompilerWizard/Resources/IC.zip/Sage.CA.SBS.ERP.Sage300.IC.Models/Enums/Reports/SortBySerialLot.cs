﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// SortBySerialLot Enum
    /// </summary>
    public enum SortBySerialLot
    {
        

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [EnumValue("Location", typeof(ICCommonResx))]
        Location = 0,

        /// <summary>
        /// Gets or sets Items
        /// </summary>
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 1,
    }
}
