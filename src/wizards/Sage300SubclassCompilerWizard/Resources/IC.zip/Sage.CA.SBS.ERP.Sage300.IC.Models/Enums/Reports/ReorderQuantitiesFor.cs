﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region usings
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum Quantities For Location
    /// </summary>
    public enum ReorderQuantitiesFor
    {
        /// <summary>
        /// Gets or sets Specific Location
        /// </summary>
        [EnumValue("SpecificLocation", typeof(ICCommonResx))]
        SpecificLocation = 1,
                
        /// <summary>
        /// Gets or sets All Locations
        /// </summary>
        [EnumValue("AllLocations", typeof(ICCommonResx))]
        AllLocation = 2,

        /// <summary>
        /// Gets or sets Specific and All Locations
        /// </summary>
        [EnumValue("SpecificAndAllLocations", typeof(ICCommonResx))]
        SpecificAndAllLocation = 3

    }
}
