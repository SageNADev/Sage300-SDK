﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// ReportCurrency Enum
    /// </summary>
    public enum ReportCurrency
    {
        /// <summary>
        /// Gets or sets Functional
        /// </summary>
        [EnumValue("ValCboFunctionalCurrency", typeof(InventoryMovementReportResx))]
        Functional = 0,

        /// <summary>
        /// Gets or sets SourceandFunctional
        /// </summary>
        [EnumValue("ValCboSourceFuncCurrency", typeof(InventoryMovementReportResx))]
        SourceandFunctional = 1,
    }
}
