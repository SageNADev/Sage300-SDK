﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enums for SerialLotTransactionSortby2
    /// </summary>
    public enum SerialLotTransactionSortby2
    {
        #region Enums 

        /// <summary>
        /// Gets or sets LotNumbers
        /// </summary>
        [EnumValue("LotNumber", typeof(ICCommonResx))]
        LotNumber = 0,

        /// <summary>
        /// Gets or sets ItemNumbers
        /// </summary>
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 1,

        #endregion
    }
}
