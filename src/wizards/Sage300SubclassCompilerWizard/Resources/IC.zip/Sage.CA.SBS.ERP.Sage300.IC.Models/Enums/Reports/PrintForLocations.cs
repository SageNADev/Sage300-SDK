﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// PrintLoc Enum
    /// </summary>
    public enum PrintForLocation
    {
        /// <summary>
        /// Gets or sets SeparateLocations
        /// </summary>
        [EnumValue("SpecificLocation", typeof(ICCommonResx))]
        SpecificLocation = 1,

        /// <summary>
        /// Gets or sets ItemsbyLocation
        /// </summary>
        [EnumValue("AllLocations", typeof(ICCommonResx))]
        AllLocation = 2,

        /// <summary>
        /// Gets or sets ConsolidatedLocations
        /// </summary>
        [EnumValue("SpecificAndAllLocations", typeof(ICCommonResx))]
        SpecificAndAllLocations = 3,
    }
}

