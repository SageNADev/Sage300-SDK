﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// TransactionBy Enum
    /// </summary>
    public enum TransactionBy
    {
        /// <summary>
        /// Gets or sets Date
        /// </summary>
        [EnumValue("ValCboSelectbyDate", typeof(InventoryMovementReportResx))]
        Date=0,

        /// <summary>
        /// Gets or sets Detail
        /// </summary>
        [EnumValue("ValCboSelectbyFiscYear", typeof(InventoryMovementReportResx))]
        FiscalYearorPeriod = 1,
    }
}
