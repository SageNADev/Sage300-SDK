﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Print Info Enum
    /// </summary>
    public enum PrintInfo
    {
        /// <summary>
        /// Gets or sets Price List
        /// </summary>
        [EnumValue("PriceList", typeof(ICCommonResx))]
        PriceList = 1,

        /// <summary>
        /// Gets or sets Detail
        /// </summary>
        [EnumValue("Detail1", typeof(ICCommonResx))]
        Detail = 2,

        /// <summary>
        /// Gets or sets Price List Summary
        /// </summary>
        [EnumValue("PriceSummary", typeof(ICCommonResx))]
        PriceSummary = 3,

        /// <summary>
        /// Gets or sets Item Number Summary
        /// </summary>
        [EnumValue("ItemSummary", typeof(ICCommonResx))]
        ItemSummary = 4,
    }
}
