﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// PrintFormat Enum
    /// </summary>
    public enum PrintFormat
    {
        /// <summary>
        /// Gets or sets ConsolidateItems
        /// </summary>
        [EnumValue("ConsolidateItems", typeof(SalesStatisticsResx))]
        ConsolidateItems = 1,

        /// <summary>
        /// Gets or sets ShowEveryItem
        /// </summary>
        [EnumValue("ShowEveryItem", typeof(SalesStatisticsResx))]
        ShowEveryItem = 2,
    }
}
