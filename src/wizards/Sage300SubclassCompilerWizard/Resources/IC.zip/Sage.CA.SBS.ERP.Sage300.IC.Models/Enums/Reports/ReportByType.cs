﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Report Type Enum
    /// </summary>
    public enum ReportByType
    {
        /// <summary>
        /// Gets or sets Specific Location
        /// </summary>
        [EnumValue("ValReForSpecLoc", typeof(ReorderReportResx))]
        ReorderForSpecificLocations = 0,

        /// <summary>
        /// Gets or sets All Locations
        /// </summary>
        [EnumValue("ValReForAllLoc", typeof(ReorderReportResx))]
        ReorderForAllLocations = 1,
    }
}
