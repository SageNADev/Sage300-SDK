﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum for RecallSortBy
    /// </summary>
    public enum RecallSortBy
    {
        /// <summary>
        ///  Gets or sets RecallNumber
        /// </summary>
        [EnumValue("RecallNumber", typeof(ICCommonResx))]
        RecallNumber = 0,

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 1,

        /// <summary>
        /// Gets or sets  Customer/VendorNumber
        /// </summary>
        [EnumValue("CustVendNumber", typeof(ICCommonResx))]
       CustomerVendorNumber = 2,
    }
}