﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// For Segment Enum
    /// </summary>
    public enum Segment
    {
        /// <summary>
        /// Gets or sets Less Than Minimum
        /// </summary>
        [EnumValue("Category", typeof(ICCommonResx))]
        Category = 1,

        /// <summary>
        /// Gets or sets Less Than Or Equal To Zero
        /// </summary>
        [EnumValue("Style", typeof(ReorderReportResx))]
        Style = 2,

        /// <summary>
        /// Gets or sets Less Than Sales Projected
        /// </summary>
        [EnumValue("Color", typeof(ReorderReportResx))]
        Color = 3,

        /// <summary>
        /// Gets or sets Equal To Zero
        /// </summary>
        [EnumValue("Model", typeof(ReorderReportResx))]
        Model = 4,

        /// <summary>
        /// Gets or sets Less Than Or Equal To Zero
        /// </summary>
        [EnumValue("Series", typeof(ReorderReportResx))]
        Series = 5,

        /// <summary>
        /// Gets or sets Less Than Sales Projected
        /// </summary>
        [EnumValue("Long", typeof(ReorderReportResx))]
        Long = 6,

    }
}
