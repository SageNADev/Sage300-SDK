﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;


#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Sort By Field Enum
    /// </summary>
    public enum CustomerSortBy
    {       
        /// <summary>
        /// Gets or sets Item Number
        /// </summary>
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 0,

        /// <summary>
        /// Gets or sets Vendor Number
        /// </summary>
        [EnumValue("CustomerNumber", typeof(ICCommonResx))]
        CustomerNumber = 1,

    }
}
