﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Transaction History Report Types
    /// </summary>
    public enum TransactionHistoryReportType
    {
        #region Enum

        /// <summary>
        ///  Gets or sets Detail 
        /// </summary>
        [EnumValue("DetailWithSerialsLots", typeof(TransactionHistoryReportResx))]
        Detail = 0,

        /// <summary>
        ///  Gets or sets Summary 
        /// </summary>
        [EnumValue("Summary", typeof(ICCommonResx))]
        Summary = 1
        
        #endregion
    }
}