﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Cost Info Enum
    /// </summary>
    public enum PrintItemFor
    {
        /// <summary>
        /// Gets or sets Most Recent Cost
        /// </summary>
        [EnumValue("QuantityGreaterThanMaximumLevel", typeof(OverstockedItemReportResx))]
        QuantityGreaterThanMaximumLevel = 0,

        /// <summary>
        /// Gets or sets Vendor Cost
        /// </summary>
        [EnumValue("QuantityGreaterThanProjectedSales", typeof(OverstockedItemReportResx))]
        QuantityGreaterThanProjectedScale =1,
        /// <summary>
        /// Gets or sets Vendor Cost
        /// </summary>
        [EnumValue("AnnualizedTurnEarnRatio", typeof(OverstockedItemReportResx))]
        AnnualizedTurnAndEarnRatio = 2,

        /// <summary>
        /// Gets or sets Vendor Cost
        /// </summary>
        [EnumValue("AverageCostExcessQuantity", typeof(OverstockedItemReportResx))]
        AverageCostOfExcessQuantity = 3,

        /// <summary>
        /// Gets or sets Vendor Cost
        /// </summary>
        [EnumValue("MostRecentCostExcessQuantity", typeof(OverstockedItemReportResx))]
        MostRecentCostOfExcessQuantity = 4,
    }
}
