// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Action
    /// </summary>
    public enum Action
    {
        /// <summary>
        /// Added default zero to avoid serialization issue
        /// </summary>
        [EnumValue("Default", typeof(ICCommonResx))]
        Default = 0,

        /// <summary>
        /// Gets or sets Post
        /// </summary>
        [EnumValue("Post", typeof(ICCommonResx))]
        Post = 1,

        /// <summary>
        /// Gets or sets UpdatePrintFlag
        /// </summary>
        [EnumValue("UpdatePrintFlag", typeof(ICEnumerationsResx))]
        UpdatePrintFlag = 2,

        /// <summary>
        /// Gets or sets UpdateTransferSlipPrintFlag
        /// </summary>
        [EnumValue("UpdateTransferSlipPrintFlag", typeof(ICEnumerationsResx))]
        UpdateTransferSlipPrintFlag = 3
    }
}
