﻿
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Posting Journal Type 
    /// </summary>
    public enum PostingJournalType
    {
        /// <summary>
        /// Gets or sets Adjustments
        /// </summary>	
        Adjustments = 0,

        /// <summary>
        /// Gets or sets Assemblies
        /// </summary>	
        Assemblies = 1,

        /// <summary>
        /// Gets or sets Receipts
        /// </summary>	
        Receipts = 2,

        /// <summary>
        /// Gets or sets Shipments
        /// </summary>	
        Shipments = 3,

        /// <summary>
        /// Gets or sets InternalUsage
        /// </summary>	
        InternalUsage = 4,

        /// <summary>
        /// Gets or sets StockTransfers
        /// </summary>	
        StockTransfers = 5

    }
}
