﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Serial & Lot Number Enum
    /// </summary>
    public enum SerialLotNumber
    {
        #region LotNumber enum

        /// <summary>
        /// Gets or sets SerialNumbers
        /// </summary>
        [EnumValue("SerialNumbers", typeof (ICCommonResx))] SerialNumbers = 0,

        /// <summary>
        /// Gets or sets LotNumbers
        /// </summary>
        [EnumValue("LotNumbers", typeof (ICCommonResx))] LotNumbers = 1,

        #endregion
    }
}
