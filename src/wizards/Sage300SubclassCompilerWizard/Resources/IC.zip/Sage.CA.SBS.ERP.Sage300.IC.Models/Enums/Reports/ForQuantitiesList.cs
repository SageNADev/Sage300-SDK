﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// For Quantities Enum
    /// </summary>
    public enum ForQuantitiesList
    {
        /// <summary>
        /// Gets or sets Less Than Minimum
        /// </summary>
        [EnumValue("ValLThanMin", typeof(ReorderReportResx))]
        LessThanMinimum = 0,

        /// <summary>
        /// Gets or sets Less Than Or Equal To Zero
        /// </summary>
        [EnumValue("ValLThanorEqtoZero", typeof(ReorderReportResx))]
        LessThanOrEqualToZero = 1,

        /// <summary>
        /// Gets or sets Less Than Sales Projected
        /// </summary>
        [EnumValue("ValLThanSaleProjtd", typeof(ReorderReportResx))]
        LessThanSalesProjected = 2,

        /// <summary>
        /// Gets or sets Equal To Zero
        /// </summary>
        [EnumValue("ValEqtoZero", typeof(ReorderReportResx))]
        EqualToZero = 3,
    }
}
