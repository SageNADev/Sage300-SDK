﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    public enum TransactionHistorySortBy
    {
        #region Enum

        /// <summary>
        ///  Gets or sets Account Set Code 
        /// </summary>
        [EnumValue("AccountSetCode", typeof(ICCommonResx))]
        AccountSetCode = 0,

        /// <summary>
        ///  Gets or sets Item Number 
        /// </summary>
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 1

        #endregion
    }
}