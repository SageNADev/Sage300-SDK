﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Serial & Lot Number List, first select by Enum
    /// </summary>
    public enum SerialLotListSelectBy1
    {
        #region SelectBy1 enum 

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [EnumValue("ItemNumber", typeof (ICCommonResx))] ItemNumber = 0,

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [EnumValue("SerialNumber", typeof (ICCommonResx))] SerialNumber = 1,

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [EnumValue("LotNumber", typeof (ICCommonResx))] LotNumber = 2,

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [EnumValue("CustomerNumber", typeof (ICCommonResx))] CustomerNumber = 3,

        #endregion
    }
}