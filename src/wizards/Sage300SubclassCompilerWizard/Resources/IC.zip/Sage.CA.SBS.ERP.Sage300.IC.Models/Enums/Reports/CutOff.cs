﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Cut Off Enum
    /// </summary>
    public enum CutOff
    {
        /// <summary>
        /// Gets or sets Most  Document Date
        /// </summary>
        [EnumValue("ValCboCutOffByDate", typeof(AgedInventoryReportResx))]
        DocumentDate = 0,

        /// <summary>
        /// Gets or sets Year/Period
        /// </summary>
        [EnumValue("ValCboCutOffByFiscYear", typeof(AgedInventoryReportResx))]
        YearPeriod = 1,

    }
}

