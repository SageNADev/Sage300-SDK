﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Include Enum
    /// </summary>
    public enum Include
    {
        /// <summary>
        /// Gets or sets  All
        /// </summary>
          [EnumValue("ValCboIncludeAll", typeof(AgedInventoryReportResx))]
         All = 0,

        /// <summary>
          /// Gets or sets  Only Positive
        /// </summary>
        [EnumValue("ValCboIncludeOnlyPositive", typeof(AgedInventoryReportResx))]
        OnlyPositive = 1,

        /// <summary>
        /// Gets or sets Only Zero
        /// </summary>
        [EnumValue("ValCboIncludeOnlyZero", typeof(AgedInventoryReportResx))]
        OnlyZero = 2,

        /// <summary>
        /// Gets or sets Only Negative
        /// </summary>
        [EnumValue("ValCboIncludeOnlyNegative", typeof(AgedInventoryReportResx))]
        OnlyNegative = 3,

        /// <summary>
        /// Gets or sets  Non Zero
        /// </summary>
        [EnumValue("ValCboIncludeOnlyNonZero", typeof(AgedInventoryReportResx))]
       NonZero = 4,

    }
}
