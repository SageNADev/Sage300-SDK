﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// PrintTransaction Enum
    /// </summary>
    public enum StockTransactionType
    {
        /// <summary>
        /// Gets or sets Summary
        /// </summary>
        [EnumValue("ValCboTransactionInSummary", typeof(AgedInventoryReportResx))]
        Summary = 0,

        /// <summary>
        /// Gets or sets Detail
        /// </summary>
        [EnumValue("ValCboTransactionInDetail", typeof(AgedInventoryReportResx))]
        Detail = 1,
    }
}
