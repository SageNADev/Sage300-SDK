﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Warranty Contract Show Enum
    /// </summary>
    public enum WarrantyContractShow
    {
        #region Show enum

        /// <summary>
        ///  Gets or sets Registered 
        /// </summary>
        [EnumValue("Registered", typeof (WarrantyContractListReportResx))] Registered = 0,

        /// <summary>
        ///  Gets or sets NotRegistered 
        /// </summary>
        [EnumValue("NotRegistered", typeof (WarrantyContractListReportResx))] NotRegistered = 1,

        /// <summary>
        ///  Gets or sets Both 
        /// </summary>
        [EnumValue("Both", typeof (ICCommonResx))] Both = 2,

        #endregion
    }
}
