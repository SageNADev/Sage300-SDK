﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Serial & Lot Number List, second and third select by Enum
    /// </summary>
    public enum SerialLotListSelectBy2
    {
        #region SelectBy2 enum

        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof (ICCommonResx))] None = 0,

        /// <summary>
        /// Gets or sets VendorNumber
        /// </summary>
        [EnumValue("VendorNumber", typeof (ICCommonResx))] VendorNumber = 1,

        /// <summary>
        /// Gets or sets SoldDate
        /// </summary>
        [EnumValue("SoldDate", typeof (ICCommonResx))] SoldDate = 2,

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [EnumValue("Location", typeof (ICCommonResx))] Location = 3,

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [EnumValue("ExpiryDate", typeof (ICCommonResx))] ExpiryDate = 4,

        #endregion
    }
}
