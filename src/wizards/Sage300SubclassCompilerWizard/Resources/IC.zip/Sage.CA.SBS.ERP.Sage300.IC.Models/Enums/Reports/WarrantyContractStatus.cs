﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum Warranty Contract Status
    /// </summary>
    public enum WarrantyContractStatus
    {
        #region Status enum

        /// <summary>
        ///  Gets or sets Both 
        /// </summary>
        [EnumValue("Both", typeof (ICCommonResx))] Both = 0,

        /// <summary>
        ///  Gets or sets NotAvailable 
        /// </summary>
        [EnumValue("NotAvailable", typeof (ICCommonResx))] NotAvailable = 1,

        /// <summary>
        ///  Gets or sets Available 
        /// </summary>
        [EnumValue("Available", typeof (ICCommonResx))] Available = 2,

        #endregion
    }
}
