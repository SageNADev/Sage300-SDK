﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Cost Info Enum
    /// </summary>
    public enum CostInfo
    {
        /// <summary>
        /// Gets or sets Most Recent Cost
        /// </summary>
        [EnumValue("MostRecentCost", typeof(ICCommonResx))]
        MostRecentCost = 0,

        /// <summary>
        /// Gets or sets Vendor Cost
        /// </summary>
        [EnumValue("ValVendorCost", typeof(ReorderReportResx))]
        VendorCost = 1,

    }
}
