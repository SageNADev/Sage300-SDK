﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enums for SerialLotTransactionSortby1
    /// </summary>
    public enum SerialLotTransactionSortby1
    {
        #region Enums
        
        /// <summary>
        /// Gets or sets SerialNumbers
        /// </summary>
        [EnumValue("SerialNumber", typeof (ICCommonResx))] SerialNumber = 0,

        /// <summary>
        /// Gets or sets ItemNumbers
        /// </summary>
        [EnumValue("ItemNumber", typeof (ICCommonResx))] ItemNumber = 1,

        #endregion 
    }
}
