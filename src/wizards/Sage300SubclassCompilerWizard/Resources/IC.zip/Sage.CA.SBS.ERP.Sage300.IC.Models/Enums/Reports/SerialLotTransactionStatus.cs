﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enums for SerialLotTransactionStatus
    /// </summary>
    public enum SerialLotTransactionStatus
    {
        #region enums

        /// <summary>
        ///  Gets or sets NotAvailable 
        /// </summary>
        [EnumValue("NotAvailable", typeof(ICCommonResx), 2)]
        NotAvailable = 0,

        /// <summary>
        ///  Gets or sets Available 
        /// </summary>
        [EnumValue("Available", typeof(ICCommonResx), 3)]
        Available = 1,

        /// <summary>
        ///  Gets or sets Both 
        /// </summary>
        [EnumValue("Both", typeof(ICCommonResx), 1)]
        Both = 2,

        #endregion
    }
}
