﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Report Type Enum
    /// </summary>
    public enum StockReportType
    {
        /// <summary>
        /// Gets or sets Transaction
        /// </summary>
        [EnumValue("CbreporttypeTransxns", typeof(StockTransactionReportResx))]
        StockTransaction = 0,

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [EnumValue("CbreporttypeStatus", typeof(StockTransactionReportResx))]
        StockStatus = 1,
    }
}
