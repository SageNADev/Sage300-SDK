// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum for ReportName which gets the reports fot Itemlabel screen
    /// </summary>
    public enum ReportForItem
    {

        /// <summary>
        /// Gets or sets ICITLB01
        /// </summary>
        
        ICITLB01=0,

    }
}
