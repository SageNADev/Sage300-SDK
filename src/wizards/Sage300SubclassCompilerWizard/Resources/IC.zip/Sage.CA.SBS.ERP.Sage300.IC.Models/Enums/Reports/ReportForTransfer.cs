// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Reports
{
    /// <summary>
    /// Enum for ReportName which gets the reports fot Itemlabel screen
    /// </summary>
    public enum ReportForTransfer
    {

        /// <summary>
        /// Gets or sets ICTRNS01
        /// </summary>
        [EnumValue("ICTRNS01", typeof(TransferSlipResx), 1)]
        ICTRNS01 = 0,
        /// <summary>
        /// Gets or sets ICTRNS01
        /// </summary>
        [EnumValue("ICTRNS02", typeof(TransferSlipResx), 1)]
        ICTRNS02 = 1,

    }
}
