﻿// /* Copyright (c) 1994-2026 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for message type
    /// </summary>
    public enum ExpiredLotMessage
    {
        /// <summary>
        /// None
        /// </summary>
        None = 0,

        /// <summary>
        /// Warning
        /// </summary>
        Warning = 1,

        /// <summary>
        /// Error
        /// </summary>
        Error = 2,
    }
}