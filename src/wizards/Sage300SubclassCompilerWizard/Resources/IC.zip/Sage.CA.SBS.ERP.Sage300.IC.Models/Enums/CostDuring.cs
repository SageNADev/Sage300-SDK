// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Cost During
    /// </summary>
    public enum CostDuring
    {
        /// <summary>
        /// Day End Processing
        /// </summary>
        [EnumValue("DayEndProcessing", typeof (EnumerationsResx))] DayEndProcessing = 1,

        /// <summary>
        /// Posting
        /// </summary>
        [EnumValue("Posting", typeof (EnumerationsResx))] Posting = 2,
    }
}