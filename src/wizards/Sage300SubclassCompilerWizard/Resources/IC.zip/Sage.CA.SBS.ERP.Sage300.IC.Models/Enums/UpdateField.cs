// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
	/// <summary>
	/// Enum for UpdateField
	/// </summary>
	public enum UpdateField
	{
		/// <summary>
		/// Gets or sets BasePrice
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("BasePrice", typeof(ICCommonResx))]
		BasePrice = 1,

		/// <summary>
		/// Gets or sets SalePrice
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("SalePrice", typeof(ICCommonResx))]
		SalePrice = 2,

		/// <summary>
		/// Gets or sets MarkupCost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("MarkupCost", typeof(ICCommonResx))]
		MarkupCost = 3,

		/// <summary>
		/// Gets or sets PriceCheck
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("PriceCheck", typeof(ICCommonResx))]
		PriceCheck = 4,

		/// <summary>
		/// Gets or sets PriceListDates
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("PriceListDates", typeof(UpdateItemPricingResx))]
		PriceListDates = 5
	}
}
