// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for Status
     /// </summary>
     public enum WorksheetHeaderStatus
     {
         /// <summary>
         /// Gets or sets None
         /// </summary>
         None = 0,
          /// <summary>
          /// Gets or sets ReadyTopost
          /// </summary>
          [EnumValue("ReadyToPost", typeof(CommonResx))] 
          ReadyTopost = 1,
          /// <summary>
          /// Gets or sets Onhold
          /// </summary>
          [EnumValue("OnHold", typeof(PhysicalInventoryQuantitiesResx))] 
          Onhold = 2,
          /// <summary>
          /// Gets or sets Itemdoesnotexist
          /// </summary>
          [EnumValue("ItemDoesNotExist", typeof(PhysicalInventoryQuantitiesResx))]
          Itemdoesnotexist = 3,
          /// <summary>
          /// Gets or sets Nonstockitem
          /// </summary>
          [EnumValue("NonStockItem", typeof(PhysicalInventoryQuantitiesResx))]
          Nonstockitem = 4,
          /// <summary>
          /// Gets or sets Itemnotallowedatlocation
          /// </summary>
          [EnumValue("ItemNotAllowedAtLocation", typeof(PhysicalInventoryQuantitiesResx))]
          Itemnotallowedatlocation = 5,
          /// <summary>
          /// Gets or sets Insufficientquantity
          /// </summary>
          [EnumValue("InsufficientQuantity", typeof(PhysicalInventoryQuantitiesResx))]
          Insufficientquantity = 6,
          /// <summary>
          /// Gets or sets Itemnotactive
          /// </summary>
          [EnumValue("ItemNotActive", typeof(PhysicalInventoryQuantitiesResx))]
          Itemnotactive = 7,
     }
}
