/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    ///     Enum for DocumentType
    /// </summary>
    public enum TransferDocumentType
    {
        /// <summary>
        ///     Gets or sets Transfer
        /// </summary>
        [EnumValue("Transfer", typeof(ICCommonResx))]
        Transfer = 1,

        /// <summary>
        ///     Gets or sets TransitTransfer
        /// </summary>
        [EnumValue("TransitTransfer", typeof(ICEnumerationsResx))]
        TransitTransfer = 2,

        /// <summary>
        ///     Gets or sets TransitReceipt
        /// </summary>
        [EnumValue("TransitReceipt", typeof(ICEnumerationsResx))]
        TransitReceipt = 3
    }
}