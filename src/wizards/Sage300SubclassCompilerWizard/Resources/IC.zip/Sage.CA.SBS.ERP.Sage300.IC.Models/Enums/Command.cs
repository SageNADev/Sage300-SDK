// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for Command
     /// </summary>
     public enum Command
     {
          /// <summary>
          /// Gets or sets Nocommand
          /// </summary>
          Nocommand = 0,
          /// <summary>
          /// Gets or sets GetApplication
          /// </summary>
          GetApplication = 1,
          /// <summary>
          /// Gets or sets SetDirty
          /// </summary>
          SetDirty = 2,
     }
}
