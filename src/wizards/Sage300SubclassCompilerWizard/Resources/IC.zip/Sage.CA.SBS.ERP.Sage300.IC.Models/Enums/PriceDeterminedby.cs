// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for PriceDeterminedby 
    /// </summary>
    public enum PriceDeterminedby
    {
        /// <summary>
        /// Gets or sets CustomerType 
        /// </summary>	
        [EnumValue("CustomerType", typeof(ICCommonResx))]
        CustomerType = 1,

        /// <summary>
        /// Gets or sets VolumeDiscounts 
        /// </summary>	
        [EnumValue("VolumeDiscounts", typeof(ICCommonResx))]
        VolumeDiscounts = 2,
    }
}
