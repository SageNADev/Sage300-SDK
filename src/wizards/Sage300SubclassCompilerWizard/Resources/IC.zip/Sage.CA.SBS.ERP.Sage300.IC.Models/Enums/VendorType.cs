﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for VendorType 
    /// </summary>
    public enum VendorType
    {
        /// <summary>
        /// Gets or sets Vendor1 
        /// </summary>	
        [EnumValue("Vendor1", typeof(VendorDetailsResx))]
        Vendor1 = 1,
        
        /// <summary>
        /// Gets or sets Vendor2 
        /// </summary>	
        [EnumValue("Vendor2", typeof(VendorDetailsResx))]
        Vendor2 = 2,
        
        /// <summary>
        /// Gets or sets Vendor3 
        /// </summary>	
        [EnumValue("Vendor3", typeof(VendorDetailsResx))]
        Vendor3 = 3,
        
        /// <summary>
        /// Gets or sets Vendor4 
        /// </summary>	
        [EnumValue("Vendor4", typeof(VendorDetailsResx))]
        Vendor4 = 4,
        
        /// <summary>
        /// Gets or sets Vendor5 
        /// </summary>	
        [EnumValue("Vendor5", typeof(VendorDetailsResx))]
        Vendor5 = 5,
        
        /// <summary>
        /// Gets or sets Vendor6 
        /// </summary>	
        [EnumValue("Vendor6", typeof(VendorDetailsResx))]
        Vendor6 = 6,
        
        /// <summary>
        /// Gets or sets Vendor7 
        /// </summary>	
        [EnumValue("Vendor7", typeof(VendorDetailsResx))]
        Vendor7 = 7,
        
        /// <summary>
        /// Gets or sets Vendor8 
        /// </summary>	
        [EnumValue("Vendor8", typeof(VendorDetailsResx))]
        Vendor8 = 8,
        
        /// <summary>
        /// Gets or sets Vendor9 
        /// </summary>	
        [EnumValue("Vendor9", typeof(VendorDetailsResx))]
        Vendor9 = 9,
    }
}
