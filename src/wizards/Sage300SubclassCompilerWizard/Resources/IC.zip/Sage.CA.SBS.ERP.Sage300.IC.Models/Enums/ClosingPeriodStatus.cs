// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for ClosingPeriodStatus
     /// </summary>
     public enum ClosingPeriodStatus
     {
          /// <summary>
          /// Gets or sets Unlocked
          /// </summary>
          Unlocked = 1,
          /// <summary>
          /// Gets or sets Locked
          /// </summary>
          Locked = 0,
     }
}
