// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ReceiptType
    /// </summary>
    public enum ReceiptType
    {
        /// <summary>
        /// Gets or sets Included 
        /// </summary>	
        [EnumValue("Receipt", typeof(ICCommonResx))]
        Receipt = 1,

        /// <summary>
        /// Gets or sets Included 
        /// </summary>	
        [EnumValue("Return", typeof(ICCommonResx))]
        Return = 2,

        /// <summary>
        /// Gets or sets Included 
        /// </summary>	
        [EnumValue("Adjustment", typeof(ICCommonResx))]
        Adjustment = 3,

        /// <summary>
        /// Gets or sets Included 
        /// </summary>	
        [EnumValue("Complete", typeof(CommonResx))]
        Complete = 4,
    }
}
