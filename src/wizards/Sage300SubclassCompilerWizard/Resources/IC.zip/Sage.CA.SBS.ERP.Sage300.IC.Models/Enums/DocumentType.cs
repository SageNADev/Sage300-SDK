// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for DocumentType
	/// </summary>
	public enum DocumentType
	{
		/// <summary>
		/// Gets or sets None
		/// </summary>
		[EnumValue("None", typeof(CommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets QuantityonSO
		/// </summary>
        [EnumValue("QuantityonSO", typeof(ItemLocationDocumentResx))]
		QuantityonSO = 1,

		/// <summary>
		/// Gets or sets QuantityCommitted
		/// </summary>
        [EnumValue("QuantityCommitted", typeof(ItemLocationDocumentResx))]
		QuantityCommitted = 2,

		/// <summary>
		/// Gets or sets QuantityonPO
		/// </summary>
        [EnumValue("QuantityonPO", typeof(ItemLocationDocumentResx))]
		QuantityonPO = 3
	}
}
