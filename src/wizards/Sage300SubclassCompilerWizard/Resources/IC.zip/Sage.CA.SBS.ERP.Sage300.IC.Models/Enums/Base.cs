// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for Base
	/// </summary>
	public enum Base
	{
		/// <summary>
		/// Gets or sets Increase
		/// </summary>
        [EnumValue("Increase", typeof(UpdateBillsOfMaterialResx))]
		Increase = 1,

		/// <summary>
		/// Gets or sets Decrease
		/// </summary>
        [EnumValue("Decrease", typeof(UpdateBillsOfMaterialResx))]
		Decrease = 2
	}
}
