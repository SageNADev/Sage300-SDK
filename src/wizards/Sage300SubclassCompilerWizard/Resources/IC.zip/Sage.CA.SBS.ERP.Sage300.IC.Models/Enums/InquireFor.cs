// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Inquire For Enum
    /// </summary>
    public enum InquireFor
    {
        /// <summary>
        /// Gets or sets Specific Location
        /// </summary>
        [EnumValue("SpecificLocation", typeof(ICCommonResx))]
        SpecificLocation = 1,

        /// <summary>
        /// Gets or sets All Locations
        /// </summary>
        [EnumValue("AllLocations", typeof(ICCommonResx))]
        AllLocation = 2,
    }
}
