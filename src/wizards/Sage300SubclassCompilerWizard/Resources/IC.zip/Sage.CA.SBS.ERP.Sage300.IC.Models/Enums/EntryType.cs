// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace References

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for EntryType
    /// </summary>
    public enum EntryType
    {
        #region EntryType enums

        /// <summary>
        /// Gets or sets Shipment
        /// </summary>
        [EnumValue("Shipment", typeof (ICCommonResx))] Shipment = 1,

        /// <summary>
        /// Gets or sets Return
        /// </summary>
        [EnumValue("Return", typeof (ICCommonResx))] Return = 2,

        #endregion
    }
}
