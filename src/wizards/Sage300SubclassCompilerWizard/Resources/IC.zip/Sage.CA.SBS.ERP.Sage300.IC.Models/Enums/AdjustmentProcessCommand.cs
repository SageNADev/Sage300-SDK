﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand
    /// </summary>
    public enum AdjustmentProcessCommand
    {
        #region Properties

        /// <summary>
        /// Gets or sets NothingtoProcess 
        /// </summary>
        [EnumValue("NothingToProcess", typeof(ICCommonResx))]
        NothingToProcess = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>
        [EnumValue("InsertOptionalFields", typeof(ICCommonResx))]
        InsertOptionalFields = 1,

        /// <summary>
        /// Gets or sets DefaultAndTranferOptionalFields
        /// </summary>
        [EnumValue("DefaultAndTranferOptionalFields", typeof(ICEnumerationsResx))]
        DefaultAndTranferOptionalFields = 2,
        
        /// <summary>
        /// Gets or sets DefaultOptFieldsDuringRecordGeneration
        /// </summary>
        [EnumValue("DefaultOptFieldsDuringRecordGeneration", typeof(InventoryWorksheetResx))]
        DefaultOptFieldsDuringRecordGeneration = 3,

        #endregion
    }
}
