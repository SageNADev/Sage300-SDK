﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    public enum LotSplitCombineType
    {
        /// <summary>
        /// Gets or Sets Split
        /// </summary>
        [EnumValue("Split", typeof(LotSplitsCombinesResx))]
        Split = 1,

        /// <summary>
        /// Gets or Sets Combine
        /// </summary>
        [EnumValue("Combine", typeof(LotSplitsCombinesResx))]
        Combine = 2
    }
}
