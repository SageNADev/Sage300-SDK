// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for ReorderFor
	/// </summary>
	public enum ReorderFor
	{
        /// <summary>
        /// Gets or sets Default
        /// </summary>
        Default = 0,

		/// <summary>
		/// Gets or sets SpecificLocation
		/// </summary>
        [EnumValue("SpecificLocation", typeof(ICCommonResx))]
		SpecificLocation = 1,

		/// <summary>
		/// Gets or sets AllLocations
		/// </summary>
        [EnumValue("AllLocations", typeof(ICCommonResx))]
		AllLocations = 2
	}
}
