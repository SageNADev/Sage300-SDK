// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for WorksheetStatus
     /// </summary>
     public enum WorksheetStatus
     {
          /// <summary>
          /// Gets or sets NotPosted
          /// </summary>
          [EnumValue("NotPosted", typeof(InventoryWorksheetResx))]
          NotPosted = 1,

          /// <summary>
          /// Gets or sets Posted
          /// </summary>
          [EnumValue("Posted", typeof(InventoryWorksheetResx))]
          Posted = 2,

          /// <summary>
          /// Gets or sets ErrorsonPosting
          /// </summary>
          [EnumValue("ErrorsonPosting", typeof(InventoryWorksheetResx))]
          ErrorsonPosting = 3,
     }
}
