// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for BucketType
     /// </summary>
     public enum BucketType
     {
          /// <summary>
          /// Gets or sets OffsetBucket
          /// </summary>
         [EnumValue("OffsetBucket", typeof(AdjustmentResx))]
         OffsetBucket = 1,
          /// <summary>
          /// Gets or sets SpecificBucket
          /// </summary>
         [EnumValue("SpecificBucket", typeof(AdjustmentResx))]
         SpecificBucket = 2,
          /// <summary>
          /// Gets or sets Prorate
          /// </summary>
         [EnumValue("Prorate", typeof(AdjustmentResx))]
         Prorate = 3,
     }
}
