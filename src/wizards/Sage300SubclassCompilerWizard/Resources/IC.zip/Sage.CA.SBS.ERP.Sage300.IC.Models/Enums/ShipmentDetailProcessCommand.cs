// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand
    /// </summary>
    public enum ShipmentDetailProcessCommand
    {
        #region ShipmentDetailProcessCommand enums

        /// <summary>
        /// Gets or sets NothingToProcess
        /// </summary>
        NothingToProcess = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        InsertOptionalFields = 1,

        /// <summary>
        /// Gets or sets AutogenerateSerials
        /// </summary>
        AutogenerateSerials = 21,

        /// <summary>
        /// Gets or sets AutogenerateLots
        /// </summary>
        AutogenerateLots = 22,

        /// <summary>
        /// Gets or sets AutoallocateSerials
        /// </summary>
        AutoallocateSerials = 23,

        /// <summary>
        /// Gets or sets AutoallocateLots
        /// </summary>
        AutoallocateLots = 24,

        /// <summary>
        /// Gets or sets ClearSerials
        /// </summary>
        ClearSerials = 25,

        /// <summary>
        /// Gets or sets ClearLots
        /// </summary>
        ClearLots = 26,

        /// <summary>
        /// Gets or sets PostSerialsLotsToICInventory
        /// </summary>
        PostSerialsLotsToICInventory = 31,
        
        #endregion
    }
}
