﻿using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.ExportImport
{
        /// <summary>
        /// Enum for Physical Export/Import Options.
        /// </summary>
        public enum PhysicalInventoryExportImportOptions
        {
            [EnumValue("PhysicalInvQuantity", typeof(ICCommonResx))]
            PhysicalInvQuantity = 1,

            [EnumValue("PhysicalInvQuantityHeader", typeof(ICCommonResx))]
            PhysicalInvQuantityHeader = 2,
        }
  
}
