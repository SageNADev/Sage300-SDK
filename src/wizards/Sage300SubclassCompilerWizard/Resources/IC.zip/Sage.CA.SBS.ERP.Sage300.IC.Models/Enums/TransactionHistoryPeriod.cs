// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Process
{
    /// <summary>
    /// Enum for TransactionHistoryPeriod
    /// </summary>
    public enum TransactionHistoryPeriod
    {
        /// <summary>
        /// Gets or sets Num1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num1 = 1,

        /// <summary>
        /// Gets or sets Num2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num2 = 2,

        /// <summary>
        /// Gets or sets Num3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num3 = 3,

        /// <summary>
        /// Gets or sets Num4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num4 = 4,

        /// <summary>
        /// Gets or sets Num5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num5 = 5,

        /// <summary>
        /// Gets or sets Num6
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num6 = 6,

        /// <summary>
        /// Gets or sets Num7
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num7 = 7,

        /// <summary>
        /// Gets or sets Num8
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num8 = 8,

        /// <summary>
        /// Gets or sets Num9
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num9 = 9,

        /// <summary>
        /// Gets or sets Num10
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num10 = 10,

        /// <summary>
        /// Gets or sets Num11
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num11 = 11,

        /// <summary>
        /// Gets or sets Num12
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        Num12 = 12
    }
}
