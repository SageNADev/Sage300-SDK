// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
     /// <summary>
     /// Enum for Quarterwith4Periods
     /// </summary>
     public enum Quarterwith4Periods
     {
          /// <summary>
          /// Gets or sets Num1
          /// </summary>
          Num1 = 1,
          /// <summary>
          /// Gets or sets Num2
          /// </summary>
          Num2 = 2,
          /// <summary>
          /// Gets or sets Num3
          /// </summary>
          Num3 = 3,
          /// <summary>
          /// Gets or sets Num4
          /// </summary>
          Num4 = 4,
     }
}
