// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum SerialNumberHistoryStatus
    {
        /// <summary>
        /// Gets or sets Adjusted
        /// </summary>
        [EnumValue("Adjusted", typeof(ICCommonResx))]
        Adjusted = 0,

        /// <summary>
        /// Gets or sets Removed
        /// </summary>
        [EnumValue("Removed", typeof(SerialNumberResx))]
        Removed = -1,

        /// <summary>
        /// Gets or sets Added
        /// </summary>
        [EnumValue("Added", typeof(SerialNumberResx))]
        Added = 1
    }
}