// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Default Posting Date
    /// </summary>
    public enum DefaultPostingDate
    {
        /// <summary>
        /// Document Date
        /// </summary>
        [EnumValue("DocumentDate", typeof (ICCommonResx))] DocumentDate = 1,

        /// <summary>
        /// Session Date
        /// </summary>
        [EnumValue("SessionDate", typeof (CommonResx))] SessionDate = 2,
    }
}