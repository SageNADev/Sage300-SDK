// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for RoundingMethod 
    /// </summary>
    public enum RoundingMethod
    {
        /// <summary>
        /// Gets or sets NoRounding 
        /// </summary>	
        [EnumValue("NoRounding", typeof(ICCommonResx))]
        NoRounding = 1,

        /// <summary>
        /// Gets or sets RoundUp 
        /// </summary>	
        [EnumValue("RoundUp", typeof(ICCommonResx))]
        RoundUp = 2,

        /// <summary>
        /// Gets or sets RoundDown 
        /// </summary>	
        [EnumValue("RoundDown", typeof(ICCommonResx))]
        RoundDown = 3,
    }
}
