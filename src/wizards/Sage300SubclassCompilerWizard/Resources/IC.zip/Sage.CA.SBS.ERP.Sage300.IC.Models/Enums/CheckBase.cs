// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for CheckBase 
    /// </summary>
    public enum CheckBase
    {
        /// <summary>
        /// Gets or sets CostPlusaPercentage 
        /// </summary>	
        [EnumValue("CostPlusaPercentage", typeof(ICCommonResx))]
        CostPlusaPercentage = 1,

        /// <summary>
        /// Gets or sets CostPlusaFixedAmount 
        /// </summary>	
        [EnumValue("CostPlusaFixedAmount", typeof(ICCommonResx))]
        CostPlusaFixedAmount = 2,

        /// <summary>
        /// Gets or sets FixedAmount 
        /// </summary>	
        [EnumValue("FixedAmount", typeof(ICCommonResx))]
        FixedAmount = 3,
    }
}
