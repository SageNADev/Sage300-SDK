// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for SortOrder
    /// </summary>
    public enum SortOrder
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(EnumerationsResx))]
        None = 0,

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemNumber", typeof(ICCommonResx))]
        ItemNumber = 1,

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Category", typeof(ICCommonResx))]
        Category = 2,

        /// <summary>
        /// Gets or sets ItemSegment
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemSegment", typeof(ICCommonResx))]
        ItemSegment = 3,

        /// <summary>
        /// Gets or sets PickingSequence
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("PickingSequence", typeof(ICCommonResx))]
        PickingSequence = 4,

        /// <summary>
        /// Gets or sets ItemsColor
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemsColor", typeof(InventoryWorksheetResx))]
        ItemsColor = 9,

        /// <summary>
        /// Gets or sets DangerousItem
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("DangerousItem", typeof(AlternateItemsReportResx))]
        DangerousItem = 10,

        /// <summary>
        /// Gets or sets ExtendedWarrantyAvailable
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ExtendedWarrantyAvailable", typeof(AlternateItemsReportResx))]
        ExtendedWarrantyAvailable = 11,

        /// <summary>
        /// Gets or sets ItemType
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemType", typeof(AlternateItemsReportResx))]
        ItemType = 12,

        /// <summary>
        /// Gets or sets ItemLeadTime
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemLeadTime", typeof(AlternateItemsReportResx))]
        ItemLeadTime = 13,

        /// <summary>
        /// Gets or sets Manufacturer
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Manufacturer", typeof(AlternateItemsReportResx))]
        Manufacturer = 14,

        /// <summary>
        /// Gets or sets ManufacturerNumber
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ManufacturerNumber", typeof(ReorderReportResx))]
        ManufacturerNumber = 15,

        /// <summary>
        /// Gets or sets NewItem
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("NewItem", typeof(AlternateItemsReportResx))]
        NewItem = 16,

        /// <summary>
        /// Gets or sets Price
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Price", typeof(ReorderReportResx))]
        Price = 17,

        /// <summary>
        /// Gets or sets ItemProcurement
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemProcurement", typeof(ReorderReportResx))]
        ItemProcurement = 18,

        /// <summary>
        /// Gets or sets ItemSize
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemSize", typeof(AlternateItemsReportResx))]
        ItemSize = 19,

        /// <summary>
        /// Gets or sets ItemVolume
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("ItemVolume", typeof(AlternateItemsReportResx))]
        ItemVolume = 20,

        /// <summary>
        /// Gets or sets Warranty
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Warranty", typeof(ICCommonResx))]
        Warranty = 21,

        /// <summary>
        /// Gets or sets WarrantyPeriod
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("WarrantyPeriod", typeof(AlternateItemsReportResx))]
        WarrantyPeriod = 22
    }
}
