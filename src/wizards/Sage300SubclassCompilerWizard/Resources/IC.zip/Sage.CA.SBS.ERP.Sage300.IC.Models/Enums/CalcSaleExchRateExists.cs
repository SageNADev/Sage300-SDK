// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for CalcSaleExchRateExists
    /// </summary>
    public enum CalcSaleExchRateExists
    {
        /// <summary>
        /// Gets or sets Ratedoesnotexist
        /// </summary>
        [EnumValue("RateDoesNotExist", typeof(ItemPricingResx))]
        Ratedoesnotexist = 0,

        /// <summary>
        /// Gets or sets Rateexists
        /// </summary>
        [EnumValue("RateExists", typeof(ItemPricingResx))]
        Rateexists = 1,

        /// <summary>
        /// Gets or sets RateIscalculated
        /// </summary>
        [EnumValue("RateIsCalculated", typeof(ItemPricingResx))]
        RateIscalculated = 2,
    }
}
