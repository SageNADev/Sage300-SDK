// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region NameSpaces 

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
    /// Enum for Pricing Price By 
    /// </summary>
	public enum PricingPriceBy 
	{
			/// <summary>
		/// Gets or sets Quantity 
		/// </summary>	
        [EnumValue("Quantity", typeof(ICCommonResx))]
        Quantity = 1,
		/// <summary>
		/// Gets or sets Weight 
		/// </summary>	
        [EnumValue("Weight", typeof(ICCommonResx))]
        Weight = 2,
	}
}
