// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Transaction Post Oredr or Cost
    /// </summary>
    public enum TransactionpostOrdepOrcost
    {
        /// <summary>
        /// QuantityOnly
        /// </summary>
        QuantityOnly = 11,

        /// <summary>
        /// CostOnly 
        /// </summary>
        CostOnly = 12,

        /// <summary>
        /// CostandLedger 
        /// </summary>
        CostandLedger = 13,
    }
}