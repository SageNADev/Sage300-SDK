﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for OrderInquiryType
    /// </summary>
    public enum OrderInquiryType
    {
        /// <summary>
        /// Gets or sets PurchaseOrders
        /// </summary>
        [EnumValue("ListPurchaseOrders", typeof(CurrentTransactionsInquiryResx))]
        PurchaseOrders = 1,

        /// <summary>
        /// Gets or sets SalesOrders
        /// </summary>
        [EnumValue("ListSaleOrders", typeof(CurrentTransactionsInquiryResx))]
        SalesOrders = 2,
    }
}
