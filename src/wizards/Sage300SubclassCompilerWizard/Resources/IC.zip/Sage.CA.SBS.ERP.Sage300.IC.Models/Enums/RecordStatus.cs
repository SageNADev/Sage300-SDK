// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for RecordStatus
    /// </summary>
    public enum RecordStatus
    {
        /// <summary>
        /// Gets or sets Entered
        /// </summary>
        [EnumValue("Entered", typeof(ICCommonResx))]
        Entered = 1,

        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("Posted", typeof(ICCommonResx))]
        Posted = 2,

        /// <summary>
        /// Gets or sets Costed
        /// </summary>
        [EnumValue("Costed", typeof(ICCommonResx))]
        Costed = 3,

        /// <summary>
        /// Gets or sets DayEndCompleted
        /// </summary>
        [EnumValue("DayEndCompleted", typeof(ICCommonResx))]
        DayEndCompleted = 20,
    }
}
