// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for Source Transaction Type
    /// </summary>
    public enum SourceTransactionType
    {
        #region SourceTransactionType enums

        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [EnumValue("Receipt", typeof (ICCommonResx), 1)] Receipt = 100,

        /// <summary>
        /// Gets or sets Receipt Detail
        /// </summary>
        [EnumValue("ReceiptDetail", typeof (GLIntegrationResx), 2)] ReceiptDetail = 101,

        /// <summary>
        /// Gets or sets Shipment
        /// </summary>
        [EnumValue("Shipment", typeof (ICCommonResx), 3)] Shipment = 200,

        /// <summary>
        /// Gets or sets Shipment Detail
        /// </summary>
        [EnumValue("ShipmentDetail", typeof (GLIntegrationResx), 4)] ShipmentDetail = 201,

        /// <summary>
        /// Gets or sets Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof (ICCommonResx), 5)] Adjustment = 300,

        /// <summary>
        /// Gets or sets Adjustment Detail
        /// </summary>
        [EnumValue("AdjustmentDetail", typeof (GLIntegrationResx), 6)] AdjustmentDetail = 301,

        /// <summary>
        /// Gets or sets Transfer
        /// </summary>
        [EnumValue("Transfer", typeof (ICCommonResx), 7)] Transfer = 400,

        /// <summary>
        /// Gets or sets Transfer Detail
        /// </summary>
        [EnumValue("TransferDetail", typeof (GLIntegrationResx), 8)] TransferDetail = 401,

        /// <summary>
        /// Gets or sets Assemblies
        /// </summary>
        [EnumValue("Assemblies", typeof (ICCommonResx), 9)] Assemblies = 500,

        /// <summary>
        /// Gets or sets Internal Usage
        /// </summary>
        [EnumValue("InternalUsage", typeof (ICCommonResx), 10)] InternalUsage = 600,

        /// <summary>
        /// Gets or sets Internal Usage Detail
        /// </summary>
        [EnumValue("InternalUsageDetail", typeof (GLIntegrationResx), 11)] InternalUsageDetail = 601,

        #endregion
    }
}
