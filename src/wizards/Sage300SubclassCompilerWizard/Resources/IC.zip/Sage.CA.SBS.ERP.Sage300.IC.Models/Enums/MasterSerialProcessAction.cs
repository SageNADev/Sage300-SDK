// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for MasterSerialProcessAction
	/// </summary>
	public enum MasterSerialProcessAction
	{
		/// <summary>
		/// Gets or sets None
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets AddMasterSerial
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		AddMasterSerial = 1,

		/// <summary>
		/// Gets or sets DeleteMasterSerial
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		DeleteMasterSerial = 2,

		/// <summary>
		/// Gets or sets VerifyMasterSerial
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		VerifyMasterSerial = 3,

		/// <summary>
		/// Gets or sets AssignMasterSerialsToComps
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		AssignMasterSerialsToComps = 4
	}
}
