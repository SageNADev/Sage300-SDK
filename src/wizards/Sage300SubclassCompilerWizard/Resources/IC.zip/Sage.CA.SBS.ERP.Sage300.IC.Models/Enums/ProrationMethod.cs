// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for ProrationMethod
	/// </summary>
	public enum ProrationMethod
	{
		/// <summary>
		/// Gets or sets ProratebyQuantity
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProratebyQuantity", typeof(EnumerationsResx))]
		ProratebyQuantity = 1,

		/// <summary>
		/// Gets or sets ProratebyWeight
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProratebyWeight", typeof(EnumerationsResx))]
		ProratebyWeight = 2,

		/// <summary>
		/// Gets or sets ProratebyCost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProratebyCost", typeof(EnumerationsResx))]
		ProratebyCost = 3,

		/// <summary>
		/// Gets or sets ProrateEqually
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProrateEqually", typeof(ICEnumerationsResx))]
		ProrateEqually = 4,

		/// <summary>
		/// Gets or sets ProrateManually
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
        [EnumValue("ProrateManually", typeof(EnumerationsResx))]
		ProrateManually = 5
	}
}
