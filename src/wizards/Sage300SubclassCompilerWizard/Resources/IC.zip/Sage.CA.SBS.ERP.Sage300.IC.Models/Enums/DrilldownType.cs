// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
	/// Enum for DrilldownType
	/// </summary>
	public enum DrilldownType
	{
		/// <summary>
		/// Gets or sets Nodrilldowninformationavailable
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		Nodrilldowninformationavailable = 0,

		/// <summary>
		/// Gets or sets Keepparentwindowopen
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		Keepparentwindowopen = 1,

		/// <summary>
		/// Gets or sets Closeparentwindow
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		Closeparentwindow = 2,

		/// <summary>
		/// Gets or sets NotallowedTodrilldownTothisappl
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		NotallowedTodrilldownTothisappl = 3
	}
}