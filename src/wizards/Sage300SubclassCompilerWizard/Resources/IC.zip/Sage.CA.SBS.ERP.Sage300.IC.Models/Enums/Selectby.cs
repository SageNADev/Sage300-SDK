 
namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
	/// <summary>
    /// Enum for Selectby 
    /// </summary>
	public enum Selectby 
	{
			/// <summary>
		/// Gets or sets ItemNumber 
		/// </summary>	
        ItemNumber = 1,
		/// <summary>
		/// Gets or sets Category 
		/// </summary>	
        Category = 2,
		/// <summary>
		/// Gets or sets ItemSegment 
		/// </summary>	
        ItemSegment = 3,
		/// <summary>
		/// Gets or sets PickingSequence 
		/// </summary>	
        PickingSequence = 4,
		/// <summary>
		/// Gets or sets ItemsColor 
		/// </summary>	
        ItemsColor = 9,
		/// <summary>
		/// Gets or sets DangerousItem 
		/// </summary>	
        DangerousItem = 10,
		/// <summary>
		/// Gets or sets ExtendedWarrantyAvailable 
		/// </summary>	
        ExtendedWarrantyAvailable = 11,
		/// <summary>
		/// Gets or sets ItemType 
		/// </summary>	
        ItemType = 12,
		/// <summary>
		/// Gets or sets ItemLeadTime 
		/// </summary>	
        ItemLeadTime = 13,
		/// <summary>
		/// Gets or sets Manufacturer 
		/// </summary>	
        Manufacturer = 14,
		/// <summary>
		/// Gets or sets ManufacturerNumber 
		/// </summary>	
        ManufacturerNumber = 15,
		/// <summary>
		/// Gets or sets NewItem 
		/// </summary>	
        NewItem = 16,
		/// <summary>
		/// Gets or sets Price 
		/// </summary>	
        Price = 17,
		/// <summary>
		/// Gets or sets ItemProcurement 
		/// </summary>	
        ItemProcurement = 18,
		/// <summary>
		/// Gets or sets ItemSize 
		/// </summary>	
        ItemSize = 19,
		/// <summary>
		/// Gets or sets ItemVolume 
		/// </summary>	
        ItemVolume = 20,
		/// <summary>
		/// Gets or sets Warranty 
		/// </summary>	
        Warranty = 21,
		/// <summary>
		/// Gets or sets WarrantyPeriod 
		/// </summary>	
        WarrantyPeriod = 22,
	}
}
