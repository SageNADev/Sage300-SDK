// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for DefaultBasePriceUsing
    /// </summary>
    public enum DefaultBasePriceUsing
    {
        /// <summary>
        /// Gets or sets NoDefault
        /// </summary>
        [EnumValue("NoDefault", typeof (ItemPricingResx))]
        NoDefault = 0,

        /// <summary>
        /// Gets or sets CostPlusaPercentage
        /// </summary>
        [EnumValue("CostPlusPercentage", typeof(ItemPricingResx))]
        CostPlusaPercentage = 1,

        /// <summary>
        /// Gets or sets CostPlusanAmount
        /// </summary>
        [EnumValue("CostPlusAmount", typeof(ItemPricingResx))] 
        CostPlusanAmount = 2,

        /// <summary>
        /// Gets or sets CostConvertedPlusaPercentage
        /// </summary>
        [EnumValue("CostConvertedPlusPercentage", typeof(ItemPricingResx))]
        CostConvertedPlusaPercentage = 3,

        /// <summary>
        /// Gets or sets CostConvertedPlusaAmount
        /// </summary>
        [EnumValue("CostConvertedPlusAmount", typeof(ItemPricingResx))]
        CostConvertedPlusaAmount = 4,
    }
}