// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand
    /// </summary>
    public enum ShipmentProcessCommand
    {
        #region ShipmentProcessCommand enums

        /// <summary>
        /// Gets or sets NothingToProcess
        /// </summary>
        NothingToProcess = 0,

        /// <summary>
        /// Gets or sets InsertOptionalFields
        /// </summary>
        InsertOptionalFields = 1,
        
        #endregion
    }
}
