﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Enums
{
    /// <summary>
    /// Enum for CostingMethod 
    /// </summary>
    public enum CostingMethod
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(EnumerationsResx))]
        None = 0,
        /// <summary>
        /// Gets or sets MovingAverage 
        /// </summary>	
        [EnumValue("MovingAverage", typeof(EnumerationsResx))]
        MovingAverage = 1,

        /// <summary>
        /// Gets or sets FIFO 
        /// </summary>	
        [EnumValue("FIFO", typeof(EnumerationsResx))]
        FIFO = 2,

        /// <summary>
        /// Gets or sets LIFO 
        /// </summary>	
        [EnumValue("LIFO", typeof(EnumerationsResx))]
        LIFO = 3,

        /// <summary>
        /// Gets or sets StandardCost 
        /// </summary>	
        [EnumValue("StandardCost", typeof(EnumerationsResx))]
        StandardCost = 4,

        /// <summary>
        /// Gets or sets MostRecentCost 
        /// </summary>	
        [EnumValue("MostRecentCost", typeof(EnumerationsResx))]
        MostRecentCost = 5,

        /// <summary>
        /// Gets or sets UserSpecified 
        /// </summary>	
        [EnumValue("UserSpecified", typeof(EnumerationsResx))]
        UserSpecified = 6,

        /// <summary>
        /// Gets or sets MostRecentCost 
        /// </summary>	
        [EnumValue("Serial", typeof(EnumerationsResx))]
        Serial = 7,

        /// <summary>
        /// Gets or sets UserSpecified 
        /// </summary>	
        [EnumValue("Lot", typeof(EnumerationsResx))]
        Lot = 8,

    }
}
