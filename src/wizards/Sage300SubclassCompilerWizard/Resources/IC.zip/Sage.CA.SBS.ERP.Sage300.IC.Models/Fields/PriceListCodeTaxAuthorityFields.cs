// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of PriceListCodeTaxAuthorities Constants 
    /// </summary>
	public partial class PriceListCodeTaxAuthority 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "IC0395";

        /// <summary>
        /// Contains list of PriceListCodeTaxAuthorities Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for PriceListCode 
        /// </summary>
	    public const string PriceListCode  = "PRICELIST";
	            /// <summary>
        /// Property for TaxAuthority 
        /// </summary>
	    public const string TaxAuthority  = "AUTHORITY";
	            /// <summary>
        /// Property for TaxIncludedinPrice 
        /// </summary>
	    public const string TaxIncludedinPrice  = "TAXINCL";
	            /// <summary>
        /// Property for CustomerTaxClass 
        /// </summary>
	    public const string CustomerTaxClass  = "TAXCLASS";
	            /// <summary>
        /// Property for CustomerTaxClassDescription 
        /// </summary>
	    public const string CustomerTaxClassDescription  = "TXCLSDESC";
	            /// <summary>
        /// Property for TaxAuthorityDescription 
        /// </summary>
	    public const string TaxAuthorityDescription  = "TXAUTHDESC";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of PriceListCodeTaxAuthorities Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for PriceListCode 
        /// </summary>
	    public const int PriceListCode  = 1;
	             /// <summary>
        /// Property Indexer for TaxAuthority 
        /// </summary>
	    public const int TaxAuthority  = 2;
	             /// <summary>
        /// Property Indexer for TaxIncludedinPrice 
        /// </summary>
	    public const int TaxIncludedinPrice  = 3;
	             /// <summary>
        /// Property Indexer for CustomerTaxClass 
        /// </summary>
	    public const int CustomerTaxClass  = 4;
	             /// <summary>
        /// Property Indexer for CustomerTaxClassDescription 
        /// </summary>
	    public const int CustomerTaxClassDescription  = 5;
	             /// <summary>
        /// Property Indexer for TaxAuthorityDescription 
        /// </summary>
	    public const int TaxAuthorityDescription  = 6;
	     
        #endregion
	    }

	
	}
}
	