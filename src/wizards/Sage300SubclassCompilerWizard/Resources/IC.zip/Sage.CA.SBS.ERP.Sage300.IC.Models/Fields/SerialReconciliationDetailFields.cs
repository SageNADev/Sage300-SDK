// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of SerialReconciliationDetail Constants
	/// </summary>
	public partial class SerialReconciliationDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0828";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of SerialReconciliationDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "SEQUENCENO";

			/// <summary>
			/// Property for SerialNumber
			/// </summary>
			public const string SerialNumber = "SERIALNUMF";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of SerialReconciliationDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for SerialNumber
			/// </summary>
			public const int SerialNumber = 2;

		}

		#endregion

	}
}
