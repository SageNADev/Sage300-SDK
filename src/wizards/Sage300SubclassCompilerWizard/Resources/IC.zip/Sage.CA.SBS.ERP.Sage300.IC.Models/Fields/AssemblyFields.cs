// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
// ReSharper disable CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of Assemblie Constants
	/// </summary>
	public partial class Assembly
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0160";

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0160";

	    [IgnoreExportImport]
	    public static Dictionary<string, string> DynamicAttributes
	    {
            get {
                return new Dictionary<string, string> {
                {"ASSMENSEQ","SequenceNumber"},
			    {"TRANSNUM","TransactionNumber"},
			     {"DOCNUM","AssemblyNumber"},
			     {"TRANSDATE","TransactionDate"},
			     {"FISCYEAR","FiscalYear"},
			     {"FISCPERIOD","FiscalPeriod"},
                 {"REFERENCE","Reference"},
			     {"HDRDESC","Description"},
			     {"ITEMNO","ItemNumber"},
			     {"BOMNO","BOMNumber"},
                 {"LOCATION","Location"},
			     {"QUANTITY","Quantity"},
			     {"UNIT","UnitOfMeasure"},
			     {"TRANSTYPE","TransactionType"},
			     {"DOCUNIQ","ICUniqueDocumentNumber"},
			     {"STATUS","RecordStatus"},
			     {"DELETED","RecordDeleted"},
			     {"MANITEMNO","ManufacturersItemNumber"},
                 {"UNITCOST","UnitCost"},
			     {"FROMASSNUM","FromAssemblyNumber"},
			     {"FROMASSQTY","FromAssemblyQuantity"},
			     {"DISASSCOST","DisassemblyCost"},
			     {"PRINTED","RecordPrinted"},
			     {"VALUES","OptionalFields"},
			     {"MASTASSNUM","MasterAssemblyNumber"},
			     {"COMPASSMTD","ComponentAssemblyMethod"},
			     {"USEDQTY","QuantityUsed"},
			     {"NEEDQTYSTK","QtyNeededStockingUOM"},
			     {"MULTLEVEL","MultilevelLevel"},
			     {"MULTSEQ","MultilevelSeqNo"},
			     {"PRNMULTSEQ","MultilevelParentSeqNo"},
			     {"PRNASSNUM","MultilevelParentAssemblyNo"},
			     {"CMPMASTITM","ComponentsMasterItemNo"},
			     {"ENTEREDBY","EnteredBy"},
			     {"DATEBUS","PostingDate"},
			     {"SITEMCOUNT","SerialItemsInAssembly"},
			     {"LITEMCOUNT","LotItemsInAssembly"},
			     {"REMAINASSD","AssemblyQuantityRemaining"},
			     {"CONVERSION","ConversionFactor"},
			     {"IPCID","InterprocessCommID"},
			     {"ESTIMACOST","EstimatedCost"},
			     {"FORCEPOPSN","ForcePopupSN"},
			     {"POPUPSN","PopupSN"},
			     {"CLOSESN","CloseSN"},
			     {"LTSETID","LTSetID"},
			     {"FORCEPOPLT","ForcePopupLT"},
			     {"POPUPLT","PopupLT"},
			     {"CLOSELT","CloseLT"},
			     {"CDOCNUM","CDOCNUM"},
			     {"POSTSEQNUM","PostSequenceNumber"},
			     {"FROMASSSEQ","FromAssemblySeq"},
			     {"PROCESSCMD","ProcessCommand"},
			     {"FMTITEMNO","FormattedItemNumber"},
			     {"FMTCMPMAST","FormattedCompMasterItemNo"},
			     {"ITEMDESC","ItemDescription"},
			     {"GLBATCHID","GLBatchID"},
			     {"XGENALCQTY","SerialLotQuantityToProcess"},
			     {"XLOTMAKQTY","NumberOfLotsToGenerate"},
			     {"XPERLOTQTY","QuantityperLot"},
			     {"THISCOMPID","CompIDCurrentlyProcessed"},
			     {"XPRNCOMPID","ParentSerialLotComponentID"},
			     {"XITEM","SerialLotItem"},
			     {"XBOMNO","SerialLotBOMNumber"},
			     {"XUNIT","SerialLotItemUnitOfMeasure"},
			     {"XPRNITEM","SerialMasterItem"},
			     {"SQTYNEEDED","SerialQuantityRequired"},
			     {"LQTYNEEDED","LotQuantityRequired"},
			     {"SQTYGENALC","SerialQuantity"},
			     {"LQTYGENALC","LotQuantity"},
			     {"XPRNSERNUM","MasterSerialNumber"},
			     {"XPRNSACTN","MasterSerialProcessAction"},
			     {"SALLOCFROM","AllocateFromSerial"},
			     {"LALLOCFROM","AllocateFromLot"},
			     {"METERHWND","SerialLotWindowHandle"},
			     {"NOUPDATE","Disallowsavepost"},
                }; 
            }
	    }

	    #region Properties

		/// <summary>
		/// Contains list of Assemblie Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "ASSMENSEQ";

			/// <summary>
			/// Property for TransactionNumber
			/// </summary>
			public const string TransactionNumber = "TRANSNUM";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for DOCNUM
			/// </summary>
			public const string AssemblyNumber = "DOCNUM";

			/// <summary>
			/// Property for TransactionDate
			/// </summary>
			public const string TransactionDate = "TRANSDATE";

			/// <summary>
			/// Property for FiscalYear
			/// </summary>
			public const string FiscalYear = "FISCYEAR";

			/// <summary>
			/// Property for FiscalPeriod
			/// </summary>
			public const string FiscalPeriod = "FISCPERIOD";

			/// <summary>
			/// Property for Reference
			/// </summary>
			public const string Reference = "REFERENCE";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "HDRDESC";

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for BOMNumber
			/// </summary>
			public const string BOMNumber = "BOMNO";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for Quantity
			/// </summary>
			public const string Quantity = "QUANTITY";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "UNIT";

			/// <summary>
			/// Property for TransactionType
			/// </summary>
			public const string TransactionType = "TRANSTYPE";

			/// <summary>
			/// Property for ICUniqueDocumentNumber
			/// </summary>
			public const string ICUniqueDocumentNumber = "DOCUNIQ";

			/// <summary>
			/// Property for RecordStatus
			/// </summary>
			public const string RecordStatus = "STATUS";

			/// <summary>
			/// Property for RecordDeleted
			/// </summary>
			public const string RecordDeleted = "DELETED";

			/// <summary>
			/// Property for ManufacturersItemNumber
			/// </summary>
			public const string ManufacturersItemNumber = "MANITEMNO";

			/// <summary>
			/// Property for UnitCost
			/// </summary>
			public const string UnitCost = "UNITCOST";

			/// <summary>
			/// Property for FromAssemblyNumber
			/// </summary>
			public const string FromAssemblyNumber = "FROMASSNUM";

			/// <summary>
			/// Property for FromAssemblyQuantity
			/// </summary>
			public const string FromAssemblyQuantity = "FROMASSQTY";

			/// <summary>
			/// Property for DisassemblyCost
			/// </summary>
			public const string DisassemblyCost = "DISASSCOST";

			/// <summary>
			/// Property for RecordPrinted
			/// </summary>
			public const string RecordPrinted = "PRINTED";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for MasterAssemblyNumber
			/// </summary>
			public const string MasterAssemblyNumber = "MASTASSNUM";

			/// <summary>
			/// Property for ComponentAssemblyMethod
			/// </summary>
			public const string ComponentAssemblyMethod = "COMPASSMTD";

			/// <summary>
			/// Property for QuantityUsed
			/// </summary>
			public const string QuantityUsed = "USEDQTY";

			/// <summary>
			/// Property for QtyNeededStockingUOM
			/// </summary>
			public const string QtyNeededStockingUOM = "NEEDQTYSTK";

			/// <summary>
			/// Property for MultilevelLevel
			/// </summary>
			public const string MultilevelLevel = "MULTLEVEL";

			/// <summary>
			/// Property for MultilevelSeqNo
			/// </summary>
			public const string MultilevelSeqNo = "MULTSEQ";

			/// <summary>
			/// Property for MultilevelParentSeqNo
			/// </summary>
			public const string MultilevelParentSeqNo = "PRNMULTSEQ";

			/// <summary>
			/// Property for MultilevelParentAssemblyNo
			/// </summary>
			public const string MultilevelParentAssemblyNo = "PRNASSNUM";

			/// <summary>
			/// Property for ComponentsMasterItemNo
			/// </summary>
			public const string ComponentsMasterItemNo = "CMPMASTITM";

			/// <summary>
			/// Property for EnteredBy
			/// </summary>
			public const string EnteredBy = "ENTEREDBY";

			/// <summary>
			/// Property for PostingDate
			/// </summary>
			public const string PostingDate = "DATEBUS";

			/// <summary>
			/// Property for SerialItemsInAssembly
			/// </summary>
			public const string SerialItemsInAssembly = "SITEMCOUNT";

			/// <summary>
			/// Property for LotItemsInAssembly
			/// </summary>
			public const string LotItemsInAssembly = "LITEMCOUNT";

			/// <summary>
			/// Property for AssemblyQuantityRemaining
			/// </summary>
			public const string AssemblyQuantityRemaining = "REMAINASSD";

			/// <summary>
			/// Property for ConversionFactor
			/// </summary>
			public const string ConversionFactor = "CONVERSION";

			/// <summary>
			/// Property for InterprocessCommID
			/// </summary>
			public const string InterprocessCommID = "IPCID";

			/// <summary>
			/// Property for EstimatedCost
			/// </summary>
			public const string EstimatedCost = "ESTIMACOST";

			/// <summary>
			/// Property for ForcePopupSN
			/// </summary>
			public const string ForcePopupSN = "FORCEPOPSN";

			/// <summary>
			/// Property for PopupSN
			/// </summary>
			public const string PopupSN = "POPUPSN";

			/// <summary>
			/// Property for CloseSN
			/// </summary>
			public const string CloseSN = "CLOSESN";

			/// <summary>
			/// Property for LTSetID
			/// </summary>
			public const string LTSetID = "LTSETID";

			/// <summary>
			/// Property for ForcePopupLT
			/// </summary>
			public const string ForcePopupLT = "FORCEPOPLT";

			/// <summary>
			/// Property for PopupLT
			/// </summary>
			public const string PopupLT = "POPUPLT";

			/// <summary>
			/// Property for CloseLT
			/// </summary>
			public const string CloseLT = "CLOSELT";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for CDOCNUM
			/// </summary>
			public const string CDOCNUM = "CDOCNUM";

			/// <summary>
			/// Property for PostSequenceNumber
			/// </summary>
			public const string PostSequenceNumber = "POSTSEQNUM";

			/// <summary>
			/// Property for FromAssemblySeq
			/// </summary>
			public const string FromAssemblySeq = "FROMASSSEQ";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

			/// <summary>
			/// Property for FormattedItemNumber
			/// </summary>
			public const string FormattedItemNumber = "FMTITEMNO";

			/// <summary>
			/// Property for FormattedCompMasterItemNo
			/// </summary>
			public const string FormattedCompMasterItemNo = "FMTCMPMAST";

			/// <summary>
			/// Property for ItemDescription
			/// </summary>
			public const string ItemDescription = "ITEMDESC";

			/// <summary>
			/// Property for GLBatchID
			/// </summary>
			public const string GLBatchID = "GLBATCHID";

			/// <summary>
			/// Property for SerialLotQuantityToProcess
			/// </summary>
			public const string SerialLotQuantityToProcess = "XGENALCQTY";

			/// <summary>
			/// Property for NumberOfLotsToGenerate
			/// </summary>
			public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

			/// <summary>
			/// Property for QuantityperLot
			/// </summary>
			public const string QuantityperLot = "XPERLOTQTY";

			/// <summary>
			/// Property for CompIDCurrentlyProcessed
			/// </summary>
			public const string CompIDCurrentlyProcessed = "THISCOMPID";

			/// <summary>
			/// Property for ParentSerialLotComponentID
			/// </summary>
			public const string ParentSerialLotComponentID = "XPRNCOMPID";

			/// <summary>
			/// Property for SerialLotItem
			/// </summary>
			public const string SerialLotItem = "XITEM";

			/// <summary>
			/// Property for SerialLotBOMNumber
			/// </summary>
			public const string SerialLotBOMNumber = "XBOMNO";

			/// <summary>
			/// Property for SerialLotItemUnitOfMeasure
			/// </summary>
			public const string SerialLotItemUnitOfMeasure = "XUNIT";

			/// <summary>
			/// Property for SerialMasterItem
			/// </summary>
			public const string SerialMasterItem = "XPRNITEM";

			/// <summary>
			/// Property for SerialQuantityRequired
			/// </summary>
			public const string SerialQuantityRequired = "SQTYNEEDED";

			/// <summary>
			/// Property for LotQuantityRequired
			/// </summary>
			public const string LotQuantityRequired = "LQTYNEEDED";

			/// <summary>
			/// Property for SerialQuantity
			/// </summary>
			public const string SerialQuantity = "SQTYGENALC";

			/// <summary>
			/// Property for LotQuantity
			/// </summary>
			public const string LotQuantity = "LQTYGENALC";

			/// <summary>
			/// Property for MasterSerialNumber
			/// </summary>
			public const string MasterSerialNumber = "XPRNSERNUM";

			/// <summary>
			/// Property for MasterSerialProcessAction
			/// </summary>
			public const string MasterSerialProcessAction = "XPRNSACTN";

			/// <summary>
			/// Property for AllocateFromSerial
			/// </summary>
			public const string AllocateFromSerial = "SALLOCFROM";

			/// <summary>
			/// Property for AllocateFromLot
			/// </summary>
			public const string AllocateFromLot = "LALLOCFROM";

			/// <summary>
			/// Property for SerialLotWindowHandle
			/// </summary>
			public const string SerialLotWindowHandle = "METERHWND";

			/// <summary>
			/// Property for Disallowsavepost
			/// </summary>
			public const string Disallowsavepost = "NOUPDATE";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of Assemblie Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for TransactionNumber
			/// </summary>
			public const int TransactionNumber = 2;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
            /// Property Indexer for AssemblyNumber
			/// </summary>
            public const int AssemblyNumber = 3;

			/// <summary>
			/// Property Indexer for TransactionDate
			/// </summary>
			public const int TransactionDate = 4;

			/// <summary>
			/// Property Indexer for FiscalYear
			/// </summary>
			public const int FiscalYear = 5;

			/// <summary>
			/// Property Indexer for FiscalPeriod
			/// </summary>
			public const int FiscalPeriod = 6;

			/// <summary>
			/// Property Indexer for Reference
			/// </summary>
			public const int Reference = 7;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 8;

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 9;

			/// <summary>
			/// Property Indexer for BOMNumber
			/// </summary>
			public const int BOMNumber = 10;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 11;

			/// <summary>
			/// Property Indexer for Quantity
			/// </summary>
			public const int Quantity = 12;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 13;

			/// <summary>
			/// Property Indexer for TransactionType
			/// </summary>
			public const int TransactionType = 14;

			/// <summary>
			/// Property Indexer for ICUniqueDocumentNumber
			/// </summary>
			public const int ICUniqueDocumentNumber = 15;

			/// <summary>
			/// Property Indexer for RecordStatus
			/// </summary>
			public const int RecordStatus = 16;

			/// <summary>
			/// Property Indexer for RecordDeleted
			/// </summary>
			public const int RecordDeleted = 17;

			/// <summary>
			/// Property Indexer for ManufacturersItemNumber
			/// </summary>
			public const int ManufacturersItemNumber = 18;

			/// <summary>
			/// Property Indexer for UnitCost
			/// </summary>
			public const int UnitCost = 19;

			/// <summary>
			/// Property Indexer for FromAssemblyNumber
			/// </summary>
			public const int FromAssemblyNumber = 20;

			/// <summary>
			/// Property Indexer for FromAssemblyQuantity
			/// </summary>
			public const int FromAssemblyQuantity = 21;

			/// <summary>
			/// Property Indexer for DisassemblyCost
			/// </summary>
			public const int DisassemblyCost = 22;

			/// <summary>
			/// Property Indexer for RecordPrinted
			/// </summary>
			public const int RecordPrinted = 23;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 24;

			/// <summary>
			/// Property Indexer for MasterAssemblyNumber
			/// </summary>
			public const int MasterAssemblyNumber = 25;

			/// <summary>
			/// Property Indexer for ComponentAssemblyMethod
			/// </summary>
			public const int ComponentAssemblyMethod = 26;

			/// <summary>
			/// Property Indexer for QuantityUsed
			/// </summary>
			public const int QuantityUsed = 27;

			/// <summary>
			/// Property Indexer for QtyNeededStockingUOM
			/// </summary>
			public const int QtyNeededStockingUOM = 28;

			/// <summary>
			/// Property Indexer for MultilevelLevel
			/// </summary>
			public const int MultilevelLevel = 29;

			/// <summary>
			/// Property Indexer for MultilevelSeqNo
			/// </summary>
			public const int MultilevelSeqNo = 30;

			/// <summary>
			/// Property Indexer for MultilevelParentSeqNo
			/// </summary>
			public const int MultilevelParentSeqNo = 31;

			/// <summary>
			/// Property Indexer for MultilevelParentAssemblyNo
			/// </summary>
			public const int MultilevelParentAssemblyNo = 32;

			/// <summary>
			/// Property Indexer for ComponentsMasterItemNo
			/// </summary>
			public const int ComponentsMasterItemNo = 33;

			/// <summary>
			/// Property Indexer for EnteredBy
			/// </summary>
			public const int EnteredBy = 34;

			/// <summary>
			/// Property Indexer for PostingDate
			/// </summary>
			public const int PostingDate = 35;

			/// <summary>
			/// Property Indexer for SerialItemsInAssembly
			/// </summary>
			public const int SerialItemsInAssembly = 36;

			/// <summary>
			/// Property Indexer for LotItemsInAssembly
			/// </summary>
			public const int LotItemsInAssembly = 37;

			/// <summary>
			/// Property Indexer for AssemblyQuantityRemaining
			/// </summary>
			public const int AssemblyQuantityRemaining = 38;

			/// <summary>
			/// Property Indexer for ConversionFactor
			/// </summary>
			public const int ConversionFactor = 41;

			/// <summary>
			/// Property Indexer for InterprocessCommID
			/// </summary>
			public const int InterprocessCommID = 42;

			/// <summary>
			/// Property Indexer for EstimatedCost
			/// </summary>
			public const int EstimatedCost = 43;

			/// <summary>
			/// Property Indexer for ForcePopupSN
			/// </summary>
			public const int ForcePopupSN = 44;

			/// <summary>
			/// Property Indexer for PopupSN
			/// </summary>
			public const int PopupSN = 45;

			/// <summary>
			/// Property Indexer for CloseSN
			/// </summary>
			public const int CloseSN = 46;

			/// <summary>
			/// Property Indexer for LTSetID
			/// </summary>
			public const int LTSetID = 47;

			/// <summary>
			/// Property Indexer for ForcePopupLT
			/// </summary>
			public const int ForcePopupLT = 48;

			/// <summary>
			/// Property Indexer for PopupLT
			/// </summary>
			public const int PopupLT = 49;

			/// <summary>
			/// Property Indexer for CloseLT
			/// </summary>
			public const int CloseLT = 50;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for CDOCNUM
			/// </summary>
			public const int CDOCNUM = 51;

			/// <summary>
			/// Property Indexer for PostSequenceNumber
			/// </summary>
			public const int PostSequenceNumber = 52;

			/// <summary>
			/// Property Indexer for FromAssemblySeq
			/// </summary>
			public const int FromAssemblySeq = 53;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 54;

			/// <summary>
			/// Property Indexer for FormattedItemNumber
			/// </summary>
			public const int FormattedItemNumber = 55;

			/// <summary>
			/// Property Indexer for FormattedCompMasterItemNo
			/// </summary>
			public const int FormattedCompMasterItemNo = 56;

			/// <summary>
			/// Property Indexer for ItemDescription
			/// </summary>
			public const int ItemDescription = 57;

			/// <summary>
			/// Property Indexer for GLBatchID
			/// </summary>
			public const int GLBatchID = 58;

			/// <summary>
			/// Property Indexer for SerialLotQuantityToProcess
			/// </summary>
			public const int SerialLotQuantityToProcess = 59;

			/// <summary>
			/// Property Indexer for NumberOfLotsToGenerate
			/// </summary>
			public const int NumberOfLotsToGenerate = 60;

			/// <summary>
			/// Property Indexer for QuantityperLot
			/// </summary>
			public const int QuantityperLot = 61;

			/// <summary>
			/// Property Indexer for CompIDCurrentlyProcessed
			/// </summary>
			public const int CompIDCurrentlyProcessed = 62;

			/// <summary>
			/// Property Indexer for ParentSerialLotComponentID
			/// </summary>
			public const int ParentSerialLotComponentID = 63;

			/// <summary>
			/// Property Indexer for SerialLotItem
			/// </summary>
			public const int SerialLotItem = 64;

			/// <summary>
			/// Property Indexer for SerialLotBOMNumber
			/// </summary>
			public const int SerialLotBOMNumber = 65;

			/// <summary>
			/// Property Indexer for SerialLotItemUnitOfMeasure
			/// </summary>
			public const int SerialLotItemUnitOfMeasure = 66;

			/// <summary>
			/// Property Indexer for SerialMasterItem
			/// </summary>
			public const int SerialMasterItem = 67;

			/// <summary>
			/// Property Indexer for SerialQuantityRequired
			/// </summary>
			public const int SerialQuantityRequired = 68;

			/// <summary>
			/// Property Indexer for LotQuantityRequired
			/// </summary>
			public const int LotQuantityRequired = 69;

			/// <summary>
			/// Property Indexer for SerialQuantity
			/// </summary>
			public const int SerialQuantity = 70;

			/// <summary>
			/// Property Indexer for LotQuantity
			/// </summary>
			public const int LotQuantity = 71;

			/// <summary>
			/// Property Indexer for MasterSerialNumber
			/// </summary>
			public const int MasterSerialNumber = 72;

			/// <summary>
			/// Property Indexer for MasterSerialProcessAction
			/// </summary>
			public const int MasterSerialProcessAction = 73;

			/// <summary>
			/// Property Indexer for AllocateFromSerial
			/// </summary>
			public const int AllocateFromSerial = 74;

			/// <summary>
			/// Property Indexer for AllocateFromLot
			/// </summary>
			public const int AllocateFromLot = 75;

			/// <summary>
			/// Property Indexer for SerialLotWindowHandle
			/// </summary>
			public const int SerialLotWindowHandle = 76;

			/// <summary>
			/// Property Indexer for Disallowsavepost
			/// </summary>
			public const int Disallowsavepost = 77;

		}

		#endregion

	}
}
