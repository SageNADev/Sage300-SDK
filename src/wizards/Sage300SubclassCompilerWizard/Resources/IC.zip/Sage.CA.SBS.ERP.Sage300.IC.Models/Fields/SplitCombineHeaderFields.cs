// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of SplitCombineHeader Constants
	/// </summary>
	public partial class SplitCombineHeader
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0843";

		#region Properties

		/// <summary>
		/// Contains list of SplitCombineHeader Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "SEQUENCENO";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "DOCNUM";

			/// <summary>
			/// Property for LotNumber
			/// </summary>
			public const string LotNumber = "LOTNUMF";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for EntryType
			/// </summary>
			public const string EntryType = "TRANSTYPE";

			/// <summary>
			/// Property for TransactionDate
			/// </summary>
			public const string TransactionDate = "TRANSDATE";

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "UOM";

			/// <summary>
			/// Property for QuantityShippable
			/// </summary>
			public const string QuantityShippable = "QTYAVAIL";

			/// <summary>
			/// Property for SplitCombineQuantity
			/// </summary>
			public const string SplitCombineQuantity = "QUANTITY";

			/// <summary>
			/// Property for TotalOfDetailQuantities
			/// </summary>
			public const string TotalOfDetailQuantities = "QTYDTLSTOT";

			/// <summary>
			/// Property for NextDetailLineNumber
			/// </summary>
			public const string NextDetailLineNumber = "NEXTDTLNUM";

			/// <summary>
			/// Property for ExpiryDate
			/// </summary>
			public const string ExpiryDate = "EXPIRYDATE";

			/// <summary>
			/// Property for StockDate
			/// </summary>
			public const string StockDate = "STOCKDATE";

			/// <summary>
			/// Property for DetailCount
			/// </summary>
			public const string DetailCount = "DTLCOUNT";

			/// <summary>
			/// Property for QuantityRemaining
			/// </summary>
			public const string QuantityRemaining = "QTYREMAIN";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of SplitCombineHeader Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 2;

			/// <summary>
			/// Property Indexer for LotNumber
			/// </summary>
			public const int LotNumber = 3;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 4;

			/// <summary>
			/// Property Indexer for EntryType
			/// </summary>
			public const int EntryType = 5;

			/// <summary>
			/// Property Indexer for TransactionDate
			/// </summary>
			public const int TransactionDate = 6;

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 7;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 8;

			/// <summary>
			/// Property Indexer for QuantityShippable
			/// </summary>
			public const int QuantityShippable = 9;

			/// <summary>
			/// Property Indexer for SplitCombineQuantity
			/// </summary>
			public const int SplitCombineQuantity = 10;

			/// <summary>
			/// Property Indexer for TotalOfDetailQuantities
			/// </summary>
			public const int TotalOfDetailQuantities = 11;

			/// <summary>
			/// Property Indexer for NextDetailLineNumber
			/// </summary>
			public const int NextDetailLineNumber = 12;

			/// <summary>
			/// Property Indexer for ExpiryDate
			/// </summary>
			public const int ExpiryDate = 13;

			/// <summary>
			/// Property Indexer for StockDate
			/// </summary>
			public const int StockDate = 14;

			/// <summary>
			/// Property Indexer for DetailCount
			/// </summary>
			public const int DetailCount = 15;

			/// <summary>
			/// Property Indexer for QuantityRemaining
			/// </summary>
			public const int QuantityRemaining = 16;

		}

		#endregion

	}
}
