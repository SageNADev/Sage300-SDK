// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.
// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of InventoryLotNumber Constants
	/// </summary>
	public partial class InventoryLotNumber
    {
        #region Public Property 

        /// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "IC0810";

        #endregion

        #region Properties

        /// <summary>
		/// Contains list of InventoryLotNumber Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for UnformattedLotNumber
			/// </summary>
			public const string UnformattedLotNumber = "LOTNUM";

			/// <summary>
			/// Property for UnformattedItemNumber
			/// </summary>
			public const string UnformattedItemNumber = "ITEMNUM";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for QuantityAvailable
			/// </summary>
			public const string QuantityAvailable = "QTYAVAIL";

			/// <summary>
			/// Property for QuantityOnorder
			/// </summary>
			public const string QuantityOnorder = "QTYORDED";

			/// <summary>
			/// Property for StockDate
			/// </summary>
			public const string StockDate = "STOCKDATE";

			/// <summary>
			/// Property for ExpiryDate
			/// </summary>
			public const string ExpiryDate = "EXPIRYDATE";

			/// <summary>
			/// Property for QuarantineReleaseDate
			/// </summary>
			public const string QuarantineReleaseDate = "QUARTRELDT";

			/// <summary>
			/// Property for LotNumber
			/// </summary>
			public const string LotNumber = "LOTNUMF";

			/// <summary>
			/// Property for QuantityLevel
			/// </summary>
			public const string QuantityLevel = "QTYLEVEL";

			/// <summary>
			/// Property for QuantityForCosting
			/// </summary>
			public const string QuantityForCosting = "ASSETQTY";

			/// <summary>
			/// Property for CostForCosting
			/// </summary>
			public const string CostForCosting = "ASSETCOST";

			/// <summary>
			/// Property for Recalled
			/// </summary>
			public const string Recalled = "RECALLED";

			/// <summary>
			/// Property for DateRecalled
			/// </summary>
			public const string DateRecalled = "RECALLDATE";

			/// <summary>
			/// Property for ContractCode
			/// </summary>
			public const string ContractCode = "CONTCODE";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for ContractPeriod1InUse
			/// </summary>
			public const string ContractPeriod1InUse = "INUSE1";

			/// <summary>
			/// Property for ContractPeriod1ExpiryDate
			/// </summary>
			public const string ContractPeriod1ExpiryDate = "DATE1";

			/// <summary>
			/// Property for ContractPeriod1EffectiveDate
			/// </summary>
			public const string ContractPeriod1EffectiveDate = "EFFDATE1";

			/// <summary>
			/// Property for ContractPeriod1Lifetime
			/// </summary>
			public const string ContractPeriod1Lifetime = "LIFECONT1";

			/// <summary>
			/// Property for ContractPeriod2InUse
			/// </summary>
			public const string ContractPeriod2InUse = "INUSE2";

			/// <summary>
			/// Property for ContractPeriod2ExpiryDate
			/// </summary>
			public const string ContractPeriod2ExpiryDate = "DATE2";

			/// <summary>
			/// Property for ContractPeriod2EffectiveDate
			/// </summary>
			public const string ContractPeriod2EffectiveDate = "EFFDATE2";

			/// <summary>
			/// Property for ContractPeriod2Lifetime
			/// </summary>
			public const string ContractPeriod2Lifetime = "LIFECONT2";

			/// <summary>
			/// Property for ContractPeriod3InUse
			/// </summary>
			public const string ContractPeriod3InUse = "INUSE3";

			/// <summary>
			/// Property for ContractPeriod3ExpiryDate
			/// </summary>
			public const string ContractPeriod3ExpiryDate = "DATE3";

			/// <summary>
			/// Property for ContractPeriod3EffectiveDate
			/// </summary>
			public const string ContractPeriod3EffectiveDate = "EFFDATE3";

			/// <summary>
			/// Property for ContractPeriod3Lifetime
			/// </summary>
			public const string ContractPeriod3Lifetime = "LIFECONT3";

			/// <summary>
			/// Property for ContractPeriod4InUse
			/// </summary>
			public const string ContractPeriod4InUse = "INUSE4";

			/// <summary>
			/// Property for ContractPeriod4ExpiryDate
			/// </summary>
			public const string ContractPeriod4ExpiryDate = "DATE4";

			/// <summary>
			/// Property for ContractPeriod4EffectiveDate
			/// </summary>
			public const string ContractPeriod4EffectiveDate = "EFFDATE4";

			/// <summary>
			/// Property for ContractPeriod4Lifetime
			/// </summary>
			public const string ContractPeriod4Lifetime = "LIFECONT4";

			/// <summary>
			/// Property for ContractPeriod5InUse
			/// </summary>
			public const string ContractPeriod5InUse = "INUSE5";

			/// <summary>
			/// Property for ContractPeriod5ExpiryDate
			/// </summary>
			public const string ContractPeriod5ExpiryDate = "DATE5";

			/// <summary>
			/// Property for ContractPeriod5EffectiveDate
			/// </summary>
			public const string ContractPeriod5EffectiveDate = "EFFDATE5";

			/// <summary>
			/// Property for ContractPeriod5Lifetime
			/// </summary>
			public const string ContractPeriod5Lifetime = "LIFECONT5";

			/// <summary>
			/// Property for LotOnQuarantine
			/// </summary>
			public const string LotOnQuarantine = "ONQUART";

			/// <summary>
			/// Property for DateQuarantineed
			/// </summary>
			public const string DateQuarantineed = "ONQUARTDT";

			/// <summary>
			/// Property for Status
			/// </summary>
			public const string Status = "STATUS";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "CONTDESC";

			/// <summary>
			/// Property for ContractPeriod1Description
			/// </summary>
			public const string ContractPeriod1Description = "DESC1";

			/// <summary>
			/// Property for ContractPeriod2Description
			/// </summary>
			public const string ContractPeriod2Description = "DESC2";

			/// <summary>
			/// Property for ContractPeriod3Description
			/// </summary>
			public const string ContractPeriod3Description = "DESC3";

			/// <summary>
			/// Property for ContractPeriod4Description
			/// </summary>
			public const string ContractPeriod4Description = "DESC4";

			/// <summary>
			/// Property for ContractPeriod5Description
			/// </summary>
			public const string ContractPeriod5Description = "DESC5";

			/// <summary>
			/// Property for QuantityShippable
			/// </summary>
			public const string QuantityShippable = "QTYSHPABLE";

			/// <summary>
			/// Property for AssetUnitCost
			/// </summary>
			public const string AssetUnitCost = "ASSETUCST";

			/// <summary>
			/// Property for UpdatedbyUI
			/// </summary>
			public const string UpdatedbyUI = "EDITFROMUI";

			/// <summary>
			/// Property for HomeCurrencyDecimals
			/// </summary>
			public const string HomeCurrencyDecimals = "HOMECURDEC";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InventoryLotNumber Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for UnformattedLotNumber
			/// </summary>
			public const int UnformattedLotNumber = 1;

			/// <summary>
			/// Property Indexer for UnformattedItemNumber
			/// </summary>
			public const int UnformattedItemNumber = 2;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 3;

			/// <summary>
			/// Property Indexer for QuantityAvailable
			/// </summary>
			public const int QuantityAvailable = 4;

			/// <summary>
			/// Property Indexer for QuantityOnorder
			/// </summary>
			public const int QuantityOnorder = 5;

			/// <summary>
			/// Property Indexer for StockDate
			/// </summary>
			public const int StockDate = 6;

			/// <summary>
			/// Property Indexer for ExpiryDate
			/// </summary>
			public const int ExpiryDate = 7;

			/// <summary>
			/// Property Indexer for QuarantineReleaseDate
			/// </summary>
			public const int QuarantineReleaseDate = 8;

			/// <summary>
			/// Property Indexer for LotNumber
			/// </summary>
			public const int LotNumber = 9;

			/// <summary>
			/// Property Indexer for QuantityLevel
			/// </summary>
			public const int QuantityLevel = 10;

			/// <summary>
			/// Property Indexer for QuantityForCosting
			/// </summary>
			public const int QuantityForCosting = 11;

			/// <summary>
			/// Property Indexer for CostForCosting
			/// </summary>
			public const int CostForCosting = 12;

			/// <summary>
			/// Property Indexer for Recalled
			/// </summary>
			public const int Recalled = 13;

			/// <summary>
			/// Property Indexer for DateRecalled
			/// </summary>
			public const int DateRecalled = 14;

			/// <summary>
			/// Property Indexer for ContractCode
			/// </summary>
			public const int ContractCode = 15;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 16;

			/// <summary>
			/// Property Indexer for ContractPeriod1InUse
			/// </summary>
			public const int ContractPeriod1InUse = 17;

			/// <summary>
			/// Property Indexer for ContractPeriod1ExpiryDate
			/// </summary>
			public const int ContractPeriod1ExpiryDate = 18;

			/// <summary>
			/// Property Indexer for ContractPeriod1EffectiveDate
			/// </summary>
			public const int ContractPeriod1EffectiveDate = 19;

			/// <summary>
			/// Property Indexer for ContractPeriod1Lifetime
			/// </summary>
			public const int ContractPeriod1Lifetime = 20;

			/// <summary>
			/// Property Indexer for ContractPeriod2InUse
			/// </summary>
			public const int ContractPeriod2InUse = 21;

			/// <summary>
			/// Property Indexer for ContractPeriod2ExpiryDate
			/// </summary>
			public const int ContractPeriod2ExpiryDate = 22;

			/// <summary>
			/// Property Indexer for ContractPeriod2EffectiveDate
			/// </summary>
			public const int ContractPeriod2EffectiveDate = 23;

			/// <summary>
			/// Property Indexer for ContractPeriod2Lifetime
			/// </summary>
			public const int ContractPeriod2Lifetime = 24;

			/// <summary>
			/// Property Indexer for ContractPeriod3InUse
			/// </summary>
			public const int ContractPeriod3InUse = 25;

			/// <summary>
			/// Property Indexer for ContractPeriod3ExpiryDate
			/// </summary>
			public const int ContractPeriod3ExpiryDate = 26;

			/// <summary>
			/// Property Indexer for ContractPeriod3EffectiveDate
			/// </summary>
			public const int ContractPeriod3EffectiveDate = 27;

			/// <summary>
			/// Property Indexer for ContractPeriod3Lifetime
			/// </summary>
			public const int ContractPeriod3Lifetime = 28;

			/// <summary>
			/// Property Indexer for ContractPeriod4InUse
			/// </summary>
			public const int ContractPeriod4InUse = 29;

			/// <summary>
			/// Property Indexer for ContractPeriod4ExpiryDate
			/// </summary>
			public const int ContractPeriod4ExpiryDate = 30;

			/// <summary>
			/// Property Indexer for ContractPeriod4EffectiveDate
			/// </summary>
			public const int ContractPeriod4EffectiveDate = 31;

			/// <summary>
			/// Property Indexer for ContractPeriod4Lifetime
			/// </summary>
			public const int ContractPeriod4Lifetime = 32;

			/// <summary>
			/// Property Indexer for ContractPeriod5InUse
			/// </summary>
			public const int ContractPeriod5InUse = 33;

			/// <summary>
			/// Property Indexer for ContractPeriod5ExpiryDate
			/// </summary>
			public const int ContractPeriod5ExpiryDate = 34;

			/// <summary>
			/// Property Indexer for ContractPeriod5EffectiveDate
			/// </summary>
			public const int ContractPeriod5EffectiveDate = 35;

			/// <summary>
			/// Property Indexer for ContractPeriod5Lifetime
			/// </summary>
			public const int ContractPeriod5Lifetime = 36;

			/// <summary>
			/// Property Indexer for LotOnQuarantine
			/// </summary>
			public const int LotOnQuarantine = 37;

			/// <summary>
			/// Property Indexer for DateQuarantineed
			/// </summary>
			public const int DateQuarantineed = 38;

			/// <summary>
			/// Property Indexer for Status
			/// </summary>
			public const int Status = 50;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 51;

			/// <summary>
			/// Property Indexer for ContractPeriod1Description
			/// </summary>
			public const int ContractPeriod1Description = 52;

			/// <summary>
			/// Property Indexer for ContractPeriod2Description
			/// </summary>
			public const int ContractPeriod2Description = 53;

			/// <summary>
			/// Property Indexer for ContractPeriod3Description
			/// </summary>
			public const int ContractPeriod3Description = 54;

			/// <summary>
			/// Property Indexer for ContractPeriod4Description
			/// </summary>
			public const int ContractPeriod4Description = 55;

			/// <summary>
			/// Property Indexer for ContractPeriod5Description
			/// </summary>
			public const int ContractPeriod5Description = 56;

			/// <summary>
			/// Property Indexer for QuantityShippable
			/// </summary>
			public const int QuantityShippable = 57;

			/// <summary>
			/// Property Indexer for AssetUnitCost
			/// </summary>
			public const int AssetUnitCost = 58;

			/// <summary>
			/// Property Indexer for UpdatedbyUI
			/// </summary>
			public const int UpdatedbyUI = 59;

			/// <summary>
			/// Property Indexer for HomeCurrencyDecimals
			/// </summary>
			public const int HomeCurrencyDecimals = 60;

		}

		#endregion

	}
}
