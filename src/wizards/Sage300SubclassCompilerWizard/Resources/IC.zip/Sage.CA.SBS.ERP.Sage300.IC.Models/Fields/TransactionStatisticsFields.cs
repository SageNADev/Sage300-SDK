/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of TransactionStatistics Constants 
    /// </summary>
    public partial class TransactionStatistics
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0700";

        /// <summary>
        /// Contains list of TransactionStatistics Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "YEAR";
            /// <summary>
            /// Property for Period 
            /// </summary>
            public const string Period = "PERIOD";
            /// <summary>
            /// Property for NumberofReceipts 
            /// </summary>
            public const string NumberofReceipts = "RECCOUNT";
            /// <summary>
            /// Property for CostofReceipts 
            /// </summary>
            public const string CostofReceipts = "RECTOTAL";
            /// <summary>
            /// Property for NumberofReceiptAdjustments 
            /// </summary>
            public const string NumberofReceiptAdjustments = "RECADJ";
            /// <summary>
            /// Property for CostofReceiptAdjustments 
            /// </summary>
            public const string CostofReceiptAdjustments = "RECADJTTL";
            /// <summary>
            /// Property for NumberofReceiptReturns 
            /// </summary>
            public const string NumberofReceiptReturns = "RECRTN";
            /// <summary>
            /// Property for CostofReceiptReturns 
            /// </summary>
            public const string CostofReceiptReturns = "RECRTNTTL";
            /// <summary>
            /// Property for NumberofShipments 
            /// </summary>
            public const string NumberofShipments = "SHIPCOUNT";
            /// <summary>
            /// Property for CostofShipments 
            /// </summary>
            public const string CostofShipments = "SHIPTOTAL";
            /// <summary>
            /// Property for PriceofShipments 
            /// </summary>
            public const string PriceofShipments = "SHIPPRICE";
            /// <summary>
            /// Property for NumberofShipmentReturns 
            /// </summary>
            public const string NumberofShipmentReturns = "SHIPRTN";
            /// <summary>
            /// Property for CostofShipmentReturns 
            /// </summary>
            public const string CostofShipmentReturns = "SHIPRTNTTL";
            /// <summary>
            /// Property for PriceofShipmentReturns 
            /// </summary>
            public const string PriceofShipmentReturns = "SHIPRTNPRC";
            /// <summary>
            /// Property for NumberofAdjustments 
            /// </summary>
            public const string NumberofAdjustments = "ADJCOUNT";
            /// <summary>
            /// Property for CostofAdjustments 
            /// </summary>
            public const string CostofAdjustments = "ADJTOTAL";
            /// <summary>
            /// Property for NumberofTransfers 
            /// </summary>
            public const string NumberofTransfers = "TRANFCOUNT";
            /// <summary>
            /// Property for NumberofInternalUsages 
            /// </summary>
            public const string NumberofInternalUsages = "ICSCOUNT";
            /// <summary>
            /// Property for CostofInternalUsages 
            /// </summary>
            public const string CostofInternalUsages = "ICSTOTAL";

            #endregion
        }

        /// <summary>
        /// Contains list of TransactionStatistics Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 1;
            /// <summary>
            /// Property Indexer for Period 
            /// </summary>
            public const int Period = 2;
            /// <summary>
            /// Property Indexer for NumberofReceipts 
            /// </summary>
            public const int NumberofReceipts = 3;
            /// <summary>
            /// Property Indexer for CostofReceipts 
            /// </summary>
            public const int CostofReceipts = 4;
            /// <summary>
            /// Property Indexer for NumberofReceiptAdjustments 
            /// </summary>
            public const int NumberofReceiptAdjustments = 5;
            /// <summary>
            /// Property Indexer for CostofReceiptAdjustments 
            /// </summary>
            public const int CostofReceiptAdjustments = 6;
            /// <summary>
            /// Property Indexer for NumberofReceiptReturns 
            /// </summary>
            public const int NumberofReceiptReturns = 7;
            /// <summary>
            /// Property Indexer for CostofReceiptReturns 
            /// </summary>
            public const int CostofReceiptReturns = 8;
            /// <summary>
            /// Property Indexer for NumberofShipments 
            /// </summary>
            public const int NumberofShipments = 9;
            /// <summary>
            /// Property Indexer for CostofShipments 
            /// </summary>
            public const int CostofShipments = 10;
            /// <summary>
            /// Property Indexer for PriceofShipments 
            /// </summary>
            public const int PriceofShipments = 11;
            /// <summary>
            /// Property Indexer for NumberofShipmentReturns 
            /// </summary>
            public const int NumberofShipmentReturns = 12;
            /// <summary>
            /// Property Indexer for CostofShipmentReturns 
            /// </summary>
            public const int CostofShipmentReturns = 13;
            /// <summary>
            /// Property Indexer for PriceofShipmentReturns 
            /// </summary>
            public const int PriceofShipmentReturns = 14;
            /// <summary>
            /// Property Indexer for NumberofAdjustments 
            /// </summary>
            public const int NumberofAdjustments = 15;
            /// <summary>
            /// Property Indexer for CostofAdjustments 
            /// </summary>
            public const int CostofAdjustments = 16;
            /// <summary>
            /// Property Indexer for NumberofTransfers 
            /// </summary>
            public const int NumberofTransfers = 17;
            /// <summary>
            /// Property Indexer for NumberofInternalUsages 
            /// </summary>
            public const int NumberofInternalUsages = 18;
            /// <summary>
            /// Property Indexer for CostofInternalUsages 
            /// </summary>
            public const int CostofInternalUsages = 19;

            #endregion
        }
    }
}
