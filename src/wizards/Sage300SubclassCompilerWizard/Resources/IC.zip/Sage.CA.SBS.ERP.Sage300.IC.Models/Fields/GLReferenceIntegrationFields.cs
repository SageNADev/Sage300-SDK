/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of GL Integration Constants
     /// </summary>
     public partial class GLReferenceIntegration
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "IC0281";

          #region Properties
          /// <summary>
          /// Contains list of GL Integration Fields Constants
          /// </summary>
          public class Fields: BaseFields
          {

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of GL Integration Index Constants
          /// </summary>
          public class Index: BaseIndex
          {

               /// <summary>
               /// Property Indexer for Separator
               /// </summary>
               public const int Separator = 3;

               /// <summary>
               /// Property Indexer for Example
               /// </summary>
               public const int Example = 4;

          }
          #endregion
     }
}
