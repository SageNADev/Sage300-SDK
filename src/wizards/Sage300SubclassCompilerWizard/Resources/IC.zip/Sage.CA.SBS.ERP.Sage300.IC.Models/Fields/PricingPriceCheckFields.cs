// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of PricingPriceCheck Constants
     /// </summary>
     public partial class PricingPriceCheck
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "IC0481";

          #region Properties
          /// <summary>
          /// Contains list of PricingPriceCheck Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CurrencyCode
               /// </summary>
               public const string CurrencyCode = "CURRENCY";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for PriceListCode
               /// </summary>
               public const string PriceListCode = "PRICELIST";

               /// <summary>
               /// Property for UserID
               /// </summary>
               public const string UserID = "USERID";

               /// <summary>
               /// Property for RecordExists
               /// </summary>
               public const string RecordExists = "EXISTS";

               /// <summary>
               /// Property for GreaterthanPercentage
               /// </summary>
               public const string GreaterthanPercentage = "CGTPERCENT";

               /// <summary>
               /// Property for LessthanPercentage
               /// </summary>
               public const string LessthanPercentage = "CLTPERCENT";

               /// <summary>
               /// Property for GreaterthanAmount
               /// </summary>
               public const string GreaterthanAmount = "CGTAMOUNT";

               /// <summary>
               /// Property for LessthanAmount
               /// </summary>
               public const string LessthanAmount = "CLTAMOUNT";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of PricingPriceCheck Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CurrencyCode
               /// </summary>
               public const int CurrencyCode = 1;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 2;

               /// <summary>
               /// Property Indexer for PriceListCode
               /// </summary>
               public const int PriceListCode = 3;

               /// <summary>
               /// Property Indexer for UserID
               /// </summary>
               public const int UserID = 4;

               /// <summary>
               /// Property Indexer for RecordExists
               /// </summary>
               public const int RecordExists = 5;

               /// <summary>
               /// Property Indexer for GreaterthanPercentage
               /// </summary>
               public const int GreaterthanPercentage = 6;

               /// <summary>
               /// Property Indexer for LessthanPercentage
               /// </summary>
               public const int LessthanPercentage = 7;

               /// <summary>
               /// Property Indexer for GreaterthanAmount
               /// </summary>
               public const int GreaterthanAmount = 8;

               /// <summary>
               /// Property Indexer for LessthanAmount
               /// </summary>
               public const int LessthanAmount = 9;

          }
          #endregion

     }
}
