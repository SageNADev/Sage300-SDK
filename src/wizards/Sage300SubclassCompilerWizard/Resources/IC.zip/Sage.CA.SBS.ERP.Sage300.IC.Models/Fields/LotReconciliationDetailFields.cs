// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of LotReconciliationDetail Constants
	/// </summary>
	public partial class LotReconciliationDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0827";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of LotReconciliationDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "SEQUENCENO";

			/// <summary>
			/// Property for LotNumber
			/// </summary>
			public const string LotNumber = "LOTNUMF";

			/// <summary>
			/// Property for ExpiryDate
			/// </summary>
			public const string ExpiryDate = "EXPIRYDATE";

			/// <summary>
			/// Property for Quantity
			/// </summary>
			public const string Quantity = "QTY";

			/// <summary>
			/// Property for LotQuantityInStockingUOM
			/// </summary>
			public const string LotQuantityInStockingUOM = "QTYSQ";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of LotReconciliationDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for LotNumber
			/// </summary>
			public const int LotNumber = 2;

			/// <summary>
			/// Property Indexer for ExpiryDate
			/// </summary>
			public const int ExpiryDate = 3;

			/// <summary>
			/// Property Indexer for Quantity
			/// </summary>
			public const int Quantity = 4;

			/// <summary>
			/// Property Indexer for LotQuantityInStockingUOM
			/// </summary>
			public const int LotQuantityInStockingUOM = 5;

		}

		#endregion

	}
}
