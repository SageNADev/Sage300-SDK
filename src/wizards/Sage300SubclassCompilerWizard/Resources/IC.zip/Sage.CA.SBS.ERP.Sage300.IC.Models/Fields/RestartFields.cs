// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of Restart Constants
	/// </summary>
	public partial class Restart
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0606";

		#region Properties

		/// <summary>
		/// Contains list of Restart Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Key
			/// </summary>
			public const string Key = "KEY";

			/// <summary>
			/// Property for UserID
			/// </summary>
			public const string UserID = "USERID";

			/// <summary>
			/// Property for DataBlock1
			/// </summary>
			public const string DataBlock1 = "DATA1";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of Restart Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Key
			/// </summary>
			public const int Key = 1;

			/// <summary>
			/// Property Indexer for UserID
			/// </summary>
			public const int UserID = 2;

			/// <summary>
			/// Property Indexer for DataBlock1
			/// </summary>
			public const int DataBlock1 = 3;

		}

		#endregion

	}
}
