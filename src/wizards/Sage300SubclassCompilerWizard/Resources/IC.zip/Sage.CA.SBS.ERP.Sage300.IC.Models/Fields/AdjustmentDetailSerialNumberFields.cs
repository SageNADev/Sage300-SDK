// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of AdjustmentDetailSerialNumber Constants
    /// </summary>
    public partial class AdjustmentDetailSerialNumber
    {
        #region Public Properties

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0117";

        #endregion

        #region Constants

        /// <summary>
        /// Contains list of AdjustmentDetailSerialNumber Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Constant for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "ADJENSEQ";

            /// <summary>
            /// Constant for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Constant for SerialNumber
            /// </summary>
            public const string SerialNumber = "SERIALNUMF";

            /// <summary>
            /// Constant for SerialCost
            /// </summary>
            public const string SerialCost = "COST";

            /// <summary>
            /// Constant for SerialQuantity
            /// </summary>
            public const string SerialQuantity = "SCOUNT";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of AdjustmentDetailSerialNumber Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Constant Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Constant Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Constant Indexer for SerialNumber
            /// </summary>
            public const int SerialNumber = 3;

            /// <summary>
            /// Constant Indexer for SerialCost
            /// </summary>
            public const int SerialCost = 5;

            /// <summary>
            /// Constant Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 50;

        }

        #endregion
    }
}
