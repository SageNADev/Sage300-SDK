﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of ItemSegments Constants 
    /// </summary>
    public partial class ItemSegment
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0610";

        /// <summary>
        /// Contains list of ItemSegments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for SegmentNumber 
            /// </summary>
            public const string SegmentNumber = "SEGMENT";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Validate 
            /// </summary>
            public const string Validate = "VALIDATE";

            #endregion
        }

        /// <summary>
        /// Contains list of ItemSegments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for SegmentNumber 
            /// </summary>
            public const int SegmentNumber = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 3;

            /// <summary>
            /// Property Indexer for Validate 
            /// </summary>
            public const int Validate = 4;

            #endregion
        }
    }
}