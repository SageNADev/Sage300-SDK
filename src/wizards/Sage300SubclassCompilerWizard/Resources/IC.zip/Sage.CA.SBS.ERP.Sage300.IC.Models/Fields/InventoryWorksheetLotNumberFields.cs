// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of InventoryWorksheetLotNumber Constants
     /// </summary>
     public partial class InventoryWorksheetLotNumber
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0793";

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetLotNumber Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for SortCode
               /// </summary>
               public const string SortCode = "SORTCODE";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for LotNumber
               /// </summary>
               public const string LotNumber = "LOTNUMF";

               /// <summary>
               /// Property for ExpiryDate
               /// </summary>
               public const string ExpiryDate = "EXPIRYDATE";

               /// <summary>
               /// Property for TransactionQuantity
               /// </summary>
               public const string TransactionQuantity = "QTY";

               /// <summary>
               /// Property for LotQuantityInStockingUom
               /// </summary>
               public const string LotQuantityInStockingUom = "QTYSQ";

               /// <summary>
               /// Property for LotCost
               /// </summary>
               public const string LotCost = "COST";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetLotNumber Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for SortCode
               /// </summary>
               public const int SortCode = 2;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 3;

               /// <summary>
               /// Property Indexer for LotNumber
               /// </summary>
               public const int LotNumber = 4;

               /// <summary>
               /// Property Indexer for ExpiryDate
               /// </summary>
               public const int ExpiryDate = 6;

               /// <summary>
               /// Property Indexer for TransactionQuantity
               /// </summary>
               public const int TransactionQuantity = 7;

               /// <summary>
               /// Property Indexer for LotQuantityInStockingUom
               /// </summary>
               public const int LotQuantityInStockingUom = 8;

               /// <summary>
               /// Property Indexer for LotCost
               /// </summary>
               public const int LotCost = 9;

          }
          #endregion

     }
}
