// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion
// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of AssemblyLotDetail Constants
	/// </summary>
	public partial class AssemblyLotDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0162";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of AssemblyLotDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "ASSMENSEQ";

			/// <summary>
			/// Property for ComponentID
			/// </summary>
			public const string ComponentID = "COMPID";

			/// <summary>
			/// Property for ParentComponentID
			/// </summary>
			public const string ParentComponentID = "PRNCOMPID";

			/// <summary>
			/// Property for LotNumber
			/// </summary>
			public const string LotNumber = "LOTNUMF";

			/// <summary>
			/// Property for MasterItemLotNumber
			/// </summary>
			public const string MasterItemLotNumber = "PRNLOTNUMF";

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for BOMNumber
			/// </summary>
			public const string BOMNumber = "BOMNO";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "UNIT";

			/// <summary>
			/// Property for ExpiryDate
			/// </summary>
			public const string ExpiryDate = "EXPIRYDATE";

			/// <summary>
			/// Property for TransactionQuantity
			/// </summary>
			public const string TransactionQuantity = "QTY";

			/// <summary>
			/// Property for LotQuantityInStockingUOM
			/// </summary>
			public const string LotQuantityInStockingUOM = "QTYSQ";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of AssemblyLotDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for ComponentID
			/// </summary>
			public const int ComponentID = 2;

			/// <summary>
			/// Property Indexer for ParentComponentID
			/// </summary>
			public const int ParentComponentID = 3;

			/// <summary>
			/// Property Indexer for LotNumber
			/// </summary>
			public const int LotNumber = 4;

			/// <summary>
			/// Property Indexer for MasterItemLotNumber
			/// </summary>
			public const int MasterItemLotNumber = 5;

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 6;

			/// <summary>
			/// Property Indexer for BOMNumber
			/// </summary>
			public const int BOMNumber = 7;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 8;

			/// <summary>
			/// Property Indexer for ExpiryDate
			/// </summary>
			public const int ExpiryDate = 9;

			/// <summary>
			/// Property Indexer for TransactionQuantity
			/// </summary>
			public const int TransactionQuantity = 10;

			/// <summary>
			/// Property Indexer for LotQuantityInStockingUOM
			/// </summary>
			public const int LotQuantityInStockingUOM = 11;

		}

		#endregion

	}
}
