// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models.Process
{
	/// <summary>
	/// Contains list of BillsOfMaterialInquiry Constants
	/// </summary>
	public partial class BillsOfMaterialInquiry
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "IC0201";

		#region Properties

		/// <summary>
		/// Contains list of BillsOfMaterialInquiry Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ComponentItemNumber
			/// </summary>
			public const string ComponentItemNumber = "CMPNITEMNO";
            
			/// <summary>
            /// Property for Master Item Number
			/// </summary>
			public const string MasterItemNumber = "MSTRITEMNO";

			/// <summary>
			/// Property for Master BOM Number
			/// </summary>
			public const string MasterBOMNumber = "MSTRBOMNO";

			/// <summary>
			/// Property for Component Line Number
			/// </summary>
			public const string ComponentLineNumber = "CMPNLINENO";

			/// <summary>
			/// Property for Component Quantity
			/// </summary>
			public const string ComponentQuantity = "CMPNQTY";

			/// <summary>
			/// Property for Component BOM Number
			/// </summary>
			public const string ComponentBOMNumber = "CMPNBOMNO";

			/// <summary>
			/// Property for Component Formatted ItemNo
			/// </summary>
			public const string ComponentFormattedItemNo = "CMPNFMTIT";

			/// <summary>
			/// Property for Master Description
			/// </summary>
			public const string MasterDescription = "MSTRDESC";

			/// <summary>
			/// Property for BuildQuantity
			/// </summary>
			public const string BuildQuantity = "MSTRQTY";

			/// <summary>
			/// Property for MasterUnitOfMeasure
			/// </summary>
			public const string MasterUnitOfMeasure = "MSTRUNIT";
			
			/// <summary>
            /// Property for Master Formatted Item Number
			/// </summary>
			public const string MasterFormattedItemNumber = "MSTRFMTIT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of BillsOfMaterialInquiry Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ComponentItemNumber
			/// </summary>
			public const int ComponentItemNumber = 1;
            
			/// <summary>
			/// Property Indexer for MSTRITEMNO
			/// </summary>
            public const int MasterItemNumber = 2;

			/// <summary>
			/// Property Indexer for MasterBOMNumber
			/// </summary>
			public const int MasterBOMNumber = 3;

			/// <summary>
			/// Property Indexer for ComponentLineNumber
			/// </summary>
			public const int ComponentLineNumber = 4;

			/// <summary>
			/// Property Indexer for ComponentQuantity
			/// </summary>
			public const int ComponentQuantity = 5;

			/// <summary>
			/// Property Indexer for ComponentBOMNumber
			/// </summary>
			public const int ComponentBOMNumber = 6;

			/// <summary>
			/// Property Indexer for ComponentFormattedItemNo
			/// </summary>
			public const int ComponentFormattedItemNo = 7;

			/// <summary>
			/// Property Indexer for MasterDescription
			/// </summary>
			public const int MasterDescription = 8;

			/// <summary>
			/// Property Indexer for BuildQuantity
			/// </summary>
			public const int BuildQuantity = 9;

			/// <summary>
			/// Property Indexer for MasterUnitOfMeasure
			/// </summary>
			public const int MasterUnitOfMeasure = 10;
			
			/// <summary>
			/// Property Indexer for MSTRFMTIT
			/// </summary>
            public const int MasterFormattedItemNumber = 11;

		}

		#endregion

	}
}