﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of VendorItemNumbers Constants 
    /// </summary>
    public partial class VendorItemNumber
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0340";

        /// <summary>
        /// Contains list of VendorItemNumbers Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "ITEMNO";
            /// <summary>
            /// Property for VendorType 
            /// </summary>
            public const string VendorType = "VENDTYPE";
            /// <summary>
            /// Property for VendorNumber 
            /// </summary>
            public const string VendorNumber = "VENDNUM";
            /// <summary>
            /// Property for VendorName 
            /// </summary>
            public const string VendorName = "VENDNAME";
            /// <summary>
            /// Property for VendorItemNumber 
            /// </summary>
            public const string VendorItemId = "VENDITEM";
            /// <summary>
            /// Property for VendorContact 
            /// </summary>
            public const string VendorContact = "VENDCONT";
            /// <summary>
            /// Property for VendorCurrency 
            /// </summary>
            public const string VendorCurrency = "VENDCNCY";
            /// <summary>
            /// Property for VendorCost 
            /// </summary>
            public const string VendorCost = "VENDCOST";
            /// <summary>
            /// Property for VendorExists 
            /// </summary>
            public const string VendorExists = "VENDEXISTS";
            /// <summary>
            /// Property for CostUnitConvFactor 
            /// </summary>
            public const string CostUnitConvFactor = "FACTOR";
            /// <summary>
            /// Property for CostUnit 
            /// </summary>
            public const string CostUnit = "COSTUNIT";
            /// <summary>
            /// Property for OrderMinimumSia 
            /// </summary>
            public const string OrderMinimumSia = "QTYMINORD";
            /// <summary>
            /// Property for PreferredVendorSia 
            /// </summary>
            public const string PreferredVendorSia = "PREFERRED";

            #endregion
        }


        /// <summary>
        /// Contains list of VendorItemNumbers Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 1;
            /// <summary>
            /// Property Indexer for VendorType 
            /// </summary>
            public const int VendorType = 2;
            /// <summary>
            /// Property Indexer for VendorNumber 
            /// </summary>
            public const int VendorNumber = 3;
            /// <summary>
            /// Property Indexer for VendorName 
            /// </summary>
            public const int VendorName = 4;
            /// <summary>
            /// Property Indexer for VendorItemNumber 
            /// </summary>
            public const int VendorItemId = 5;
            /// <summary>
            /// Property Indexer for VendorContact 
            /// </summary>
            public const int VendorContact = 6;
            /// <summary>
            /// Property Indexer for VendorCurrency 
            /// </summary>
            public const int VendorCurrency = 7;
            /// <summary>
            /// Property Indexer for VendorCost 
            /// </summary>
            public const int VendorCost = 8;
            /// <summary>
            /// Property Indexer for VendorExists 
            /// </summary>
            public const int VendorExists = 9;
            /// <summary>
            /// Property Indexer for CostUnitConvFactor 
            /// </summary>
            public const int CostUnitConvFactor = 10;
            /// <summary>
            /// Property Indexer for CostUnit 
            /// </summary>
            public const int CostUnit = 11;
            /// <summary>
            /// Property Indexer for OrderMinimumSia 
            /// </summary>
            public const int OrderMinimumSia = 12;
            /// <summary>
            /// Property Indexer for PreferredVendorSia 
            /// </summary>
            public const int PreferredVendorSia = 30;

            #endregion
        }


    }
}
