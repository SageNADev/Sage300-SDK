// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of LocationQuantitie Constants
	/// </summary>
	public partial class LocationQuantityFinder
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0372";

		#region Properties

		/// <summary>
		/// Contains list of LocationQuantitie Field Constants
		/// </summary>
		public class Fields
		{ 
			/// <summary>
			/// Property for ITEMNO
			/// </summary>
			public const string ITEMNO = "ITEMNO";

            /// <summary>
            /// ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";
             
			/// <summary>
			/// Property for LOCATION
			/// </summary>
			public const string LOCATION = "LOCATION";

			/// <summary>
			/// Property for LOCATION2
			/// </summary>
			public const string LOCATION2 = "LOCATION2";
             
			/// <summary>
			/// Property for DESC
			/// </summary>
			public const string DESC = "DESC";
             
			/// <summary>
			/// Property for AddressLine1
			/// </summary>
			public const string AddressLine1 = "ADDRESS1";

			/// <summary>
			/// Property for AddressLine2
			/// </summary>
			public const string AddressLine2 = "ADDRESS2";

			/// <summary>
			/// Property for AddressLine3
			/// </summary>
			public const string AddressLine3 = "ADDRESS3";

			/// <summary>
			/// Property for AddressLine4
			/// </summary>
			public const string AddressLine4 = "ADDRESS4";

			/// <summary>
			/// Property for City
			/// </summary>
			public const string City = "CITY";

			/// <summary>
			/// Property for State
			/// </summary>
			public const string State = "STATE";

			/// <summary>
			/// Property for ZipPostalCode
			/// </summary>
			public const string ZipPostalCode = "ZIP";

			/// <summary>
			/// Property for Country
			/// </summary>
			public const string Country = "COUNTRY";

			/// <summary>
			/// Property for PhoneNumber
			/// </summary>
			public const string PhoneNumber = "PHONE";

			/// <summary>
			/// Property for FaxNumber
			/// </summary>
			public const string FaxNumber = "FAX";

			/// <summary>
			/// Property for Contact
			/// </summary>
			public const string Contact = "CONTACT";

			/// <summary>
			/// Property for SegmentOverride
			/// </summary>
			public const string SegmentOverride = "SEGOVERRD";

            /// <summary>
            /// Property for SegmentOverrideString
            /// </summary>
		    public const string SegmentOverrideString = SegmentOverride;
			/// <summary>
			/// Property for DateLastMaintained
			/// </summary>
			public const string DateLastMaintained = "DATELASTMN";

			/// <summary>
			/// Property for Status
			/// </summary>
			public const string Status = "INACTIVE";

			/// <summary>
			/// Property for DateInactive
			/// </summary>
			public const string DateInactive = "DATEINACTV";

			/// <summary>
			/// Property for SegmentNumber1
			/// </summary>
			public const string SegmentNumber1 = "SEGNUM1";

			/// <summary>
			/// Property for SegmentValue1
			/// </summary>
			public const string SegmentValue1 = "SEGVAL1";

			/// <summary>
			/// Property for SegmentNumber2
			/// </summary>
			public const string SegmentNumber2 = "SEGNUM2";

			/// <summary>
			/// Property for SegmentValue2
			/// </summary>
			public const string SegmentValue2 = "SEGVAL2";

			/// <summary>
			/// Property for SegmentNumber3
			/// </summary>
			public const string SegmentNumber3 = "SEGNUM3";

			/// <summary>
			/// Property for SegmentValue3
			/// </summary>
			public const string SegmentValue3 = "SEGVAL3";

			/// <summary>
			/// Property for SegmentNumber4
			/// </summary>
			public const string SegmentNumber4 = "SEGNUM4";

			/// <summary>
			/// Property for SegmentValue4
			/// </summary>
			public const string SegmentValue4 = "SEGVAL4";

			/// <summary>
			/// Property for SegmentNumber5
			/// </summary>
			public const string SegmentNumber5 = "SEGNUM5";

			/// <summary>
			/// Property for SegmentValue5
			/// </summary>
			public const string SegmentValue5 = "SEGVAL5";

			/// <summary>
			/// Property for SegmentNumber6
			/// </summary>
			public const string SegmentNumber6 = "SEGNUM6";

			/// <summary>
			/// Property for SegmentValue6
			/// </summary>
			public const string SegmentValue6 = "SEGVAL6";

			/// <summary>
			/// Property for SegmentNumber7
			/// </summary>
			public const string SegmentNumber7 = "SEGNUM7";

			/// <summary>
			/// Property for SegmentValue7
			/// </summary>
			public const string SegmentValue7 = "SEGVAL7";

			/// <summary>
			/// Property for SegmentNumber8
			/// </summary>
			public const string SegmentNumber8 = "SEGNUM8";

			/// <summary>
			/// Property for SegmentValue8
			/// </summary>
			public const string SegmentValue8 = "SEGVAL8";

			/// <summary>
			/// Property for SegmentNumber9
			/// </summary>
			public const string SegmentNumber9 = "SEGNUM9";

			/// <summary>
			/// Property for SegmentValue9
			/// </summary>
			public const string SegmentValue9 = "SEGVAL9";

			/// <summary>
			/// Property for LocationEmail
			/// </summary>
			public const string LocationEmail = "EMAIL";

			/// <summary>
			/// Property for ContactPhone
			/// </summary>
			public const string ContactPhone = "PHONEC";

			/// <summary>
			/// Property for ContactFax
			/// </summary>
			public const string ContactFax = "FAXC";

			/// <summary>
			/// Property for ContactEmail
			/// </summary>
			public const string ContactEmail = "EMAILC";

			/// <summary>
			/// Property for LocationType
			/// </summary>
			public const string LocationType = "LOCTYPE";

			/// <summary>
			/// Property for ITEMNO2
			/// </summary>
			public const string ITEMNO2 = "ITEMNO2";

			/// <summary>
			/// Property for LOCATION3
			/// </summary>
			public const string LOCATION3 = "LOCATION3";

			/// <summary>
			/// Property for PickingSequence
			/// </summary>
			public const string PickingSequence = "PICKINGSEQ";

			/// <summary>
			/// Property for Allowed
			/// </summary>
			public const string Allowed = "ACTIVE";

		    /// <summary>
		    /// Property for Allowed String.
		    /// </summary>
		    public const string AllowedString = Allowed;


			/// <summary>
			/// Property for DateLocationActivated
			/// </summary>
			public const string DateLocationActivated = "DATEACTIVE";

			/// <summary>
			/// Property for InUse
			/// </summary>
			public const string InUse = "USED";

			/// <summary>
			/// Property for DateLastUsed
			/// </summary>
			public const string DateLastUsed = "LASTUSED";

			/// <summary>
			/// Property for QuantityonHandLastDayEnd
			/// </summary>
			public const string QuantityonHandLastDayEnd = "QTYONHAND";

			/// <summary>
			/// Property for QuantityonPO
			/// </summary>
			public const string QuantityonPO = "QTYONORDER";

		    /// <summary>
		    /// Property for QuantityonSO
		    /// </summary>
		    public const string QuantityonSO = "QTYSALORDR"; 

			/// <summary>
			/// Property for QuantityNotInCostFile
			/// </summary>
			public const string QuantityNotInCostFile = "QTYOFFSET";

			/// <summary>
			/// Property for QuantityShippedNotCosted
			/// </summary>
			public const string QuantityShippedNotCosted = "QTYSHNOCST";

			/// <summary>
			/// Property for QuantityReceivedNotCosted
			/// </summary>
			public const string QuantityReceivedNotCosted = "QTYRENOCST";

			/// <summary>
			/// Property for QuantityAdjustedNotCosted
			/// </summary>
			public const string QuantityAdjustedNotCosted = "QTYADNOCST";

			/// <summary>
			/// Property for NumberOfUncostedTransactions
			/// </summary>
			public const string NumberOfUncostedTransactions = "NUMNOCST";

			/// <summary>
			/// Property for TotalCost
			/// </summary>
			public const string TotalCost = "TOTALCOST";

			/// <summary>
			/// Property for CostNotInCostFile
			/// </summary>
			public const string CostNotInCostFile = "COSTOFFSET";

			/// <summary>
			/// Property for CostUnitOfMeasure
			/// </summary>
			public const string CostUnitOfMeasure = "COSTUNIT";

			/// <summary>
			/// Property for CostUnitConversionFactor
			/// </summary>
			public const string CostUnitConversionFactor = "COSTCONV";

			/// <summary>
			/// Property for StandardCost
			/// </summary>
			public const string StandardCost = "STDCOST";

			/// <summary>
			/// Property for LastStandardCost
			/// </summary>
			public const string LastStandardCost = "LASTSTDCST";

			/// <summary>
			/// Property for LastStandardCostDate
			/// </summary>
			public const string LastStandardCostDate = "LASTSTDDAT";

			/// <summary>
			/// Property for LastShipmentDate
			/// </summary>
			public const string LastShipmentDate = "LASTSHIPDT";

			/// <summary>
			/// Property for AverageDaysToShip
			/// </summary>
			public const string AverageDaysToShip = "DAYSTOSHIP";

			/// <summary>
			/// Property for AverageUnitsShipped
			/// </summary>
			public const string AverageUnitsShipped = "UNITSSHIP";

			/// <summary>
			/// Property for ShipmentsUsedInCalculation
			/// </summary>
			public const string ShipmentsUsedInCalculation = "SHIPMENTS";

			/// <summary>
			/// Property for LastReceiptDate
			/// </summary>
			public const string LastReceiptDate = "LASTRCPTDT";

			/// <summary>
			/// Property for MostRecentCost
			/// </summary>
			public const string MostRecentCost = "RECENTCOST";

			/// <summary>
			/// Property for UserDefinedCost1
			/// </summary>
			public const string UserDefinedCost1 = "COST1";

			/// <summary>
			/// Property for UserDefinedCost2
			/// </summary>
			public const string UserDefinedCost2 = "COST2";

			/// <summary>
			/// Property for LastUnitCost
			/// </summary>
			public const string LastUnitCost = "LASTCOST";

			/// <summary>
			/// Property for QuantityCommitted
			/// </summary>
			public const string QuantityCommitted = "QTYCOMMIT";

			/// <summary>
			/// Property for LastAllocatedSerial
			/// </summary>
			public const string LastAllocatedSerial = "LASTSERALC";

			/// <summary>
			/// Property for LastAllocatedLot
			/// </summary>
			public const string LastAllocatedLot = "LASTLOTALC";

			/// <summary>
			/// Property for LeadTimeSIA
			/// </summary>
			public const string LeadTimeSIA = "LEADTIME";

			/// <summary>
			/// Property for InventoryMinimumSIA
			/// </summary>
			public const string InventoryMinimumSIA = "QTYMINREQ";

			/// <summary>
			/// Property for QuantityAvailableToShip
			/// </summary>
			public const string QuantityAvailableToShip = "QTYAVAIL";

			/// <summary>
			/// Property for AccountSetCode
			/// </summary>
			public const string AccountSetCode = "CNTLACCT";

			/// <summary>
			/// Property for QuantityonHand
			/// </summary>
			public const string QuantityonHand = "AQTYONHAND";

			/// <summary>
			/// Property for AverageCost
			/// </summary>
			public const string AverageCost = "AVGCOST";

			/// <summary>
			/// Property for CostingMethod
			/// </summary>
			public const string CostingMethod = "COSTMETHOD";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for LOCDESC
			/// </summary>
			public const string LOCDESC = "LOCDESC";

			/// <summary>
			/// Property for CheckItemExistence
			/// </summary>
			public const string CheckItemExistence = "CHECKITEM";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of LocationQuantitie Index Constants
		/// </summary>
		public class Index
		{
             
			/// <summary>
			/// Property Indexer for ITEMNO
			/// </summary>
			public const int ITEMNO = 1;
             
			/// <summary>
			/// Property Indexer for LOCATION
			/// </summary>
			public const int LOCATION = 2;

			/// <summary>
			/// Property Indexer for LOCATION2
			/// </summary>
			public const int LOCATION2 = 1001;
             
			/// <summary>
			/// Property Indexer for DESC
			/// </summary>
			public const int DESC = 1002;

			/// <summary>
			/// Property Indexer for AddressLine1
			/// </summary>
			public const int AddressLine1 = 1003;

			/// <summary>
			/// Property Indexer for AddressLine2
			/// </summary>
			public const int AddressLine2 = 1004;

			/// <summary>
			/// Property Indexer for AddressLine3
			/// </summary>
			public const int AddressLine3 = 1005;

			/// <summary>
			/// Property Indexer for AddressLine4
			/// </summary>
			public const int AddressLine4 = 1006;

			/// <summary>
			/// Property Indexer for City
			/// </summary>
			public const int City = 1007;

			/// <summary>
			/// Property Indexer for State
			/// </summary>
			public const int State = 1008;

			/// <summary>
			/// Property Indexer for ZipPostalCode
			/// </summary>
			public const int ZipPostalCode = 1009;

			/// <summary>
			/// Property Indexer for Country
			/// </summary>
			public const int Country = 1010;

			/// <summary>
			/// Property Indexer for PhoneNumber
			/// </summary>
			public const int PhoneNumber = 1011;

			/// <summary>
			/// Property Indexer for FaxNumber
			/// </summary>
			public const int FaxNumber = 1012;

			/// <summary>
			/// Property Indexer for Contact
			/// </summary>
			public const int Contact = 1013;

			/// <summary>
			/// Property Indexer for SegmentOverride
			/// </summary>
			public const int SegmentOverride = 1014;

			/// <summary>
			/// Property Indexer for DateLastMaintained
			/// </summary>
			public const int DateLastMaintained = 1015;

			/// <summary>
			/// Property Indexer for Status
			/// </summary>
			public const int Status = 1016;

			/// <summary>
			/// Property Indexer for DateInactive
			/// </summary>
			public const int DateInactive = 1017;

			/// <summary>
			/// Property Indexer for SegmentNumber1
			/// </summary>
			public const int SegmentNumber1 = 1018;

			/// <summary>
			/// Property Indexer for SegmentValue1
			/// </summary>
			public const int SegmentValue1 = 1019;

			/// <summary>
			/// Property Indexer for SegmentNumber2
			/// </summary>
			public const int SegmentNumber2 = 1020;

			/// <summary>
			/// Property Indexer for SegmentValue2
			/// </summary>
			public const int SegmentValue2 = 1021;

			/// <summary>
			/// Property Indexer for SegmentNumber3
			/// </summary>
			public const int SegmentNumber3 = 1022;

			/// <summary>
			/// Property Indexer for SegmentValue3
			/// </summary>
			public const int SegmentValue3 = 1023;

			/// <summary>
			/// Property Indexer for SegmentNumber4
			/// </summary>
			public const int SegmentNumber4 = 1024;

			/// <summary>
			/// Property Indexer for SegmentValue4
			/// </summary>
			public const int SegmentValue4 = 1025;

			/// <summary>
			/// Property Indexer for SegmentNumber5
			/// </summary>
			public const int SegmentNumber5 = 1026;

			/// <summary>
			/// Property Indexer for SegmentValue5
			/// </summary>
			public const int SegmentValue5 = 1027;

			/// <summary>
			/// Property Indexer for SegmentNumber6
			/// </summary>
			public const int SegmentNumber6 = 1028;

			/// <summary>
			/// Property Indexer for SegmentValue6
			/// </summary>
			public const int SegmentValue6 = 1029;

			/// <summary>
			/// Property Indexer for SegmentNumber7
			/// </summary>
			public const int SegmentNumber7 = 1030;

			/// <summary>
			/// Property Indexer for SegmentValue7
			/// </summary>
			public const int SegmentValue7 = 1031;

			/// <summary>
			/// Property Indexer for SegmentNumber8
			/// </summary>
			public const int SegmentNumber8 = 1032;

			/// <summary>
			/// Property Indexer for SegmentValue8
			/// </summary>
			public const int SegmentValue8 = 1033;

			/// <summary>
			/// Property Indexer for SegmentNumber9
			/// </summary>
			public const int SegmentNumber9 = 1034;

			/// <summary>
			/// Property Indexer for SegmentValue9
			/// </summary>
			public const int SegmentValue9 = 1035;

			/// <summary>
			/// Property Indexer for LocationEmail
			/// </summary>
			public const int LocationEmail = 1036;

			/// <summary>
			/// Property Indexer for ContactPhone
			/// </summary>
			public const int ContactPhone = 1037;

			/// <summary>
			/// Property Indexer for ContactFax
			/// </summary>
			public const int ContactFax = 1038;

			/// <summary>
			/// Property Indexer for ContactEmail
			/// </summary>
			public const int ContactEmail = 1039;

			/// <summary>
			/// Property Indexer for LocationType
			/// </summary>
			public const int LocationType = 1040;

			/// <summary>
			/// Property Indexer for ITEMNO2
			/// </summary>
			public const int ITEMNO2 = 2001;

			/// <summary>
			/// Property Indexer for LOCATION3
			/// </summary>
			public const int LOCATION3 = 2002;

			/// <summary>
			/// Property Indexer for PickingSequence
			/// </summary>
			public const int PickingSequence = 2003;

			/// <summary>
			/// Property Indexer for Allowed
			/// </summary>
			public const int Allowed = 2004;

			/// <summary>
			/// Property Indexer for DateLocationActivated
			/// </summary>
			public const int DateLocationActivated = 2005;

			/// <summary>
			/// Property Indexer for InUse
			/// </summary>
			public const int InUse = 2006;

			/// <summary>
			/// Property Indexer for DateLastUsed
			/// </summary>
			public const int DateLastUsed = 2007;

			/// <summary>
			/// Property Indexer for QuantityonHandLastDayEnd
			/// </summary>
			public const int QuantityonHandLastDayEnd = 2008;

			/// <summary>
			/// Property Indexer for QuantityonPO
			/// </summary>
			public const int QuantityonPO = 2009;

			/// <summary>
			/// Property Indexer for QuantityonSO
			/// </summary>
			public const int QuantityonSO = 2010;

			/// <summary>
			/// Property Indexer for QuantityNotInCostFile
			/// </summary>
			public const int QuantityNotInCostFile = 2011;

			/// <summary>
			/// Property Indexer for QuantityShippedNotCosted
			/// </summary>
			public const int QuantityShippedNotCosted = 2012;

			/// <summary>
			/// Property Indexer for QuantityReceivedNotCosted
			/// </summary>
			public const int QuantityReceivedNotCosted = 2013;

			/// <summary>
			/// Property Indexer for QuantityAdjustedNotCosted
			/// </summary>
			public const int QuantityAdjustedNotCosted = 2014;

			/// <summary>
			/// Property Indexer for NumberOfUncostedTransactions
			/// </summary>
			public const int NumberOfUncostedTransactions = 2015;

			/// <summary>
			/// Property Indexer for TotalCost
			/// </summary>
			public const int TotalCost = 2016;

			/// <summary>
			/// Property Indexer for CostNotInCostFile
			/// </summary>
			public const int CostNotInCostFile = 2017;

			/// <summary>
			/// Property Indexer for CostUnitOfMeasure
			/// </summary>
			public const int CostUnitOfMeasure = 2018;

			/// <summary>
			/// Property Indexer for CostUnitConversionFactor
			/// </summary>
			public const int CostUnitConversionFactor = 2019;

			/// <summary>
			/// Property Indexer for StandardCost
			/// </summary>
			public const int StandardCost = 2020;

			/// <summary>
			/// Property Indexer for LastStandardCost
			/// </summary>
			public const int LastStandardCost = 2021;

			/// <summary>
			/// Property Indexer for LastStandardCostDate
			/// </summary>
			public const int LastStandardCostDate = 2022;

			/// <summary>
			/// Property Indexer for LastShipmentDate
			/// </summary>
			public const int LastShipmentDate = 2023;

			/// <summary>
			/// Property Indexer for AverageDaysToShip
			/// </summary>
			public const int AverageDaysToShip = 2024;

			/// <summary>
			/// Property Indexer for AverageUnitsShipped
			/// </summary>
			public const int AverageUnitsShipped = 2025;

			/// <summary>
			/// Property Indexer for ShipmentsUsedInCalculation
			/// </summary>
			public const int ShipmentsUsedInCalculation = 2026;

			/// <summary>
			/// Property Indexer for LastReceiptDate
			/// </summary>
			public const int LastReceiptDate = 2027;

			/// <summary>
			/// Property Indexer for MostRecentCost
			/// </summary>
			public const int MostRecentCost = 2028;

			/// <summary>
			/// Property Indexer for UserDefinedCost1
			/// </summary>
			public const int UserDefinedCost1 = 2029;

			/// <summary>
			/// Property Indexer for UserDefinedCost2
			/// </summary>
			public const int UserDefinedCost2 = 2030;

			/// <summary>
			/// Property Indexer for LastUnitCost
			/// </summary>
			public const int LastUnitCost = 2031;

			/// <summary>
			/// Property Indexer for QuantityCommitted
			/// </summary>
			public const int QuantityCommitted = 2032;

			/// <summary>
			/// Property Indexer for LastAllocatedSerial
			/// </summary>
			public const int LastAllocatedSerial = 2033;

			/// <summary>
			/// Property Indexer for LastAllocatedLot
			/// </summary>
			public const int LastAllocatedLot = 2034;

			/// <summary>
			/// Property Indexer for LeadTimeSIA
			/// </summary>
			public const int LeadTimeSIA = 2035;

			/// <summary>
			/// Property Indexer for InventoryMinimumSIA
			/// </summary>
			public const int InventoryMinimumSIA = 2036;

			/// <summary>
			/// Property Indexer for QuantityAvailableToShip
			/// </summary>
			public const int QuantityAvailableToShip = 2062;

			/// <summary>
			/// Property Indexer for AccountSetCode
			/// </summary>
			public const int AccountSetCode = 2063;

			/// <summary>
			/// Property Indexer for QuantityonHand
			/// </summary>
			public const int QuantityonHand = 2064;

			/// <summary>
			/// Property Indexer for AverageCost
			/// </summary>
			public const int AverageCost = 2065;

			/// <summary>
			/// Property Indexer for CostingMethod
			/// </summary>
			public const int CostingMethod = 2066;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for LOCDESC
			/// </summary>
			public const int LOCDESC = 2067;

			/// <summary>
			/// Property Indexer for CheckItemExistence
			/// </summary>
			public const int CheckItemExistence = 2068;

		}

		#endregion

	}
}
