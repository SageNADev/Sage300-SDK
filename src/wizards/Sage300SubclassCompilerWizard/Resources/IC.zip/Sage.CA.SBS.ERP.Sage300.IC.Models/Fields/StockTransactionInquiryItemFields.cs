﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    public partial class StockTransactionInquiryItem
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "IC0352";

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of Fields Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for AccountSetCode
            /// </summary>
            public const string AccountSetCode = "ACCTSET";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for DayEndNumber
            /// </summary>
            public const string DayEndNumber = "DAYENDSEQ";

            /// <summary>
            /// Property for TransactionSequence
            /// </summary>
            public const string TransactionSequence = "ENTRYSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for TransactionQuantity
            /// </summary>
            public const string TransactionQuantity = "QUANTITY";

            /// <summary>
            /// Property for ConversionFactor
            /// </summary>
            public const string ConversionFactor = "CONVERSION";

            /// <summary>
            /// Property for TransactionCost
            /// </summary>
            public const string TransactionCost = "TRANSCOST";

            /// <summary>
            /// Property for QuantityInStockingUOM
            /// </summary>
            public const string QuantityInStockingUOM = "STKQTY";

            /// <summary>
            /// Property for OptionalAmount
            /// </summary>
            public const string OptionalAmount = "OPTAMT";

            /// <summary>
            /// Property for Application
            /// </summary>
            public const string Application = "APP";

            /// <summary>
            /// Property for StockUnit
            /// </summary>
            public const string StockUnit = "STOCKUNIT";

            /// <summary>
            /// Property for DefaultPriceList
            /// </summary>
            public const string DefaultPriceList = "DEFPRICLST";

            /// <summary>
            /// Property for TotalCost
            /// </summary>
            public const string TotalCost = "TOTALCOST";

            /// <summary>
            /// Property for RecentCost
            /// </summary>
            public const string RecentCost = "RECENTCOST";

            /// <summary>
            /// Property for Cost1Name
            /// </summary>
            public const string Cost1Name = "COST1";

            /// <summary>
            /// Property for Cost2Name
            /// </summary>
            public const string Cost2Name = "COST2";

            /// <summary>
            /// Property for LastCost
            /// </summary>
            public const string LastCost = "LASTCOST";

            /// <summary>
            /// Property for StandardCost
            /// </summary>
            public const string StandardCost = "STDCOST";

            /// <summary>
            /// Property for CostUnit
            /// </summary>
            public const string CostUnit = "COSTUNIT";

            /// <summary>
            /// Property for CostConversion
            /// </summary>
            public const string CostConversion = "COSTCONV";

            /// <summary>
            /// Property for TotalQuantity
            /// </summary>
            public const string TotalQuantity = "TOTALQTY";

            /// <summary>
            /// Property for PriceListCode
            /// </summary>
            public const string PriceListCode = "PRICELIST";

            /// <summary>
            /// Property for DecimalsInPrice
            /// </summary>
            public const string DecimalsInPrice = "PRICEDECS";

            /// <summary>
            /// Property for BasePrice
            /// </summary>
            public const string BasePrice = "BASEPRICE";

            /// <summary>
            /// Property for PricingUnitOfMeasure
            /// </summary>
            public const string PricingUnitOfMeasure = "BASEUNIT";

            /// <summary>
            /// Property for BaseConversionFactor
            /// </summary>
            public const string BaseConversionFactor = "BASECONV";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for DetailComponentNumber
            /// </summary>
            public const string DetailComponentNumber = "COMPNUM";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for FormattedItemNumber
            /// </summary>
            public const string FormattedItemNumber = "FMTITEMNO";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";
        }

        #endregion Properties

        /// <summary>
        /// Contains list of Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for AccountSetCode
            /// </summary>
            public const int AccountSetCode = 1;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 2;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 5;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 6;

            /// <summary>
            /// Property Indexer for DayEndNumber
            /// </summary>
            public const int DayEndNumber = 7;

            /// <summary>
            /// Property Indexer for TransactionSequence
            /// </summary>
            public const int TransactionSequence = 8;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 9;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 10;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 11;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 12;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 13;

            /// <summary>
            /// Property Indexer for TransactionQuantity
            /// </summary>
            public const int TransactionQuantity = 14;

            /// <summary>
            /// Property Indexer for ConversionFactor
            /// </summary>
            public const int ConversionFactor = 15;

            /// <summary>
            /// Property Indexer for TransactionCost
            /// </summary>
            public const int TransactionCost = 16;

            /// <summary>
            /// Property Indexer for QuantityInStockingUOM
            /// </summary>
            public const int QuantityInStockingUOM = 17;

            /// <summary>
            /// Property Indexer for OptionalAmount
            /// </summary>
            public const int OptionalAmount = 18;

            /// <summary>
            /// Property Indexer for Application
            /// </summary>
            public const int Application = 19;

            /// <summary>
            /// Property Indexer for StockUnit
            /// </summary>
            public const int StockUnit = 20;

            /// <summary>
            /// Property Indexer for DefaultPriceList
            /// </summary>
            public const int DefaultPriceList = 21;

            /// <summary>
            /// Property Indexer for TotalCost
            /// </summary>
            public const int TotalCost = 22;

            /// <summary>
            /// Property Indexer for RecentCost
            /// </summary>
            public const int RecentCost = 23;

            /// <summary>
            /// Property Indexer for Cost1Name
            /// </summary>
            public const int Cost1Name = 24;

            /// <summary>
            /// Property Indexer for Cost2Name
            /// </summary>
            public const int Cost2Name = 25;

            /// <summary>
            /// Property Indexer for LastCost
            /// </summary>
            public const int LastCost = 26;

            /// <summary>
            /// Property Indexer for StandardCost
            /// </summary>
            public const int StandardCost = 27;

            /// <summary>
            /// Property Indexer for CostUnit
            /// </summary>
            public const int CostUnit = 28;

            /// <summary>
            /// Property Indexer for CostConversion
            /// </summary>
            public const int CostConversion = 29;

            /// <summary>
            /// Property Indexer for TotalQuantity
            /// </summary>
            public const int TotalQuantity = 30;

            /// <summary>
            /// Property Indexer for PriceListCode
            /// </summary>
            public const int PriceListCode = 31;

            /// <summary>
            /// Property Indexer for DecimalsInPrice
            /// </summary>
            public const int DecimalsInPrice = 32;

            /// <summary>
            /// Property Indexer for BasePrice
            /// </summary>
            public const int BasePrice = 33;

            /// <summary>
            /// Property Indexer for PricingUnitOfMeasure
            /// </summary>
            public const int PricingUnitOfMeasure = 34;

            /// <summary>
            /// Property Indexer for BaseConversionFactor
            /// </summary>
            public const int BaseConversionFactor = 35;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 36;

            /// <summary>
            /// Property Indexer for DetailComponentNumber
            /// </summary>
            public const int DetailComponentNumber = 37;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 38;

            /// <summary>
            /// Property Indexer for FormattedItemNumber
            /// </summary>
            public const int FormattedItemNumber = 70;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 71;
        }
    }
}