// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A class for UnitsofMeasure Constants 
    /// </summary>
    public partial class UnitsOfMeasure
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0746";

        /// <summary>
        /// Contains list of UnitsofMeasure Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for UnitsofMeasure 
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for DefaultConversionFactor 
            /// </summary>
            public const string DefaultConversionFactor = "DEFCONV";

            #endregion
        }

        /// <summary>
        /// Contains list of UnitsofMeasure Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for UnitsofMeasure 
            /// </summary>
            public const int UnitOfMeasure = 1;

            /// <summary>
            /// Property Indexer for DefaultConversionFactor 
            /// </summary>
            public const int DefaultConversionFactor = 2;

            #endregion
        }
    }
}