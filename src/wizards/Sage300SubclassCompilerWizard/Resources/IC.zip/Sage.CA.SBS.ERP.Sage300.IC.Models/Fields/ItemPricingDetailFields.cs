// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of ItemPricingDetail Constants
     /// </summary>
     public partial class ItemPricingDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "IC0482";

          #region Properties
          /// <summary>
          /// Contains list of ItemPricingDetail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CurrencyCode
               /// </summary>
               public const string CurrencyCode = "CURRENCY";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for PriceListCode
               /// </summary>
               public const string PriceListCode = "PRICELIST";

               /// <summary>
               /// Property for PriceDetailType
               /// </summary>
               public const string PriceDetailType = "DPRICETYPE";

               /// <summary>
               /// Property for QuantityUnit
               /// </summary>
               public const string QuantityUnit = "QTYUNIT";

               /// <summary>
               /// Property for WeightUnit
               /// </summary>
               public const string WeightUnit = "WEIGHTUNIT";

               /// <summary>
               /// Property for UnitPrice
               /// </summary>
               public const string UnitPrice = "UNITPRICE";

               /// <summary>
               /// Property for ConversionFactor
               /// </summary>
               public const string ConversionFactor = "CONVERSION";

               /// <summary>
               /// Property for SaleStart
               /// </summary>
               public const string SaleStart = "SALESTART";

               /// <summary>
               /// Property for SaleEnd
               /// </summary>
               public const string SaleEnd = "SALEEND";

               /// <summary>
               /// Property for LastPriceChangeDate
               /// </summary>
               public const string LastPriceChangeDate = "LASTPRICDT";

               /// <summary>
               /// Property for PreviousPrice
               /// </summary>
               public const string PreviousPrice = "PREVPRICE";

               /// <summary>
               /// Property for DefaultUnit
               /// </summary>
               public const string DefaultUnit = "DEFAULT";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of ItemPricingDetail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CurrencyCode
               /// </summary>
               public const int CurrencyCode = 1;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 2;

               /// <summary>
               /// Property Indexer for PriceListCode
               /// </summary>
               public const int PriceListCode = 3;

               /// <summary>
               /// Property Indexer for PriceDetailType
               /// </summary>
               public const int PriceDetailType = 4;

               /// <summary>
               /// Property Indexer for QuantityUnit
               /// </summary>
               public const int QuantityUnit = 5;

               /// <summary>
               /// Property Indexer for WeightUnit
               /// </summary>
               public const int WeightUnit = 6;

               /// <summary>
               /// Property Indexer for UnitPrice
               /// </summary>
               public const int UnitPrice = 7;

               /// <summary>
               /// Property Indexer for ConversionFactor
               /// </summary>
               public const int ConversionFactor = 8;

               /// <summary>
               /// Property Indexer for SaleStart
               /// </summary>
               public const int SaleStart = 9;

               /// <summary>
               /// Property Indexer for SaleEnd
               /// </summary>
               public const int SaleEnd = 10;

               /// <summary>
               /// Property Indexer for LastPriceChangeDate
               /// </summary>
               public const int LastPriceChangeDate = 11;

               /// <summary>
               /// Property Indexer for PreviousPrice
               /// </summary>
               public const int PreviousPrice = 12;

               /// <summary>
               /// Property Indexer for DefaultUnit
               /// </summary>
               public const int DefaultUnit = 70;

          }
          #endregion

     }
}
