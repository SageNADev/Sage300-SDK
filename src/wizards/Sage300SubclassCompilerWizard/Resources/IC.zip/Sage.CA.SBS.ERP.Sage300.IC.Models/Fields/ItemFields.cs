﻿// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Items Constants 
    /// </summary>
    public partial class Item
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0310";

        /// <summary>
        /// Contains list of Items Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for UnformattedItemNumber 
            /// </summary>
            public const string UnformattedItemNumber = "ITEMNO";

            /// <summary>
            /// Property for AlternateItemSetNumber 
            /// </summary>
            public const string AlternateItemSetNumber = "ALTSET";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for StructureCode 
            /// </summary>
            public const string StructureCode = "ITEMBRKID";

            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "FMTITEMNO";

            /// <summary>
            /// Property for Category 
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for AccountSetCode 
            /// </summary>
            public const string AccountSetCode = "CNTLACCT";

            /// <summary>
            /// Property for StockItem 
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for StockingUnitOfMeasure 
            /// </summary>
            public const string StockingUnitOfMeasure = "STOCKUNIT";

            /// <summary>
            /// Property for DefaultPriceListCode 
            /// </summary>
            public const string DefaultPriceListCode = "DEFPRICLST";

            /// <summary>
            /// Property for UnitWeight 
            /// </summary>
            public const string UnitWeight = "UNITWGT";

            /// <summary>
            /// Property for DefaultPickingSequence 
            /// </summary>
            public const string DefaultPickingSequence = "PICKINGSEQ";

            /// <summary>
            /// Property for SerialNumbers 
            /// </summary>
            public const string SerialNumbers = "SERIALNO";

            /// <summary>
            /// Property for CommodityNumber 
            /// </summary>
            public const string CommodityNumber = "COMMODIM";

            /// <summary>
            /// Property for DateInactive 
            /// </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary>
            /// Property for Segment1 
            /// </summary>
            public const string Segment1 = "SEGMENT1";

            /// <summary>
            /// Property for Segment2 
            /// </summary>
            public const string Segment2 = "SEGMENT2";

            /// <summary>
            /// Property for Segment3 
            /// </summary>
            public const string Segment3 = "SEGMENT3";

            /// <summary>
            /// Property for Segment4 
            /// </summary>
            public const string Segment4 = "SEGMENT4";

            /// <summary>
            /// Property for Segment5 
            /// </summary>
            public const string Segment5 = "SEGMENT5";

            /// <summary>
            /// Property for Segment6 
            /// </summary>
            public const string Segment6 = "SEGMENT6";

            /// <summary>
            /// Property for Segment7 
            /// </summary>
            public const string Segment7 = "SEGMENT7";

            /// <summary>
            /// Property for Segment8 
            /// </summary>
            public const string Segment8 = "SEGMENT8";

            /// <summary>
            /// Property for Segment9 
            /// </summary>
            public const string Segment9 = "SEGMENT9";

            /// <summary>
            /// Property for Segment10 
            /// </summary>
            public const string Segment10 = "SEGMENT10";

            /// <summary>
            /// Property for Comment1 
            /// </summary>
            public const string Comment1 = "COMMENT1";

            /// <summary>
            /// Property for Comment2 
            /// </summary>
            public const string Comment2 = "COMMENT2";

            /// <summary>
            /// Property for Comment3 
            /// </summary>
            public const string Comment3 = "COMMENT3";

            /// <summary>
            /// Property for Comment4 
            /// </summary>
            public const string Comment4 = "COMMENT4";

            /// <summary>
            /// Property for AllowItemInWebStore 
            /// </summary>
            public const string AllowItemInWebStore = "ALLOWONWEB";

            /// <summary>
            /// Property for KittingItem 
            /// </summary>
            public const string KittingItem = "KITTING";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for DefaultKitNumber 
            /// </summary>
            public const string DefaultKitNumber = "DEFKITNO";

            /// <summary>
            /// Property for Sellable 
            /// </summary>
            public const string Sellable = "SELLABLE";

            /// <summary>
            /// Property for WeightUnitOfMeasure 
            /// </summary>
            public const string WeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for UnformattedAlternateItemNo 
            /// </summary>
            public const string UnformattedAlternateItemNo = "ALTITEMNO";

            /// <summary>
            /// Property for AlternateItemNumber 
            /// </summary>
            public const string AlternateItemNumber = "FMTALTITEM";
             
            /// <summary>
            /// Property for AlternateItemDescription 
            /// </summary>
            public const string AlternateItemDescription = "ALTITEMDSC";

            /// <summary>
            /// Property for CostingMethod 
            /// </summary>
            public const string CostingMethod = "COSTMETHOD";

            /// <summary>
            /// Property for ProcessCommand 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for WeightConversionFactor 
            /// </summary>
            public const string WeightConversionFactor = "WEIGHTCONV";

            /// <summary>
            /// Property for IsItemaBomComponent 
            /// </summary>
            public const string IsItemaBomComponent = "ISBOMCMPN";

            /// <summary>
            /// Property for SerialNumberMask 
            /// </summary>
            public const string SerialNumberMask = "SERIALMASK";

            /// <summary>
            /// Property for NextSerialNumber 
            /// </summary>
            public const string NextSerialNumber = "NEXTSERFMT";

            /// <summary>
            /// Property for UseSerialsDaysToExpire 
            /// </summary>
            public const string UseSerialsDaysToExpire = "SUSEEXPDAY";

            /// <summary>
            /// Property for SerialsDaysToExpire 
            /// </summary>
            public const string SerialsDaysToExpire = "SEXPDAYS";

            /// <summary>
            /// Property for AllowDifferentSerialQty 
            /// </summary>
            public const string AllowDifferentSerialQty = "SDIFQTYOK";

            /// <summary>
            /// Property for SerialsOptionalFields 
            /// </summary>
            public const string SerialsOptionalFields = "SVALUES";

            /// <summary>
            /// Property for DefaultSerialWarrantyCode 
            /// </summary>
            public const string DefaultSerialWarrantyCode = "SWARYCODE";

            /// <summary>
            /// Property for DefaultSerialContractCode 
            /// </summary>
            public const string DefaultSerialContractCode = "SCONTCODE";

            /// <summary>
            /// Property for SerialIsOnContWhenReceived 
            /// </summary>
            public const string SerialIsOnContWhenReceived = "SCONTRECE";

            /// <summary>
            /// Property for SerialIsOnWarrWhenSold 
            /// </summary>
            public const string SerialIsOnWarrWhenSold = "SWARYSOLD";

            /// <summary>
            /// Property for SerialIsOnWarrWhenRegister 
            /// </summary>
            public const string SerialIsOnWarrWhenRegister = "SWARYREG";

            /// <summary>
            /// Property for LotNumbers 
            /// </summary>
            public const string LotNumbers = "LOTITEM";

            /// <summary>
            /// Property for LotNumberMask 
            /// </summary>
            public const string LotNumberMask = "LOTMASK";

            /// <summary>
            /// Property for NextLotNumber 
            /// </summary>
            public const string NextLotNumber = "NEXTLOTFMT";

            /// <summary>
            /// Property for UseLotsDaysToExpire 
            /// </summary>
            public const string UseLotsDaysToExpire = "LUSEEXPDAY";

            /// <summary>
            /// Property for LotsDaysToExpire 
            /// </summary>
            public const string LotsDaysToExpire = "LEXPDAYS";

            /// <summary>
            /// Property for UseLotsDaysOnQuarantine 
            /// </summary>
            public const string UseLotsDaysOnQuarantine = "LUSEQRNDAY";

            /// <summary>
            /// Property for LotsDaysOnQuarantine 
            /// </summary>
            public const string LotsDaysOnQuarantine = "LQRNDAYS";

            /// <summary>
            /// Property for AllowDifferentLotQty 
            /// </summary>
            public const string AllowDifferentLotQty = "LDIFQTYOK";

            /// <summary>
            /// Property for LotsOptionalFields 
            /// </summary>
            public const string LotsOptionalFields = "LVALUES";

            /// <summary>
            /// Property for DefaultLotWarrantyCode 
            /// </summary>
            public const string DefaultLotWarrantyCode = "LWARYCODE";

            /// <summary>
            /// Property for DefaultLotContractCode 
            /// </summary>
            public const string DefaultLotContractCode = "LCONTCODE";

            /// <summary>
            /// Property for LotIsOnContWhenReceived 
            /// </summary>
            public const string LotIsOnContWhenReceived = "LCONTRECE";

            /// <summary>
            /// Property for LotIsOnWarrWhenSold 
            /// </summary>
            public const string LotIsOnWarrWhenSold = "LWARYSOLD";

            /// <summary>
            /// Property for SerialNumbersInUse 
            /// </summary>
            public const string SerialNumbersInUse = "SERIALUSED";
            /// <summary>
            /// Property for SerialMaskStructure 
            /// </summary>
            public const string SerialMaskStructure = "SMSKSTRUCT";

            /// <summary>
            /// Property for SerialMaskDescription 
            /// </summary>
            public const string SerialMaskDescription = "SMSKDESC";

            /// <summary>
            /// Property for UnformattedSerialNumber 
            /// </summary>
            public const string UnformattedSerialNumber = "UNFSERIAL";

            /// <summary>
            /// Property for SerialNumber 
            /// </summary>
            public const string SerialNumber = "FMTSERIAL";

            /// <summary>
            /// Property for AutogenSerialNumber 
            /// </summary>
            public const string AutogenSerialNumber = "NXTAUTOSER";

            /// <summary>
            /// Property for NumberOfSerialsToGenerate 
            /// </summary>
            public const string NumberOfSerialsToGenerate = "GENNEWSER";

            /// <summary>
            /// Property for NumberOfSerialsNotGenerated 
            /// </summary>
            public const string NumberOfSerialsNotGenerated = "GENRMNSER";

            /// <summary>
            /// Property for FirstGeneratedSerial 
            /// </summary>
            public const string FirstGeneratedSerial = "SFIRSTGEN";

            /// <summary>
            /// Property for LastGeneratedSerial 
            /// </summary>
            public const string LastGeneratedSerial = "SLASTGEN";

            /// <summary>
            /// Property for LotNumbersInUse 
            /// </summary>
            public const string LotNumbersInUse = "LOTUSED";

            /// <summary>
            /// Property for LotMaskStructure 
            /// </summary>
            public const string LotMaskStructure = "LMSKSTRUCT";

            /// <summary>
            /// Property for LotMaskDescription 
            /// </summary>
            public const string LotMaskDescription = "LMSKDESC";

            /// <summary>
            /// Property for UnformattedLotNumber 
            /// </summary>
            public const string UnformattedLotNumber = "UNFLOT";

            /// <summary>
            /// Property for LotNumber 
            /// </summary>
            public const string LotNumber = "FMTLOT";

            /// <summary>
            /// Property for AutogenLotNumber 
            /// </summary>
            public const string AutogenLotNumber = "NXTAUTOLOT";

            /// <summary>
            /// Property for NumberOfLotsToGenerate 
            /// </summary>
            public const string NumberOfLotsToGenerate = "GENNEWLOT";

            /// <summary>
            /// Property for NumberOfLotsNotGenerated 
            /// </summary>
            public const string NumberOfLotsNotGenerated = "GENRMNLOT";

            /// <summary>
            /// Property for FirstGeneratedLot 
            /// </summary>
            public const string FirstGeneratedLot = "LFIRSTGEN";

            /// <summary>
            /// Property for LastGeneratedLot 
            /// </summary>
            public const string LastGeneratedLot = "LLASTGEN";

            /// <summary>
            /// Property for SiaPreferredVendorType 
            /// </summary>
            public const string SiaPreferredVendorType = "PREVENDTY";

            /// <summary>
            /// Property for DefaultBomNumber 
            /// </summary>
            public const string DefaultBomNumber = "DEFBOMNO";

            /// <summary>
            /// Property for Status1 
            /// </summary>
            public const string Status1 = "INACTIVE";

            /// <summary>
            /// Property for StockItem1 
            /// </summary>
            public const string StockItem1 = "STOCKITEM";

            /// <summary>
            /// Property for Sellable1 
            /// </summary>
            public const string Sellable1 = "SELLABLE";

            /// <summary>
            /// Property for AllowItemInWebStore1 
            /// </summary>
            public const string AllowItemInWebStore1 = "ALLOWONWEB";

            /// <summary>
            /// Property for KittingItem1 
            /// </summary>
            public const string KittingItem1 = "KITTING";

            /// <summary>
            /// Property for IsItemaBomComponent1 
            /// </summary>
            public const string IsItemaBomComponent1 = "ISBOMCMPN";

            /// <summary>
            /// Property for CostingMethodName
            /// </summary>
            public const string CostingMethodName = "COSTMETHOD";

            /// <summary>
            /// Property for ProcessCommandName
            /// </summary>
            public const string ProcessCommandName = "PROCESSCMD";


            /// <summary>
            /// Property Indexer for Qty. on Hand
            /// </summary>
            public const string QtyonHand = "QTONHANDA";
            /// <summary>
            /// Property Indexer for Qty. on Purchase Order 
            /// </summary>
            public const string QtyonPurchaseOrder = "QTONORDERA";

            /// <summary>
            /// Property Indexer for Qty. on Sales Order 
            /// </summary>
            public const string QtyonSalesOrder = "QTSALORDRA";

            /// <summary>
            /// Property Indexer for Qty. Available 
            /// </summary>
            public const string QtyAvailable = "QTAVAILA";

            /// <summary>
            /// Property Indexer for Qty. Committed 
            /// </summary>
            public const string QtyCommitted = "QTYCOMMITA";

            /// <summary>
            /// Property Indexer for Preferred Vendor 
            /// </summary>
            public const string PreferredVendor = "PREVENDOR";
            /// <summary>
            /// Property Indexer for Preferred Vendor Item 
            /// </summary>
            public const string PreferredVendorItem = "VENDITEM ";
            #endregion
        }


        /// <summary>
        /// Contains list of Items Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for UnformattedItemNumber 
            /// </summary>
            public const int UnformattedItemNumber = 1;

            /// <summary>
            /// Property Indexer for AlternateItemSetNumber 
            /// </summary>
            public const int AlternateItemSetNumber = 2;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 4;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 5;

            /// <summary>
            /// Property Indexer for StructureCode 
            /// </summary>
            public const int StructureCode = 6;

            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 7;

            /// <summary>
            /// Property Indexer for Category 
            /// </summary>
            public const int Category = 8;

            /// <summary>
            /// Property Indexer for AccountSetCode 
            /// </summary>
            public const int AccountSetCode = 9;

            /// <summary>
            /// Property Indexer for StockItem 
            /// </summary>
            public const int StockItem = 10;

            /// <summary>
            /// Property Indexer for StockingUnitOfMeasure 
            /// </summary>
            public const int StockingUnitOfMeasure = 11;

            /// <summary>
            /// Property Indexer for DefaultPriceListCode 
            /// </summary>
            public const int DefaultPriceListCode = 12;

            /// <summary>
            /// Property Indexer for UnitWeight 
            /// </summary>
            public const int UnitWeight = 13;

            /// <summary>
            /// Property Indexer for DefaultPickingSequence 
            /// </summary>
            public const int DefaultPickingSequence = 14;

            /// <summary>
            /// Property Indexer for SerialNumbers 
            /// </summary>
            public const int SerialNumbers = 15;

            /// <summary>
            /// Property Indexer for CommodityNumber 
            /// </summary>
            public const int CommodityNumber = 24;

            /// <summary>
            /// Property Indexer for DateInactive 
            /// </summary>
            public const int DateInactive = 25;

            /// <summary>
            /// Property Indexer for Segment1 
            /// </summary>
            public const int Segment1 = 26;

            /// <summary>
            /// Property Indexer for Segment2 
            /// </summary>
            public const int Segment2 = 27;

            /// <summary>
            /// Property Indexer for Segment3 
            /// </summary>
            public const int Segment3 = 28;

            /// <summary>
            /// Property Indexer for Segment4 
            /// </summary>
            public const int Segment4 = 29;

            /// <summary>
            /// Property Indexer for Segment5 
            /// </summary>
            public const int Segment5 = 30;

            /// <summary>
            /// Property Indexer for Segment6 
            /// </summary>
            public const int Segment6 = 31;

            /// <summary>
            /// Property Indexer for Segment7 
            /// </summary>
            public const int Segment7 = 32;

            /// <summary>
            /// Property Indexer for Segment8 
            /// </summary>
            public const int Segment8 = 33;

            /// <summary>
            /// Property Indexer for Segment9 
            /// </summary>
            public const int Segment9 = 34;

            /// <summary>
            /// Property Indexer for Segment10 
            /// </summary>
            public const int Segment10 = 35;

            /// <summary>
            /// Property Indexer for Comment1 
            /// </summary>
            public const int Comment1 = 36;

            /// <summary>
            /// Property Indexer for Comment2 
            /// </summary>
            public const int Comment2 = 37;

            /// <summary>
            /// Property Indexer for Comment3 
            /// </summary>
            public const int Comment3 = 38;

            /// <summary>
            /// Property Indexer for Comment4 
            /// </summary>
            public const int Comment4 = 39;

            /// <summary>
            /// Property Indexer for AllowItemInWebStore 
            /// </summary>
            public const int AllowItemInWebStore = 40;

            /// <summary>
            /// Property Indexer for KittingItem 
            /// </summary>
            public const int KittingItem = 41;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 42;

            /// <summary>
            /// Property Indexer for DefaultKitNumber 
            /// </summary>
            public const int DefaultKitNumber = 43;

            /// <summary>
            /// Property Indexer for Sellable 
            /// </summary>
            public const int Sellable = 44;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure 
            /// </summary>
            public const int WeightUnitOfMeasure = 45;

            /// <summary>
            /// Property Indexer for UnformattedAlternateItemNo 
            /// </summary>
            public const int UnformattedAlternateItemNo = 56;

            /// <summary>
            /// Property Indexer for AlternateItemNumber 
            /// </summary>
            public const int AlternateItemNumber = 57;

            /// <summary>
            /// Property Indexer for AlternateItemDescription 
            /// </summary>
            public const int AlternateItemDescription = 58;

            /// <summary>
            /// Property Indexer for CostingMethod 
            /// </summary>
            public const int CostingMethod = 59;

            /// <summary>
            /// Property Indexer for ProcessCommand 
            /// </summary>
            public const int ProcessCommand = 60;

            /// <summary>
            /// Property Indexer for WeightConversionFactor 
            /// </summary>
            public const int WeightConversionFactor = 61;

            /// <summary>
            /// Property Indexer for IsItemaBomComponent 
            /// </summary>
            public const int IsItemaBomComponent = 62;

            /// <summary>
            /// Property Indexer for SerialNumberMask 
            /// </summary>
            public const int SerialNumberMask = 63;

            /// <summary>
            /// Property Indexer for NextSerialNumber 
            /// </summary>
            public const int NextSerialNumber = 64;

            /// <summary>
            /// Property Indexer for UseSerialsDaysToExpire 
            /// </summary>
            public const int UseSerialsDaysToExpire = 65;

            /// <summary>
            /// Property Indexer for SerialsDaysToExpire 
            /// </summary>
            public const int SerialsDaysToExpire = 66;

            /// <summary>
            /// Property Indexer for AllowDifferentSerialQty 
            /// </summary>
            public const int AllowDifferentSerialQty = 67;

            /// <summary>
            /// Property Indexer for SerialsOptionalFields 
            /// </summary>
            public const int SerialsOptionalFields = 68;

            /// <summary>
            /// Property Indexer for DefaultSerialWarrantyCode 
            /// </summary>
            public const int DefaultSerialWarrantyCode = 69;

            /// <summary>
            /// Property Indexer for DefaultSerialContractCode 
            /// </summary>
            public const int DefaultSerialContractCode = 70;

            /// <summary>
            /// Property Indexer for SerialIsOnContWhenReceived 
            /// </summary>
            public const int SerialIsOnContWhenReceived = 71;

            /// <summary>
            /// Property Indexer for SerialIsOnWarrWhenSold 
            /// </summary>
            public const int SerialIsOnWarrWhenSold = 72;

            /// <summary>
            /// Property Indexer for SerialIsOnWarrWhenRegister 
            /// </summary>
            public const int SerialIsOnWarrWhenRegister = 73;

            /// <summary>
            /// Property Indexer for LotNumbers 
            /// </summary>
            public const int LotNumbers = 74;

            /// <summary>
            /// Property Indexer for LotNumberMask 
            /// </summary>
            public const int LotNumberMask = 75;

            /// <summary>
            /// Property Indexer for NextLotNumber 
            /// </summary>
            public const int NextLotNumber = 76;

            /// <summary>
            /// Property Indexer for UseLotsDaysToExpire 
            /// </summary>
            public const int UseLotsDaysToExpire = 77;

            /// <summary>
            /// Property Indexer for LotsDaysToExpire 
            /// </summary>
            public const int LotsDaysToExpire = 78;

            /// <summary>
            /// Property Indexer for UseLotsDaysOnQuarantine 
            /// </summary>
            public const int UseLotsDaysOnQuarantine = 79;

            /// <summary>
            /// Property Indexer for LotsDaysOnQuarantine 
            /// </summary>
            public const int LotsDaysOnQuarantine = 80;

            /// <summary>
            /// Property Indexer for AllowDifferentLotQty 
            /// </summary>
            public const int AllowDifferentLotQty = 81;

            /// <summary>
            /// Property Indexer for LotsOptionalFields 
            /// </summary>
            public const int LotsOptionalFields = 82;

            /// <summary>
            /// Property Indexer for DefaultLotWarrantyCode 
            /// </summary>
            public const int DefaultLotWarrantyCode = 83;

            /// <summary>
            /// Property Indexer for DefaultLotContractCode 
            /// </summary>
            public const int DefaultLotContractCode = 84;

            /// <summary>
            /// Property Indexer for LotIsOnContWhenReceived 
            /// </summary>
            public const int LotIsOnContWhenReceived = 85;

            /// <summary>
            /// Property Indexer for LotIsOnWarrWhenSold 
            /// </summary>
            public const int LotIsOnWarrWhenSold = 86;

            /// <summary>
            /// Property Indexer for SerialNumbersInUse 
            /// </summary>
            public const int SerialNumbersInUse = 87;

            /// <summary>
            /// Property Indexer for SerialMaskStructure 
            /// </summary>
            public const int SerialMaskStructure = 88;

            /// <summary>
            /// Property Indexer for SerialMaskDescription 
            /// </summary>
            public const int SerialMaskDescription = 89;

            /// <summary>
            /// Property Indexer for UnformattedSerialNumber 
            /// </summary>
            public const int UnformattedSerialNumber = 90;

            /// <summary>
            /// Property Indexer for SerialNumber 
            /// </summary>
            public const int SerialNumber = 91;

            /// <summary>
            /// Property Indexer for AutogenSerialNumber 
            /// </summary>
            public const int AutogenSerialNumber = 92;

            /// <summary>
            /// Property Indexer for NumberOfSerialsToGenerate 
            /// </summary>
            public const int NumberOfSerialsToGenerate = 93;

            /// <summary>
            /// Property Indexer for NumberOfSerialsNotGenerated 
            /// </summary>
            public const int NumberOfSerialsNotGenerated = 94;

            /// <summary>
            /// Property Indexer for FirstGeneratedSerial 
            /// </summary>
            public const int FirstGeneratedSerial = 95;

            /// <summary>
            /// Property Indexer for LastGeneratedSerial 
            /// </summary>
            public const int LastGeneratedSerial = 96;

            /// <summary>
            /// Property Indexer for LotNumbersInUse 
            /// </summary>
            public const int LotNumbersInUse = 97;

            /// <summary>
            /// Property Indexer for LotMaskStructure 
            /// </summary>
            public const int LotMaskStructure = 98;

            /// <summary>
            /// Property Indexer for LotMaskDescription 
            /// </summary>
            public const int LotMaskDescription = 99;

            /// <summary>
            /// Property Indexer for UnformattedLotNumber 
            /// </summary>
            public const int UnformattedLotNumber = 100;

            /// <summary>
            /// Property Indexer for LotNumber 
            /// </summary>
            public const int LotNumber = 101;

            /// <summary>
            /// Property Indexer for AutogenLotNumber 
            /// </summary>
            public const int AutogenLotNumber = 102;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate 
            /// </summary>
            public const int NumberOfLotsToGenerate = 103;

            /// <summary>
            /// Property Indexer for NumberOfLotsNotGenerated 
            /// </summary>
            public const int NumberOfLotsNotGenerated = 104;

            /// <summary>
            /// Property Indexer for FirstGeneratedLot 
            /// </summary>
            public const int FirstGeneratedLot = 105;

            /// <summary>
            /// Property Indexer for LastGeneratedLot 
            /// </summary>
            public const int LastGeneratedLot = 106;

            /// <summary>
            /// Property Indexer for SiaPreferredVendorType 
            /// </summary>
            public const int SiaPreferredVendorType = 107;
            /// <summary>
            /// Property Indexer for DefaultBomNumber 
            /// </summary>
            public const int DefaultBomNumber = 108;

            /// <summary>
            /// Property Indexer for Qty. on Hand
            /// </summary>
            public const int QtyonHand = 110;

            /// <summary>
            /// Property Indexer for Qty. on Purchase Order 
            /// </summary>
            public const int QtyonPurchaseOrder = 111;

            /// <summary>
            /// Property Indexer for Qty. on Sales Order 
            /// </summary>
            public const int QtyonSalesOrder = 112;

            /// <summary>
            /// Property Indexer for Qty. Available 
            /// </summary>
            public const int QtyAvailable = 113;

            /// <summary>
            /// Property Indexer for Qty. Committed 
            /// </summary>
            public const int QtyCommitted = 114;

            /// <summary>
            /// Property Indexer for Preferred Vendor 
            /// </summary>
            public const int PreferredVendor = 115;
            /// <summary>
            /// Property Indexer for Preferred Vendor Item 
            /// </summary>
            public const int PreferredVendorItem = 116;


            #endregion
        }


    }
}
