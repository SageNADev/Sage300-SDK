﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ItemStructures Constants 
    /// </summary>
    public partial class ItemStructure
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0320";

        /// <summary>
        /// Contains list of ItemStructures Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for StructureCode 
            /// </summary>
            public const string StructureCode = "ITEMBRKID";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Prefix 
            /// </summary>
            public const string Prefix = "DELIM0";

            /// <summary>
            /// Property for Segment1 
            /// </summary>
            public const string Segment1 = "SEGMENT1";

            /// <summary>
            /// Property for Segment1Offset 
            /// </summary>
            public const string Segment1Offset = "OFFSET1";

            /// <summary>
            /// Property for Segment1Length 
            /// </summary>
            public const string Segment1Length = "LENGTH1";

            /// <summary>
            /// Property for ValidateSegment1 
            /// </summary>
            public const string ValidateSegment1 = "VALIDATE1";

            /// <summary>
            /// Property for SegmentSeparator1 
            /// </summary>
            public const string SegmentSeparator1 = "DELIM1";

            /// <summary>
            /// Property for Segment2 
            /// </summary>
            public const string Segment2 = "SEGMENT2";

            /// <summary>
            /// Property for Segment2Offset 
            /// </summary>
            public const string Segment2Offset = "OFFSET2";

            /// <summary>
            /// Property for Segment2Length 
            /// </summary>
            public const string Segment2Length = "LENGTH2";

            /// <summary>
            /// Property for ValidateSegment2 
            /// </summary>
            public const string ValidateSegment2 = "VALIDATE2";

            /// <summary>
            /// Property for SegmentSeparator2 
            /// </summary>
            public const string SegmentSeparator2 = "DELIM2";

            /// <summary>
            /// Property for Segment3 
            /// </summary>
            public const string Segment3 = "SEGMENT3";

            /// <summary>
            /// Property for Segment3Offset 
            /// </summary>
            public const string Segment3Offset = "OFFSET3";

            /// <summary>
            /// Property for Segment3Length 
            /// </summary>
            public const string Segment3Length = "LENGTH3";

            /// <summary>
            /// Property for ValidateSegment3 
            /// </summary>
            public const string ValidateSegment3 = "VALIDATE3";

            /// <summary>
            /// Property for SegmentSeparator3 
            /// </summary>
            public const string SegmentSeparator3 = "DELIM3";

            /// <summary>
            /// Property for Segment4 
            /// </summary>
            public const string Segment4 = "SEGMENT4";

            /// <summary>
            /// Property for Segment4Offset 
            /// </summary>
            public const string Segment4Offset = "OFFSET4";

            /// <summary>
            /// Property for Segment4Length 
            /// </summary>
            public const string Segment4Length = "LENGTH4";

            /// <summary>
            /// Property for ValidateSegment4 
            /// </summary>
            public const string ValidateSegment4 = "VALIDATE4";

            /// <summary>
            /// Property for SegmentSeparator4 
            /// </summary>
            public const string SegmentSeparator4 = "DELIM4";

            /// <summary>
            /// Property for Segment5 
            /// </summary>
            public const string Segment5 = "SEGMENT5";

            /// <summary>
            /// Property for Segment5Offset 
            /// </summary>
            public const string Segment5Offset = "OFFSET5";

            /// <summary>
            /// Property for Segment5Length 
            /// </summary>
            public const string Segment5Length = "LENGTH5";

            /// <summary>
            /// Property for ValidateSegment5 
            /// </summary>
            public const string ValidateSegment5 = "VALIDATE5";

            /// <summary>
            /// Property for SegmentSeparator5 
            /// </summary>
            public const string SegmentSeparator5 = "DELIM5";

            /// <summary>
            /// Property for Segment6 
            /// </summary>
            public const string Segment6 = "SEGMENT6";

            /// <summary>
            /// Property for Segment6Offset 
            /// </summary>
            public const string Segment6Offset = "OFFSET6";

            /// <summary>
            /// Property for Segment6Length 
            /// </summary>
            public const string Segment6Length = "LENGTH6";

            /// <summary>
            /// Property for ValidateSegment6 
            /// </summary>
            public const string ValidateSegment6 = "VALIDATE6";

            /// <summary>
            /// Property for SegmentSeparator6 
            /// </summary>
            public const string SegmentSeparator6 = "DELIM6";

            /// <summary>
            /// Property for Segment7 
            /// </summary>
            public const string Segment7 = "SEGMENT7";

            /// <summary>
            /// Property for Segment7Offset 
            /// </summary>
            public const string Segment7Offset = "OFFSET7";

            /// <summary>
            /// Property for Segment7Length 
            /// </summary>
            public const string Segment7Length = "LENGTH7";

            /// <summary>
            /// Property for ValidateSegment7 
            /// </summary>
            public const string ValidateSegment7 = "VALIDATE7";

            /// <summary>
            /// Property for SegmentSeparator7 
            /// </summary>
            public const string SegmentSeparator7 = "DELIM7";

            /// <summary>
            /// Property for Segment8 
            /// </summary>
            public const string Segment8 = "SEGMENT8";

            /// <summary>
            /// Property for Segment8Offset 
            /// </summary>
            public const string Segment8Offset = "OFFSET8";

            /// <summary>
            /// Property for Segment8Length 
            /// </summary>
            public const string Segment8Length = "LENGTH8";

            /// <summary>
            /// Property for ValidateSegment8 
            /// </summary>
            public const string ValidateSegment8 = "VALIDATE8";

            /// <summary>
            /// Property for SegmentSeparator8 
            /// </summary>
            public const string SegmentSeparator8 = "DELIM8";

            /// <summary>
            /// Property for Segment9 
            /// </summary>
            public const string Segment9 = "SEGMENT9";

            /// <summary>
            /// Property for Segment9Offset 
            /// </summary>
            public const string Segment9Offset = "OFFSET9";

            /// <summary>
            /// Property for Segment9Length 
            /// </summary>
            public const string Segment9Length = "LENGTH9";

            /// <summary>
            /// Property for ValidateSegment9 
            /// </summary>
            public const string ValidateSegment9 = "VALIDATE9";

            /// <summary>
            /// Property for SegmentSeparator9 
            /// </summary>
            public const string SegmentSeparator9 = "DELIM9";

            /// <summary>
            /// Property for Segment10 
            /// </summary>
            public const string Segment10 = "SEGMENT10";

            /// <summary>
            /// Property for Segment10Offset 
            /// </summary>
            public const string Segment10Offset = "OFFSET10";

            /// <summary>
            /// Property for Segment10Length 
            /// </summary>
            public const string Segment10Length = "LENGTH10";

            /// <summary>
            /// Property for ValidateSegment10 
            /// </summary>
            public const string ValidateSegment10 = "VALIDATE10";

            /// <summary>
            /// Property for SegmentSeparator10 
            /// </summary>
            public const string SegmentSeparator10 = "DELIM10";

            /// <summary>
            /// Property for PrefixEnumValue 
            /// </summary>
            public const string PrefixEnumValue = "DELIM0";

            /// <summary>
            /// Property for SegmentSeparator1EnumValue 
            /// </summary>
            public const string SegmentSeparator1EnumValue = "DELIM1";

            /// <summary>
            /// Property for SegmentSeparator2EnumValue 
            /// </summary>
            public const string SegmentSeparator2EnumValue = "DELIM2";

            /// <summary>
            /// Property for SegmentSeparator3EnumValue 
            /// </summary>
            public const string SegmentSeparator3EnumValue = "DELIM3";

            /// <summary>
            /// Property for SegmentSeparator4EnumValue 
            /// </summary>
            public const string SegmentSeparator4EnumValue = "DELIM4";

            /// <summary>
            /// Property for SegmentSeparator5EnumValue 
            /// </summary>
            public const string SegmentSeparator5EnumValue = "DELIM5";

            /// <summary>
            /// Property for SegmentSeparator6EnumValue 
            /// </summary>
            public const string SegmentSeparator6EnumValue = "DELIM6";

            /// <summary>
            /// Property for SegmentSeparator7EnumValue 
            /// </summary>
            public const string SegmentSeparator7EnumValue = "DELIM7";

            /// <summary>
            /// Property for SegmentSeparator8EnumValue 
            /// </summary>
            public const string SegmentSeparator8EnumValue = "DELIM8";

            /// <summary>
            /// Property for SegmentSeparator9EnumValue 
            /// </summary>
            public const string SegmentSeparator9EnumValue = "DELIM9";

            /// <summary>
            /// Property for SegmentSeparator10EnumValue 
            /// </summary>
            public const string SegmentSeparator10EnumValue = "DELIM10";

            #endregion
        }

        /// <summary>
        /// Contains list of ItemStructures Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for StructureCode 
            /// </summary>
            public const int StructureCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Prefix 
            /// </summary>
            public const int Prefix = 3;

            /// <summary>
            /// Property Indexer for Segment1 
            /// </summary>
            public const int Segment1 = 4;

            /// <summary>
            /// Property Indexer for Segment1Offset 
            /// </summary>
            public const int Segment1Offset = 5;

            /// <summary>
            /// Property Indexer for Segment1Length 
            /// </summary>
            public const int Segment1Length = 6;

            /// <summary>
            /// Property Indexer for ValidateSegment1 
            /// </summary>
            public const int ValidateSegment1 = 7;

            /// <summary>
            /// Property Indexer for SegmentSeparator1 
            /// </summary>
            public const int SegmentSeparator1 = 8;

            /// <summary>
            /// Property Indexer for Segment2 
            /// </summary>
            public const int Segment2 = 9;

            /// <summary>
            /// Property Indexer for Segment2Offset 
            /// </summary>
            public const int Segment2Offset = 10;

            /// <summary>
            /// Property Indexer for Segment2Length 
            /// </summary>
            public const int Segment2Length = 11;

            /// <summary>
            /// Property Indexer for ValidateSegment2 
            /// </summary>
            public const int ValidateSegment2 = 12;

            /// <summary>
            /// Property Indexer for SegmentSeparator2 
            /// </summary>
            public const int SegmentSeparator2 = 13;

            /// <summary>
            /// Property Indexer for Segment3 
            /// </summary>
            public const int Segment3 = 14;

            /// <summary>
            /// Property Indexer for Segment3Offset 
            /// </summary>
            public const int Segment3Offset = 15;

            /// <summary>
            /// Property Indexer for Segment3Length 
            /// </summary>
            public const int Segment3Length = 16;

            /// <summary>
            /// Property Indexer for ValidateSegment3 
            /// </summary>
            public const int ValidateSegment3 = 17;

            /// <summary>
            /// Property Indexer for SegmentSeparator3 
            /// </summary>
            public const int SegmentSeparator3 = 18;

            /// <summary>
            /// Property Indexer for Segment4 
            /// </summary>
            public const int Segment4 = 19;

            /// <summary>
            /// Property Indexer for Segment4Offset 
            /// </summary>
            public const int Segment4Offset = 20;

            /// <summary>
            /// Property Indexer for Segment4Length 
            /// </summary>
            public const int Segment4Length = 21;

            /// <summary>
            /// Property Indexer for ValidateSegment4 
            /// </summary>
            public const int ValidateSegment4 = 22;

            /// <summary>
            /// Property Indexer for SegmentSeparator4 
            /// </summary>
            public const int SegmentSeparator4 = 23;

            /// <summary>
            /// Property Indexer for Segment5 
            /// </summary>
            public const int Segment5 = 24;

            /// <summary>
            /// Property Indexer for Segment5Offset 
            /// </summary>
            public const int Segment5Offset = 25;

            /// <summary>
            /// Property Indexer for Segment5Length 
            /// </summary>
            public const int Segment5Length = 26;

            /// <summary>
            /// Property Indexer for ValidateSegment5 
            /// </summary>
            public const int ValidateSegment5 = 27;

            /// <summary>
            /// Property Indexer for SegmentSeparator5 
            /// </summary>
            public const int SegmentSeparator5 = 28;

            /// <summary>
            /// Property Indexer for Segment6 
            /// </summary>
            public const int Segment6 = 29;

            /// <summary>
            /// Property Indexer for Segment6Offset 
            /// </summary>
            public const int Segment6Offset = 30;

            /// <summary>
            /// Property Indexer for Segment6Length 
            /// </summary>
            public const int Segment6Length = 31;

            /// <summary>
            /// Property Indexer for ValidateSegment6 
            /// </summary>
            public const int ValidateSegment6 = 32;

            /// <summary>
            /// Property Indexer for SegmentSeparator6 
            /// </summary>
            public const int SegmentSeparator6 = 33;

            /// <summary>
            /// Property Indexer for Segment7 
            /// </summary>
            public const int Segment7 = 34;

            /// <summary>
            /// Property Indexer for Segment7Offset 
            /// </summary>
            public const int Segment7Offset = 35;

            /// <summary>
            /// Property Indexer for Segment7Length 
            /// </summary>
            public const int Segment7Length = 36;

            /// <summary>
            /// Property Indexer for ValidateSegment7 
            /// </summary>
            public const int ValidateSegment7 = 37;

            /// <summary>
            /// Property Indexer for SegmentSeparator7 
            /// </summary>
            public const int SegmentSeparator7 = 38;

            /// <summary>
            /// Property Indexer for Segment8 
            /// </summary>
            public const int Segment8 = 39;

            /// <summary>
            /// Property Indexer for Segment8Offset 
            /// </summary>
            public const int Segment8Offset = 40;

            /// <summary>
            /// Property Indexer for Segment8Length 
            /// </summary>
            public const int Segment8Length = 41;

            /// <summary>
            /// Property Indexer for ValidateSegment8 
            /// </summary>
            public const int ValidateSegment8 = 42;

            /// <summary>
            /// Property Indexer for SegmentSeparator8 
            /// </summary>
            public const int SegmentSeparator8 = 43;

            /// <summary>
            /// Property Indexer for Segment9 
            /// </summary>
            public const int Segment9 = 44;

            /// <summary>
            /// Property Indexer for Segment9Offset 
            /// </summary>
            public const int Segment9Offset = 45;

            /// <summary>
            /// Property Indexer for Segment9Length 
            /// </summary>
            public const int Segment9Length = 46;

            /// <summary>
            /// Property Indexer for ValidateSegment9 
            /// </summary>
            public const int ValidateSegment9 = 47;

            /// <summary>
            /// Property Indexer for SegmentSeparator9 
            /// </summary>
            public const int SegmentSeparator9 = 48;

            /// <summary>
            /// Property Indexer for Segment10 
            /// </summary>
            public const int Segment10 = 49;

            /// <summary>
            /// Property Indexer for Segment10Offset 
            /// </summary>
            public const int Segment10Offset = 50;

            /// <summary>
            /// Property Indexer for Segment10Length 
            /// </summary>
            public const int Segment10Length = 51;

            /// <summary>
            /// Property Indexer for ValidateSegment10 
            /// </summary>
            public const int ValidateSegment10 = 52;

            /// <summary>
            /// Property Indexer for SegmentSeparator10 
            /// </summary>
            public const int SegmentSeparator10 = 53;

            #endregion
        }
    }
}