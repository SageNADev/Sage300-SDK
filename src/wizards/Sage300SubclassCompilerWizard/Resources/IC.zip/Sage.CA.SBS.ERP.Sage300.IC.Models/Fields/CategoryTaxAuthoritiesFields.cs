/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CategoryTaxAuthorities Constants 
    /// </summary>
	public partial class CategoryTaxAuthority 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0220";

        /// <summary>
        /// Contains list of CategoryTaxAuthorities Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for Category 
        /// </summary>
        public const string CategoryCode = "CATEGORY";
	            /// <summary>
        /// Property for TaxAuthority 
        /// </summary>
	    public const string TaxAuthority  = "AUTHORITY";
	            /// <summary>
        /// Property for PurchaseTaxClass 
        /// </summary>
	    public const string PurchaseTaxClass  = "PURCHTAXCL";
	            /// <summary>
        /// Property for SalesTaxClass 
        /// </summary>
	    public const string SalesTaxClass  = "SALESTAXCL";
	            /// <summary>
        /// Property for PurchaseTaxClassDescription 
        /// </summary>
	    public const string PurchaseTaxClassDescription  = "PURCHDESC";
	            /// <summary>
        /// Property for SalesTaxClassDescription 
        /// </summary>
	    public const string SalesTaxClassDescription  = "SALESDESC";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of CategoryTaxAuthorities Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for Category 
        /// </summary>
        public const int CategoryCode = 1;
	             /// <summary>
        /// Property Indexer for TaxAuthority 
        /// </summary>
	    public const int TaxAuthority  = 2;
	             /// <summary>
        /// Property Indexer for PurchaseTaxClass 
        /// </summary>
	    public const int PurchaseTaxClass  = 3;
	             /// <summary>
        /// Property Indexer for SalesTaxClass 
        /// </summary>
	    public const int SalesTaxClass  = 4;
	             /// <summary>
        /// Property Indexer for PurchaseTaxClassDescription 
        /// </summary>
	    public const int PurchaseTaxClassDescription  = 5;
	             /// <summary>
        /// Property Indexer for SalesTaxClassDescription 
        /// </summary>
	    public const int SalesTaxClassDescription  = 6;
	     
        #endregion
	    }

	
	}
}
	