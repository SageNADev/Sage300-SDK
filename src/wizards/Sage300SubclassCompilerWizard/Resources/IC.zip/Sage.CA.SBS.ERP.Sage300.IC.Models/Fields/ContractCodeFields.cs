// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of ContractCode Constants
    /// </summary>
    public partial class ContractCode
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0800";

        #endregion

        #region Contains list of ContractCode Field Constants

        /// <summary>
        /// Contains list of ContractCode Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for ContractNo
            /// </summary>
            public const string ContractNo = "CONTCODE";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "CONTDESC";

            /// <summary>
            /// Property for Days1
            /// </summary>
            public const string Days1 = "DAYS1";

            /// <summary>
            /// Property for EffectiveDays1
            /// </summary>
            public const string EffectiveDays1 = "EFFDAYS1";

            /// <summary>
            /// Property for LifetimeContract1
            /// </summary>
            public const string LifetimeContract1 = "LIFECONT1";

            /// <summary>
            /// Property for Description1
            /// </summary>
            public const string Description1 = "DESC1";

            /// <summary>
            /// Property for Days2
            /// </summary>
            public const string Days2 = "DAYS2";

            /// <summary>
            /// Property for EffectiveDays2
            /// </summary>
            public const string EffectiveDays2 = "EFFDAYS2";

            /// <summary>
            /// Property for LifetimeContract2
            /// </summary>
            public const string LifetimeContract2 = "LIFECONT2";

            /// <summary>
            /// Property for Description2
            /// </summary>
            public const string Description2 = "DESC2";

            /// <summary>
            /// Property for Days3
            /// </summary>
            public const string Days3 = "DAYS3";

            /// <summary>
            /// Property for EffectiveDays3
            /// </summary>
            public const string EffectiveDays3 = "EFFDAYS3";

            /// <summary>
            /// Property for LifetimeContract3
            /// </summary>
            public const string LifetimeContract3 = "LIFECONT3";

            /// <summary>
            /// Property for Description3
            /// </summary>
            public const string Description3 = "DESC3";

            /// <summary>
            /// Property for Days4
            /// </summary>
            public const string Days4 = "DAYS4";

            /// <summary>
            /// Property for EffectiveDays4
            /// </summary>
            public const string EffectiveDays4 = "EFFDAYS4";

            /// <summary>
            /// Property for LifetimeContract4
            /// </summary>
            public const string LifetimeContract4 = "LIFECONT4";

            /// <summary>
            /// Property for Description4
            /// </summary>
            public const string Description4 = "DESC4";

            /// <summary>
            /// Property for Days5
            /// </summary>
            public const string Days5 = "DAYS5";

            /// <summary>
            /// Property for EffectiveDays5
            /// </summary>
            public const string EffectiveDays5 = "EFFDAYS5";

            /// <summary>
            /// Property for LifetimeContract5
            /// </summary>
            public const string LifetimeContract5 = "LIFECONT5";

            /// <summary>
            /// Property for Description5
            /// </summary>
            public const string Description5 = "DESC5";

        }

        #endregion

        #region Contains list of ContractCode Index Constants

        /// <summary>
        /// Contains list of ContractCode Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for ContractNo
            /// </summary>
            public const int ContractNo = 1;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Days1
            /// </summary>
            public const int Days1 = 3;

            /// <summary>
            /// Property Indexer for EffectiveDays1
            /// </summary>
            public const int EffectiveDays1 = 4;

            /// <summary>
            /// Property Indexer for LifetimeContract1
            /// </summary>
            public const int LifetimeContract1 = 5;

            /// <summary>
            /// Property Indexer for Description1
            /// </summary>
            public const int Description1 = 6;

            /// <summary>
            /// Property Indexer for Days2
            /// </summary>
            public const int Days2 = 7;

            /// <summary>
            /// Property Indexer for EffectiveDays2
            /// </summary>
            public const int EffectiveDays2 = 8;

            /// <summary>
            /// Property Indexer for LifetimeContract2
            /// </summary>
            public const int LifetimeContract2 = 9;

            /// <summary>
            /// Property Indexer for Description2
            /// </summary>
            public const int Description2 = 10;

            /// <summary>
            /// Property Indexer for Days3
            /// </summary>
            public const int Days3 = 11;

            /// <summary>
            /// Property Indexer for EffectiveDays3
            /// </summary>
            public const int EffectiveDays3 = 12;

            /// <summary>
            /// Property Indexer for LifetimeContract3
            /// </summary>
            public const int LifetimeContract3 = 13;

            /// <summary>
            /// Property Indexer for Description3
            /// </summary>
            public const int Description3 = 14;

            /// <summary>
            /// Property Indexer for Days4
            /// </summary>
            public const int Days4 = 15;

            /// <summary>
            /// Property Indexer for EffectiveDays4
            /// </summary>
            public const int EffectiveDays4 = 16;

            /// <summary>
            /// Property Indexer for LifetimeContract4
            /// </summary>
            public const int LifetimeContract4 = 17;

            /// <summary>
            /// Property Indexer for Description4
            /// </summary>
            public const int Description4 = 18;

            /// <summary>
            /// Property Indexer for Days5
            /// </summary>
            public const int Days5 = 19;

            /// <summary>
            /// Property Indexer for EffectiveDays5
            /// </summary>
            public const int EffectiveDays5 = 20;

            /// <summary>
            /// Property Indexer for LifetimeContract5
            /// </summary>
            public const int LifetimeContract5 = 21;

            /// <summary>
            /// Property Indexer for Description5
            /// </summary>
            public const int Description5 = 22;

        }

        #endregion
    }
}
