// Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class OptimizeInventory
    {
        public const string ViewName = "IC0307";
        public const string EntityName = ViewName;

        public static class Fields
        {
            public const string RunId = "RUNID";
            public const string Comment = "TEXTCMNT";
            public const string FromItemNumber = "FROMITEMNO";
            public const string ToItemNumber = "TOITEMNO";
            public const string FromCategory = "FROMCATG";
            public const string ToCategory = "TOCATG";
            public const string FromAccountSet = "FROMCTLACC";
            public const string ToAccountSet = "TOCTLACC";
            public const string FromVendorNumber = "FROMVENDNO";
            public const string ToVendorNumber = "TOVENDNO";
            public const string Year = "YEAR";
            public const string Period = "PERIOD";
            public const string Location = "LOCATION";
            public const string SalesPeriods = "SALESPRD";
        }

        public static class Index
        {
            public const int RunId = 1;
            public const int Comment = 2;
            public const int FromItemNumber = 3;
            public const int ToItemNumber = 4;
            public const int FromCategory = 5;
            public const int ToCategory = 6;
            public const int FromAccountSet = 7;
            public const int ToAccountSet = 8;
            public const int FromVendorNumber = 9;
            public const int ToVendorNumber = 10;
            public const int Year = 11;
            public const int Period = 12;
            public const int Location = 13;
            public const int SalesPeriods = 14;
        }
    }
}
