// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of FiscalCalendar Constants
     /// </summary>
     public partial class FiscalCalendar
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "CS0002";

          #region Properties
          /// <summary>
          /// Contains list of FiscalCalendar Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for FiscalYear
               /// </summary>
               public const string FiscalYear = "FSCYEAR";

               /// <summary>
               /// Property for NumberOfFiscalPeriods
               /// </summary>
               public const string NumberOfFiscalPeriods = "PERIODS";

               /// <summary>
               /// Property for Quarterwith4Periods
               /// </summary>
               public const string Quarterwith4Periods = "QTR4PERD";

               /// <summary>
               /// Property for Active
               /// </summary>
               public const string Active = "ACTIVE";

               /// <summary>
               /// Property for FiscalPeriod1StartDate
               /// </summary>
               public const string FiscalPeriod1StartDate = "BGNDATE1";

               /// <summary>
               /// Property for FiscalPeriod2StartDate
               /// </summary>
               public const string FiscalPeriod2StartDate = "BGNDATE2";

               /// <summary>
               /// Property for FiscalPeriod3StartDate
               /// </summary>
               public const string FiscalPeriod3StartDate = "BGNDATE3";

               /// <summary>
               /// Property for FiscalPeriod4StartDate
               /// </summary>
               public const string FiscalPeriod4StartDate = "BGNDATE4";

               /// <summary>
               /// Property for FiscalPeriod5StartDate
               /// </summary>
               public const string FiscalPeriod5StartDate = "BGNDATE5";

               /// <summary>
               /// Property for FiscalPeriod6StartDate
               /// </summary>
               public const string FiscalPeriod6StartDate = "BGNDATE6";

               /// <summary>
               /// Property for FiscalPeriod7StartDate
               /// </summary>
               public const string FiscalPeriod7StartDate = "BGNDATE7";

               /// <summary>
               /// Property for FiscalPeriod8StartDate
               /// </summary>
               public const string FiscalPeriod8StartDate = "BGNDATE8";

               /// <summary>
               /// Property for FiscalPeriod9StartDate
               /// </summary>
               public const string FiscalPeriod9StartDate = "BGNDATE9";

               /// <summary>
               /// Property for FiscalPeriod10StartDate
               /// </summary>
               public const string FiscalPeriod10StartDate = "BGNDATE10";

               /// <summary>
               /// Property for FiscalPeriod11StartDate
               /// </summary>
               public const string FiscalPeriod11StartDate = "BGNDATE11";

               /// <summary>
               /// Property for FiscalPeriod12StartDate
               /// </summary>
               public const string FiscalPeriod12StartDate = "BGNDATE12";

               /// <summary>
               /// Property for FiscalPeriod13StartDate
               /// </summary>
               public const string FiscalPeriod13StartDate = "BGNDATE13";

               /// <summary>
               /// Property for FiscalPeriod1EndDate
               /// </summary>
               public const string FiscalPeriod1EndDate = "ENDDATE1";

               /// <summary>
               /// Property for FiscalPeriod2EndDate
               /// </summary>
               public const string FiscalPeriod2EndDate = "ENDDATE2";

               /// <summary>
               /// Property for FiscalPeriod3EndDate
               /// </summary>
               public const string FiscalPeriod3EndDate = "ENDDATE3";

               /// <summary>
               /// Property for FiscalPeriod4EndDate
               /// </summary>
               public const string FiscalPeriod4EndDate = "ENDDATE4";

               /// <summary>
               /// Property for FiscalPeriod5EndDate
               /// </summary>
               public const string FiscalPeriod5EndDate = "ENDDATE5";

               /// <summary>
               /// Property for FiscalPeriod6EndDate
               /// </summary>
               public const string FiscalPeriod6EndDate = "ENDDATE6";

               /// <summary>
               /// Property for FiscalPeriod7EndDate
               /// </summary>
               public const string FiscalPeriod7EndDate = "ENDDATE7";

               /// <summary>
               /// Property for FiscalPeriod8EndDate
               /// </summary>
               public const string FiscalPeriod8EndDate = "ENDDATE8";

               /// <summary>
               /// Property for FiscalPeriod9EndDate
               /// </summary>
               public const string FiscalPeriod9EndDate = "ENDDATE9";

               /// <summary>
               /// Property for FiscalPeriod10EndDate
               /// </summary>
               public const string FiscalPeriod10EndDate = "ENDDATE10";

               /// <summary>
               /// Property for FiscalPeriod11EndDate
               /// </summary>
               public const string FiscalPeriod11EndDate = "ENDDATE11";

               /// <summary>
               /// Property for FiscalPeriod12EndDate
               /// </summary>
               public const string FiscalPeriod12EndDate = "ENDDATE12";

               /// <summary>
               /// Property for FiscalPeriod13EndDate
               /// </summary>
               public const string FiscalPeriod13EndDate = "ENDDATE13";

               /// <summary>
               /// Property for AdjustmentPeriodStatus
               /// </summary>
               public const string AdjustmentPeriodStatus = "STATUSADJ";

               /// <summary>
               /// Property for ClosingPeriodStatus
               /// </summary>
               public const string ClosingPeriodStatus = "STATUSCLS";

               /// <summary>
               /// Property for Command
               /// </summary>
               public const string Command = "PROCESSCMD";

               /// <summary>
               /// Property for Application
               /// </summary>
               public const string Application = "GOTPGM";

               /// <summary>
               /// Property for Open
               /// </summary>
               public const string Open = "PGMDESC";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of FiscalCalendar Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for FiscalYear
               /// </summary>
               public const int FiscalYear = 1;

               /// <summary>
               /// Property Indexer for NumberOfFiscalPeriods
               /// </summary>
               public const int NumberOfFiscalPeriods = 2;

               /// <summary>
               /// Property Indexer for Quarterwith4Periods
               /// </summary>
               public const int Quarterwith4Periods = 3;

               /// <summary>
               /// Property Indexer for Active
               /// </summary>
               public const int Active = 4;

               /// <summary>
               /// Property Indexer for FiscalPeriod1StartDate
               /// </summary>
               public const int FiscalPeriod1StartDate = 5;

               /// <summary>
               /// Property Indexer for FiscalPeriod2StartDate
               /// </summary>
               public const int FiscalPeriod2StartDate = 6;

               /// <summary>
               /// Property Indexer for FiscalPeriod3StartDate
               /// </summary>
               public const int FiscalPeriod3StartDate = 7;

               /// <summary>
               /// Property Indexer for FiscalPeriod4StartDate
               /// </summary>
               public const int FiscalPeriod4StartDate = 8;

               /// <summary>
               /// Property Indexer for FiscalPeriod5StartDate
               /// </summary>
               public const int FiscalPeriod5StartDate = 9;

               /// <summary>
               /// Property Indexer for FiscalPeriod6StartDate
               /// </summary>
               public const int FiscalPeriod6StartDate = 10;

               /// <summary>
               /// Property Indexer for FiscalPeriod7StartDate
               /// </summary>
               public const int FiscalPeriod7StartDate = 11;

               /// <summary>
               /// Property Indexer for FiscalPeriod8StartDate
               /// </summary>
               public const int FiscalPeriod8StartDate = 12;

               /// <summary>
               /// Property Indexer for FiscalPeriod9StartDate
               /// </summary>
               public const int FiscalPeriod9StartDate = 13;

               /// <summary>
               /// Property Indexer for FiscalPeriod10StartDate
               /// </summary>
               public const int FiscalPeriod10StartDate = 14;

               /// <summary>
               /// Property Indexer for FiscalPeriod11StartDate
               /// </summary>
               public const int FiscalPeriod11StartDate = 15;

               /// <summary>
               /// Property Indexer for FiscalPeriod12StartDate
               /// </summary>
               public const int FiscalPeriod12StartDate = 16;

               /// <summary>
               /// Property Indexer for FiscalPeriod13StartDate
               /// </summary>
               public const int FiscalPeriod13StartDate = 17;

               /// <summary>
               /// Property Indexer for FiscalPeriod1EndDate
               /// </summary>
               public const int FiscalPeriod1EndDate = 18;

               /// <summary>
               /// Property Indexer for FiscalPeriod2EndDate
               /// </summary>
               public const int FiscalPeriod2EndDate = 19;

               /// <summary>
               /// Property Indexer for FiscalPeriod3EndDate
               /// </summary>
               public const int FiscalPeriod3EndDate = 20;

               /// <summary>
               /// Property Indexer for FiscalPeriod4EndDate
               /// </summary>
               public const int FiscalPeriod4EndDate = 21;

               /// <summary>
               /// Property Indexer for FiscalPeriod5EndDate
               /// </summary>
               public const int FiscalPeriod5EndDate = 22;

               /// <summary>
               /// Property Indexer for FiscalPeriod6EndDate
               /// </summary>
               public const int FiscalPeriod6EndDate = 23;

               /// <summary>
               /// Property Indexer for FiscalPeriod7EndDate
               /// </summary>
               public const int FiscalPeriod7EndDate = 24;

               /// <summary>
               /// Property Indexer for FiscalPeriod8EndDate
               /// </summary>
               public const int FiscalPeriod8EndDate = 25;

               /// <summary>
               /// Property Indexer for FiscalPeriod9EndDate
               /// </summary>
               public const int FiscalPeriod9EndDate = 26;

               /// <summary>
               /// Property Indexer for FiscalPeriod10EndDate
               /// </summary>
               public const int FiscalPeriod10EndDate = 27;

               /// <summary>
               /// Property Indexer for FiscalPeriod11EndDate
               /// </summary>
               public const int FiscalPeriod11EndDate = 28;

               /// <summary>
               /// Property Indexer for FiscalPeriod12EndDate
               /// </summary>
               public const int FiscalPeriod12EndDate = 29;

               /// <summary>
               /// Property Indexer for FiscalPeriod13EndDate
               /// </summary>
               public const int FiscalPeriod13EndDate = 30;

               /// <summary>
               /// Property Indexer for AdjustmentPeriodStatus
               /// </summary>
               public const int AdjustmentPeriodStatus = 31;

               /// <summary>
               /// Property Indexer for ClosingPeriodStatus
               /// </summary>
               public const int ClosingPeriodStatus = 32;

               /// <summary>
               /// Property Indexer for Command
               /// </summary>
               public const int Command = 60;

               /// <summary>
               /// Property Indexer for Application
               /// </summary>
               public const int Application = 61;

               /// <summary>
               /// Property Indexer for Open
               /// </summary>
               public const int Open = 62;

          }
          #endregion

     }
}
