// Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class OptimizeInventoryDetail
    {
        public const string ViewName = "IC0306";
        public const string EntityName = ViewName;

        public static class Fields
        {
            public const string RunId = "RUNID"; public const string ItemNumber = "ITEMNO"; public const string Location = "LOCATION";
            public const string FormattedItemNumber = "FMTITEMNO"; public const string Description = "DESC"; public const string Category = "CATEGORY"; public const string AccountSet = "CNTLACCT"; public const string StockingUnit = "STOCKUNIT";
            public const string MostRecentCost = "RECENTCOST"; public const string Seasonal = "SEASONAL"; public const string VendorNumber = "VENDNUM"; public const string VendorName = "VENDNAME"; public const string VendorItemNumber = "VENDITEM"; public const string VendorCost = "VENDCOST";
            public const string MinimumOrderQuantity = "QTYMINORD"; public const string QuantityOnHand = "QTYONHAND"; public const string QuantityOnPurchaseOrder = "QTYONORDER"; public const string QuantityOnSalesOrder = "QTYSALORDR"; public const string QuantityAvailable = "QTYAVAIL"; public const string UnitsShipped = "UNITSSHIP"; public const string LastReceiptDate = "LASTRCPTDT"; public const string LeadTime = "LEADTIME"; public const string MinimumRequiredQuantity = "QTYMINREQ";
            public const string SalesPeriod01 = "SALESPD01"; public const string SalesPeriod02 = "SALESPD02"; public const string SalesPeriod03 = "SALESPD03"; public const string SalesPeriod04 = "SALESPD04"; public const string SalesPeriod05 = "SALESPD05"; public const string SalesPeriod06 = "SALESPD06"; public const string SalesPeriod07 = "SALESPD07"; public const string SalesPeriod08 = "SALESPD08"; public const string SalesPeriod09 = "SALESPD09"; public const string SalesPeriod10 = "SALESPD10"; public const string SalesPeriod11 = "SALESPD11"; public const string SalesPeriod12 = "SALESPD12"; public const string SalesPeriod13 = "SALESPD13";
            public const string WeightedAverageSales = "WGTAVGSALE"; public const string SalesTrend = "TRENDUPDN"; public const string CurrentMinimumLevel = "CURMINLVL"; public const string CurrentMaximumLevel = "CURMAXLVL"; public const string CalculatedMinimumLevel = "CALMINLVL"; public const string CalculatedMaximumLevel = "CALMAXLVL"; public const string AdjustedMinimumLevel = "ADJMINLVL"; public const string AdjustedMaximumLevel = "ADJMAXLVL";
            public const string QuantityAvailableValue = "TOTALCOST"; public const string CurrentMinimumValue = "CURVALMIN"; public const string CurrentMaximumValue = "CURVALMAX"; public const string AdjustedMinimumValue = "CALVALMIN"; public const string AdjustedMaximumValue = "CALVALMAX"; public const string MinimumValueVariance = "VALVALMIN"; public const string MaximumValueVariance = "VALVALMAX"; public const string Update = "UPDATE";
        }

        public static class Index
        {
            public const int RunId = 1; public const int ItemNumber = 2; public const int Location = 3;
            public const int FormattedItemNumber = 4; public const int Description = 5; public const int Category = 6; public const int AccountSet = 7; public const int StockingUnit = 8;
            public const int MostRecentCost = 9; public const int Seasonal = 10; public const int VendorNumber = 11; public const int VendorName = 12; public const int VendorItemNumber = 13; public const int VendorCost = 14;
            public const int MinimumOrderQuantity = 15; public const int QuantityOnHand = 16; public const int QuantityOnPurchaseOrder = 17; public const int QuantityOnSalesOrder = 18; public const int QuantityAvailable = 19; public const int UnitsShipped = 20; public const int LastReceiptDate = 21; public const int LeadTime = 22; public const int MinimumRequiredQuantity = 23;
            public const int SalesPeriod01 = 24; public const int SalesPeriod02 = 25; public const int SalesPeriod03 = 26; public const int SalesPeriod04 = 27; public const int SalesPeriod05 = 28; public const int SalesPeriod06 = 29; public const int SalesPeriod07 = 30; public const int SalesPeriod08 = 31; public const int SalesPeriod09 = 32; public const int SalesPeriod10 = 33; public const int SalesPeriod11 = 34; public const int SalesPeriod12 = 35; public const int SalesPeriod13 = 36;
            public const int WeightedAverageSales = 37; public const int SalesTrend = 38; public const int CurrentMinimumLevel = 39; public const int CurrentMaximumLevel = 40; public const int CalculatedMinimumLevel = 41; public const int CalculatedMaximumLevel = 42; public const int AdjustedMinimumLevel = 43; public const int AdjustedMaximumLevel = 44;
            public const int QuantityAvailableValue = 45; public const int CurrentMinimumValue = 46; public const int CurrentMaximumValue = 47; public const int AdjustedMinimumValue = 48; public const int AdjustedMaximumValue = 49; public const int MinimumValueVariance = 50; public const int MaximumValueVariance = 51; public const int Update = 52;
        }
    }
}
