// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of SalesStatistic Constants
    /// </summary>
    public partial class SalesStatistic
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "IC0710";

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of SalesStatistic Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "YEAR";

            /// <summary>
            /// Property for Period
            /// </summary>
            public const string Period = "PERIOD";

            /// <summary>
            /// Property for SalesAmount
            /// </summary>
            public const string SalesAmount = "SALESAMT";

            /// <summary>
            /// Property for SalesCount
            /// </summary>
            public const string SalesCount = "SALESCOUNT";

            /// <summary>
            /// Property for SalesQuantity
            /// </summary>
            public const string SalesQuantity = "SALESQTY";

            /// <summary>
            /// Property for CostOfGoodsSold
            /// </summary>
            public const string CostOfGoodsSold = "COGS";

            /// <summary>
            /// Property for SalesReturnAmount
            /// </summary>
            public const string SalesReturnAmount = "SALERTNAMT";

            /// <summary>
            /// Property for SalesReturnCount
            /// </summary>
            public const string SalesReturnCount = "SALERTNCNT";

            /// <summary>
            /// Property for SalesReturnQuantity
            /// </summary>
            public const string SalesReturnQuantity = "SALERTNQTY";

            /// <summary>
            /// Property for CostOfGoodsReturned
            /// </summary>
            public const string CostOfGoodsReturned = "COGSRTN";

            /// <summary>
            /// Property for GrossMargin
            /// </summary>
            public const string GrossMargin = "MARGIN";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for LocationDescription
            /// </summary>
            public const string LocationDescription = "LOCDESC";

            /// <summary>
            /// Property for StockingUnitOfMeasure
            /// </summary>
            public const string StockingUnitOfMeasure = "STOCKUNIT";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of SalesStatistic Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 1;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 2;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 3;

            /// <summary>
            /// Property Indexer for Period
            /// </summary>
            public const int Period = 4;

            /// <summary>
            /// Property Indexer for SalesAmount
            /// </summary>
            public const int SalesAmount = 6;

            /// <summary>
            /// Property Indexer for SalesCount
            /// </summary>
            public const int SalesCount = 7;

            /// <summary>
            /// Property Indexer for SalesQuantity
            /// </summary>
            public const int SalesQuantity = 8;

            /// <summary>
            /// Property Indexer for CostOfGoodsSold
            /// </summary>
            public const int CostOfGoodsSold = 9;

            /// <summary>
            /// Property Indexer for SalesReturnAmount
            /// </summary>
            public const int SalesReturnAmount = 10;

            /// <summary>
            /// Property Indexer for SalesReturnCount
            /// </summary>
            public const int SalesReturnCount = 11;

            /// <summary>
            /// Property Indexer for SalesReturnQuantity
            /// </summary>
            public const int SalesReturnQuantity = 12;

            /// <summary>
            /// Property Indexer for CostOfGoodsReturned
            /// </summary>
            public const int CostOfGoodsReturned = 13;

            /// <summary>
            /// Property Indexer for GrossMargin
            /// </summary>
            public const int GrossMargin = 22;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 23;

            /// <summary>
            /// Property Indexer for LocationDescription
            /// </summary>
            public const int LocationDescription = 24;

            /// <summary>
            /// Property Indexer for StockingUnitOfMeasure
            /// </summary>
            public const int StockingUnitOfMeasure = 25;
        }

        #endregion
    }
}