// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{

     /// <summary>
     /// Contains list of InventoryWorksheet Constants
     /// </summary>
     public partial class InventoryWorksheet
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0770";

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheet Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for WorksheetStatus
               /// </summary>
               public const string WorksheetStatus = "POSTTYPE";

               /// <summary>
               /// Property for DateCreated
               /// </summary>
               public const string DateCreated = "DATE";

               /// <summary>
               /// Property for Name
               /// </summary>
               public const string Name = "DESC";

               /// <summary>
               /// Property for WorksheetComment
               /// </summary>
               public const string WorksheetComment = "COMMENT";

               /// <summary>
               /// Property for SortOrder
               /// </summary>
               public const string SortOrder = "SORTBY";

               /// <summary>
               /// Property for SortOrderDescription
               /// </summary>
               public const string SortOrderDescription = "SORTBYDESC";

               /// <summary>
               /// Property for SegmentNumber
               /// </summary>
               public const string SegmentNumber = "SEGMENT";

               /// <summary>
               /// Property for SegmentDescription
               /// </summary>
               public const string SegmentDescription = "SEGDESC";

               /// <summary>
               /// Property for FromCode
               /// </summary>
               public const string FromCode = "FROMCODE";

               /// <summary>
               /// Property for ToCode
               /// </summary>
               public const string ToCode = "TOCODE";

               /// <summary>
               /// Property for FromAccountSetCode
               /// </summary>
               public const string FromAccountSetCode = "FRCNTLACCT";

               /// <summary>
               /// Property for ToAccountSetCode
               /// </summary>
               public const string ToAccountSetCode = "TOCNTLACCT";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for ProcessAction
               /// </summary>
               public const string ProcessAction = "PROCACTION";

               /// <summary>
               /// Property for ProcessCommand
               /// </summary>
               public const string ProcessCommand = "PROCESSCMD";

               /// <summary>
               /// Property for OptionalField
               /// </summary>
               public const string OptionalField = "OPTFIELD";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheet Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for WorksheetStatus
               /// </summary>
               public const int WorksheetStatus = 2;

               /// <summary>
               /// Property Indexer for DateCreated
               /// </summary>
               public const int DateCreated = 3;

               /// <summary>
               /// Property Indexer for Name
               /// </summary>
               public const int Name = 4;

               /// <summary>
               /// Property Indexer for WorksheetComment
               /// </summary>
               public const int WorksheetComment = 5;

               /// <summary>
               /// Property Indexer for SortOrder
               /// </summary>
               public const int SortOrder = 6;

               /// <summary>
               /// Property Indexer for SortOrderDescription
               /// </summary>
               public const int SortOrderDescription = 7;

               /// <summary>
               /// Property Indexer for SegmentNumber
               /// </summary>
               public const int SegmentNumber = 8;

               /// <summary>
               /// Property Indexer for SegmentDescription
               /// </summary>
               public const int SegmentDescription = 9;

               /// <summary>
               /// Property Indexer for FromCode
               /// </summary>
               public const int FromCode = 10;

               /// <summary>
               /// Property Indexer for ToCode
               /// </summary>
               public const int ToCode = 11;

               /// <summary>
               /// Property Indexer for FromAccountSetCode
               /// </summary>
               public const int FromAccountSetCode = 12;

               /// <summary>
               /// Property Indexer for ToAccountSetCode
               /// </summary>
               public const int ToAccountSetCode = 13;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 14;

               /// <summary>
               /// Property Indexer for ProcessAction
               /// </summary>
               public const int ProcessAction = 31;

               /// <summary>
               /// Property Indexer for ProcessCommand
               /// </summary>
               public const int ProcessCommand = 32;

               /// <summary>
               /// Property Indexer for OptionalField
               /// </summary>
               public const int OptionalField = 33;

          }
          #endregion

     }
}
