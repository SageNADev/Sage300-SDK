// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of RecallReleaseHeader Constants
    /// </summary>
    public partial class LotRecallReleaseHeader
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0822";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get { return new Dictionary<string, string>(); }
        }

        #region Properties

        /// <summary>
        /// Contains list of LotRecallReleaseHeader Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for LotNumber
            /// </summary>
            public const string LotNumber = "LOTNUM";

            /// <summary>
            /// Property for EntryType
            /// </summary>
            public const string EntryType = "TRANSTYPE";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for RecallNumber
            /// </summary>
            public const string RecallNumber = "RECALLNUM";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for NextDetailLineNumber
            /// </summary>
            public const string NextDetailLineNumber = "NEXTDTLNUM";

            /// <summary>
            /// Property for RecordPrinted
            /// </summary>
            public const string RecordPrinted = "PRINTED";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of LotRecallReleaseHeader Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 2;

            /// <summary>
            /// Property Indexer for LotNumber
            /// </summary>
            public const int LotNumber = 3;

            /// <summary>
            /// Property Indexer for EntryType
            /// </summary>
            public const int EntryType = 4;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 5;

            /// <summary>
            /// Property Indexer for RecallNumber
            /// </summary>
            public const int RecallNumber = 6;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 7;

            /// <summary>
            /// Property Indexer for NextDetailLineNumber
            /// </summary>
            public const int NextDetailLineNumber = 8;

            /// <summary>
            /// Property Indexer for RecordPrinted
            /// </summary>
            public const int RecordPrinted = 9;

        }

        #endregion

    }
}
