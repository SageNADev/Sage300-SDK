// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ContractPricing Constants 
    /// </summary>
    public partial class ContractPricing
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0274";

        /// <summary>
        /// Contains list of ContractPricing Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Customer Number 
            /// </summary>
            public const string CustomerNumber = "CUSTNO";

            /// <summary>
            /// Property for Price By 
            /// </summary>
            public const string PriceBy = "PRICEBY";

            /// <summary>
            /// Property for Category Code 
            /// </summary>
            public const string CategoryCode = "CATEGORY";

            /// <summary>
            /// Property for Item Number 
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Price List 
            /// </summary>
            public const string PriceList = "PRICELIST";

            /// <summary>
            /// Property for Expiration Date 
            /// </summary>
            public const string ExpirationDate = "EXPIRE";

            /// <summary>
            /// Property for Price Type 
            /// </summary>
            public const string PriceType = "PRICETYPE";

            /// <summary>
            /// Property for Customer Type 
            /// </summary>
            public const string CustomerType = "CUSTTYPE";

            /// <summary>
            /// Property for Discount Percentage 
            /// </summary>
            public const string DiscountPercentage = "DISCPER";

            /// <summary>
            /// Property for Discount Amount 
            /// </summary>
            public const string DiscountAmount = "DISCAMT";

            /// <summary>
            /// Property for Costing Method 
            /// </summary>
            public const string CostingMethod = "COSTMETHOD";

            /// <summary>
            /// Property for Plus Amount 
            /// </summary>
            public const string PlusAmount = "PLUSAMT";

            /// <summary>
            /// Property for Plus Percentage 
            /// </summary>
            public const string PlusPercentage = "PLUSPER";

            /// <summary>
            /// Property for Fixed Price 
            /// </summary>
            public const string FixedPrice = "FIXPRICE";

            /// <summary>
            /// Property for Start Date 
            /// </summary>
            public const string StartDate = "STARTDATE";

            /// <summary>
            /// Property for Use Lowest Price 
            /// </summary>
            public const string UseLowestPrice = "USELOWEST";

            /// <summary>
            /// Property for Calculated Unit Price 
            /// </summary>
            public const string CalculatedUnitPrice = "CALCPRICE";

            /// <summary>
            /// Property for Calculated Price Decimals 
            /// </summary>
            public const string CalculatedPriceDecimals = "CALCDECS";

            /// <summary>
            /// Property for Formatted Item Number 
            /// </summary>
            public const string FormattedItemNumber = "FMTITEMNO";

            /// <summary>
            /// Property for Customer Name 
            /// </summary>
            public const string CustomerName = "CUSTDESC";

            /// <summary>
            /// Property for Category Description 
            /// </summary>
            public const string CategoryDescription = "CATDESC";

            /// <summary>
            /// Property for Item Description 
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for Price List Description 
            /// </summary>
            public const string PriceListDescription = "PRLSTDESC";

            /// <summary>
            /// Property for Currency Code 
            /// </summary>
            public const string CurrencyCode = "CURRDESC";

            /// <summary>
            /// Property for Price Unit Description 
            /// </summary>
            public const string PriceUnitDescription = "PRUNTDESC";

            /// <summary>
            /// Property for Location 
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Calculated Unit Price Is Valid 
            /// </summary>
            public const string CalculatedUnitPriceIsValid = "CALCVALID";

            /// <summary>
            /// Property for Pricing Price By 
            /// </summary>
            public const string PricingPriceBy = "PRICPRICBY";

            /// <summary>
            /// Property for Check Item Existence 
            /// </summary>
            public const string CheckItemExistence = "CHECKITEM";

            #endregion
        }


        /// <summary>
        /// Contains list of ContractPricing Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for Customer Number 
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for Price By 
            /// </summary>
            public const int PriceBy = 2;

            /// <summary>
            /// Property Indexer for Category Code 
            /// </summary>
            public const int CategoryCode = 3;

            /// <summary>
            /// Property Indexer for Item Number 
            /// </summary>
            public const int ItemNumber = 4;

            /// <summary>
            /// Property Indexer for Price List 
            /// </summary>
            public const int PriceList = 5;

            /// <summary>
            /// Property Indexer for Expiration Date 
            /// </summary>
            public const int ExpirationDate = 6;

            /// <summary>
            /// Property Indexer for Price Type 
            /// </summary>
            public const int PriceType = 7;

            /// <summary>
            /// Property Indexer for Customer Type 
            /// </summary>
            public const int CustomerType = 8;

            /// <summary>
            /// Property Indexer for Discount Percentage 
            /// </summary>
            public const int DiscountPercentage = 9;

            /// <summary>
            /// Property Indexer for Discount Amount 
            /// </summary>
            public const int DiscountAmount = 10;

            /// <summary>
            /// Property Indexer for Costing Method 
            /// </summary>
            public const int CostingMethod = 11;

            /// <summary>
            /// Property Indexer for Plus Amount 
            /// </summary>
            public const int PlusAmount = 12;

            /// <summary>
            /// Property Indexer for Plus Percentage 
            /// </summary>
            public const int PlusPercentage = 13;

            /// <summary>
            /// Property Indexer for Fixed Price 
            /// </summary>
            public const int FixedPrice = 14;

            /// <summary>
            /// Property Indexer for Start Date 
            /// </summary>
            public const int StartDate = 15;

            /// <summary>
            /// Property Indexer for Use Lowest Price 
            /// </summary>
            public const int UseLowestPrice = 16;

            /// <summary>
            /// Property Indexer for Calculated Unit Price 
            /// </summary>
            public const int CalculatedUnitPrice = 50;

            /// <summary>
            /// Property Indexer for Calculated Price Decimals 
            /// </summary>
            public const int CalculatedPriceDecimals = 51;

            /// <summary>
            /// Property Indexer for Formatted Item Number 
            /// </summary>
            public const int FormattedItemNumber = 52;

            /// <summary>
            /// Property Indexer for Customer Name 
            /// </summary>
            public const int CustomerName = 53;

            /// <summary>
            /// Property Indexer for Category Description 
            /// </summary>
            public const int CategoryDescription = 54;

            /// <summary>
            /// Property Indexer for Item Description 
            /// </summary>
            public const int ItemDescription = 55;

            /// <summary>
            /// Property Indexer for Price List Description 
            /// </summary>
            public const int PriceListDescription = 56;

            /// <summary>
            /// Property Indexer for Currency Code 
            /// </summary>
            public const int CurrencyCode = 57;

            /// <summary>
            /// Property Indexer for Price Unit Description 
            /// </summary>
            public const int PriceUnitDescription = 58;

            /// <summary>
            /// Property Indexer for Location 
            /// </summary>
            public const int Location = 59;

            /// <summary>
            /// Property Indexer for Calculated Unit Price is Valid 
            /// </summary>
            public const int CalculatedUnitPriceIsValid = 60;

            /// <summary>
            /// Property Indexer for Pricing Price By 
            /// </summary>
            public const int PricingPriceBy = 61;

            /// <summary>
            /// Property Indexer for Check Item Existence 
            /// </summary>
            public const int CheckItemExistence = 62;

            #endregion
        }

        /// <summary>
        /// Keys for Order By - Used in Customer Inquiry Screen.
        /// </summary>
        public class Keys
        {
            public const int PriceBy = 0;
        }

    }
}
