// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of ICDrillDownDriver Constants
	/// </summary>
	public partial class ICDrillDownDriver
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0273";

		#region Properties

		/// <summary>
		/// Contains list of ICDrillDownDriver Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for DrilldownApplicationCode
			/// </summary>
			public const string DrilldownApplicationCode = "DRILLAPP";

			/// <summary>
			/// Property for DrilldownTransactionType
			/// </summary>
			public const string DrilldownTransactionType = "SRCETYPE";

			/// <summary>
			/// Property for DrilldownLink
			/// </summary>
			public const string DrilldownLink = "DRILLDWNLK";

			/// <summary>
			/// Property for DrilldownType
			/// </summary>
			public const string DrilldownType = "DRILLTYPE";

			/// <summary>
			/// Property for RotoIDOfUIobject
			/// </summary>
			public const string RotoIDOfUIobject = "ROTOID";

			/// <summary>
			/// Property for Parameters
			/// </summary>
			public const string Parameters = "PARAMETERS";

			/// <summary>
			/// Property for DocumentKey
			/// </summary>
			public const string DocumentKey = "DRILLKEY";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ICDrillDownDriver Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for DrilldownApplicationCode
			/// </summary>
			public const int DrilldownApplicationCode = 1;

			/// <summary>
			/// Property Indexer for DrilldownTransactionType
			/// </summary>
			public const int DrilldownTransactionType = 2;

			/// <summary>
			/// Property Indexer for DrilldownLink
			/// </summary>
			public const int DrilldownLink = 3;

			/// <summary>
			/// Property Indexer for DrilldownType
			/// </summary>
			public const int DrilldownType = 4;

			/// <summary>
			/// Property Indexer for RotoIDOfUIobject
			/// </summary>
			public const int RotoIDOfUIobject = 5;

			/// <summary>
			/// Property Indexer for Parameters
			/// </summary>
			public const int Parameters = 6;

			/// <summary>
			/// Property Indexer for DocumentKey
			/// </summary>
			public const int DocumentKey = 7;

		}

		#endregion

	}
}
