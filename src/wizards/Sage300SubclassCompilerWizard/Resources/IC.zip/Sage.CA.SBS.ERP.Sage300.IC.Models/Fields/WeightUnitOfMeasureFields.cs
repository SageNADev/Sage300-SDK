﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A class for WeightUnitsofMeasure Constants 
    /// </summary>
    public partial class WeightUnitOfMeasure
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0758";

        /// <summary>
        /// Contains list of WeightUnitsofMeasure Fields Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for WeightUnitofMeasure 
            /// </summary>
            public const string WeightUnitsOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "WUOMDESC";

            /// <summary>
            /// Property for WeightConversionFactor 
            /// </summary>
            public const string WeightConversionFactor = "CONVERSION";

            /// <summary>
            /// Property for DefaultWeightUnitofMeasure 
            /// </summary>
            public const string DefaultWeightUnitOfMeasure = "DEFAULT";

            /// <summary>
            /// Property for Num10000inDefWeightUOMEquals 
            /// </summary>
            public const string NumInDefWeightUomEquals = "WGHTCNVDEF";
        }

        /// <summary>
        /// Contains list of WeightUnitsofMeasure Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for WeightUnitofMeasure 
            /// </summary>
            public const int WeightUnitsOfMeasure = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for WeightConversionFactor 
            /// </summary>
            public const int WeightConversionFactor = 3;

            /// <summary>
            /// Property Indexer for DefaultWeightUnitofMeasure 
            /// </summary>
            public const int DefaultWeightUnitOfMeasure = 30;

            /// <summary>
            /// Property Indexer for Num10000inDefWeightUOMEquals 
            /// </summary>
            public const int NumInDefWeightUomEquals = 31;
        }
    }
}