// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of SplitCombineDetail Constants
	/// </summary>
	public partial class SplitCombineDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0845";

		#region Properties

		/// <summary>
		/// Contains list of SplitCombineDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "SEQUENCENO";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENO";

			/// <summary>
			/// Property for LotNumber
			/// </summary>
			public const string LotNumber = "LOTNUMF";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "UOM";

			/// <summary>
			/// Property for QuantityShippable
			/// </summary>
			public const string QuantityShippable = "QTYAVAIL";

			/// <summary>
			/// Property for Quantity
			/// </summary>
			public const string Quantity = "QUANTITY";

			/// <summary>
			/// Property for DetailLineNumber
			/// </summary>
			public const string DetailLineNumber = "DETAILNUM";

			/// <summary>
			/// Property for ExpiryDate
			/// </summary>
			public const string ExpiryDate = "EXPIRYDATE";

			/// <summary>
			/// Property for StockDate
			/// </summary>
			public const string StockDate = "STOCKDATE";

			/// <summary>
			/// Property for DetailCount
			/// </summary>
			public const string DetailCount = "DTLCOUNT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of SplitCombineDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 2;

			/// <summary>
			/// Property Indexer for LotNumber
			/// </summary>
			public const int LotNumber = 3;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 4;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 5;

			/// <summary>
			/// Property Indexer for QuantityShippable
			/// </summary>
			public const int QuantityShippable = 6;

			/// <summary>
			/// Property Indexer for Quantity
			/// </summary>
			public const int Quantity = 7;

			/// <summary>
			/// Property Indexer for DetailLineNumber
			/// </summary>
			public const int DetailLineNumber = 8;

			/// <summary>
			/// Property Indexer for ExpiryDate
			/// </summary>
			public const int ExpiryDate = 9;

			/// <summary>
			/// Property Indexer for StockDate
			/// </summary>
			public const int StockDate = 10;

			/// <summary>
			/// Property Indexer for DetailCount
			/// </summary>
			public const int DetailCount = 30;

		}

		#endregion

	}
}
