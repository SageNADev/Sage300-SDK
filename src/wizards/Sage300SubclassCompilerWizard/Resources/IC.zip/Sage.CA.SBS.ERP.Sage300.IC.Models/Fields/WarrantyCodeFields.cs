// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of WarrantyCode Constants
	/// </summary>
	public partial class WarrantyCode
    {
        #region Constants

        /// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "IC0850";

        #endregion

        #region Contains list of WarrantyCode Field Constants

        /// <summary>
		/// Contains list of WarrantyCode Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for WarrantyCode
			/// </summary>
			public const string Warranty = "WARRCODE";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "WARRDESC";

			/// <summary>
			/// Property for Period1Days
			/// </summary>
			public const string Period1Days = "DAYS1";

			/// <summary>
			/// Property for Period1EffectiveDays
			/// </summary>
			public const string Period1EffectiveDays = "EFFDAYS1";

			/// <summary>
			/// Property for Period1IsLifetime
			/// </summary>
			public const string Period1IsLifetime = "LIFEWARR1";

			/// <summary>
			/// Property for Period1Description
			/// </summary>
			public const string Period1Description = "DESC1";

			/// <summary>
			/// Property for Period2Days
			/// </summary>
			public const string Period2Days = "DAYS2";

			/// <summary>
			/// Property for Period2EffectiveDays
			/// </summary>
			public const string Period2EffectiveDays = "EFFDAYS2";

			/// <summary>
			/// Property for Period2IsLifetime
			/// </summary>
			public const string Period2IsLifetime = "LIFEWARR2";

			/// <summary>
			/// Property for Period2Description
			/// </summary>
			public const string Period2Description = "DESC2";

			/// <summary>
			/// Property for Period3Days
			/// </summary>
			public const string Period3Days = "DAYS3";

			/// <summary>
			/// Property for Period3EffectiveDays
			/// </summary>
			public const string Period3EffectiveDays = "EFFDAYS3";

			/// <summary>
			/// Property for Period3IsLifetime
			/// </summary>
			public const string Period3IsLifetime = "LIFEWARR3";

			/// <summary>
			/// Property for Period3Description
			/// </summary>
			public const string Period3Description = "DESC3";

			/// <summary>
			/// Property for Period4Days
			/// </summary>
			public const string Period4Days = "DAYS4";

			/// <summary>
			/// Property for Period4EffectiveDays
			/// </summary>
			public const string Period4EffectiveDays = "EFFDAYS4";

			/// <summary>
			/// Property for Period4IsLifetime
			/// </summary>
			public const string Period4IsLifetime = "LIFEWARR4";

			/// <summary>
			/// Property for Period4Description
			/// </summary>
			public const string Period4Description = "DESC4";

			/// <summary>
			/// Property for Period5Days
			/// </summary>
			public const string Period5Days = "DAYS5";

			/// <summary>
			/// Property for Period5EffectiveDays
			/// </summary>
			public const string Period5EffectiveDays = "EFFDAYS5";

			/// <summary>
			/// Property for Period5IsLifetime
			/// </summary>
			public const string Period5IsLifetime = "LIFEWARR5";

			/// <summary>
			/// Property for Period5Description
			/// </summary>
			public const string Period5Description = "DESC5";

		}

		#endregion

        #region Contains list of WarrantyCode Index Constants

        /// <summary>
		/// Contains list of WarrantyCode Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for WarrantyCode
			/// </summary>
			public const int Warranty = 1;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 2;

			/// <summary>
			/// Property Indexer for Period1Days
			/// </summary>
			public const int Period1Days = 3;

			/// <summary>
			/// Property Indexer for Period1EffectiveDays
			/// </summary>
			public const int Period1EffectiveDays = 4;

			/// <summary>
			/// Property Indexer for Period1IsLifetime
			/// </summary>
			public const int Period1IsLifetime = 5;

			/// <summary>
			/// Property Indexer for Period1Description
			/// </summary>
			public const int Period1Description = 6;

			/// <summary>
			/// Property Indexer for Period2Days
			/// </summary>
			public const int Period2Days = 7;

			/// <summary>
			/// Property Indexer for Period2EffectiveDays
			/// </summary>
			public const int Period2EffectiveDays = 8;

			/// <summary>
			/// Property Indexer for Period2IsLifetime
			/// </summary>
			public const int Period2IsLifetime = 9;

			/// <summary>
			/// Property Indexer for Period2Description
			/// </summary>
			public const int Period2Description = 10;

			/// <summary>
			/// Property Indexer for Period3Days
			/// </summary>
			public const int Period3Days = 11;

			/// <summary>
			/// Property Indexer for Period3EffectiveDays
			/// </summary>
			public const int Period3EffectiveDays = 12;

			/// <summary>
			/// Property Indexer for Period3IsLifetime
			/// </summary>
			public const int Period3IsLifetime = 13;

			/// <summary>
			/// Property Indexer for Period3Description
			/// </summary>
			public const int Period3Description = 14;

			/// <summary>
			/// Property Indexer for Period4Days
			/// </summary>
			public const int Period4Days = 15;

			/// <summary>
			/// Property Indexer for Period4EffectiveDays
			/// </summary>
			public const int Period4EffectiveDays = 16;

			/// <summary>
			/// Property Indexer for Period4IsLifetime
			/// </summary>
			public const int Period4IsLifetime = 17;

			/// <summary>
			/// Property Indexer for Period4Description
			/// </summary>
			public const int Period4Description = 18;

			/// <summary>
			/// Property Indexer for Period5Days
			/// </summary>
			public const int Period5Days = 19;

			/// <summary>
			/// Property Indexer for Period5EffectiveDays
			/// </summary>
			public const int Period5EffectiveDays = 20;

			/// <summary>
			/// Property Indexer for Period5IsLifetime
			/// </summary>
			public const int Period5IsLifetime = 21;

			/// <summary>
			/// Property Indexer for Period5Description
			/// </summary>
			public const int Period5Description = 22;

		}

		#endregion

	}
}
