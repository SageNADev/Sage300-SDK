/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Locations Constants 
    /// </summary>
	public partial class Locations 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0370";

        /// <summary>
        /// Contains list of Locations Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for Location 
        /// </summary>
	    public const string Location  = "LOCATION";
	            /// <summary>
        /// Property for Name 
        /// </summary>
	    public const string Name  = "DESC";
	            /// <summary>
        /// Property for AddressLine1 
        /// </summary>
	    public const string AddressLine1  = "ADDRESS1";
	            /// <summary>
        /// Property for AddressLine2 
        /// </summary>
	    public const string AddressLine2  = "ADDRESS2";
	            /// <summary>
        /// Property for AddressLine3 
        /// </summary>
	    public const string AddressLine3  = "ADDRESS3";
	            /// <summary>
        /// Property for AddressLine4 
        /// </summary>
	    public const string AddressLine4  = "ADDRESS4";
	            /// <summary>
        /// Property for City 
        /// </summary>
	    public const string City  = "CITY";
	            /// <summary>
        /// Property for State 
        /// </summary>
	    public const string State  = "STATE";
	            /// <summary>
        /// Property for ZipOrPostalCode 
        /// </summary>
	    public const string ZipOrPostalCode  = "ZIP";
	            /// <summary>
        /// Property for Country 
        /// </summary>
	    public const string Country  = "COUNTRY";
	            /// <summary>
        /// Property for PhoneNumber 
        /// </summary>
	    public const string PhoneNumber  = "PHONE";
	            /// <summary>
        /// Property for FaxNumber 
        /// </summary>
	    public const string FaxNumber  = "FAX";
	            /// <summary>
        /// Property for Contact 
        /// </summary>
	    public const string Contact  = "CONTACT";
	            /// <summary>
        /// Property for SegmentOverride 
        /// </summary>
	    public const string SegmentOverride  = "SEGOVERRD";
	            /// <summary>
        /// Property for DateLastMaintained 
        /// </summary>
	    public const string DateLastMaintained  = "DATELASTMN";
	            /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "INACTIVE";
	            /// <summary>
        /// Property for DateInactive 
        /// </summary>
	    public const string DateInactive  = "DATEINACTV";
	            /// <summary>
        /// Property for SegmentNumber1 
        /// </summary>
	    public const string SegmentNumber1  = "SEGNUM1";
	            /// <summary>
        /// Property for SegmentValue1 
        /// </summary>
	    public const string SegmentValue1  = "SEGVAL1";
	            /// <summary>
        /// Property for SegmentNumber2 
        /// </summary>
	    public const string SegmentNumber2  = "SEGNUM2";
	            /// <summary>
        /// Property for SegmentValue2 
        /// </summary>
	    public const string SegmentValue2  = "SEGVAL2";
	            /// <summary>
        /// Property for SegmentNumber3 
        /// </summary>
	    public const string SegmentNumber3  = "SEGNUM3";
	            /// <summary>
        /// Property for SegmentValue3 
        /// </summary>
	    public const string SegmentValue3  = "SEGVAL3";
	            /// <summary>
        /// Property for SegmentNumber4 
        /// </summary>
	    public const string SegmentNumber4  = "SEGNUM4";
	            /// <summary>
        /// Property for SegmentValue4 
        /// </summary>
	    public const string SegmentValue4  = "SEGVAL4";
	            /// <summary>
        /// Property for SegmentNumber5 
        /// </summary>
	    public const string SegmentNumber5  = "SEGNUM5";
	            /// <summary>
        /// Property for SegmentValue5 
        /// </summary>
	    public const string SegmentValue5  = "SEGVAL5";
	            /// <summary>
        /// Property for SegmentNumber6 
        /// </summary>
	    public const string SegmentNumber6  = "SEGNUM6";
	            /// <summary>
        /// Property for SegmentValue6 
        /// </summary>
	    public const string SegmentValue6  = "SEGVAL6";
	            /// <summary>
        /// Property for SegmentNumber7 
        /// </summary>
	    public const string SegmentNumber7  = "SEGNUM7";
	            /// <summary>
        /// Property for SegmentValue7 
        /// </summary>
	    public const string SegmentValue7  = "SEGVAL7";
	            /// <summary>
        /// Property for SegmentNumber8 
        /// </summary>
	    public const string SegmentNumber8  = "SEGNUM8";
	            /// <summary>
        /// Property for SegmentValue8 
        /// </summary>
	    public const string SegmentValue8  = "SEGVAL8";
	            /// <summary>
        /// Property for SegmentNumber9 
        /// </summary>
	    public const string SegmentNumber9  = "SEGNUM9";
	            /// <summary>
        /// Property for SegmentValue9 
        /// </summary>
	    public const string SegmentValue9  = "SEGVAL9";
	            /// <summary>
        /// Property for LocationEmail 
        /// </summary>
	    public const string LocationEmail  = "EMAIL";
	            /// <summary>
        /// Property for ContactPhone 
        /// </summary>
	    public const string ContactPhone  = "PHONEC";
	            /// <summary>
        /// Property for ContactFax 
        /// </summary>
	    public const string ContactFax  = "FAXC";
	            /// <summary>
        /// Property for ContactEmail 
        /// </summary>
	    public const string ContactEmail  = "EMAILC";
	            /// <summary>
        /// Property for LocationType 
        /// </summary>
	    public const string LocationType  = "LOCTYPE";
        /// <summary>
        /// Property for StatusDescription 
        /// </summary>
        public const string StatusDescription = "INACTIVE";
        /// <summary>
        /// Property for LocationTypeDescription 
        /// </summary>
        public const string LocationTypeDescription = "LOCTYPE";
        /// <summary>
        /// property for SegmentOverrideDescription
        /// </summary>
        public const string SegmentOverrideDescription = "SEGOVERRD";

        #endregion
	    }


		/// <summary>
        /// Contains list of Locations Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for Location 
        /// </summary>
	    public const int Location  = 1;
	             /// <summary>
        /// Property Indexer for Name 
        /// </summary>
	    public const int Name  = 2;
	             /// <summary>
        /// Property Indexer for AddressLine1 
        /// </summary>
	    public const int AddressLine1  = 3;
	             /// <summary>
        /// Property Indexer for AddressLine2 
        /// </summary>
	    public const int AddressLine2  = 4;
	             /// <summary>
        /// Property Indexer for AddressLine3 
        /// </summary>
	    public const int AddressLine3  = 5;
	             /// <summary>
        /// Property Indexer for AddressLine4 
        /// </summary>
	    public const int AddressLine4  = 6;
	             /// <summary>
        /// Property Indexer for City 
        /// </summary>
	    public const int City  = 7;
	             /// <summary>
        /// Property Indexer for State 
        /// </summary>
	    public const int State  = 8;
	             /// <summary>
        /// Property Indexer for ZipOrPostalCode 
        /// </summary>
	    public const int ZipOrPostalCode  = 9;
	             /// <summary>
        /// Property Indexer for Country 
        /// </summary>
	    public const int Country  = 10;
	             /// <summary>
        /// Property Indexer for PhoneNumber 
        /// </summary>
	    public const int PhoneNumber  = 11;
	             /// <summary>
        /// Property Indexer for FaxNumber 
        /// </summary>
	    public const int FaxNumber  = 12;
	             /// <summary>
        /// Property Indexer for Contact 
        /// </summary>
	    public const int Contact  = 13;
	             /// <summary>
        /// Property Indexer for SegmentOverride 
        /// </summary>
	    public const int SegmentOverride  = 14;
	             /// <summary>
        /// Property Indexer for DateLastMaintained 
        /// </summary>
	    public const int DateLastMaintained  = 15;
	             /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 16;
	             /// <summary>
        /// Property Indexer for DateInactive 
        /// </summary>
	    public const int DateInactive  = 17;
	             /// <summary>
        /// Property Indexer for SegmentNumber1 
        /// </summary>
	    public const int SegmentNumber1  = 18;
	             /// <summary>
        /// Property Indexer for SegmentValue1 
        /// </summary>
	    public const int SegmentValue1  = 19;
	             /// <summary>
        /// Property Indexer for SegmentNumber2 
        /// </summary>
	    public const int SegmentNumber2  = 20;
	             /// <summary>
        /// Property Indexer for SegmentValue2 
        /// </summary>
	    public const int SegmentValue2  = 21;
	             /// <summary>
        /// Property Indexer for SegmentNumber3 
        /// </summary>
	    public const int SegmentNumber3  = 22;
	             /// <summary>
        /// Property Indexer for SegmentValue3 
        /// </summary>
	    public const int SegmentValue3  = 23;
	             /// <summary>
        /// Property Indexer for SegmentNumber4 
        /// </summary>
	    public const int SegmentNumber4  = 24;
	             /// <summary>
        /// Property Indexer for SegmentValue4 
        /// </summary>
	    public const int SegmentValue4  = 25;
	             /// <summary>
        /// Property Indexer for SegmentNumber5 
        /// </summary>
	    public const int SegmentNumber5  = 26;
	             /// <summary>
        /// Property Indexer for SegmentValue5 
        /// </summary>
	    public const int SegmentValue5  = 27;
	             /// <summary>
        /// Property Indexer for SegmentNumber6 
        /// </summary>
	    public const int SegmentNumber6  = 28;
	             /// <summary>
        /// Property Indexer for SegmentValue6 
        /// </summary>
	    public const int SegmentValue6  = 29;
	             /// <summary>
        /// Property Indexer for SegmentNumber7 
        /// </summary>
	    public const int SegmentNumber7  = 30;
	             /// <summary>
        /// Property Indexer for SegmentValue7 
        /// </summary>
	    public const int SegmentValue7  = 31;
	             /// <summary>
        /// Property Indexer for SegmentNumber8 
        /// </summary>
	    public const int SegmentNumber8  = 32;
	             /// <summary>
        /// Property Indexer for SegmentValue8 
        /// </summary>
	    public const int SegmentValue8  = 33;
	             /// <summary>
        /// Property Indexer for SegmentNumber9 
        /// </summary>
	    public const int SegmentNumber9  = 34;
	             /// <summary>
        /// Property Indexer for SegmentValue9 
        /// </summary>
	    public const int SegmentValue9  = 35;
	             /// <summary>
        /// Property Indexer for LocationEmail 
        /// </summary>
	    public const int LocationEmail  = 36;
	             /// <summary>
        /// Property Indexer for ContactPhone 
        /// </summary>
	    public const int ContactPhone  = 37;
	             /// <summary>
        /// Property Indexer for ContactFax 
        /// </summary>
	    public const int ContactFax  = 38;
	             /// <summary>
        /// Property Indexer for ContactEmail 
        /// </summary>
	    public const int ContactEmail  = 39;
	             /// <summary>
        /// Property Indexer for LocationType 
        /// </summary>
	    public const int LocationType  = 40;
	     
        #endregion
	    }

	
	}
}
	