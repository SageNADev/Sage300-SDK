// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of InventorySerialNumber Constants
	/// </summary>
	public partial class InventorySerialNumber
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0830";

		#region Properties

		/// <summary>
		/// Contains list of InventorySerialNumber Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for UnformattedSerialNumber
			/// </summary>
			public const string UnformattedSerialNumber = "SERIALNUM";

			/// <summary>
			/// Property for UnformattedItemNumber
			/// </summary>
			public const string UnformattedItemNumber = "ITEMNUM";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for Status
			/// </summary>
			public const string Status = "STATUS";

			/// <summary>
			/// Property for StockDate
			/// </summary>
			public const string StockDate = "STOCKDATE";

			/// <summary>
			/// Property for ExpiryDate
			/// </summary>
			public const string ExpiryDate = "EXPIRYDATE";

			/// <summary>
			/// Property for SerialNumber
			/// </summary>
			public const string SerialNumber = "SERIALNUMF";

			/// <summary>
			/// Property for ReserveForOrder
			/// </summary>
			public const string ReserveForOrder = "RESVFORORD";

			/// <summary>
			/// Property for StockedForCosting
			/// </summary>
			public const string StockedForCosting = "ASSETSTOCK";

			/// <summary>
			/// Property for CostForCosting
			/// </summary>
			public const string CostForCosting = "ASSETCOST";

			/// <summary>
			/// Property for ContractCode
			/// </summary>
			public const string ContractCode = "CONTCODE";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for ContractPeriod1InUse
			/// </summary>
			public const string ContractPeriod1InUse = "INUSE1";

			/// <summary>
			/// Property for ContractPeriod1ExpiryDate
			/// </summary>
			public const string ContractPeriod1ExpiryDate = "DATE1";

			/// <summary>
			/// Property for ContractPeriod1EffectiveDate
			/// </summary>
			public const string ContractPeriod1EffectiveDate = "EFFDATE1";

			/// <summary>
			/// Property for ContractPeriod1Lifetime
			/// </summary>
			public const string ContractPeriod1Lifetime = "LIFECONT1";

			/// <summary>
			/// Property for ContractPeriod2InUse
			/// </summary>
			public const string ContractPeriod2InUse = "INUSE2";

			/// <summary>
			/// Property for ContractPeriod2ExpiryDate
			/// </summary>
			public const string ContractPeriod2ExpiryDate = "DATE2";

			/// <summary>
			/// Property for ContractPeriod2EffectiveDate
			/// </summary>
			public const string ContractPeriod2EffectiveDate = "EFFDATE2";

			/// <summary>
			/// Property for ContractPeriod2Lifetime
			/// </summary>
			public const string ContractPeriod2Lifetime = "LIFECONT2";

			/// <summary>
			/// Property for ContractPeriod3InUse
			/// </summary>
			public const string ContractPeriod3InUse = "INUSE3";

			/// <summary>
			/// Property for ContractPeriod3ExpiryDate
			/// </summary>
			public const string ContractPeriod3ExpiryDate = "DATE3";

			/// <summary>
			/// Property for ContractPeriod3EffectiveDate
			/// </summary>
			public const string ContractPeriod3EffectiveDate = "EFFDATE3";

			/// <summary>
			/// Property for ContractPeriod3Lifetime
			/// </summary>
			public const string ContractPeriod3Lifetime = "LIFECONT3";

			/// <summary>
			/// Property for ContractPeriod4InUse
			/// </summary>
			public const string ContractPeriod4InUse = "INUSE4";

			/// <summary>
			/// Property for ContractPeriod4ExpiryDate
			/// </summary>
			public const string ContractPeriod4ExpiryDate = "DATE4";

			/// <summary>
			/// Property for ContractPeriod4EffectiveDate
			/// </summary>
			public const string ContractPeriod4EffectiveDate = "EFFDATE4";

			/// <summary>
			/// Property for ContractPeriod4Lifetime
			/// </summary>
			public const string ContractPeriod4Lifetime = "LIFECONT4";

			/// <summary>
			/// Property for ContractPeriod5InUse
			/// </summary>
			public const string ContractPeriod5InUse = "INUSE5";

			/// <summary>
			/// Property for ContractPeriod5ExpiryDate
			/// </summary>
			public const string ContractPeriod5ExpiryDate = "DATE5";

			/// <summary>
			/// Property for ContractPeriod5EffectiveDate
			/// </summary>
			public const string ContractPeriod5EffectiveDate = "EFFDATE5";

			/// <summary>
			/// Property for ContractPeriod5Lifetime
			/// </summary>
			public const string ContractPeriod5Lifetime = "LIFECONT5";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "CONTDESC";

			/// <summary>
			/// Property for ContractPeriod1Description
			/// </summary>
			public const string ContractPeriod1Description = "DESC1";

			/// <summary>
			/// Property for ContractPeriod2Description
			/// </summary>
			public const string ContractPeriod2Description = "DESC2";

			/// <summary>
			/// Property for ContractPeriod3Description
			/// </summary>
			public const string ContractPeriod3Description = "DESC3";

			/// <summary>
			/// Property for ContractPeriod4Description
			/// </summary>
			public const string ContractPeriod4Description = "DESC4";

			/// <summary>
			/// Property for ContractPeriod5Description
			/// </summary>
			public const string ContractPeriod5Description = "DESC5";

			/// <summary>
			/// Property for UpdatedbyUI
			/// </summary>
			public const string UpdatedbyUI = "EDITFROMUI";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of InventorySerialNumber Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for UnformattedSerialNumber
			/// </summary>
			public const int UnformattedSerialNumber = 1;

			/// <summary>
			/// Property Indexer for UnformattedItemNumber
			/// </summary>
			public const int UnformattedItemNumber = 2;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 3;

			/// <summary>
			/// Property Indexer for Status
			/// </summary>
			public const int Status = 4;

			/// <summary>
			/// Property Indexer for StockDate
			/// </summary>
			public const int StockDate = 5;

			/// <summary>
			/// Property Indexer for ExpiryDate
			/// </summary>
			public const int ExpiryDate = 6;

			/// <summary>
			/// Property Indexer for SerialNumber
			/// </summary>
			public const int SerialNumber = 7;

			/// <summary>
			/// Property Indexer for ReserveForOrder
			/// </summary>
			public const int ReserveForOrder = 8;

			/// <summary>
			/// Property Indexer for StockedForCosting
			/// </summary>
			public const int StockedForCosting = 9;

			/// <summary>
			/// Property Indexer for CostForCosting
			/// </summary>
			public const int CostForCosting = 10;

			/// <summary>
			/// Property Indexer for ContractCode
			/// </summary>
			public const int ContractCode = 11;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 12;

			/// <summary>
			/// Property Indexer for ContractPeriod1InUse
			/// </summary>
			public const int ContractPeriod1InUse = 13;

			/// <summary>
			/// Property Indexer for ContractPeriod1ExpiryDate
			/// </summary>
			public const int ContractPeriod1ExpiryDate = 14;

			/// <summary>
			/// Property Indexer for ContractPeriod1EffectiveDate
			/// </summary>
			public const int ContractPeriod1EffectiveDate = 15;

			/// <summary>
			/// Property Indexer for ContractPeriod1Lifetime
			/// </summary>
			public const int ContractPeriod1Lifetime = 16;

			/// <summary>
			/// Property Indexer for ContractPeriod2InUse
			/// </summary>
			public const int ContractPeriod2InUse = 17;

			/// <summary>
			/// Property Indexer for ContractPeriod2ExpiryDate
			/// </summary>
			public const int ContractPeriod2ExpiryDate = 18;

			/// <summary>
			/// Property Indexer for ContractPeriod2EffectiveDate
			/// </summary>
			public const int ContractPeriod2EffectiveDate = 19;

			/// <summary>
			/// Property Indexer for ContractPeriod2Lifetime
			/// </summary>
			public const int ContractPeriod2Lifetime = 20;

			/// <summary>
			/// Property Indexer for ContractPeriod3InUse
			/// </summary>
			public const int ContractPeriod3InUse = 21;

			/// <summary>
			/// Property Indexer for ContractPeriod3ExpiryDate
			/// </summary>
			public const int ContractPeriod3ExpiryDate = 22;

			/// <summary>
			/// Property Indexer for ContractPeriod3EffectiveDate
			/// </summary>
			public const int ContractPeriod3EffectiveDate = 23;

			/// <summary>
			/// Property Indexer for ContractPeriod3Lifetime
			/// </summary>
			public const int ContractPeriod3Lifetime = 24;

			/// <summary>
			/// Property Indexer for ContractPeriod4InUse
			/// </summary>
			public const int ContractPeriod4InUse = 25;

			/// <summary>
			/// Property Indexer for ContractPeriod4ExpiryDate
			/// </summary>
			public const int ContractPeriod4ExpiryDate = 26;

			/// <summary>
			/// Property Indexer for ContractPeriod4EffectiveDate
			/// </summary>
			public const int ContractPeriod4EffectiveDate = 27;

			/// <summary>
			/// Property Indexer for ContractPeriod4Lifetime
			/// </summary>
			public const int ContractPeriod4Lifetime = 28;

			/// <summary>
			/// Property Indexer for ContractPeriod5InUse
			/// </summary>
			public const int ContractPeriod5InUse = 29;

			/// <summary>
			/// Property Indexer for ContractPeriod5ExpiryDate
			/// </summary>
			public const int ContractPeriod5ExpiryDate = 30;

			/// <summary>
			/// Property Indexer for ContractPeriod5EffectiveDate
			/// </summary>
			public const int ContractPeriod5EffectiveDate = 31;

			/// <summary>
			/// Property Indexer for ContractPeriod5Lifetime
			/// </summary>
			public const int ContractPeriod5Lifetime = 32;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 75;

			/// <summary>
			/// Property Indexer for ContractPeriod1Description
			/// </summary>
			public const int ContractPeriod1Description = 76;

			/// <summary>
			/// Property Indexer for ContractPeriod2Description
			/// </summary>
			public const int ContractPeriod2Description = 77;

			/// <summary>
			/// Property Indexer for ContractPeriod3Description
			/// </summary>
			public const int ContractPeriod3Description = 78;

			/// <summary>
			/// Property Indexer for ContractPeriod4Description
			/// </summary>
			public const int ContractPeriod4Description = 79;

			/// <summary>
			/// Property Indexer for ContractPeriod5Description
			/// </summary>
			public const int ContractPeriod5Description = 80;

			/// <summary>
			/// Property Indexer for UpdatedbyUI
			/// </summary>
			public const int UpdatedbyUI = 81;

		}

		#endregion

	}
}