// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of ReorderQuantityDetail Constants
	/// </summary>
	public partial class ReorderQuantityDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0600";

        /// <summary>
        /// Entity Name for Export/Import
        /// </summary>
        public const string EntityName = "IC0600";

		#region Properties

		/// <summary>
		/// Contains list of ReorderQuantitiesDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for PeriodStart
			/// </summary>
			public const string PeriodStart = "PERIODSTRT";

			/// <summary>
			/// Property for MinimumQuantity
			/// </summary>
			public const string MinimumQuantity = "MINLEVEL";

			/// <summary>
			/// Property for MaximumQuantity
			/// </summary>
			public const string MaximumQuantity = "MAXLEVEL";

			/// <summary>
			/// Property for ReorderQuantity
			/// </summary>
			public const string ReorderQuantity = "REORDERQTY";

			/// <summary>
			/// Property for ProjectedSalesQty
			/// </summary>
			public const string ProjectedSalesQty = "SALESPROJ";

			/// <summary>
			/// Property for PeriodEnd
			/// </summary>
			public const string PeriodEnd = "PERIODEND";

			/// <summary>
			/// Property for ReorderFor
			/// </summary>
			public const string ReorderFor = "ORDERFOR";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ReorderQuantitiesDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 1;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 2;

			/// <summary>
			/// Property Indexer for PeriodStart
			/// </summary>
			public const int PeriodStart = 3;

			/// <summary>
			/// Property Indexer for MinimumQuantity
			/// </summary>
			public const int MinimumQuantity = 4;

			/// <summary>
			/// Property Indexer for MaximumQuantity
			/// </summary>
			public const int MaximumQuantity = 5;

			/// <summary>
			/// Property Indexer for ReorderQuantity
			/// </summary>
			public const int ReorderQuantity = 6;

			/// <summary>
			/// Property Indexer for ProjectedSalesQty
			/// </summary>
			public const int ProjectedSalesQty = 7;

			/// <summary>
			/// Property Indexer for PeriodEnd
			/// </summary>
			public const int PeriodEnd = 8;

			/// <summary>
			/// Property Indexer for ReorderFor
			/// </summary>
			public const int ReorderFor = 9;

		}

		#endregion

	}
}
