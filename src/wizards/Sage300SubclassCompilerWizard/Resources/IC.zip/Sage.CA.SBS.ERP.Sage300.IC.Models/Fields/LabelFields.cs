// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of Label Constants
    /// </summary>
    public partial class Label
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0360";

        #region Properties
        /// <summary>
        /// Contains list of Label Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptNumber
            /// </summary>
            public const string ReceiptNumber = "RECPNUM";

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQNUM";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for NumberOfLabels
            /// </summary>
            public const string NumberOfLabels = "NUMLABELS";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "PRINTED";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of Label Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 1;

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 2;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 3;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 4;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 5;

            /// <summary>
            /// Property Indexer for NumberOfLabels
            /// </summary>
            public const int NumberOfLabels = 6;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 7;
        }
        #endregion
    }
}