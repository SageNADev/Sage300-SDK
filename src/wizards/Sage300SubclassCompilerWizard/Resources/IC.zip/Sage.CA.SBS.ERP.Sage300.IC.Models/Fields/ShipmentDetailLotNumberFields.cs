// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of ShipmentDetailLotNumber Constants
    /// </summary>
    public partial class ShipmentDetailLotNumber
    {
        #region Entity Name

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "IC0632";

        #endregion

        #region ShipmentDetailLotNumber Field Constants

        /// <summary>
        /// Contains list of ShipmentDetailLotNumber Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for LotNumber
            /// </summary>
            public const string LotNumber = "LOTNUMF";

            /// <summary>
            /// Property for ExpiryDate
            /// </summary>
            public const string ExpiryDate = "EXPIRYDATE";

            /// <summary>
            /// Property for TransactionQuantity
            /// </summary>
            public const string TransactionQuantity = "QTY";

            /// <summary>
            /// Property for LotQuantityInStockingUOM
            /// </summary>
            public const string LotQuantityInStockingUOM = "QTYSQ";
        }

        #endregion

        #region ShipmentDetailLotNumber Index Constants

        /// <summary>
        /// Contains list of ShipmentDetailLotNumber Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for LotNumber
            /// </summary>
            public const int LotNumber = 3;

            /// <summary>
            /// Property Indexer for ExpiryDate
            /// </summary>
            public const int ExpiryDate = 5;

            /// <summary>
            /// Property Indexer for TransactionQuantity
            /// </summary>
            public const int TransactionQuantity = 6;

            /// <summary>
            /// Property Indexer for LotQuantityInStockingUOM
            /// </summary>
            public const int LotQuantityInStockingUOM = 7;
        }

        #endregion
    }
}
