// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of ReceiptCost Constants
     /// </summary>
     public partial class ReceiptCost
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "IC0260";

          #region Properties
          /// <summary>
          /// Contains list of ReceiptCost Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for TransactionDate
               /// </summary>
               public const string TransactionDate = "TRANSDATE";

               /// <summary>
               /// Property for SequenceNumber
               /// </summary>
               public const string SequenceNumber = "SEQUENCE";

               /// <summary>
               /// Property for Reference
               /// </summary>
               public const string Reference = "REFERENCE";

               /// <summary>
               /// Property for DocumentNumber
               /// </summary>
               public const string DocumentNumber = "RECEIPTNUM";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "LINENUMBER";

               /// <summary>
               /// Property for OriginalQuantity
               /// </summary>
               public const string OriginalQuantity = "QTY";

               /// <summary>
               /// Property for OriginalCost
               /// </summary>
               public const string OriginalCost = "COST";

               /// <summary>
               /// Property for QuantityShipped
               /// </summary>
               public const string QuantityShipped = "SHIPQTY";

               /// <summary>
               /// Property for ShippedCost
               /// </summary>
               public const string ShippedCost = "SHIPCOST";

               /// <summary>
               /// Property for QuantityAvailable
               /// </summary>
               public const string QuantityAvailable = "AVAILQTY";

               /// <summary>
               /// Property for AvailableCost
               /// </summary>
               public const string AvailableCost = "AVAILCOST";

               /// <summary>
               /// Property for FormattedItemNumber
               /// </summary>
               public const string FormattedItemNumber = "FMTITEMNO";

               /// <summary>
               /// Property for AccountSetCode
               /// </summary>
               public const string AccountSetCode = "ACCTSET";

               /// <summary>
               /// Property for AccountSetDescription
               /// </summary>
               public const string AccountSetDescription = "ACCTDESC";

               /// <summary>
               /// Property for ItemDescription
               /// </summary>
               public const string ItemDescription = "ITEMDESC";

               /// <summary>
               /// Property for LocationDescription
               /// </summary>
               public const string LocationDescription = "LOCDESC";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of ReceiptCost Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 1;

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 2;

               /// <summary>
               /// Property Indexer for TransactionDate
               /// </summary>
               public const int TransactionDate = 3;

               /// <summary>
               /// Property Indexer for SequenceNumber
               /// </summary>
               public const int SequenceNumber = 4;

               /// <summary>
               /// Property Indexer for Reference
               /// </summary>
               public const int Reference = 5;

               /// <summary>
               /// Property Indexer for DocumentNumber
               /// </summary>
               public const int DocumentNumber = 6;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 7;

               /// <summary>
               /// Property Indexer for OriginalQuantity
               /// </summary>
               public const int OriginalQuantity = 8;

               /// <summary>
               /// Property Indexer for OriginalCost
               /// </summary>
               public const int OriginalCost = 9;

               /// <summary>
               /// Property Indexer for QuantityShipped
               /// </summary>
               public const int QuantityShipped = 10;

               /// <summary>
               /// Property Indexer for ShippedCost
               /// </summary>
               public const int ShippedCost = 11;

               /// <summary>
               /// Property Indexer for QuantityAvailable
               /// </summary>
               public const int QuantityAvailable = 20;

               /// <summary>
               /// Property Indexer for AvailableCost
               /// </summary>
               public const int AvailableCost = 21;

               /// <summary>
               /// Property Indexer for FormattedItemNumber
               /// </summary>
               public const int FormattedItemNumber = 22;

               /// <summary>
               /// Property Indexer for AccountSetCode
               /// </summary>
               public const int AccountSetCode = 23;

               /// <summary>
               /// Property Indexer for AccountSetDescription
               /// </summary>
               public const int AccountSetDescription = 24;

               /// <summary>
               /// Property Indexer for ItemDescription
               /// </summary>
               public const int ItemDescription = 25;

               /// <summary>
               /// Property Indexer for LocationDescription
               /// </summary>
               public const int LocationDescription = 26;

          }
          #endregion

     }
}
