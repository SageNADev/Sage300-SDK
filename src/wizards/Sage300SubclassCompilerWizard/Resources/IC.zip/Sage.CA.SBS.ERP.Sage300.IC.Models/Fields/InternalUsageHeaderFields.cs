// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of InternalUsageHeader Constants
    /// </summary>
    public partial class InternalUsageHeader
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0288";

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageHeader Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for TransactionNumber
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property for InternalUsageNumber
            /// </summary>
            public const string InternalUsageNumber = "DOCNUM";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "HDRDESC";

            /// <summary>
            /// Property for EntryType
            /// </summary>
            public const string EntryType = "TRANSTYPE";

            /// <summary>
            /// Property for InternalUsageDate
            /// </summary>
            public const string InternalUsageDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for ICUniqueDocumentNumber
            /// </summary>
            public const string ICUniqueDocumentNumber = "DOCUNIQ";

            /// <summary>
            /// Property for NextDetailLineNumber
            /// </summary>
            public const string NextDetailLineNumber = "NEXTDTLNUM";

            /// <summary>
            /// Property for RecordStatus
            /// </summary>
            public const string RecordStatus = "STATUS";

            /// <summary>
            /// Property for RecordDeleted
            /// </summary>
            public const string RecordDeleted = "DELETED";

            /// <summary>
            /// Property for RecordPrinted
            /// </summary>
            public const string RecordPrinted = "PRINTED";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for EmployeeNumber
            /// </summary>
            public const string EmployeeNumber = "EMPLOYEENO";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for PostSequenceNumber
            /// </summary>
            public const string PostSequenceNumber = "POSTSEQNUM";

            /// <summary>
            /// Property for IsCanadianPayrollActive
            /// </summary>
            public const string IsCanadianPayrollActive = "CPACTIVE";

            /// <summary>
            /// Property for IsUSPayrollActive
            /// </summary>
            public const string IsUSPayrollActive = "UPACTIVE";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageHeader Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for TransactionNumber
            /// </summary>
            public const int TransactionNumber = 2;

            /// <summary>
            /// Property Indexer for InternalUsageNumber
            /// </summary>
            public const int InternalUsageNumber = 3;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 4;

            /// <summary>
            /// Property Indexer for EntryType
            /// </summary>
            public const int EntryType = 5;

            /// <summary>
            /// Property Indexer for InternalUsageDate
            /// </summary>
            public const int InternalUsageDate = 6;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 7;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 8;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 9;

            /// <summary>
            /// Property Indexer for ICUniqueDocumentNumber
            /// </summary>
            public const int ICUniqueDocumentNumber = 10;

            /// <summary>
            /// Property Indexer for NextDetailLineNumber
            /// </summary>
            public const int NextDetailLineNumber = 11;

            /// <summary>
            /// Property Indexer for RecordStatus
            /// </summary>
            public const int RecordStatus = 12;

            /// <summary>
            /// Property Indexer for RecordDeleted
            /// </summary>
            public const int RecordDeleted = 13;

            /// <summary>
            /// Property Indexer for RecordPrinted
            /// </summary>
            public const int RecordPrinted = 14;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 15;

            /// <summary>
            /// Property Indexer for EmployeeNumber
            /// </summary>
            public const int EmployeeNumber = 16;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 17;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 18;

            /// <summary>
            /// Property Indexer for PostSequenceNumber
            /// </summary>
            public const int PostSequenceNumber = 61;

            /// <summary>
            /// Property Indexer for IsCanadianPayrollActive
            /// </summary>
            public const int IsCanadianPayrollActive = 62;

            /// <summary>
            /// Property Indexer for IsUSPayrollActive
            /// </summary>
            public const int IsUSPayrollActive = 63;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 64;

        }

        #endregion

        #region Keys

        /// <summary>
        /// Order Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Document Number Key
            /// </summary>
            public const int InternalUsageNumber = 3;
        }

        #endregion
    }
}
