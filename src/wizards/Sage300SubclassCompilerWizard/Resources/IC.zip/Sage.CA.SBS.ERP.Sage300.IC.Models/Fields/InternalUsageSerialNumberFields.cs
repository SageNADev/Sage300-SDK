﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of InternalUsageSerialNumber Constants
    /// </summary>
    public partial class InternalUsageSerialNumber
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0284";

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageSerialNumber Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for SerialNumber
            /// </summary>
            public const string SerialNumber = "SERIALNUMF";

            /// <summary>
            /// Property for SerialQuantity
            /// </summary>
            public const string SerialQuantity = "SCOUNT";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageSerialNumber Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for SerialNumber
            /// </summary>
            public const int SerialNumber = 3;

            /// <summary>
            /// Property Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 50;

        }

        #endregion

    }
}
