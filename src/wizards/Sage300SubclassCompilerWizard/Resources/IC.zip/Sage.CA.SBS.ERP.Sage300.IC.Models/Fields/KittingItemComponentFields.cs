// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of KittingItemComponent Constants
     /// </summary>
     public partial class KittingItemComponent
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0355";

          #region Properties
          /// <summary>
          /// Contains list of KittingItemComponent Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for KittingNumber
               /// </summary>
               public const string KittingNumber = "KITNO";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "LINENO";

               /// <summary>
               /// Property for ComponentItemNumber
               /// </summary>
               public const string ComponentItemNumber = "COMPONENT";

               /// <summary>
               /// Property for Quantity
               /// </summary>
               public const string Quantity = "QTY";

               /// <summary>
               /// Property for UnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for UnitCost
               /// </summary>
               public const string UnitCost = "UNITCOST";

               /// <summary>
               /// Property for UserSpecifiedCost
               /// </summary>
               public const string UserSpecifiedCost = "SWUSERCOST";

               /// <summary>
               /// Property for Sellable
               /// </summary>
               public const string Sellable = "SELLABLE";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of KittingItemComponent Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 1;

               /// <summary>
               /// Property Indexer for KittingNumber
               /// </summary>
               public const int KittingNumber = 2;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 3;

               /// <summary>
               /// Property Indexer for ComponentItemNumber
               /// </summary>
               public const int ComponentItemNumber = 4;

               /// <summary>
               /// Property Indexer for Quantity
               /// </summary>
               public const int Quantity = 5;

               /// <summary>
               /// Property Indexer for UnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 6;

               /// <summary>
               /// Property Indexer for UnitCost
               /// </summary>
               public const int UnitCost = 7;

               /// <summary>
               /// Property Indexer for UserSpecifiedCost
               /// </summary>
               public const int UserSpecifiedCost = 32;

               /// <summary>
               /// Property Indexer for Sellable
               /// </summary>
               public const int Sellable = 33;

          }
          #endregion

     }
}
