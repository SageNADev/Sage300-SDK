// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of UpdateBillsOfMaterial Constants
	/// </summary>
	public partial class UpdateBillsOfMaterial
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0203";

		#region Properties

		/// <summary>
		/// Contains list of UpdateBillsOfMaterial Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for FromMasterItemNumber
			/// </summary>
			public const string FromMasterItemNumber = "FROMITEM";

			/// <summary>
			/// Property for ToMasterItemNumber
			/// </summary>
			public const string ToMasterItemNumber = "TOITEM";

			/// <summary>
			/// Property for FromBOMNumber
			/// </summary>
			public const string FromBOMNumber = "FROMBOM";

			/// <summary>
			/// Property for ToBOMNumber
			/// </summary>
			public const string ToBOMNumber = "TOBOM";

			/// <summary>
			/// Property for Update
			/// </summary>
			public const string Update = "UPDATE";

			/// <summary>
			/// Property for ComponentType
			/// </summary>
			public const string ComponentType = "CMPNTYPE";

			/// <summary>
			/// Property for CostType
			/// </summary>
			public const string CostType = "COSTTYPE";

			/// <summary>
			/// Property for ComponentItemNumber
			/// </summary>
			public const string ComponentItemNumber = "CMPNTITM";

			/// <summary>
			/// Property for ComponentBOMNumber
			/// </summary>
			public const string ComponentBOMNumber = "CMPNTBOM";

			/// <summary>
			/// Property for ReplacementItemNumber
			/// </summary>
			public const string ReplacementItemNumber = "RPLBYITM";

			/// <summary>
			/// Property for ReplacementBOMNumber
			/// </summary>
			public const string ReplacementBOMNumber = "RPLBYBOM";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "UNIT";

			/// <summary>
			/// Property for Quantity
			/// </summary>
			public const string Quantity = "QUANTITY";

			/// <summary>
			/// Property for UnitCost
			/// </summary>
			public const string UnitCost = "UNITCOST";

			/// <summary>
			/// Property for Using
			/// </summary>
			public const string Using = "USING";

			/// <summary>
			/// Property for Base
			/// </summary>
			public const string Base = "BASE";

			/// <summary>
			/// Property for Amount
			/// </summary>
			public const string Amount = "AMNT";

			/// <summary>
			/// Property for Percentage
			/// </summary>
			public const string Percentage = "PERCENT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of UpdateBillsOfMaterial Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for FromMasterItemNumber
			/// </summary>
			public const int FromMasterItemNumber = 1;

			/// <summary>
			/// Property Indexer for ToMasterItemNumber
			/// </summary>
			public const int ToMasterItemNumber = 2;

			/// <summary>
			/// Property Indexer for FromBOMNumber
			/// </summary>
			public const int FromBOMNumber = 3;

			/// <summary>
			/// Property Indexer for ToBOMNumber
			/// </summary>
			public const int ToBOMNumber = 4;

			/// <summary>
			/// Property Indexer for Update
			/// </summary>
			public const int Update = 5;

			/// <summary>
			/// Property Indexer for ComponentType
			/// </summary>
			public const int ComponentType = 6;

			/// <summary>
			/// Property Indexer for CostType
			/// </summary>
			public const int CostType = 7;

			/// <summary>
			/// Property Indexer for ComponentItemNumber
			/// </summary>
			public const int ComponentItemNumber = 8;

			/// <summary>
			/// Property Indexer for ComponentBOMNumber
			/// </summary>
			public const int ComponentBOMNumber = 9;

			/// <summary>
			/// Property Indexer for ReplacementItemNumber
			/// </summary>
			public const int ReplacementItemNumber = 10;

			/// <summary>
			/// Property Indexer for ReplacementBOMNumber
			/// </summary>
			public const int ReplacementBOMNumber = 11;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 12;

			/// <summary>
			/// Property Indexer for Quantity
			/// </summary>
			public const int Quantity = 13;

			/// <summary>
			/// Property Indexer for UnitCost
			/// </summary>
			public const int UnitCost = 14;

			/// <summary>
			/// Property Indexer for Using
			/// </summary>
			public const int Using = 15;

			/// <summary>
			/// Property Indexer for Base
			/// </summary>
			public const int Base = 16;

			/// <summary>
			/// Property Indexer for Amount
			/// </summary>
			public const int Amount = 17;

			/// <summary>
			/// Property Indexer for Percentage
			/// </summary>
			public const int Percentage = 18;

		}

		#endregion

	}
}
