﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of BillsOfMaterial Constants
    /// </summary>
    public partial class BillsOfMaterial
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0200";

        #region Properties

        /// <summary>
        /// Contains list of BillsOfMaterial Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "ITEMNO";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for BOMNO
            /// </summary>
            public const string BOMNO = "BOMNO";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "REMARK";

            /// <summary>
            /// Property for FixedCost
            /// </summary>
            public const string FixedCost = "FIXEDCOST";

            /// <summary>
            /// Property for BuildQuantity
            /// </summary>
            public const string BuildQuantity = "BUILDQTY";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for VariableCost
            /// </summary>
            public const string VariableCost = "VARBLCOST";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "STARTDATE";

            /// <summary>
            /// Property for EndDate
            /// </summary>
            public const string EndDate = "ENDDATE";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for DateInactive
            /// </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "FMTITEMNO";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for BOMNO2
            /// </summary>
            public const string BOMNO2 = "BOMNO2";

            /// <summary>
            /// Property for CheckItemExistence
            /// </summary>
            public const string CheckItemExistence = "CHECKITEM";

            /// <summary>
            /// Property for LoopCheck
            /// </summary>
            public const string LoopCheck = "LOOPCHECK";

            /// <summary>
            /// Property for UseAsDefault
            /// </summary>
            public const string UseAsDefault = "DEFAULT";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of BillsOfMaterial Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 1;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for BOMNO
            /// </summary>
            public const int BOMNO = 2;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 3;

            /// <summary>
            /// Property Indexer for FixedCost
            /// </summary>
            public const int FixedCost = 4;

            /// <summary>
            /// Property Indexer for BuildQuantity
            /// </summary>
            public const int BuildQuantity = 5;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 6;

            /// <summary>
            /// Property Indexer for VariableCost
            /// </summary>
            public const int VariableCost = 7;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 8;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 9;

            /// <summary>
            /// Property Indexer for EndDate
            /// </summary>
            public const int EndDate = 10;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 11;

            /// <summary>
            /// Property Indexer for DateInactive
            /// </summary>
            public const int DateInactive = 12;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 20;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 21;

            /// <summary>
            /// Property Indexer for BOMNO2
            /// </summary>
            public const int BOMNO2 = 22;

            /// <summary>
            /// Property Indexer for CheckItemExistence
            /// </summary>
            public const int CheckItemExistence = 23;

            /// <summary>
            /// Property Indexer for LoopCheck
            /// </summary>
            public const int LoopCheck = 24;

            /// <summary>
            /// Property Indexer for UseAsDefault
            /// </summary>
            public const int UseAsDefault = 25;

        }

        #endregion

    }
}
