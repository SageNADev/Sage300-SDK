﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of BillsOfMaterialComponent Constants
    /// </summary>
    public partial class BillsOfMaterialComponent
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0190";

        #region Properties

        /// <summary>
        /// Contains list of BillsOfMaterialComponent Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for MasterItemNumber
            /// </summary>
            public const string MasterItemNumber = "ITEMNO";

            /// <summary>
            /// Property for BOMNumber
            /// </summary>
            public const string BOMNumber = "BOMNO";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for ComponentItemNumber
            /// </summary>
            public const string ComponentItemNumber = "COMPONENT";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QTY";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for ComponentBOMNumber
            /// </summary>
            public const string ComponentBOMNumber = "COMPBOMNO";

            /// <summary>
            /// Property for CopyDetail
            /// </summary>
            public const string CopyDetail = "COPYDETAIL";

            /// <summary>
            /// Property for UserSpecifiedCost
            /// </summary>
            public const string UserSpecifiedCost = "SWUSERCOST";

            /// <summary>
            /// Property for FormattedComponentItemNumber
            /// </summary>
            public const string FormattedComponentItemNumber = "FMTCOMP";

            /// <summary>
            /// Property for ComponentItemDescription
            /// </summary>
            public const string ComponentItemDescription = "COMPDESC";

            /// <summary>
            /// Property for FormattedMasterItemNumber
            /// </summary>
            public const string FormattedMasterItemNumber = "FMTITEM";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of BillsOfMaterialComponent Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for MasterItemNumber
            /// </summary>
            public const int MasterItemNumber = 1;

            /// <summary>
            /// Property Indexer for BOMNumber
            /// </summary>
            public const int BOMNumber = 2;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 3;

            /// <summary>
            /// Property Indexer for ComponentItemNumber
            /// </summary>
            public const int ComponentItemNumber = 4;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 5;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 6;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 7;

            /// <summary>
            /// Property Indexer for ComponentBOMNumber
            /// </summary>
            public const int ComponentBOMNumber = 8;

            /// <summary>
            /// Property Indexer for CopyDetail
            /// </summary>
            public const int CopyDetail = 9;

            /// <summary>
            /// Property Indexer for UserSpecifiedCost
            /// </summary>
            public const int UserSpecifiedCost = 32;

            /// <summary>
            /// Property Indexer for FormattedComponentItemNumber
            /// </summary>
            public const int FormattedComponentItemNumber = 33;

            /// <summary>
            /// Property Indexer for ComponentItemDescription
            /// </summary>
            public const int ComponentItemDescription = 34;

            /// <summary>
            /// Property Indexer for FormattedMasterItemNumber
            /// </summary>
            public const int FormattedMasterItemNumber = 35;

        }

        #endregion

    }
}
