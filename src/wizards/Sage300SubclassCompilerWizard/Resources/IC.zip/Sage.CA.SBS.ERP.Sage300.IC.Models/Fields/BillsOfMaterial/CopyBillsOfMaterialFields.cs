﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of CopyBillsOfMaterial Constants
    /// </summary>
    public partial class CopyBillsOfMaterial
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0189";

        #region Properties

        /// <summary>
        /// Contains list of CopyBillsOfMaterial Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for FromMasterItem
            /// </summary>
            public const string FromMasterItem = "FROMMITM";

            /// <summary>
            /// Property for FromBOMNO
            /// </summary>
            public const string FromBOMNO = "FROMBOM";

            /// <summary>
            /// Property for ToMasterItem
            /// </summary>
            public const string ToMasterItem = "TOMITM";

            /// <summary>
            /// Property for ToBOMNO
            /// </summary>
            public const string ToBOMNO = "TOBOM";

            /// <summary>
            /// Property for ActionPerformed
            /// </summary>
            public const string ActionPerformed = "ACTION";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of CopyBillsOfMaterial Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for FromMasterItem
            /// </summary>
            public const int FromMasterItem = 1;

            /// <summary>
            /// Property Indexer for FromBOMNO
            /// </summary>
            public const int FromBOMNO = 2;

            /// <summary>
            /// Property Indexer for ToMasterItem
            /// </summary>
            public const int ToMasterItem = 3;

            /// <summary>
            /// Property Indexer for ToBOMNO
            /// </summary>
            public const int ToBOMNO = 4;

            /// <summary>
            /// Property Indexer for ActionPerformed
            /// </summary>
            public const int ActionPerformed = 5;

        }

        #endregion

    }
}
