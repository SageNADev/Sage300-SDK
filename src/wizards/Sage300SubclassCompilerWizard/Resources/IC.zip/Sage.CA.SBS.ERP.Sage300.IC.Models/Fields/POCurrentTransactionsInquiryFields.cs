// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
    /// Contains list of CurrentTransactionsInquiry For PurchaseOrder Constants
	/// </summary>
    public partial class POCurrentTransactionsInquiry
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0272";

		#region Properties

		/// <summary>
        /// Contains list of CurrentTransactionsInquiryfor PurchaseOrder Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for HeaderSequence
			/// </summary>
			public const string HeaderSequence = "PORHSEQ";

			/// <summary>
			/// Property for LineSequence
			/// </summary>
			public const string LineSequence = "PORLSEQ";

			/// <summary>
			/// Property for PONumber
			/// </summary>
			public const string PONumber = "PONUMBER";

			/// <summary>
			/// Property for VendorNumber
			/// </summary>
			public const string VendorNumber = "VDCODE";

			/// <summary>
			/// Property for VendorName
			/// </summary>
			public const string VendorName = "VDNAME";

			/// <summary>
			/// Property for ExpectedArrivalDate
			/// </summary>
			public const string ExpectedArrivalDate = "EXPARRIVAL";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "POLOCATION";

			/// <summary>
			/// Property for QtyOrdered
			/// </summary>
			public const string QtyOrdered = "OQORDERED";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "ORDERUNIT";

			/// <summary>
			/// Property for QtyReceived
			/// </summary>
			public const string QtyReceived = "OQRECEIVED";

			/// <summary>
			/// Property for QtyOutstanding
			/// </summary>
			public const string QtyOutstanding = "OQOUTSTAND";

		}

		#endregion

		#region Index

		/// <summary>
        /// Contains list of CurrentTransactionsInquiryfor PurchaseOrder Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 1;

			/// <summary>
			/// Property Indexer for HeaderSequence
			/// </summary>
			public const int HeaderSequence = 2;

			/// <summary>
			/// Property Indexer for LineSequence
			/// </summary>
			public const int LineSequence = 3;

			/// <summary>
			/// Property Indexer for PONumber
			/// </summary>
			public const int PONumber = 4;

			/// <summary>
			/// Property Indexer for VendorNumber
			/// </summary>
			public const int VendorNumber = 5;

			/// <summary>
			/// Property Indexer for VendorName
			/// </summary>
			public const int VendorName = 6;

			/// <summary>
			/// Property Indexer for ExpectedArrivalDate
			/// </summary>
			public const int ExpectedArrivalDate = 7;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 8;

			/// <summary>
			/// Property Indexer for QtyOrdered
			/// </summary>
			public const int QtyOrdered = 9;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 10;

			/// <summary>
			/// Property Indexer for QtyReceived
			/// </summary>
			public const int QtyReceived = 11;

			/// <summary>
			/// Property Indexer for QtyOutstanding
			/// </summary>
			public const int QtyOutstanding = 12;

		}

		#endregion

	}
}
