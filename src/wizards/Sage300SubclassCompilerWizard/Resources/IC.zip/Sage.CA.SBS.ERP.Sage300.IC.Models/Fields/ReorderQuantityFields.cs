// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of ReorderQuantity Constants
	/// </summary>
	public partial class ReorderQuantity
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0599";

        /// <summary>
        /// Entity Name for Export/Import
        /// </summary>
        public const string EntityName = "IC0599";

		#region Properties

		/// <summary>
		/// Contains list of ReorderQuantitie Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for ReorderFor
			/// </summary>
			public const string ReorderFor = "ORDERFOR";

			/// <summary>
			/// Property for NumberOfDetails
			/// </summary>
			public const string NumberOfDetails = "DTLCOUNT";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for FormattedItemNumber
			/// </summary>
			public const string FormattedItemNumber = "FMTITEMNO";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

			/// <summary>
			/// Property for CheckItemExistence
			/// </summary>
			public const string CheckItemExistence = "CHECKITEM";

		}

		#endregion

		#region Properties

		/// <summary>
        /// Contains list of ReorderQuantity Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 1;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 2;

			/// <summary>
			/// Property Indexer for ReorderFor
			/// </summary>
			public const int ReorderFor = 3;

			/// <summary>
			/// Property Indexer for NumberOfDetails
			/// </summary>
			public const int NumberOfDetails = 4;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 5;

			/// <summary>
			/// Property Indexer for FormattedItemNumber
			/// </summary>
			public const int FormattedItemNumber = 20;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 21;

			/// <summary>
			/// Property Indexer for CheckItemExistence
			/// </summary>
			public const int CheckItemExistence = 22;

		}

		#endregion

	}
}
