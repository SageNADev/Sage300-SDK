// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of PriceListTaxAuthority Constants
    /// </summary>
    public partial class PriceListTaxAuthority
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0490";

        #region Properties
        /// <summary>
        /// Contains list of PriceListTaxAuthoritie Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CURRENCY";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for PriceListCode
            /// </summary>
            public const string PriceListCode = "PRICELIST";

            /// <summary>
            /// Property for TaxAuthority
            /// </summary>
            public const string TaxAuthority = "AUTHORITY";

            /// <summary>
            /// Property for TaxIncludedInPrice
            /// </summary>
            public const string TaxIncludedInPrice = "TAXINCL";

            /// <summary>
            /// Property for CustomerTaxClass
            /// </summary>
            public const string CustomerTaxClass = "TAXCLASS";

            /// <summary>
            /// Property for CustomerTaxClassDescription
            /// </summary>
            public const string CustomerTaxClassDescription = "TXCLSDESC";

            /// <summary>
            /// Property for TaxAuthorityDescription
            /// </summary>
            public const string TaxAuthorityDescription = "TXAUTHDESC";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of PriceListTaxAuthoritie Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 1;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 2;

            /// <summary>
            /// Property Indexer for PriceListCode
            /// </summary>
            public const int PriceListCode = 3;

            /// <summary>
            /// Property Indexer for TaxAuthority
            /// </summary>
            public const int TaxAuthority = 4;

            /// <summary>
            /// Property Indexer for TaxIncludedInPrice
            /// </summary>
            public const int TaxIncludedInPrice = 5;

            /// <summary>
            /// Property Indexer for CustomerTaxClass
            /// </summary>
            public const int CustomerTaxClass = 6;

            /// <summary>
            /// Property Indexer for CustomerTaxClassDescription
            /// </summary>
            public const int CustomerTaxClassDescription = 7;

            /// <summary>
            /// Property Indexer for TaxAuthorityDescription
            /// </summary>
            public const int TaxAuthorityDescription = 8;

        }
        #endregion

    }
}
