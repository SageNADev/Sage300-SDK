// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of PriceListCodes Constants 
    /// </summary>
    public partial class PriceListCode
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0390";

        /// <summary>
        /// Contains list of PriceListCodes Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for PriceListCode 
            /// </summary>
            public const string PriceListCodeName = "PRICELIST";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";
            /// <summary>
            /// Property for SellingPriceBasedon 
            /// </summary>
            public const string SellingPriceBasedon = "PRICETYPE";
            /// <summary>
            /// Property for DiscountOrMarkuponPriceby 
            /// </summary>
            public const string DiscountOrMarkuponPriceby = "PRICEFMT";
            /// <summary>
            /// Property for DiscountOrMarkupPercentage1 
            /// </summary>
            public const string DiscountOrMarkupPercentage1 = "PRCNTLVL1";
            /// <summary>
            /// Property for DiscountOrMarkupPercentage2 
            /// </summary>
            public const string DiscountOrMarkupPercentage2 = "PRCNTLVL2";
            /// <summary>
            /// Property for DiscountOrMarkupPercentage3 
            /// </summary>
            public const string DiscountOrMarkupPercentage3 = "PRCNTLVL3";
            /// <summary>
            /// Property for DiscountOrMarkupPercentage4 
            /// </summary>
            public const string DiscountOrMarkupPercentage4 = "PRCNTLVL4";
            /// <summary>
            /// Property for DiscountOrMarkupPercentage5 
            /// </summary>
            public const string DiscountOrMarkupPercentage5 = "PRCNTLVL5";
            /// <summary>
            /// Property for PriceDeterminedby 
            /// </summary>
            public const string PriceDeterminedby = "PRICEBASE";
            /// <summary>
            /// Property for QuantityLevel1 
            /// </summary>
            public const string QuantityLevel1 = "PRICEQTY1";
            /// <summary>
            /// Property for QuantityLevel2 
            /// </summary>
            public const string QuantityLevel2 = "PRICEQTY2";
            /// <summary>
            /// Property for QuantityLevel3 
            /// </summary>
            public const string QuantityLevel3 = "PRICEQTY3";
            /// <summary>
            /// Property for QuantityLevel4 
            /// </summary>
            public const string QuantityLevel4 = "PRICEQTY4";
            /// <summary>
            /// Property for QuantityLevel5 
            /// </summary>
            public const string QuantityLevel5 = "PRICEQTY5";
            /// <summary>
            /// Property for DecimalsinPrice 
            /// </summary>
            public const string DecimalsinPrice = "PRICEDECS";
            /// <summary>
            /// Property for RoundingMethod 
            /// </summary>
            public const string RoundingMethod = "ROUNDMETHD";
            /// <summary>
            /// Property for RoundtoaMultipleof 
            /// </summary>
            public const string RoundtoaMultipleof = "ROUNDAMT";
            /// <summary>
            /// Property for DiscountOrMarkupAmount1 
            /// </summary>
            public const string DiscountOrMarkupAmount1 = "AMOUNTLVL1";
            /// <summary>
            /// Property for DiscountOrMarkupAmount2 
            /// </summary>
            public const string DiscountOrMarkupAmount2 = "AMOUNTLVL2";
            /// <summary>
            /// Property for DiscountOrMarkupAmount3 
            /// </summary>
            public const string DiscountOrMarkupAmount3 = "AMOUNTLVL3";
            /// <summary>
            /// Property for DiscountOrMarkupAmount4 
            /// </summary>
            public const string DiscountOrMarkupAmount4 = "AMOUNTLVL4";
            /// <summary>
            /// Property for DiscountOrMarkupAmount5 
            /// </summary>
            public const string DiscountOrMarkupAmount5 = "AMOUNTLVL5";
            /// <summary>
            /// Property for PriceBy 
            /// </summary>
            public const string PriceBy = "PRICEBY";
            /// <summary>
            /// Property for WeightLevel1 
            /// </summary>
            public const string WeightLevel1 = "PRICEWGHT1";
            /// <summary>
            /// Property for WeightLevel2 
            /// </summary>
            public const string WeightLevel2 = "PRICEWGHT2";
            /// <summary>
            /// Property for WeightLevel3 
            /// </summary>
            public const string WeightLevel3 = "PRICEWGHT3";
            /// <summary>
            /// Property for WeightLevel4 
            /// </summary>
            public const string WeightLevel4 = "PRICEWGHT4";
            /// <summary>
            /// Property for WeightLevel5 
            /// </summary>
            public const string WeightLevel5 = "PRICEWGHT5";
            /// <summary>
            /// Property for PriceCheckType 
            /// </summary>
            public const string PriceCheckType = "CPRICETYPE";
            /// <summary>
            /// Property for Check 
            /// </summary>
            public const string Check = "CCHECK";
            /// <summary>
            /// Property for CheckBase 
            /// </summary>
            public const string CheckBase = "CCHECKBASE";
            /// <summary>
            /// Property for CostOrMarginBase 
            /// </summary>
            public const string CostOrMarginBase = "CBASE";

            #endregion
        }


        /// <summary>
        /// Contains list of PriceListCodes Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for PriceListCode 
            /// </summary>
            public const int PriceListCodeName = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for SellingPriceBasedon 
            /// </summary>
            public const int SellingPriceBasedon = 3;
            /// <summary>
            /// Property Indexer for DiscountOrMarkuponPriceby 
            /// </summary>
            public const int DiscountOrMarkuponPriceby = 4;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupPercentage1 
            /// </summary>
            public const int DiscountOrMarkupPercentage1 = 5;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupPercentage2 
            /// </summary>
            public const int DiscountOrMarkupPercentage2 = 6;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupPercentage3 
            /// </summary>
            public const int DiscountOrMarkupPercentage3 = 7;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupPercentage4 
            /// </summary>
            public const int DiscountOrMarkupPercentage4 = 8;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupPercentage5 
            /// </summary>
            public const int DiscountOrMarkupPercentage5 = 9;
            /// <summary>
            /// Property Indexer for PriceDeterminedby 
            /// </summary>
            public const int PriceDeterminedby = 10;
            /// <summary>
            /// Property Indexer for QuantityLevel1 
            /// </summary>
            public const int QuantityLevel1 = 11;
            /// <summary>
            /// Property Indexer for QuantityLevel2 
            /// </summary>
            public const int QuantityLevel2 = 12;
            /// <summary>
            /// Property Indexer for QuantityLevel3 
            /// </summary>
            public const int QuantityLevel3 = 13;
            /// <summary>
            /// Property Indexer for QuantityLevel4 
            /// </summary>
            public const int QuantityLevel4 = 14;
            /// <summary>
            /// Property Indexer for QuantityLevel5 
            /// </summary>
            public const int QuantityLevel5 = 15;
            /// <summary>
            /// Property Indexer for DecimalsinPrice 
            /// </summary>
            public const int DecimalsinPrice = 16;
            /// <summary>
            /// Property Indexer for RoundingMethod 
            /// </summary>
            public const int RoundingMethod = 17;
            /// <summary>
            /// Property Indexer for RoundtoaMultipleof 
            /// </summary>
            public const int RoundtoaMultipleof = 18;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupAmount1 
            /// </summary>
            public const int DiscountOrMarkupAmount1 = 19;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupAmount2 
            /// </summary>
            public const int DiscountOrMarkupAmount2 = 20;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupAmount3 
            /// </summary>
            public const int DiscountOrMarkupAmount3 = 21;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupAmount4 
            /// </summary>
            public const int DiscountOrMarkupAmount4 = 22;
            /// <summary>
            /// Property Indexer for DiscountOrMarkupAmount5 
            /// </summary>
            public const int DiscountOrMarkupAmount5 = 23;
            /// <summary>
            /// Property Indexer for PriceBy 
            /// </summary>
            public const int PriceBy = 24;
            /// <summary>
            /// Property Indexer for WeightLevel1 
            /// </summary>
            public const int WeightLevel1 = 25;
            /// <summary>
            /// Property Indexer for WeightLevel2 
            /// </summary>
            public const int WeightLevel2 = 26;
            /// <summary>
            /// Property Indexer for WeightLevel3 
            /// </summary>
            public const int WeightLevel3 = 27;
            /// <summary>
            /// Property Indexer for WeightLevel4 
            /// </summary>
            public const int WeightLevel4 = 28;
            /// <summary>
            /// Property Indexer for WeightLevel5 
            /// </summary>
            public const int WeightLevel5 = 29;
            /// <summary>
            /// Property Indexer for PriceCheckType 
            /// </summary>
            public const int PriceCheckType = 30;
            /// <summary>
            /// Property Indexer for Check 
            /// </summary>
            public const int Check = 31;
            /// <summary>
            /// Property Indexer for CheckBase 
            /// </summary>
            public const int CheckBase = 32;
            /// <summary>
            /// Property Indexer for CostOrMarginBase 
            /// </summary>
            public const int CostOrMarginBase = 33;

            #endregion
        }


    }
}
