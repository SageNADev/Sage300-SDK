// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of Label Constants
    /// </summary>
    public partial class ReceiptForLabel
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0365";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>();
            }
        }

        #region Properties
        /// <summary>
        /// Contains list of Label Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptNumber
            /// </summary>
            public const string ReceiptNumber = "RECPNUM";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of Label Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 1;
        }
        #endregion
    }
}
