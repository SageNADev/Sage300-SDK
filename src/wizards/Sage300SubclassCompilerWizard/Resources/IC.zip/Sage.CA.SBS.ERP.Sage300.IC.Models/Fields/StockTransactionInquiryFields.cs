// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Stock Transaction Inquiry Summary Constants
    /// </summary>
    public partial class StockTransactionInquirySummary
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "IC0299";

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FromItemNumber
            /// </summary>
            public const string FromItemNumber = "FROMITEM";

            /// <summary>
            /// Property for ToItemNumber
            /// </summary>
            public const string ToItemNumber = "TOITEM";

            /// <summary>
            /// Property for FromAccountSet
            /// </summary>
            public const string FromAccountSet = "FROMACCT";

            /// <summary>
            /// Property for ToAccountSet
            /// </summary>
            public const string ToAccountSet = "TOACCT";

            /// <summary>
            /// Property for FromLocation
            /// </summary>
            public const string FromLocation = "FROMLOC";

            /// <summary>
            /// Property for ToLocation
            /// </summary>
            public const string ToLocation = "TOLOC";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for UnitsOfMeasure
            /// </summary>
            public const string UnitsOfMeasure = "UNIT";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for OpeningQuantity
            /// </summary>
            public const string OpeningQuantity = "OPENQTY";

            /// <summary>
            /// Property for OpeningTotalCost
            /// </summary>
            public const string OpeningTotalCost = "OPENTOTCST";

            /// <summary>
            /// Property for OpeningAverageCost
            /// </summary>
            public const string OpeningAverageCost = "OPENAVGCST";

            /// <summary>
            /// Property for ReceiptQuantity
            /// </summary>
            public const string ReceiptQuantity = "RECPQTY";

            /// <summary>
            /// Property for ReceiptTotalCost
            /// </summary>
            public const string ReceiptTotalCost = "RECPTOTCST";

            /// <summary>
            /// Property for ReceiptAverageCost
            /// </summary>
            public const string ReceiptAverageCost = "RECPAVGCST";

            /// <summary>
            /// Property for ReceiptCount
            /// </summary>
            public const string ReceiptCount = "RECPCOUNT";

            /// <summary>
            /// Property for ReturnQuantity
            /// </summary>
            public const string ReturnQuantity = "RETQTY";

            /// <summary>
            /// Property for ReturnTotalCost
            /// </summary>
            public const string ReturnTotalCost = "RETTOTCST";

            /// <summary>
            /// Property for ReturnAverageCost
            /// </summary>
            public const string ReturnAverageCost = "RETAVGCST";

            /// <summary>
            /// Property for ReturnCount
            /// </summary>
            public const string ReturnCount = "RETCOUNT";

            /// <summary>
            /// Property for SalesQuantity
            /// </summary>
            public const string SalesQuantity = "SALEQTY";

            /// <summary>
            /// Property for SalesTotalCost
            /// </summary>
            public const string SalesTotalCost = "SALETOTCST";

            /// <summary>
            /// Property for SalesAverageCost
            /// </summary>
            public const string SalesAverageCost = "SALEAVGCST";

            /// <summary>
            /// Property for SalesCount
            /// </summary>
            public const string SalesCount = "SALECOUNT";

            /// <summary>
            /// Property for AdjustmentsQuantity
            /// </summary>
            public const string AdjustmentsQuantity = "ADJQTY";

            /// <summary>
            /// Property for AdjustmentsTotalCost
            /// </summary>
            public const string AdjustmentsTotalCost = "ADJTOTCST";

            /// <summary>
            /// Property for AdjustmentsAverageCost
            /// </summary>
            public const string AdjustmentsAverageCost = "ADJAVGCST";

            /// <summary>
            /// Property for AdjustmentsCount
            /// </summary>
            public const string AdjustmentsCount = "ADJCOUNT";

            /// <summary>
            /// Property for TransfersQuantity
            /// </summary>
            public const string TransfersQuantity = "TRANQTY";

            /// <summary>
            /// Property for TransfersTotalCost
            /// </summary>
            public const string TransfersTotalCost = "TRANTOTCST";

            /// <summary>
            /// Property for TransfersAverageCost
            /// </summary>
            public const string TransfersAverageCost = "TRANAVGCST";

            /// <summary>
            /// Property for TransfersCount
            /// </summary>
            public const string TransfersCount = "TRANCOUNT";

            /// <summary>
            /// Property for AssembliesQuantity
            /// </summary>
            public const string AssembliesQuantity = "ASMQTY";

            /// <summary>
            /// Property for AssembliesTotalCost
            /// </summary>
            public const string AssembliesTotalCost = "ASMTOTCST";

            /// <summary>
            /// Property for AssembliesAverageCost
            /// </summary>
            public const string AssembliesAverageCost = "ASMAVGCST";

            /// <summary>
            /// Property for AssembliesCount
            /// </summary>
            public const string AssembliesCount = "ASMCOUNT";

            /// <summary>
            /// Property for InternalUsageQuantity
            /// </summary>
            public const string InternalUsageQuantity = "INUSQTY";

            /// <summary>
            /// Property for InternalUsageTotalCost
            /// </summary>
            public const string InternalUsageTotalCost = "INUSTOTCST";

            /// <summary>
            /// Property for InternalUsageAverageCost
            /// </summary>
            public const string InternalUsageAverageCost = "INUSAVGCST";

            /// <summary>
            /// Property for InternalUsageCount
            /// </summary>
            public const string InternalUsageCount = "INUSCOUNT";

            /// <summary>
            /// Property for ClosingQuantity
            /// </summary>
            public const string ClosingQuantity = "CLOSQTY";

            /// <summary>
            /// Property for ClosingTotalCost
            /// </summary>
            public const string ClosingTotalCost = "CLOSTOTCST";

            /// <summary>
            /// Property for ClosingAverageCost
            /// </summary>
            public const string ClosingAverageCost = "CLOSAVGCST";
        }

        #endregion Properties

        #region Index Properties

        /// <summary>
        /// Contains list of Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FromItemNumber
            /// </summary>
            public const int FromItemNumber = 1;

            /// <summary>
            /// Property Indexer for ToItemNumber
            /// </summary>
            public const int ToItemNumber = 2;

            /// <summary>
            /// Property Indexer for FromAccountSet
            /// </summary>
            public const int FromAccountSet = 3;

            /// <summary>
            /// Property Indexer for ToAccountSet
            /// </summary>
            public const int ToAccountSet = 4;

            /// <summary>
            /// Property Indexer for FromLocation
            /// </summary>
            public const int FromLocation = 5;

            /// <summary>
            /// Property Indexer for ToLocation
            /// </summary>
            public const int ToLocation = 6;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 7;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 8;

            /// <summary>
            /// Property Indexer for UnitsOfMeasure
            /// </summary>
            public const int UnitsOfMeasure = 9;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 10;

            /// <summary>
            /// Property Indexer for OpeningQuantity
            /// </summary>
            public const int OpeningQuantity = 11;

            /// <summary>
            /// Property Indexer for OpeningTotalCost
            /// </summary>
            public const int OpeningTotalCost = 12;

            /// <summary>
            /// Property Indexer for OpeningAverageCost
            /// </summary>
            public const int OpeningAverageCost = 13;

            /// <summary>
            /// Property Indexer for ReceiptQuantity
            /// </summary>
            public const int ReceiptQuantity = 14;

            /// <summary>
            /// Property Indexer for ReceiptTotalCost
            /// </summary>
            public const int ReceiptTotalCost = 15;

            /// <summary>
            /// Property Indexer for ReceiptAverageCost
            /// </summary>
            public const int ReceiptAverageCost = 16;

            /// <summary>
            /// Property Indexer for ReceiptCount
            /// </summary>
            public const int ReceiptCount = 17;

            /// <summary>
            /// Property Indexer for ReturnQuantity
            /// </summary>
            public const int ReturnQuantity = 18;

            /// <summary>
            /// Property Indexer for ReturnTotalCost
            /// </summary>
            public const int ReturnTotalCost = 19;

            /// <summary>
            /// Property Indexer for ReturnAverageCost
            /// </summary>
            public const int ReturnAverageCost = 20;

            /// <summary>
            /// Property Indexer for ReturnCount
            /// </summary>
            public const int ReturnCount = 21;

            /// <summary>
            /// Property Indexer for SalesQuantity
            /// </summary>
            public const int SalesQuantity = 22;

            /// <summary>
            /// Property Indexer for SalesTotalCost
            /// </summary>
            public const int SalesTotalCost = 23;

            /// <summary>
            /// Property Indexer for SalesAverageCost
            /// </summary>
            public const int SalesAverageCost = 24;

            /// <summary>
            /// Property Indexer for SalesCount
            /// </summary>
            public const int SalesCount = 25;

            /// <summary>
            /// Property Indexer for AdjustmentsQuantity
            /// </summary>
            public const int AdjustmentsQuantity = 26;

            /// <summary>
            /// Property Indexer for AdjustmentsTotalCost
            /// </summary>
            public const int AdjustmentsTotalCost = 27;

            /// <summary>
            /// Property Indexer for AdjustmentsAverageCost
            /// </summary>
            public const int AdjustmentsAverageCost = 28;

            /// <summary>
            /// Property Indexer for AdjustmentsCount
            /// </summary>
            public const int AdjustmentsCount = 29;

            /// <summary>
            /// Property Indexer for TransfersQuantity
            /// </summary>
            public const int TransfersQuantity = 30;

            /// <summary>
            /// Property Indexer for TransfersTotalCost
            /// </summary>
            public const int TransfersTotalCost = 31;

            /// <summary>
            /// Property Indexer for TransfersAverageCost
            /// </summary>
            public const int TransfersAverageCost = 32;

            /// <summary>
            /// Property Indexer for TransfersCount
            /// </summary>
            public const int TransfersCount = 33;

            /// <summary>
            /// Property Indexer for AssembliesQuantity
            /// </summary>
            public const int AssembliesQuantity = 34;

            /// <summary>
            /// Property Indexer for AssembliesTotalCost
            /// </summary>
            public const int AssembliesTotalCost = 35;

            /// <summary>
            /// Property Indexer for AssembliesAverageCost
            /// </summary>
            public const int AssembliesAverageCost = 36;

            /// <summary>
            /// Property Indexer for AssembliesCount
            /// </summary>
            public const int AssembliesCount = 37;

            /// <summary>
            /// Property Indexer for InternalUsageQuantity
            /// </summary>
            public const int InternalUsageQuantity = 38;

            /// <summary>
            /// Property Indexer for InternalUsageTotalCost
            /// </summary>
            public const int InternalUsageTotalCost = 39;

            /// <summary>
            /// Property Indexer for InternalUsageAverageCost
            /// </summary>
            public const int InternalUsageAverageCost = 40;

            /// <summary>
            /// Property Indexer for InternalUsageCount
            /// </summary>
            public const int InternalUsageCount = 41;

            /// <summary>
            /// Property Indexer for ClosingQuantity
            /// </summary>
            public const int ClosingQuantity = 42;

            /// <summary>
            /// Property Indexer for ClosingTotalCost
            /// </summary>
            public const int ClosingTotalCost = 43;

            /// <summary>
            /// Property Indexer for ClosingAverageCost
            /// </summary>
            public const int ClosingAverageCost = 44;
        }

        #endregion Properties
    }
}