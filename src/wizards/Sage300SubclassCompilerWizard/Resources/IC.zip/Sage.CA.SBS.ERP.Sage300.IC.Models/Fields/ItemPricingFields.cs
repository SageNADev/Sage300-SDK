// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of ItemPricing Constants
     /// </summary>
     public partial class ItemPricing
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "IC0480";

          #region Properties
          /// <summary>
          /// Contains list of ItemPricing Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CurrencyCode
               /// </summary>
               public const string CurrencyCode = "CURRENCY";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for PriceListCode
               /// </summary>
               public const string PriceListCode = "PRICELIST";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for DecimalsInPrice
               /// </summary>
               public const string DecimalsInPrice = "PRICEDECS";

               /// <summary>
               /// Property for MarkupCost
               /// </summary>
               public const string MarkupCost = "MARKUPCOST";

               /// <summary>
               /// Property for MarkupUnitOfMeasure
               /// </summary>
               public const string MarkupUnitOfMeasure = "MARKUPUNIT";

               /// <summary>
               /// Property for MarkupConversionFactor
               /// </summary>
               public const string MarkupConversionFactor = "MARKUPCONV";

               /// <summary>
               /// Property for SellingPriceBasedon
               /// </summary>
               public const string SellingPriceBasedon = "PRICETYPE";

               /// <summary>
               /// Property for DiscountMarkupPriceby
               /// </summary>
               public const string DiscountMarkupPriceby = "PRICEFMT";

               /// <summary>
               /// Property for DiscountMarkupPercentage1
               /// </summary>
               public const string DiscountMarkupPercentage1 = "PRCNTLVL1";

               /// <summary>
               /// Property for DiscountMarkupPercentage2
               /// </summary>
               public const string DiscountMarkupPercentage2 = "PRCNTLVL2";

               /// <summary>
               /// Property for DiscountMarkupPercentage3
               /// </summary>
               public const string DiscountMarkupPercentage3 = "PRCNTLVL3";

               /// <summary>
               /// Property for DiscountMarkupPercentage4
               /// </summary>
               public const string DiscountMarkupPercentage4 = "PRCNTLVL4";

               /// <summary>
               /// Property for DiscountMarkupPercentage5
               /// </summary>
               public const string DiscountMarkupPercentage5 = "PRCNTLVL5";

               /// <summary>
               /// Property for PriceDeterminedby
               /// </summary>
               public const string PriceDeterminedby = "PRICEBASE";

               /// <summary>
               /// Property for QuantityLevel1
               /// </summary>
               public const string QuantityLevel1 = "PRICEQTY1";

               /// <summary>
               /// Property for QuantityLevel2
               /// </summary>
               public const string QuantityLevel2 = "PRICEQTY2";

               /// <summary>
               /// Property for QuantityLevel3
               /// </summary>
               public const string QuantityLevel3 = "PRICEQTY3";

               /// <summary>
               /// Property for QuantityLevel4
               /// </summary>
               public const string QuantityLevel4 = "PRICEQTY4";

               /// <summary>
               /// Property for QuantityLevel5
               /// </summary>
               public const string QuantityLevel5 = "PRICEQTY5";

               /// <summary>
               /// Property for MarkupFactor
               /// </summary>
               public const string MarkupFactor = "MARKUP";

               /// <summary>
               /// Property for LastMarkupCostChangeDate
               /// </summary>
               public const string LastMarkupCostChangeDate = "LASTMKPDT";

               /// <summary>
               /// Property for PreviousMarkupCost
               /// </summary>
               public const string PreviousMarkupCost = "PREVMKPCST";

               /// <summary>
               /// Property for LastExchangeRateChangeDate
               /// </summary>
               public const string LastExchangeRateChangeDate = "LASTEXCHDT";

               /// <summary>
               /// Property for PreviousExchangeRate
               /// </summary>
               public const string PreviousExchangeRate = "PREVEXCHRT";

               /// <summary>
               /// Property for RoundingMethod
               /// </summary>
               public const string RoundingMethod = "ROUNDMETHD";

               /// <summary>
               /// Property for RoundToaMultipleof
               /// </summary>
               public const string RoundToaMultipleof = "ROUNDAMT";

               /// <summary>
               /// Property for DiscountMarkupAmount1
               /// </summary>
               public const string DiscountMarkupAmount1 = "AMOUNTLVL1";

               /// <summary>
               /// Property for DiscountMarkupAmount2
               /// </summary>
               public const string DiscountMarkupAmount2 = "AMOUNTLVL2";

               /// <summary>
               /// Property for DiscountMarkupAmount3
               /// </summary>
               public const string DiscountMarkupAmount3 = "AMOUNTLVL3";

               /// <summary>
               /// Property for DiscountMarkupAmount4
               /// </summary>
               public const string DiscountMarkupAmount4 = "AMOUNTLVL4";

               /// <summary>
               /// Property for DiscountMarkupAmount5
               /// </summary>
               public const string DiscountMarkupAmount5 = "AMOUNTLVL5";

               /// <summary>
               /// Property for PriceBy
               /// </summary>
               public const string PriceBy = "PRICEBY";

               /// <summary>
               /// Property for MarkupWeightUnitOfMeasure
               /// </summary>
               public const string MarkupWeightUnitOfMeasure = "MRKUPWUNIT";

               /// <summary>
               /// Property for WeightLevel1
               /// </summary>
               public const string WeightLevel1 = "PRICEWGHT1";

               /// <summary>
               /// Property for WeightLevel2
               /// </summary>
               public const string WeightLevel2 = "PRICEWGHT2";

               /// <summary>
               /// Property for WeightLevel3
               /// </summary>
               public const string WeightLevel3 = "PRICEWGHT3";

               /// <summary>
               /// Property for WeightLevel4
               /// </summary>
               public const string WeightLevel4 = "PRICEWGHT4";

               /// <summary>
               /// Property for WeightLevel5
               /// </summary>
               public const string WeightLevel5 = "PRICEWGHT5";

               /// <summary>
               /// Property for PriceCheckType
               /// </summary>
               public const string PriceCheckType = "CPRICETYPE";

               /// <summary>
               /// Property for Check
               /// </summary>
               public const string Check = "CCHECK";

               /// <summary>
               /// Property for CheckBase
               /// </summary>
               public const string CheckBase = "CCHECKBASE";

               /// <summary>
               /// Property for CostMarginBase
               /// </summary>
               public const string CostMarginBase = "CBASE";

               /// <summary>
               /// Property for DefaultBaseUnit
               /// </summary>
               public const string DefaultBaseUnit = "DEFBUNIT";

               /// <summary>
               /// Property for DefaultBaseWeightUnit
               /// </summary>
               public const string DefaultBaseWeightUnit = "DEFBWUNIT";

               /// <summary>
               /// Property for DefaultSaleUnit
               /// </summary>
               public const string DefaultSaleUnit = "DEFSUNIT";

               /// <summary>
               /// Property for DefaultSaleWeightUnit
               /// </summary>
               public const string DefaultSaleWeightUnit = "DEFSWUNIT";

               /// <summary>
               /// Property for StockItem
               /// </summary>
               public const string StockItem = "STOCKITEM";

               /// <summary>
               /// Property for BasePrice
               /// </summary>
               public const string BasePrice = "DBASEPRICE";

               /// <summary>
               /// Property for PricingUnitOfMeasure
               /// </summary>
               public const string PricingUnitOfMeasure = "DBASEUNIT";

               /// <summary>
               /// Property for PricingWeightUnitOfMeasure
               /// </summary>
               public const string PricingWeightUnitOfMeasure = "DBASEWUNIT";

               /// <summary>
               /// Property for BaseConversionFactor
               /// </summary>
               public const string BaseConversionFactor = "DBASECONV";

               /// <summary>
               /// Property for SalePrice
               /// </summary>
               public const string SalePrice = "DSALEPRICE";

               /// <summary>
               /// Property for SaleUnitOfMeasure
               /// </summary>
               public const string SaleUnitOfMeasure = "DSALEUNIT";

               /// <summary>
               /// Property for SaleWeightUnitOfMeasure
               /// </summary>
               public const string SaleWeightUnitOfMeasure = "DSALEWUNIT";

               /// <summary>
               /// Property for SaleConversionFactor
               /// </summary>
               public const string SaleConversionFactor = "DSALECONV";

               /// <summary>
               /// Property for SaleStartDate
               /// </summary>
               public const string SaleStartDate = "DSALESTART";

               /// <summary>
               /// Property for SaleEndDate
               /// </summary>
               public const string SaleEndDate = "DSALEEND";

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "FMTITEMNO";

               /// <summary>
               /// Property for StockingUnitOfMeasure
               /// </summary>
               public const string StockingUnitOfMeasure = "STOCKUNIT";

               /// <summary>
               /// Property for BasePriceType
               /// </summary>
               public const string BasePriceType = "BPRICETYPE";

               /// <summary>
               /// Property for DefaultBasePriceUsing
               /// </summary>
               public const string DefaultBasePriceUsing = "BDEFUSING";

               /// <summary>
               /// Property for BaseLocation
               /// </summary>
               public const string BaseLocation = "BLOCATION";

               /// <summary>
               /// Property for BaseCostBase
               /// </summary>
               public const string BaseCostBase = "BBASE";

               /// <summary>
               /// Property for BasePercentage
               /// </summary>
               public const string BasePercentage = "BPERCENT";

               /// <summary>
               /// Property for BaseAmount
               /// </summary>
               public const string BaseAmount = "BAMOUNT";

               /// <summary>
               /// Property for BaseRateType
               /// </summary>
               public const string BaseRateType = "BRATETYPE";

               /// <summary>
               /// Property for BaseRateDate
               /// </summary>
               public const string BaseRateDate = "BRATEDATE";

               /// <summary>
               /// Property for BaseExchangeRate
               /// </summary>
               public const string BaseExchangeRate = "BEXCHRATE";

               /// <summary>
               /// Property for BaseRateOperator
               /// </summary>
               public const string BaseRateOperator = "BRATEOP";

               /// <summary>
               /// Property for BaseRateOveridden
               /// </summary>
               public const string BaseRateOveridden = "BRATEOVRRD";

               /// <summary>
               /// Property for SalePriceType
               /// </summary>
               public const string SalePriceType = "SPRICETYPE";

               /// <summary>
               /// Property for DefaultSalePriceUsing
               /// </summary>
               public const string DefaultSalePriceUsing = "SDEFUSING";

               /// <summary>
               /// Property for SaleLocation
               /// </summary>
               public const string SaleLocation = "SLOCATION";

               /// <summary>
               /// Property for SaleCostBase
               /// </summary>
               public const string SaleCostBase = "SBASE";

               /// <summary>
               /// Property for SalePercentage
               /// </summary>
               public const string SalePercentage = "SPERCENT";

               /// <summary>
               /// Property for SaleAmount
               /// </summary>
               public const string SaleAmount = "SAMOUNT";

               /// <summary>
               /// Property for SaleRateType
               /// </summary>
               public const string SaleRateType = "SRATETYPE";

               /// <summary>
               /// Property for SaleRateDate
               /// </summary>
               public const string SaleRateDate = "SRATEDATE";

               /// <summary>
               /// Property for SaleExchangeRate
               /// </summary>
               public const string SaleExchangeRate = "SEXCHRATE";

               /// <summary>
               /// Property for SaleRateOperator
               /// </summary>
               public const string SaleRateOperator = "SRATEOP";

               /// <summary>
               /// Property for SaleRateOveridden
               /// </summary>
               public const string SaleRateOveridden = "SRATEOVRRD";

               /// <summary>
               /// Property for ProcessCommand
               /// </summary>
               public const string ProcessCommand = "PROCESSCMD";

               /// <summary>
               /// Property for CheckItemExistence
               /// </summary>
               public const string CheckItemExistence = "CHECKITEM";

               /// <summary>
               /// Property for CalcBaseExchRateExists
               /// </summary>
               public const string CalcBaseExchRateExists = "BRATEEXIST";

               /// <summary>
               /// Property for CalcSaleExchRateExists
               /// </summary>
               public const string CalcSaleExchRateExists = "SRATEEXIST";

               /// <summary>
               /// Property for ItemLocationCostAllowable
               /// </summary>
               public const string ItemLocationCostAllowable = "LOCCOSTOK";

               /// <summary>
               /// Property for PriceListStartDate
               /// </summary>
               public const string PriceListStartDate = "PRICESTART";

               /// <summary>
               /// Property for PriceListEndDate
               /// </summary>
               public const string PriceListEndDate = "PRICEEND";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of ItemPricing Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CurrencyCode
               /// </summary>
               public const int CurrencyCode = 1;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 2;

               /// <summary>
               /// Property Indexer for PriceListCode
               /// </summary>
               public const int PriceListCode = 3;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 4;

               /// <summary>
               /// Property Indexer for DecimalsInPrice
               /// </summary>
               public const int DecimalsInPrice = 5;

               /// <summary>
               /// Property Indexer for MarkupCost
               /// </summary>
               public const int MarkupCost = 14;

               /// <summary>
               /// Property Indexer for MarkupUnitOfMeasure
               /// </summary>
               public const int MarkupUnitOfMeasure = 15;

               /// <summary>
               /// Property Indexer for MarkupConversionFactor
               /// </summary>
               public const int MarkupConversionFactor = 16;

               /// <summary>
               /// Property Indexer for SellingPriceBasedon
               /// </summary>
               public const int SellingPriceBasedon = 17;

               /// <summary>
               /// Property Indexer for DiscountMarkupPriceby
               /// </summary>
               public const int DiscountMarkupPriceby = 18;

               /// <summary>
               /// Property Indexer for DiscountMarkupPercentage1
               /// </summary>
               public const int DiscountMarkupPercentage1 = 19;

               /// <summary>
               /// Property Indexer for DiscountMarkupPercentage2
               /// </summary>
               public const int DiscountMarkupPercentage2 = 20;

               /// <summary>
               /// Property Indexer for DiscountMarkupPercentage3
               /// </summary>
               public const int DiscountMarkupPercentage3 = 21;

               /// <summary>
               /// Property Indexer for DiscountMarkupPercentage4
               /// </summary>
               public const int DiscountMarkupPercentage4 = 22;

               /// <summary>
               /// Property Indexer for DiscountMarkupPercentage5
               /// </summary>
               public const int DiscountMarkupPercentage5 = 23;

               /// <summary>
               /// Property Indexer for PriceDeterminedby
               /// </summary>
               public const int PriceDeterminedby = 24;

               /// <summary>
               /// Property Indexer for QuantityLevel1
               /// </summary>
               public const int QuantityLevel1 = 25;

               /// <summary>
               /// Property Indexer for QuantityLevel2
               /// </summary>
               public const int QuantityLevel2 = 26;

               /// <summary>
               /// Property Indexer for QuantityLevel3
               /// </summary>
               public const int QuantityLevel3 = 27;

               /// <summary>
               /// Property Indexer for QuantityLevel4
               /// </summary>
               public const int QuantityLevel4 = 28;

               /// <summary>
               /// Property Indexer for QuantityLevel5
               /// </summary>
               public const int QuantityLevel5 = 29;

               /// <summary>
               /// Property Indexer for MarkupFactor
               /// </summary>
               public const int MarkupFactor = 30;

               /// <summary>
               /// Property Indexer for LastMarkupCostChangeDate
               /// </summary>
               public const int LastMarkupCostChangeDate = 33;

               /// <summary>
               /// Property Indexer for PreviousMarkupCost
               /// </summary>
               public const int PreviousMarkupCost = 34;

               /// <summary>
               /// Property Indexer for LastExchangeRateChangeDate
               /// </summary>
               public const int LastExchangeRateChangeDate = 35;

               /// <summary>
               /// Property Indexer for PreviousExchangeRate
               /// </summary>
               public const int PreviousExchangeRate = 36;

               /// <summary>
               /// Property Indexer for RoundingMethod
               /// </summary>
               public const int RoundingMethod = 37;

               /// <summary>
               /// Property Indexer for RoundToaMultipleof
               /// </summary>
               public const int RoundToaMultipleof = 38;

               /// <summary>
               /// Property Indexer for DiscountMarkupAmount1
               /// </summary>
               public const int DiscountMarkupAmount1 = 39;

               /// <summary>
               /// Property Indexer for DiscountMarkupAmount2
               /// </summary>
               public const int DiscountMarkupAmount2 = 40;

               /// <summary>
               /// Property Indexer for DiscountMarkupAmount3
               /// </summary>
               public const int DiscountMarkupAmount3 = 41;

               /// <summary>
               /// Property Indexer for DiscountMarkupAmount4
               /// </summary>
               public const int DiscountMarkupAmount4 = 42;

               /// <summary>
               /// Property Indexer for DiscountMarkupAmount5
               /// </summary>
               public const int DiscountMarkupAmount5 = 43;

               /// <summary>
               /// Property Indexer for PriceBy
               /// </summary>
               public const int PriceBy = 44;

               /// <summary>
               /// Property Indexer for MarkupWeightUnitOfMeasure
               /// </summary>
               public const int MarkupWeightUnitOfMeasure = 45;

               /// <summary>
               /// Property Indexer for WeightLevel1
               /// </summary>
               public const int WeightLevel1 = 46;

               /// <summary>
               /// Property Indexer for WeightLevel2
               /// </summary>
               public const int WeightLevel2 = 47;

               /// <summary>
               /// Property Indexer for WeightLevel3
               /// </summary>
               public const int WeightLevel3 = 48;

               /// <summary>
               /// Property Indexer for WeightLevel4
               /// </summary>
               public const int WeightLevel4 = 49;

               /// <summary>
               /// Property Indexer for WeightLevel5
               /// </summary>
               public const int WeightLevel5 = 50;

               /// <summary>
               /// Property Indexer for PriceCheckType
               /// </summary>
               public const int PriceCheckType = 51;

               /// <summary>
               /// Property Indexer for Check
               /// </summary>
               public const int Check = 52;

               /// <summary>
               /// Property Indexer for CheckBase
               /// </summary>
               public const int CheckBase = 53;

               /// <summary>
               /// Property Indexer for CostMarginBase
               /// </summary>
               public const int CostMarginBase = 54;

               /// <summary>
               /// Property Indexer for DefaultBaseUnit
               /// </summary>
               public const int DefaultBaseUnit = 55;

               /// <summary>
               /// Property Indexer for DefaultBaseWeightUnit
               /// </summary>
               public const int DefaultBaseWeightUnit = 56;

               /// <summary>
               /// Property Indexer for DefaultSaleUnit
               /// </summary>
               public const int DefaultSaleUnit = 57;

               /// <summary>
               /// Property Indexer for DefaultSaleWeightUnit
               /// </summary>
               public const int DefaultSaleWeightUnit = 58;

               /// <summary>
               /// Property Indexer for StockItem
               /// </summary>
               public const int StockItem = 59;

               /// <summary>
               /// Property Indexer for BasePrice
               /// </summary>
               public const int BasePrice = 60;

               /// <summary>
               /// Property Indexer for PricingUnitOfMeasure
               /// </summary>
               public const int PricingUnitOfMeasure = 61;

               /// <summary>
               /// Property Indexer for PricingWeightUnitOfMeasure
               /// </summary>
               public const int PricingWeightUnitOfMeasure = 62;

               /// <summary>
               /// Property Indexer for BaseConversionFactor
               /// </summary>
               public const int BaseConversionFactor = 63;

               /// <summary>
               /// Property Indexer for SalePrice
               /// </summary>
               public const int SalePrice = 64;

               /// <summary>
               /// Property Indexer for SaleUnitOfMeasure
               /// </summary>
               public const int SaleUnitOfMeasure = 65;

               /// <summary>
               /// Property Indexer for SaleWeightUnitOfMeasure
               /// </summary>
               public const int SaleWeightUnitOfMeasure = 66;

               /// <summary>
               /// Property Indexer for SaleConversionFactor
               /// </summary>
               public const int SaleConversionFactor = 67;

               /// <summary>
               /// Property Indexer for SaleStartDate
               /// </summary>
               public const int SaleStartDate = 68;

               /// <summary>
               /// Property Indexer for SaleEndDate
               /// </summary>
               public const int SaleEndDate = 69;

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 70;

               /// <summary>
               /// Property Indexer for StockingUnitOfMeasure
               /// </summary>
               public const int StockingUnitOfMeasure = 71;

               /// <summary>
               /// Property Indexer for BasePriceType
               /// </summary>
               public const int BasePriceType = 72;

               /// <summary>
               /// Property Indexer for DefaultBasePriceUsing
               /// </summary>
               public const int DefaultBasePriceUsing = 73;

               /// <summary>
               /// Property Indexer for BaseLocation
               /// </summary>
               public const int BaseLocation = 74;

               /// <summary>
               /// Property Indexer for BaseCostBase
               /// </summary>
               public const int BaseCostBase = 75;

               /// <summary>
               /// Property Indexer for BasePercentage
               /// </summary>
               public const int BasePercentage = 76;

               /// <summary>
               /// Property Indexer for BaseAmount
               /// </summary>
               public const int BaseAmount = 77;

               /// <summary>
               /// Property Indexer for BaseRateType
               /// </summary>
               public const int BaseRateType = 78;

               /// <summary>
               /// Property Indexer for BaseRateDate
               /// </summary>
               public const int BaseRateDate = 79;

               /// <summary>
               /// Property Indexer for BaseExchangeRate
               /// </summary>
               public const int BaseExchangeRate = 80;

               /// <summary>
               /// Property Indexer for BaseRateOperator
               /// </summary>
               public const int BaseRateOperator = 81;

               /// <summary>
               /// Property Indexer for BaseRateOveridden
               /// </summary>
               public const int BaseRateOveridden = 82;

               /// <summary>
               /// Property Indexer for SalePriceType
               /// </summary>
               public const int SalePriceType = 83;

               /// <summary>
               /// Property Indexer for DefaultSalePriceUsing
               /// </summary>
               public const int DefaultSalePriceUsing = 84;

               /// <summary>
               /// Property Indexer for SaleLocation
               /// </summary>
               public const int SaleLocation = 85;

               /// <summary>
               /// Property Indexer for SaleCostBase
               /// </summary>
               public const int SaleCostBase = 86;

               /// <summary>
               /// Property Indexer for SalePercentage
               /// </summary>
               public const int SalePercentage = 87;

               /// <summary>
               /// Property Indexer for SaleAmount
               /// </summary>
               public const int SaleAmount = 88;

               /// <summary>
               /// Property Indexer for SaleRateType
               /// </summary>
               public const int SaleRateType = 89;

               /// <summary>
               /// Property Indexer for SaleRateDate
               /// </summary>
               public const int SaleRateDate = 90;

               /// <summary>
               /// Property Indexer for SaleExchangeRate
               /// </summary>
               public const int SaleExchangeRate = 91;

               /// <summary>
               /// Property Indexer for SaleRateOperator
               /// </summary>
               public const int SaleRateOperator = 92;

               /// <summary>
               /// Property Indexer for SaleRateOveridden
               /// </summary>
               public const int SaleRateOveridden = 93;

               /// <summary>
               /// Property Indexer for ProcessCommand
               /// </summary>
               public const int ProcessCommand = 94;

               /// <summary>
               /// Property Indexer for CheckItemExistence
               /// </summary>
               public const int CheckItemExistence = 95;

               /// <summary>
               /// Property Indexer for CalcBaseExchRateExists
               /// </summary>
               public const int CalcBaseExchRateExists = 96;

               /// <summary>
               /// Property Indexer for CalcSaleExchRateExists
               /// </summary>
               public const int CalcSaleExchRateExists = 97;

               /// <summary>
               /// Property Indexer for ItemLocationCostAllowable
               /// </summary>
               public const int ItemLocationCostAllowable = 98;

               /// <summary>
               /// Property Indexer for PriceListStartDate
               /// </summary>
               public const int PriceListStartDate = 99;

               /// <summary>
               /// Property Indexer for PriceListEndDate
               /// </summary>
               public const int PriceListEndDate = 100;

          }
          #endregion

     }
}
