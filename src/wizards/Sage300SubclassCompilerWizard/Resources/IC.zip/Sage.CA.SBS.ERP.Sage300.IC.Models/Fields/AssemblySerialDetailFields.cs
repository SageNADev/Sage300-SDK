// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of AssemblySerialDetail Constants
	/// </summary>
	public partial class AssemblySerialDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0167";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of AssemblySerialDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "ASSMENSEQ";

			/// <summary>
			/// Property for ComponentID
			/// </summary>
			public const string ComponentID = "COMPID";

			/// <summary>
			/// Property for ParentComponentID
			/// </summary>
			public const string ParentComponentID = "PRNCOMPID";

			/// <summary>
			/// Property for SerialNumber
			/// </summary>
			public const string SerialNumber = "SERIALNUMF";

			/// <summary>
			/// Property for MasterItemSerialNumber
			/// </summary>
			public const string MasterItemSerialNumber = "PRNSERNUMF";

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for BOMNumber
			/// </summary>
			public const string BOMNumber = "BOMNO";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "UNIT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of AssemblySerialDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for ComponentID
			/// </summary>
			public const int ComponentID = 2;

			/// <summary>
			/// Property Indexer for ParentComponentID
			/// </summary>
			public const int ParentComponentID = 3;

			/// <summary>
			/// Property Indexer for SerialNumber
			/// </summary>
			public const int SerialNumber = 4;

			/// <summary>
			/// Property Indexer for MasterItemSerialNumber
			/// </summary>
			public const int MasterItemSerialNumber = 5;

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 6;

			/// <summary>
			/// Property Indexer for BOMNumber
			/// </summary>
			public const int BOMNumber = 7;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 8;

		}

		#endregion

	}
}
