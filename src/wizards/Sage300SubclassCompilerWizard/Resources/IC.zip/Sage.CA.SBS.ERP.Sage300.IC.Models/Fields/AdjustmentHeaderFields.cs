// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of AdjustmentHeader Constants
    /// </summary>
    public partial class AdjustmentHeader
    {
        #region Public Properties

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0120";

        #endregion

        #region Constants

        /// <summary>
        /// Contains list of AdjustmentHeader Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Constant for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "ADJENSEQ";

            /// <summary>
            /// Constant for TransactionNumber
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";

            /// <summary>
            /// Constant for AdjustmentNumber
            /// </summary>
            public const string AdjustmentNumber = "DOCNUM";

            /// <summary>
            /// Constant for Description
            /// </summary>
            public const string Description = "HDRDESC";

            /// <summary>
            /// Constant for AdjustmentDate
            /// </summary>
            public const string AdjustmentDate = "TRANSDATE";

            /// <summary>
            /// Constant for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Constant for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Constant for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Constant for ICUniqueDocumentNumber
            /// </summary>
            public const string ICUniqueDocumentNumber = "DOCUNIQ";

            /// <summary>
            /// Constant for RecordStatus
            /// </summary>
            public const string RecordStatus = "STATUS";

            /// <summary>
            /// Constant for RecordDeleted
            /// </summary>
            public const string RecordDeleted = "DELETED";

            /// <summary>
            /// Constant for NextDetailLineNumber
            /// </summary>
            public const string NextDetailLineNumber = "NEXTDTLNUM";

            /// <summary>
            /// Constant for RecordPrinted
            /// </summary>
            public const string RecordPrinted = "PRINTED";

            /// <summary>
            /// Constant for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Constant for JobRelated
            /// </summary>
            public const string JobRelated = "JOBCOST";

            /// <summary>
            /// Constant for PMAdjustmentNumber
            /// </summary>
            public const string PMAdjustmentNumber = "PMADJUSTNO";

            /// <summary>
            /// Constant for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Constant for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Constant for PostSequenceNumber
            /// </summary>
            public const string PostSequenceNumber = "POSTSEQNUM";

            /// <summary>
            /// Constant for ProcessCommandLocation
            /// </summary>
            public const string ProcessCommandLocation = "OOVERLOC";

            /// <summary>
            /// Constant for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Constant for FromPhysicalInventory
            /// </summary>
            public const string FromPhysicalInventory = "FROMPHYINV";
        }

        #endregion

        #region Indexers

        /// <summary>
        /// Contains list of AdjustmentHeader Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Constant Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Constant Indexer for TransactionNumber
            /// </summary>
            public const int TransactionNumber = 2;

            /// <summary>
            /// Constant Indexer for AdjustmentNumber
            /// </summary>
            public const int AdjustmentNumber = 3;

            /// <summary>
            /// Constant Indexer for Description
            /// </summary>
            public const int Description = 4;

            /// <summary>
            /// Constant Indexer for AdjustmentDate
            /// </summary>
            public const int AdjustmentDate = 5;

            /// <summary>
            /// Constant Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 6;

            /// <summary>
            /// Constant Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 7;

            /// <summary>
            /// Constant Indexer for Reference
            /// </summary>
            public const int Reference = 8;

            /// <summary>
            /// Constant Indexer for ICUniqueDocumentNumber
            /// </summary>
            public const int ICUniqueDocumentNumber = 9;

            /// <summary>
            /// Constant Indexer for RecordStatus
            /// </summary>
            public const int RecordStatus = 10;

            /// <summary>
            /// Constant Indexer for RecordDeleted
            /// </summary>
            public const int RecordDeleted = 11;

            /// <summary>
            /// Constant Indexer for NextDetailLineNumber
            /// </summary>
            public const int NextDetailLineNumber = 12;

            /// <summary>
            /// Constant Indexer for RecordPrinted
            /// </summary>
            public const int RecordPrinted = 13;

            /// <summary>
            /// Constant Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 14;

            /// <summary>
            /// Constant Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 15;

            /// <summary>
            /// Constant Indexer for PMAdjustmentNumber
            /// </summary>
            public const int PMAdjustmentNumber = 16;

            /// <summary>
            /// Constant Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 17;

            /// <summary>
            /// Constant Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 18;

            /// <summary>
            /// Constant Indexer for PostSequenceNumber
            /// </summary>
            public const int PostSequenceNumber = 41;

            /// <summary>
            /// Constant Indexer for ProcessCommandLocation
            /// </summary>
            public const int ProcessCommandLocation = 42;

            /// <summary>
            /// Constant Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 43;

            /// <summary>
            /// Constant Indexer for FromPhysicalInventory
            /// </summary>
            public const int FromPhysicalInventory = 44;

        }

        #endregion

        #region Keys

        /// <summary>
        /// Adjustment Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Adjustment Number Key
            /// </summary>
            public const int AdjustmentNumber = 3;
        }

        #endregion
    }
}
