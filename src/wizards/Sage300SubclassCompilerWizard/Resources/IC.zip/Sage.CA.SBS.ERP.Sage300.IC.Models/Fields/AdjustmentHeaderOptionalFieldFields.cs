// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of Adjustment Header Optional Field Constants
    /// </summary>
    public partial class AdjustmentHeaderOptionalField
    {
        #region Public Properties

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0125";

        #endregion

        #region Constants

        /// <summary>
        /// Contains list of AdjustmentHeaderOpt.Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Constant for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "ADJENSEQ";

            /// <summary>
            /// Constant for OptionalField
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Constant for Value
            /// </summary>
            public const string Value = "VALUE";

            /// <summary>
            /// Constant for Type
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Constant for Length
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Constant for Decimals
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Constant for AllowBlank
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Constant for Validate
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Constant for ValueSet
            /// </summary>
            public const string ValueSet = "SWSET";

            /// <summary>
            /// Constant for TypedValueFieldIndex
            /// </summary>
            public const string TypedValueFieldIndex = "VALINDEX";

            /// <summary>
            /// Constant for TextValue
            /// </summary>
            public const string TextValue = "VALIFTEXT";

            /// <summary>
            /// Constant for AmountValue
            /// </summary>
            public const string AmountValue = "VALIFMONEY";

            /// <summary>
            /// Constant for NumberValue
            /// </summary>
            public const string NumberValue = "VALIFNUM";

            /// <summary>
            /// Constant for IntegerValue
            /// </summary>
            public const string IntegerValue = "VALIFLONG";

            /// <summary>
            /// Constant for YesNoValue
            /// </summary>
            public const string YesNoValue = "VALIFBOOL";

            /// <summary>
            /// Constant for DateValue
            /// </summary>
            public const string DateValue = "VALIFDATE";

            /// <summary>
            /// Constant for TimeValue
            /// </summary>
            public const string TimeValue = "VALIFTIME";

            /// <summary>
            /// Constant for OptionalFieldDescription
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";

            /// <summary>
            /// Constant for ValueDescription
            /// </summary>
            public const string ValueDescription = "VDESC";

        }

        #endregion

        #region Indexers

        /// <summary>
        /// Contains list of AdjustmentHeaderOpt.Field Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Constant Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Constant Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 2;

            /// <summary>
            /// Constant Indexer for Value
            /// </summary>
            public const int Value = 3;

            /// <summary>
            /// Constant Indexer for Type
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Constant Indexer for Length
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Constant Indexer for Decimals
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Constant Indexer for AllowBlank
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Constant Indexer for Validate
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Constant Indexer for ValueSet
            /// </summary>
            public const int ValueSet = 9;

            /// <summary>
            /// Constant Indexer for TypedValueFieldIndex
            /// </summary>
            public const int TypedValueFieldIndex = 20;

            /// <summary>
            /// Constant Indexer for TextValue
            /// </summary>
            public const int TextValue = 21;

            /// <summary>
            /// Constant Indexer for AmountValue
            /// </summary>
            public const int AmountValue = 22;

            /// <summary>
            /// Constant Indexer for NumberValue
            /// </summary>
            public const int NumberValue = 23;

            /// <summary>
            /// Constant Indexer for IntegerValue
            /// </summary>
            public const int IntegerValue = 24;

            /// <summary>
            /// Constant Indexer for YesNoValue
            /// </summary>
            public const int YesNoValue = 25;

            /// <summary>
            /// Constant Indexer for DateValue
            /// </summary>
            public const int DateValue = 26;

            /// <summary>
            /// Constant Indexer for TimeValue
            /// </summary>
            public const int TimeValue = 27;

            /// <summary>
            /// Constant Indexer for OptionalFieldDescription
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Constant Indexer for ValueDescription
            /// </summary>
            public const int ValueDescription = 29;
        }

        #endregion
    }
}
