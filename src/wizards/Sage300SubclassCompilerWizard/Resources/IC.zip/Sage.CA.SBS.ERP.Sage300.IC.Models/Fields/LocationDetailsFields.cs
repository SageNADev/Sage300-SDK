/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of LocationDetails Constants 
    /// </summary>
    public partial class LocationDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0290";

        /// <summary>
        /// Contains list of LocationDetails Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "ITEMNO";
            /// <summary>
            /// Property for Location 
            /// </summary>
            public const string Location = "LOCATION";
            /// <summary>
            /// Property for PickingSequence 
            /// </summary>
            public const string PickingSequence = "PICKINGSEQ";
            /// <summary>
            /// Property for Allowed 
            /// </summary>
            public const string Allowed = "ACTIVE";
            /// <summary>
            /// Property for DateLocationActivated 
            /// </summary>
            public const string DateLocationActivated = "DATEACTIVE";
            /// <summary>
            /// Property for InUse 
            /// </summary>
            public const string InUse = "USED";
            /// <summary>
            /// Property for DateLastUsed 
            /// </summary>
            public const string DateLastUsed = "LASTUSED";
            /// <summary>
            /// Property for QuantityonHandLastDayEnd 
            /// </summary>
            public const string QuantityonHandLastDayEnd = "QTYONHAND";
            /// <summary>
            /// Property for QuantityonPOrO 
            /// </summary>
            public const string QuantityonPOrO = "QTYONORDER";
            /// <summary>
            /// Property for QuantityonSOrO 
            /// </summary>
            public const string QuantityonSOrO = "QTYSALORDR";
            /// <summary>
            /// Property for QuantityNotinCostFile 
            /// </summary>
            public const string QuantityNotinCostFile = "QTYOFFSET";
            /// <summary>
            /// Property for QuantityShippedNotCosted 
            /// </summary>
            public const string QuantityShippedNotCosted = "QTYSHNOCST";
            /// <summary>
            /// Property for QuantityReceivedNotCosted 
            /// </summary>
            public const string QuantityReceivedNotCosted = "QTYRENOCST";
            /// <summary>
            /// Property for QuantityAdjustedNotCosted 
            /// </summary>
            public const string QuantityAdjustedNotCosted = "QTYADNOCST";
            /// <summary>
            /// Property for NumberofUncontestedTransactions 
            /// </summary>
            public const string NumberofUncontestedTransactions = "NUMNOCST";
            /// <summary>
            /// Property for TotalCost 
            /// </summary>
            public const string TotalCost = "TOTALCOST";
            /// <summary>
            /// Property for CostNotinCostFile 
            /// </summary>
            public const string CostNotinCostFile = "COSTOFFSET";
            /// <summary>
            /// Property for CostUnitofMeasure 
            /// </summary>
            public const string CostUnitofMeasure = "COSTUNIT";
            /// <summary>
            /// Property for CostUnitConversionFactor 
            /// </summary>
            public const string CostUnitConversionFactor = "COSTCONV";
            /// <summary>
            /// Property for StandardCost 
            /// </summary>
            public const string StandardCost = "STDCOST";
            /// <summary>
            /// Property for LastStandardCost 
            /// </summary>
            public const string LastStandardCost = "LASTSTDCST";
            /// <summary>
            /// Property for LastStandardCostDate 
            /// </summary>
            public const string LastStandardCostDate = "LASTSTDDAT";
            /// <summary>
            /// Property for LastShipmentDate 
            /// </summary>
            public const string LastShipmentDate = "LASTSHIPDT";
            /// <summary>
            /// Property for AverageDaysToShip 
            /// </summary>
            public const string AverageDaysToShip = "DAYSTOSHIP";
            /// <summary>
            /// Property for AverageUnitsShipped 
            /// </summary>
            public const string AverageUnitsShipped = "UNITSSHIP";
            /// <summary>
            /// Property for ShipmentsUsedInCalculation 
            /// </summary>
            public const string ShipmentsUsedInCalculation = "SHIPMENTS";
            /// <summary>
            /// Property for LastReceiptDate 
            /// </summary>
            public const string LastReceiptDate = "LASTRCPTDT";
            /// <summary>
            /// Property for MostRecentCost 
            /// </summary>
            public const string MostRecentCost = "RECENTCOST";
            /// <summary>
            /// Property for UserDefinedCost1 
            /// </summary>
            public const string UserDefinedCost1 = "COST1";
            /// <summary>
            /// Property for UserDefinedCost2 
            /// </summary>
            public const string UserDefinedCost2 = "COST2";
            /// <summary>
            /// Property for LastUnitCost 
            /// </summary>
            public const string LastUnitCost = "LASTCOST";
            /// <summary>
            /// Property for QuantityCommitted 
            /// </summary>
            public const string QuantityCommitted = "QTYCOMMIT";
            /// <summary>
            /// Property for LastAllocatedSerial 
            /// </summary>
            public const string LastAllocatedSerial = "LASTSERALC";
            /// <summary>
            /// Property for LastAllocatedLot 
            /// </summary>
            public const string LastAllocatedLot = "LASTLOTALC";
            /// <summary>
            /// Property for LeadTimeSIA 
            /// </summary>
            public const string LeadTimeSIA = "LEADTIME";
            /// <summary>
            /// Property for InventoryMinimumSIA 
            /// </summary>
            public const string InventoryMinimumSIA = "QTYMINREQ";
            /// <summary>
            /// Property for QuantityAvailabletoShip 
            /// </summary>
            public const string QuantityAvailabletoShip = "QTYAVAIL";
            /// <summary>
            /// Property for AccountSetCode 
            /// </summary>
            public const string AccountSetCode = "CNTLACCT";
            /// <summary>
            /// Property for QuantityonHand 
            /// </summary>
            public const string QuantityonHand = "AQTYONHAND";
            /// <summary>
            /// Property for AverageCost 
            /// </summary>
            public const string AverageCost = "AVGCOST";
            /// <summary>
            /// Property for CostingMethod 
            /// </summary>
            public const string CostingMethod = "COSTMETHOD";
            /// <summary>
            /// Property for Name 
            /// </summary>
            public const string Name = "LOCDESC";
            /// <summary>
            /// Property for CheckItemExistence 
            /// </summary>
            public const string CheckItemExistence = "CHECKITEM";

            #endregion
        }


        /// <summary>
        /// Contains list of LocationDetails Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 1;
            /// <summary>
            /// Property Indexer for Location 
            /// </summary>
            public const int Location = 2;
            /// <summary>
            /// Property Indexer for PickingSequence 
            /// </summary>
            public const int PickingSequence = 3;
            /// <summary>
            /// Property Indexer for Allowed 
            /// </summary>
            public const int Allowed = 4;
            /// <summary>
            /// Property Indexer for DateLocationActivated 
            /// </summary>
            public const int DateLocationActivated = 5;
            /// <summary>
            /// Property Indexer for InUse 
            /// </summary>
            public const int InUse = 6;
            /// <summary>
            /// Property Indexer for DateLastUsed 
            /// </summary>
            public const int DateLastUsed = 7;
            /// <summary>
            /// Property Indexer for QuantityonHandLastDayEnd 
            /// </summary>
            public const int QuantityonHandLastDayEnd = 8;
            /// <summary>
            /// Property Indexer for QuantityonPOrO 
            /// </summary>
            public const int QuantityonPOrO = 9;
            /// <summary>
            /// Property Indexer for QuantityonSOrO 
            /// </summary>
            public const int QuantityonSOrO = 10;
            /// <summary>
            /// Property Indexer for QuantityNotinCostFile 
            /// </summary>
            public const int QuantityNotinCostFile = 11;
            /// <summary>
            /// Property Indexer for QuantityShippedNotCosted 
            /// </summary>
            public const int QuantityShippedNotCosted = 12;
            /// <summary>
            /// Property Indexer for QuantityReceivedNotCosted 
            /// </summary>
            public const int QuantityReceivedNotCosted = 13;
            /// <summary>
            /// Property Indexer for QuantityAdjustedNotCosted 
            /// </summary>
            public const int QuantityAdjustedNotCosted = 14;
            /// <summary>
            /// Property Indexer for NumberofUncontestedTransactions 
            /// </summary>
            public const int NumberofUncontestedTransactions = 15;
            /// <summary>
            /// Property Indexer for TotalCost 
            /// </summary>
            public const int TotalCost = 16;
            /// <summary>
            /// Property Indexer for CostNotinCostFile 
            /// </summary>
            public const int CostNotinCostFile = 17;
            /// <summary>
            /// Property Indexer for CostUnitofMeasure 
            /// </summary>
            public const int CostUnitofMeasure = 18;
            /// <summary>
            /// Property Indexer for CostUnitConversionFactor 
            /// </summary>
            public const int CostUnitConversionFactor = 19;
            /// <summary>
            /// Property Indexer for StandardCost 
            /// </summary>
            public const int StandardCost = 20;
            /// <summary>
            /// Property Indexer for LastStandardCost 
            /// </summary>
            public const int LastStandardCost = 21;
            /// <summary>
            /// Property Indexer for LastStandardCostDate 
            /// </summary>
            public const int LastStandardCostDate = 22;
            /// <summary>
            /// Property Indexer for LastShipmentDate 
            /// </summary>
            public const int LastShipmentDate = 23;
            /// <summary>
            /// Property Indexer for AverageDaysToShip 
            /// </summary>
            public const int AverageDaysToShip = 24;
            /// <summary>
            /// Property Indexer for AverageUnitsShipped 
            /// </summary>
            public const int AverageUnitsShipped = 25;
            /// <summary>
            /// Property Indexer for ShipmentsUsedInCalculation 
            /// </summary>
            public const int ShipmentsUsedInCalculation = 26;
            /// <summary>
            /// Property Indexer for LastReceiptDate 
            /// </summary>
            public const int LastReceiptDate = 27;
            /// <summary>
            /// Property Indexer for MostRecentCost 
            /// </summary>
            public const int MostRecentCost = 28;
            /// <summary>
            /// Property Indexer for UserDefinedCost1 
            /// </summary>
            public const int UserDefinedCost1 = 29;
            /// <summary>
            /// Property Indexer for UserDefinedCost2 
            /// </summary>
            public const int UserDefinedCost2 = 30;
            /// <summary>
            /// Property Indexer for LastUnitCost 
            /// </summary>
            public const int LastUnitCost = 31;
            /// <summary>
            /// Property Indexer for QuantityCommitted 
            /// </summary>
            public const int QuantityCommitted = 32;
            /// <summary>
            /// Property Indexer for LastAllocatedSerial 
            /// </summary>
            public const int LastAllocatedSerial = 33;
            /// <summary>
            /// Property Indexer for LastAllocatedLot 
            /// </summary>
            public const int LastAllocatedLot = 34;
            /// <summary>
            /// Property Indexer for LeadTimeSIA 
            /// </summary>
            public const int LeadTimeSIA = 35;
            /// <summary>
            /// Property Indexer for InventoryMinimumSIA 
            /// </summary>
            public const int InventoryMinimumSIA = 36;
            /// <summary>
            /// Property Indexer for QuantityAvailabletoShip 
            /// </summary>
            public const int QuantityAvailabletoShip = 62;
            /// <summary>
            /// Property Indexer for AccountSetCode 
            /// </summary>
            public const int AccountSetCode = 63;
            /// <summary>
            /// Property Indexer for QuantityonHand 
            /// </summary>
            public const int QuantityonHand = 64;
            /// <summary>
            /// Property Indexer for AverageCost 
            /// </summary>
            public const int AverageCost = 65;
            /// <summary>
            /// Property Indexer for CostingMethod 
            /// </summary>
            public const int CostingMethod = 66;
            /// <summary>
            /// Property Indexer for Name 
            /// </summary>
            public const int Name = 67;
            /// <summary>
            /// Property Indexer for CheckItemExistence 
            /// </summary>
            public const int CheckItemExistence = 68;

            #endregion
        }


    }
}
