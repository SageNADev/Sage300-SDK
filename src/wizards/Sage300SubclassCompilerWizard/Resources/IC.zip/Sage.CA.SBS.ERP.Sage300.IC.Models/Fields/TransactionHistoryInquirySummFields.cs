﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of TransactionHistoryInquirySumm Constants
    /// </summary>
    public partial class TransactionHistoryInquirySumm
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0285";

        #region Properties

        /// <summary>
        /// Contains list of TransactionHistoryInquirySumm Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for AccountSetCode
            /// </summary>
            public const string AccountSetCode = "ACCTSET";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Itemno
            /// </summary>
            public const string Itemno = "ITEMNO";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for Fmtitemno
            /// </summary>
            public const string Fmtitemno = "FMTITEMNO";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for HistoryRecordsFilter
            /// </summary>
            public const string HistoryRecordsFilter = "HISTFILTER";
        }

        #endregion Properties

        #region Properties

        /// <summary>
        /// Contains list of TransactionHistoryInquirySumm Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for AccountSetCode
            /// </summary>
            public const int AccountSetCode = 1;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 2;

            /// <summary>
            /// Property Indexer for Itemno
            /// </summary>
            public const int Itemno = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 5;

            /// <summary>
            /// Property Indexer for Fmtitemno
            /// </summary>
            public const int Fmtitemno = 6;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 7;

            /// <summary>
            /// Property Indexer for HistoryRecordsFilter
            /// </summary>
            public const int HistoryRecordsFilter = 8;
        }

        #endregion Properties
    }
}