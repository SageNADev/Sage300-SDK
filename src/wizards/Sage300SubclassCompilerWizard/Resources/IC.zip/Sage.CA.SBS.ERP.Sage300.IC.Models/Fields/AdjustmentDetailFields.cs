// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of Adjustment Detail Constants
    /// </summary>
    public partial class AdjustmentDetail
    {
        #region Public Properties

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0110";

        /// <summary>
        /// Dynamic Attributes for Adjustment details grid
        /// It contain a reverse mapping of field and Constant
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"QUANTITY", "Quantity"},
					{"UNIT", "UnitOfMeasure"},
					{"EXTCOST", "CostAdjustment"},
					{"WOFFACCT", "AdjustmentWriteOffAccount"},
					{"MDALLOCATE", "BucketType"},
					{"RECEIPT", "DocumentNumber"},
					{"COSTDATE", "CostDate"},
					{"COSTSEQNUM", "CostingSequenceNumber"}
				};
            }
        }

        #endregion region

        #region Constants

        /// <summary>
        /// Contains list of AdjustmentDetail Fields
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Constant for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "ADJENSEQ";

            /// <summary>
            /// Constant for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Constant for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Constant for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Constant for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Constant for TransactionType
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Constant for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Constant for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Constant for ConversionFactor
            /// </summary>
            public const string ConversionFactor = "CONVERSION";

            /// <summary>
            /// Constant for CostAdjustment
            /// </summary>
            public const string CostAdjustment = "EXTCOST";

            /// <summary>
            /// Constant for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Constant for AdjustmentWriteOffAccount
            /// </summary>
            public const string AdjustmentWriteOffAccount = "WOFFACCT";

            /// <summary>
            /// Constant for OriginalWriteOffAccount
            /// </summary>
            public const string OriginalWriteOffAccount = "ORIGACCT";

            /// <summary>
            /// Constant for CostingMethod
            /// </summary>
            public const string CostingMethod = "COSTMETHOD";

            /// <summary>
            /// Constant for BucketType
            /// </summary>
            public const string BucketType = "MDALLOCATE";

            /// <summary>
            /// Constant for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "RECEIPT";

            /// <summary>
            /// Constant for CostDate
            /// </summary>
            public const string CostDate = "COSTDATE";

            /// <summary>
            /// Constant for CostingSequenceNumber
            /// </summary>
            public const string CostingSequenceNumber = "COSTSEQNUM";

            /// <summary>
            /// Constant for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Constant for ManufacturersItemNumber
            /// </summary>
            public const string ManufacturersItemNumber = "MANITEMNO";

            /// <summary>
            /// Constant for DetailLineNumber
            /// </summary>
            public const string DetailLineNumber = "DETAILNUM";

            /// <summary>
            /// Constant for PMContract
            /// </summary>
            public const string PMContract = "PMCONTRACT";

            /// <summary>
            /// Constant for PMProject
            /// </summary>
            public const string PMProject = "PMPROJECT";

            /// <summary>
            /// Constant for PMCategory
            /// </summary>
            public const string PMCategory = "PMCATEGORY";

            /// <summary>
            /// Constant for PMOverheadAccount
            /// </summary>
            public const string PMOverheadAccount = "PMOHACCT";

            /// <summary>
            /// Constant for PMOverheadAmount
            /// </summary>
            public const string PMOverheadAmount = "PMOHAMT";

            /// <summary>
            /// Constant for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Constant for NumberOfSerials
            /// </summary>
            public const string NumberOfSerials = "SERIALQTY";

            /// <summary>
            /// Constant for LotQuantity
            /// </summary>
            public const string LotQuantity = "LOTQTY";

            /// <summary>
            /// Constant for SerialsCost
            /// </summary>
            public const string SerialsCost = "SERIALCOST";

            /// <summary>
            /// Constant for LotsCost
            /// </summary>
            public const string LotsCost = "LOTCOST";

            /// <summary>
            /// Constant for AverageCost
            /// </summary>
            public const string AverageCost = "AVGCOST";

            /// <summary>
            /// Constant for CostUOM
            /// </summary>
            public const string CostUOM = "COSTUNIT";

            /// <summary>
            /// Constant for RevisionListLineNumber
            /// </summary>
            public const string RevisionListLineNumber = "REVLINE";

            /// <summary>
            /// Constant for InterprocessCommID
            /// </summary>
            public const string InterprocessCommID = "IPCID";

            /// <summary>
            /// Constant for ForcePopupSN
            /// </summary>
            public const string ForcePopupSN = "FORCEPOPSN";

            /// <summary>
            /// Constant for PopupSN
            /// </summary>
            public const string PopupSN = "POPUPSN";

            /// <summary>
            /// Constant for CloseSN
            /// </summary>
            public const string CloseSN = "CLOSESN";

            /// <summary>
            /// Constant for LTSetID
            /// </summary>
            public const string LTSetID = "LTSETID";

            /// <summary>
            /// Constant for ForcePopupLT
            /// </summary>
            public const string ForcePopupLT = "FORCEPOPLT";

            /// <summary>
            /// Constant for PopupLT
            /// </summary>
            public const string PopupLT = "POPUPLT";

            /// <summary>
            /// Constant for CloseLT
            /// </summary>
            public const string CloseLT = "CLOSELT";

            /// <summary>
            /// Constant for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "UNFMTITMNO";

            /// <summary>
            /// Constant for ProcessCommandLocation
            /// </summary>
            public const string ProcessCommandLocation = "OOVERLOC";

            /// <summary>
            /// Constant for ProcessCommandSortCode
            /// </summary>
            public const string ProcessCommandSortCode = "OOVERSORTC";

            /// <summary>
            /// Constant for ProcessCommandItemNumber
            /// </summary>
            public const string ProcessCommandItemNumber = "OOVERITEMN";

            /// <summary>
            /// Constant for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Constant for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Constant for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Constant for QuantityperLot
            /// </summary>
            public const string QuantityperLot = "XPERLOTQTY";

            /// <summary>
            /// Constant for AllocateFromSerial
            /// </summary>
            public const string AllocateFromSerial = "SALLOCFROM";

            /// <summary>
            /// Constant for AllocateFromLot
            /// </summary>
            public const string AllocateFromLot = "LALLOCFROM";

            /// <summary>
            /// Constant for SerialLotWindowHandle
            /// </summary>
            public const string SerialLotWindowHandle = "METERHWND";

        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of Adjustment Detail Index
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Constant Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Constant Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Constant Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 3;

            /// <summary>
            /// Constant Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 4;

            /// <summary>
            /// Constant Indexer for Location
            /// </summary>
            public const int Location = 5;

            /// <summary>
            /// Constant Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 6;

            /// <summary>
            /// Constant Indexer for Quantity
            /// </summary>
            public const int Quantity = 7;

            /// <summary>
            /// Constant Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 8;

            /// <summary>
            /// Constant Indexer for ConversionFactor
            /// </summary>
            public const int ConversionFactor = 9;

            /// <summary>
            /// Constant Indexer for CostAdjustment
            /// </summary>
            public const int CostAdjustment = 10;

            /// <summary>
            /// Constant Indexer for Comments
            /// </summary>
            public const int Comments = 11;

            /// <summary>
            /// Constant Indexer for AdjustmentWriteOffAccount
            /// </summary>
            public const int AdjustmentWriteOffAccount = 12;

            /// <summary>
            /// Constant Indexer for OriginalWriteOffAccount
            /// </summary>
            public const int OriginalWriteOffAccount = 13;

            /// <summary>
            /// Constant Indexer for CostingMethod
            /// </summary>
            public const int CostingMethod = 14;

            /// <summary>
            /// Constant Indexer for BucketType
            /// </summary>
            public const int BucketType = 15;

            /// <summary>
            /// Constant Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 16;

            /// <summary>
            /// Constant Indexer for CostDate
            /// </summary>
            public const int CostDate = 17;

            /// <summary>
            /// Constant Indexer for CostingSequenceNumber
            /// </summary>
            public const int CostingSequenceNumber = 18;

            /// <summary>
            /// Constant Indexer for StockItem
            /// </summary>
            public const int StockItem = 19;

            /// <summary>
            /// Constant Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 20;

            /// <summary>
            /// Constant Indexer for DetailLineNumber
            /// </summary>
            public const int DetailLineNumber = 21;

            /// <summary>
            /// Constant Indexer for PMContract
            /// </summary>
            public const int PMContract = 22;

            /// <summary>
            /// Constant Indexer for PMProject
            /// </summary>
            public const int PMProject = 23;

            /// <summary>
            /// Constant Indexer for PMCategory
            /// </summary>
            public const int PMCategory = 24;

            /// <summary>
            /// Constant Indexer for PMOverheadAccount
            /// </summary>
            public const int PMOverheadAccount = 25;

            /// <summary>
            /// Constant Indexer for PMOverheadAmount
            /// </summary>
            public const int PMOverheadAmount = 26;

            /// <summary>
            /// Constant Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 27;

            /// <summary>
            /// Constant Indexer for NumberOfSerials
            /// </summary>
            public const int NumberOfSerials = 28;

            /// <summary>
            /// Constant Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 29;

            /// <summary>
            /// Constant Indexer for SerialsCost
            /// </summary>
            public const int SerialsCost = 30;

            /// <summary>
            /// Constant Indexer for LotsCost
            /// </summary>
            public const int LotsCost = 31;

            /// <summary>
            /// Constant Indexer for AverageCost
            /// </summary>
            public const int AverageCost = 101;

            /// <summary>
            /// Constant Indexer for CostUOM
            /// </summary>
            public const int CostUOM = 102;

            /// <summary>
            /// Constant Indexer for RevisionListLineNumber
            /// </summary>
            public const int RevisionListLineNumber = 103;

            /// <summary>
            /// Constant Indexer for InterprocessCommID
            /// </summary>
            public const int InterprocessCommID = 104;

            /// <summary>
            /// Constant Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSN = 105;

            /// <summary>
            /// Constant Indexer for PopupSN
            /// </summary>
            public const int PopupSN = 106;

            /// <summary>
            /// Constant Indexer for CloseSN
            /// </summary>
            public const int CloseSN = 107;

            /// <summary>
            /// Constant Indexer for LTSetID
            /// </summary>
            public const int LTSetID = 108;

            /// <summary>
            /// Constant Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLT = 109;

            /// <summary>
            /// Constant Indexer for PopupLT
            /// </summary>
            public const int PopupLT = 110;

            /// <summary>
            /// Constant Indexer for CloseLT
            /// </summary>
            public const int CloseLT = 111;

            /// <summary>
            /// Constant Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 112;

            /// <summary>
            /// Constant Indexer for ProcessCommandLocation
            /// </summary>
            public const int ProcessCommandLocation = 113;

            /// <summary>
            /// Constant Indexer for ProcessCommandSortCode
            /// </summary>
            public const int ProcessCommandSortCode = 114;

            /// <summary>
            /// Constant Indexer for ProcessCommandItemNumber
            /// </summary>
            public const int ProcessCommandItemNumber = 115;

            /// <summary>
            /// Constant Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 116;

            /// <summary>
            /// Constant Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 117;

            /// <summary>
            /// Constant Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 118;

            /// <summary>
            /// Constant Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 119;

            /// <summary>
            /// Constant Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 120;

            /// <summary>
            /// Constant Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 121;

            /// <summary>
            /// Constant Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 122;

        }

        #endregion
    }
}
