// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{

    /// <summary>
    /// Contains list of LIFOFIFOInquirySummary Constants
    /// </summary>
    // ReSharper disable once InconsistentNaming 
    public partial class LIFOFIFOInquirySummary
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0258";

        #region Properties
        /// <summary>
        /// Contains list of LIFOFIFOInquirySummary Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ITEMNO
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for AccountSetCode
            /// </summary>
            public const string AccountSetCode = "CNTLACCT";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTITEMNO
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string FMTITEMNO = "FMTITEMNO";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

        }
        #endregion

        #region Index
        /// <summary>
        /// Contains list of LIFOFIFOInquirySummary Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ITEMNO
            /// </summary>
            public const int ItemNumber = 1;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 2;

            /// <summary>
            /// Property Indexer for AccountSetCode
            /// </summary>
            public const int AccountSetCode = 3;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTITEMNO
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int FMTITEMNO = 4;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 5;

        }
        #endregion
    }
}
