﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{

     /// <summary>
     /// Contains list of ManufacturersItem Constants
     /// </summary>
     public partial class ManufacturersItem
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0305";

          #region Properties
          /// <summary>
          /// Class for  Manufacturer'sItem Number Fields
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for ManufacturersItemNumber
               /// </summary>
               public const string ManufacturersItemNumber = "MANITEMNO";

               /// <summary>
               /// Property for ManufacturersItemDescription
               /// </summary>
               public const string ManufacturersItemDescription = "ITEMDESC";

               /// <summary>
               /// Property for UnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for Comments
               /// </summary>
               public const string Comments = "COMMENT";

               /// <summary>
               /// Property for FormattedItemNumber
               /// </summary>
               public const string FormattedItemNumber = "FMTITEMNO";

               /// <summary>
               /// Property for ForWMS
               /// </summary>
               public const string ForWMS = "FORWMS";

               /// <summary>
               /// Property for CheckItemExistence
               /// </summary>
               public const string CheckItemExistence = "CHECKITEM";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Class for  Manufacturer'sItem Number Index
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 1;

               /// <summary>
               /// Property Indexer for ManufacturersItemNumber
               /// </summary>
               public const int ManufacturersItemNumber = 2;

               /// <summary>
               /// Property Indexer for ManufacturersItemDescription
               /// </summary>
               public const int ManufacturersItemDescription = 3;

               /// <summary>
               /// Property Indexer for UnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 4;

               /// <summary>
               /// Property Indexer for Comments
               /// </summary>
               public const int Comments = 5;

               /// <summary>
               /// Property Indexer for FormattedItemNumber
               /// </summary>
               public const int FormattedItemNumber = 21;

               /// <summary>
               /// Property Indexer for ForWMS
               /// </summary>
               public const int ForWMS = 22;

               /// <summary>
               /// Property Indexer for CheckItemExistence
               /// </summary>
               public const int CheckItemExistence = 23;

          }
          #endregion

     }
 }

