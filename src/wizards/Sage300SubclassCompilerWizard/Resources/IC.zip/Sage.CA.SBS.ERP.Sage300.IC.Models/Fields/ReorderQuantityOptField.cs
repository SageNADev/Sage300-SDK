// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of ReorderQuantityOptField Constants
	/// </summary>
	public partial class ReorderQuantityOptField
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0601";

        /// <summary>
        /// Entity Name for Export/Import
        /// </summary>
        public const string EntityName = "IC0601";

		#region Properties

		/// <summary>
		/// Contains list of ReorderQuantitiesOptField Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for OptionalField
			/// </summary>
			public const string OptionalField = "OPTFIELD";

			/// <summary>
			/// Property for Value
			/// </summary>
			public const string Value = "VALUE";

			/// <summary>
			/// Property for Type
			/// </summary>
			public const string Type = "TYPE";

			/// <summary>
			/// Property for Length
			/// </summary>
			public const string Length = "LENGTH";

			/// <summary>
			/// Property for Decimals
			/// </summary>
			public const string Decimals = "DECIMALS";

			/// <summary>
			/// Property for AllowBlank
			/// </summary>
			public const string AllowBlank = "ALLOWNULL";

			/// <summary>
			/// Property for Validate
			/// </summary>
			public const string Validate = "VALIDATE";

			/// <summary>
			/// Property for ValueSet
			/// </summary>
			public const string ValueSet = "SWSET";

			/// <summary>
			/// Property for TypedValueFieldIndex
			/// </summary>
			public const string TypedValueFieldIndex = "VALINDEX";

			/// <summary>
			/// Property for TextValue
			/// </summary>
			public const string TextValue = "VALIFTEXT";

			/// <summary>
			/// Property for AmountValue
			/// </summary>
			public const string AmountValue = "VALIFMONEY";

			/// <summary>
			/// Property for NumberValue
			/// </summary>
			public const string NumberValue = "VALIFNUM";

			/// <summary>
			/// Property for IntegerValue
			/// </summary>
			public const string IntegerValue = "VALIFLONG";

			/// <summary>
			/// Property for YesNoValue
			/// </summary>
			public const string YesNoValue = "VALIFBOOL";

			/// <summary>
			/// Property for DateValue
			/// </summary>
			public const string DateValue = "VALIFDATE";

			/// <summary>
			/// Property for TimeValue
			/// </summary>
			public const string TimeValue = "VALIFTIME";

			/// <summary>
			/// Property for OptionalFieldDescription
			/// </summary>
			public const string OptionalFieldDescription = "FDESC";

			/// <summary>
			/// Property for ValueDescription
			/// </summary>
			public const string ValueDescription = "VDESC";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ReorderQuantitiesOptField Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 1;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 2;

			/// <summary>
			/// Property Indexer for OptionalField
			/// </summary>
			public const int OptionalField = 3;

			/// <summary>
			/// Property Indexer for Value
			/// </summary>
			public const int Value = 4;

			/// <summary>
			/// Property Indexer for Type
			/// </summary>
			public const int Type = 5;

			/// <summary>
			/// Property Indexer for Length
			/// </summary>
			public const int Length = 6;

			/// <summary>
			/// Property Indexer for Decimals
			/// </summary>
			public const int Decimals = 7;

			/// <summary>
			/// Property Indexer for AllowBlank
			/// </summary>
			public const int AllowBlank = 8;

			/// <summary>
			/// Property Indexer for Validate
			/// </summary>
			public const int Validate = 9;

			/// <summary>
			/// Property Indexer for ValueSet
			/// </summary>
			public const int ValueSet = 10;

			/// <summary>
			/// Property Indexer for TypedValueFieldIndex
			/// </summary>
			public const int TypedValueFieldIndex = 20;

			/// <summary>
			/// Property Indexer for TextValue
			/// </summary>
			public const int TextValue = 21;

			/// <summary>
			/// Property Indexer for AmountValue
			/// </summary>
			public const int AmountValue = 22;

			/// <summary>
			/// Property Indexer for NumberValue
			/// </summary>
			public const int NumberValue = 23;

			/// <summary>
			/// Property Indexer for IntegerValue
			/// </summary>
			public const int IntegerValue = 24;

			/// <summary>
			/// Property Indexer for YesNoValue
			/// </summary>
			public const int YesNoValue = 25;

			/// <summary>
			/// Property Indexer for DateValue
			/// </summary>
			public const int DateValue = 26;

			/// <summary>
			/// Property Indexer for TimeValue
			/// </summary>
			public const int TimeValue = 27;

			/// <summary>
			/// Property Indexer for OptionalFieldDescription
			/// </summary>
			public const int OptionalFieldDescription = 28;

			/// <summary>
			/// Property Indexer for ValueDescription
			/// </summary>
			public const int ValueDescription = 29;

		}

		#endregion

	}
}
