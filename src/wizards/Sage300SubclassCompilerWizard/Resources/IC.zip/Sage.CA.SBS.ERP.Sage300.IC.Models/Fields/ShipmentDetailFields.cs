// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of ShipmentDetail Constants
    /// </summary>
    public partial class ShipmentDetail
    {
        #region Entity Name

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0630";

        #endregion

        #region Dynamic Properties for Enable / Disable.

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"UNITCOST", "UnitCost"},
                    {"EXTCOST", "ExtendedCost"},
                    {"SERIALNO", "SerialNumbers"}
                };
            }
        }
       
        #endregion

        #region ShipmentDetail Field Constants

        /// <summary>
        /// Contains list of ShipmentDetail Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for ConversionFactor
            /// </summary>
            public const string ConversionFactor = "CONVERSION";

            /// <summary>
            /// Property for PriceList
            /// </summary>
            public const string PriceList = "PRICELIST";

            /// <summary>
            /// Property for UnitPrice
            /// </summary>
            public const string UnitPrice = "UNITPRICE";

            /// <summary>
            /// Property for ExtendedPrice
            /// </summary>
            public const string ExtendedPrice = "SHIPPRICE";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTCOST";

            ///// <summary>
            ///// Property for ***Obsolete***
            ///// </summary>
            //public const string ***Obsolete*** = "JOBNO";

            /// <summary>
            /// Property for SerialNumbers
            /// </summary>
            public const string SerialNumbers = "SERIALNO";

            /// <summary>
            /// Property for SerialNumberUniquifier
            /// </summary>
            public const string SerialNumberUniquifier = "SERIALUNIQ";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for PMContract
            /// </summary>
            public const string PMContract = "PMCONTRACT";

            /// <summary>
            /// Property for PMProject
            /// </summary>
            public const string PMProject = "PMPROJECT";

            /// <summary>
            /// Property for PMCategory
            /// </summary>
            public const string PMCategory = "PMCATEGORY";

            /// <summary>
            /// Property for PMDetail
            /// </summary>
            public const string PMDetail = "PMDETAIL";

            /// <summary>
            /// Property for PMWIPAccount
            /// </summary>
            public const string PMWIPAccount = "PMWIPACCT";

            /// <summary>
            /// Property for ManufacturersItemNumber
            /// </summary>
            public const string ManufacturersItemNumber = "MANITEMNO";

            /// <summary>
            /// Property for CustomerItemNumber
            /// </summary>
            public const string CustomerItemNumber = "CUSTITEMNO";

            /// <summary>
            /// Property for DetailLineNumber
            /// </summary>
            public const string DetailLineNumber = "DETAILNUM";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for GLControlAmountShipment
            /// </summary>
            public const string GLControlAmountShipment = "SAMTCNTL";

            /// <summary>
            /// Property for GLCostVarianceShipment
            /// </summary>
            public const string GLCostVarianceShipment = "SAMTCSTVAR";

            /// <summary>
            /// Property for GLControlAmountShipmentRet
            /// </summary>
            public const string GLControlAmountShipmentRet = "RAMTCNTL";

            /// <summary>
            /// Property for GLCostVarianceShipmentRetu
            /// </summary>
            public const string GLCostVarianceShipmentRetu = "RAMTCSTVAR";

            /// <summary>
            /// Property for NumberOfSerials
            /// </summary>
            public const string NumberOfSerials = "SERIALQTY";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "LOTQTY";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for RevisionListLineNumber
            /// </summary>
            public const string RevisionListLineNumber = "REVLINE";

            /// <summary>
            /// Property for InterprocessCommID
            /// </summary>
            public const string InterprocessCommID = "IPCID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            public const string ForcePopupSN = "FORCEPOPSN";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            public const string PopupSN = "POPUPSN";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            public const string CloseSN = "CLOSESN";

            /// <summary>
            /// Property for LTSetID
            /// </summary>
            public const string LTSetID = "LTSETID";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            public const string ForcePopupLT = "FORCEPOPLT";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            public const string PopupLT = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            public const string CloseLT = "CLOSELT";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "UNFMTITMNO";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Property for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Property for QuantityperLot
            /// </summary>
            public const string QuantityperLot = "XPERLOTQTY";

            /// <summary>
            /// Property for EntryType
            /// </summary>
            public const string EntryType = "TRANSTYPE";

            /// <summary>
            /// Property for AllocateFromSerial
            /// </summary>
            public const string AllocateFromSerial = "SALLOCFROM";

            /// <summary>
            /// Property for AllocateFromLot
            /// </summary>
            public const string AllocateFromLot = "LALLOCFROM";

            /// <summary>
            /// Property for SerialLotWindowHandle
            /// </summary>
            public const string SerialLotWindowHandle = "METERHWND";

        }

        #endregion

        #region ShipmentDetail Index Constants

        /// <summary>
        /// Contains list of ShipmentDetail Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 3;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 4;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 5;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 6;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 7;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 8;

            /// <summary>
            /// Property Indexer for ConversionFactor
            /// </summary>
            public const int ConversionFactor = 9;

            /// <summary>
            /// Property Indexer for PriceList
            /// </summary>
            public const int PriceList = 10;

            /// <summary>
            /// Property Indexer for UnitPrice
            /// </summary>
            public const int UnitPrice = 11;

            /// <summary>
            /// Property Indexer for ExtendedPrice
            /// </summary>
            public const int ExtendedPrice = 12;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 13;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 14;

            ///// <summary>
            ///// Property Indexer for ***Obsolete***
            ///// </summary>
            //public const int ***Obsolete*** = 15;

            /// <summary>
            /// Property Indexer for SerialNumbers
            /// </summary>
            public const int SerialNumbers = 16;

            /// <summary>
            /// Property Indexer for SerialNumberUniquifier
            /// </summary>
            public const int SerialNumberUniquifier = 17;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 18;

            /// <summary>
            /// Property Indexer for PMContract
            /// </summary>
            public const int PMContract = 19;

            /// <summary>
            /// Property Indexer for PMProject
            /// </summary>
            public const int PMProject = 20;

            /// <summary>
            /// Property Indexer for PMCategory
            /// </summary>
            public const int PMCategory = 21;

            /// <summary>
            /// Property Indexer for PMDetail
            /// </summary>
            public const int PMDetail = 22;

            /// <summary>
            /// Property Indexer for PMWIPAccount
            /// </summary>
            public const int PMWIPAccount = 23;

            /// <summary>
            /// Property Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 24;

            /// <summary>
            /// Property Indexer for CustomerItemNumber
            /// </summary>
            public const int CustomerItemNumber = 25;

            /// <summary>
            /// Property Indexer for DetailLineNumber
            /// </summary>
            public const int DetailLineNumber = 26;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 27;

            /// <summary>
            /// Property Indexer for GLControlAmountShipment
            /// </summary>
            public const int GLControlAmountShipment = 28;

            /// <summary>
            /// Property Indexer for GLCostVarianceShipment
            /// </summary>
            public const int GLCostVarianceShipment = 29;

            /// <summary>
            /// Property Indexer for GLControlAmountShipmentRet
            /// </summary>
            public const int GLControlAmountShipmentRet = 30;

            /// <summary>
            /// Property Indexer for GLCostVarianceShipmentRetu
            /// </summary>
            public const int GLCostVarianceShipmentRetu = 31;

            /// <summary>
            /// Property Indexer for NumberOfSerials
            /// </summary>
            public const int NumberOfSerials = 32;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 33;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 41;

            /// <summary>
            /// Property Indexer for RevisionListLineNumber
            /// </summary>
            public const int RevisionListLineNumber = 42;

            /// <summary>
            /// Property Indexer for InterprocessCommID
            /// </summary>
            public const int InterprocessCommID = 43;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSN = 44;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            public const int PopupSN = 45;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            public const int CloseSN = 46;

            /// <summary>
            /// Property Indexer for LTSetID
            /// </summary>
            public const int LTSetID = 47;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLT = 48;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            public const int PopupLT = 49;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            public const int CloseLT = 50;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 51;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 52;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 53;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 54;

            /// <summary>
            /// Property Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 55;

            /// <summary>
            /// Property Indexer for EntryType
            /// </summary>
            public const int EntryType = 56;

            /// <summary>
            /// Property Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 57;

            /// <summary>
            /// Property Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 58;

            /// <summary>
            /// Property Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 59;

        }

        #endregion
    }
}
