// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of ShipmentHeader Constants
    /// </summary>
    public partial class ShipmentHeader
    {
        #region Entity Name

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0640";

        #endregion

        #region ShipmentHeader Field Constants

        /// <summary>
        /// Contains list of ShipmentHeader Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for TransactionNumber
            /// </summary>
            public const string TransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property for ShipmentNumber
            /// </summary>
            public const string ShipmentNumber = "DOCNUM";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "HDRDESC";

            /// <summary>
            /// Property for ShipDate
            /// </summary>
            public const string ShipDate = "TRANSDATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for EntryType
            /// </summary>
            public const string EntryType = "TRANSTYPE";

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "CUSTNO";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTNAME";

            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "CONTACT";

            /// <summary>
            /// Property for SourceCurrency
            /// </summary>
            public const string SourceCurrency = "CURRENCY";

            /// <summary>
            /// Property for PriceList
            /// </summary>
            public const string PriceList = "PRICELIST";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "EXCHRATE";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperation
            /// </summary>
            public const string RateOperation = "RATEOP";

            /// <summary>
            /// Property for RateOverride
            /// </summary>
            public const string RateOverride = "RATEOVRRD";

            /// <summary>
            /// Property for SerialNumberUniquifier
            /// </summary>
            public const string SerialNumberUniquifier = "SERIALUNIQ";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "JOBCOST";

            /// <summary>
            /// Property for ICUniqueDocumentNumber
            /// </summary>
            public const string ICUniqueDocumentNumber = "DOCUNIQ";

            /// <summary>
            /// Property for RecordStatus
            /// </summary>
            public const string RecordStatus = "STATUS";

            /// <summary>
            /// Property for RecordDeleted
            /// </summary>
            public const string RecordDeleted = "DELETED";

            /// <summary>
            /// Property for NextDetailLineNumber
            /// </summary>
            public const string NextDetailLineNumber = "NEXTDTLNUM";

            /// <summary>
            /// Property for RecordPrinted
            /// </summary>
            public const string RecordPrinted = "PRINTED";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for CustomerExists
            /// </summary>
            public const string CustomerExists = "CUSTEXISTS";

            /// <summary>
            /// Property for PostSequenceNumber
            /// </summary>
            public const string PostSequenceNumber = "POSTSEQNUM";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

        }

        #endregion

        #region ShipmentHeader Index Constants

        /// <summary>
        /// Contains list of ShipmentHeader Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for TransactionNumber
            /// </summary>
            public const int TransactionNumber = 2;

            /// <summary>
            /// Property Indexer for ShipmentNumber
            /// </summary>
            public const int ShipmentNumber = 3;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 4;

            /// <summary>
            /// Property Indexer for ShipDate
            /// </summary>
            public const int ShipDate = 5;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 6;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 7;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 8;

            /// <summary>
            /// Property Indexer for EntryType
            /// </summary>
            public const int EntryType = 9;

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 10;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 11;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 12;

            /// <summary>
            /// Property Indexer for SourceCurrency
            /// </summary>
            public const int SourceCurrency = 13;

            /// <summary>
            /// Property Indexer for PriceList
            /// </summary>
            public const int PriceList = 14;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 15;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 16;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 17;

            /// <summary>
            /// Property Indexer for RateOperation
            /// </summary>
            public const int RateOperation = 18;

            /// <summary>
            /// Property Indexer for RateOverride
            /// </summary>
            public const int RateOverride = 19;

            /// <summary>
            /// Property Indexer for SerialNumberUniquifier
            /// </summary>
            public const int SerialNumberUniquifier = 20;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 21;

            /// <summary>
            /// Property Indexer for ICUniqueDocumentNumber
            /// </summary>
            public const int ICUniqueDocumentNumber = 22;

            /// <summary>
            /// Property Indexer for RecordStatus
            /// </summary>
            public const int RecordStatus = 23;

            /// <summary>
            /// Property Indexer for RecordDeleted
            /// </summary>
            public const int RecordDeleted = 24;

            /// <summary>
            /// Property Indexer for NextDetailLineNumber
            /// </summary>
            public const int NextDetailLineNumber = 25;

            /// <summary>
            /// Property Indexer for RecordPrinted
            /// </summary>
            public const int RecordPrinted = 26;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 27;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 28;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 29;

            /// <summary>
            /// Property Indexer for CustomerExists
            /// </summary>
            public const int CustomerExists = 101;

            /// <summary>
            /// Property Indexer for PostSequenceNumber
            /// </summary>
            public const int PostSequenceNumber = 102;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 103;

        }

        #endregion

        #region Keys

        /// <summary>
        /// Order Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Shipment Number Key
            /// </summary>
            public const int ShipmentNumber = 3;
        }

        #endregion
    }
}
