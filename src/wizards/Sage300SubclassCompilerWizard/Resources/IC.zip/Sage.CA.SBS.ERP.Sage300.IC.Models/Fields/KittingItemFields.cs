// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of KittingItem Constants
     /// </summary>
     public partial class KittingItem
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0356";

          #region Properties
          /// <summary>
          /// Contains list of KittingItem Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for KittingNumber
               /// </summary>
               public const string KittingNumber = "KITNO";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for Comments
               /// </summary>
               public const string Comments = "REMARK";

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "FMTITEMNO";

               /// <summary>
               /// Property for ItemDescription
               /// </summary>
               public const string ItemDescription = "ITEMDESC";

               /// <summary>
               /// Property for UseAsDefault
               /// </summary>
               public const string UseAsDefault = "DEFAULT";

               /// <summary>
               /// Property for BuildQuantity
               /// </summary>
               public const string BuildQuantity = "BUILDQTY";

               /// <summary>
               /// Property for UnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for CheckItemExistence
               /// </summary>
               public const string CheckItemExistence = "CHECKITEM";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of KittingItem Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 1;

               /// <summary>
               /// Property Indexer for KittingNumber
               /// </summary>
               public const int KittingNumber = 2;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 3;

               /// <summary>
               /// Property Indexer for Comments
               /// </summary>
               public const int Comments = 4;

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 20;

               /// <summary>
               /// Property Indexer for ItemDescription
               /// </summary>
               public const int ItemDescription = 21;

               /// <summary>
               /// Property Indexer for UseAsDefault
               /// </summary>
               public const int UseAsDefault = 22;

               /// <summary>
               /// Property Indexer for BuildQuantity
               /// </summary>
               public const int BuildQuantity = 23;

               /// <summary>
               /// Property Indexer for UnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 24;

               /// <summary>
               /// Property Indexer for CheckItemExistence
               /// </summary>
               public const int CheckItemExistence = 25;

          }
          #endregion

     }
}
