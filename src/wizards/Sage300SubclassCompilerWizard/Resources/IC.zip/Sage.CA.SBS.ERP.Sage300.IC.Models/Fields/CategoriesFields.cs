/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Categories Constants 
    /// </summary>
	public partial class Category 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0210";

        /// <summary>
        /// Contains list of Categories Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for CategoryCode 
        /// </summary>
	    public const string CategoryCode  = "CATEGORY";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "DESC";
	            /// <summary>
        /// Property for CostofGoodsSoldAccount 
        /// </summary>
	    public const string CostofGoodsSoldAccount  = "COGSACCT";
	            /// <summary>
        /// Property for SalesAccount 
        /// </summary>
	    public const string SalesAccount  = "REVENUACCT";
	            /// <summary>
        /// Property for ReturnsAccount 
        /// </summary>
	    public const string ReturnsAccount  = "RETURNACCT";
	            /// <summary>
        /// Property for CostVarianceAccount 
        /// </summary>
	    public const string CostVarianceAccount  = "VARIANACCT";
	            /// <summary>
        /// Property for CommissionPaid 
        /// </summary>
	    public const string CommissionPaid  = "COMMSNPAID";
	            /// <summary>
        /// Property for CommissionRate 
        /// </summary>
	    public const string CommissionRate  = "COMMSNRATE";
	            /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "INACTIVE";
	            /// <summary>
        /// Property for DateLastMaintained 
        /// </summary>
	    public const string DateLastMaintained  = "DATELASTMN";
	            /// <summary>
        /// Property for DefaultPriceListCode 
        /// </summary>
	    public const string DefaultPriceListCode  = "DEFPRICLST";
	            /// <summary>
        /// Property for DateInactive 
        /// </summary>
	    public const string DateInactive  = "DATEINACTV";
	            /// <summary>
        /// Property for DamagedGoodsAccount 
        /// </summary>
	    public const string DamagedGoodsAccount  = "DAMAGEACCT";
	            /// <summary>
        /// Property for InternalUsageAccount 
        /// </summary>
	    public const string InternalUsageAccount  = "ICSEXPACCT";
        /// <summary>
        /// Property for Status 
        /// </summary>
        public const string StatusString = "INACTIVE";
        /// <summary>
        /// Property for CommissionPaidString 
        /// </summary>
        public const string CommissionPaidString = "COMMSNPAID";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of Categories Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for CategoryCode 
        /// </summary>
	    public const int CategoryCode  = 1;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 2;
	             /// <summary>
        /// Property Indexer for CostofGoodsSoldAccount 
        /// </summary>
	    public const int CostofGoodsSoldAccount  = 3;
	             /// <summary>
        /// Property Indexer for SalesAccount 
        /// </summary>
	    public const int SalesAccount  = 4;
	             /// <summary>
        /// Property Indexer for ReturnsAccount 
        /// </summary>
	    public const int ReturnsAccount  = 5;
	             /// <summary>
        /// Property Indexer for CostVarianceAccount 
        /// </summary>
	    public const int CostVarianceAccount  = 6;
	             /// <summary>
        /// Property Indexer for CommissionPaid 
        /// </summary>
	    public const int CommissionPaid  = 7;
	             /// <summary>
        /// Property Indexer for CommissionRate 
        /// </summary>
	    public const int CommissionRate  = 8;
	             /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 9;
	             /// <summary>
        /// Property Indexer for DateLastMaintained 
        /// </summary>
	    public const int DateLastMaintained  = 10;
	             /// <summary>
        /// Property Indexer for DefaultPriceListCode 
        /// </summary>
	    public const int DefaultPriceListCode  = 11;
	             /// <summary>
        /// Property Indexer for DateInactive 
        /// </summary>
	    public const int DateInactive  = 12;
	             /// <summary>
        /// Property Indexer for DamagedGoodsAccount 
        /// </summary>
	    public const int DamagedGoodsAccount  = 13;
	             /// <summary>
        /// Property Indexer for InternalUsageAccount 
        /// </summary>
	    public const int InternalUsageAccount  = 14;
	     
        #endregion
	    }

	
	}
}
	