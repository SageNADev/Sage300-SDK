// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of InventoryWorksheetSerialNumber Constants
     /// </summary>
     public partial class InventoryWorksheetSerialNumber
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0797";

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetSerialNumbe Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for SortCode
               /// </summary>
               public const string SortCode = "SORTCODE";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for SerialNumber
               /// </summary>
               public const string SerialNumber = "SERIALNUMF";

               /// <summary>
               /// Property for SerialCost
               /// </summary>
               public const string SerialCost = "COST";

               /// <summary>
               /// Property for SerialQuantity
               /// </summary>
               public const string SerialQuantity = "SCOUNT";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetSerialNumbe Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for SortCode
               /// </summary>
               public const int SortCode = 2;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 3;

               /// <summary>
               /// Property Indexer for SerialNumber
               /// </summary>
               public const int SerialNumber = 4;

               /// <summary>
               /// Property Indexer for SerialCost
               /// </summary>
               public const int SerialCost = 6;

               /// <summary>
               /// Property Indexer for SerialQuantity
               /// </summary>
               public const int SerialQuantity = 50;

          }
          #endregion

     }
}
