// Copyright (c) 2026 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of MaskStructure Constants
    /// </summary>
    public partial class MaskStructure
    {
        #region Constants

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0805";

        #endregion

        #region Contains list of MaskStructure Field Constants

        /// <summary>
        /// Contains list of MaskStructure Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Structure Code
            /// </summary>
            public const string StructureCode = "MASKCODE";

            /// <summary>
            /// Mask Type
            /// </summary>
            public const string MaskType = "MASKTYPE";

            /// <summary>
            /// Description
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Prefix
            /// </summary>
            public const string Prefix = "PREFIX";

            /// <summary>
            /// Segment Type 1
            /// </summary>
            public const string SegmentType1 = "SEGTYPE1";

            /// <summary>
            /// Segment Type 2
            /// </summary>
            public const string SegmentType2 = "SEGTYPE2";

            /// <summary>
            /// Segment Type 3
            /// </summary>
            public const string SegmentType3 = "SEGTYPE3";

            /// <summary>
            /// Segment Type 4
            /// </summary>
            public const string SegmentType4 = "SEGTYPE4";

            /// <summary>
            /// Segment Type 5
            /// </summary>
            public const string SegmentType5 = "SEGTYPE5";

            /// <summary>
            /// Segment Length 1
            /// </summary>
            public const string SegmentLength1 = "SEGLEN1";

            /// <summary>
            /// Segment Length 2
            /// </summary>
            public const string SegmentLength2 = "SEGLEN2";

            /// <summary>
            /// Segment Length 3
            /// </summary>
            public const string SegmentLength3 = "SEGLEN3";

            /// <summary>
            /// Segment Length 4
            /// </summary>
            public const string SegmentLength4 = "SEGLEN4";

            /// <summary>
            /// Segment Length 5
            /// </summary>
            public const string SegmentLength5 = "SEGLEN5";

            /// <summary>
            /// Segment Separator 1
            /// </summary>
            public const string SegmentSeparator1 = "SEGSEPAR1";

            /// <summary>
            /// Segment Separator 2
            /// </summary>
            public const string SegmentSeparator2 = "SEGSEPAR2";

            /// <summary>
            /// Segment Separator 3
            /// </summary>
            public const string SegmentSeparator3 = "SEGSEPAR3";

            /// <summary>
            /// Segment Separator 4
            /// </summary>
            public const string SegmentSeparator4 = "SEGSEPAR4";

            /// <summary>
            /// Segment Separator 5
            /// </summary>
            public const string SegmentSeparator5 = "SEGSEPAR5";

            /// <summary>
            /// Increment 1
            /// </summary>
            public const string Increment1 = "INCREMEN1";

            /// <summary>
            /// Increment 2
            /// </summary>
            public const string Increment2 = "INCREMEN2";

            /// <summary>
            /// Increment 3
            /// </summary>
            public const string Increment3 = "INCREMEN3";

            /// <summary>
            /// Increment 4
            /// </summary>
            public const string Increment4 = "INCREMEN4";

            /// <summary>
            /// Increment 5
            /// </summary>
            public const string Increment5 = "INCREMEN5";

            /// <summary>
            /// Mask Structure
            /// </summary>
            public const string MaskStructureValue = "MASKSTRUCT";

            /// <summary>
            /// Mask Length
            /// </summary>
            public const string MaskLength = "MASKLENGTH";

            /// <summary>
            /// Is Structure Code Used
            /// </summary>
            public const string InUse = "INUSE";
        }

        #endregion

        #region Contains list of MaskStructure Index Constants

        /// <summary>
        /// Contains list of MaskStructure Field Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Structure Code
            /// </summary>
            public const int StructureCode = 1;

            /// <summary>
            /// Mask Type
            /// </summary>
            public const int MaskType = 2;

            /// <summary>   
            /// Description
            /// </summary>
            public const int Description = 3;

            /// <summary>
            /// Prefix
            /// </summary>
            public const int Prefix = 4;

            /// <summary>
            /// Segment Type 1
            /// </summary>
            public const int SegmentType1 = 5;

            /// <summary>
            /// Segment Type 2
            /// </summary>
            public const int SegmentType2 = 6;

            /// <summary>
            /// Segment Type 3
            /// </summary>
            public const int SegmentType3 = 7;

            /// <summary>
            /// Segment Type 4
            /// </summary>
            public const int SegmentType4 = 8;

            /// <summary>
            /// Segment Type 5
            /// </summary>
            public const int SegmentType5 = 9;

            /// <summary>
            /// Segment Length 1
            /// </summary>
            public const int SegmentLength1 = 10;

            /// <summary>
            /// Segment Length 2
            /// </summary>
            public const int SegmentLength2 = 11;

            /// <summary>
            /// Segment Length 3
            /// </summary>
            public const int SegmentLength3 = 12;

            /// <summary>
            /// Segment Length 4
            /// </summary>
            public const int SegmentLength4 = 13;

            /// <summary>
            /// Segment Length 5
            /// </summary>
            public const int SegmentLength5 = 14;

            /// <summary>
            /// Segment Separator 1
            /// </summary>
            public const int SegmentSeparator1 = 15;

            /// <summary>
            /// Segment Separator 2
            /// </summary>
            public const int SegmentSeparator2 = 16;

            /// <summary>
            /// Segment Separator 3
            /// </summary>
            public const int SegmentSeparator3 = 17;

            /// <summary>
            /// Segment Separator 4
            /// </summary>
            public const int SegmentSeparator4 = 18;

            /// <summary>
            /// Segment Separator 5
            /// </summary>
            public const int SegmentSeparator5 = 19;

            /// <summary>
            /// Increment 1
            /// </summary>
            public const int Increment1 = 20;

            /// <summary>
            /// Increment 2
            /// </summary>
            public const int Increment2 = 21;

            /// <summary>
            /// Increment 3
            /// </summary>
            public const int Increment3 = 22;

            /// <summary>
            /// Increment 4
            /// </summary>
            public const int Increment4 = 23;

            /// <summary>
            /// Increment 5
            /// </summary>
            public const int Increment5 = 24;

            /// <summary>
            /// Mask Structure
            /// </summary>
            public const int MaskStructureValue = 50;

            /// <summary>
            /// Mask Length
            /// </summary>
            public const int MaskLength = 51;

            /// <summary>
            /// Is Structure Code Used
            /// </summary>
            public const int InUse = 52;
        }

        #endregion
    }
}
