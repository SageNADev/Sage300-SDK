// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of Adjustment Detail Lot Number Constants
    /// </summary>
    public partial class AdjustmentDetailLotNumber
    {
        #region Public Properties

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0113";

        #endregion

        #region Constants

        /// <summary>
        /// Contains list of Adjustment Detail Lot Number Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Constant for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "ADJENSEQ";

            /// <summary>
            /// Constant for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Constant for LotNumber
            /// </summary>
            public const string LotNumber = "LOTNUMF";

            /// <summary>
            /// Constant for ExpiryDate
            /// </summary>
            public const string ExpiryDate = "EXPIRYDATE";

            /// <summary>
            /// Constant for TransactionQuantity
            /// </summary>
            public const string TransactionQuantity = "QTY";

            /// <summary>
            /// Constant for LotQuantityInStockingUOM
            /// </summary>
            public const string LotQuantityInStockingUOM = "QTYSQ";

            /// <summary>
            /// Constant for LotCost
            /// </summary>
            public const string LotCost = "COST";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of Adjustment Detail Lot Number Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Constant Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Constant Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Constant Indexer for LotNumber
            /// </summary>
            public const int LotNumber = 3;

            /// <summary>
            /// Constant Indexer for ExpiryDate
            /// </summary>
            public const int ExpiryDate = 5;

            /// <summary>
            /// Constant Indexer for TransactionQuantity
            /// </summary>
            public const int TransactionQuantity = 6;

            /// <summary>
            /// Constant Indexer for LotQuantityInStockingUOM
            /// </summary>
            public const int LotQuantityInStockingUOM = 7;

            /// <summary>
            /// Constant Indexer for LotCost
            /// </summary>
            public const int LotCost = 8;

        }
        #endregion
    }
}
