// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of ReceiptDetailSerialNumber Constants
     /// </summary>
     public partial class ReceiptDetailSerialNumber
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0587";

          #region Properties
          /// <summary>
          /// Contains list of ReceiptDetailSerialNumber Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for SequenceNumber
               /// </summary>
               public const string SequenceNumber = "SEQUENCENO";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "LINENO";

               /// <summary>
               /// Property for SerialNumber
               /// </summary>
               public const string SerialNumber = "SERIALNUMF";

               /// <summary>
               /// Property for SerialReturned
               /// </summary>
               public const string SerialReturned = "MOVED";

               /// <summary>
               /// Property for TransactionQuantity
               /// </summary>
               public const string TransactionQuantity = "QTY";

               /// <summary>
               /// Property for SerialQuantityReturned
               /// </summary>
               public const string SerialQuantityReturned = "QTYMOVED";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of ReceiptDetailSerialNumber Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for SequenceNumber
               /// </summary>
               public const int SequenceNumber = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for SerialNumber
               /// </summary>
               public const int SerialNumber = 3;

               /// <summary>
               /// Property Indexer for SerialReturned
               /// </summary>
               public const int SerialReturned = 4;

               /// <summary>
               /// Property Indexer for TransactionQuantity
               /// </summary>
               public const int TransactionQuantity = 51;

               /// <summary>
               /// Property Indexer for SerialQuantityReturned
               /// </summary>
               public const int SerialQuantityReturned = 52;

          }
          #endregion

     }
}
