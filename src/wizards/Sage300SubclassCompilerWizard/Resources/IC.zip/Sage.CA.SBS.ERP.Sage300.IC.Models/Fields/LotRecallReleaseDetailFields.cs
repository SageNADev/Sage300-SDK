// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of RecallReleaseDetail Constants
    /// </summary>
    public partial class LotRecallReleaseDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "IC0820";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get { return new Dictionary<string, string>(); }
        }

        #region Properties

        /// <summary>
        /// Contains list of LotRecallReleaseDetail Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for DetailLineNumber
            /// </summary>
            public const string DetailLineNumber = "DETAILNUM";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of LotRecallReleaseDetail Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 3;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 4;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 5;

            /// <summary>
            /// Property Indexer for DetailLineNumber
            /// </summary>
            public const int DetailLineNumber = 6;

        }

        #endregion

    }
}
