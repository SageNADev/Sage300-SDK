﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class TransactionHistoryItem
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0280";

        #region Properties

        /// <summary>
        /// Contains list of TransactionHistory Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for AccountSetCode
            /// </summary>
            public const string AccountSetCode = "ACCTSET";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for DayEndNumber
            /// </summary>
            public const string DayEndNumber = "DAYENDSEQ";

            /// <summary>
            /// Property for TransactionSequence
            /// </summary>
            public const string TransactionSequence = "ENTRYSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUM";

            /// <summary>
            /// Property for SourceApplication
            /// </summary>
            public const string SourceApplication = "APP";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for SourceCurrency
            /// </summary>
            public const string SourceCurrency = "SRCCURR";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "EXRATE";

            /// <summary>
            /// Property for ExtendedCostSource
            /// </summary>
            public const string ExtendedCostSource = "SRCEXTCST";

            /// <summary>
            /// Property for ExtendedCostFunctional
            /// </summary>
            public const string ExtendedCostFunctional = "HOMEEXTCST";

            /// <summary>
            /// Property for DrillDownType
            /// </summary>
            public const string DrillDownType = "DRILSRCTY";

            /// <summary>
            /// Property for DrillDownLinkNumber
            /// </summary>
            public const string DrillDownLinkNumber = "DRILLDWNLK";

            /// <summary>
            /// Property for DrillDownApplicationSource
            /// </summary>
            public const string DrillDownApplicationSource = "DRILAPP";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for DetailComponentNumber
            /// </summary>
            public const string DetailComponentNumber = "COMPNUM";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for FormattedItemNumber
            /// </summary>
            public const string FormattedItemNumber = "FMTITEMNO";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for InvoiceNumber
            /// </summary>
            public const string InvoiceNumber = "INVNUMBER";

        }

        #endregion

   

        /// <summary>
        /// Contains list of TransactionHistory Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for AccountSetCode
            /// </summary>
            public const int AccountSetCode = 1;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 2;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 3;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 4;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 5;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 6;

            /// <summary>
            /// Property Indexer for DayEndNumber
            /// </summary>
            public const int DayEndNumber = 7;

            /// <summary>
            /// Property Indexer for TransactionSequence
            /// </summary>
            public const int TransactionSequence = 8;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 9;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 10;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 11;

            /// <summary>
            /// Property Indexer for SourceApplication
            /// </summary>
            public const int SourceApplication = 12;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionTypes = 13;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 14;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 15;

            /// <summary>
            /// Property Indexer for SourceCurrency
            /// </summary>
            public const int SourceCurrency = 16;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 17;

            /// <summary>
            /// Property Indexer for ExtendedCostSource
            /// </summary>
            public const int ExtendedCostSource = 18;

            /// <summary>
            /// Property Indexer for ExtendedCostFunctional
            /// </summary>
            public const int ExtendedCostFunctional = 19;

            /// <summary>
            /// Property Indexer for DrillDownType
            /// </summary>
            public const int DrillDownType = 20;

            /// <summary>
            /// Property Indexer for DrillDownLinkNumber
            /// </summary>
            public const int DrillDownLinkNumber = 21;

            /// <summary>
            /// Property Indexer for DrillDownApplicationSource
            /// </summary>
            public const int DrillDownApplicationSource = 22;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 23;

            /// <summary>
            /// Property Indexer for DetailComponentNumber
            /// </summary>
            public const int DetailComponentNumber = 24;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 25;

            /// <summary>
            /// Property Indexer for FormattedItemNumber
            /// </summary>
            public const int FormattedItemNumber = 30;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 31;

            /// <summary>
            /// Property Indexer for InvoiceNumber
            /// </summary>
            public const int InvoiceNumber = 32;
        }
    }
} 
