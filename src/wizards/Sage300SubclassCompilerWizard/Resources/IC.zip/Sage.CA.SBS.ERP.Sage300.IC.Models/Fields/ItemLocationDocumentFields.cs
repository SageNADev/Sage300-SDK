// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of ItemLocationDocument Constants
	/// </summary>
	public partial class ItemLocationDocument
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "IC0296";

		#region Properties

		/// <summary>
		/// Contains list of ItemLocationDocument Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for DocumentType
			/// </summary>
			public const string DocumentType = "DOCTYPE";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "DOCNUM";

			/// <summary>
			/// Property for DetailLineUniquifier
			/// </summary>
			public const string DetailLineUniquifier = "LINENUM";

			/// <summary>
			/// Property for ComponentNumber
			/// </summary>
			public const string ComponentNumber = "COMPNUM";

			/// <summary>
			/// Property for DocumentSequenceNumber
			/// </summary>
			public const string DocumentSequenceNumber = "DOCUNIQ";

			/// <summary>
			/// Property for DocumentDate
			/// </summary>
			public const string DocumentDate = "DOCDATE";

			/// <summary>
			/// Property for CustomerVendorNumber
			/// </summary>
			public const string CustomerVendorNumber = "CVNUMBER";

			/// <summary>
			/// Property for CustomerVendorName
			/// </summary>
			public const string CustomerVendorName = "CVNAME";

			/// <summary>
			/// Property for ExpectedShippingArrivalDate
			/// </summary>
			public const string ExpectedShippingArrivalDate = "EXPECTDATE";

			/// <summary>
			/// Property for DocumentLocation
			/// </summary>
			public const string DocumentLocation = "DOCLOC";

			/// <summary>
			/// Property for QtyInStockingUnit
			/// </summary>
			public const string QtyInStockingUnit = "QUANTITY";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ItemLocationDocument Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 1;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 2;

			/// <summary>
			/// Property Indexer for DocumentType
			/// </summary>
			public const int DocumentType = 3;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 4;

			/// <summary>
			/// Property Indexer for DetailLineUniquifier
			/// </summary>
			public const int DetailLineUniquifier = 5;

			/// <summary>
			/// Property Indexer for ComponentNumber
			/// </summary>
			public const int ComponentNumber = 6;

			/// <summary>
			/// Property Indexer for DocumentSequenceNumber
			/// </summary>
			public const int DocumentSequenceNumber = 7;

			/// <summary>
			/// Property Indexer for DocumentDate
			/// </summary>
			public const int DocumentDate = 8;

			/// <summary>
			/// Property Indexer for CustomerVendorNumber
			/// </summary>
			public const int CustomerVendorNumber = 9;

			/// <summary>
			/// Property Indexer for CustomerVendorName
			/// </summary>
			public const int CustomerVendorName = 10;

			/// <summary>
			/// Property Indexer for ExpectedShippingArrivalDate
			/// </summary>
			public const int ExpectedShippingArrivalDate = 11;

			/// <summary>
			/// Property Indexer for DocumentLocation
			/// </summary>
			public const int DocumentLocation = 12;

			/// <summary>
			/// Property Indexer for QtyInStockingUnit
			/// </summary>
			public const int QtyInStockingUnit = 13;

		}

		#endregion

	}
}
