﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of OptionalFieldHeader Constants 
    /// </summary>
    public partial class OptionalFieldHeader
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0378";

        /// <summary>
        /// Contains list of OptionalFieldHeader Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            
            /// <summary>
            /// Property for Location 
            /// </summary>
            public const string Location = "LOCATION";
           
            /// <summary>
            /// Property for NumberofValues 
            /// </summary>
            public const string NumberOfValues = "VALUES";

            #endregion
        }


        /// <summary>
        /// Contains list of OptionalFieldHeader Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
           
            /// <summary>
            /// Property Indexer for Location 
            /// </summary>
            public const int Location = 1;
           
            /// <summary>
            /// Property Indexer for NumberofValues 
            /// </summary>
            public const int NumberOfValues = 2;

            #endregion
        }


    }
}
