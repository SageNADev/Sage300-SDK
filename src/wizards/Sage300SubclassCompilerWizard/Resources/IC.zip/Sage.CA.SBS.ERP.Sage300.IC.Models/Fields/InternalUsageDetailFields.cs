﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of InternalUsageDetail Constants
    /// </summary>
    public partial class InternalUsageDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0286";

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageDetail Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QUANTITY";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for ConversionFactor
            /// </summary>
            public const string ConversionFactor = "CONVERSION";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTCOST";

            /// <summary>
            /// Property for SerialNumbers
            /// </summary>
            public const string SerialNumbers = "SERIALNO";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "COMMENTS";

            /// <summary>
            /// Property for ManufacturersItemNumber
            /// </summary>
            public const string ManufacturersItemNumber = "MANITEMNO";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for DetailLineNumber
            /// </summary>
            public const string DetailLineNumber = "DETAILNUM";

            /// <summary>
            /// Property for GLAccount
            /// </summary>
            public const string GLAccount = "GLACCT";

            /// <summary>
            /// Property for EmployeeNumber
            /// </summary>
            public const string EmployeeNumber = "EMPLOYEENO";

            /// <summary>
            /// Property for SageFixedAssetsAttached
            /// </summary>
            public const string SageFixedAssetsAttached = "FASDETAIL";

            /// <summary>
            /// Property for NumberOfSerials
            /// </summary>
            public const string NumberOfSerials = "SERIALQTY";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "LOTQTY";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for RevisionListLineNumber
            /// </summary>
            public const string RevisionListLineNumber = "REVLINE";

            /// <summary>
            /// Property for InterprocessCommID
            /// </summary>
            public const string InterprocessCommID = "IPCID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            public const string ForcePopupSN = "FORCEPOPSN";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            public const string PopupSN = "POPUPSN";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            public const string CloseSN = "CLOSESN";

            /// <summary>
            /// Property for LTSetID
            /// </summary>
            public const string LTSetID = "LTSETID";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            public const string ForcePopupLT = "FORCEPOPLT";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            public const string PopupLT = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            public const string CloseLT = "CLOSELT";

            /// <summary>
            /// Property for UnformattedItemNumber
            /// </summary>
            public const string UnformattedItemNumber = "UNFMTITMNO";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for Database
            /// </summary>
            public const string Database = "FASDB";

            /// <summary>
            /// Property for Company
            /// </summary>
            public const string Company = "FASCMP";

            /// <summary>
            /// Property for Template
            /// </summary>
            public const string Template = "FASTMPL";

            /// <summary>
            /// Property for AssetDescription
            /// </summary>
            public const string AssetDescription = "TEXTDESC";

            /// <summary>
            /// Property for SeparateQuantities
            /// </summary>
            public const string SeparateQuantities = "SEPQTY";

            /// <summary>
            /// Property for AssetQuantity
            /// </summary>
            public const string AssetQuantity = "FASQTY";

            /// <summary>
            /// Property for UnitsOfMeasure
            /// </summary>
            public const string UnitsOfMeasure = "UOM";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMTHC";

            /// <summary>
            /// Property for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Property for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Property for QuantityperLot
            /// </summary>
            public const string QuantityperLot = "XPERLOTQTY";

            /// <summary>
            /// Property for AllocateFromSerial
            /// </summary>
            public const string AllocateFromSerial = "SALLOCFROM";

            /// <summary>
            /// Property for AllocateFromLot
            /// </summary>
            public const string AllocateFromLot = "LALLOCFROM";

            /// <summary>
            /// Property for SerialLotWindowHandle
            /// </summary>
            public const string SerialLotWindowHandle = "METERHWND";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageDetail Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 3;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 4;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 5;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 6;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 7;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 8;

            /// <summary>
            /// Property Indexer for ConversionFactor
            /// </summary>
            public const int ConversionFactor = 9;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 10;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 11;

            /// <summary>
            /// Property Indexer for SerialNumbers
            /// </summary>
            public const int SerialNumbers = 12;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 13;

            /// <summary>
            /// Property Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 14;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 15;

            /// <summary>
            /// Property Indexer for DetailLineNumber
            /// </summary>
            public const int DetailLineNumber = 16;

            /// <summary>
            /// Property Indexer for GLAccount
            /// </summary>
            public const int GLAccount = 17;

            /// <summary>
            /// Property Indexer for EmployeeNumber
            /// </summary>
            public const int EmployeeNumber = 18;

            /// <summary>
            /// Property Indexer for SageFixedAssetsAttached
            /// </summary>
            public const int SageFixedAssetsAttached = 19;

            /// <summary>
            /// Property Indexer for NumberOfSerials
            /// </summary>
            public const int NumberOfSerials = 20;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 21;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 41;

            /// <summary>
            /// Property Indexer for RevisionListLineNumber
            /// </summary>
            public const int RevisionListLineNumber = 42;

            /// <summary>
            /// Property Indexer for InterprocessCommID
            /// </summary>
            public const int InterprocessCommID = 43;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSN = 44;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            public const int PopupSN = 45;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            public const int CloseSN = 46;

            /// <summary>
            /// Property Indexer for LTSetID
            /// </summary>
            public const int LTSetID = 47;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLT = 48;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            public const int PopupLT = 49;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            public const int CloseLT = 50;

            /// <summary>
            /// Property Indexer for UnformattedItemNumber
            /// </summary>
            public const int UnformattedItemNumber = 51;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 52;

            /// <summary>
            /// Property Indexer for Database
            /// </summary>
            public const int Database = 53;

            /// <summary>
            /// Property Indexer for Company
            /// </summary>
            public const int Company = 54;

            /// <summary>
            /// Property Indexer for Template
            /// </summary>
            public const int Template = 55;

            /// <summary>
            /// Property Indexer for AssetDescription
            /// </summary>
            public const int AssetDescription = 56;

            /// <summary>
            /// Property Indexer for SeparateQuantities
            /// </summary>
            public const int SeparateQuantities = 57;

            /// <summary>
            /// Property Indexer for AssetQuantity
            /// </summary>
            public const int AssetQuantity = 58;

            /// <summary>
            /// Property Indexer for UnitsOfMeasure
            /// </summary>
            public const int UnitsOfMeasure = 59;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 60;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 61;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 62;

            /// <summary>
            /// Property Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 63;

            /// <summary>
            /// Property Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 64;

            /// <summary>
            /// Property Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 65;

            /// <summary>
            /// Property Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 66;

        }

        #endregion

    }
}
