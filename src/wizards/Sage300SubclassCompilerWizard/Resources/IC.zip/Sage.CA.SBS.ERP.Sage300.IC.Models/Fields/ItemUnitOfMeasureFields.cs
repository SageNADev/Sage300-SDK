﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of UnitsofMeasure Constants 
    /// </summary>
    public partial class ItemUnitOfMeasure
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0750";

        /// <summary>
        /// Contains list of UnitsofMeasure Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for UnitOfMeasure 
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for Conversion 
            /// </summary>
            public const string Conversion = "CONVERSION";

            /// <summary>
            /// Property for Factor 
            /// </summary>
            public const string Factor = "FACTOR";

            #endregion
        }


        /// <summary>
        /// Contains list of UnitsofMeasure Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 1;

            /// <summary>
            /// Property Indexer for UnitOfMeasure 
            /// </summary>
            public const int UnitOfMeasure = 2;

            /// <summary>
            /// Property Indexer for Conversion 
            /// </summary>
            public const int Conversion = 3;

            /// <summary>
            /// Property Indexer for Factor 
            /// </summary>
            public const int Factor = 4;

            #endregion
        }


    }
}
