﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CustomerItemNumber Constants 
    /// </summary>
    public partial class CustomerItemNumber
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0319";

        /// <summary>
        /// Contains list of CustomerItemNumbers Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "ITEMNO";
            /// <summary>
            /// Property for CustomerNumber 
            /// </summary>
            public const string CustomerNumber = "CUSTNO";
            /// <summary>
            /// Property for CustomerName 
            /// </summary>
            public const string CustomerName = "CUSTNAME";
            /// <summary>
            /// Property for CustomersItemNumber 
            /// </summary>
            public const string CustomersItemNumber = "CITEMNO";
            /// <summary>
            /// Property for CustomersItemDescription 
            /// </summary>
            public const string CustomersItemDescription = "CITEMDESC";
            /// <summary>
            /// Property for UnitOfMeasure 
            /// </summary>
            public const string UnitOfMeasure = "UNIT";
            /// <summary>
            /// Property for Comments 
            /// </summary>
            public const string Comments = "COMMENT";
            /// <summary>
            /// Property for Instructions 
            /// </summary>
            public const string Instructions = "INSTRUCTIO";
            /// <summary>
            /// Property for FmtItemNumber 
            /// </summary>
            public const string FmtItemNumber = "FMTITEMNO";

            #endregion
        }


        /// <summary>
        /// Contains list of CustomerItemNumbers Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 1;
            /// <summary>
            /// Property Indexer for CustomerNumber 
            /// </summary>
            public const int CustomerNumber = 2;
            /// <summary>
            /// Property Indexer for CustomerName 
            /// </summary>
            public const int CustomerName = 3;
            /// <summary>
            /// Property Indexer for CustomersItemNumber 
            /// </summary>
            public const int CustomersItemNumber = 4;
            /// <summary>
            /// Property Indexer for CustomersItemDescription 
            /// </summary>
            public const int CustomersItemDescription = 5;
            /// <summary>
            /// Property Indexer for UnitOfMeasure 
            /// </summary>
            public const int UnitOfMeasure = 6;
            /// <summary>
            /// Property Indexer for Comments 
            /// </summary>
            public const int Comments = 7;
            /// <summary>
            /// Property Indexer for Instructions 
            /// </summary>
            public const int Instructions = 8;
            /// <summary>
            /// Property Indexer for FmtItemNumber 
            /// </summary>
            public const int FmtItemNumber = 12;

            #endregion
        }


    }
}
