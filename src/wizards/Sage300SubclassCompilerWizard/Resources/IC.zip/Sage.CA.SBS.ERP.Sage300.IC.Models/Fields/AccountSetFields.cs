﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A Contains list of AccountSets Constants 
    /// </summary>
    public partial class AccountSet
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0100";

        /// <summary>
        /// Contains list of AccountSets Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for AccountSetCode 
            /// </summary>
            public const string AccountSetCode = "CNTLACCT";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for CostingMethod 
            /// </summary>
            public const string CostingMethod = "COSTMETHOD";

            /// <summary>
            /// Property for InventoryControlAccount 
            /// </summary>
            public const string InventoryControlAccount = "INVACCT";

            /// <summary>
            /// Property for PayablesClearingAccount 
            /// </summary>
            public const string PayablesClearingAccount = "PAYABLACCT";

            /// <summary>
            /// Property for AdjustmentOrWriteOffAccount 
            /// </summary>
            public const string AdjustmentOrWriteOffAccount = "ADJWRTACCT";

            /// <summary>
            /// Property for AssemblyCostCreditAccount 
            /// </summary>
            public const string AssemblyCostCreditAccount = "ASSMACCT";

            /// <summary>
            /// Property for NonstockClearingAccount 
            /// </summary>
            public const string NonstockClearingAccount = "NONSTKACCT";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "INACTIVE";

            /// <summary>
            /// Property for Status 
            /// Added for finder grid
            /// Display the Account Sets Status
            /// </summary>
            public const string StatusDescription = "INACTIVE";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for DateInactive 
            /// </summary>
            public const string DateInactive = "DATEINACTV";

            /// <summary>
            /// Property for TransferClearingAccount 
            /// </summary>
            public const string TransferClearingAccount = "TRANSACCT";

            /// <summary>
            /// Property for ShipmentClearingAccount 
            /// </summary>
            public const string ShipmentClearingAccount = "SHIPACCT";

            /// <summary>
            /// Property for DisassemblyExpenseAccount 
            /// </summary>
            public const string DisassemblyExpenseAccount = "DISEXPACCT";

            /// <summary>
            /// Property for PhysicalInventoryAdjAcct 
            /// </summary>
            public const string PhysicalInventoryAdjAcct = "PHINVAACCT";

            /// <summary>
            /// Property for CreditOrDebitNoteClearingAcct 
            /// </summary>
            public const string CreditOrDebitNoteClearingAcct = "CRNCLRACCT";

            /// <summary>
            /// Property for CostingMethodName
            /// This is required for Finder
            /// </summary>
            public const string CostingMethodName = "COSTMETHOD";

            #endregion
        }

        /// <summary>
        /// Contains list of AccountSets Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for AccountSetCode 
            /// </summary>
            public const int AccountSetCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for CostingMethod 
            /// </summary>
            public const int CostingMethod = 3;

            /// <summary>
            /// Property Indexer for InventoryControlAccount 
            /// </summary>
            public const int InventoryControlAccount = 4;

            /// <summary>
            /// Property Indexer for PayablesClearingAccount 
            /// </summary>
            public const int PayablesClearingAccount = 5;

            /// <summary>
            /// Property Indexer for AdjustmentOrWriteOffAccount 
            /// </summary>
            public const int AdjustmentOrWriteOffAccount = 6;

            /// <summary>
            /// Property Indexer for AssemblyCostCreditAccount 
            /// </summary>
            public const int AssemblyCostCreditAccount = 7;

            /// <summary>
            /// Property Indexer for NonstockClearingAccount 
            /// </summary>
            public const int NonstockClearingAccount = 8;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 9;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 10;

            /// <summary>
            /// Property Indexer for DateInactive 
            /// </summary>
            public const int DateInactive = 11;

            /// <summary>
            /// Property Indexer for TransferClearingAccount 
            /// </summary>
            public const int TransferClearingAccount = 12;

            /// <summary>
            /// Property Indexer for ShipmentClearingAccount 
            /// </summary>
            public const int ShipmentClearingAccount = 13;

            /// <summary>
            /// Property Indexer for DisassemblyExpenseAccount 
            /// </summary>
            public const int DisassemblyExpenseAccount = 14;

            /// <summary>
            /// Property Indexer for PhysicalInventoryAdjAcct 
            /// </summary>
            public const int PhysicalInventoryAdjAcct = 15;

            /// <summary>
            /// Property Indexer for CreditOrDebitNoteClearingAcct 
            /// </summary>
            public const int CreditOrDebitNoteClearingAcct = 16;

            #endregion
        }
    }
}
