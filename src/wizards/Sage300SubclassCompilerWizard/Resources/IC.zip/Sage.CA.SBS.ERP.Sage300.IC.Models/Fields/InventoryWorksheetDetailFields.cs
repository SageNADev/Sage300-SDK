// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of InventoryWorksheetDetail Constants
     /// </summary>
     public partial class InventoryWorksheetDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0780";

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetDetail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for SortCode
               /// </summary>
               public const string SortCode = "SORTCODE";

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for UnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for QuantityCounted
               /// </summary>
               public const string QuantityCounted = "QTYCOUNTED";

               /// <summary>
               /// Property for ConversionFactor
               /// </summary>
               public const string ConversionFactor = "CONVERSION";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetDetail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for SortCode
               /// </summary>
               public const int SortCode = 2;

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 3;

               /// <summary>
               /// Property Indexer for UnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 4;

               /// <summary>
               /// Property Indexer for QuantityCounted
               /// </summary>
               public const int QuantityCounted = 5;

               /// <summary>
               /// Property Indexer for ConversionFactor
               /// </summary>
               public const int ConversionFactor = 6;

          }
          #endregion

     }
}
