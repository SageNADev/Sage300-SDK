// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of SerialNumberHistory Constants
	/// </summary>
	public partial class SerialNumberHistory
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "IC0835";

		#region Properties

		/// <summary>
		/// Contains list of SerialNumberHistory Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for UnformattedSerialNumber
			/// </summary>
			public const string UnformattedSerialNumber = "SERIALNUM";

			/// <summary>
			/// Property for UnformattedItemNumber
			/// </summary>
			public const string UnformattedItemNumber = "ITEMNUM";

			/// <summary>
			/// Property for DayEndNumber
			/// </summary>
			public const string DayEndNumber = "DAYENDSEQ";

			/// <summary>
			/// Property for TransactionSequence
			/// </summary>
			public const string TransactionSequence = "ENTRYSEQ";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "LINENO";

			/// <summary>
			/// Property for ComponentNumber
			/// </summary>
			public const string ComponentNumber = "COMPNUM";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for SourceApplication
			/// </summary>
			public const string SourceApplication = "APP";

			/// <summary>
			/// Property for TransactionType
			/// </summary>
			public const string TransactionType = "TRANSTYPE";

			/// <summary>
			/// Property for TransactionDate
			/// </summary>
			public const string TransactionDate = "TRANSDATE";

			/// <summary>
			/// Property for Stocked
			/// </summary>
			public const string Stocked = "STOCKED";

			/// <summary>
			/// Property for ExtendedCost
			/// </summary>
			public const string ExtendedCost = "COST";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "DOCNUM";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for FiscalYear
			/// </summary>
			public const string FiscalYear = "FISCYEAR";

			/// <summary>
			/// Property for FiscalPeriod
			/// </summary>
			public const string FiscalPeriod = "FISCPERIOD";

			/// <summary>
			/// Property for WarrantyCode
			/// </summary>
			public const string WarrantyCode = "WARRCODE";

			/// <summary>
			/// Property for Registered
			/// </summary>
			public const string Registered = "REGISTERED";

			/// <summary>
			/// Property for DateRegistered
			/// </summary>
			public const string DateRegistered = "REGISTDATE";

			/// <summary>
			/// Property for CustomerVendorNumber
			/// </summary>
			public const string CustomerVendorNumber = "CUSTVEND";

			/// <summary>
			/// Property for WarrantyPeriod1IsInUse
			/// </summary>
			public const string WarrantyPeriod1IsInUse = "INUSE1";

			/// <summary>
			/// Property for WarrantyPeriod1ExpiryDate
			/// </summary>
			public const string WarrantyPeriod1ExpiryDate = "DATE1";

			/// <summary>
			/// Property for WarrantyPeriod1EffectiveDate
			/// </summary>
			public const string WarrantyPeriod1EffectiveDate = "EFFDATE1";

			/// <summary>
			/// Property for WarrantyPeriod1Lifetime
			/// </summary>
			public const string WarrantyPeriod1Lifetime = "LIFEWARR1";

			/// <summary>
			/// Property for WarrantyPeriod2IsInUse
			/// </summary>
			public const string WarrantyPeriod2IsInUse = "INUSE2";

			/// <summary>
			/// Property for WarrantyPeriod2ExpiryDate
			/// </summary>
			public const string WarrantyPeriod2ExpiryDate = "DATE2";

			/// <summary>
			/// Property for WarrantyPeriod2EffectiveDate
			/// </summary>
			public const string WarrantyPeriod2EffectiveDate = "EFFDATE2";

			/// <summary>
			/// Property for WarrantyPeriod2Lifetime
			/// </summary>
			public const string WarrantyPeriod2Lifetime = "LIFEWARR2";

			/// <summary>
			/// Property for WarrantyPeriod3IsInUse
			/// </summary>
			public const string WarrantyPeriod3IsInUse = "INUSE3";

			/// <summary>
			/// Property for WarrantyPeriod3ExpiryDate
			/// </summary>
			public const string WarrantyPeriod3ExpiryDate = "DATE3";

			/// <summary>
			/// Property for WarrantyPeriod3EffectiveDate
			/// </summary>
			public const string WarrantyPeriod3EffectiveDate = "EFFDATE3";

			/// <summary>
			/// Property for WarrantyPeriod3Lifetime
			/// </summary>
			public const string WarrantyPeriod3Lifetime = "LIFEWARR3";

			/// <summary>
			/// Property for WarrantyPeriod4IsInUse
			/// </summary>
			public const string WarrantyPeriod4IsInUse = "INUSE4";

			/// <summary>
			/// Property for WarrantyPeriod4ExpiryDate
			/// </summary>
			public const string WarrantyPeriod4ExpiryDate = "DATE4";

			/// <summary>
			/// Property for WarrantyPeriod4EffectiveDate
			/// </summary>
			public const string WarrantyPeriod4EffectiveDate = "EFFDATE4";

			/// <summary>
			/// Property for WarrantyPeriod4Lifetime
			/// </summary>
			public const string WarrantyPeriod4Lifetime = "LIFEWARR4";

			/// <summary>
			/// Property for WarrantyPeriod5IsInUse
			/// </summary>
			public const string WarrantyPeriod5IsInUse = "INUSE5";

			/// <summary>
			/// Property for WarrantyPeriod5ExpiryDate
			/// </summary>
			public const string WarrantyPeriod5ExpiryDate = "DATE5";

			/// <summary>
			/// Property for WarrantyPeriod5EffectiveDate
			/// </summary>
			public const string WarrantyPeriod5EffectiveDate = "EFFDATE5";

			/// <summary>
			/// Property for WarrantyPeriod5Lifetime
			/// </summary>
			public const string WarrantyPeriod5Lifetime = "LIFEWARR5";

			/// <summary>
			/// Property for DrillDownType
			/// </summary>
			public const string DrillDownType = "DRILSRCTY";

			/// <summary>
			/// Property for DrillDownLinkNumber
			/// </summary>
			public const string DrillDownLinkNumber = "DRILLDWNLK";

			/// <summary>
			/// Property for EnteredBy
			/// </summary>
			public const string EnteredBy = "ENTEREDBY";

			/// <summary>
			/// Property for WarrantyDescription
			/// </summary>
			public const string WarrantyDescription = "WARRDESC";

			/// <summary>
			/// Property for WarrantyPeriod1Description
			/// </summary>
			public const string WarrantyPeriod1Description = "DESC1";

			/// <summary>
			/// Property for WarrantyPeriod2Description
			/// </summary>
			public const string WarrantyPeriod2Description = "DESC2";

			/// <summary>
			/// Property for WarrantyPeriod3Description
			/// </summary>
			public const string WarrantyPeriod3Description = "DESC3";

			/// <summary>
			/// Property for WarrantyPeriod4Description
			/// </summary>
			public const string WarrantyPeriod4Description = "DESC4";

			/// <summary>
			/// Property for WarrantyPeriod5Description
			/// </summary>
			public const string WarrantyPeriod5Description = "DESC5";

			/// <summary>
			/// Property for Status
			/// </summary>
			public const string Status = "STATUS";

			/// <summary>
			/// Property for OEInvoiceNumber
			/// </summary>
			public const string OEInvoiceNumber = "OEINVNUM";

			/// <summary>
			/// Property for POInvoiceNumber
			/// </summary>
			public const string POInvoiceNumber = "POINVNUM";

			/// <summary>
			/// Property for POCreditNoteNumber
			/// </summary>
			public const string POCreditNoteNumber = "POCRNNUM";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of SerialNumberHistory Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for UnformattedSerialNumber
			/// </summary>
			public const int UnformattedSerialNumber = 1;

			/// <summary>
			/// Property Indexer for UnformattedItemNumber
			/// </summary>
			public const int UnformattedItemNumber = 2;

			/// <summary>
			/// Property Indexer for DayEndNumber
			/// </summary>
			public const int DayEndNumber = 3;

			/// <summary>
			/// Property Indexer for TransactionSequence
			/// </summary>
			public const int TransactionSequence = 4;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 5;

			/// <summary>
			/// Property Indexer for ComponentNumber
			/// </summary>
			public const int ComponentNumber = 6;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 7;

			/// <summary>
			/// Property Indexer for SourceApplication
			/// </summary>
			public const int SourceApplication = 8;

			/// <summary>
			/// Property Indexer for TransactionType
			/// </summary>
			public const int TransactionType = 9;

			/// <summary>
			/// Property Indexer for TransactionDate
			/// </summary>
			public const int TransactionDate = 10;

			/// <summary>
			/// Property Indexer for Stocked
			/// </summary>
			public const int Stocked = 11;

			/// <summary>
			/// Property Indexer for ExtendedCost
			/// </summary>
			public const int ExtendedCost = 12;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 13;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 14;

			/// <summary>
			/// Property Indexer for FiscalYear
			/// </summary>
			public const int FiscalYear = 15;

			/// <summary>
			/// Property Indexer for FiscalPeriod
			/// </summary>
			public const int FiscalPeriod = 16;

			/// <summary>
			/// Property Indexer for WarrantyCode
			/// </summary>
			public const int WarrantyCode = 17;

			/// <summary>
			/// Property Indexer for Registered
			/// </summary>
			public const int Registered = 18;

			/// <summary>
			/// Property Indexer for DateRegistered
			/// </summary>
			public const int DateRegistered = 19;

			/// <summary>
			/// Property Indexer for CustomerVendorNumber
			/// </summary>
			public const int CustomerVendorNumber = 20;

			/// <summary>
			/// Property Indexer for WarrantyPeriod1IsInUse
			/// </summary>
			public const int WarrantyPeriod1IsInUse = 21;

			/// <summary>
			/// Property Indexer for WarrantyPeriod1ExpiryDate
			/// </summary>
			public const int WarrantyPeriod1ExpiryDate = 22;

			/// <summary>
			/// Property Indexer for WarrantyPeriod1EffectiveDate
			/// </summary>
			public const int WarrantyPeriod1EffectiveDate = 23;

			/// <summary>
			/// Property Indexer for WarrantyPeriod1Lifetime
			/// </summary>
			public const int WarrantyPeriod1Lifetime = 24;

			/// <summary>
			/// Property Indexer for WarrantyPeriod2IsInUse
			/// </summary>
			public const int WarrantyPeriod2IsInUse = 25;

			/// <summary>
			/// Property Indexer for WarrantyPeriod2ExpiryDate
			/// </summary>
			public const int WarrantyPeriod2ExpiryDate = 26;

			/// <summary>
			/// Property Indexer for WarrantyPeriod2EffectiveDate
			/// </summary>
			public const int WarrantyPeriod2EffectiveDate = 27;

			/// <summary>
			/// Property Indexer for WarrantyPeriod2Lifetime
			/// </summary>
			public const int WarrantyPeriod2Lifetime = 28;

			/// <summary>
			/// Property Indexer for WarrantyPeriod3IsInUse
			/// </summary>
			public const int WarrantyPeriod3IsInUse = 29;

			/// <summary>
			/// Property Indexer for WarrantyPeriod3ExpiryDate
			/// </summary>
			public const int WarrantyPeriod3ExpiryDate = 30;

			/// <summary>
			/// Property Indexer for WarrantyPeriod3EffectiveDate
			/// </summary>
			public const int WarrantyPeriod3EffectiveDate = 31;

			/// <summary>
			/// Property Indexer for WarrantyPeriod3Lifetime
			/// </summary>
			public const int WarrantyPeriod3Lifetime = 32;

			/// <summary>
			/// Property Indexer for WarrantyPeriod4IsInUse
			/// </summary>
			public const int WarrantyPeriod4IsInUse = 33;

			/// <summary>
			/// Property Indexer for WarrantyPeriod4ExpiryDate
			/// </summary>
			public const int WarrantyPeriod4ExpiryDate = 34;

			/// <summary>
			/// Property Indexer for WarrantyPeriod4EffectiveDate
			/// </summary>
			public const int WarrantyPeriod4EffectiveDate = 35;

			/// <summary>
			/// Property Indexer for WarrantyPeriod4Lifetime
			/// </summary>
			public const int WarrantyPeriod4Lifetime = 36;

			/// <summary>
			/// Property Indexer for WarrantyPeriod5IsInUse
			/// </summary>
			public const int WarrantyPeriod5IsInUse = 37;

			/// <summary>
			/// Property Indexer for WarrantyPeriod5ExpiryDate
			/// </summary>
			public const int WarrantyPeriod5ExpiryDate = 38;

			/// <summary>
			/// Property Indexer for WarrantyPeriod5EffectiveDate
			/// </summary>
			public const int WarrantyPeriod5EffectiveDate = 39;

			/// <summary>
			/// Property Indexer for WarrantyPeriod5Lifetime
			/// </summary>
			public const int WarrantyPeriod5Lifetime = 40;

			/// <summary>
			/// Property Indexer for DrillDownType
			/// </summary>
			public const int DrillDownType = 41;

			/// <summary>
			/// Property Indexer for DrillDownLinkNumber
			/// </summary>
			public const int DrillDownLinkNumber = 42;

			/// <summary>
			/// Property Indexer for EnteredBy
			/// </summary>
			public const int EnteredBy = 43;

			/// <summary>
			/// Property Indexer for WarrantyDescription
			/// </summary>
			public const int WarrantyDescription = 75;

			/// <summary>
			/// Property Indexer for WarrantyPeriod1Description
			/// </summary>
			public const int WarrantyPeriod1Description = 76;

			/// <summary>
			/// Property Indexer for WarrantyPeriod2Description
			/// </summary>
			public const int WarrantyPeriod2Description = 77;

			/// <summary>
			/// Property Indexer for WarrantyPeriod3Description
			/// </summary>
			public const int WarrantyPeriod3Description = 78;

			/// <summary>
			/// Property Indexer for WarrantyPeriod4Description
			/// </summary>
			public const int WarrantyPeriod4Description = 79;

			/// <summary>
			/// Property Indexer for WarrantyPeriod5Description
			/// </summary>
			public const int WarrantyPeriod5Description = 80;

			/// <summary>
			/// Property Indexer for Status
			/// </summary>
			public const int Status = 81;

			/// <summary>
			/// Property Indexer for OEInvoiceNumber
			/// </summary>
			public const int OEInvoiceNumber = 82;

			/// <summary>
			/// Property Indexer for POInvoiceNumber
			/// </summary>
			public const int POInvoiceNumber = 83;

			/// <summary>
			/// Property Indexer for POCreditNoteNumber
			/// </summary>
			public const int POCreditNoteNumber = 84;

		}

		#endregion

	}
}