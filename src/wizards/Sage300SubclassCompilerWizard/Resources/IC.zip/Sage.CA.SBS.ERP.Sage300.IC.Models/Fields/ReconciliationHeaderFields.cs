// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Contains list of ReconciliationHeader Constants
	/// </summary>
	public partial class ReconciliationHeader
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0825";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of ReconciliationHeader Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "SEQUENCENO";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "DOCNUM";

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for TransactionDate
			/// </summary>
			public const string TransactionDate = "TRANSDATE";

			/// <summary>
			/// Property for TransactionType
			/// </summary>
			public const string TransactionType = "TRANSTYPE";

			/// <summary>
			/// Property for StockUnitOfMeasure
			/// </summary>
			public const string StockUnitOfMeasure = "STOCKUNIT";

			/// <summary>
			/// Property for Quantity
			/// </summary>
			public const string Quantity = "QUANTITY";

			/// <summary>
			/// Property for SerialQuantity
			/// </summary>
			public const string SerialQuantity = "SERIALQTY";

			/// <summary>
			/// Property for LotQuantity
			/// </summary>
			public const string LotQuantity = "LOTQTY";

			/// <summary>
			/// Property for ApplyToInvoiceNumber
			/// </summary>
			public const string ApplyToInvoiceNumber = "APPLYTODOC";

			/// <summary>
			/// Property for Cost
			/// </summary>
			public const string Cost = "ASSETCOST";

			/// <summary>
			/// Property for SerialLotQuantityToProcess
			/// </summary>
			public const string SerialLotQuantityToProcess = "XGENALCQTY";

			/// <summary>
			/// Property for NumberOfLotsToGenerate
			/// </summary>
			public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

			/// <summary>
			/// Property for QuantityperLot
			/// </summary>
			public const string QuantityperLot = "XPERLOTQTY";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

			/// <summary>
			/// Property for AllocateFromSerial
			/// </summary>
			public const string AllocateFromSerial = "SALLOCFROM";

			/// <summary>
			/// Property for AllocateFromLot
			/// </summary>
			public const string AllocateFromLot = "LALLOCFROM";

			/// <summary>
			/// Property for SerialLotWindowHandle
			/// </summary>
			public const string SerialLotWindowHandle = "METERHWND";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of ReconciliationHeader Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 1;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 2;

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 3;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 4;

			/// <summary>
			/// Property Indexer for TransactionDate
			/// </summary>
			public const int TransactionDate = 5;

			/// <summary>
			/// Property Indexer for TransactionType
			/// </summary>
			public const int TransactionType = 6;

			/// <summary>
			/// Property Indexer for StockUnitOfMeasure
			/// </summary>
			public const int StockUnitOfMeasure = 7;

			/// <summary>
			/// Property Indexer for Quantity
			/// </summary>
			public const int Quantity = 8;

			/// <summary>
			/// Property Indexer for SerialQuantity
			/// </summary>
			public const int SerialQuantity = 9;

			/// <summary>
			/// Property Indexer for LotQuantity
			/// </summary>
			public const int LotQuantity = 10;

			/// <summary>
			/// Property Indexer for ApplyToInvoiceNumber
			/// </summary>
			public const int ApplyToInvoiceNumber = 11;

			/// <summary>
			/// Property Indexer for Cost
			/// </summary>
			public const int Cost = 12;

			/// <summary>
			/// Property Indexer for SerialLotQuantityToProcess
			/// </summary>
			public const int SerialLotQuantityToProcess = 30;

			/// <summary>
			/// Property Indexer for NumberOfLotsToGenerate
			/// </summary>
			public const int NumberOfLotsToGenerate = 31;

			/// <summary>
			/// Property Indexer for QuantityperLot
			/// </summary>
			public const int QuantityperLot = 32;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 33;

			/// <summary>
			/// Property Indexer for AllocateFromSerial
			/// </summary>
			public const int AllocateFromSerial = 34;

			/// <summary>
			/// Property Indexer for AllocateFromLot
			/// </summary>
			public const int AllocateFromLot = 35;

			/// <summary>
			/// Property Indexer for SerialLotWindowHandle
			/// </summary>
			public const int SerialLotWindowHandle = 36;

		}

		#endregion

	}
}
