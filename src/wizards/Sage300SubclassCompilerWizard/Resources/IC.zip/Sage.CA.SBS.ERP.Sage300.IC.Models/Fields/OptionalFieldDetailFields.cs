﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of OptionalFields Detail Constants 
    /// </summary>
    public partial class OptionalFieldDetail
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0377";

        /// <summary>
        /// Contains list of OptionalFields Detail Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for Location 
            /// </summary>
            public const string Location = "LOCATION";
            /// <summary>
            /// Property for OptionalField 
            /// </summary>
            public const string OptionalField = "OPTFIELD";
            /// <summary>
            /// Property for DefaultValue 
            /// </summary>
            public const string DefaultValue = "DEFVAL";
            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";
            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";
            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";
            /// <summary>
            /// Property for AllowBlank 
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";
            /// <summary>
            /// Property for Validate 
            /// </summary>
            public const string Validate = "VALIDATE";
            /// <summary>
            /// Property for AutoInsert 
            /// </summary>
            public const string AutoInsert = "INITFLAG";
            /// <summary>
            /// Property for PayablesClearing 
            /// </summary>
            public const string PayablesClearing = "SWPAYCLR";
            /// <summary>
            /// Property for InventoryControl 
            /// </summary>
            public const string InventoryControl = "SWICCTL";
            /// <summary>
            /// Property for NonStockClearing 
            /// </summary>
            public const string NonStockClearing = "SWNSCLR";
            /// <summary>
            /// Property for CostofGoodsSold 
            /// </summary>
            public const string CostOfGoodsSold = "SWCOGS";
            /// <summary>
            /// Property for CostVariance 
            /// </summary>
            public const string CostVariance = "SWCV";
            /// <summary>
            /// Property for AdjustmentWriteOff 
            /// </summary>
            public const string AdjustmentWriteOff = "SWADJWO";
            /// <summary>
            /// Property for WorkinProgress 
            /// </summary>
            public const string WorkinProgress = "SWPMWIP";
            /// <summary>
            /// Property for CostofSales 
            /// </summary>
            public const string CostOfSales = "SWPMCOS";
            /// <summary>
            /// Property for Overhead 
            /// </summary>
            public const string Overhead = "SWPMOH";
            /// <summary>
            /// Property for InventoryControlFromLocation 
            /// </summary>
            public const string InventoryControlFromLocation = "SWICCTLFR";
            /// <summary>
            /// Property for InventoryControlToLocation 
            /// </summary>
            public const string InventoryControlToLocation = "SWICCTLTO";
            /// <summary>
            /// Property for InventoryControlGITLocation 
            /// </summary>
            public const string InventoryControlGitLocation = "SWICCTLGIT";
            /// <summary>
            /// Property for TransferClearing 
            /// </summary>
            public const string TransferClearing = "SWTRCLR";
            /// <summary>
            /// Property for InventoryControlMasterItem 
            /// </summary>
            public const string InventoryControlMasterItem = "SWICCTLMA";
            /// <summary>
            /// Property for InventoryControlComponent 
            /// </summary>
            public const string InventoryControlComponent = "SWICCTLCO";
            /// <summary>
            /// Property for AssemblyCostCredit 
            /// </summary>
            public const string AssemblyCostCredit = "SWACC";
            /// <summary>
            /// Property for DisassemblyExpense 
            /// </summary>
            public const string DisassemblyExpense = "SWDE";
            /// <summary>
            /// Property for Required 
            /// </summary>
            public const string Required = "SWREQUIRED";
            /// <summary>
            /// Property for ValueSet 
            /// </summary>
            public const string ValueSet = "SWSET";
            /// <summary>
            /// Property for InternalUsage 
            /// </summary>
            public const string InternalUsage = "SWICSEXP";
            /// <summary>
            /// Property for TypedDefaultValueFieldIndex 
            /// </summary>
            public const string TypedDefaultValueFieldIndex = "DVINDEX";
            /// <summary>
            /// Property for DefaultTextValue 
            /// </summary>
            public const string DefaultTextValue = "DVIFTEXT";
            /// <summary>
            /// Property for DefaultAmountValue 
            /// </summary>
            public const string DefaultAmountValue = "DVIFMONEY";
            /// <summary>
            /// Property for DefaultNumberValue 
            /// </summary>
            public const string DefaultNumberValue = "DVIFNUM";
            /// <summary>
            /// Property for DefaultIntegerValue 
            /// </summary>
            public const string DefaultIntegerValue = "DVIFLONG";
            /// <summary>
            /// Property for DefaultYesOrNoValue 
            /// </summary>
            public const string DefaultYesOrNoValue = "DVIFBOOL";
            /// <summary>
            /// Property for DefaultDateValue 
            /// </summary>
            public const string DefaultDateValue = "DVIFDATE";
            /// <summary>
            /// Property for DefaultTimeValue 
            /// </summary>
            public const string DefaultTimeValue = "DVIFTIME";
            /// <summary>
            /// Property for OptionalFieldDescription 
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";
            /// <summary>
            /// Property for DefaultValueDescription 
            /// </summary>
            public const string DefaultValueDescription = "VDESC";
            /// <summary>
            /// Property for PayablesClearing1 
            /// </summary>
            public const string PayablesClearing1 = "SWPAYCLR";
            /// <summary>
            /// Property for InventoryControl1 
            /// </summary>
            public const string InventoryControl1 = "SWICCTL";
            /// <summary>
            /// Property for NonStockClearing1 
            /// </summary>
            public const string NonStockClearing1 = "SWNSCLR";
            /// <summary>
            /// Property for CostofGoodsSold1 
            /// </summary>
            public const string CostOfGoodsSold1 = "SWCOGS";
            /// <summary>
            /// Property for CostVariance1 
            /// </summary>
            public const string CostVariance1 = "SWCV";
            /// <summary>
            /// Property for AdjustmentWriteOff1 
            /// </summary>
            public const string AdjustmentWriteOff1 = "SWADJWO";
            /// <summary>
            /// Property for InventoryControlFromLocation1 
            /// </summary>
            public const string InventoryControlFromLocation1 = "SWICCTLFR";
            /// <summary>
            /// Property for InventoryControlToLocation1 
            /// </summary>
            public const string InventoryControlToLocation1 = "SWICCTLTO";
            /// <summary>
            /// Property for InventoryControlGITLocation1 
            /// </summary>
            public const string InventoryControlGitLocation1 = "SWICCTLGIT";
            /// <summary>
            /// Property for TransferClearing1 
            /// </summary>
            public const string TransferClearing1 = "SWTRCLR";
            /// <summary>
            /// Property for InventoryControlMasterItem1 
            /// </summary>
            public const string InventoryControlMasterItem1 = "SWICCTLMA";
            /// <summary>
            /// Property for InventoryControlComponent1 
            /// </summary>
            public const string InventoryControlComponent1 = "SWICCTLCO";
            /// <summary>
            /// Property for AssemblyCostCredit1 
            /// </summary>
            public const string AssemblyCostCredit1 = "SWACC";
            /// <summary>
            /// Property for DisassemblyExpense1 
            /// </summary>
            public const string DisassemblyExpense1 = "SWDE";
            /// <summary>
            /// Property for InternalUsage1 
            /// </summary>
            public const string InternalUsage1 = "SWICSEXP";
            #endregion
        }


        /// <summary>
        /// Contains list of OptionalFields Detail Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for Location 
            /// </summary>
            public const int Location = 1;
            /// <summary>
            /// Property Indexer for OptionalField 
            /// </summary>
            public const int OptionalField = 2;
            /// <summary>
            /// Property Indexer for DefaultValue 
            /// </summary>
            public const int DefaultValue = 3;
            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 4;
            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 5;
            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 6;
            /// <summary>
            /// Property Indexer for AllowBlank 
            /// </summary>
            public const int AllowBlank = 7;
            /// <summary>
            /// Property Indexer for Validate 
            /// </summary>
            public const int Validate = 8;
            /// <summary>
            /// Property Indexer for AutoInsert 
            /// </summary>
            public const int AutoInsert = 9;
            /// <summary>
            /// Property Indexer for PayablesClearing 
            /// </summary>
            public const int PayablesClearing = 10;
            /// <summary>
            /// Property Indexer for InventoryControl 
            /// </summary>
            public const int InventoryControl = 11;
            /// <summary>
            /// Property Indexer for NonStockClearing 
            /// </summary>
            public const int NonStockClearing = 12;
            /// <summary>
            /// Property Indexer for CostofGoodsSold 
            /// </summary>
            public const int CostOfGoodsSold = 13;
            /// <summary>
            /// Property Indexer for CostVariance 
            /// </summary>
            public const int CostVariance = 14;
            /// <summary>
            /// Property Indexer for AdjustmentWriteOff 
            /// </summary>
            public const int AdjustmentWriteOff = 15;
            /// <summary>
            /// Property Indexer for WorkinProgress 
            /// </summary>
            public const int WorkinProgress = 16;
            /// <summary>
            /// Property Indexer for CostofSales 
            /// </summary>
            public const int CostOfSales = 17;
            /// <summary>
            /// Property Indexer for Overhead 
            /// </summary>
            public const int Overhead = 18;
            /// <summary>
            /// Property Indexer for InventoryControlFromLocation 
            /// </summary>
            public const int InventoryControlFromLocation = 19;
            /// <summary>
            /// Property Indexer for InventoryControlToLocation 
            /// </summary>
            public const int InventoryControlToLocation = 20;
            /// <summary>
            /// Property Indexer for InventoryControlGITLocation 
            /// </summary>
            public const int InventoryControlGitLocation = 21;
            /// <summary>
            /// Property Indexer for TransferClearing 
            /// </summary>
            public const int TransferClearing = 22;
            /// <summary>
            /// Property Indexer for InventoryControlMasterItem 
            /// </summary>
            public const int InventoryControlMasterItem = 23;
            /// <summary>
            /// Property Indexer for InventoryControlComponent 
            /// </summary>
            public const int InventoryControlComponent = 24;
            /// <summary>
            /// Property Indexer for AssemblyCostCredit 
            /// </summary>
            public const int AssemblyCostCredit = 25;
            /// <summary>
            /// Property Indexer for DisassemblyExpense 
            /// </summary>
            public const int DisassemblyExpense = 26;
            /// <summary>
            /// Property Indexer for Required 
            /// </summary>
            public const int Required = 27;
            /// <summary>
            /// Property Indexer for ValueSet 
            /// </summary>
            public const int ValueSet = 28;
            /// <summary>
            /// Property Indexer for InternalUsage 
            /// </summary>
            public const int InternalUsage = 29;
            /// <summary>
            /// Property Indexer for TypedDefaultValueFieldIndex 
            /// </summary>
            public const int TypedDefaultValueFieldIndex = 40;
            /// <summary>
            /// Property Indexer for DefaultTextValue 
            /// </summary>
            public const int DefaultTextValue = 41;
            /// <summary>
            /// Property Indexer for DefaultAmountValue 
            /// </summary>
            public const int DefaultAmountValue = 42;
            /// <summary>
            /// Property Indexer for DefaultNumberValue 
            /// </summary>
            public const int DefaultNumberValue = 43;
            /// <summary>
            /// Property Indexer for DefaultIntegerValue 
            /// </summary>
            public const int DefaultIntegerValue = 44;
            /// <summary>
            /// Property Indexer for DefaultYesOrNoValue 
            /// </summary>
            public const int DefaultYesOrNoValue = 45;
            /// <summary>
            /// Property Indexer for DefaultDateValue 
            /// </summary>
            public const int DefaultDateValue = 46;
            /// <summary>
            /// Property Indexer for DefaultTimeValue 
            /// </summary>
            public const int DefaultTimeValue = 47;
            /// <summary>
            /// Property Indexer for OptionalFieldDescription 
            /// </summary>
            public const int OptionalFieldDescription = 48;
            /// <summary>
            /// Property Indexer for DefaultValueDescription 
            /// </summary>
            public const int DefaultValueDescription = 49;

            #endregion
        }


    }
}
