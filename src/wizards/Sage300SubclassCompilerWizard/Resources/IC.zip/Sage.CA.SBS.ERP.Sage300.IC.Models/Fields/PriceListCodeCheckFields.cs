// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of PriceListCodesChecks Constants 
    /// </summary>
    public partial class PriceListCodeCheck
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0392";

        /// <summary>
        /// Contains list of PriceListCodesChecks Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for PriceListCode 
            /// </summary>
            public const string PriceListCode = "PRICELIST";
            /// <summary>
            /// Property for UserID 
            /// </summary>
            public const string UserID = "USERID";
            /// <summary>
            /// Property for RecordExists 
            /// </summary>
            public const string RecordExists = "EXISTS";
            /// <summary>
            /// Property for GreaterthanPercentage 
            /// </summary>
            public const string GreaterthanPercentage = "CGTPERCENT";
            /// <summary>
            /// Property for LessthanPercentage 
            /// </summary>
            public const string LessthanPercentage = "CLTPERCENT";
            /// <summary>
            /// Property for GreaterthanAmount 
            /// </summary>
            public const string GreaterthanAmount = "CGTAMOUNT";
            /// <summary>
            /// Property for LessthanAmount 
            /// </summary>
            public const string LessthanAmount = "CLTAMOUNT";

            #endregion
        }


        /// <summary>
        /// Contains list of PriceListCodesChecks Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for PriceListCode 
            /// </summary>
            public const int PriceListCode = 1;
            /// <summary>
            /// Property Indexer for UserID 
            /// </summary>
            public const int UserID = 2;
            /// <summary>
            /// Property Indexer for RecordExists 
            /// </summary>
            public const int RecordExists = 3;
            /// <summary>
            /// Property Indexer for GreaterthanPercentage 
            /// </summary>
            public const int GreaterthanPercentage = 4;
            /// <summary>
            /// Property Indexer for LessthanPercentage 
            /// </summary>
            public const int LessthanPercentage = 5;
            /// <summary>
            /// Property Indexer for GreaterthanAmount 
            /// </summary>
            public const int GreaterthanAmount = 6;
            /// <summary>
            /// Property Indexer for LessthanAmount 
            /// </summary>
            public const int LessthanAmount = 7;

            #endregion
        }


    }
}
