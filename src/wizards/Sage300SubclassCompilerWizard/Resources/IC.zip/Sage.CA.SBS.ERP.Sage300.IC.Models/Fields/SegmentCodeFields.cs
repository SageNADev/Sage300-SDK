// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of SegmentCodes Constants 
    /// </summary>
    public partial class SegmentCode
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0620";

        /// <summary>
        /// Contains list of SegmentCodes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for SegmentNumber 
            /// </summary>
            public const string SegmentNumber = "SEGMENT";

            /// <summary>
            /// Property for SegmentCode 
            /// </summary>
            public const string SegmentCodeName = "SEGVAL";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "DESC";

            #endregion
        }

        /// <summary>
        /// Contains list of SegmentCodes Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for SegmentNumber 
            /// </summary>
            public const int SegmentNumber = 1;

            /// <summary>
            /// Property Indexer for SegmentCode 
            /// </summary>
            public const int SegmentCodeName = 2;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 3;

            #endregion
        }

        /// <summary>
        /// To get integer value for unique id for grid
        /// </summary>
        public long SerialNumber { get; set; }
    }
}