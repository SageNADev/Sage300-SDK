// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Contains list of InventoryWorksheetHeader Constants
     /// </summary>
     public partial class InventoryWorksheetHeader
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "IC0790";

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetHeader Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for SortCode
               /// </summary>
               public const string SortCode = "SORTCODE";

               /// <summary>
               /// Property for UnformattedItemNumber
               /// </summary>
               public const string UnformattedItemNumber = "ITEMNO";

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "FMTITEMNO";

               /// <summary>
               /// Property for ItemDescription
               /// </summary>
               public const string ItemDescription = "DESC";

               /// <summary>
               /// Property for PickingSequence
               /// </summary>
               public const string PickingSequence = "PICKINGSEQ";

               /// <summary>
               /// Property for QuantityonHand
               /// </summary>
               public const string QuantityonHand = "QTYONHAND";

               /// <summary>
               /// Property for QuantityCounted
               /// </summary>
               public const string QuantityCounted = "QTYCOUNTED";

               /// <summary>
               /// Property for QuantityVariance
               /// </summary>
               public const string QuantityVariance = "QTYVAR";

               /// <summary>
               /// Property for StockingUnitOfMeasure
               /// </summary>
               public const string StockingUnitOfMeasure = "STOCKUNIT";

               /// <summary>
               /// Property for EstimatedUnitCost
               /// </summary>
               public const string EstimatedUnitCost = "CALCCOST";

               /// <summary>
               /// Property for AdjustmentUnitCost
               /// </summary>
               public const string AdjustmentUnitCost = "ADJCOST";

               /// <summary>
               /// Property for CostVariance
               /// </summary>
               public const string CostVariance = "COSTVAR";

               /// <summary>
               /// Property for Status
               /// </summary>
               public const string Status = "ONHOLD";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";
               
               /// <summary>
               /// Property for SerialQty
               /// </summary>
               public const string SerialQty = "SERIALQTY";

               /// <summary>
               /// Property for LotQuantity
               /// </summary>
               public const string LotQuantity = "LOTQTY";

               /// <summary>
               /// Property for SerialsCost
               /// </summary>
               public const string SerialsCost = "SERIALCOST";

               /// <summary>
               /// Property for LotsCost
               /// </summary>
               public const string LotsCost = "LOTCOST";

               /// <summary>
               /// Property for InterprocessCommID
               /// </summary>
               public const string InterprocessCommID = "IPCID";
               
               /// <summary>
               /// Property for NumSerial
               /// </summary>
               public const string NumSerial = "NUMSERIAL";

               /// <summary>
               /// Property for ForcePopupSn
               /// </summary>
               public const string ForcePopupSn = "FORCEPOPSN";

               /// <summary>
               /// Property for PopupSn
               /// </summary>
               public const string PopupSn = "POPUPSN";

               /// <summary>
               /// Property for CloseSn
               /// </summary>
               public const string CloseSn = "CLOSESN";

               /// <summary>
               /// Property for LtSetID
               /// </summary>
               public const string LtSetID = "LTSETID";

               /// <summary>
               /// Property for ForcePopupLt
               /// </summary>
               public const string ForcePopupLt = "FORCEPOPLT";

               /// <summary>
               /// Property for PopupLt
               /// </summary>
               public const string PopupLt = "POPUPLT";

               /// <summary>
               /// Property for CloseLt
               /// </summary>
               public const string CloseLt = "CLOSELT";

               /// <summary>
               /// Property for ProcessCommand
               /// </summary>
               public const string ProcessCommand = "PROCESSCMD";

               /// <summary>
               /// Property for SerialLotQuantityToProcess
               /// </summary>
               public const string SerialLotQuantityToProcess = "XGENALCQTY";

               /// <summary>
               /// Property for NumberOfLotsToGenerate
               /// </summary>
               public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

               /// <summary>
               /// Property for QuantityperLot
               /// </summary>
               public const string QuantityperLot = "XPERLOTQTY";

               /// <summary>
               /// Property for AllocateFromSerial
               /// </summary>
               public const string AllocateFromSerial = "SALLOCFROM";

               /// <summary>
               /// Property for AllocateFromLot
               /// </summary>
               public const string AllocateFromLot = "LALLOCFROM";

               /// <summary>
               /// Property for SerialLotWindowHandle
               /// </summary>
               public const string SerialLotWindowHandle = "METERHWND";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of InventoryWorksheetHeader Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for SortCode
               /// </summary>
               public const int SortCode = 2;

               /// <summary>
               /// Property Indexer for UnformattedItemNumber
               /// </summary>
               public const int UnformattedItemNumber = 3;

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 4;

               /// <summary>
               /// Property Indexer for ItemDescription
               /// </summary>
               public const int ItemDescription = 5;

               /// <summary>
               /// Property Indexer for PickingSequence
               /// </summary>
               public const int PickingSequence = 6;

               /// <summary>
               /// Property Indexer for QuantityonHand
               /// </summary>
               public const int QuantityonHand = 7;

               /// <summary>
               /// Property Indexer for QuantityCounted
               /// </summary>
               public const int QuantityCounted = 8;

               /// <summary>
               /// Property Indexer for QuantityVariance
               /// </summary>
               public const int QuantityVariance = 9;

               /// <summary>
               /// Property Indexer for StockingUnitOfMeasure
               /// </summary>
               public const int StockingUnitOfMeasure = 10;

               /// <summary>
               /// Property Indexer for EstimatedUnitCost
               /// </summary>
               public const int EstimatedUnitCost = 11;

               /// <summary>
               /// Property Indexer for AdjustmentUnitCost
               /// </summary>
               public const int AdjustmentUnitCost = 12;

               /// <summary>
               /// Property Indexer for CostVariance
               /// </summary>
               public const int CostVariance = 13;

               /// <summary>
               /// Property Indexer for Status
               /// </summary>
               public const int Status = 14;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 15;
               
               /// <summary>
               /// Property Indexer for SerialQty
               /// </summary>
               public const int SerialQty = 16;

               /// <summary>
               /// Property Indexer for LotQuantity
               /// </summary>
               public const int LotQuantity = 17;

               /// <summary>
               /// Property Indexer for SerialsCost
               /// </summary>
               public const int SerialsCost = 18;

               /// <summary>
               /// Property Indexer for LotsCost
               /// </summary>
               public const int LotsCost = 19;

               /// <summary>
               /// Property Indexer for InterprocessCommID
               /// </summary>
               public const int InterprocessCommID = 41;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for NumSerial
               /// </summary>
               public const int NumSerial = 42;

               /// <summary>
               /// Property Indexer for ForcePopupSn
               /// </summary>
               public const int ForcePopupSn = 43;

               /// <summary>
               /// Property Indexer for PopupSn
               /// </summary>
               public const int PopupSn = 44;

               /// <summary>
               /// Property Indexer for CloseSn
               /// </summary>
               public const int CloseSn = 45;

               /// <summary>
               /// Property Indexer for LtSetID
               /// </summary>
               public const int LtSetID = 46;

               /// <summary>
               /// Property Indexer for ForcePopupLt
               /// </summary>
               public const int ForcePopupLt = 47;

               /// <summary>
               /// Property Indexer for PopupLt
               /// </summary>
               public const int PopupLt = 48;

               /// <summary>
               /// Property Indexer for CloseLt
               /// </summary>
               public const int CloseLt = 49;

               /// <summary>
               /// Property Indexer for ProcessCommand
               /// </summary>
               public const int ProcessCommand = 50;

               /// <summary>
               /// Property Indexer for SerialLotQuantityToProcess
               /// </summary>
               public const int SerialLotQuantityToProcess = 51;

               /// <summary>
               /// Property Indexer for NumberOfLotsToGenerate
               /// </summary>
               public const int NumberOfLotsToGenerate = 52;

               /// <summary>
               /// Property Indexer for QuantityperLot
               /// </summary>
               public const int QuantityperLot = 53;

               /// <summary>
               /// Property Indexer for AllocateFromSerial
               /// </summary>
               public const int AllocateFromSerial = 54;

               /// <summary>
               /// Property Indexer for AllocateFromLot
               /// </summary>
               public const int AllocateFromLot = 55;

               /// <summary>
               /// Property Indexer for SerialLotWindowHandle
               /// </summary>
               public const int SerialLotWindowHandle = 56;

          }
          #endregion

     }
}
