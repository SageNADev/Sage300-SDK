// /* Copyright (c) 1994-2025 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of ICOptions Constants 
    /// </summary>
    public partial class Options
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0380";

        /// <summary>
        /// Contains list of ICOptions Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for DummyField 
            /// </summary>
            public const string DummyField = "DUMMY";

            /// <summary>
            /// Property for ContactName 
            /// </summary>
            public const string ContactName = "CONTACT";

            /// <summary>
            /// Property for PhoneNumber 
            /// </summary>
            public const string PhoneNumber = "PHONE";

            /// <summary>
            /// Property for FaxNumber 
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for FractionalQuantities 
            /// </summary>
            public const string FractionalQuantities = "FRACTQTY";

            /// <summary>
            /// Property for AllowNegativeQuantities 
            /// </summary>
            public const string AllowNegativeQuantities = "NEGQTY";

            /// <summary>
            /// Property for KeepTransactionHistory 
            /// </summary>
            public const string KeepTransactionHistory = "TRANSHIST";

            /// <summary>
            /// Property for InterfaceWithJobCost 
            /// </summary>
            public const string InterfaceWithJobCost = "JOBCOST";

            /// <summary>
            /// Property for GOrLReferenceField 
            /// </summary>
            public const string GOrLReferenceField = "REFCHOICE";

            /// <summary>
            /// Property for GOrLDescriptionField 
            /// </summary>
            public const string GOrLDescriptionField = "DESCCHOICE";

            /// <summary>
            /// Property for DefaultWeightUnitofMeasure 
            /// </summary>
            public const string DefaultWeightUnitofMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for Cost1Name 
            /// </summary>
            public const string Cost1Name = "COST1NAME";

            /// <summary>
            /// Property for Cost2Name 
            /// </summary>
            public const string Cost2Name = "COST2NAME";

            /// <summary>
            /// Property for DayEndTransactionsOutstanding 
            /// </summary>
            public const string DayEndTransactionsOutstanding = "DAYEND";

            /// <summary>
            /// Property for NextTransactionNumber 
            /// </summary>
            public const string NextTransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property for NextAlternateItemSetNumber 
            /// </summary>
            public const string NextAlternateItemSetNumber = "NXTALTSET";

            /// <summary>
            /// Property for GOrLTransCreatedThruDayEnd 
            /// </summary>
            public const string GOrLTransCreatedThruDayEnd = "GLDAYEND";

            /// <summary>
            /// Property for NextAdjustmentEntrySeq 
            /// </summary>
            public const string NextAdjustmentEntrySeq = "ADJENSEQ";

            /// <summary>
            /// Property for NextAssemblyEntrySeq 
            /// </summary>
            public const string NextAssemblyEntrySeq = "ASSMENSEQ";

            /// <summary>
            /// Property for NextReceiptEntrySeq 
            /// </summary>
            public const string NextReceiptEntrySeq = "RECENSEQ";

            /// <summary>
            /// Property for NextShipmentEntrySeq 
            /// </summary>
            public const string NextShipmentEntrySeq = "SHIPENSEQ";

            /// <summary>
            /// Property for NextTransferEntrySeq 
            /// </summary>
            public const string NextTransferEntrySeq = "TRANFENSEQ";

            /// <summary>
            /// Property for NextHistoryEntrySeq 
            /// </summary>
            public const string NextHistoryEntrySeq = "HISTENSEQ";

            /// <summary>
            /// Property for NextDayEndPostingSeq 
            /// </summary>
            public const string NextDayEndPostingSeq = "DAYENDSEQ";

            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "MULTICURR";

            /// <summary>
            /// Property for DeferredGOrLPosting 
            /// </summary>
            public const string DeferredGOrLPosting = "DEFERGLPST";

            /// <summary>
            /// Property for AppendToGOrLBatch 
            /// </summary>
            public const string AppendToGOrLBatch = "APPENDGL";

            /// <summary>
            /// Property for ConsolidateGOrLBatch 
            /// </summary>
            public const string ConsolidateGOrLBatch = "CONSOLGL";

            /// <summary>
            /// Property for StatisticsCalendar 
            /// </summary>
            public const string StatisticsCalendar = "STATCALNDR";

            /// <summary>
            /// Property for StatisticsPeriod 
            /// </summary>
            public const string StatisticsPeriod = "STATPRD";

            /// <summary>
            /// Property for EditStatistics 
            /// </summary>
            public const string EditStatistics = "STATEDIT";

            /// <summary>
            /// Property for AllowItemsatAllLocations 
            /// </summary>
            public const string AllowItemsatAllLocations = "CRTITEMLOC";

            /// <summary>
            /// Property for AddlCostonRcptReturns 
            /// </summary>
            public const string AddlCostonRcptReturns = "ADDCSTTYPE";

            /// <summary>
            /// Property for DefaultRateType 
            /// </summary>
            public const string DefaultRateType = "RATETYPE";

            /// <summary>
            /// Property for DefaultItemStructure 
            /// </summary>
            public const string DefaultItemStructure = "ITEMBRKID";

            /// <summary>
            /// Property for AccumulateItemStatistics 
            /// </summary>
            public const string AccumulateItemStatistics = "STATACCUM";

            /// <summary>
            /// Property for PostToClosedFiscalPeriods 
            /// </summary>
            public const string PostToClosedFiscalPeriods = "PSTTOCLOSD";

            /// <summary>
            /// Property for PeriodType 
            /// </summary>
            public const string PeriodType = "PERIODTYPE";

            /// <summary>
            /// Property for PeriodLength 
            /// </summary>
            public const string PeriodLength = "PERIODLENG";

            /// <summary>
            /// Property for FractionalQuantityDecimals 
            /// </summary>
            public const string FractionalQuantityDecimals = "FRACTDEC";

            /// <summary>
            /// Property for ConversionFactorDecimals 
            /// </summary>
            public const string ConversionFactorDecimals = "FACTORDEC";

            /// <summary>
            /// Property for StatisticalPeriods 
            /// </summary>
            public const string StatisticalPeriods = "STATPRDS";

            /// <summary>
            /// Property for UseHyhenasItemSeparator 
            /// </summary>
            public const string UseHyhenasItemSeparator = "HYHEN";

            /// <summary>
            /// Property for UseForwardSlashasItemSeparator 
            /// </summary>
            public const string UseForwardSlashasItemSeparator = "FWDSLASH";

            /// <summary>
            /// Property for UseBackSlashasItemSeparator 
            /// </summary>
            public const string UseBackSlashasItemSeparator = "BCKSLASH";

            /// <summary>
            /// Property for UseAsteriskasItemSeparator 
            /// </summary>
            public const string UseAsteriskasItemSeparator = "ASTERISK";

            /// <summary>
            /// Property for UsePeriodasItemSeparator 
            /// </summary>
            public const string UsePeriodasItemSeparator = "PERIOD";

            /// <summary>
            /// Property for UseLeftParenthesisasItemSep 
            /// </summary>
            public const string UseLeftParenthesisasItemSep = "LFTPARENS";

            /// <summary>
            /// Property for UseRightParenthesisasItemSeparator 
            /// </summary>
            public const string UseRightParenthesisasItemSeparator = "RGTPARENS";

            /// <summary>
            /// Property for UsePoundSignasItemSeparator 
            /// </summary>
            public const string UsePoundSignasItemSeparator = "POUNDSGN";

            /// <summary>
            /// Property for AllowReceiptofNonstockItems 
            /// </summary>
            public const string AllowReceiptofNonstockItems = "RECNONSTK";

            /// <summary>
            /// Property for PrompttoDeleteduringPosting 
            /// </summary>
            public const string PrompttoDeleteduringPosting = "DELPROMPT";

            /// <summary>
            /// Property for CostDuring 
            /// </summary>
            public const string CostDuring = "COSTDURING";

            /// <summary>
            /// Property for AssemblyNumberLength 
            /// </summary>
            public const string AssemblyNumberLength = "ASSNUMBERL";

            /// <summary>
            /// Property for AssemblyNumberPrefix 
            /// </summary>
            public const string AssemblyNumberPrefix = "ASSPREFIXD";

            /// <summary>
            /// Property for ASSBODYD 
            /// </summary>
            public const string ASSBODYD = "ASSBODYD";

            /// <summary>
            /// Property for DisassemblyNumberLength 
            /// </summary>
            public const string DisassemblyNumberLength = "DASNUMBERL";

            /// <summary>
            /// Property for DisassemblyNumberPrefix 
            /// </summary>
            public const string DisassemblyNumberPrefix = "DASPREFIXD";

            /// <summary>
            /// Property for DASBODYD 
            /// </summary>
            public const string DASBODYD = "DASBODYD";

            /// <summary>
            /// Property for TransferNumberLength 
            /// </summary>
            public const string TransferNumberLength = "TRFNUMBERL";

            /// <summary>
            /// Property for TransferNumberPrefix 
            /// </summary>
            public const string TransferNumberPrefix = "TRFPREFIXD";

            /// <summary>
            /// Property for TRFBODYD 
            /// </summary>
            public const string TRFBODYD = "TRFBODYD";

            /// <summary>
            /// Property for AdjustmentNumberLength 
            /// </summary>
            public const string AdjustmentNumberLength = "ADJNUMBERL";

            /// <summary>
            /// Property for AdjustmentNumberPrefix 
            /// </summary>
            public const string AdjustmentNumberPrefix = "ADJPREFIXD";

            /// <summary>
            /// Property for ADJBODYD 
            /// </summary>
            public const string ADJBODYD = "ADJBODYD";

            /// <summary>
            /// Property for ShipmentNumberLength 
            /// </summary>
            public const string ShipmentNumberLength = "SHPNUMBERL";

            /// <summary>
            /// Property for ShipmentNumberPrefix 
            /// </summary>
            public const string ShipmentNumberPrefix = "SHPPREFIXD";

            /// <summary>
            /// Property for SHPBODYD 
            /// </summary>
            public const string SHPBODYD = "SHPBODYD";

            /// <summary>
            /// Property for ShipmentReturnNumberLength 
            /// </summary>
            public const string ShipmentReturnNumberLength = "SRTNUMBERL";

            /// <summary>
            /// Property for ShipmentReturnNumberPrefix 
            /// </summary>
            public const string ShipmentReturnNumberPrefix = "SRTPREFIXD";

            /// <summary>
            /// Property for SRTBODYD 
            /// </summary>
            public const string SRTBODYD = "SRTBODYD";

            /// <summary>
            /// Property for ReceiptNumberLength 
            /// </summary>
            public const string ReceiptNumberLength = "RCPNUMBERL";

            /// <summary>
            /// Property for ReceiptNumberPrefix 
            /// </summary>
            public const string ReceiptNumberPrefix = "RCPPREFIXD";

            /// <summary>
            /// Property for RCPBODYD 
            /// </summary>
            public const string RCPBODYD = "RCPBODYD";

            /// <summary>
            /// Property for TransitReceiptNumberLength 
            /// </summary>
            public const string TransitReceiptNumberLength = "TRCNUMBERL";

            /// <summary>
            /// Property for TransitReceiptNumberPrefix 
            /// </summary>
            public const string TransitReceiptNumberPrefix = "TRCPREFIXD";

            /// <summary>
            /// Property for TRCBODYD 
            /// </summary>
            public const string TRCBODYD = "TRCBODYD";

            /// <summary>
            /// Property for NextNoncostedReceiptDayEnd 
            /// </summary>
            public const string NextNoncostedReceiptDayEnd = "RECDESEQ";

            /// <summary>
            /// Property for SeparatorHyhen 
            /// </summary>
            public const string SeparatorHyhen = "SPHYHEN";

            /// <summary>
            /// Property for SeparatorForwardSlash 
            /// </summary>
            public const string SeparatorForwardSlash = "SPFWDSLASH";

            /// <summary>
            /// Property for SeparatorBackSlash 
            /// </summary>
            public const string SeparatorBackSlash = "SPBCKSLASH";

            /// <summary>
            /// Property for SeparatorAsterisk 
            /// </summary>
            public const string SeparatorAsterisk = "SPASTERISK";

            /// <summary>
            /// Property for SeparatorPeriod 
            /// </summary>
            public const string SeparatorPeriod = "SPPERIOD";

            /// <summary>
            /// Property for SeparatorLeftParenthesis 
            /// </summary>
            public const string SeparatorLeftParenthesis = "SPLPARENS";

            /// <summary>
            /// Property for SeparatorRightParenthesis 
            /// </summary>
            public const string SeparatorRightParenthesis = "SPRPARENS";

            /// <summary>
            /// Property for SeparatorNumberSign 
            /// </summary>
            public const string SeparatorNumberSign = "SPPOUNDSGN";

            /// <summary>
            /// Property for HomeCurrency 
            /// </summary>
            public const string HomeCurrency = "HOMECURR";

            /// <summary>
            /// Property for DefaultAssemblyNumber 
            /// </summary>
            public const string DefaultAssemblyNumber = "ASSDEFAULT";

            /// <summary>
            /// Property for ASSVALUE 
            /// </summary>
            public const string ASSVALUE = "ASSVALUE";

            /// <summary>
            /// Property for DefaultDisassemblyNumber 
            /// </summary>
            public const string DefaultDisassemblyNumber = "DASDEFAULT";

            /// <summary>
            /// Property for DASVALUE 
            /// </summary>
            public const string DASVALUE = "DASVALUE";

            /// <summary>
            /// Property for DefaultTransferNumber 
            /// </summary>
            public const string DefaultTransferNumber = "TRFDEFAULT";

            /// <summary>
            /// Property for TRFVALUE 
            /// </summary>
            public const string TRFVALUE = "TRFVALUE";

            /// <summary>
            /// Property for DefaultAdjustmentNumber 
            /// </summary>
            public const string DefaultAdjustmentNumber = "ADJDEFAULT";

            /// <summary>
            /// Property for ADJVALUE 
            /// </summary>
            public const string ADJVALUE = "ADJVALUE";

            /// <summary>
            /// Property for DefaultShipmentNumber 
            /// </summary>
            public const string DefaultShipmentNumber = "SHPDEFAULT";

            /// <summary>
            /// Property for SHPVALUE 
            /// </summary>
            public const string SHPVALUE = "SHPVALUE";

            /// <summary>
            /// Property for DefaultShipmentReturnNumber 
            /// </summary>
            public const string DefaultShipmentReturnNumber = "SRTDEFAULT";

            /// <summary>
            /// Property for SRTVALUE 
            /// </summary>
            public const string SRTVALUE = "SRTVALUE";

            /// <summary>
            /// Property for DefaultReceiptNumber 
            /// </summary>
            public const string DefaultReceiptNumber = "RCPDEFAULT";

            /// <summary>
            /// Property for RCPVALUE 
            /// </summary>
            public const string RCPVALUE = "RCPVALUE";

            /// <summary>
            /// Property for DefaultTransitReceiptNumber 
            /// </summary>
            public const string DefaultTransitReceiptNumber = "TRCDEFAULT";

            /// <summary>
            /// Property for TRCVALUE 
            /// </summary>
            public const string TRCVALUE = "TRCVALUE";

            /// <summary>
            /// Property for DefaultGoodsinTransitLocatio 
            /// </summary>
            public const string DefaultGoodsinTransitLocatio = "GITLOC";

            /// <summary>
            /// Property for TransitLocationDescription 
            /// </summary>
            public const string TransitLocationDescription = "GITLOCDESC";

            /// <summary>
            /// Property for OnlyUseDefinedUOM 
            /// </summary>
            public const string OnlyUseDefinedUOM = "DEFUOM";

            /// <summary>
            /// Property for AgingPeriod1 
            /// </summary>
            public const string AgingPeriod1 = "AGING1";

            /// <summary>
            /// Property for AgingPeriod2 
            /// </summary>
            public const string AgingPeriod2 = "AGING2";

            /// <summary>
            /// Property for AgingPeriod3 
            /// </summary>
            public const string AgingPeriod3 = "AGING3";

            /// <summary>
            /// Property for CreateSubledgerOrAuditDuring 
            /// </summary>
            public const string CreateSubledgerOrAuditDuring = "SLAUDURING";

            /// <summary>
            /// Property for NextInternalUsageEntrySeq 
            /// </summary>
            public const string NextInternalUsageEntrySeq = "ICSENSEQ";

            /// <summary>
            /// Property for InternalUsageNumberLength 
            /// </summary>
            public const string InternalUsageNumberLength = "ICSNUMBERL";

            /// <summary>
            /// Property for InternalUsageNumberPrefix 
            /// </summary>
            public const string InternalUsageNumberPrefix = "ICSPREFIXD";

            /// <summary>
            /// Property for ICSBODYD 
            /// </summary>
            public const string ICSBODYD = "ICSBODYD";

            /// <summary>
            /// Property for DefaultInternalUsageNumber 
            /// </summary>
            public const string DefaultInternalUsageNumber = "ICSDEFAULT";

            /// <summary>
            /// Property for ICSVALUE 
            /// </summary>
            public const string ICSVALUE = "ICSVALUE";

            /// <summary>
            /// Property for TransactionpostOrdepOrcost 
            /// </summary>
            public const string TransactionpostOrdepOrcost = "TPOSTACTN";

            /// <summary>
            /// Property for IOrCReceipts 
            /// </summary>
            public const string IOrCReceipts = "SRCTYPERC";

            /// <summary>
            /// Property for IOrCReceiptReturns 
            /// </summary>
            public const string IOrCReceiptReturns = "SRCTYPERR";

            /// <summary>
            /// Property for IOrCReceiptAdjustments 
            /// </summary>
            public const string IOrCReceiptAdjustments = "SRCTYPERA";

            /// <summary>
            /// Property for IOrCShipments 
            /// </summary>
            public const string IOrCShipments = "SRCTYPESH";

            /// <summary>
            /// Property for IOrCShipmentReturns 
            /// </summary>
            public const string IOrCShipmentReturns = "SRCTYPESR";

            /// <summary>
            /// Property for IOrCTransfers 
            /// </summary>
            public const string IOrCTransfers = "SRCTYPETF";

            /// <summary>
            /// Property for IOrCAssemblies 
            /// </summary>
            public const string IOrCAssemblies = "SRCTYPEAS";

            /// <summary>
            /// Property for IOrCAdjustments 
            /// </summary>
            public const string IOrCAdjustments = "SRCTYPEAD";

            /// <summary>
            /// Property for IOrCConsolidatedEntry 
            /// </summary>
            public const string IOrCConsolidatedEntry = "SRCTYPECO";

            /// <summary>
            /// Property for IOrCDisassemblies 
            /// </summary>
            public const string IOrCDisassemblies = "SRCTYPEDA";

            /// <summary>
            /// Property for IOrCInternalUsage 
            /// </summary>
            public const string IOrCInternalUsage = "SRCTYPEIN";

            /// <summary>
            /// Property for DefaultPostingDate 
            /// </summary>
            public const string DefaultPostingDate = "DATEBUSDFT";

            /// <summary>
            /// Property for SerialNumberMask 
            /// </summary>
            public const string SerialNumberMask = "SERIALMASK";

            /// <summary>
            /// Property for UseSerialsDaystoExpire 
            /// </summary>
            public const string UseSerialsDaystoExpire = "SUSEEXPDAY";

            /// <summary>
            /// Property for SerialsDaystoExpire 
            /// </summary>
            public const string SerialsDaystoExpire = "SEXPDAYS";

            /// <summary>
            /// Property for AllowDifferentSerialQty 
            /// </summary>
            public const string AllowDifferentSerialQty = "SDIFQTYOK";

            /// <summary>
            /// Property for AllowSerialAlloconQtyOrd 
            /// </summary>
            public const string AllowSerialAlloconQtyOrd = "SALCQTYORD";

            /// <summary>
            /// Property for SortSerialsby 
            /// </summary>
            public const string SortSerialsby = "SSORTBY";

            /// <summary>
            /// Property for SortSerialsFirstby 
            /// </summary>
            public const string SortSerialsFirstby = "SFIRST";

            /// <summary>
            /// Property for StopAllocationofExpiredSeria 
            /// </summary>
            public const string StopAllocationofExpiredSerial = "SEXPLEVEL";

            /// <summary>
            /// Property for SerialsHyphenasSeparator 
            /// </summary>
            public const string SerialsHyphenasSeparator = "SHYPHEN";

            /// <summary>
            /// Property for SerialsFwdSlashasSeparator 
            /// </summary>
            public const string SerialsFwdSlashasSeparator = "SFWDSLASH";

            /// <summary>
            /// Property for SerialsBackSlashasSeparator 
            /// </summary>
            public const string SerialsBackSlashasSeparator = "SBCKSLASH";

            /// <summary>
            /// Property for SerialsAsteriskasSeparator 
            /// </summary>
            public const string SerialsAsteriskasSeparator = "SASTERISK";

            /// <summary>
            /// Property for SerialsPeriodasSeparator 
            /// </summary>
            public const string SerialsPeriodasSeparator = "SPERIOD";

            /// <summary>
            /// Property for SerialsLeftParenthesisasSep 
            /// </summary>
            public const string SerialsLeftParenthesisasSep = "SLFPARENS";

            /// <summary>
            /// Property for SerialsRightParenthesisasSep 
            /// </summary>
            public const string SerialsRightParenthesisasSep = "SRGTPARENS";

            /// <summary>
            /// Property for SerialsPoundSignasSeparator 
            /// </summary>
            public const string SerialsPoundSignasSeparator = "SPOUNDSIGN";

            /// <summary>
            /// Property for SerialsLeftBracketasSep 
            /// </summary>
            public const string SerialsLeftBracketasSep = "SLFBRACKT";

            /// <summary>
            /// Property for SerialsRightBracketasSep 
            /// </summary>
            public const string SerialsRightBracketasSep = "SRGTBRACKT";

            /// <summary>
            /// Property for SerialsLeftBraceasSep 
            /// </summary>
            public const string SerialsLeftBraceasSep = "SLFBRACE";

            /// <summary>
            /// Property for SerialsRightBraceasSep 
            /// </summary>
            public const string SerialsRightBraceasSep = "SRGTBRACE";

            /// <summary>
            /// Property for LotNumberMask 
            /// </summary>
            public const string LotNumberMask = "LOTMASK";

            /// <summary>
            /// Property for UseLotsDaystoExpire 
            /// </summary>
            public const string UseLotsDaystoExpire = "LUSEEXPDAY";

            /// <summary>
            /// Property for LotsDaystoExpire 
            /// </summary>
            public const string LotsDaystoExpire = "LEXPDAYS";

            /// <summary>
            /// Property for UseLotsDaysonQuarantine 
            /// </summary>
            public const string UseLotsDaysonQuarantine = "LUSEQRNDAY";

            /// <summary>
            /// Property for LotsDaysonQuarantine 
            /// </summary>
            public const string LotsDaysonQuarantine = "LQRNDAYS";

            /// <summary>
            /// Property for AllowDifferentLotQty 
            /// </summary>
            public const string AllowDifferentLotQty = "LDIFQTYOK";

            /// <summary>
            /// Property for AllowLotAlloconQtyOrd 
            /// </summary>
            public const string AllowLotAlloconQtyOrd = "LALCQTYORD";

            /// <summary>
            /// Property for SortLotsby 
            /// </summary>
            public const string SortLotsby = "LSORTBY";

            /// <summary>
            /// Property for SortLotsFirstby 
            /// </summary>
            public const string SortLotsFirstby = "LFIRST";

            /// <summary>
            /// Property for StopAllocationofExpiredLots 
            /// </summary>
            public const string StopAllocationofExpiredLots = "LEXPLEVEL";

            /// <summary>
            /// Property for LotsHyphenasSeparator 
            /// </summary>
            public const string LotsHyphenasSeparator = "LHYPHEN";

            /// <summary>
            /// Property for LotsFwdSlashasSeparator 
            /// </summary>
            public const string LotsFwdSlashasSeparator = "LFWDSLASH";

            /// <summary>
            /// Property for LotsBackSlashasSeparator 
            /// </summary>
            public const string LotsBackSlashasSeparator = "LBCKSLASH";

            /// <summary>
            /// Property for LotsAsteriskasSeparator 
            /// </summary>
            public const string LotsAsteriskasSeparator = "LASTERISK";

            /// <summary>
            /// Property for LotsPeriodasSeparator 
            /// </summary>
            public const string LotsPeriodasSeparator = "LPERIOD";

            /// <summary>
            /// Property for LotsLeftParenthesisasSep 
            /// </summary>
            public const string LotsLeftParenthesisasSep = "LLFPARENS";

            /// <summary>
            /// Property for LotsRightParenthesisasSep 
            /// </summary>
            public const string LotsRightParenthesisasSep = "LRGTPARENS";

            /// <summary>
            /// Property for LotsPoundSignasSeparator 
            /// </summary>
            public const string LotsPoundSignasSeparator = "LPOUNDSIGN";

            /// <summary>
            /// Property for LotsLeftBracketasSeparator 
            /// </summary>
            public const string LotsLeftBracketasSeparator = "LLFBRACKT";

            /// <summary>
            /// Property for LotsRightBracketasSeparator 
            /// </summary>
            public const string LotsRightBracketasSeparator = "LRGTBRACKT";

            /// <summary>
            /// Property for LotsLeftBraceasSeparator 
            /// </summary>
            public const string LotsLeftBraceasSeparator = "LLFBRACE";

            /// <summary>
            /// Property for LotsRightBraceasSeparator 
            /// </summary>
            public const string LotsRightBraceasSeparator = "LRGTBRACE";

            /// <summary>
            /// Property for RecallOrReleaseSequenceNumber 
            /// </summary>
            public const string RecallOrReleaseSequenceNumber = "RECALENSEQ";

            /// <summary>
            /// Property for RecallNumberLength 
            /// </summary>
            public const string RecallNumberLength = "RECNUMBERL";

            /// <summary>
            /// Property for RecallNumberPrefix 
            /// </summary>
            public const string RecallNumberPrefix = "RECPREFIXD";

            /// <summary>
            /// Property for RECBODYD 
            /// </summary>
            public const string RECBODYD = "RECBODYD";

            /// <summary>
            /// Property for DefaultRecallNumber 
            /// </summary>
            public const string DefaultRecallNumber = "RECDEFAULT";

            /// <summary>
            /// Property for RECVALUE 
            /// </summary>
            public const string RECVALUE = "RECVALUE";

            /// <summary>
            /// Property for ReleaseNumberLength 
            /// </summary>
            public const string ReleaseNumberLength = "RELNUMBERL";

            /// <summary>
            /// Property for ReleaseNumberPrefix 
            /// </summary>
            public const string ReleaseNumberPrefix = "RELPREFIXD";

            /// <summary>
            /// Property for RELBODYD 
            /// </summary>
            public const string RELBODYD = "RELBODYD";

            /// <summary>
            /// Property for DefaultReleaseNumber 
            /// </summary>
            public const string DefaultReleaseNumber = "RELDEFAULT";

            /// <summary>
            /// Property for RELVALUE 
            /// </summary>
            public const string RELVALUE = "RELVALUE";

            /// <summary>
            /// Property for CombineOrSplitSequenceNumber 
            /// </summary>
            public const string CombineOrSplitSequenceNumber = "COMENSEQ";

            /// <summary>
            /// Property for CombineNumberLength 
            /// </summary>
            public const string CombineNumberLength = "COMNUMBERL";

            /// <summary>
            /// Property for CombineNumberPrefix 
            /// </summary>
            public const string CombineNumberPrefix = "COMPREFIXD";

            /// <summary>
            /// Property for COMBODYD 
            /// </summary>
            public const string COMBODYD = "COMBODYD";

            /// <summary>
            /// Property for DefaultCombineNumber 
            /// </summary>
            public const string DefaultCombineNumber = "COMDEFAULT";

            /// <summary>
            /// Property for COMVALUE 
            /// </summary>
            public const string COMVALUE = "COMVALUE";

            /// <summary>
            /// Property for SplitNumberLength 
            /// </summary>
            public const string SplitNumberLength = "SPLNUMBERL";

            /// <summary>
            /// Property for SplitNumberPrefix 
            /// </summary>
            public const string SplitNumberPrefix = "SPLPREFIXD";

            /// <summary>
            /// Property for SPLBODYD 
            /// </summary>
            public const string SPLBODYD = "SPLBODYD";

            /// <summary>
            /// Property for DefaultSplitNumber 
            /// </summary>
            public const string DefaultSplitNumber = "SPLDEFAULT";

            /// <summary>
            /// Property for SPLVALUE 
            /// </summary>
            public const string SPLVALUE = "SPLVALUE";

            /// <summary>
            /// Property for ReconciliationSequenceNumber 
            /// </summary>
            public const string ReconciliationSequenceNumber = "RCNENSEQ";

            /// <summary>
            /// Property for ReconciliationNumberLength 
            /// </summary>
            public const string ReconciliationNumberLength = "RCNNUMBERL";

            /// <summary>
            /// Property for ReconciliationNumberPrefix 
            /// </summary>
            public const string ReconciliationNumberPrefix = "RCNPREFIXD";

            /// <summary>
            /// Property for RCNBODYD 
            /// </summary>
            public const string RCNBODYD = "RCNBODYD";

            /// <summary>
            /// Property for DefaultReconciliationNumber 
            /// </summary>
            public const string DefaultReconciliationNumber = "RCNDEFAULT";

            /// <summary>
            /// Property for RCNVALUE 
            /// </summary>
            public const string RCNVALUE = "RCNVALUE";

            /// <summary>
            /// Property for SeparatorLeftBracket 
            /// </summary>
            public const string SeparatorLeftBracket = "SPLBRACKET";

            /// <summary>
            /// Property for SeparatorRightBracket 
            /// </summary>
            public const string SeparatorRightBracket = "SPRBRACKET";

            /// <summary>
            /// Property for SeparatorLeftBrace 
            /// </summary>
            public const string SeparatorLeftBrace = "SPLBRACE";

            /// <summary>
            /// Property for SeparatorRightBrace 
            /// </summary>
            public const string SeparatorRightBrace = "SPRBRACE";

            /// <summary>
            /// Property for AllowDuplicateSerials 
            /// </summary>
            public const string AllowDuplicateSerials = "DUPSERIALS";

            /// <summary>
            /// Property for Last Day End Process Date
            /// </summary>
            public const string LastDayEndProcessDate = "DLASTDEP";

            /// <summary>
            /// Property for Last Day End Process Time
            /// </summary>
            public const string LastDayEndProcessTime = "TLASTDEP";

            /// <summary>
            /// Property for Last Day End Process UserID
            /// </summary>
            public const string LastDayEndProcessUserID = "ULASTDEP";

            #endregion
        }

        /// <summary>
        /// Contains list of ICOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for DummyField 
            /// </summary>
            public const int DummyField = 1;

            /// <summary>
            /// Property Indexer for ContactName 
            /// </summary>
            public const int ContactName = 2;

            /// <summary>
            /// Property Indexer for PhoneNumber 
            /// </summary>
            public const int PhoneNumber = 3;

            /// <summary>
            /// Property Indexer for FaxNumber 
            /// </summary>
            public const int FaxNumber = 4;

            /// <summary>
            /// Property Indexer for FractionalQuantities 
            /// </summary>
            public const int FractionalQuantities = 5;

            /// <summary>
            /// Property Indexer for AllowNegativeQuantities 
            /// </summary>
            public const int AllowNegativeQuantities = 6;

            /// <summary>
            /// Property Indexer for KeepTransactionHistory 
            /// </summary>
            public const int KeepTransactionHistory = 7;

            /// <summary>
            /// Property Indexer for InterfaceWithJobCost 
            /// </summary>
            public const int InterfaceWithJobCost = 8;

            /// <summary>
            /// Property Indexer for GOrLReferenceField 
            /// </summary>
            public const int GOrLReferenceField = 9;

            /// <summary>
            /// Property Indexer for GOrLDescriptionField 
            /// </summary>
            public const int GOrLDescriptionField = 10;

            /// <summary>
            /// Property Indexer for DefaultWeightUnitofMeasure 
            /// </summary>
            public const int DefaultWeightUnitofMeasure = 11;

            /// <summary>
            /// Property Indexer for Cost1Name 
            /// </summary>
            public const int Cost1Name = 12;

            /// <summary>
            /// Property Indexer for Cost2Name 
            /// </summary>
            public const int Cost2Name = 13;

            /// <summary>
            /// Property Indexer for DayEndTransactionsOutstanding 
            /// </summary>
            public const int DayEndTransactionsOutstanding = 14;

            /// <summary>
            /// Property Indexer for NextTransactionNumber 
            /// </summary>
            public const int NextTransactionNumber = 15;

            /// <summary>
            /// Property Indexer for NextAlternateItemSetNumber 
            /// </summary>
            public const int NextAlternateItemSetNumber = 16;

            /// <summary>
            /// Property Indexer for GOrLTransCreatedThruDayEnd 
            /// </summary>
            public const int GOrLTransCreatedThruDayEnd = 17;

            /// <summary>
            /// Property Indexer for NextAdjustmentEntrySeq 
            /// </summary>
            public const int NextAdjustmentEntrySeq = 18;

            /// <summary>
            /// Property Indexer for NextAssemblyEntrySeq 
            /// </summary>
            public const int NextAssemblyEntrySeq = 19;

            /// <summary>
            /// Property Indexer for NextReceiptEntrySeq 
            /// </summary>
            public const int NextReceiptEntrySeq = 20;

            /// <summary>
            /// Property Indexer for NextShipmentEntrySeq 
            /// </summary>
            public const int NextShipmentEntrySeq = 21;

            /// <summary>
            /// Property Indexer for NextTransferEntrySeq 
            /// </summary>
            public const int NextTransferEntrySeq = 22;

            /// <summary>
            /// Property Indexer for NextHistoryEntrySeq 
            /// </summary>
            public const int NextHistoryEntrySeq = 23;

            /// <summary>
            /// Property Indexer for NextDayEndPostingSeq 
            /// </summary>
            public const int NextDayEndPostingSeq = 24;

            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 25;

            /// <summary>
            /// Property Indexer for DeferredGOrLPosting 
            /// </summary>
            public const int DeferredGOrLPosting = 26;

            /// <summary>
            /// Property Indexer for AppendToGOrLBatch 
            /// </summary>
            public const int AppendToGOrLBatch = 27;

            /// <summary>
            /// Property Indexer for ConsolidateGOrLBatch 
            /// </summary>
            public const int ConsolidateGOrLBatch = 28;

            /// <summary>
            /// Property Indexer for StatisticsCalendar 
            /// </summary>
            public const int StatisticsCalendar = 29;

            /// <summary>
            /// Property Indexer for StatisticsPeriod 
            /// </summary>
            public const int StatisticsPeriod = 30;

            /// <summary>
            /// Property Indexer for EditStatistics 
            /// </summary>
            public const int EditStatistics = 31;

            /// <summary>
            /// Property Indexer for AllowItemsatAllLocations 
            /// </summary>
            public const int AllowItemsatAllLocations = 54;

            /// <summary>
            /// Property Indexer for AddlCostonRcptReturns 
            /// </summary>
            public const int AddlCostonRcptReturns = 55;

            /// <summary>
            /// Property Indexer for DefaultRateType 
            /// </summary>
            public const int DefaultRateType = 56;

            /// <summary>
            /// Property Indexer for DefaultItemStructure 
            /// </summary>
            public const int DefaultItemStructure = 57;

            /// <summary>
            /// Property Indexer for AccumulateItemStatistics 
            /// </summary>
            public const int AccumulateItemStatistics = 58;

            /// <summary>
            /// Property Indexer for PostToClosedFiscalPeriods 
            /// </summary>
            public const int PostToClosedFiscalPeriods = 59;

            /// <summary>
            /// Property Indexer for PeriodType 
            /// </summary>
            public const int PeriodType = 60;

            /// <summary>
            /// Property Indexer for PeriodLength 
            /// </summary>
            public const int PeriodLength = 61;

            /// <summary>
            /// Property Indexer for FractionalQuantityDecimals 
            /// </summary>
            public const int FractionalQuantityDecimals = 62;

            /// <summary>
            /// Property Indexer for ConversionFactorDecimals 
            /// </summary>
            public const int ConversionFactorDecimals = 63;

            /// <summary>
            /// Property Indexer for StatisticalPeriods 
            /// </summary>
            public const int StatisticalPeriods = 64;

            /// <summary>
            /// Property Indexer for UseHyhenasItemSeparator 
            /// </summary>
            public const int UseHyhenasItemSeparator = 65;

            /// <summary>
            /// Property Indexer for UseForwardSlashasItemSepara 
            /// </summary>
            public const int UseForwardSlashasItemSepara = 66;

            /// <summary>
            /// Property Indexer for UseBackSlashasItemSeparator 
            /// </summary>
            public const int UseBackSlashasItemSeparator = 67;

            /// <summary>
            /// Property Indexer for UseAsteriskasItemSeparator 
            /// </summary>
            public const int UseAsteriskasItemSeparator = 68;

            /// <summary>
            /// Property Indexer for UsePeriodasItemSeparator 
            /// </summary>
            public const int UsePeriodasItemSeparator = 69;

            /// <summary>
            /// Property Indexer for UseLeftParenthesisasItemSep 
            /// </summary>
            public const int UseLeftParenthesisasItemSep = 70;

            /// <summary>
            /// Property Indexer for UseRightParenthesisasItemSe 
            /// </summary>
            public const int UseRightParenthesisasItemSe = 71;

            /// <summary>
            /// Property Indexer for UsePoundSignasItemSeparator 
            /// </summary>
            public const int UsePoundSignasItemSeparator = 72;

            /// <summary>
            /// Property Indexer for AllowReceiptofNonstockItems 
            /// </summary>
            public const int AllowReceiptofNonstockItems = 73;

            /// <summary>
            /// Property Indexer for PrompttoDeleteduringPosting 
            /// </summary>
            public const int PrompttoDeleteduringPosting = 74;

            /// <summary>
            /// Property Indexer for CostDuring 
            /// </summary>
            public const int CostDuring = 75;

            /// <summary>
            /// Property Indexer for AssemblyNumberLength 
            /// </summary>
            public const int AssemblyNumberLength = 76;

            /// <summary>
            /// Property Indexer for AssemblyNumberPrefix 
            /// </summary>
            public const int AssemblyNumberPrefix = 77;

            /// <summary>
            /// Property Indexer for ASSBODYD 
            /// </summary>
            public const int ASSBODYD = 78;

            /// <summary>
            /// Property Indexer for DisassemblyNumberLength 
            /// </summary>
            public const int DisassemblyNumberLength = 79;

            /// <summary>
            /// Property Indexer for DisassemblyNumberPrefix 
            /// </summary>
            public const int DisassemblyNumberPrefix = 80;

            /// <summary>
            /// Property Indexer for DASBODYD 
            /// </summary>
            public const int DASBODYD = 81;

            /// <summary>
            /// Property Indexer for TransferNumberLength 
            /// </summary>
            public const int TransferNumberLength = 82;

            /// <summary>
            /// Property Indexer for TransferNumberPrefix 
            /// </summary>
            public const int TransferNumberPrefix = 83;

            /// <summary>
            /// Property Indexer for TRFBODYD 
            /// </summary>
            public const int TRFBODYD = 84;

            /// <summary>
            /// Property Indexer for AdjustmentNumberLength 
            /// </summary>
            public const int AdjustmentNumberLength = 85;

            /// <summary>
            /// Property Indexer for AdjustmentNumberPrefix 
            /// </summary>
            public const int AdjustmentNumberPrefix = 86;

            /// <summary>
            /// Property Indexer for ADJBODYD 
            /// </summary>
            public const int ADJBODYD = 87;

            /// <summary>
            /// Property Indexer for ShipmentNumberLength 
            /// </summary>
            public const int ShipmentNumberLength = 88;

            /// <summary>
            /// Property Indexer for ShipmentNumberPrefix 
            /// </summary>
            public const int ShipmentNumberPrefix = 89;

            /// <summary>
            /// Property Indexer for SHPBODYD 
            /// </summary>
            public const int SHPBODYD = 90;

            /// <summary>
            /// Property Indexer for ShipmentReturnNumberLength 
            /// </summary>
            public const int ShipmentReturnNumberLength = 91;

            /// <summary>
            /// Property Indexer for ShipmentReturnNumberPrefix 
            /// </summary>
            public const int ShipmentReturnNumberPrefix = 92;

            /// <summary>
            /// Property Indexer for SRTBODYD 
            /// </summary>
            public const int SRTBODYD = 93;

            /// <summary>
            /// Property Indexer for ReceiptNumberLength 
            /// </summary>
            public const int ReceiptNumberLength = 94;

            /// <summary>
            /// Property Indexer for ReceiptNumberPrefix 
            /// </summary>
            public const int ReceiptNumberPrefix = 95;

            /// <summary>
            /// Property Indexer for RCPBODYD 
            /// </summary>
            public const int RCPBODYD = 96;

            /// <summary>
            /// Property Indexer for TransitReceiptNumberLength 
            /// </summary>
            public const int TransitReceiptNumberLength = 97;

            /// <summary>
            /// Property Indexer for TransitReceiptNumberPrefix 
            /// </summary>
            public const int TransitReceiptNumberPrefix = 98;

            /// <summary>
            /// Property Indexer for TRCBODYD 
            /// </summary>
            public const int TRCBODYD = 99;

            /// <summary>
            /// Property Indexer for NextNoncostedReceiptDayEnd 
            /// </summary>
            public const int NextNoncostedReceiptDayEnd = 100;

            /// <summary>
            /// Property Indexer for SeparatorHyhen 
            /// </summary>
            public const int SeparatorHyhen = 106;

            /// <summary>
            /// Property Indexer for SeparatorForwardSlash 
            /// </summary>
            public const int SeparatorForwardSlash = 107;

            /// <summary>
            /// Property Indexer for SeparatorBackSlash 
            /// </summary>
            public const int SeparatorBackSlash = 108;

            /// <summary>
            /// Property Indexer for SeparatorAsterisk 
            /// </summary>
            public const int SeparatorAsterisk = 109;

            /// <summary>
            /// Property Indexer for SeparatorPeriod 
            /// </summary>
            public const int SeparatorPeriod = 110;

            /// <summary>
            /// Property Indexer for SeparatorLeftParenthesis 
            /// </summary>
            public const int SeparatorLeftParenthesis = 111;

            /// <summary>
            /// Property Indexer for SeparatorRightParenthesis 
            /// </summary>
            public const int SeparatorRightParenthesis = 112;

            /// <summary>
            /// Property Indexer for SeparatorNumberSign 
            /// </summary>
            public const int SeparatorNumberSign = 113;

            /// <summary>
            /// Property Indexer for HomeCurrency 
            /// </summary>
            public const int HomeCurrency = 114;

            /// <summary>
            /// Property Indexer for DefaultAssemblyNumber 
            /// </summary>
            public const int DefaultAssemblyNumber = 115;

            /// <summary>
            /// Property Indexer for ASSVALUE 
            /// </summary>
            public const int ASSVALUE = 116;

            /// <summary>
            /// Property Indexer for DefaultDisassemblyNumber 
            /// </summary>
            public const int DefaultDisassemblyNumber = 117;

            /// <summary>
            /// Property Indexer for DASVALUE 
            /// </summary>
            public const int DASVALUE = 118;

            /// <summary>
            /// Property Indexer for DefaultTransferNumber 
            /// </summary>
            public const int DefaultTransferNumber = 119;

            /// <summary>
            /// Property Indexer for TRFVALUE 
            /// </summary>
            public const int TRFVALUE = 120;

            /// <summary>
            /// Property Indexer for DefaultAdjustmentNumber 
            /// </summary>
            public const int DefaultAdjustmentNumber = 121;

            /// <summary>
            /// Property Indexer for ADJVALUE 
            /// </summary>
            public const int ADJVALUE = 122;

            /// <summary>
            /// Property Indexer for DefaultShipmentNumber 
            /// </summary>
            public const int DefaultShipmentNumber = 123;

            /// <summary>
            /// Property Indexer for SHPVALUE 
            /// </summary>
            public const int SHPVALUE = 124;

            /// <summary>
            /// Property Indexer for DefaultShipmentReturnNumber 
            /// </summary>
            public const int DefaultShipmentReturnNumber = 125;

            /// <summary>
            /// Property Indexer for SRTVALUE 
            /// </summary>
            public const int SRTVALUE = 126;

            /// <summary>
            /// Property Indexer for DefaultReceiptNumber 
            /// </summary>
            public const int DefaultReceiptNumber = 127;

            /// <summary>
            /// Property Indexer for RCPVALUE 
            /// </summary>
            public const int RCPVALUE = 128;

            /// <summary>
            /// Property Indexer for DefaultTransitReceiptNumber 
            /// </summary>
            public const int DefaultTransitReceiptNumber = 129;

            /// <summary>
            /// Property Indexer for TRCVALUE 
            /// </summary>
            public const int TRCVALUE = 130;

            /// <summary>
            /// Property Indexer for DefaultGoodsinTransitLocatio 
            /// </summary>
            public const int DefaultGoodsinTransitLocatio = 131;

            /// <summary>
            /// Property Indexer for TransitLocationDescription 
            /// </summary>
            public const int TransitLocationDescription = 132;

            /// <summary>
            /// Property Indexer for OnlyUseDefinedUOM 
            /// </summary>
            public const int OnlyUseDefinedUOM = 133;

            /// <summary>
            /// Property Indexer for AgingPeriod1 
            /// </summary>
            public const int AgingPeriod1 = 134;

            /// <summary>
            /// Property Indexer for AgingPeriod2 
            /// </summary>
            public const int AgingPeriod2 = 135;

            /// <summary>
            /// Property Indexer for AgingPeriod3 
            /// </summary>
            public const int AgingPeriod3 = 136;

            /// <summary>
            /// Property Indexer for CreateSubledgerOrAuditDuring 
            /// </summary>
            public const int CreateSubledgerOrAuditDuring = 137;

            /// <summary>
            /// Property Indexer for NextInternalUsageEntrySeq 
            /// </summary>
            public const int NextInternalUsageEntrySeq = 138;

            /// <summary>
            /// Property Indexer for InternalUsageNumberLength 
            /// </summary>
            public const int InternalUsageNumberLength = 139;

            /// <summary>
            /// Property Indexer for InternalUsageNumberPrefix 
            /// </summary>
            public const int InternalUsageNumberPrefix = 140;

            /// <summary>
            /// Property Indexer for ICSBODYD 
            /// </summary>
            public const int ICSBODYD = 141;

            /// <summary>
            /// Property Indexer for DefaultInternalUsageNumber 
            /// </summary>
            public const int DefaultInternalUsageNumber = 142;

            /// <summary>
            /// Property Indexer for ICSVALUE 
            /// </summary>
            public const int ICSVALUE = 143;

            /// <summary>
            /// Property Indexer for TransactionpostOrdepOrcost 
            /// </summary>
            public const int TransactionpostOrdepOrcost = 144;

            /// <summary>
            /// Property Indexer for IOrCReceipts 
            /// </summary>
            public const int IOrCReceipts = 145;

            /// <summary>
            /// Property Indexer for IOrCReceiptReturns 
            /// </summary>
            public const int IOrCReceiptReturns = 146;

            /// <summary>
            /// Property Indexer for IOrCReceiptAdjustments 
            /// </summary>
            public const int IOrCReceiptAdjustments = 147;

            /// <summary>
            /// Property Indexer for IOrCShipments 
            /// </summary>
            public const int IOrCShipments = 148;

            /// <summary>
            /// Property Indexer for IOrCShipmentReturns 
            /// </summary>
            public const int IOrCShipmentReturns = 149;

            /// <summary>
            /// Property Indexer for IOrCTransfers 
            /// </summary>
            public const int IOrCTransfers = 150;

            /// <summary>
            /// Property Indexer for IOrCAssemblies 
            /// </summary>
            public const int IOrCAssemblies = 151;

            /// <summary>
            /// Property Indexer for IOrCAdjustments 
            /// </summary>
            public const int IOrCAdjustments = 152;

            /// <summary>
            /// Property Indexer for IOrCConsolidatedEntry 
            /// </summary>
            public const int IOrCConsolidatedEntry = 153;

            /// <summary>
            /// Property Indexer for IOrCDisassemblies 
            /// </summary>
            public const int IOrCDisassemblies = 154;

            /// <summary>
            /// Property Indexer for IOrCInternalUsage 
            /// </summary>
            public const int IOrCInternalUsage = 155;

            /// <summary>
            /// Property Indexer for DefaultPostingDate 
            /// </summary>
            public const int DefaultPostingDate = 156;

            /// <summary>
            /// Property Indexer for SerialNumberMask 
            /// </summary>
            public const int SerialNumberMask = 157;

            /// <summary>
            /// Property Indexer for UseSerialsDaystoExpire 
            /// </summary>
            public const int UseSerialsDaystoExpire = 158;

            /// <summary>
            /// Property Indexer for SerialsDaystoExpire 
            /// </summary>
            public const int SerialsDaystoExpire = 159;

            /// <summary>
            /// Property Indexer for AllowDifferentSerialQty 
            /// </summary>
            public const int AllowDifferentSerialQty = 160;

            /// <summary>
            /// Property Indexer for AllowSerialAlloconQtyOrd 
            /// </summary>
            public const int AllowSerialAlloconQtyOrd = 161;

            /// <summary>
            /// Property Indexer for SortSerialsby 
            /// </summary>
            public const int SortSerialsby = 162;

            /// <summary>
            /// Property Indexer for SortSerialsFirstby 
            /// </summary>
            public const int SortSerialsFirstby = 163;

            /// <summary>
            /// Property Indexer for StopAllocationofExpiredSeria 
            /// </summary>
            public const int StopAllocationofExpiredSeria = 164;

            /// <summary>
            /// Property Indexer for SerialsHyphenasSeparator 
            /// </summary>
            public const int SerialsHyphenasSeparator = 165;

            /// <summary>
            /// Property Indexer for SerialsFwdSlashasSeparator 
            /// </summary>
            public const int SerialsFwdSlashasSeparator = 166;

            /// <summary>
            /// Property Indexer for SerialsBackSlashasSeparator 
            /// </summary>
            public const int SerialsBackSlashasSeparator = 167;

            /// <summary>
            /// Property Indexer for SerialsAsteriskasSeparator 
            /// </summary>
            public const int SerialsAsteriskasSeparator = 168;

            /// <summary>
            /// Property Indexer for SerialsPeriodasSeparator 
            /// </summary>
            public const int SerialsPeriodasSeparator = 169;

            /// <summary>
            /// Property Indexer for SerialsLeftParenthesisasSep 
            /// </summary>
            public const int SerialsLeftParenthesisasSep = 170;

            /// <summary>
            /// Property Indexer for SerialsRightParenthesisasSep 
            /// </summary>
            public const int SerialsRightParenthesisasSep = 171;

            /// <summary>
            /// Property Indexer for SerialsPoundSignasSeparator 
            /// </summary>
            public const int SerialsPoundSignasSeparator = 172;

            /// <summary>
            /// Property Indexer for SerialsLeftBracketasSep 
            /// </summary>
            public const int SerialsLeftBracketasSep = 173;

            /// <summary>
            /// Property Indexer for SerialsRightBracketasSep 
            /// </summary>
            public const int SerialsRightBracketasSep = 174;

            /// <summary>
            /// Property Indexer for SerialsLeftBraceasSep 
            /// </summary>
            public const int SerialsLeftBraceasSep = 175;

            /// <summary>
            /// Property Indexer for SerialsRightBraceasSep 
            /// </summary>
            public const int SerialsRightBraceasSep = 176;

            /// <summary>
            /// Property Indexer for LotNumberMask 
            /// </summary>
            public const int LotNumberMask = 177;

            /// <summary>
            /// Property Indexer for UseLotsDaystoExpire 
            /// </summary>
            public const int UseLotsDaystoExpire = 178;

            /// <summary>
            /// Property Indexer for LotsDaystoExpire 
            /// </summary>
            public const int LotsDaystoExpire = 179;

            /// <summary>
            /// Property Indexer for UseLotsDaysonQuarantine 
            /// </summary>
            public const int UseLotsDaysonQuarantine = 180;

            /// <summary>
            /// Property Indexer for LotsDaysonQuarantine 
            /// </summary>
            public const int LotsDaysonQuarantine = 181;

            /// <summary>
            /// Property Indexer for AllowDifferentLotQty 
            /// </summary>
            public const int AllowDifferentLotQty = 182;

            /// <summary>
            /// Property Indexer for AllowLotAlloconQtyOrd 
            /// </summary>
            public const int AllowLotAlloconQtyOrd = 183;

            /// <summary>
            /// Property Indexer for SortLotsby 
            /// </summary>
            public const int SortLotsby = 184;

            /// <summary>
            /// Property Indexer for SortLotsFirstby 
            /// </summary>
            public const int SortLotsFirstby = 185;

            /// <summary>
            /// Property Indexer for StopAllocationofExpiredLots 
            /// </summary>
            public const int StopAllocationofExpiredLots = 186;

            /// <summary>
            /// Property Indexer for LotsHyphenasSeparator 
            /// </summary>
            public const int LotsHyphenasSeparator = 187;

            /// <summary>
            /// Property Indexer for LotsFwdSlashasSeparator 
            /// </summary>
            public const int LotsFwdSlashasSeparator = 188;

            /// <summary>
            /// Property Indexer for LotsBackSlashasSeparator 
            /// </summary>
            public const int LotsBackSlashasSeparator = 189;

            /// <summary>
            /// Property Indexer for LotsAsteriskasSeparator 
            /// </summary>
            public const int LotsAsteriskasSeparator = 190;

            /// <summary>
            /// Property Indexer for LotsPeriodasSeparator 
            /// </summary>
            public const int LotsPeriodasSeparator = 191;

            /// <summary>
            /// Property Indexer for LotsLeftParenthesisasSep 
            /// </summary>
            public const int LotsLeftParenthesisasSep = 192;

            /// <summary>
            /// Property Indexer for LotsRightParenthesisasSep 
            /// </summary>
            public const int LotsRightParenthesisasSep = 193;

            /// <summary>
            /// Property Indexer for LotsPoundSignasSeparator 
            /// </summary>
            public const int LotsPoundSignasSeparator = 194;

            /// <summary>
            /// Property Indexer for LotsLeftBracketasSeparator 
            /// </summary>
            public const int LotsLeftBracketasSeparator = 195;

            /// <summary>
            /// Property Indexer for LotsRightBracketasSeparator 
            /// </summary>
            public const int LotsRightBracketasSeparator = 196;

            /// <summary>
            /// Property Indexer for LotsLeftBraceasSeparator 
            /// </summary>
            public const int LotsLeftBraceasSeparator = 197;

            /// <summary>
            /// Property Indexer for LotsRightBraceasSeparator 
            /// </summary>
            public const int LotsRightBraceasSeparator = 198;

            /// <summary>
            /// Property Indexer for RecallOrReleaseSequenceNumber 
            /// </summary>
            public const int RecallOrReleaseSequenceNumber = 199;

            /// <summary>
            /// Property Indexer for RecallNumberLength 
            /// </summary>
            public const int RecallNumberLength = 200;

            /// <summary>
            /// Property Indexer for RecallNumberPrefix 
            /// </summary>
            public const int RecallNumberPrefix = 201;

            /// <summary>
            /// Property Indexer for RECBODYD 
            /// </summary>
            public const int RECBODYD = 202;

            /// <summary>
            /// Property Indexer for DefaultRecallNumber 
            /// </summary>
            public const int DefaultRecallNumber = 203;

            /// <summary>
            /// Property Indexer for RECVALUE 
            /// </summary>
            public const int RECVALUE = 204;

            /// <summary>
            /// Property Indexer for ReleaseNumberLength 
            /// </summary>
            public const int ReleaseNumberLength = 205;

            /// <summary>
            /// Property Indexer for ReleaseNumberPrefix 
            /// </summary>
            public const int ReleaseNumberPrefix = 206;

            /// <summary>
            /// Property Indexer for RELBODYD 
            /// </summary>
            public const int RELBODYD = 207;

            /// <summary>
            /// Property Indexer for DefaultReleaseNumber 
            /// </summary>
            public const int DefaultReleaseNumber = 208;

            /// <summary>
            /// Property Indexer for RELVALUE 
            /// </summary>
            public const int RELVALUE = 209;

            /// <summary>
            /// Property Indexer for CombineOrSplitSequenceNumber 
            /// </summary>
            public const int CombineOrSplitSequenceNumber = 210;

            /// <summary>
            /// Property Indexer for CombineNumberLength 
            /// </summary>
            public const int CombineNumberLength = 211;

            /// <summary>
            /// Property Indexer for CombineNumberPrefix 
            /// </summary>
            public const int CombineNumberPrefix = 212;

            /// <summary>
            /// Property Indexer for COMBODYD 
            /// </summary>
            public const int COMBODYD = 213;

            /// <summary>
            /// Property Indexer for DefaultCombineNumber 
            /// </summary>
            public const int DefaultCombineNumber = 214;

            /// <summary>
            /// Property Indexer for COMVALUE 
            /// </summary>
            public const int COMVALUE = 215;

            /// <summary>
            /// Property Indexer for SplitNumberLength 
            /// </summary>
            public const int SplitNumberLength = 216;

            /// <summary>
            /// Property Indexer for SplitNumberPrefix 
            /// </summary>
            public const int SplitNumberPrefix = 217;

            /// <summary>
            /// Property Indexer for SPLBODYD 
            /// </summary>
            public const int SPLBODYD = 218;

            /// <summary>
            /// Property Indexer for DefaultSplitNumber 
            /// </summary>
            public const int DefaultSplitNumber = 219;

            /// <summary>
            /// Property Indexer for SPLVALUE 
            /// </summary>
            public const int SPLVALUE = 220;

            /// <summary>
            /// Property Indexer for ReconciliationSequenceNumber 
            /// </summary>
            public const int ReconciliationSequenceNumber = 221;

            /// <summary>
            /// Property Indexer for ReconciliationNumberLength 
            /// </summary>
            public const int ReconciliationNumberLength = 222;

            /// <summary>
            /// Property Indexer for ReconciliationNumberPrefix 
            /// </summary>
            public const int ReconciliationNumberPrefix = 223;

            /// <summary>
            /// Property Indexer for RCNBODYD 
            /// </summary>
            public const int RCNBODYD = 224;

            /// <summary>
            /// Property Indexer for DefaultReconciliationNumber 
            /// </summary>
            public const int DefaultReconciliationNumber = 225;

            /// <summary>
            /// Property Indexer for RCNVALUE 
            /// </summary>
            public const int RCNVALUE = 226;

            /// <summary>
            /// Property Indexer for SeparatorLeftBracket 
            /// </summary>
            public const int SeparatorLeftBracket = 227;

            /// <summary>
            /// Property Indexer for SeparatorRightBracket 
            /// </summary>
            public const int SeparatorRightBracket = 228;

            /// <summary>
            /// Property Indexer for SeparatorLeftBrace 
            /// </summary>
            public const int SeparatorLeftBrace = 229;

            /// <summary>
            /// Property Indexer for SeparatorRightBrace 
            /// </summary>
            public const int SeparatorRightBrace = 230;

            /// <summary>
            /// Property Indexer for AllowDuplicateSerials 
            /// </summary>
            public const int AllowDuplicateSerials = 231;

            /// <summary>
            /// Property Indexer for Last Day End Process Date
            /// </summary>
            public const int LastDayEndProcessDate = 243;

            /// <summary>
            /// Property Indexer for Last Day End Process Time
            /// </summary>
            public const int LastDayEndProcessTime = 244;

            /// <summary>
            /// Property Indexer for Last Day End UserID
            /// </summary>
            public const int LastDayEndProcessUserID = 247;

            #endregion
        }
    }
}