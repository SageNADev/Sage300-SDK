﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contains list of InternalUsageLotNumber Constants
    /// </summary>
    public partial class InternalUsageLotNumber
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "IC0282";

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageLotNumber Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for SequenceNumber
            /// </summary>
            public const string SequenceNumber = "SEQUENCENO";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINENO";

            /// <summary>
            /// Property for LotNumber
            /// </summary>
            public const string LotNumber = "LOTNUMF";

            /// <summary>
            /// Property for ExpiryDate
            /// </summary>
            public const string ExpiryDate = "EXPIRYDATE";

            /// <summary>
            /// Property for TransactionQuantity
            /// </summary>
            public const string TransactionQuantity = "QTY";

            /// <summary>
            /// Property for LotQuantityInStockingUOM
            /// </summary>
            public const string LotQuantityInStockingUOM = "QTYSQ";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InternalUsageLotNumber Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for SequenceNumber
            /// </summary>
            public const int SequenceNumber = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for LotNumber
            /// </summary>
            public const int LotNumber = 3;

            /// <summary>
            /// Property Indexer for ExpiryDate
            /// </summary>
            public const int ExpiryDate = 5;

            /// <summary>
            /// Property Indexer for TransactionQuantity
            /// </summary>
            public const int TransactionQuantity = 6;

            /// <summary>
            /// Property Indexer for LotQuantityInStockingUOM
            /// </summary>
            public const int LotQuantityInStockingUOM = 7;

        }

        #endregion

    }
}
