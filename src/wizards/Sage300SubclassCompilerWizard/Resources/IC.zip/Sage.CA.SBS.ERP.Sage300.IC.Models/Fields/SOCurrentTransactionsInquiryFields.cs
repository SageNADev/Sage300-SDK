// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
    /// Contains list of CurrentTransactionsInquiry For SalesOrder Constants
	/// </summary>
    public partial class SOCurrentTransactionsInquiry
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "IC0271";

		#region Properties

		/// <summary>
        /// Contains list of CurrentTransactionsInquiryfor SalesOrder Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEM";

			/// <summary>
			/// Property for OrderUniquifier
			/// </summary>
			public const string OrderUniquifier = "ORDUNIQ";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
			/// Property for OrderNumber
			/// </summary>
			public const string OrderNumber = "ORDNUMBER";

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "CUSTOMER";

			/// <summary>
			/// Property for CustomerName
			/// </summary>
			public const string CustomerName = "BILNAME";

			/// <summary>
			/// Property for ExpectedShipDate
			/// </summary>
			public const string ExpectedShipDate = "EXPDATE";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "OELOCATION";

			/// <summary>
			/// Property for OriginalQuantityOrdered
			/// </summary>
			public const string OriginalQuantityOrdered = "ORIGQTY";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "ORDUNIT";

			/// <summary>
			/// Property for QuantityShipped
			/// </summary>
			public const string QuantityShipped = "QTYSHPTODT";

			/// <summary>
			/// Property for QuantityOutstanding
			/// </summary>
			public const string QuantityOutstanding = "QTYORDERED";

		}

		#endregion

		#region Index

		/// <summary>
        /// Contains list of CurrentTransactionsInquiryfor SalesOrder Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 1;

			/// <summary>
			/// Property Indexer for OrderUniquifier
			/// </summary>
			public const int OrderUniquifier = 2;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 3;

			/// <summary>
			/// Property Indexer for OrderNumber
			/// </summary>
			public const int OrderNumber = 4;

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 5;

			/// <summary>
			/// Property Indexer for CustomerName
			/// </summary>
			public const int CustomerName = 6;

			/// <summary>
			/// Property Indexer for ExpectedShipDate
			/// </summary>
			public const int ExpectedShipDate = 7;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 8;

			/// <summary>
			/// Property Indexer for OriginalQuantityOrdered
			/// </summary>
			public const int OriginalQuantityOrdered = 9;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 10;

			/// <summary>
			/// Property Indexer for QuantityShipped
			/// </summary>
			public const int QuantityShipped = 11;

			/// <summary>
			/// Property Indexer for QuantityOutstanding
			/// </summary>
			public const int QuantityOutstanding = 12;

		}

		#endregion

	}
}
