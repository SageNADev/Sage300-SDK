﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region NameSpaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Classes for SerialNumberInquiry
    /// </summary>
    public class SerialNumberInquiry : ModelBase
    {
        /// <summary>
        /// Constant for char 'Z'
        /// </summary>
        private const char Z = 'Z';

        /// <summary>
        /// Constant Char for 'z'
        /// </summary>
        private const char z = 'z';

        /// <summary>
        /// Integer constant for SerialNumberLength
        /// </summary>
        private const int SerialNumberLength = 40;

        /// <summary>
        /// Integer constant for ItemNumberRecurringLength
        /// </summary>
        private const int ItemNumberRecurringLength = 24;

        /// <summary>
        /// Integer constant for LocationNumberLength
        /// </summary>
        private const int LocationNumberLength = 6;

        /// <summary>
        /// Gets or sets the property of FromSerialNumber
        /// </summary>
        [StringLength(SerialNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialNumber", ResourceType = typeof(ICCommonResx))]
        public string FromSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of ToSerialNumber
        /// </summary>
        [StringLength(SerialNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of ItemNumberFrom
        /// </summary>
        [StringLength(ItemNumberRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        public string FromItemNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of ItemNumberTo
        /// </summary>
        [StringLength(ItemNumberRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToItemNumber { get; set; }

        /// <summary>
        /// Gets or sets the LocationFrom
        /// </summary>
        [StringLength(LocationNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        public string FromLocation { get; set; }

        /// <summary>
        /// Gets or sets the LocationTo
        /// </summary>
        [StringLength(LocationNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToLocation { get; set; }

        /// <summary>
        /// From Stock Date
        /// </summary>
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        public DateTime? FromStockDate { get; set; }

        /// <summary>
        /// To Stock Date
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        public DateTime? ToStockDate { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        public InventorySerialNumberStatus Status { get; set; }

        /// <summary>
        /// Gets or sets an EnumerableResponse of objects of type <see cref="InventorySerialNumbers" />
        /// </summary>
        public EnumerableResponse<InventorySerialNumber> InventorySerialNumbers { get; set; }

        #region Constructor

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public SerialNumberInquiry()
        {
            ToItemNumber=CommonUtil.Repeat(Z, ItemNumberRecurringLength);
            ToSerialNumber = CommonUtil.Repeat(z, SerialNumberLength);
            ToLocation = CommonUtil.Repeat(Z, LocationNumberLength);
        }

        #endregion
    }
}