// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for Assembly Serial Detail
	/// </summary>
	public partial class AssemblySerialDetail : ModelBase
	{
		/// <summary>
		/// Gets or sets SequenceNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long SequenceNumber { get; set; }

		/// <summary>
		/// Gets or sets ComponentID
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ComponentID", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ComponentID, Id = Index.ComponentID, FieldType = EntityFieldType.Long, Size = 4)]
		public long ComponentID { get; set; }

		/// <summary>
		/// Gets or sets ParentComponentID
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ParentComponentID", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ParentComponentID, Id = Index.ParentComponentID, FieldType = EntityFieldType.Long, Size = 4)]
		public long ParentComponentID { get; set; }

		/// <summary>
		/// Gets or sets SerialNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "SerialNumber", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string SerialNumber { get; set; }

		/// <summary>
		/// Gets or sets MasterItemSerialNumber
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MasterItemSerialNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MasterItemSerialNumber, Id = Index.MasterItemSerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string MasterItemSerialNumber { get; set; }

		/// <summary>
		/// Gets or sets ItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ItemNumber", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ItemNumber { get; set; }

		/// <summary>
		/// Gets or sets BOMNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "BOMNumber", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.BOMNumber, Id = Index.BOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string BOMNumber { get; set; }

		/// <summary>
		/// Gets or sets UnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "UnitOfMeasure", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
		public string UnitOfMeasure { get; set; }

		#region UI Strings

		#endregion
	}
}
