// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for Receipt Header
    /// </summary>
    public partial class ReceiptHeader : ModelBase
    {
        /// <summary>
        /// This constructor initializes EnumerableResponses/Lists to be empty.
        /// This avoids the problem of serializing null collections.
        /// </summary>
        public ReceiptHeader() 
        {
            ReceiptDetail = new EnumerableResponse<ReceiptDetail>();
            ReceiptOptionalField = new EnumerableResponse<ReceiptOptionalField>();
            ReceiptDetailOptionalField = new EnumerableResponse<ReceiptDetailOptionalField>();
            ReceiptDetailLotNumber = new EnumerableResponse<ReceiptDetailLotNumber>();
            ReceiptDetailSerialNumber = new EnumerableResponse<ReceiptDetailSerialNumber>();
            // Casts from List to IList.
        }

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDate", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PurchaseOrderNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets ReceiptType
        /// </summary>
        [Display(Name = "ReceiptType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ReceiptType, Id = Index.ReceiptType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ReceiptType ReceiptType { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets VendorNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(ICCommonResx))]    
        [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptCurrency", ResourceType = typeof(ReceiptResx))]   
        [ViewField(Name = Fields.ReceiptCurrency, Id = Index.ReceiptCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ReceiptCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ICCommonResx))]           
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(ICCommonResx))]   
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [Display(Name = "RateDate", ResourceType = typeof(ICCommonResx))]   
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOverride
        /// </summary>
        [Display(Name = "RateOverride", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.RateOverride, Id = Index.RateOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.RateOverride RateOverride { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCost
        /// </summary>
        [Display(Name = "AdditionalCost", ResourceType = typeof(ICCommonResx))]          
        [ViewField(Name = Fields.AdditionalCost, Id = Index.AdditionalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdditionalCost { get; set; }

        /// <summary>
        /// Gets or sets OrigAdditionalCostFunc
        /// </summary>
        [Display(Name = "OrigAdditionalCostFunc", ResourceType = typeof(ReceiptResx))]        
        [ViewField(Name = Fields.OrigAdditionalCostFunc, Id = Index.OrigAdditionalCostFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrigAdditionalCostFunc { get; set; }

        /// <summary>
        /// Gets or sets OrigAdditionalCostSource
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OrigAdditionalCostSource", ResourceType = typeof(ReceiptResx))]   
        [ViewField(Name = Fields.OrigAdditionalCostSource, Id = Index.OrigAdditionalCostSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OrigAdditionalCostSource { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdditionalCostCurrency", ResourceType = typeof(ReceiptResx))]        
        [ViewField(Name = Fields.AdditionalCostCurrency, Id = Index.AdditionalCostCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string AdditionalCostCurrency { get; set; }

        /// <summary>
        /// Gets or sets TotalExtendedCostFunctional
        /// </summary>
        [Display(Name = "TotalExtendedCostFunctional", ResourceType = typeof(ReceiptResx))] 
        [ViewField(Name = Fields.TotalExtendedCostFunctional, Id = Index.TotalExtendedCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalExtendedCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets TotalExtendedCostSource
        /// </summary>
        [Display(Name = "TotalExtendedCostSource", ResourceType = typeof(ReceiptResx))]         
        [ViewField(Name = Fields.TotalExtendedCostSource, Id = Index.TotalExtendedCostSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalExtendedCostSource { get; set; }

        /// <summary>
        /// Gets or sets TotalExtendedCostAdjusted
        /// </summary>
        [Display(Name = "TotalExtendedCostAdjusted", ResourceType = typeof(ReceiptResx))]         
        [ViewField(Name = Fields.TotalExtendedCostAdjusted, Id = Index.TotalExtendedCostAdjusted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalExtendedCostAdjusted { get; set; }

        /// <summary>
        /// Gets or sets TotalAdjustedCostFunctional
        /// </summary>
        [IgnoreExportImport] 
        [Display(Name = "TotalAdjustedCostFunctional", ResourceType = typeof(ReceiptResx))] 
        [ViewField(Name = Fields.TotalAdjustedCostFunctional, Id = Index.TotalAdjustedCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdjustedCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets TotalReturnCost
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TotalReturnCost", ResourceType = typeof(ReceiptResx))] 
        [ViewField(Name = Fields.TotalReturnCost, Id = Index.TotalReturnCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalReturnCost { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetailswithCost
        /// </summary>
        [Display(Name = "NumberOfDetailswithCost", ResourceType = typeof(ReceiptResx))]         
        [ViewField(Name = Fields.NumberOfDetailswithCost, Id = Index.NumberOfDetailswithCost, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfDetailswithCost { get; set; }

        /// <summary>
        /// Gets or sets RequireLabels
        /// </summary>
        [Display(Name = "RequireLabels", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.RequireLabels, Id = Index.RequireLabels, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.RequireLabels RequireLabels { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostAllocationType
        /// </summary>
        [Display(Name = "AdditionalCostAllocationType", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.AdditionalCostAllocationType, Id = Index.AdditionalCostAllocationType, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.AddlCostonRcptReturns AdditionalCostAllocationType { get; set; }

        /// <summary>
        /// Gets or sets Complete
        /// </summary>
        [Display(Name = "Complete", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.Complete, Id = Index.Complete, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.Complete Complete { get; set; }

        /// <summary>
        /// Gets or sets OriginalTotalCostSource
        /// </summary>
        [Display(Name = "OriginalTotalCostSource", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.OriginalTotalCostSource, Id = Index.OriginalTotalCostSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalTotalCostSource { get; set; }

        /// <summary>
        /// Gets or sets OriginalTotalCostFunctional
        /// </summary>
        [Display(Name = "OriginalTotalCostFunctional", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.OriginalTotalCostFunctional, Id = Index.OriginalTotalCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalTotalCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostFunctional
        /// </summary>
        [Display(Name = "AdditionalCostFunctional", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.AdditionalCostFunctional, Id = Index.AdditionalCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdditionalCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets TotalCostReceiptAdditional
        /// </summary>
        [Display(Name = "AdditionalCostFunctional", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.TotalCostReceiptAdditional, Id = Index.TotalCostReceiptAdditional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCostReceiptAdditional { get; set; }

        /// <summary>
        /// Gets or sets TotalAdjCostReceiptAddl
        /// </summary>
        [Display(Name = "TotalAdjCostReceiptAddl", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.TotalAdjCostReceiptAddl, Id = Index.TotalAdjCostReceiptAddl, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdjCostReceiptAddl { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCurrencyDecimals
        /// </summary>
        [Display(Name = "ReceiptCurrencyDecimals", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ReceiptCurrencyDecimals, Id = Index.ReceiptCurrencyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReceiptCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets VendorShortName
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorShortName", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.VendorShortName, Id = Index.VendorShortName, FieldType = EntityFieldType.Char, Size = 10)]
        public string VendorShortName { get; set; }

        /// <summary>
        /// Gets or sets ICUniqueDocumentNumber
        /// </summary>
        [Display(Name = "ICUniqueDocumentNumber", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ICUniqueDocumentNumber, Id = Index.ICUniqueDocumentNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICUniqueDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorExists
        /// </summary>
        [Display(Name = "VendorExists", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.VendorExists VendorExists { get; set; }

        /// <summary>
        /// Gets or sets RecordDeleted
        /// </summary>
        [Display(Name = "RecordDeleted", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.RecordDeleted, Id = Index.RecordDeleted, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.RecordDeleted RecordDeleted { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(ReceiptResx))]     
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordStatus
        /// </summary>
        [Display(Name = "RecordStatus", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.RecordStatus, Id = Index.RecordStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.RecordStatus RecordStatus { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(ICCommonResx))]     
        [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets NextDetailLineNumber
        /// </summary>
        [Display(Name = "NextDetailLineNumber", ResourceType = typeof(ReceiptResx))]  
        [ViewField(Name = Fields.NextDetailLineNumber, Id = Index.NextDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordPrinted
        /// </summary>
        [Display(Name = "RecordPrinted", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.RecordPrinted, Id = Index.RecordPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.RecordPrinted RecordPrinted { get; set; }

        /// <summary>
        /// Gets or sets PostSequenceNumber
        /// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof(ReceiptResx))]  
        [ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long PostSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]  
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.ReceiptProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets VendorName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(ICCommonResx))]  
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(ReceiptResx))]  
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ICCommonResx))]  
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets Use ReceiptType string value
        /// </summary>
        [IgnoreExportImport]
        public string ReceiptTypeInText
        {
            get { return EnumUtility.GetStringValue(ReceiptType); }
        }

        /// <summary>
        /// Gets or sets Home currency 
        /// </summary>
        [IgnoreExportImport]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptDetail> ReceiptDetail { get; set; }

        /// <summary>
        /// Gets or sets ReceiptOptionalField
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptOptionalField> ReceiptOptionalField { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDetailOptionalField
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptDetailOptionalField> ReceiptDetailOptionalField { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDetailLotNumber
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptDetailLotNumber> ReceiptDetailLotNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDetailSerialNumber
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptDetailSerialNumber> ReceiptDetailSerialNumber { get; set; }

        /// <summary>
        /// IsOptionalFields is for validating the OptionalFields checkbox
        /// </summary> 
        [IgnoreExportImport]
        public bool IsOptionalFields { get; set; }

        /// <summary>
        /// IsRequireLabel is for validating the RequireLabels checkbox
        /// </summary> 
        [IgnoreExportImport]
        public bool IsRequireLabel { get; set; }

        #region User Defined

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string ReceiptTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(ReceiptType);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string RateOperationString
        {
            get
            {
                return EnumUtility.GetStringValue(RateOperation);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string RateOverrideString
        {
            get
            {
                return EnumUtility.GetStringValue(RateOverride);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string RequireLabelsString
        {
            get
            {
                return EnumUtility.GetStringValue(RequireLabels);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string AddlCostAllocationTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(AdditionalCostAllocationType);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string VendorExistsString
        {
            get
            {
                return EnumUtility.GetStringValue(VendorExists);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string RecordStatusString
        {
            get
            {
                return EnumUtility.GetStringValue(RecordStatus);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string CompleteString
        {
            get
            {
                return EnumUtility.GetStringValue(Complete);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string RecordDeletedString
        {
            get
            {
                return EnumUtility.GetStringValue(RecordDeleted);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string RecordPrintedString
        {
            get
            {
                return EnumUtility.GetStringValue(RecordPrinted);
            }
        }

        /// <summary>
        /// String value of Receipt Type
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandString
        {
            get
            {
                return EnumUtility.GetStringValue(ProcessCommand);
            }
        }

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        [IgnoreExportImport]
        public string FiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(FiscalPeriod); }
        }

        /// <summary>
        /// Gets or sets IsHeader
        /// </summary> 
        [IgnoreExportImport]
        public bool IsHeader { get; set; }

        /// <summary>
        /// TotalCostReceiptAdditionalDecimal
        /// </summary>
        public int TotalCostReceiptAdditionalDecimal { get; set; }

        /// <summary>
        /// TotalReturnCostDecimal
        /// </summary>
        public int TotalReturnCostDecimal { get; set; }

        #endregion
    }
}
