/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class Locations : ModelBase
    {

        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof (LocationsResx))]
        [Key]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof (LocationsResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Char, Size = 30)]
        public string State { get; set; }

        /// <summary>
        /// Gets or sets ZipOrPostalCode 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ZIPPostal", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20, Mask = "%-20C")]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Contact 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets SegmentOverride 
        /// </summary>
        [Display(Name = "SegmentOverride", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentOverride, Id = Index.SegmentOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SegmentOverride { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets DateInactive 
        /// </summary>
        [Display(Name = "DateInactive", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateInactive { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber1 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber1", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber1, Id = Index.SegmentNumber1, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue1 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue1", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue1, Id = Index.SegmentValue1, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue1 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber2 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber2", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber2, Id = Index.SegmentNumber2, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue2 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue2", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue2, Id = Index.SegmentValue2, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue2 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber3 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber3", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber3, Id = Index.SegmentNumber3, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue3 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue3", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue3, Id = Index.SegmentValue3, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue3 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber4 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber4", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber4, Id = Index.SegmentNumber4, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue4 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue4", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue4, Id = Index.SegmentValue4, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue4 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber5 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber5", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber5, Id = Index.SegmentNumber5, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue5 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue5", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue5, Id = Index.SegmentValue5, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue5 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber6 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber6", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber6, Id = Index.SegmentNumber6, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber6 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue6 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue6", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue6, Id = Index.SegmentValue6, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue6 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber7 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber7", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber7, Id = Index.SegmentNumber7, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber7 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue7 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue7", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue7, Id = Index.SegmentValue7, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue7 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber8 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber8", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber8, Id = Index.SegmentNumber8, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber8 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue8 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue8", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue8, Id = Index.SegmentValue8, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue8 { get; set; }

        /// <summary>
        /// Gets or sets SegmentNumber9 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentNumber9", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentNumber9, Id = Index.SegmentNumber9, FieldType = EntityFieldType.Char, Size = 6)]
        public string SegmentNumber9 { get; set; }

        /// <summary>
        /// Gets or sets SegmentValue9 
        /// </summary>
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentValue9", ResourceType = typeof(LocationsResx))]
        [ViewField(Name = Fields.SegmentValue9, Id = Index.SegmentValue9, FieldType = EntityFieldType.Char, Size = 15, Mask = "%-15N")]
        public string SegmentValue9 { get; set; }

        /// <summary>
        /// Gets or sets LocationEmail 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.LocationEmail, Id = Index.LocationEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string LocationEmail { get; set; }

        /// <summary>
        /// Gets or sets ContactPhone 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactFax 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactFax { get; set; }

        /// <summary>
        /// Gets or sets ContactEmail 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactEmail { get; set; }

        /// <summary>
        /// Gets or sets LocationType 
        /// </summary>
        [Display(Name = "LocType", ResourceType = typeof (LocationsResx))]
        [ViewField(Name = Fields.LocationType, Id = Index.LocationType, FieldType = EntityFieldType.Int, Size = 2)]
        public LocationType LocationType { get; set; }


         /// <summary>
        /// UI Property
        /// </summary>
        public string StatusDescription 
        {
            get
            {
                if (Status)
                {
                    return EnumUtility.GetStringValue(IC.Models.Enums.Status.Inactive);
                }
                else
                {
                    return EnumUtility.GetStringValue(IC.Models.Enums.Status.Active);
                }
            }
        }
       

        /// <summary>
        /// UI Property
        /// </summary>
        public string LocationTypeDescription
        {
            get { return EnumUtility.GetStringValue(LocationType); }
        }

        /// <summary>
        /// UI Property
        /// </summary>
        public string SegmentOverrideDescription
        {
            get
            {
                if(SegmentOverride)
                {
                    return EnumUtility.GetStringValue(BooleanType.True);
                }
                else
                {
                    return EnumUtility.GetStringValue(BooleanType.False);
                }
            }
        }

        /// <summary>
        /// Gets or Sets SortByOptions
        /// </summary>
        public SortBy SortByOptions { get; set; }

    }
}
