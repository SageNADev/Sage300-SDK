// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class SegmentCode : ModelBase
    {
        /// <summary>
        /// Gets or sets SegmentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentName", ResourceType = typeof (SegmentCodesResx))]
        [Key]
        [ViewField(Name = Fields.SegmentNumber, Id = Index.SegmentNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public string SegmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Segment 
        /// </summary>
        public string Segment{ get; set; }

        /// <summary>
        /// Gets or sets SegmentCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentCode", ResourceType = typeof (SegmentCodesResx))]
        [Key]
        [ViewField(Name = Fields.SegmentCodeName, Id = Index.SegmentCodeName, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-2N")]
        public string SegmentCodeName { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "SegmentDescription", ResourceType = typeof (SegmentCodesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }
    }
}
