// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for PricingPriceCheck
    /// </summary>
    public partial class PricingPriceCheck : ModelBase
    {
        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets PriceListCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "PriceListCode", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.PriceListCode, Id = Index.PriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceListCode { get; set; }

        /// <summary>
        /// Gets or sets UserID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof (ItemPricingResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets RecordExists
        /// </summary>
        [Display(Name = "RecordExists", ResourceType = typeof (ICCommonResx))]
        [IsMvcSpecific]
        [ViewField(Name = Fields.RecordExists, Id = Index.RecordExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordExists RecordExists { get; set; }

        /// <summary>
        /// Gets or sets GreaterthanPercentage
        /// </summary>
        [Display(Name = "GreaterthanPercentage", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.GreaterthanPercentage, Id = Index.GreaterthanPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal GreaterthanPercentage { get; set; }

        /// <summary>
        /// Gets or sets LessthanPercentage
        /// </summary>
        [Display(Name = "LessthanPercentage", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.LessthanPercentage, Id = Index.LessthanPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal LessthanPercentage { get; set; }

        /// <summary>
        /// Gets or sets GreaterthanAmount
        /// </summary>
        [Display(Name = "GreaterthanAmount", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.GreaterthanAmount, Id = Index.GreaterthanAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal GreaterthanAmount { get; set; }

        /// <summary>
        /// Gets or sets LessthanAmount
        /// </summary>
        [Display(Name = "LessthanAmount", ResourceType = typeof (ICCommonResx))]
        [ViewField(Name = Fields.LessthanAmount, Id = Index.LessthanAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal LessthanAmount { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber - Unique key for grid rows
        /// </summary>
        [IgnoreExportImport]
        [IsMvcSpecific]
        public long SerialNumber { get; set; }

    }
}
