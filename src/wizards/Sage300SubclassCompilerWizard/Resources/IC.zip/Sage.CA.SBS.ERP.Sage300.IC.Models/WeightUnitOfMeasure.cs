// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A class for Weight Unit of Measure
    /// </summary>
    public partial class WeightUnitOfMeasure : ModelBase
    {
        /// <summary>
        /// Gets or sets WeightUnitofMeasure 
        /// </summary>
        [Key]
        [Display(Name = "WeightUnitofMeasure", ResourceType = typeof (WeightUnitsOfMeasureResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.WeightUnitsOfMeasure, Id = Index.WeightUnitsOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitsOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ProcessingDescription", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets WeightConversionFactor 
        /// </summary>
        [Display(Name = "WeightConversionFactor", ResourceType = typeof (WeightUnitsOfMeasureResx))]
        [ViewField(Name = Fields.WeightConversionFactor, Id = Index.WeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal WeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets DefaultWeightUnitofMeasure 
        /// </summary>
        [Display(Name = "DefaultWeightUOM", ResourceType = typeof (WeightUnitsOfMeasureResx))]
        [ViewField(Name = Fields.DefaultWeightUnitOfMeasure, Id = Index.DefaultWeightUnitOfMeasure, FieldType = EntityFieldType.Bool, Size = 2)]
        public DefaultWeightUnitOfMeasure DefaultWeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Num10000inDefWeightUOMEquals 
        /// </summary>
        [Display(Name = "DefaultConversionYields", ResourceType = typeof (WeightUnitsOfMeasureResx))]
        [ViewField(Name = Fields.NumInDefWeightUomEquals, Id = Index.NumInDefWeightUomEquals, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumInDefWeightUomEquals { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets DefaultWeightUnitOfMeasureString
        /// </summary>
        public string DefaultWeightUnitOfMeasureString
        {
            get { return EnumUtility.GetStringValue(DefaultWeightUnitOfMeasure); }
        }
    }
}
