// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
     /// <summary>
     /// Partial class for Receipt Detail SerialNumber
     /// </summary>
     public partial class ReceiptDetailSerialNumber : ModelBase
     {
          /// <summary>
          /// Gets or sets SequenceNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]            
          [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
          public long SequenceNumber {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]            
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
          public int LineNumber {get; set;}

          /// <summary>
          /// Gets or sets SerialNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "SerialNumber", ResourceType = typeof(ICCommonResx))]                
          [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string SerialNumber {get; set;}

          /// <summary>
          /// Gets or sets SerialReturned
          /// </summary>
          [Display(Name = "SerialReturned", ResourceType = typeof(ICCommonResx))]           
          [ViewField(Name = Fields.SerialReturned, Id = Index.SerialReturned, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool SerialReturned {get; set;}

          /// <summary>
          /// Gets or sets TransactionQuantity
          /// </summary>
          [Display(Name = "TransactionQuantity", ResourceType = typeof(ICCommonResx))]             
          [ViewField(Name = Fields.TransactionQuantity, Id = Index.TransactionQuantity, FieldType = EntityFieldType.Long, Size = 4)]
          public long TransactionQuantity {get; set;}

          /// <summary>
          /// Gets or sets SerialQuantityReturned
          /// </summary>
          [Display(Name = "SerialQuantityReturned", ResourceType = typeof(ICCommonResx))]             
          [ViewField(Name = Fields.SerialQuantityReturned, Id = Index.SerialQuantityReturned, FieldType = EntityFieldType.Long, Size = 4)]
          public long SerialQuantityReturned {get; set;}
     }
}
