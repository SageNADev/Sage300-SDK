// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved. 

#region Usings

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class Item : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="Item" /> class.
        /// </summary>
        public Item()
        {
            UnitOfMeasureItems = new EnumerableResponse<ItemUnitOfMeasure>();
            TaxAuthorityItems = new EnumerableResponse<ItemTaxAuthority>();
            OptionalFieldItems = new EnumerableResponse<ItemOptionalField>();
        }


        /// <summary>
        /// Gets or sets UnformattedItemNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "UnformattedItemNo", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets AlternateItemSetNumber 
        /// </summary>
        [Display(Name = "AltItemSetNo", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.AlternateItemSetNumber, Id = Index.AlternateItemSetNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long AlternateItemSetNumber { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingDescription", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Status { get; set; }

        /// <summary>
        /// Gets or sets StructureCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StructureCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StructureCode, Id = Index.StructureCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string StructureCode { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [Key]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Category 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets AccountSetCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets StockItem 
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets StockingUnitOfMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StockingUnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StockingUnitOfMeasure, Id = Index.StockingUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string StockingUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets DefaultPriceListCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultPriceList", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DefaultPriceListCode, Id = Index.DefaultPriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultPriceListCode { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight 
        /// </summary>
        [Display(Name = "UnitWeight", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets DefaultPickingSequence 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PickingSeq", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.DefaultPickingSequence, Id = Index.DefaultPickingSequence, FieldType = EntityFieldType.Char, Size = 10)]
        public string DefaultPickingSequence { get; set; }

        /// <summary>
        /// Gets or sets SerialNumbers 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialNumbers, Id = Index.SerialNumbers, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem SerialNumbers { get; set; }

        /// <summary>
        /// Gets or sets CommodityNumber 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommodIm", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.CommodityNumber, Id = Index.CommodityNumber, FieldType = EntityFieldType.Char, Size = 16)]
        public string CommodityNumber { get; set; }

        /// <summary>
        /// Gets or sets DateInactive 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "InactiveAsOfDate", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateInactive { get; set; }

        /// <summary>
        /// Gets or sets Segment1 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg1", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment1, Id = Index.Segment1, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment1 { get; set; }

        /// <summary>
        /// Gets or sets Segment2 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg2", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment2, Id = Index.Segment2, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment2 { get; set; }

        /// <summary>
        /// Gets or sets Segment3 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg3", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment3, Id = Index.Segment3, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment3 { get; set; }

        /// <summary>
        /// Gets or sets Segment4 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg4", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment4, Id = Index.Segment4, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment4 { get; set; }

        /// <summary>
        /// Gets or sets Segment5 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg5", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment5, Id = Index.Segment5, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment5 { get; set; }

        /// <summary>
        /// Gets or sets Segment6 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg6", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment6, Id = Index.Segment6, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment6 { get; set; }

        /// <summary>
        /// Gets or sets Segment7 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg7", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment7, Id = Index.Segment7, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment7 { get; set; }

        /// <summary>
        /// Gets or sets Segment8 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg8", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment8, Id = Index.Segment8, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment8 { get; set; }

        /// <summary>
        /// Gets or sets Segment9 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg9", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment9, Id = Index.Segment9, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment9 { get; set; }

        /// <summary>
        /// Gets or sets Segment10 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Seg10", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Segment10, Id = Index.Segment10, FieldType = EntityFieldType.Char, Size = 24)]
        public string Segment10 { get; set; }

        /// <summary>
        /// Gets or sets Comment1 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment1", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.Comment1, Id = Index.Comment1, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comment1 { get; set; }

        /// <summary>
        /// Gets or sets Comment2 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment2", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.Comment2, Id = Index.Comment2, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comment2 { get; set; }

        /// <summary>
        /// Gets or sets Comment3 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment3", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.Comment3, Id = Index.Comment3, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comment3 { get; set; }

        /// <summary>
        /// Gets or sets Comment4 
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment4", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.Comment4, Id = Index.Comment4, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comment4 { get; set; }

        /// <summary>
        /// Gets or sets AllowItemInWebStore 
        /// </summary>
        [Display(Name = "InWebStore", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.AllowItemInWebStore, Id = Index.AllowItemInWebStore, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowItemInWebStore { get; set; }

        /// <summary>
        /// Gets or sets KittingItem 
        /// </summary>
        [Display(Name = "Kitting", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.KittingItem, Id = Index.KittingItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool KittingItem { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets DefaultKitNumber 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultKitNo", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.DefaultKitNumber, Id = Index.DefaultKitNumber, FieldType = EntityFieldType.Char, Size = 6)]
        public string DefaultKitNumber { get; set; }

        /// <summary>
        /// Gets or sets Sellable 
        /// </summary>
        [Display(Name = "Sellable", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.Sellable, Id = Index.Sellable, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Sellable { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitofMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WeightUnitofMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnformattedAlternateItemNo 
        /// </summary>
         [IgnoreExportImport]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedAltItemNo", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.UnformattedAlternateItemNo, Id = Index.UnformattedAlternateItemNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedAlternateItemNo { get; set; }

        /// <summary>
        /// Gets or sets AlternateItemNumber 
        /// </summary>
         [IgnoreExportImport]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AltItemNo", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.AlternateItemNumber, Id = Index.AlternateItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string AlternateItemNumber { get; set; }

        /// <summary>
        /// Gets or sets AlternateItemDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AltItemNoDesc", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.AlternateItemDescription, Id = Index.AlternateItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string AlternateItemDescription { get; set; }

        /// <summary>
        /// Gets or sets CostingMethod 
        /// </summary>
        [Display(Name = "CostingMethod", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostingMethod, Id = Index.CostingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public CostingMethod CostingMethod { get; set; }


        /// <summary>
        /// Gets or sets ProcessCommand 
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets WeightConversionFactor 
        /// </summary>
        [Display(Name = "WeightConversionFactor", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.WeightConversionFactor, Id = Index.WeightConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal WeightConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets IsItemaBomComponent 
        /// </summary>
        [Display(Name = "IsBOMComponent", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.IsItemaBomComponent, Id = Index.IsItemaBomComponent, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem IsItemaBomComponent { get; set; }

        /// <summary>
        /// Gets or sets SerialNumberMask 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialNumberMask, Id = Index.SerialNumberMask, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SerialNumberMask { get; set; }

        /// <summary>
        /// Gets or sets NextSerialNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.NextSerialNumber, Id = Index.NextSerialNumber, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string NextSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets UseSerialsDaysToExpire 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UseSerialsDaysToExpire, Id = Index.UseSerialsDaysToExpire, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem UseSerialsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets SerialsDaysToExpire 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialsDaysToExpire, Id = Index.SerialsDaysToExpire, FieldType = EntityFieldType.Int, Size = 2)]
        public int SerialsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets AllowDifferentSerialQty 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.AllowDifferentSerialQty, Id = Index.AllowDifferentSerialQty, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem AllowDifferentSerialQty { get; set; }

        /// <summary>
        /// Gets or sets SerialsOptionalFields 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialsOptionalFields, Id = Index.SerialsOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialsOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets DefaultSerialWarrantyCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DefaultSerialWarrantyCode, Id = Index.DefaultSerialWarrantyCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultSerialWarrantyCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultSerialContractCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DefaultSerialContractCode, Id = Index.DefaultSerialContractCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultSerialContractCode { get; set; }

        /// <summary>
        /// Gets or sets SerialIsOnContWhenReceived 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialIsOnContWhenReceived, Id = Index.SerialIsOnContWhenReceived, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem SerialIsOnContWhenReceived { get; set; }

        /// <summary>
        /// Gets or sets SerialIsOnWarrWhenSold 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialIsOnWarrWhenSold, Id = Index.SerialIsOnWarrWhenSold, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem SerialIsOnWarrWhenSold { get; set; }

        /// <summary>
        /// Gets or sets SerialIsOnWarrWhenRegister 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialIsOnWarrWhenRegister, Id = Index.SerialIsOnWarrWhenRegister, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem SerialIsOnWarrWhenRegister { get; set; }

        /// <summary>
        /// Gets or sets LotNumbers 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotNumbers, Id = Index.LotNumbers, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem LotNumbers { get; set; }

        /// <summary>
        /// Gets or sets LotNumberMask 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotNumberMask, Id = Index.LotNumberMask, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string LotNumberMask { get; set; }

        /// <summary>
        /// Gets or sets NextLotNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.NextLotNumber, Id = Index.NextLotNumber, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string NextLotNumber { get; set; }

        /// <summary>
        /// Gets or sets UseLotsDaysToExpire 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UseLotsDaysToExpire, Id = Index.UseLotsDaysToExpire, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem UseLotsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets LotsDaysToExpire 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotsDaysToExpire, Id = Index.LotsDaysToExpire, FieldType = EntityFieldType.Int, Size = 2)]
        public int LotsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets UseLotsDaysOnQuarantine 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UseLotsDaysOnQuarantine, Id = Index.UseLotsDaysOnQuarantine, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem UseLotsDaysOnQuarantine { get; set; }

        /// <summary>
        /// Gets or sets LotsDaysOnQuarantine 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotsDaysOnQuarantine, Id = Index.LotsDaysOnQuarantine, FieldType = EntityFieldType.Int, Size = 2)]
        public int LotsDaysOnQuarantine { get; set; }

        /// <summary>
        /// Gets or sets AllowDifferentLotQty 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.AllowDifferentLotQty, Id = Index.AllowDifferentLotQty, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem AllowDifferentLotQty { get; set; }

        /// <summary>
        /// Gets or sets LotsOptionalFields 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotsOptionalFields, Id = Index.LotsOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long LotsOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets DefaultLotWarrantyCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DefaultLotWarrantyCode, Id = Index.DefaultLotWarrantyCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultLotWarrantyCode { get; set; }

        /// <summary>
        /// Gets or sets DefaultLotContractCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DefaultLotContractCode, Id = Index.DefaultLotContractCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultLotContractCode { get; set; }

        /// <summary>
        /// Gets or sets LotIsOnContWhenReceived 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotIsOnContWhenReceived, Id = Index.LotIsOnContWhenReceived, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem LotIsOnContWhenReceived { get; set; }

        /// <summary>
        /// Gets or sets LotIsOnWarrWhenSold 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotIsOnWarrWhenSold, Id = Index.LotIsOnWarrWhenSold, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem LotIsOnWarrWhenSold { get; set; }

        /// <summary>
        /// Gets or sets SerialNumbersInUse 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialNumbersInUse, Id = Index.SerialNumbersInUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem SerialNumbersInUse { get; set; }

        /// <summary>
        /// Gets or sets SerialMaskStructure 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialMaskStructure, Id = Index.SerialMaskStructure, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string SerialMaskStructure { get; set; }

        /// <summary>
        /// Gets or sets SerialMaskDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialMaskDescription, Id = Index.SerialMaskDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string SerialMaskDescription { get; set; }

        /// <summary>
        /// Gets or sets UnformattedSerialNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.UnformattedSerialNumber, Id = Index.UnformattedSerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string UnformattedSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets AutogenSerialNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AutogenSerialNumber, Id = Index.AutogenSerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string AutogenSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfSerialsToGenerate 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfSerialsToGenerate, Id = Index.NumberOfSerialsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfSerialsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfSerialsNotGenerated 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfSerialsNotGenerated, Id = Index.NumberOfSerialsNotGenerated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfSerialsNotGenerated { get; set; }

        /// <summary>
        /// Gets or sets FirstGeneratedSerial 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.FirstGeneratedSerial, Id = Index.FirstGeneratedSerial, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string FirstGeneratedSerial { get; set; }

        /// <summary>
        /// Gets or sets LastGeneratedSerial 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LastGeneratedSerial, Id = Index.LastGeneratedSerial, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string LastGeneratedSerial { get; set; }

        /// <summary>
        /// Gets or sets LotNumbersInUse 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotNumbersInUse, Id = Index.LotNumbersInUse, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem LotNumbersInUse { get; set; }

        /// <summary>
        /// Gets or sets LotMaskStructure 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotMaskStructure, Id = Index.LotMaskStructure, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string LotMaskStructure { get; set; }

        /// <summary>
        /// Gets or sets LotMaskDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotMaskDescription, Id = Index.LotMaskDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LotMaskDescription { get; set; }

        /// <summary>
        /// Gets or sets UnformattedLotNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.UnformattedLotNumber, Id = Index.UnformattedLotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string UnformattedLotNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets AutogenLotNumber 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AutogenLotNumber, Id = Index.AutogenLotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string AutogenLotNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsNotGenerated 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfLotsNotGenerated, Id = Index.NumberOfLotsNotGenerated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsNotGenerated { get; set; }

        /// <summary>
        /// Gets or sets FirstGeneratedLot 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.FirstGeneratedLot, Id = Index.FirstGeneratedLot, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string FirstGeneratedLot { get; set; }

        /// <summary>
        /// Gets or sets LastGeneratedLot 
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LastGeneratedLot, Id = Index.LastGeneratedLot, FieldType = EntityFieldType.Char, Size = 40, Mask = "%-40c")]
        public string LastGeneratedLot { get; set; }

        /// <summary>
        /// Gets or sets SiaPreferredVendorType 
        /// </summary>
        [Display(Name = "SIAPreferredVendType", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.SiaPreferredVendorType, Id = Index.SiaPreferredVendorType, FieldType = EntityFieldType.Int, Size = 2)]
        public int SiaPreferredVendorType { get; set; }

        /// <summary>
        /// Gets or sets DefaultBomNumber 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultBOMNo", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.DefaultBomNumber, Id = Index.DefaultBomNumber, FieldType = EntityFieldType.Char, Size = 6)]
        public string DefaultBomNumber { get; set; }

        /// <summary>
        /// Gets or sets Unit Of Measures
        /// </summary>
        public EnumerableResponse<ItemUnitOfMeasure> UnitOfMeasureItems { get; set; }

        /// <summary>
        /// Gets or sets Tax Authorities
        /// </summary>
        public EnumerableResponse<ItemTaxAuthority> TaxAuthorityItems { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        public EnumerableResponse<ItemOptionalField> OptionalFieldItems { get; set; }

        /// <summary>
        /// Gets or sets Status1 
        /// </summary>
        [IgnoreExportImport]
        public Status Status1 { get; set; }
        /// <summary>
        /// Gets or sets StockItem1 
        /// </summary>
        [IgnoreExportImport]
        public Validate StockItem1 { get; set; }
        /// <summary>
        /// Gets or sets Sellable1 
        /// </summary>
        [IgnoreExportImport]
        public Validate Sellable1 { get; set; }

        /// <summary>
        /// Gets or sets AllowItemInWebStore1 
        /// </summary>
        [IgnoreExportImport]
        public Validate AllowItemInWebStore1 { get; set; }
        /// <summary>
        /// Gets or sets KittingItem1 
        /// </summary>
        [IgnoreExportImport]
        public Validate KittingItem1 { get; set; }

        /// <summary>
        /// Gets or sets KittingItem1 
        /// </summary>
        [IgnoreExportImport]
        public Validate IsItemaBomComponent1 { get; set; }

        /// <summary>
        /// Gets or sets StatusString 
        /// </summary>
        [IgnoreExportImport]
        public string StatusString { get { return EnumUtility.GetStringValue(Status1); } }
        /// <summary>
        /// Gets or sets StockItemString 
        /// </summary>
        [IgnoreExportImport]
        public string StockItemString { get { return EnumUtility.GetStringValue(StockItem1); } }
        /// <summary>
        /// Gets or sets SellableString 
        /// </summary>
        [IgnoreExportImport]
        public string SellableString { get { return EnumUtility.GetStringValue(Sellable1); } }
        /// <summary>
        /// Gets or sets AllowItemInWebStoreString 
        /// </summary>
        [IgnoreExportImport]
        public string AllowItemInWebStoreString { get { return EnumUtility.GetStringValue(AllowItemInWebStore1); } }

        /// <summary>
        /// Gets or sets KittingItemString 
        /// </summary>
        [IgnoreExportImport]
        public string KittingItemString { get { return EnumUtility.GetStringValue(KittingItem1); } }
        /// <summary>
        /// Gets or sets IsItemaBomComponentString 
        /// </summary>
        [IgnoreExportImport]
        public string IsItemaBomComponentString { get { return EnumUtility.GetStringValue(IsItemaBomComponent1); } }

        /// <summary>
        /// A string value set while Costing Method is selected
        /// </summary>
        [IgnoreExportImport]
        public string CostingMethodName
        {
            get { return EnumUtility.GetStringValue(CostingMethod); }
        }
        /// <summary>
        /// A string value set while Costing Method is selected
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandName
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets or sets SellableString 
        /// </summary>
        [IgnoreExportImport]
        public string SerialNumbersString { get { return EnumUtility.GetStringValue(SerialNumbers); } }

        /// <summary>
        /// Gets or sets SellableString 
        /// </summary>
        [IgnoreExportImport]
        public string LotNumbersString { get { return EnumUtility.GetStringValue(LotNumbers); } }

        /// <summary>
        /// Gets or sets QtyonHand
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.QtyonHand, Id = Index.QtyonHand, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyonHand { get; set; }

        /// <summary>
        /// Gets or sets QtyonPurchaseOrder
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.QtyonPurchaseOrder, Id = Index.QtyonPurchaseOrder, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyonPurchaseOrder { get; set; }

        /// <summary>
        /// Gets or sets QtyonSalesOrder
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.QtyonSalesOrder, Id = Index.QtyonSalesOrder, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyonSalesOrder { get; set; }

        /// <summary>
        /// Gets or sets QtyAvailable
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.QtyAvailable, Id = Index.QtyAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyAvailable { get; set; }

        /// <summary>
        /// Gets or sets QtyCommitted
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.QtyCommitted, Id = Index.QtyCommitted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QtyCommitted { get; set; }

        /// <summary>
        /// Gets or sets PreferredVendor
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PreferredVendor, Id = Index.PreferredVendor, FieldType = EntityFieldType.Char, Size = 75)]
        public string PreferredVendor { get; set; }

        /// <summary>
        /// Gets or sets PreferredVendorItem
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PreferredVendorItem, Id = Index.PreferredVendorItem, FieldType = EntityFieldType.Char, Size = 24)]
        public string PreferredVendorItem { get; set; }
    }
}
