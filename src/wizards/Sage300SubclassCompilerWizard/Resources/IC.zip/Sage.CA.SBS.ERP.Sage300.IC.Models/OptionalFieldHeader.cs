/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Class for Optional Field Header Model.
    /// </summary>
    public partial class OptionalFieldHeader : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="OptionalFieldHeader" /> class.
        /// </summary>
        public OptionalFieldHeader()
        {
            OptionalFieldDetail = new EnumerableResponse<OptionalFieldDetail>();
        }

        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets NumberofValues 
        /// </summary>
        [Display(Name = "NumberofValues", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberOfValues, Id = Index.NumberOfValues, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfValues { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets OptFields
        /// </summary>
        /// <value>The optional fields.</value>
        public EnumerableResponse<OptionalFieldDetail> OptionalFieldDetail { get; set; }
    }
}
