﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// ItemWizard Class
    /// </summary>
    public class ItemWizard : ModelBase
    {
        /// <summary>
        /// Gets or sets a value indicating whether [user is admin].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [user is admin]; otherwise, <c>false</c>.
        /// </value>
        public bool UserIsAdmin { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update item].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [user can update item]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateItem { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update item location].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update item location]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateItemLocation { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update item pricing].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update item pricing]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateItemPricing { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update price list codes].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update price list codes]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdatePriceListCodes { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update contract pricing].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update contract pricing]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateContractPricing { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update manufacturers item].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update manufacturers item]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateManufacturersItem { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update customer item].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update customer item]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateCustomerItem { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update billsof material].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update billsof material]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateBillsofMaterial { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can inquire billsof material].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can inquire billsof material]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanInquireBillsofMaterial { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update kitting items].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update kitting items]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateKittingItems { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can inquire kitting items].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can inquire kitting items]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanInquireKittingItems { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can update reorder quantities].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can update reorder quantities]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanUpdateReorderQuantities { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user can inquire reorder quantities].
        /// </summary>
        /// <value>
        /// <c>true</c> if [user can inquire reorder quantities]; otherwise, <c>false</c>.
        /// </value>
        public bool UserCanInquireReorderQuantities { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [enterprise edition].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [enterprise edition]; otherwise, <c>false</c>.
        /// </value>
        public bool EnterpriseEdition { get; set; }


        /// <summary>
        /// Gets or sets a value indicating whether [oe active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [oe active]; otherwise, <c>false</c>.
        /// </value>
        public bool OEActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [ap active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [ap active]; otherwise, <c>false</c>.
        /// </value>
        public bool APActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [ar active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [ar active]; otherwise, <c>false</c>.
        /// </value>
        public bool ARActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [tx active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [tx active]; otherwise, <c>false</c>.
        /// </value>
        public bool TXActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ItemWizard"/> is poactive.
        /// </summary>
        /// <value>
        ///   <c>true</c> if poactive; otherwise, <c>false</c>.
        /// </value>
        public bool POActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance has SNLT license.
        /// </summary>
        /// <value>
        /// SNLT license <c>true</c> if [x license]; otherwise, <c>false</c>.
        /// </value>
        public bool XLicense { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [oe version56 a active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [oe version56 a active]; otherwise, <c>false</c>.
        /// </value>
        public bool OEVersion56AActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [po version56 a active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [po version56 a active]; otherwise, <c>false</c>.
        /// </value>
        public bool POVersion56AActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [optional field license].
        /// </summary>
        /// <value>
        /// <c>true</c> if [optional field license]; otherwise, <c>false</c>.
        /// </value>
        public bool OptionalFieldLicense { get; set; }

        /// <summary>
        /// Gets or sets Home currency
        /// </summary>
        /// <value>The home currency decimals.</value>
        public string HomeCurrencyDecimals { get; set; }
    }
}
