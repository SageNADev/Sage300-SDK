﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region NameSpaces

using Sage.CA.SBS.ERP.Sage300.IC.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.Common.Models
{
    public class ItemType
    {
        /// <summary>
        /// Gets or sets IsItemNumber.
        /// </summary>
        public bool IsItemNumber { get; set; }

        /// <summary>
        /// Gets or sets IsManufacturerNumber
        /// </summary>
        public bool IsManufacturerNumber { get; set; }

        /// <summary>
        ///  Gets or sets Item
        /// </summary>
        public Item Item { get; set; }

        /// <summary>
        /// Gets or sets NoOfManufacturerItemsMoreThan1
        /// </summary>
        public bool NoOfManufacturerItemsMoreThan1 { get; set; }

        /// <summary>
        /// Gets or sets the manufacturing item number
        /// </summary>
        public string ManufacturerItemNumber { get; set; }
         
        /// <summary>
        /// UserMessage
        /// </summary>
        public UserMessage UserMessage { get; set; }


    }
}
