// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;


#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ContractCode
    /// </summary>
    public partial class ContractCode : ModelBase
    {
        /// <summary>
        /// CustomerInquiryViewModel
        /// </summary>
        public ContractCode()
        {
            ContractCodes = new EnumerableResponse<ContractCodes>();
        }

        #region Public Properties

        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ContractNo, Id = Index.ContractNo, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ContractNo { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Days1
        /// </summary>
        [Display(Name = "Days1", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Days1, Id = Index.Days1, FieldType = EntityFieldType.Long, Size = 4)]
        public long Days1 { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDays1
        /// </summary>
        [Display(Name = "EffectiveDays1", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.EffectiveDays1, Id = Index.EffectiveDays1, FieldType = EntityFieldType.Long, Size = 4)]
        public long EffectiveDays1 { get; set; }

        /// <summary>
        /// Gets or sets LifetimeContract1
        /// </summary>
        [Display(Name = "LifetimeContract1", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.LifetimeContract1, Id = Index.LifetimeContract1, FieldType = EntityFieldType.Bool, Size = 2)]
        public LifetimeContract1 LifetimeContract1 { get; set; }

        /// <summary>
        /// Gets or sets Description1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description1", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Description1, Id = Index.Description1, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description1 { get; set; }

        /// <summary>
        /// Gets or sets Days2
        /// </summary>
        [Display(Name = "Days2", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Days2, Id = Index.Days2, FieldType = EntityFieldType.Long, Size = 4)]
        public long Days2 { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDays2
        /// </summary>
        [Display(Name = "EffectiveDays2", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.EffectiveDays2, Id = Index.EffectiveDays2, FieldType = EntityFieldType.Long, Size = 4)]
        public long EffectiveDays2 { get; set; }

        /// <summary>
        /// Gets or sets LifetimeContract2
        /// </summary>
        [Display(Name = "LifetimeContract2", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.LifetimeContract2, Id = Index.LifetimeContract2, FieldType = EntityFieldType.Bool, Size = 2)]
        public LifetimeContract1 LifetimeContract2 { get; set; }

        /// <summary>
        /// Gets or sets Description2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description2", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Description2, Id = Index.Description2, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description2 { get; set; }

        /// <summary>
        /// Gets or sets Days3
        /// </summary>
        [Display(Name = "Days3", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Days3, Id = Index.Days3, FieldType = EntityFieldType.Long, Size = 4)]
        public long Days3 { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDays3
        /// </summary>
        [Display(Name = "EffectiveDays3", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.EffectiveDays3, Id = Index.EffectiveDays3, FieldType = EntityFieldType.Long, Size = 4)]
        public long EffectiveDays3 { get; set; }

        /// <summary>
        /// Gets or sets LifetimeContract3
        /// </summary>
        [Display(Name = "LifetimeContract3", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.LifetimeContract3, Id = Index.LifetimeContract3, FieldType = EntityFieldType.Bool, Size = 2)]
        public LifetimeContract1 LifetimeContract3 { get; set; }

        /// <summary>
        /// Gets or sets Description3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description3", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Description3, Id = Index.Description3, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description3 { get; set; }

        /// <summary>
        /// Gets or sets Days4
        /// </summary>
        [Display(Name = "Days4", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Days4, Id = Index.Days4, FieldType = EntityFieldType.Long, Size = 4)]
        public long Days4 { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDays4
        /// </summary>
        [Display(Name = "EffectiveDays4", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.EffectiveDays4, Id = Index.EffectiveDays4, FieldType = EntityFieldType.Long, Size = 4)]
        public long EffectiveDays4 { get; set; }

        /// <summary>
        /// Gets or sets LifetimeContract4
        /// </summary>
        [Display(Name = "LifetimeContract4", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.LifetimeContract4, Id = Index.LifetimeContract4, FieldType = EntityFieldType.Bool, Size = 2)]
        public LifetimeContract1 LifetimeContract4 { get; set; }

        /// <summary>
        /// Gets or sets Description4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description4", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Description4, Id = Index.Description4, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description4 { get; set; }

        /// <summary>
        /// Gets or sets Days5
        /// </summary>
        [Display(Name = "Days5", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Days5, Id = Index.Days5, FieldType = EntityFieldType.Long, Size = 4)]
        public long Days5 { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDays5
        /// </summary>
        [Display(Name = "EffectiveDays5", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.EffectiveDays5, Id = Index.EffectiveDays5, FieldType = EntityFieldType.Long, Size = 4)]
        public long EffectiveDays5 { get; set; }

        /// <summary>
        /// Gets or sets LifetimeContract5
        /// </summary>
        [Display(Name = "LifetimeContract5", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.LifetimeContract5, Id = Index.LifetimeContract5, FieldType = EntityFieldType.Bool, Size = 2)]
        public LifetimeContract1 LifetimeContract5 { get; set; }

        /// <summary>
        /// Gets or sets Description5
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description5", ResourceType = typeof(ContractCodesResx))]
        [ViewField(Name = Fields.Description5, Id = Index.Description5, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description5 { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets LifetimeContract1 string value
        /// </summary>
        public string LifetimeContract1String
        {
            get { return EnumUtility.GetStringValue(LifetimeContract1); }
        }

        /// <summary>
        /// Gets LifetimeContract2 string value
        /// </summary>
        public string LifetimeContract2String
        {
            get { return EnumUtility.GetStringValue(LifetimeContract2); }
        }

        /// <summary>
        /// Gets LifetimeContract3 string value
        /// </summary>
        public string LifetimeContract3String
        {
            get { return EnumUtility.GetStringValue(LifetimeContract3); }
        }

        /// <summary>
        /// Gets LifetimeContract4 string value
        /// </summary>
        public string LifetimeContract4String
        {
            get { return EnumUtility.GetStringValue(LifetimeContract4); }
        }

        /// <summary>
        /// Gets LifetimeContract5 string value
        /// </summary>
        public string LifetimeContract5String
        {
            get { return EnumUtility.GetStringValue(LifetimeContract5); }
        }

        /// <summary>
        /// Gets or sets LifetimeContract1
        /// </summary>
        [Display(Name = "LifeTime", ResourceType = typeof(ICCommonResx))]
        public LifetimeContract1 LifetimeContract { get; set; }

        /// <summary>
        /// Gets or sets Days
        /// </summary>
        [Display(Name = "ContractDays", ResourceType = typeof(ContractCodesResx))]
        public long Days { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDays
        /// </summary>
        [Display(Name = "EffectiveDays", ResourceType = typeof(ContractCodesResx))]
        public long EffectiveDays { get; set; }

        #endregion

        /// <summary>
        /// Get or Set ContractCodeData List
        /// </summary>
        public EnumerableResponse<ContractCodes> ContractCodes { get; set; }

        #endregion
    }
}
