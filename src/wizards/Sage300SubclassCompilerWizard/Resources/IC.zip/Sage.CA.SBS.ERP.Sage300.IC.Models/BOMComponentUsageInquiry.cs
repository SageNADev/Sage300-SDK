﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region NameSpaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Process;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Classes for BOM Component Usage Inquiry
    /// </summary>
    public class BOMComponentUsageInquiry : ModelBase
    {
        /// <summary>
        /// Gets or sets the property of ComponetsItemNumber
        /// </summary>
        [Display(Name = "ComponetsItemNumber", ResourceType = typeof(BillsOfMaterialResx))]
        public string ComponentItemNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of UnFormattedComponentItemNumber
        /// </summary>
        [Display(Name = "ComponetsItemNumber", ResourceType = typeof(BillsOfMaterialResx))]
        public string UnFormattedComponentItemNumber { get; set; }

        /// <summary>
        /// Gets or sets the property of ComponentItemDescription
        /// </summary>
        public string ComponentItemDescription { get; set; }


        /// <summary>
        /// Gets or sets an EnumerableResponse of objects of type <see cref="BillsOfMaterialInquiry" />
        /// </summary>
        public EnumerableResponse<BillsOfMaterialInquiry> BillsOfMaterialInquirys { get; set; }

    }
}