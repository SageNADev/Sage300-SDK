// Copyright (c) 1994-2026 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for SplitCombineHeader
    /// </summary>
    public partial class SplitCombineHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LotNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets EntryType
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(LotSplitsCombinesResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public LotSplitCombineType EntryType { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets QuantityShippable
        /// </summary>
        [Display(Name = "QuantityShippable", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityShippable, Id = Index.QuantityShippable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityShippable { get; set; }

        /// <summary>
        /// Gets or sets SplitCombineQuantity
        /// </summary>
        [ViewField(Name = Fields.SplitCombineQuantity, Id = Index.SplitCombineQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SplitCombineQuantity { get; set; }

        /// <summary>
        /// Gets or sets TotalOfDetailQuantities
        /// </summary>
        [ViewField(Name = Fields.TotalOfDetailQuantities, Id = Index.TotalOfDetailQuantities, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalOfDetailQuantities { get; set; }

        /// <summary>
        /// Gets or sets NextDetailLineNumber
        /// </summary>
        [ViewField(Name = Fields.NextDetailLineNumber, Id = Index.NextDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpiryDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets StockDate
        /// </summary>
        [Display(Name = "StockDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StockDate, Id = Index.StockDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StockDate { get; set; }

        /// <summary>
        /// Gets or sets DetailCount
        /// </summary>
        [ViewField(Name = Fields.DetailCount, Id = Index.DetailCount, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailCount { get; set; }

        /// <summary>
        /// Gets or sets QuantityRemaining
        /// </summary>
        [Display(Name = "Remaining", ResourceType = typeof(LotSplitsCombinesResx))]
        [ViewField(Name = Fields.QuantityRemaining, Id = Index.QuantityRemaining, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityRemaining { get; set; }

        /// <summary>
        /// Gets or sets Detail list of SplitCombineDetail
        /// </summary>
        public EnumerableResponse<SplitCombineDetail> SplitCombineDetail { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets EntryType string value
        /// </summary>
        public string EntryTypeString
        {
            get { return EnumUtility.GetStringValue(EntryType); }
        }

        #endregion
    }
}
