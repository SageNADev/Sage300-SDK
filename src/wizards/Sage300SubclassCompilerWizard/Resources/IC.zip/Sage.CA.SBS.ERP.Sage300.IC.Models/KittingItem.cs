/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using System.Linq;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for KittingItem
    /// </summary>
    public partial class KittingItem : ModelBase
    {
        #region Properties
        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets KittingNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "KittingNumber", ResourceType = typeof(KittingItemsResx))]
        [ViewField(Name = Fields.KittingNumber, Id = Index.KittingNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string KittingNumber { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets UseAsDefault
        /// </summary>
        [Display(Name = "UseAsDefault", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UseAsDefault, Id = Index.UseAsDefault, FieldType = EntityFieldType.Bool, Size = 2)]
        public UseAsDefault UseAsDefault { get; set; }

        /// <summary>
        /// Gets or sets BuildQuantity
        /// </summary>
        [Display(Name = "BuildQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.BuildQuantity, Id = Index.BuildQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal BuildQuantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets CheckItemExistence
        /// </summary>
        [Display(Name = "CheckItemExistence", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
        public CheckItemExistence CheckItemExistence { get; set; }

        /// <summary>
        /// Gets or Sets Serial Number
        /// </summary>
        /// <value>The serial number</value>
        public long SerialNumber { get; set; }


        /// <summary>
        /// Gets or sets UseAsDefaultName
        /// To display value in Finder
        /// </summary>
        public string UseAsDefaultName
        {
            get { return EnumUtility.GetStringValue(UseAsDefault); }
        }

        /// <summary>
        /// Gets or sets CheckItemExistence
        /// To display value in Finder
        /// </summary>
        public string CheckItemExistenceName
        {
            get { return EnumUtility.GetStringValue(CheckItemExistence); }
        }

        /// <summary>
        /// Gets or sets KittingItemComponent
        /// </summary>
        public EnumerableResponse<KittingItemComponent> KittingItemComponent { get; set; }

        /// <summary>
        /// Gets list of Stocking Unit Of Measures
        /// </summary>
        /// <value>Validate.</value>
        public IEnumerable<CustomSelectList> UseAsDefaultList
        {
            get { return EnumUtility.GetItemsList<UseAsDefault>(); }
        }

        /// <summary>
        /// Gets the components.
        /// </summary>
        /// <value>
        /// The components.
        /// </value>
        public YesNoValue Components
        {
            get
            {
                return KittingItemComponent != null && KittingItemComponent.Items.Any()
                    ? YesNoValue.Yes
                    : YesNoValue.No;
            }
        }

        /// <summary>
        /// Gets the components string.
        /// </summary>
        /// <value>
        /// The components string.
        /// </value>
        public string ComponentsString
        {
            get { return EnumUtility.GetStringValue(Components); }
        }


        #endregion
    }
}
