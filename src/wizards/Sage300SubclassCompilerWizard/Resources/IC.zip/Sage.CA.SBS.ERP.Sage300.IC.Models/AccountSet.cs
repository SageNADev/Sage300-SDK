/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;
using System;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A model class for AccountSet screen in Inventory Control
    /// </summary>
    public partial class AccountSet : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountSetCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(AccountSetsResx))]
        [Key]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets CostingMethod 
        /// </summary>
        [Display(Name = "CostingMethod", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.CostingMethod, Id = Index.CostingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public CostingMethod CostingMethod { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InventoryControlAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.InventoryControlAccount, Id = Index.InventoryControlAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InventoryControlAccount { get; set; }

        /// <summary>
        /// Gets or sets PayablesClearingAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayablesClearingAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.PayablesClearingAccount, Id = Index.PayablesClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PayablesClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentOrWriteOffAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdjustmentOrWriteOffAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.AdjustmentOrWriteOffAccount, Id = Index.AdjustmentOrWriteOffAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AdjustmentOrWriteOffAccount { get; set; }

        /// <summary>
        /// Gets or sets AssemblyCostCreditAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AssemblyCostCreditAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.AssemblyCostCreditAccount, Id = Index.AssemblyCostCreditAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AssemblyCostCreditAccount { get; set; }

        /// <summary>
        /// Gets or sets NonstockClearingAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NonstockClearingAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.NonstockClearingAccount, Id = Index.NonstockClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string NonstockClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Status { get; set; }

        /// <summary>
        /// Finder Grid property Set.
        /// </summary>
        public string StatusDescription { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets DateInactive 
        /// </summary>
        [Display(Name = "DateInactive", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateInactive { get; set; }

        /// <summary>
        /// Gets or sets TransferClearingAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransferClearingAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.TransferClearingAccount, Id = Index.TransferClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TransferClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets ShipmentClearingAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentClearingAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.ShipmentClearingAccount, Id = Index.ShipmentClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ShipmentClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets DisassemblyExpenseAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DisassemblyExpenseAccount", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.DisassemblyExpenseAccount, Id = Index.DisassemblyExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DisassemblyExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets PhysicalInventoryAdjAcct 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PhysicalInventoryAdjAcct", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.PhysicalInventoryAdjAcct, Id = Index.PhysicalInventoryAdjAcct, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PhysicalInventoryAdjAcct { get; set; }

        /// <summary>
        /// Gets or sets CreditOrDebitNoteClearingAcct 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditOrDebitNoteClearingAcct", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.CreditOrDebitNoteClearingAcct, Id = Index.CreditOrDebitNoteClearingAcct, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CreditOrDebitNoteClearingAcct { get; set; }

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        /// <summary>
        /// A string value set while Costing Method is selected
        /// </summary>
        public string CostingMethodName
        {
            get { return EnumUtility.GetStringValue(CostingMethod); }
        }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get
            {
                return EnumUtility.GetStringValue(ActiveStatus);
            }
        }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(AccountSetsResx))]
        public AccountSetsStatus ActiveStatus { get; set; }
    }
}
