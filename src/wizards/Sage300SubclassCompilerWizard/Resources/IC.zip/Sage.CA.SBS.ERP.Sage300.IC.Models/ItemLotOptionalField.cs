// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Usings

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class ItemLotOptionalField : ModelBase
    {

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value 
        /// </summary>
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>

        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public IC.Models.Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>

        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>

        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>

        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate 
        /// </summary>

        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet 
        /// </summary>

        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex 
        /// </summary>

        [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue 
        /// </summary>
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue 
        /// </summary>

        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue 
        /// </summary>

        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue 
        /// </summary>

        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesOrNoValue 
        /// </summary>

        [ViewField(Name = Fields.YesOrNoValue, Id = Index.YesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem YesOrNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue 
        /// </summary>
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue 
        /// </summary>

        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription 
        /// </summary>
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets ValueDescription 
        /// </summary>
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }
    }
}
