// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for UpdateBillsOfMaterial
	/// </summary>
	public partial class UpdateBillsOfMaterial : ModelBase
	{
		/// <summary>
		/// Gets or sets FromMasterItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.FromMasterItemNumber, Id = Index.FromMasterItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string FromMasterItemNumber { get; set; }

		/// <summary>
		/// Gets or sets ToMasterItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ToMasterItemNumber, Id = Index.ToMasterItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ToMasterItemNumber { get; set; }

		/// <summary>
		/// Gets or sets FromBOMNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.FromBOMNumber, Id = Index.FromBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string FromBOMNumber { get; set; }

		/// <summary>
		/// Gets or sets ToBOMNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ToBOMNumber, Id = Index.ToBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ToBOMNumber { get; set; }

		/// <summary>
		/// Gets or sets Update
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Update, Id = Index.Update, FieldType = EntityFieldType.Int, Size = 2)]
		public Update Update { get; set; }

		/// <summary>
		/// Gets or sets ComponentType
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ComponentType, Id = Index.ComponentType, FieldType = EntityFieldType.Int, Size = 2)]
		public ComponentType ComponentType { get; set; }

		/// <summary>
		/// Gets or sets CostType
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CostType, Id = Index.CostType, FieldType = EntityFieldType.Int, Size = 2)]
		public CostType CostType { get; set; }

		/// <summary>
		/// Gets or sets ComponentItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ComponentItemNumber, Id = Index.ComponentItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ComponentItemNumber { get; set; }

		/// <summary>
		/// Gets or sets ComponentBOMNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ComponentBOMNumber, Id = Index.ComponentBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ComponentBOMNumber { get; set; }

		/// <summary>
		/// Gets or sets ReplacementItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReplacementItemNumber, Id = Index.ReplacementItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ReplacementItemNumber { get; set; }

		/// <summary>
		/// Gets or sets ReplacementBOMNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReplacementBOMNumber, Id = Index.ReplacementBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string ReplacementBOMNumber { get; set; }

		/// <summary>
		/// Gets or sets UnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
		public string UnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets Quantity
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal Quantity { get; set; }

		/// <summary>
		/// Gets or sets UnitCost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UnitCost { get; set; }

		/// <summary>
		/// Gets or sets Using
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Using, Id = Index.Using, FieldType = EntityFieldType.Int, Size = 2)]
		public Using Using { get; set; }

		/// <summary>
		/// Gets or sets Base
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Base, Id = Index.Base, FieldType = EntityFieldType.Int, Size = 2)]
		public Base Base { get; set; }

		/// <summary>
		/// Gets or sets Amount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal Amount { get; set; }

		/// <summary>
		/// Gets or sets Percentage
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Percentage, Id = Index.Percentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal Percentage { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Update string value
		/// </summary>
		public string UpdateString
		{
			get { return EnumUtility.GetStringValue(Update); }
		}

		/// <summary>
		/// Gets ComponentType string value
		/// </summary>
		public string ComponentTypeString
		{
			get { return EnumUtility.GetStringValue(ComponentType); }
		}

		/// <summary>
		/// Gets CostType string value
		/// </summary>
		public string CostTypeString
		{
			get { return EnumUtility.GetStringValue(CostType); }
		}

		/// <summary>
		/// Gets Using string value
		/// </summary>
		public string UsingString
		{
			get { return EnumUtility.GetStringValue(Using); }
		}

		/// <summary>
		/// Gets Base string value
		/// </summary>
		public string BaseString
		{
			get { return EnumUtility.GetStringValue(Base); }
		}

		#endregion
	}
}
