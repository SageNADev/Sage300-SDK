// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

// ReSharper disable once CheckNamespace

// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for CopyBillsOfMaterial
    /// </summary>
    public partial class CopyBillsOfMaterial : ModelBase
    {
        public CopyBillsOfMaterial()
        {
            BillsOfMaterial = new BillsOfMaterial();
            BillsOfMaterialComponent = new EnumerableResponse<BillsOfMaterialComponent>();
        }

        /// <summary>
        /// Gets or sets FromMasterItem
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromMITEM", ResourceType = typeof(CopyBillsOfMaterialResx))]
        [ViewField(Name = Fields.FromMasterItem, Id = Index.FromMasterItem, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FromMasterItem { get; set; }

        /// <summary>
        /// Gets or sets FromBOMNO
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromBOM", ResourceType = typeof(CopyBillsOfMaterialResx))]
        public string FromBomNo { get; set; }

        /// <summary>
        /// Gets or sets ToMasterItem
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToMITEM", ResourceType = typeof(CopyBillsOfMaterialResx))]
        [ViewField(Name = Fields.ToMasterItem, Id = Index.ToMasterItem, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ToMasterItem { get; set; }

        /// <summary>
        /// Gets or sets ToBOMNO
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToBOM", ResourceType = typeof(CopyBillsOfMaterialResx))]
        public string ToBomNo { get; set; }

        /// <summary>
        /// Gets or sets ActionPerformed
        /// </summary>
        [ViewField(Name = Fields.ActionPerformed, Id = Index.ActionPerformed, FieldType = EntityFieldType.Int, Size = 2)]
        public int ActionPerformed { get; set; }

        public BillsOfMaterial BillsOfMaterial { get; set; }

        public EnumerableResponse<BillsOfMaterialComponent> BillsOfMaterialComponent { get; set; }

        #region UI Strings

        /// <summary>
        /// 
        /// </summary>
        public string FrmMasterItemDesc { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string ToMasterItemDesc { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FormattedFromManufItem { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FormattedToManufItem { get; set; }
        
        #endregion
    }
}
