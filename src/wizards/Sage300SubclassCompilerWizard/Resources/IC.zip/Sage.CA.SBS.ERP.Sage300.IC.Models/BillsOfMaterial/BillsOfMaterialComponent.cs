// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for BillsOfMaterialComponent
    /// </summary>
    public partial class BillsOfMaterialComponent : ModelBase
    {
        /// <summary>
        /// Gets or sets MasterItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MasterItemNo", ResourceType = typeof(BillsOfMaterialResx))]
        [ViewField(Name = Fields.MasterItemNumber, Id = Index.MasterItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string MasterItemNumber { get; set; }

        /// <summary>
        /// Gets or sets BOMNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BOMNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.BOMNumber, Id = Index.BOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BOMNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ComponentItemNumber, Id = Index.ComponentItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ComponentItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets ComponentBOMNumber
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ComponentBOMNO", ResourceType = typeof(CopyBillsOfMaterialResx))]
        [ViewField(Name = Fields.ComponentBOMNumber, Id = Index.ComponentBOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ComponentBOMNumber { get; set; }

        /// <summary>
        /// Gets or sets CopyDetail
        /// </summary>
        [Display(Name = "CopyDetail", ResourceType = typeof(CopyBillsOfMaterialResx))]
        [ViewField(Name = Fields.CopyDetail, Id = Index.CopyDetail, FieldType = EntityFieldType.Bool, Size = 2)]
        public CopyDetail CopyDetail { get; set; }

        /// <summary>
        /// Gets or sets UserSpecifiedCost
        /// </summary>
        [Display(Name = "UserSpecified", ResourceType = typeof(EnumerationsResx))]
        [ViewField(Name = Fields.UserSpecifiedCost, Id = Index.UserSpecifiedCost, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UserSpecifiedCost { get; set; }

        /// <summary>
        /// Gets or sets FormattedComponentItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ComponentItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FormattedComponentItemNumber, Id = Index.FormattedComponentItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string FormattedComponentItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ComponentItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ComponentItemDescription, Id = Index.ComponentItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ComponentItemDescription { get; set; }

        /// <summary>
        /// Gets or sets FormattedMasterItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MasterItemNo", ResourceType = typeof(BillsOfMaterialResx))]
        [ViewField(Name = Fields.FormattedMasterItemNumber, Id = Index.FormattedMasterItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string FormattedMasterItemNumber { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets CopyDetail string value
        /// </summary>
        [Display(Name = "CopyDetail", ResourceType = typeof(CopyBillsOfMaterialResx))]
        public string CopyDetailString
        {
            get { return EnumUtility.GetStringValue(CopyDetail); }
        }

        /// <summary>
        /// Gets the Status options
        /// </summary>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> CopyDetailList
        {
            get
            {
                return EnumUtility.GetItemsList<CopyDetail>().ToList();
            }
        }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        /// 
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        /// <summary>
        ///     Set Costing method Type
        /// </summary>
        [IgnoreExportImport]
        public int CostingMethod { get; set; }

        #endregion
    }
}
