// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for BillsOfMaterial
    /// </summary>
    public partial class BillsOfMaterial : ModelBase
    {
        public BillsOfMaterial()
        {
            BOMDetails = new EnumerableResponse<BillsOfMaterialComponent>();
        }
        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets BOMNO
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BOMNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.BOMNO, Id = Index.BOMNO, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BOMNO { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets FixedCost
        /// </summary>
        [Display(Name = "FixedCost", ResourceType = typeof(BillsOfMaterialResx))]
        [ViewField(Name = Fields.FixedCost, Id = Index.FixedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FixedCost { get; set; }

        /// <summary>
        /// Gets or sets BuildQuantity
        /// </summary>
        [Display(Name = "BuildQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.BuildQuantity, Id = Index.BuildQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal BuildQuantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets VariableCost
        /// </summary>
        [Display(Name = "VariableCost", ResourceType = typeof(BillsOfMaterialResx))]
        [ViewField(Name = Fields.VariableCost, Id = Index.VariableCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal VariableCost { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets StartDate
        /// </summary>
        [ValidateDateFormatAllowNullAttribute(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// Gets or sets EndDate
        /// </summary>
        [ValidateDateFormatAllowNullAttribute(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EndDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.EndDate, Id = Index.EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Inactive", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.Status Status { get; set; }

        /// <summary>
        /// Gets or sets DateInactive
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateInactive", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateInactive { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets BOMNO2
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillsOfMaterial", ResourceType = typeof(BillsOfMaterialResx))]
        [ViewField(Name = Fields.BOMNO2, Id = Index.BOMNO2, FieldType = EntityFieldType.Char, Size = 6)]
        public string BOMNO2 { get; set; }

        /// <summary>
        /// Gets or sets CheckItemExistence
        /// </summary>
        [ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
        public CheckItemExistence CheckItemExistence { get; set; }

        /// <summary>
        /// Gets or sets LoopCheck
        /// </summary>
        [ViewField(Name = Fields.LoopCheck, Id = Index.LoopCheck, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LoopCheck { get; set; }

        /// <summary>
        /// Gets or sets UseAsDefault
        /// </summary>
        [Display(Name = "UseAsDefault", ResourceType = typeof(BillsOfMaterialResx))]
        [ViewField(Name = Fields.UseAsDefault, Id = Index.UseAsDefault, FieldType = EntityFieldType.Bool, Size = 2)]
        public UseAsDefault UseAsDefault { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets CheckItemExistence string value
        /// </summary>
        public string CheckItemExistenceString
        {
            get { return EnumUtility.GetStringValue(CheckItemExistence); }
        }

        /// <summary>
        /// Gets UseAsDefault string value
        /// </summary>
        public string UseAsDefaultString
        {
            get { return EnumUtility.GetStringValue(UseAsDefault); }
        }

        /// <summary>
        /// Gets Inactive bool value
        /// </summary>
        [Display(Name = "Inactive", ResourceType = typeof(ICCommonResx))]
        public bool IsInactive
        {
            get { return Status == Enums.Status.Inactive; }
        }

        /// <summary>
        /// Gets Inactive date as string
        /// </summary>
        [Display(Name = "Inactive", ResourceType = typeof(ICCommonResx))]
        [IgnoreExportImport]
        public string InactiveString
        {
            get
            {
                return Status == Enums.Status.Inactive ? DateUtil.GetShortDate(DateInactive, string.Empty) : string.Empty;
            }
        }

        /// <summary>
        /// Gets UseAsDefault bool value
        /// </summary>
        public bool IsUseDefault
        {
            get { return UseAsDefault == UseAsDefault.Yes; }
        }

        /// <summary>
        /// Gets or sets Home currency 
        /// </summary>
        [IgnoreExportImport]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// BOMDetails
        /// </summary>
        public EnumerableResponse<BillsOfMaterialComponent> BOMDetails { get; set; }

        /// <summary>
        /// Gets LoopCheck String value
        /// </summary>
        [IgnoreExportImport]
        public string LoopCheckString
        {
            get
            {
                return LoopCheck ? EnumUtility.GetStringValue(BooleanType.True) : EnumUtility.GetStringValue(BooleanType.False);
            }
        }

        #endregion
    }
}
