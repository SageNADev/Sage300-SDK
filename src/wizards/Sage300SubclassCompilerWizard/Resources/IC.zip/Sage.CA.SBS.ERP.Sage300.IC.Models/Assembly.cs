// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using FiscalPeriod= Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.FiscalPeriod;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for Assemblie
	/// </summary>
	public partial class Assembly : ModelBase
	{
		/// <summary>
		/// Gets or sets SequenceNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "SequenceNumber", ResourceType = typeof (AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long SequenceNumber {get; set;}

		/// <summary>
		/// Gets or sets TransactionNumber
		/// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal TransactionNumber {get; set;}

		/// <summary>
        /// Gets or sets AssemblyNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AssemblyNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AssemblyNumber, Id = Index.AssemblyNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string AssemblyNumber { get; set; }

		/// <summary>
		/// Gets or sets TransactionDate
		/// </summary>
		//[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "TransactionDate", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime TransactionDate {get; set;}

		/// <summary>
		/// Gets or sets FiscalYear
		/// </summary>
		[StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "FiscalYear", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
		public string FiscalYear {get; set;}

		/// <summary>
		/// Gets or sets FiscalPeriod
		/// </summary>
		[Display(Name = "FiscalPeriod", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
		public FiscalPeriod FiscalPeriod {get; set;}

		/// <summary>
		/// Gets or sets Reference
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
		public string Reference {get; set;}

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Description", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string Description {get; set;}

		/// <summary>
		/// Gets or sets ItemNumber
		/// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ItemNumber", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ItemNumber {get; set;}

		/// <summary>
		/// Gets or sets BOMNumber
		/// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BOMNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.BOMNumber, Id = Index.BOMNumber, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string BOMNumber {get; set;}

		/// <summary>
		/// Gets or sets Location
		/// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Location", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string Location {get; set;}

		/// <summary>
		/// Gets or sets Quantity
		/// </summary>
		[Display(Name = "Quantity", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal Quantity {get; set;}

		/// <summary>
		/// Gets or sets UnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "UnitOfMeasure", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
		public string UnitOfMeasure {get; set;}

		/// <summary>
		/// Gets or sets TransactionType
		/// </summary>
		[Display(Name = "TransactionType", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
		public TransactionType TransactionType {get; set;}

		/// <summary>
		/// Gets or sets ICUniqueDocumentNumber
		/// </summary>
        [Display(Name = "IC_UniqueDocumentNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ICUniqueDocumentNumber, Id = Index.ICUniqueDocumentNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ICUniqueDocumentNumber {get; set;}

		/// <summary>
		/// Gets or sets RecordStatus
		/// </summary>
        [Display(Name = "RecordStatus", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.RecordStatus, Id = Index.RecordStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public RecordStatus RecordStatus {get; set;}

		/// <summary>
		/// Gets or sets RecordDeleted
		/// </summary>
        [Display(Name = "RecordDeleted", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.RecordDeleted, Id = Index.RecordDeleted, FieldType = EntityFieldType.Bool, Size = 2)]
		public RecordDeleted RecordDeleted {get; set;}

		/// <summary>
		/// Gets or sets ManufacturersItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ManufacturersItemNumber", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ManufacturersItemNumber {get; set;}

		/// <summary>
		/// Gets or sets UnitCost
		/// </summary>
		[Display(Name = "UnitCost", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UnitCost {get; set;}

		/// <summary>
		/// Gets or sets FromAssemblyNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromAssembly", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.FromAssemblyNumber, Id = Index.FromAssemblyNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string FromAssemblyNumber {get; set;}

		/// <summary>
		/// Gets or sets FromAssemblyQuantity
		/// </summary>
        [Display(Name = "FromAssemblyQuantity", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.FromAssemblyQuantity, Id = Index.FromAssemblyQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal FromAssemblyQuantity {get; set;}

		/// <summary>
		/// Gets or sets DisassemblyCost
		/// </summary>
        [Display(Name = "DisassemblyCost", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.DisassemblyCost, Id = Index.DisassemblyCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DisassemblyCost {get; set;}

		/// <summary>
		/// Gets or sets RecordPrinted
		/// </summary>
        [Display(Name = "RecordPrinted", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.RecordPrinted, Id = Index.RecordPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
		public RecordPrinted RecordPrinted {get; set;}

		/// <summary>
		/// Gets or sets OptionalFields
		/// </summary>
		[Display(Name = "OptionalFields", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
		public long OptionalFields {get; set;}

		/// <summary>
		/// Gets or sets MasterAssemblyNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MasterAssNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MasterAssemblyNumber, Id = Index.MasterAssemblyNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string MasterAssemblyNumber {get; set;}

		/// <summary>
		/// Gets or sets ComponentAssemblyMethod
		/// </summary>
        [Display(Name = "ComponentAssMethod", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ComponentAssemblyMethod, Id = Index.ComponentAssemblyMethod, FieldType = EntityFieldType.Int, Size = 2)]
		public ComponentAssemblyMethod ComponentAssemblyMethod {get; set;}

		/// <summary>
		/// Gets or sets QuantityUsed
		/// </summary>
        [Display(Name = "QuantityUsed", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.QuantityUsed, Id = Index.QuantityUsed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityUsed {get; set;}

		/// <summary>
		/// Gets or sets QtyNeededStockingUOM
		/// </summary>
        [Display(Name = "QtyNeededStockingUOM", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.QtyNeededStockingUOM, Id = Index.QtyNeededStockingUOM, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QtyNeededStockingUOM {get; set;}

		/// <summary>
		/// Gets or sets MultilevelLevel
		/// </summary>
        [Display(Name = "MultilevelLevel", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MultilevelLevel, Id = Index.MultilevelLevel, FieldType = EntityFieldType.Int, Size = 2)]
		public int MultilevelLevel {get; set;}

		/// <summary>
		/// Gets or sets MultilevelSeqNo
		/// </summary>
        [Display(Name = "MultilevelSeqNo", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MultilevelSeqNo, Id = Index.MultilevelSeqNo, FieldType = EntityFieldType.Long, Size = 4)]
		public long MultilevelSeqNo {get; set;}

		/// <summary>
		/// Gets or sets MultilevelParentSeqNo
		/// </summary>
        [Display(Name = "MultilevelParentSeqNo", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MultilevelParentSeqNo, Id = Index.MultilevelParentSeqNo, FieldType = EntityFieldType.Long, Size = 4)]
		public long MultilevelParentSeqNo {get; set;}

		/// <summary>
		/// Gets or sets MultilevelParentAssemblyNo
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MultilevelParentAssemblyNo", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MultilevelParentAssemblyNo, Id = Index.MultilevelParentAssemblyNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string MultilevelParentAssemblyNo {get; set;}

		/// <summary>
		/// Gets or sets ComponentsMasterItemNo
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CompMasterItemNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ComponentsMasterItemNo, Id = Index.ComponentsMasterItemNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ComponentsMasterItemNo {get; set;}

		/// <summary>
		/// Gets or sets EnteredBy
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string EnteredBy {get; set;}

		/// <summary>
		/// Gets or sets PostingDate
		/// </summary>
		//[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PostingDate", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime PostingDate {get; set;}

		/// <summary>
		/// Gets or sets SerialItemsInAssembly
		/// </summary>
        [Display(Name = "SerialItemsInAssembly", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialItemsInAssembly, Id = Index.SerialItemsInAssembly, FieldType = EntityFieldType.Long, Size = 4)]
		public long SerialItemsInAssembly {get; set;}

		/// <summary>
		/// Gets or sets LotItemsInAssembly
		/// </summary>
        [Display(Name = "LotItemsInAssembly", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.LotItemsInAssembly, Id = Index.LotItemsInAssembly, FieldType = EntityFieldType.Long, Size = 4)]
		public long LotItemsInAssembly {get; set;}

		/// <summary>
		/// Gets or sets AssemblyQuantityRemaining
		/// </summary>
        [Display(Name = "AssemblyQuantityRemaining", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.AssemblyQuantityRemaining, Id = Index.AssemblyQuantityRemaining, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal AssemblyQuantityRemaining {get; set;}

		/// <summary>
		/// Gets or sets ConversionFactor
		/// </summary>
		[Display(Name = "ConversionFactor", ResourceType = typeof (ICCommonResx))]
		[ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal ConversionFactor {get; set;}

		/// <summary>
		/// Gets or sets InterprocessCommID
		/// </summary>
        [Display(Name = "InterProcessCommID", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
		public long InterprocessCommID {get; set;}

		/// <summary>
		/// Gets or sets EstimatedCost
		/// </summary>
        [Display(Name = "EstimatedCost", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.EstimatedCost, Id = Index.EstimatedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal EstimatedCost {get; set;}

		/// <summary>
		/// Gets or sets ForcePopupSN
		/// </summary>
        [Display(Name = "ForcePopUpSN", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ForcePopupSN, Id = Index.ForcePopupSN, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool ForcePopupSN {get; set;}

		/// <summary>
		/// Gets or sets PopupSN
		/// </summary>
        [Display(Name = "PopUpSN", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.PopupSN, Id = Index.PopupSN, FieldType = EntityFieldType.Int, Size = 2)]
		public int PopupSN {get; set;}

		/// <summary>
		/// Gets or sets CloseSN
		/// </summary>
        [Display(Name = "CloseSN", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.CloseSN, Id = Index.CloseSN, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool CloseSN {get; set;}

		/// <summary>
		/// Gets or sets LTSetID
		/// </summary>
        [Display(Name = "LTSetID", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.LTSetID, Id = Index.LTSetID, FieldType = EntityFieldType.Long, Size = 4)]
		public long LTSetID {get; set;}

		/// <summary>
		/// Gets or sets ForcePopupLT
		/// </summary>
        [Display(Name = "ForcePopUpLT", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ForcePopupLT, Id = Index.ForcePopupLT, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool ForcePopupLT {get; set;}

		/// <summary>
		/// Gets or sets PopupLT
		/// </summary>
        [Display(Name = "PopUpLT", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.PopupLT, Id = Index.PopupLT, FieldType = EntityFieldType.Int, Size = 2)]
		public int PopupLT {get; set;}

		/// <summary>
		/// Gets or sets CloseLT
		/// </summary>
        [Display(Name = "CloseLT", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.CloseLT, Id = Index.CloseLT, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool CloseLT {get; set;}

		// TODO: The naming convention of this property has to be manually evaluated
		/// <summary>
		/// Gets or sets CDOCNUM
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AssemblyNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CDOCNUM, Id = Index.CDOCNUM, FieldType = EntityFieldType.Char, Size = 22)]
		public string CDOCNUM {get; set;}

		/// <summary>
		/// Gets or sets PostSequenceNumber
		/// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long PostSequenceNumber {get; set;}

		/// <summary>
		/// Gets or sets FromAssemblySeq
		/// </summary>
        [Display(Name = "FromAssemblySeq", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.FromAssemblySeq, Id = Index.FromAssemblySeq, FieldType = EntityFieldType.Long, Size = 4)]
		public long FromAssemblySeq {get; set;}

		/// <summary>
		/// Gets or sets ProcessCommand
		/// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
		public ProcessCommand ProcessCommand {get; set;}

		/// <summary>
		/// Gets or sets FormattedItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedItemNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
		public string FormattedItemNumber {get; set;}

		/// <summary>
		/// Gets or sets FormattedCompMasterItemNo
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedCompMasterItemNo", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.FormattedCompMasterItemNo, Id = Index.FormattedCompMasterItemNo, FieldType = EntityFieldType.Char, Size = 24)]
		public string FormattedCompMasterItemNo {get; set;}

		/// <summary>
		/// Gets or sets ItemDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string ItemDescription {get; set;}

		/// <summary>
		/// Gets or sets GLBatchID
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GL_BatchID", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.GLBatchID, Id = Index.GLBatchID, FieldType = EntityFieldType.Char, Size = 6, Mask = "%06D")]
		public string GLBatchID {get; set;}

		/// <summary>
		/// Gets or sets SerialLotQuantityToProcess
		/// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal SerialLotQuantityToProcess {get; set;}

		/// <summary>
		/// Gets or sets NumberOfLotsToGenerate
		/// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal NumberOfLotsToGenerate {get; set;}

		/// <summary>
		/// Gets or sets QuantityperLot
		/// </summary>
        [Display(Name = "QuantityPerLot", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QuantityperLot {get; set;}

		/// <summary>
		/// Gets or sets CompIDCurrentlyProcessed
		/// </summary>
        [Display(Name = "CompIDCurrentlyProcessed", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.CompIDCurrentlyProcessed, Id = Index.CompIDCurrentlyProcessed, FieldType = EntityFieldType.Long, Size = 4)]
		public long CompIDCurrentlyProcessed {get; set;}

		/// <summary>
		/// Gets or sets ParentSerialLotComponentID
		/// </summary>
        [Display(Name = "ParentSerialLotComponentID", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.ParentSerialLotComponentID, Id = Index.ParentSerialLotComponentID, FieldType = EntityFieldType.Long, Size = 4)]
		public long ParentSerialLotComponentID {get; set;}

		/// <summary>
		/// Gets or sets SerialLotItem
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialLotItem", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialLotItem, Id = Index.SerialLotItem, FieldType = EntityFieldType.Char, Size = 24)]
		public string SerialLotItem {get; set;}

		/// <summary>
		/// Gets or sets SerialLotBOMNumber
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialLotBOMNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialLotBOMNumber, Id = Index.SerialLotBOMNumber, FieldType = EntityFieldType.Char, Size = 6)]
		public string SerialLotBOMNumber {get; set;}

		/// <summary>
		/// Gets or sets SerialLotItemUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialLotItemUOM", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialLotItemUnitOfMeasure, Id = Index.SerialLotItemUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
		public string SerialLotItemUnitOfMeasure {get; set;}

		/// <summary>
		/// Gets or sets SerialMasterItem
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialMasterItem", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialMasterItem, Id = Index.SerialMasterItem, FieldType = EntityFieldType.Char, Size = 24)]
		public string SerialMasterItem {get; set;}

		/// <summary>
		/// Gets or sets SerialQuantityRequired
		/// </summary>
        [Display(Name = "SerialQuantityRequired", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialQuantityRequired, Id = Index.SerialQuantityRequired, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal SerialQuantityRequired {get; set;}

		/// <summary>
		/// Gets or sets LotQuantityRequired
		/// </summary>
        [Display(Name = "LotQuantityRequired", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.LotQuantityRequired, Id = Index.LotQuantityRequired, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal LotQuantityRequired {get; set;}

		/// <summary>
		/// Gets or sets SerialQuantity
		/// </summary>
        [Display(Name = "SerialQuantity", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal SerialQuantity {get; set;}

		/// <summary>
		/// Gets or sets LotQuantity
		/// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal LotQuantity {get; set;}

		/// <summary>
		/// Gets or sets MasterSerialNumber
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MasterSerialNumber", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MasterSerialNumber, Id = Index.MasterSerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string MasterSerialNumber {get; set;}

		/// <summary>
		/// Gets or sets MasterSerialProcessAction
		/// </summary>
        [Display(Name = "MasterSerialProcessAction", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.MasterSerialProcessAction, Id = Index.MasterSerialProcessAction, FieldType = EntityFieldType.Int, Size = 2)]
		public MasterSerialProcessAction MasterSerialProcessAction {get; set;}

		/// <summary>
		/// Gets or sets AllocateFromSerial
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "AllocateFromSerial", ResourceType = typeof (AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
		public string AllocateFromSerial {get; set;}

		/// <summary>
		/// Gets or sets AllocateFromLot
		/// </summary>
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
		public string AllocateFromLot {get; set;}

		/// <summary>
		/// Gets or sets SerialLotWindowHandle
		/// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
		public long SerialLotWindowHandle {get; set;}

		/// <summary>
		/// Gets or sets Disallowsavepost
		/// </summary>
        [Display(Name = "DisallowSavePost", ResourceType = typeof(AssembliesDisassembliesResx))]
		[ViewField(Name = Fields.Disallowsavepost, Id = Index.Disallowsavepost, FieldType = EntityFieldType.Bool, Size = 2)]
		public bool Disallowsavepost {get; set;}

        /// <summary>
        /// Gets or sets List of Additional Cost Details
        /// </summary>
        /// <value>The Additional Cost Details</value>
        [IgnoreExportImport]
        public EnumerableResponse<AssemblySerialDetail> AssemblySerialDetails { get; set; }

        /// <summary>
        /// Gets or sets List of Additional Cost Details
        /// </summary>
        /// <value>The Additional Cost Details</value>
        [IgnoreExportImport]
        public EnumerableResponse<AssemblyLotDetail> AssemblyLotDetails { get; set; }

        /// <summary>
        /// Gets or sets Additional Cost Optional Field
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AssemblyOptionalField> AssemblyOptionalFields { get; set; }

        [IgnoreExportImport]
        [IsMvcSpecific]
        public IDictionary<string, object> Attributes { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets FiscalPeriod string value
		/// </summary>
		public string FiscalPeriodString
		{
			get { return EnumUtility.GetStringValue(FiscalPeriod); }
		}

		/// <summary>
		/// Gets TransactionType string value
		/// </summary>
		public string TransactionTypeString
		{
			get { return EnumUtility.GetStringValue(TransactionType); }
		}

		/// <summary>
		/// Gets RecordStatus string value
		/// </summary>
		public string RecordStatusString
		{
			get { return EnumUtility.GetStringValue(RecordStatus); }
		}

		/// <summary>
		/// Gets RecordDeleted string value
		/// </summary>
		public string RecordDeletedString
		{
			get { return EnumUtility.GetStringValue(RecordDeleted); }
		}

		/// <summary>
		/// Gets RecordPrinted string value
		/// </summary>
		public string RecordPrintedString
		{
			get { return EnumUtility.GetStringValue(RecordPrinted); }
		}

		/// <summary>
		/// Gets ComponentAssemblyMethod string value
		/// </summary>
		public string ComponentAssemblyMethodString
		{
			get { return EnumUtility.GetStringValue(ComponentAssemblyMethod); }
		}

		/// <summary>
		/// Gets ProcessCommand string value
		/// </summary>
		public string ProcessCommandString
		{
			get { return EnumUtility.GetStringValue(ProcessCommand); }
		}

		/// <summary>
		/// Gets MasterSerialProcessAction string value
		/// </summary>
		public string MasterSerialProcessActionString
		{
			get { return EnumUtility.GetStringValue(MasterSerialProcessAction); }
		}

		#endregion
	}
}
