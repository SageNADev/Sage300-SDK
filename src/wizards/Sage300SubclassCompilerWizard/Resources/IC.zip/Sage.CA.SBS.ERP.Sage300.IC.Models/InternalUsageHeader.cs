// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for InternalUsageHeader
    /// </summary>
    public partial class InternalUsageHeader : ModelBase
    {
        /// <summary>
        /// This constructor initializes EnumerableResponses/Lists to be empty.
        /// This avoids the problem of serializing null collections.
        /// </summary>
        public InternalUsageHeader()
        {
            InternalUsageDetail = new EnumerableResponse<InternalUsageDetail>();
            InternalUsageOptionalField = new EnumerableResponse<InternalUsageOptionalField>();
            InternalUsageDetailOptionalField = new EnumerableResponse<InternalUsageDetailOptionalField>();
        }

        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InternalUsageNumber", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.InternalUsageNumber, Id = Index.InternalUsageNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InternalUsageNumber { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets EntryType
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public InternalUsageEntryType EntryType { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InternalUsageDate", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.InternalUsageDate, Id = Index.InternalUsageDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InternalUsageDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public IC.Models.Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets ICUniqueDocumentNumber
        /// </summary>
        [Display(Name = "ICUniqueDocumentNumber", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.ICUniqueDocumentNumber, Id = Index.ICUniqueDocumentNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ICUniqueDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets NextDetailLineNumber
        /// </summary>
        [Display(Name = "NextDetailLineNumber", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.NextDetailLineNumber, Id = Index.NextDetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets RecordStatus
        /// </summary>
        [Display(Name = "RecordStatus", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.RecordStatus, Id = Index.RecordStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public RecordStatus RecordStatus { get; set; }

        /// <summary>
        /// Gets or sets RecordDeleted
        /// </summary>
        [Display(Name = "RecordDeleted", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.RecordDeleted, Id = Index.RecordDeleted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordDeleted RecordDeleted { get; set; }

        /// <summary>
        /// Gets or sets RecordPrinted
        /// </summary>
        [Display(Name = "RecordPrinted", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.RecordPrinted, Id = Index.RecordPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public RecordPrinted RecordPrinted { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets EmployeeNumber
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeNumber", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.EmployeeNumber, Id = Index.EmployeeNumber, FieldType = EntityFieldType.Char, Size = 60)]
        public string EmployeeNumber { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets PostSequenceNumber
        /// </summary>
        [Display(Name = "PostSequenceNumber", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.PostSequenceNumber, Id = Index.PostSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long PostSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets IsCanadianPayrollActive
        /// </summary>
        [Display(Name = "IsCanadianPayrollActive", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.IsCanadianPayrollActive, Id = Index.IsCanadianPayrollActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsCanadianPayrollActive IsCanadianPayrollActive { get; set; }

        /// <summary>
        /// Gets or sets IsUSPayrollActive
        /// </summary>
        [Display(Name = "IsUSPayrollActive", ResourceType = typeof(InternalUsageResx))]
        [ViewField(Name = Fields.IsUSPayrollActive, Id = Index.IsUSPayrollActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsUSPayrollActive IsUSPayrollActive { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public InternalUsageProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets InternalHeaderDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InternalUsageDetail> InternalUsageDetail { get; set; }

        /// <summary>
        /// Gets or sets InternalHeaderOptionalField
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InternalUsageOptionalField> InternalUsageOptionalField { get; set; }

        /// <summary>
        /// Gets or sets InternalHeaderDetailOptionalField
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InternalUsageDetailOptionalField> InternalUsageDetailOptionalField { get; set; }

        /// <summary>
        /// Gets or sets InternalHeaderLotNumber
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InternalUsageLotNumber> InternalUsageLotNumber { get; set; }

        /// <summary>
        /// Gets or sets InternalHeaderSerialNumber
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InternalUsageSerialNumber> InternalUsageSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets NotDefaulted
        /// </summary>
        [IgnoreExportImport]
        public bool NotDefaulted { get; set; }

        /// <summary>
        /// Gets or sets HeaderExists
        /// </summary>
        [IgnoreExportImport]
        public bool HeaderExists { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets EntryType string value
        /// </summary>
        public string EntryTypeString
        {
            get { return EnumUtility.GetStringValue(EntryType); }
        }

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        public string FiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(FiscalPeriod); }
        }

        /// <summary>
        /// Gets RecordStatus string value
        /// </summary>
        public string RecordStatusString
        {
            get { return EnumUtility.GetStringValue(RecordStatus); }
        }

        /// <summary>
        /// Gets RecordDeleted string value
        /// </summary>
        public string RecordDeletedString
        {
            get { return EnumUtility.GetStringValue(RecordDeleted); }
        }

        /// <summary>
        /// Gets RecordPrinted string value
        /// </summary>
        public string RecordPrintedString
        {
            get { return EnumUtility.GetStringValue(RecordPrinted); }
        }

        /// <summary>
        /// Gets IsCanadianPayrollActive string value
        /// </summary>
        public string IsCanadianPayrollActiveString
        {
            get { return EnumUtility.GetStringValue(IsCanadianPayrollActive); }
        }

        /// <summary>
        /// Gets IsUSPayrollActive string value
        /// </summary>
        public string IsUSPayrollActiveString
        {
            get { return EnumUtility.GetStringValue(IsUSPayrollActive); }
        }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// To get the string of Record Status property
        /// </summary>
        public string RecordStatusFinder
        {
            get { return EnumUtility.GetStringValue(RecordStatus); }
        }

        #endregion
    }
}
