// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for Restart Information
	/// </summary>
    [Serializable]
    public class RestartInfo
	{
        /// <summary>
        /// Gets or sets the item no.
        /// </summary>
        /// <value>
        /// The item no.
        /// </value>
        public string ItemNo { get; set; }

        /// <summary>
        /// Gets or sets the screen.
        /// </summary>
        /// <value>
        /// The screen.
        /// </value>
        public int Screen { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [master item].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [master item]; otherwise, <c>false</c>.
        /// </value>
        public bool MasterItem { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [insert all tax authorities].
        /// </summary>
        /// <value>
        /// <c>true</c> if [insert all tax authorities]; otherwise, <c>false</c>.
        /// </value>
        public bool InsertAllTaxAuthorities { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [include all locations].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [include all locations]; otherwise, <c>false</c>.
        /// </value>
        public bool IncludeAllLocations { get; set; }

        /// <summary>
        /// Gets or sets the standard cost.
        /// </summary>
        /// <value>
        /// The standard cost.
        /// </value>
        public decimal StandardCost { get; set; }

        /// <summary>
        /// Gets or sets the most recent cost.
        /// </summary>
        /// <value>
        /// The most recent cost.
        /// </value>
        public decimal MostRecentCost { get; set; }

        /// <summary>
        /// Gets or sets the last cost.
        /// </summary>
        /// <value>
        /// The last cost.
        /// </value>
        public decimal LastCost { get; set; }

        /// <summary>
        /// Gets or sets the alternate cost1.
        /// </summary>
        /// <value>
        /// The alternate cost1.
        /// </value>
        public decimal AlternateCost1 { get; set; }

        /// <summary>
        /// Gets or sets the alternate cost2.
        /// </summary>
        /// <value>
        /// The alternate cost2.
        /// </value>
        public decimal AlternateCost2 { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [include all price list].
        /// </summary>
        /// <value>
        /// <c>true</c> if [include all price list]; otherwise, <c>false</c>.
        /// </value>
        public bool IncludeAllPriceList { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [copy contract pricing].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [copy contract pricing]; otherwise, <c>false</c>.
        /// </value>
        public bool CopyContractPricing { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [copy reorder quantities].
        /// </summary>
        /// <value>
        /// <c>true</c> if [copy reorder quantities]; otherwise, <c>false</c>.
        /// </value>
        public bool CopyReorderQuantities { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [include taxin price].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [include taxin price]; otherwise, <c>false</c>.
        /// </value>
        public bool IncludeTaxinPrice { get; set; }

	}
}
