// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using System;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Class to create for Inventory Control Options
    /// </summary>
    public partial class Options : ModelBase
    {
        #region Constructors

        public Options()
        {
            ItemSegmentCodes = new List<ItemSegment>();
        }

        #endregion

        /// <summary>
        /// Gets or sets DummyField 
        /// </summary>
        [ViewField(Name = Fields.DummyField, Id = Index.DummyField, FieldType = EntityFieldType.Int, Size = 2)]
        public int DummyField { get; set; }

        /// <summary>
        /// Gets or sets ContactName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber 
        /// </summary>
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets FractionalQuantities 
        /// </summary>
        [ViewField(Name = Fields.FractionalQuantities, Id = Index.FractionalQuantities, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FractionalQuantities { get; set; }

        /// <summary>
        /// Gets or sets AllowNegativeQuantities 
        /// </summary>
        [ViewField(Name = Fields.AllowNegativeQuantities, Id = Index.AllowNegativeQuantities, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowNegativeQuantities { get; set; }

        /// <summary>
        /// Gets or sets KeepTransactionHistory 
        /// </summary>
        [ViewField(Name = Fields.KeepTransactionHistory, Id = Index.KeepTransactionHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool KeepTransactionHistory { get; set; }

        /// <summary>
        /// Gets or sets InterfaceWithJobCost 
        /// </summary>
        [ViewField(Name = Fields.InterfaceWithJobCost, Id = Index.InterfaceWithJobCost, FieldType = EntityFieldType.Bool, Size = 2)]
        public long InterfaceWithJobCost { get; set; }

        /// <summary>
        /// Gets or sets GOrLReferenceField 
        /// </summary>
        [ViewField(Name = Fields.GOrLReferenceField, Id = Index.GOrLReferenceField, FieldType = EntityFieldType.Int, Size = 2)]
        public GOrLReferenceField GOrLReferenceField { get; set; }

        /// <summary>
        /// Gets or sets GOrLDescriptionField 
        /// </summary>
        [ViewField(Name = Fields.GOrLDescriptionField, Id = Index.GOrLDescriptionField, FieldType = EntityFieldType.Int, Size = 2)]
        public GOrLReferenceField GOrLDescriptionField { get; set; }

        /// <summary>
        /// Gets or sets DefaultWeightUnitofMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultWeightUnitofMeasure, Id = Index.DefaultWeightUnitofMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string DefaultWeightUnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets Cost1Name 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Cost1Name, Id = Index.Cost1Name, FieldType = EntityFieldType.Char, Size = 10)]
        public string Cost1Name { get; set; }

        /// <summary>
        /// Gets or sets Cost2Name 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Cost2Name, Id = Index.Cost2Name, FieldType = EntityFieldType.Char, Size = 10)]
        public string Cost2Name { get; set; }

        /// <summary>
        /// Gets or sets DayEndTransactionsOutstanding 
        /// </summary>
        [ViewField(Name = Fields.DayEndTransactionsOutstanding, Id = Index.DayEndTransactionsOutstanding, FieldType = EntityFieldType.Int, Size = 2)]
        public int DayEndTransactionsOutstanding { get; set; }

        /// <summary>
        /// Gets or sets NextTransactionNumber 
        /// </summary>
        [ViewField(Name = Fields.NextTransactionNumber, Id = Index.NextTransactionNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets NextAlternateItemSetNumber 
        /// </summary>
        [ViewField(Name = Fields.NextAlternateItemSetNumber, Id = Index.NextAlternateItemSetNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextAlternateItemSetNumber { get; set; }

        /// <summary>
        /// Gets or sets GOrLTransCreatedThruDayEnd 
        /// </summary>
        [ViewField(Name = Fields.GOrLTransCreatedThruDayEnd, Id = Index.GOrLTransCreatedThruDayEnd, FieldType = EntityFieldType.Long, Size = 4)]
        public long GOrLTransCreatedThruDayEnd { get; set; }

        /// <summary>
        /// Gets or sets NextAdjustmentEntrySeq 
        /// </summary>
        [ViewField(Name = Fields.NextAdjustmentEntrySeq, Id = Index.NextAdjustmentEntrySeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextAdjustmentEntrySeq { get; set; }

        /// <summary>
        /// Gets or sets NextAssemblyEntrySeq 
        /// </summary>
        [ViewField(Name = Fields.NextAssemblyEntrySeq, Id = Index.NextAssemblyEntrySeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextAssemblyEntrySeq { get; set; }

        /// <summary>
        /// Gets or sets NextReceiptEntrySeq 
        /// </summary>
        [ViewField(Name = Fields.NextReceiptEntrySeq, Id = Index.NextReceiptEntrySeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextReceiptEntrySeq { get; set; }

        /// <summary>
        /// Gets or sets NextShipmentEntrySeq 
        /// </summary>
        [ViewField(Name = Fields.NextShipmentEntrySeq, Id = Index.NextShipmentEntrySeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextShipmentEntrySeq { get; set; }

        /// <summary>
        /// Gets or sets NextTransferEntrySeq 
        /// </summary>
        [ViewField(Name = Fields.NextTransferEntrySeq, Id = Index.NextTransferEntrySeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextTransferEntrySeq { get; set; }

        /// <summary>
        /// Gets or sets NextHistoryEntrySeq 
        /// </summary>
        [ViewField(Name = Fields.NextHistoryEntrySeq, Id = Index.NextHistoryEntrySeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextHistoryEntrySeq { get; set; }

        /// <summary>
        /// Gets or sets NextDayEndPostingSeq 
        /// </summary>
        [ViewField(Name = Fields.NextDayEndPostingSeq, Id = Index.NextDayEndPostingSeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextDayEndPostingSeq { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency 
        /// </summary>
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets DeferredGOrLPosting 
        /// </summary>
        [ViewField(Name = Fields.DeferredGOrLPosting, Id = Index.DeferredGOrLPosting, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DeferredGOrLPosting { get; set; }

        /// <summary>
        /// Gets or sets AppendToGOrLBatch 
        /// </summary>
        [ViewField(Name = Fields.AppendToGOrLBatch, Id = Index.AppendToGOrLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public AppendToGOrLBatch AppendToGOrLBatch { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateGOrLBatch 
        /// </summary>
        [ViewField(Name = Fields.ConsolidateGOrLBatch, Id = Index.ConsolidateGOrLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidateGOrLBatch ConsolidateGOrLBatch { get; set; }

        /// <summary>
        /// Gets or sets StatisticsCalendar 
        /// </summary>
        [ViewField(Name = Fields.StatisticsCalendar, Id = Index.StatisticsCalendar, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsCalendar StatisticsCalendar { get; set; }

        /// <summary>
        /// Gets or sets StatisticsPeriod 
        /// </summary>
        [ViewField(Name = Fields.StatisticsPeriod, Id = Index.StatisticsPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriod StatisticsPeriod { get; set; }

        /// <summary>
        /// Gets or sets EditStatistics 
        /// </summary>
        [ViewField(Name = Fields.EditStatistics, Id = Index.EditStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EditStatistics { get; set; }

        /// <summary>
        /// Gets or sets AllowItemsatAllLocations 
        /// </summary>
        [ViewField(Name = Fields.AllowItemsatAllLocations, Id = Index.AllowItemsatAllLocations, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowItemsatAllLocations { get; set; }

        /// <summary>
        /// Gets or sets AddlCostonRcptReturns 
        /// </summary>
        [ViewField(Name = Fields.AddlCostonRcptReturns, Id = Index.AddlCostonRcptReturns, FieldType = EntityFieldType.Int, Size = 2)]
        public AddlCostonRcptReturns AddlCostonRcptReturns { get; set; }

        /// <summary>
        /// Gets or sets DefaultRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultRateType, Id = Index.DefaultRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string DefaultRateType { get; set; }

        /// <summary>
        /// Gets or sets DefaultItemStructure 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultItemStructure, Id = Index.DefaultItemStructure, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultItemStructure { get; set; }

        /// <summary>
        /// Gets or sets AccumulateItemStatistics 
        /// </summary>
        [ViewField(Name = Fields.AccumulateItemStatistics, Id = Index.AccumulateItemStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AccumulateItemStatistics { get; set; }

        /// <summary>
        /// Gets or sets PostToClosedFiscalPeriods 
        /// </summary>
        [ViewField(Name = Fields.PostToClosedFiscalPeriods, Id = Index.PostToClosedFiscalPeriods, FieldType = EntityFieldType.Bool, Size = 2)]
        public long PostToClosedFiscalPeriods { get; set; }

        /// <summary>
        /// Gets or sets PeriodType 
        /// </summary>
        [ViewField(Name = Fields.PeriodType, Id = Index.PeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodType PeriodType { get; set; }

        /// <summary>
        /// Gets or sets PeriodLength 
        /// </summary>
        [ViewField(Name = Fields.PeriodLength, Id = Index.PeriodLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int PeriodLength { get; set; }

        /// <summary>
        /// Gets or sets FractionalQuantityDecimals 
        /// </summary>
        [ViewField(Name = Fields.FractionalQuantityDecimals, Id = Index.FractionalQuantityDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int FractionalQuantityDecimals { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactorDecimals 
        /// </summary>
        [ViewField(Name = Fields.ConversionFactorDecimals, Id = Index.ConversionFactorDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int ConversionFactorDecimals { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriods 
        /// </summary>
        [ViewField(Name = Fields.StatisticalPeriods, Id = Index.StatisticalPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public int StatisticalPeriods { get; set; }

        /// <summary>
        /// Gets or sets UseHyhenasItemSeparator 
        /// </summary>
        [ViewField(Name = Fields.UseHyhenasItemSeparator, Id = Index.UseHyhenasItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseHyhenasItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UseForwardSlashasItemSeparator
        /// </summary>
        public long UseForwardSlashasItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UseBackSlashasItemSeparator 
        /// </summary>
        [ViewField(Name = Fields.UseBackSlashasItemSeparator, Id = Index.UseBackSlashasItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseBackSlashasItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UseAsteriskasItemSeparator 
        /// </summary>
        [ViewField(Name = Fields.UseAsteriskasItemSeparator, Id = Index.UseAsteriskasItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseAsteriskasItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UsePeriodasItemSeparator 
        /// </summary>
        [ViewField(Name = Fields.UsePeriodasItemSeparator, Id = Index.UsePeriodasItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UsePeriodasItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UseLeftParenthesisasItemSep 
        /// </summary>
        [ViewField(Name = Fields.UseLeftParenthesisasItemSep, Id = Index.UseLeftParenthesisasItemSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseLeftParenthesisasItemSep { get; set; }

        /// <summary>
        /// Gets or sets UseRightParenthesisasItemSe 
        /// </summary>
        //[ViewField(Name = Fields.UseRightParenthesisasItemSe, Id = Index.UseRightParenthesisasItemSe, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseRightParenthesisasItemSe { get; set; }

        /// <summary>
        /// Gets or sets UsePoundSignasItemSeparator 
        /// </summary>
        [ViewField(Name = Fields.UsePoundSignasItemSeparator, Id = Index.UsePoundSignasItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UsePoundSignasItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets AllowReceiptofNonstockItems 
        /// </summary>
        [ViewField(Name = Fields.AllowReceiptofNonstockItems, Id = Index.AllowReceiptofNonstockItems, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowReceiptofNonstockItems { get; set; }

        /// <summary>
        /// Gets or sets PrompttoDeleteduringPosting 
        /// </summary>
        [ViewField(Name = Fields.PrompttoDeleteduringPosting, Id = Index.PrompttoDeleteduringPosting, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PrompttoDeleteduringPosting { get; set; }

        /// <summary>
        /// Gets or sets CostDuring 
        /// </summary>
        [ViewField(Name = Fields.CostDuring, Id = Index.CostDuring, FieldType = EntityFieldType.Int, Size = 2)]
        public CostDuring CostDuring { get; set; }

        /// <summary>
        /// Gets or sets AssemblyNumberLength 
        /// </summary>
        [ViewField(Name = Fields.AssemblyNumberLength, Id = Index.AssemblyNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int AssemblyNumberLength { get; set; }

        /// <summary>
        /// Gets or sets AssemblyNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AssemblyNumberPrefix, Id = Index.AssemblyNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string AssemblyNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets ASSBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ASSBODYD, Id = Index.ASSBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string ASSBODYD { get; set; }

        /// <summary>
        /// Gets or sets DisassemblyNumberLength 
        /// </summary>
        [ViewField(Name = Fields.DisassemblyNumberLength, Id = Index.DisassemblyNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int DisassemblyNumberLength { get; set; }

        /// <summary>
        /// Gets or sets DisassemblyNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DisassemblyNumberPrefix, Id = Index.DisassemblyNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string DisassemblyNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets DASBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DASBODYD, Id = Index.DASBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string DASBODYD { get; set; }

        /// <summary>
        /// Gets or sets TransferNumberLength 
        /// </summary>
        [ViewField(Name = Fields.TransferNumberLength, Id = Index.TransferNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransferNumberLength { get; set; }

        /// <summary>
        /// Gets or sets TransferNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TransferNumberPrefix, Id = Index.TransferNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string TransferNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets TRFBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRFBODYD, Id = Index.TRFBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string TRFBODYD { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumberLength 
        /// </summary>
        [ViewField(Name = Fields.AdjustmentNumberLength, Id = Index.AdjustmentNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int AdjustmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AdjustmentNumberPrefix, Id = Index.AdjustmentNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string AdjustmentNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets ADJBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ADJBODYD, Id = Index.ADJBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string ADJBODYD { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumberLength 
        /// </summary>
        [ViewField(Name = Fields.ShipmentNumberLength, Id = Index.ShipmentNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentNumberPrefix, Id = Index.ShipmentNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipmentNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets SHPBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SHPBODYD, Id = Index.SHPBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string SHPBODYD { get; set; }

        /// <summary>
        /// Gets or sets ShipmentReturnNumberLength 
        /// </summary>
        [ViewField(Name = Fields.ShipmentReturnNumberLength, Id = Index.ShipmentReturnNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ShipmentReturnNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ShipmentReturnNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentReturnNumberPrefix, Id = Index.ShipmentReturnNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipmentReturnNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets SRTBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SRTBODYD, Id = Index.SRTBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string SRTBODYD { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumberLength 
        /// </summary>
        [ViewField(Name = Fields.ReceiptNumberLength, Id = Index.ReceiptNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReceiptNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptNumberPrefix, Id = Index.ReceiptNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReceiptNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets RCPBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RCPBODYD, Id = Index.RCPBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string RCPBODYD { get; set; }

        /// <summary>
        /// Gets or sets TransitReceiptNumberLength 
        /// </summary>
        [ViewField(Name = Fields.TransitReceiptNumberLength, Id = Index.TransitReceiptNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransitReceiptNumberLength { get; set; }

        /// <summary>
        /// Gets or sets TransitReceiptNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TransitReceiptNumberPrefix, Id = Index.TransitReceiptNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string TransitReceiptNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets TRCBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRCBODYD, Id = Index.TRCBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string TRCBODYD { get; set; }

        /// <summary>
        /// Gets or sets NextNoncostedReceiptDayEnd 
        /// </summary>
        [ViewField(Name = Fields.NextNoncostedReceiptDayEnd, Id = Index.NextNoncostedReceiptDayEnd, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextNoncostedReceiptDayEnd { get; set; }

        /// <summary>
        /// Gets or sets SeparatorHyhen 
        /// </summary>
        [ViewField(Name = Fields.SeparatorHyhen, Id = Index.SeparatorHyhen, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorHyhen SeparatorHyhen { get; set; }

        /// <summary>
        /// Gets or sets SeparatorForwardSlash 
        /// </summary>
        [ViewField(Name = Fields.SeparatorForwardSlash, Id = Index.SeparatorForwardSlash, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorForwardSlash SeparatorForwardSlash { get; set; }

        /// <summary>
        /// Gets or sets SeparatorBackSlash 
        /// </summary>
        [ViewField(Name = Fields.SeparatorBackSlash, Id = Index.SeparatorBackSlash, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorBackSlash SeparatorBackSlash { get; set; }

        /// <summary>
        /// Gets or sets SeparatorAsterisk 
        /// </summary>
        [ViewField(Name = Fields.SeparatorAsterisk, Id = Index.SeparatorAsterisk, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorAsterisk SeparatorAsterisk { get; set; }

        /// <summary>
        /// Gets or sets SeparatorPeriod 
        /// </summary>
        [ViewField(Name = Fields.SeparatorPeriod, Id = Index.SeparatorPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorPeriod SeparatorPeriod { get; set; }

        /// <summary>
        /// Gets or sets SeparatorLeftParenthesis 
        /// </summary>
        [ViewField(Name = Fields.SeparatorLeftParenthesis, Id = Index.SeparatorLeftParenthesis, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorLeftParenthesis SeparatorLeftParenthesis { get; set; }

        /// <summary>
        /// Gets or sets SeparatorRightParenthesis 
        /// </summary>
        [ViewField(Name = Fields.SeparatorRightParenthesis, Id = Index.SeparatorRightParenthesis, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorRightParenthesis SeparatorRightParenthesis { get; set; }

        /// <summary>
        /// Gets or sets SeparatorNumberSign 
        /// </summary>
        [ViewField(Name = Fields.SeparatorNumberSign, Id = Index.SeparatorNumberSign, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorNumberSign SeparatorNumberSign { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.HomeCurrency, Id = Index.HomeCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets DefaultAssemblyNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultAssemblyNumber, Id = Index.DefaultAssemblyNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultAssemblyNumber { get; set; }

        /// <summary>
        /// Gets or sets ASSVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ASSVALUE, Id = Index.ASSVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string ASSVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultDisassemblyNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultDisassemblyNumber, Id = Index.DefaultDisassemblyNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultDisassemblyNumber { get; set; }

        /// <summary>
        /// Gets or sets DASVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DASVALUE, Id = Index.DASVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string DASVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultTransferNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultTransferNumber, Id = Index.DefaultTransferNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets TRFVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRFVALUE, Id = Index.TRFVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string TRFVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultAdjustmentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultAdjustmentNumber, Id = Index.DefaultAdjustmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultAdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets ADJVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ADJVALUE, Id = Index.ADJVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string ADJVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultShipmentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultShipmentNumber, Id = Index.DefaultShipmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets SHPVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SHPVALUE, Id = Index.SHPVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string SHPVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultShipmentReturnNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultShipmentReturnNumber, Id = Index.DefaultShipmentReturnNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultShipmentReturnNumber { get; set; }

        /// <summary>
        /// Gets or sets SRTVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SRTVALUE, Id = Index.SRTVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string SRTVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultReceiptNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultReceiptNumber, Id = Index.DefaultReceiptNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets RCPVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RCPVALUE, Id = Index.RCPVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string RCPVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultTransitReceiptNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultTransitReceiptNumber, Id = Index.DefaultTransitReceiptNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultTransitReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets TRCVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TRCVALUE, Id = Index.TRCVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string TRCVALUE { get; set; }

        /// <summary>
        /// Gets or sets DefaultGoodsinTransitLocatio 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultGoodsinTransitLocatio, Id = Index.DefaultGoodsinTransitLocatio, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultGoodsinTransitLocatio { get; set; }

        /// <summary>
        /// Gets or sets TransitLocationDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TransitLocationDescription, Id = Index.TransitLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransitLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets OnlyUseDefinedUOM 
        /// </summary>
        [ViewField(Name = Fields.OnlyUseDefinedUOM, Id = Index.OnlyUseDefinedUOM, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OnlyUseDefinedUOM { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod1 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod2 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod3 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets CreateSubledgerOrAuditDuring 
        /// </summary>
        [ViewField(Name = Fields.CreateSubledgerOrAuditDuring, Id = Index.CreateSubledgerOrAuditDuring, FieldType = EntityFieldType.Int, Size = 2)]
        public CostDuring CreateSubledgerOrAuditDuring { get; set; }

        /// <summary>
        /// Gets or sets NextInternalUsageEntrySeq 
        /// </summary>
        [ViewField(Name = Fields.NextInternalUsageEntrySeq, Id = Index.NextInternalUsageEntrySeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextInternalUsageEntrySeq { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageNumberLength 
        /// </summary>
        [ViewField(Name = Fields.InternalUsageNumberLength, Id = Index.InternalUsageNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int InternalUsageNumberLength { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InternalUsageNumberPrefix, Id = Index.InternalUsageNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string InternalUsageNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets ICSBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ICSBODYD, Id = Index.ICSBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string ICSBODYD { get; set; }

        /// <summary>
        /// Gets or sets DefaultInternalUsageNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultInternalUsageNumber, Id = Index.DefaultInternalUsageNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultInternalUsageNumber { get; set; }

        /// <summary>
        /// Gets or sets ICSVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ICSVALUE, Id = Index.ICSVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string ICSVALUE { get; set; }

        /// <summary>
        /// Gets or sets TransactionpostOrdepOrcost 
        /// </summary>
        [ViewField(Name = Fields.TransactionpostOrdepOrcost, Id = Index.TransactionpostOrdepOrcost, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionpostOrdepOrcost TransactionpostOrdepOrcost { get; set; }

        /// <summary>
        /// Gets or sets IOrCReceipts 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCReceipts, Id = Index.IOrCReceipts, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCReceipts { get; set; }

        /// <summary>
        /// Gets or sets IOrCReceiptReturns 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCReceiptReturns, Id = Index.IOrCReceiptReturns, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCReceiptReturns { get; set; }

        /// <summary>
        /// Gets or sets IOrCReceiptAdjustments 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCReceiptAdjustments, Id = Index.IOrCReceiptAdjustments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCReceiptAdjustments { get; set; }

        /// <summary>
        /// Gets or sets IOrCShipments 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCShipments, Id = Index.IOrCShipments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCShipments { get; set; }

        /// <summary>
        /// Gets or sets IOrCShipmentReturns 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCShipmentReturns, Id = Index.IOrCShipmentReturns, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCShipmentReturns { get; set; }

        /// <summary>
        /// Gets or sets IOrCTransfers 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCTransfers, Id = Index.IOrCTransfers, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCTransfers { get; set; }

        /// <summary>
        /// Gets or sets IOrCAssemblies 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCAssemblies, Id = Index.IOrCAssemblies, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCAssemblies { get; set; }

        /// <summary>
        /// Gets or sets IOrCAdjustments 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCAdjustments, Id = Index.IOrCAdjustments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCAdjustments { get; set; }

        /// <summary>
        /// Gets or sets IOrCConsolidatedEntry 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCConsolidatedEntry, Id = Index.IOrCConsolidatedEntry, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCConsolidatedEntry { get; set; }

        /// <summary>
        /// Gets or sets IOrCDisassemblies 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCDisassemblies, Id = Index.IOrCDisassemblies, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCDisassemblies { get; set; }

        /// <summary>
        /// Gets or sets IOrCInternalUsage 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.IOrCInternalUsage, Id = Index.IOrCInternalUsage, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string IOrCInternalUsage { get; set; }

        /// <summary>
        /// Gets or sets DefaultPostingDate 
        /// </summary>
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; }

        /// <summary>
        /// Gets or sets SerialNumberMask 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SerialNumberMask, Id = Index.SerialNumberMask, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SerialNumberMask { get; set; }

        /// <summary>
        /// Gets or sets UseSerialsDaystoExpire 
        /// </summary>
        [ViewField(Name = Fields.UseSerialsDaystoExpire, Id = Index.UseSerialsDaystoExpire, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseSerialsDaystoExpire { get; set; }

        /// <summary>
        /// Gets or sets SerialsDaystoExpire 
        /// </summary>
        [ViewField(Name = Fields.SerialsDaystoExpire, Id = Index.SerialsDaystoExpire, FieldType = EntityFieldType.Int, Size = 2)]
        public int SerialsDaystoExpire { get; set; }

        /// <summary>
        /// Gets or sets AllowDifferentSerialQty 
        /// </summary>
        [ViewField(Name = Fields.AllowDifferentSerialQty, Id = Index.AllowDifferentSerialQty, FieldType = EntityFieldType.Bool, Size = 2)]
        public long AllowDifferentSerialQty { get; set; }

        /// <summary>
        /// Gets or sets AllowSerialAlloconQtyOrd 
        /// </summary>
        [ViewField(Name = Fields.AllowSerialAlloconQtyOrd, Id = Index.AllowSerialAlloconQtyOrd, FieldType = EntityFieldType.Bool, Size = 2)]
        public long AllowSerialAlloconQtyOrd { get; set; }

        /// <summary>
        /// Gets or sets SortSerialsby 
        /// </summary>
        [ViewField(Name = Fields.SortSerialsby, Id = Index.SortSerialsby, FieldType = EntityFieldType.Int, Size = 2)]
        public SortSerialsby SortSerialsby { get; set; }

        /// <summary>
        /// Gets or sets SortSerialsFirstby 
        /// </summary>
        [ViewField(Name = Fields.SortSerialsFirstby, Id = Index.SortSerialsFirstby, FieldType = EntityFieldType.Int, Size = 2)]
        public SortSerialsFirstby SortSerialsFirstby { get; set; }

        /// <summary>
        /// Gets or sets StopAllocationofExpiredSeria 
        /// </summary>
        public StopAllocationofExpiredSerial StopAllocationofExpiredSerial { get; set; }

        /// <summary>
        /// Gets or sets SerialsHyphenasSeparator 
        /// </summary>
        [ViewField(Name = Fields.SerialsHyphenasSeparator, Id = Index.SerialsHyphenasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsHyphenasSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsFwdSlashasSeparator 
        /// </summary>
        [ViewField(Name = Fields.SerialsFwdSlashasSeparator, Id = Index.SerialsFwdSlashasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsFwdSlashasSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsBackSlashasSeparator 
        /// </summary>
        [ViewField(Name = Fields.SerialsBackSlashasSeparator, Id = Index.SerialsBackSlashasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsBackSlashasSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsAsteriskasSeparator 
        /// </summary>
        [ViewField(Name = Fields.SerialsAsteriskasSeparator, Id = Index.SerialsAsteriskasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsAsteriskasSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsPeriodasSeparator 
        /// </summary>
        [ViewField(Name = Fields.SerialsPeriodasSeparator, Id = Index.SerialsPeriodasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsPeriodasSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsLeftParenthesisasSep 
        /// </summary>
        [ViewField(Name = Fields.SerialsLeftParenthesisasSep, Id = Index.SerialsLeftParenthesisasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsLeftParenthesisasSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsRightParenthesisasSep 
        /// </summary>
        [ViewField(Name = Fields.SerialsRightParenthesisasSep, Id = Index.SerialsRightParenthesisasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsRightParenthesisasSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsPoundSignasSeparator 
        /// </summary>
        [ViewField(Name = Fields.SerialsPoundSignasSeparator, Id = Index.SerialsPoundSignasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsPoundSignasSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsLeftBracketasSep 
        /// </summary>
        [ViewField(Name = Fields.SerialsLeftBracketasSep, Id = Index.SerialsLeftBracketasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsLeftBracketasSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsRightBracketasSep 
        /// </summary>
        [ViewField(Name = Fields.SerialsRightBracketasSep, Id = Index.SerialsRightBracketasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsRightBracketasSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsLeftBraceasSep 
        /// </summary>
        [ViewField(Name = Fields.SerialsLeftBraceasSep, Id = Index.SerialsLeftBraceasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsLeftBraceasSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsRightBraceasSep 
        /// </summary>
        [ViewField(Name = Fields.SerialsRightBraceasSep, Id = Index.SerialsRightBraceasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long SerialsRightBraceasSep { get; set; }

        /// <summary>
        /// Gets or sets LotNumberMask 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LotNumberMask, Id = Index.LotNumberMask, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string LotNumberMask { get; set; }

        /// <summary>
        /// Gets or sets UseLotsDaystoExpire 
        /// </summary>
        [ViewField(Name = Fields.UseLotsDaystoExpire, Id = Index.UseLotsDaystoExpire, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseLotsDaystoExpire { get; set; }

        /// <summary>
        /// Gets or sets LotsDaystoExpire 
        /// </summary>
        [ViewField(Name = Fields.LotsDaystoExpire, Id = Index.LotsDaystoExpire, FieldType = EntityFieldType.Int, Size = 2)]
        public int LotsDaystoExpire { get; set; }

        /// <summary>
        /// Gets or sets UseLotsDaysonQuarantine 
        /// </summary>
        [ViewField(Name = Fields.UseLotsDaysonQuarantine, Id = Index.UseLotsDaysonQuarantine, FieldType = EntityFieldType.Bool, Size = 2)]
        public long UseLotsDaysonQuarantine { get; set; }

        /// <summary>
        /// Gets or sets LotsDaysonQuarantine 
        /// </summary>
        [ViewField(Name = Fields.LotsDaysonQuarantine, Id = Index.LotsDaysonQuarantine, FieldType = EntityFieldType.Int, Size = 2)]
        public int LotsDaysonQuarantine { get; set; }

        /// <summary>
        /// Gets or sets AllowDifferentLotQty 
        /// </summary>
        [ViewField(Name = Fields.AllowDifferentLotQty, Id = Index.AllowDifferentLotQty, FieldType = EntityFieldType.Bool, Size = 2)]
        public long AllowDifferentLotQty { get; set; }

        /// <summary>
        /// Gets or sets AllowLotAlloconQtyOrd 
        /// </summary>
        [ViewField(Name = Fields.AllowLotAlloconQtyOrd, Id = Index.AllowLotAlloconQtyOrd, FieldType = EntityFieldType.Bool, Size = 2)]
        public long AllowLotAlloconQtyOrd { get; set; }

        /// <summary>
        /// Gets or sets SortLotsby 
        /// </summary>
        [ViewField(Name = Fields.SortLotsby, Id = Index.SortLotsby, FieldType = EntityFieldType.Int, Size = 2)]
        public SortLotsby SortLotsby { get; set; }

        /// <summary>
        /// Gets or sets SortLotsFirstby 
        /// </summary>
        [ViewField(Name = Fields.SortLotsFirstby, Id = Index.SortLotsFirstby, FieldType = EntityFieldType.Int, Size = 2)]
        public SortSerialsFirstby SortLotsFirstby { get; set; }

        /// <summary>
        /// Gets or sets StopAllocationofExpiredLots 
        /// </summary>
        [ViewField(Name = Fields.StopAllocationofExpiredLots, Id = Index.StopAllocationofExpiredLots, FieldType = EntityFieldType.Int, Size = 2)]
        public StopAllocationofExpiredSerial StopAllocationofExpiredLots { get; set; }

        /// <summary>
        /// Gets or sets LotsHyphenasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsHyphenasSeparator, Id = Index.LotsHyphenasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsHyphenasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsFwdSlashasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsFwdSlashasSeparator, Id = Index.LotsFwdSlashasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsFwdSlashasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsBackSlashasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsBackSlashasSeparator, Id = Index.LotsBackSlashasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsBackSlashasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsAsteriskasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsAsteriskasSeparator, Id = Index.LotsAsteriskasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsAsteriskasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsPeriodasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsPeriodasSeparator, Id = Index.LotsPeriodasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsPeriodasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsLeftParenthesisasSep 
        /// </summary>
        [ViewField(Name = Fields.LotsLeftParenthesisasSep, Id = Index.LotsLeftParenthesisasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsLeftParenthesisasSep { get; set; }

        /// <summary>
        /// Gets or sets LotsRightParenthesisasSep 
        /// </summary>
        [ViewField(Name = Fields.LotsRightParenthesisasSep, Id = Index.LotsRightParenthesisasSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsRightParenthesisasSep { get; set; }

        /// <summary>
        /// Gets or sets LotsPoundSignasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsPoundSignasSeparator, Id = Index.LotsPoundSignasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsPoundSignasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsLeftBracketasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsLeftBracketasSeparator, Id = Index.LotsLeftBracketasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsLeftBracketasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsRightBracketasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsRightBracketasSeparator, Id = Index.LotsRightBracketasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsRightBracketasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsLeftBraceasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsLeftBraceasSeparator, Id = Index.LotsLeftBraceasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsLeftBraceasSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsRightBraceasSeparator 
        /// </summary>
        [ViewField(Name = Fields.LotsRightBraceasSeparator, Id = Index.LotsRightBraceasSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public long LotsRightBraceasSeparator { get; set; }

        /// <summary>
        /// Gets or sets RecallOrReleaseSequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.RecallOrReleaseSequenceNumber, Id = Index.RecallOrReleaseSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RecallOrReleaseSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets RecallNumberLength 
        /// </summary>
        [ViewField(Name = Fields.RecallNumberLength, Id = Index.RecallNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int RecallNumberLength { get; set; }

        /// <summary>
        /// Gets or sets RecallNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RecallNumberPrefix, Id = Index.RecallNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RecallNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets RECBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RECBODYD, Id = Index.RECBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string RECBODYD { get; set; }

        /// <summary>
        /// Gets or sets DefaultRecallNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultRecallNumber, Id = Index.DefaultRecallNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultRecallNumber { get; set; }

        /// <summary>
        /// Gets or sets RECVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RECVALUE, Id = Index.RECVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string RECVALUE { get; set; }

        /// <summary>
        /// Gets or sets ReleaseNumberLength 
        /// </summary>
        [ViewField(Name = Fields.ReleaseNumberLength, Id = Index.ReleaseNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReleaseNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ReleaseNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReleaseNumberPrefix, Id = Index.ReleaseNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReleaseNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets RELBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RELBODYD, Id = Index.RELBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string RELBODYD { get; set; }

        /// <summary>
        /// Gets or sets DefaultReleaseNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultReleaseNumber, Id = Index.DefaultReleaseNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReleaseNumber { get; set; }

        /// <summary>
        /// Gets or sets RELVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RELVALUE, Id = Index.RELVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string RELVALUE { get; set; }

        /// <summary>
        /// Gets or sets CombineOrSplitSequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.CombineOrSplitSequenceNumber, Id = Index.CombineOrSplitSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CombineOrSplitSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets CombineNumberLength 
        /// </summary>
        [ViewField(Name = Fields.CombineNumberLength, Id = Index.CombineNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int CombineNumberLength { get; set; }

        /// <summary>
        /// Gets or sets CombineNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CombineNumberPrefix, Id = Index.CombineNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CombineNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets COMBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.COMBODYD, Id = Index.COMBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string COMBODYD { get; set; }

        /// <summary>
        /// Gets or sets DefaultCombineNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultCombineNumber, Id = Index.DefaultCombineNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultCombineNumber { get; set; }

        /// <summary>
        /// Gets or sets COMVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.COMVALUE, Id = Index.COMVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string COMVALUE { get; set; }

        /// <summary>
        /// Gets or sets SplitNumberLength 
        /// </summary>
        [ViewField(Name = Fields.SplitNumberLength, Id = Index.SplitNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int SplitNumberLength { get; set; }

        /// <summary>
        /// Gets or sets SplitNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SplitNumberPrefix, Id = Index.SplitNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string SplitNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets SPLBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SPLBODYD, Id = Index.SPLBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string SPLBODYD { get; set; }

        /// <summary>
        /// Gets or sets DefaultSplitNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultSplitNumber, Id = Index.DefaultSplitNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultSplitNumber { get; set; }

        /// <summary>
        /// Gets or sets SPLVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SPLVALUE, Id = Index.SPLVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string SPLVALUE { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationSequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationSequenceNumber, Id = Index.ReconciliationSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReconciliationSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationNumberLength 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationNumberLength, Id = Index.ReconciliationNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationNumberPrefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReconciliationNumberPrefix, Id = Index.ReconciliationNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReconciliationNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets RCNBODYD 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RCNBODYD, Id = Index.RCNBODYD, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string RCNBODYD { get; set; }

        /// <summary>
        /// Gets or sets DefaultReconciliationNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultReconciliationNumber, Id = Index.DefaultReconciliationNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReconciliationNumber { get; set; }

        /// <summary>
        /// Gets or sets RCNVALUE 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RCNVALUE, Id = Index.RCNVALUE, FieldType = EntityFieldType.Char, Size = 22)]
        public string RCNVALUE { get; set; }

        /// <summary>
        /// Gets or sets SeparatorLeftBracket 
        /// </summary>
        [ViewField(Name = Fields.SeparatorLeftBracket, Id = Index.SeparatorLeftBracket, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorLeftBracket SeparatorLeftBracket { get; set; }

        /// <summary>
        /// Gets or sets SeparatorRightBracket 
        /// </summary>
        [ViewField(Name = Fields.SeparatorRightBracket, Id = Index.SeparatorRightBracket, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorRightBracket SeparatorRightBracket { get; set; }

        /// <summary>
        /// Gets or sets SeparatorLeftBrace 
        /// </summary>
        [ViewField(Name = Fields.SeparatorLeftBrace, Id = Index.SeparatorLeftBrace, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorLeftBrace SeparatorLeftBrace { get; set; }

        /// <summary>
        /// Gets or sets SeparatorRightBrace 
        /// </summary>
        [ViewField(Name = Fields.SeparatorRightBrace, Id = Index.SeparatorRightBrace, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorRightBrace SeparatorRightBrace { get; set; }

        /// <summary>
        /// Gets or sets AllowDuplicateSerials 
        /// </summary>
        [ViewField(Name = Fields.AllowDuplicateSerials, Id = Index.AllowDuplicateSerials, FieldType = EntityFieldType.Bool, Size = 2)]
        public long AllowDuplicateSerials { get; set; }

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        /// <summary>
        /// Gets or sets End Process Date
        /// </summary>
        [ViewField(Name = Fields.LastDayEndProcessDate, Id = Index.LastDayEndProcessDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastDayEndProcessDate { get; set; }

        /// <summary>
        /// Gets or sets Last Day End Process Time
        /// </summary>
        [ViewField(Name = Fields.LastDayEndProcessTime, Id = Index.LastDayEndProcessTime, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime LastDayEndProcessTime { get; set; }

        #region UI Properties

        /// <summary>
        /// Get Segment Code Details
        /// </summary>
        public List<ItemSegment> ItemSegmentCodes { get; private set; }

        #endregion
    }
}
