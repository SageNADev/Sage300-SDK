// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A class for Units of Measure
    /// </summary>
    public partial class UnitsOfMeasure : ModelBase
    {

        /// <summary>
        /// Gets or sets UnitsofMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof (UnitsOfMeasureResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets DefaultConversionFactor 
        /// </summary>
        [Display(Name = "DefConversion", ResourceType = typeof (UnitsOfMeasureResx))]
        [ViewField(Name = Fields.DefaultConversionFactor, Id = Index.DefaultConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal DefaultConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        public long SerialNumber { get; set; }

    }
}
