// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Partial class for ReceiptDetail
    /// </summary>
    public partial class ReceiptDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets SequenceNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets QuantityReceived
        /// </summary>
        [Display(Name = "QuantityReceived", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityReceived, Id = Index.QuantityReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReceived { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QuantityReturned", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactor
        /// </summary>
        [Display(Name = "ConversionFactor", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets ProratedAddlCostFunc
        /// </summary>
        [Display(Name = "ProratedAddlCostFunc", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ProratedAddlCostFunc, Id = Index.ProratedAddlCostFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ProratedAddlCostFunc { get; set; }

        /// <summary>
        /// Gets or sets ProratedAddlCostSrc
        /// </summary>
        [Display(Name = "ProratedAddlCostSrc", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ProratedAddlCostSrc, Id = Index.ProratedAddlCostSrc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ProratedAddlCostSrc { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets AdjustedUnitCost
        /// </summary>
        [Display(Name = "AdjustedUnitCost", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.AdjustedUnitCost, Id = Index.AdjustedUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal AdjustedUnitCost { get; set; }

        /// <summary>
        /// Gets or sets AdjustedCost
        /// </summary>
        [Display(Name = "AdjustedCost", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.AdjustedCost, Id = Index.AdjustedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustedCost { get; set; }

        /// <summary>
        /// Gets or sets AdjustedCostFunctional
        /// </summary>
        [Display(Name = "AdjustedCostFunctional", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.AdjustedCostFunctional, Id = Index.AdjustedCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustedCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostFunctional
        /// </summary>
        [Display(Name = "ExtendedCostFunctional", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExtendedCostFunctional, Id = Index.ExtendedCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets ReturnCost
        /// </summary>
        [Display(Name = "ReturnCost", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ReturnCost, Id = Index.ReturnCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReturnCost { get; set; }

        /// <summary>
        /// Gets or sets CostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostingDate", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.CostingDate, Id = Index.CostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CostingDate { get; set; }

        /// <summary>
        /// Gets or sets CostingSequenceNo
        /// </summary>
        [Display(Name = "CostingSequenceNo", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.CostingSequenceNo, Id = Index.CostingSequenceNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets OriginalReceiptQty
        /// </summary>
        [Display(Name = "OriginalReceiptQty", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.OriginalReceiptQty, Id = Index.OriginalReceiptQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal OriginalReceiptQty { get; set; }

        /// <summary>
        /// Gets or sets OriginalUnitCost
        /// </summary>
        [Display(Name = "OriginalUnitCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.OriginalUnitCost, Id = Index.OriginalUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OriginalUnitCost { get; set; }

        /// <summary>
        /// Gets or sets OriginalExtendedCost
        /// </summary>
        [Display(Name = "OriginalExtendedCost", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.OriginalExtendedCost, Id = Index.OriginalExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets OriginalExtendedCostFunc
        /// </summary>
        [Display(Name = "OriginalExtendedCostFunc", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.OriginalExtendedCostFunc, Id = Index.OriginalExtendedCostFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalExtendedCostFunc { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets Labels
        /// </summary>
        [Display(Name = "Labels", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Labels, Id = Index.Labels, FieldType = EntityFieldType.Int, Size = 2)]
        public int Labels { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [Display(Name = "StockItem", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StockItem { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.VendorItemNumber, Id = Index.VendorItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string VendorItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailLineNumber
        /// </summary>
        [Display(Name = "DetailLineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DetailLineNumber, Id = Index.DetailLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailLineNumber { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturnedToDate
        /// </summary>
        [Display(Name = "QuantityReturnedToDate", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.QuantityReturnedToDate, Id = Index.QuantityReturnedToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturnedToDate { get; set; }

        /// <summary>
        /// Gets or sets ReturnedExtCostToDate
        /// </summary>
        [Display(Name = "ReturnedExtCostToDate", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ReturnedExtCostToDate, Id = Index.ReturnedExtCostToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReturnedExtCostToDate { get; set; }

        /// <summary>
        /// Gets or sets ReturnedExtCostFuncToDate
        /// </summary>
        [Display(Name = "ReturnedExtCostFuncToDate", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ReturnedExtCostFuncToDate, Id = Index.ReturnedExtCostFuncToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReturnedExtCostFuncToDate { get; set; }

        /// <summary>
        /// Gets or sets AdjustedExtCostToDate
        /// </summary>
        [Display(Name = "AdjustedExtCostToDate", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.AdjustedExtCostToDate, Id = Index.AdjustedExtCostToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustedExtCostToDate { get; set; }

        /// <summary>
        /// Gets or sets AdjustedExtCostFuncToDate
        /// </summary>
        [Display(Name = "AdjustedExtCostFuncToDate", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.AdjustedExtCostFuncToDate, Id = Index.AdjustedExtCostFuncToDate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustedExtCostFuncToDate { get; set; }

        /// <summary>
        /// Gets or sets PreviousDayEndReceiptQty
        /// </summary>
        [Display(Name = "PreviousDayEndReceiptQty", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.PreviousDayEndReceiptQty, Id = Index.PreviousDayEndReceiptQty, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal PreviousDayEndReceiptQty { get; set; }

        /// <summary>
        /// Gets or sets PreviousDayEndUnitCost
        /// </summary>
        [Display(Name = "PreviousDayEndUnitCost", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.PreviousDayEndUnitCost, Id = Index.PreviousDayEndUnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PreviousDayEndUnitCost { get; set; }

        /// <summary>
        /// Gets or sets PreviousDayEndExtCost
        /// </summary>
        [Display(Name = "PreviousDayEndExtCost", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.PreviousDayEndExtCost, Id = Index.PreviousDayEndExtCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreviousDayEndExtCost { get; set; }

        /// <summary>
        /// Gets or sets PreviousDayEndExtCostFunc
        /// </summary>
        [Display(Name = "PreviousDayEndExtCostFunc", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.PreviousDayEndExtCostFunc, Id = Index.PreviousDayEndExtCostFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PreviousDayEndExtCostFunc { get; set; }

        /// <summary>
        /// Gets or sets UnformattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnformattedItemNumber, Id = Index.UnformattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string UnformattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckBelowZero
        /// </summary>
        [Display(Name = "CheckBelowZero", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CheckBelowZero, Id = Index.CheckBelowZero, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CheckBelowZero { get; set; }

        /// <summary>
        /// Gets or sets RevisionListLineNumber
        /// </summary>
        [Display(Name = "RevisionListLineNumber", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.RevisionListLineNumber, Id = Index.RevisionListLineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int RevisionListLineNumber { get; set; }

        /// <summary>
        /// Gets or sets InterprocessCommID
        /// </summary>
        [Display(Name = "InterprocessCommID", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.InterprocessCommID, Id = Index.InterprocessCommID, FieldType = EntityFieldType.Long, Size = 4)]
        public long InterprocessCommID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupSN
        /// </summary>
        [Display(Name = "ForcePopupSN", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ForcePopupSN, Id = Index.ForcePopupSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupSN { get; set; }

        /// <summary>
        /// Gets or sets PopupSN
        /// </summary>
        [Display(Name = "PopupSN", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.PopupSN, Id = Index.PopupSN, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupSN { get; set; }

        /// <summary>
        /// Gets or sets CloseSN
        /// </summary>
        [Display(Name = "CloseSN", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.CloseSN, Id = Index.CloseSN, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseSN { get; set; }

        /// <summary>
        /// Gets or sets LTSetID
        /// </summary>
        [Display(Name = "LTSetID", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.LTSetID, Id = Index.LTSetID, FieldType = EntityFieldType.Long, Size = 4)]
        public long LTSetID { get; set; }

        /// <summary>
        /// Gets or sets ForcePopupLT
        /// </summary>
        [Display(Name = "ForcePopupLT", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ForcePopupLT, Id = Index.ForcePopupLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ForcePopupLT { get; set; }

        /// <summary>
        /// Gets or sets PopupLT
        /// </summary>
        [Display(Name = "PopupLT", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.PopupLT, Id = Index.PopupLT, FieldType = EntityFieldType.Int, Size = 2)]
        public int PopupLT { get; set; }

        /// <summary>
        /// Gets or sets CloseLT
        /// </summary>
        [Display(Name = "CloseLT", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.CloseLT, Id = Index.CloseLT, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CloseLT { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ReceiptResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets SerialQuantity
        /// </summary>
        [Display(Name = "SerialQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets SerialQuantityReturned
        /// </summary>
        [Display(Name = "SerialQuantityReturned", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialQuantityReturned, Id = Index.SerialQuantityReturned, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets LotQuantityReturned
        /// </summary>
        [Display(Name = "LotQuantityReturned", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LotQuantityReturned, Id = Index.LotQuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityperLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets ReceiptType
        /// </summary>
        [Display(Name = "ReceiptType", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ReceiptType, Id = Index.ReceiptType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptType ReceiptType { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        /// <summary>
        /// Get or sets ShowFinder
        /// </summary>
        [IgnoreExportImport]
        public bool ShowFinder { get; set; }

        /// <summary>
        /// Gets OptionalFieldString 
        /// </summary>
        [IgnoreExportImport]
        public string OptionalFieldString
        {
            get
            {
                return OptionalFields > 0 ? EnumUtility.GetStringValue(AllowBlank.Yes) : EnumUtility.GetStringValue(AllowBlank.No);
            }
        }
    }
}
