/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Class for Optional Field Detail Model
    /// </summary>
    public partial class OptionalFieldDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "OptionalField", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDefault", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldType Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate 
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank Validate { get; set; }

        /// <summary>
        /// Gets or sets AutoInsert 
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank AutoInsert { get; set; }

        /// <summary>
        /// Gets or sets Payables Clearing 
        /// </summary>
        [Display(Name = "PayablesClearing", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PayablesClearing, Id = Index.PayablesClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public bool PayablesClearing { get; set; }

        /// <summary>
        /// Gets or sets InventoryControl 
        /// </summary>
        [Display(Name = "InventoryControl", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InventoryControl, Id = Index.InventoryControl, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InventoryControl { get; set; }

        /// <summary>
        /// Gets or sets NonStockClearing 
        /// </summary>
        [Display(Name = "NonStockClearing", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.NonStockClearing, Id = Index.NonStockClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public bool NonStockClearing { get; set; }

        /// <summary>
        /// Gets or sets CostofGoodsSold 
        /// </summary>
        [Display(Name = "CostofGoodsSold", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostOfGoodsSold, Id = Index.CostOfGoodsSold, FieldType = EntityFieldType.Int, Size = 2)]
        public bool CostOfGoodsSold { get; set; }

        /// <summary>
        /// Gets or sets CostVariance 
        /// </summary>
        [Display(Name = "CostVariance", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostVariance, Id = Index.CostVariance, FieldType = EntityFieldType.Int, Size = 2)]
        public bool CostVariance { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentWriteOff 
        /// </summary>
        [Display(Name = "AdjustmentWriteOffs", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AdjustmentWriteOff, Id = Index.AdjustmentWriteOff, FieldType = EntityFieldType.Int, Size = 2)]
        public bool AdjustmentWriteOff { get; set; }

        /// <summary>
        /// Gets or sets WorkinProgress 
        /// </summary>
        [Display(Name = "WorkinProgress", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.WorkinProgress, Id = Index.WorkinProgress, FieldType = EntityFieldType.Int, Size = 2)]
        public PayablesClearing WorkinProgress { get; set; }

        /// <summary>
        /// Gets or sets CostofSales 
        /// </summary>
        [Display(Name = "CostofSales", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.CostOfSales, Id = Index.CostOfSales, FieldType = EntityFieldType.Int, Size = 2)]
        public PayablesClearing CostOfSales { get; set; }

        /// <summary>
        /// Gets or sets Overhead 
        /// </summary>
        [Display(Name = "Overhead", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Overhead, Id = Index.Overhead, FieldType = EntityFieldType.Int, Size = 2)]
        public PayablesClearing Overhead { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlFromLocation 
        /// </summary>
        [Display(Name = "InventoryControlFromLocation", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InventoryControlFromLocation, Id = Index.InventoryControlFromLocation, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InventoryControlFromLocation { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlToLocation 
        /// </summary>
        [Display(Name = "InventoryControlToLocation", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InventoryControlToLocation, Id = Index.InventoryControlToLocation, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InventoryControlToLocation { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlGITLocation 
        /// </summary>
        [Display(Name = "InventoryControlGitLocation", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InventoryControlGitLocation, Id = Index.InventoryControlGitLocation, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InventoryControlGitLocation { get; set; }

        /// <summary>
        /// Gets or sets TransferClearing 
        /// </summary>
        [Display(Name = "TransferClearing", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransferClearing, Id = Index.TransferClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public bool TransferClearing { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlMasterItem 
        /// </summary>
        [Display(Name = "InventoryControlMasterItem", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InventoryControlMasterItem, Id = Index.InventoryControlMasterItem, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InventoryControlMasterItem { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlComponent 
        /// </summary>
        [Display(Name = "InventoryControlComponent", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InventoryControlComponent, Id = Index.InventoryControlComponent, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InventoryControlComponent { get; set; }

        /// <summary>
        /// Gets or sets AssemblyCostCredit 
        /// </summary>
        [Display(Name = "AssemblyCostCredit", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AssemblyCostCredit, Id = Index.AssemblyCostCredit, FieldType = EntityFieldType.Int, Size = 2)]
        public bool AssemblyCostCredit { get; set; }

        /// <summary>
        /// Gets or sets DisassemblyExpense 
        /// </summary>
        [Display(Name = "DisassemblyExpense", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DisassemblyExpense, Id = Index.DisassemblyExpense, FieldType = EntityFieldType.Int, Size = 2)]
        public bool DisassemblyExpense { get; set; }

        /// <summary>
        /// Gets or sets Required 
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank Required { get; set; }

        /// <summary>
        /// Gets or sets ValueSet 
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank ValueSet { get; set; }

        /// <summary>
        /// Gets or sets InternalUsage 
        /// </summary>
        [Display(Name = "InternalUsage", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.InternalUsage, Id = Index.InternalUsage, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InternalUsage { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex 
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets DefaultTextValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultTextValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultAmountValue 
        /// </summary>
        [Display(Name = "DefaultAmountValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberValue 
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultIntegerValue 
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long DefaultIntegerValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultYesOrNoValue 
        /// </summary>
        [Display(Name = "DefaultYesOrNoValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultYesOrNoValue, Id = Index.DefaultYesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank DefaultYesOrNoValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultDateValue 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public string DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue 
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDesc", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValueDescription { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField value
        /// </summary>
        [IgnoreExportImport]
        public OptionalFields DefaultOptionFieldValue { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

        /// <summary>
        /// Gets or sets PayablesClearing1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing PayablesClearing1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControl1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing InventoryControl1 { get; set; }

        /// <summary>
        /// Gets or sets NonStockClearing1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing NonStockClearing1 { get; set; }

        /// <summary>
        /// Gets or sets CostofGoodsSold1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing CostOfGoodsSold1 { get; set; }

        /// <summary>
        /// Gets or sets CostVariance1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing CostVariance1 { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentWriteOff1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing AdjustmentWriteOff1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlFromLocation1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing InventoryControlFromLocation1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlToLocation1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing InventoryControlToLocation1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlGITLocation1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing InventoryControlGitLocation1 { get; set; }

        /// <summary>
        /// Gets or sets TransferClearing1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing TransferClearing1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlMasterItem1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing InventoryControlMasterItem1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControlComponent1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing InventoryControlComponent1 { get; set; }

        /// <summary>
        /// Gets or sets AssemblyCostCredit1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing AssemblyCostCredit1 { get; set; }

        /// <summary>
        /// Gets or sets DisassemblyExpense1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing DisassemblyExpense1 { get; set; }

        /// <summary>
        /// Gets or sets InternalUsage1 
        /// </summary>
        [IgnoreExportImport]
        public PayablesClearing InternalUsage1 { get; set; }

        /// <summary>
        /// Gets the string of Type property
        /// </summary>
        [IgnoreExportImport]
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets the string of ValueSet property
        /// </summary>
        [IgnoreExportImport]
        public string ValueSetString
        {
            get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        /// Gets the string of Location property
        /// </summary>
        [IgnoreExportImport]
        public string LocationString
        {
            get { return EnumUtility.GetStringValue(Location); }
        }

        /// <summary>
        /// Gets the string of AllowBlank property
        /// </summary>
        [IgnoreExportImport]
        public string AllowBlankString
        {
            get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// Gets the string of Validate property
        /// </summary>
        [IgnoreExportImport]
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// Gets the string of AutoInsert property
        /// </summary>
        [IgnoreExportImport]
        public string AutoInsertString
        {
            get { return EnumUtility.GetStringValue(AutoInsert); }
        }

        /// <summary>
        /// Gets the string of Required property
        /// </summary>
        [IgnoreExportImport]
        public string RequiredString
        {
            get { return EnumUtility.GetStringValue(Required); }
        }

        /// <summary>
        /// Gets the string of DefaultYesOrNoValue property
        /// </summary>
        [IgnoreExportImport]
        public string DefaultYesOrNoValueString
        {
            get { return EnumUtility.GetStringValue(DefaultYesOrNoValue); }
        }

        /// <summary>
        /// Gets WorkinProgressString 
        /// </summary>
        [IgnoreExportImport]
        public string WorkinProgressString { get { return EnumUtility.GetStringValue(WorkinProgress); } }

        /// <summary>
        /// Gets CostofSalesString 
        /// </summary>
        [IgnoreExportImport]
        public string CostOfSalesString { get { return EnumUtility.GetStringValue(CostOfSales); } }

        /// <summary>
        /// Gets OverheadString 
        /// </summary>
        [IgnoreExportImport]
        public string OverheadString { get { return EnumUtility.GetStringValue(Overhead); } }

        /// <summary>
        /// Gets Payables ClearingString 
        /// </summary>
        [IgnoreExportImport]
        public string PayablesClearingString { get { return EnumUtility.GetStringValue(PayablesClearing1); } }

        /// <summary>
        /// Gets InventoryControlString 
        /// </summary>
        [IgnoreExportImport]
        public string InventoryControlString { get { return EnumUtility.GetStringValue(InventoryControl1); } }

        /// <summary>
        /// Gets NonStockClearingString 
        /// </summary>
        [IgnoreExportImport]
        public string NonStockClearingString { get { return EnumUtility.GetStringValue(NonStockClearing1); } }

        /// <summary>
        /// Gets CostofGoodsSoldString 
        /// </summary>
        [IgnoreExportImport]
        public string CostOfGoodsSoldString { get { return EnumUtility.GetStringValue(CostOfGoodsSold1); } }

        /// <summary>
        /// Gets CostVarianceString 
        /// </summary>
        [IgnoreExportImport]
        public string CostVarianceString { get { return EnumUtility.GetStringValue(CostVariance1); } }

        /// <summary>
        /// Gets AdjustmentWriteOffString 
        /// </summary>
        [IgnoreExportImport]
        public string AdjustmentWriteOffString { get { return EnumUtility.GetStringValue(AdjustmentWriteOff1); } }

        /// <summary>
        /// Gets InventoryControlFromLocationString 
        /// </summary>
        [IgnoreExportImport]
        public string InventoryControlFromLocationString { get { return EnumUtility.GetStringValue(InventoryControlFromLocation1); } }

        /// <summary>
        /// Gets InventoryControlToLocationString 
        /// </summary>
        [IgnoreExportImport]
        public string InventoryControlToLocationString { get { return EnumUtility.GetStringValue(InventoryControlToLocation1); } }

        /// <summary>
        /// Gets InventoryControlGITLocationString 
        /// </summary>
        [IgnoreExportImport]
        public string InventoryControlGitLocationString { get { return EnumUtility.GetStringValue(InventoryControlGitLocation1); } }

        /// <summary>
        /// Gets TransferClearingString 
        /// </summary>
        [IgnoreExportImport]
        public string TransferClearingString { get { return EnumUtility.GetStringValue(TransferClearing1); } }

        /// <summary>
        /// Gets InventoryControlMasterItemString 
        /// </summary>
        [IgnoreExportImport]
        public string InventoryControlMasterItemString { get { return EnumUtility.GetStringValue(InventoryControlMasterItem1); } }

        /// <summary>
        /// Gets InventoryControlComponentString 
        /// </summary>
        [IgnoreExportImport]
        public string InventoryControlComponentString { get { return EnumUtility.GetStringValue(InventoryControlComponent1); } }

        /// <summary>
        /// Gets AssemblyCostCreditString 
        /// </summary>
        [IgnoreExportImport]
        public string AssemblyCostCreditString { get { return EnumUtility.GetStringValue(AssemblyCostCredit1); } }

        /// <summary>
        /// Gets DisassemblyExpenseString 
        /// </summary>
        [IgnoreExportImport]
        public string DisassemblyExpenseString { get { return EnumUtility.GetStringValue(DisassemblyExpense1); } }

        /// <summary>
        /// Gets InternalUsageString 
        /// </summary>
        [IgnoreExportImport]
        public string InternalUsageString { get { return EnumUtility.GetStringValue(InternalUsage1); } }

        /// <summary>
        /// Gets AllowBlankValue 
        /// </summary>
        [IgnoreExportImport]
        public AllowBlank AllowBlankValue { get { return AllowBlank; } }
    }
}
