// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
	/// <summary>
	/// Partial class for ItemLocationDocument
	/// </summary>
	public partial class ItemLocationDocument : ModelBase
	{
		/// <summary>
		/// Gets or sets ItemNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ItemNumber {get; set;}

		/// <summary>
		/// Gets or sets Location
		/// </summary>
		[Key]
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string Location {get; set;}

		/// <summary>
		/// Gets or sets DocumentType
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DocumentType", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
		public DocumentType DocumentType {get; set;}

		/// <summary>
		/// Gets or sets DocumentNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DocumentNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
		public string DocumentNumber {get; set;}

		/// <summary>
		/// Gets or sets DetailLineUniquifier
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DetailLineUniquifier, Id = Index.DetailLineUniquifier, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal DetailLineUniquifier {get; set;}

		/// <summary>
		/// Gets or sets ComponentNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ComponentNumber, Id = Index.ComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long ComponentNumber {get; set;}

		/// <summary>
		/// Gets or sets DocumentSequenceNumber
		/// </summary>
        [ViewField(Name = Fields.DocumentSequenceNumber, Id = Index.DocumentSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DocumentSequenceNumber {get; set;}

		/// <summary>
		/// Gets or sets DocumentDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DocumentDate", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DocumentDate {get; set;}

		/// <summary>
		/// Gets or sets CustomerVendorNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CustVendNumber", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CustomerVendorNumber, Id = Index.CustomerVendorNumber, FieldType = EntityFieldType.Char, Size = 12)]
		public string CustomerVendorNumber {get; set;}

		/// <summary>
		/// Gets or sets CustomerVendorName
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CustomerName", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.CustomerVendorName, Id = Index.CustomerVendorName, FieldType = EntityFieldType.Char, Size = 60)]
		public string CustomerVendorName {get; set;}

		/// <summary>
		/// Gets or sets ExpectedShippingArrivalDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
       [ViewField(Name = Fields.ExpectedShippingArrivalDate, Id = Index.ExpectedShippingArrivalDate, FieldType = EntityFieldType.Date, Size = 5)]
       public DateTime ExpectedShippingArrivalDate {get; set;}

		/// <summary>
		/// Gets or sets DocumentLocation
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DocumentLocation, Id = Index.DocumentLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string DocumentLocation {get; set;}

		/// <summary>
		/// Gets or sets QtyInStockingUnit
		/// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ICCommonResx))]
		[ViewField(Name = Fields.QtyInStockingUnit, Id = Index.QtyInStockingUnit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal QtyInStockingUnit {get; set;}

		#region UI Strings

		/// <summary>
		/// Gets DocumentType string value
		/// </summary>
		public string DocumentTypeString
		{
			get { return EnumUtility.GetStringValue(DocumentType); }
		}
        /// <summary>
        /// Gets or sets InquireFor
        /// </summary>
       [Display(Name = "InquireFor", ResourceType = typeof(ItemLocationDocumentResx))]
        public InquireFor InquireFor { get; set; }

       
        /// <summary>
       /// Gets or sets PoReceiptAccess
       /// </summary>
       public bool PoReceiptButton { get; set; }

      
       /// <summary>
       /// Gets or sets DocumentTypeCount
       /// </summary>
       public int DocumentTypeCount { get; set; }

		#endregion
	}
}
