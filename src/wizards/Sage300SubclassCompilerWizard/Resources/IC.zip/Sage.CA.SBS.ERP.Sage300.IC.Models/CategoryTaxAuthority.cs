/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region NameSpaces
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// A model class for Category Tax Authority in Inventory Control
    /// </summary>
	public partial class CategoryTaxAuthority : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets Category 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(ICCommonResx))]
        [Key]
 		[ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string CategoryCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [Display(Name = "TaxAuthority", ResourceType = typeof(CategoriesResx))]
        [Key]
 		[ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
 		public string TaxAuthority {get; set;}
		 
  		/// <summary>
        /// Gets or sets PurchaseTaxClass 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PurchaseTaxClass", ResourceType = typeof(ICCommonResx))]
 		[ViewField(Name = Fields.PurchaseTaxClass, Id = Index.PurchaseTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
 		public int PurchaseTaxClass {get; set;}
		 
  		/// <summary>
        /// Gets or sets SalesTaxClass 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SalesTaxClass", ResourceType = typeof(ICCommonResx))]
 		[ViewField(Name = Fields.SalesTaxClass, Id = Index.SalesTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
 		public int SalesTaxClass {get; set;}
		 
  		/// <summary>
        /// Gets or sets PurchaseTaxClassDescription 
        /// </summary>
        [Display(Name = "SalesTaxClassDesc", ResourceType = typeof(CategoriesResx))]
 		[ViewField(Name = Fields.PurchaseTaxClassDescription, Id = Index.PurchaseTaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
 		public string PurchaseTaxClassDescription {get; set;}
		 
  		/// <summary>
        /// Gets or sets SalesTaxClassDescription 
        /// </summary>
        [Display(Name = "PurchaseTaxClassDesc", ResourceType = typeof(CategoriesResx))]
 		[ViewField(Name = Fields.SalesTaxClassDescription, Id = Index.SalesTaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
 		public string SalesTaxClassDescription {get; set;}

        /// <summary>
        /// Gets or Sets the Line Number for Add Taxes
        /// </summary>
        public int LineNumber { get; set; }


        /// <summary>
        /// For Grid Display
        /// </summary>
        public long SerialNumber { get; set; }
        
       
		   
    }
}
