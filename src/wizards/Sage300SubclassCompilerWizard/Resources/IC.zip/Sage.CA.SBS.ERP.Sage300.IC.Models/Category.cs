/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region NameSpaces
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    ///  A model class for Category screen in Inventory Control
    /// </summary>
	public partial class Category : ModelBase
	{
        /// <summary>
        /// Initializes a new instance of the <see cref="CategoryTaxAuthority" /> class.
        /// this property holds an enumerable list of category tax details
        /// </summary>
	    public Category()
	    {
	        CategoryTaxAuthDetail = new EnumerableResponse<CategoryTaxAuthority>();
	    }
	 
  		/// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(ICCommonResx))]
        [Key]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CategoryCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "CategoryDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description {get; set;}
		 
  		/// <summary>
        /// Gets or sets CostofGoodsSoldAccount 
        /// </summary>
        [Display(Name = "CostofGoodsSold", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CostofGoodsSoldAccount, Id = Index.CostofGoodsSoldAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CostofGoodsSoldAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets SalesAccount 
        /// </summary>
        [Display(Name = "Sales", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.SalesAccount, Id = Index.SalesAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string SalesAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets ReturnsAccount 
        /// </summary>
        [Display(Name = "Returns", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ReturnsAccount, Id = Index.ReturnsAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ReturnsAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets CostVarianceAccount 
        /// </summary>
        [Display(Name = "CostVariance", ResourceType = typeof(ICCommonResx))]
 		[ViewField(Name = Fields.CostVarianceAccount, Id = Index.CostVarianceAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
 		public string CostVarianceAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets CommissionPaid 
        /// </summary>
        [Display(Name = "CommissionPaid", ResourceType = typeof(CategoriesResx))]
 		[ViewField(Name = Fields.CommissionPaid, Id = Index.CommissionPaid, FieldType = EntityFieldType.Bool, Size = 2)]
 		public CommissionPaid CommissionPaid {get; set;}

        /// <summary>
        /// Sets When the Commission Paid
        /// </summary>
        public bool IsCommissionAllowed { get; set; }
		 
  		/// <summary>
        /// Gets or sets CommissionRate 
        /// </summary>
        [Display(Name = "CommissionRate", ResourceType = typeof(CategoriesResx))]
 		[ViewField(Name = Fields.CommissionRate, Id = Index.CommissionRate, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
 		public decimal CommissionRate {get; set;}
		 
  		/// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ICCommonResx))]
 		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
 		public Status Status {get; set;}

        /// <summary>
        /// Sets Inactive Status
        /// </summary>
        public bool IsInactive { get; set; }
		 
  		/// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
         [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }
		 
  		/// <summary>
        /// Gets or sets DefaultPriceListCode 
        /// </summary>
        [Display(Name = "DefaultPriceList", ResourceType = typeof(ICCommonResx))]
 		[ViewField(Name = Fields.DefaultPriceListCode, Id = Index.DefaultPriceListCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
 		public string DefaultPriceListCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets DateInactive 
        /// </summary>
        [Display(Name = "DateInactive", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateInactive {get; set;}
		 
  		/// <summary>
        /// Gets or sets DamagedGoodsAccount 
        /// </summary>
        /// 
        [Display(Name = "DamageAcc", ResourceType = typeof(ICCommonResx))]
 		[ViewField(Name = Fields.DamagedGoodsAccount, Id = Index.DamagedGoodsAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
 		public string DamagedGoodsAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets InternalUsageAccount 
        /// </summary>
        [Display(Name = "InternalUsage", ResourceType = typeof(ICCommonResx))]
 		[ViewField(Name = Fields.InternalUsageAccount, Id = Index.InternalUsageAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
 		public string InternalUsageAccount {get; set;}

        public EnumerableResponse<CategoryTaxAuthority> CategoryTaxAuthDetail { get; set; }

        /// <summary>
        /// Gets or sets CommissionPaid1 
        /// </summary>
        [IgnoreExportImport]
        public Validate CommissionPaid1 { get; set; }
        /// <summary>
        /// Gets or sets StatusString 
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }
        /// <summary>
        /// Gets or sets CommissionPaidString 
        /// </summary>
        public string CommissionPaidString
        {
            get { return EnumUtility.GetStringValue(CommissionPaid1); }
        }
		 
    }
}
