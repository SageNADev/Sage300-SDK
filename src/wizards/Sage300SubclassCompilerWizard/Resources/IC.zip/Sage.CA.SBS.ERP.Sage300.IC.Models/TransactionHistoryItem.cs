// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
using TransactionTypes = Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.TransactionTypes;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    public partial class TransactionHistoryItem : ModelBase
    {
        /// <summary>
        /// Gets or sets AccountSetCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DayEndNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DayEndNumber, Id = Index.DayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionSequence", ResourceType = typeof(TransactionHistoryInquiryResx))]
        [ViewField(Name = Fields.TransactionSequence, Id = Index.TransactionSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionSequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(TransactionHistoryInquiryResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2)]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ICCommonResx))]
        //[ViewField(Name = Fields.TransactionTypes, Id = Index.TransactionTypes, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionTypes TransactionTypes { get; set; }

        /// <summary>
        /// Gets or sets TransactionTypeString
        /// </summary>
        public string TransactionTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(TransactionTypes);
            }
        }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10w")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceCurrency", ResourceType = typeof(TransactionHistoryInquiryResx))]
        [ViewField(Name = Fields.SourceCurrency, Id = Index.SourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string SourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostSource
        /// </summary>
        [Display(Name = "ExtendedCostSource", ResourceType = typeof(TransactionHistoryInquiryResx))]
        [ViewField(Name = Fields.ExtendedCostSource, Id = Index.ExtendedCostSource, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCostSource { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostFunctional
        /// </summary>
        [Display(Name = "ExtendedCostFunctional", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExtendedCostFunctional, Id = Index.ExtendedCostFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCostFunctional { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostFunctionalDebit
        /// </summary>
        [Display(Name = "ColtitleDebit", ResourceType = typeof(TransactionHistoryInquiryResx))]
        public decimal? ExtendedCostFunctionalDebit { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCostFunctionalCredit
        /// </summary>
        [Display(Name = "ColtitleCredit", ResourceType = typeof(TransactionHistoryInquiryResx))]
        public decimal? ExtendedCostFunctionalCredit { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType
        /// </summary>
        [Display(Name = "DrillDownType", ResourceType = typeof(TransactionHistoryInquiryResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber
        /// </summary>
        [Display(Name = "DrillDownLinkNumber", ResourceType = typeof(TransactionHistoryInquiryResx))]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplicationSource
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string DrillDownApplicationSource { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets DetailComponentNumber
        /// </summary>
        [ViewField(Name = Fields.DetailComponentNumber, Id = Index.DetailComponentNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DetailComponentNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets FormattedItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string FormattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets YearPeriod
        /// </summary>
        public string YearPeriod
        {
            get
            {
                return FiscalYear + "/" + FiscalPeriod;
            }
        }

        // It is required to display the Decimal values
        /// <summary>
        /// Gets or Sets the Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string CurrencyDecimal { get; set; }

        // It is required to display the Decimal values
        /// <summary>
        /// Gets or Sets the FunctionalCurrency
        /// </summary>
        [IgnoreExportImport]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Checks AllowFunctionalQuantities in IC Options
        /// </summary>
        [IgnoreExportImport]
        public bool AllowFractionalQuantities { get; set; }

        /// <summary>
        /// Gets or sets FractionalQuantities - OE Options Fractional Quantities
        /// </summary>
        [IgnoreExportImport]
        public int FractionalQuantityDecimals { get; set; }
    }
}
