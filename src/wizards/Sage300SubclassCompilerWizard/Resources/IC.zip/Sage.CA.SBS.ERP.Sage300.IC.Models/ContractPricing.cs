// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
using CostingMethod = Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Finder.CostingMethod;
using PriceBy = Sage.CA.SBS.ERP.Sage300.IC.Models.Enums.Finder.PriceBy;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Contract Pricing
    /// </summary>
    public partial class ContractPricing : ModelBase
    {

        /// <summary>
        /// Gets or sets Customer Number
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Price By
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceBy", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PriceBy, Id = Index.PriceBy, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceBy PriceBy { get; set; }

        /// <summary>
        /// Gets or sets Category Code
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets Item Number
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Price List
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceList", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PriceList, Id = Index.PriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string PriceList { get; set; }

        /// <summary>
        /// Gets or sets Expiration Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpirationDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets PriceType
        /// </summary>
        [Display(Name = "ContractPriceType", ResourceType = typeof(ContractPricingResx))]
        [ViewField(Name = Fields.PriceType, Id = Index.PriceType, FieldType = EntityFieldType.Int, Size = 2)]
        public PriceType PriceType { get; set; }

        /// <summary>
        /// Gets or sets CustomerType
        /// </summary>
        [Display(Name = "CustomerType", ResourceType = typeof(ContractPricingResx))]
        [ViewField(Name = Fields.CustomerType, Id = Index.CustomerType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerType CustomerType { get; set; }

        /// <summary>
        /// Gets or sets Discount Percentage
        /// </summary>
        [Display(Name = "DiscountPercentage", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets Discount Amount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets CostingMethod
        /// </summary>
        [Display(Name = "CostBase", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CostingMethod, Id = Index.CostingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public CostingMethod CostingMethod { get; set; }

        /// <summary>
        /// Gets or sets PlusAmount
        /// </summary>
        [Display(Name = "PlusAmount", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PlusAmount, Id = Index.PlusAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal PlusAmount { get; set; }

        /// <summary>
        /// Gets or sets PlusPercentage
        /// </summary>
        [Display(Name = "PlusPercentage", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PlusPercentage, Id = Index.PlusPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PlusPercentage { get; set; }

        /// <summary>
        /// Gets or sets FixedPrice
        /// </summary>
        [Display(Name = "FixedPrice", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FixedPrice, Id = Index.FixedPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal FixedPrice { get; set; }

        /// <summary>
        /// Gets or sets Start Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets UseLowestPrice
        /// </summary>
        [Display(Name = "UseLowestPrice", ResourceType = typeof(ContractPricingResx))]
        [ViewField(Name = Fields.UseLowestPrice, Id = Index.UseLowestPrice, FieldType = EntityFieldType.Bool, Size = 2)]
        public UseLowestPrice UseLowestPrice { get; set; }

        /// <summary>
        /// Gets or sets Calculated Unit Price
        /// </summary>
        [Display(Name = "CalcUnitPrice", ResourceType = typeof(ContractPricingResx))]
        [ViewField(Name = Fields.CalculatedUnitPrice, Id = Index.CalculatedUnitPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal CalculatedUnitPrice { get; set; }

        /// <summary>
        /// Gets or sets Calculated Price Decimals
        /// </summary>
        [ViewField(Name = Fields.CalculatedPriceDecimals, Id = Index.CalculatedPriceDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int CalculatedPriceDecimals { get; set; }

        /// <summary>
        /// Gets or sets Formatted Item Number
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string FormattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Customer Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets Category Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        /// <summary>
        /// Gets or sets Item Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets Price List Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PriceListDescription", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PriceListDescription, Id = Index.PriceListDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string PriceListDescription { get; set; }

        /// <summary>
        /// Gets or sets Currency Code
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets Price Unit Description
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PricingUnit", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.PriceUnitDescription, Id = Index.PriceUnitDescription, FieldType = EntityFieldType.Char, Size = 10)]
        public string PriceUnitDescription { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets Calculated Unit Price Is Valid
        /// </summary>
        [Display(Name = "CalculatedUnitPriceIsValid", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.CalculatedUnitPriceIsValid, Id = Index.CalculatedUnitPriceIsValid, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CalculatedUnitPriceIsValid { get; set; }

        /// <summary>
        /// Gets or sets Pricing Price By
        /// </summary>
        [ViewField(Name = Fields.PricingPriceBy, Id = Index.PricingPriceBy, FieldType = EntityFieldType.Int, Size = 2)]
        public PricingPriceBy PricingPriceBy { get; set; }

        /// <summary>
        /// Gets or sets Check Item Existence
        /// </summary>
        [ViewField(Name = Fields.CheckItemExistence, Id = Index.CheckItemExistence, FieldType = EntityFieldType.Bool, Size = 2)]
        public CheckItemExistence CheckItemExistence { get; set; }

        /// <summary>
        /// To get the string of Use Lowest Price property
        /// </summary>
        [Display(Name = "UseLowestPrice", ResourceType = typeof(ContractPricingResx))]
        public string UseLowestPriceString
        {
            get { return EnumUtility.GetStringValue(UseLowestPrice); }
        }

        /// <summary>
        /// To get the string of Price By property
        /// </summary>
        [Display(Name = "PriceBy", ResourceType = typeof(ICCommonResx))]
        public string PriceByString
        {
            get { return EnumUtility.GetStringValue(PriceBy); }
        }

        /// <summary>
        /// To get the string of Price Type property
        /// </summary>
        [Display(Name = "PriceType", ResourceType = typeof(ICCommonResx))]
        public string PriceTypeString
        {

            get { return EnumUtility.GetStringValue(PriceType); }
           
        }


        /// <summary>
        /// To get the string of Check Item Existence property
        /// </summary>
        public string CheckItemExistenceString
        {
            get
            {

                return EnumUtility.GetStringValue(CheckItemExistence);
            }
        }

        /// <summary>
        /// To get the string of Costing Method property
        /// </summary>
        [Display(Name = "CostingMethod", ResourceType = typeof(ICCommonResx))]
        public string CostingMethodString
        {
            get { return EnumUtility.GetStringValue(CostingMethod); }
        }

        /// <summary>
        /// To get the string of Pricing Price By property
        /// </summary>
        public string PricingPriceByString
        {
            get { return EnumUtility.GetStringValue(PricingPriceBy); }
        }

        /// <summary>
        /// To get the string of Pricing Price By property
        /// </summary>
        public string CustomerTypeString
        {
            get { return EnumUtility.GetStringValue(CustomerType); }
        }

        /// <summary>
        /// Gets Calculated Unit Price Is Valid String
        /// </summary>
        public string CalculatedUnitPriceIsValidString
        {
            get
            {
                if (CalculatedUnitPriceIsValid)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);
            }
        }

        #region Presentation List

        /// <summary>
        /// Gets or sets the price type list.
        /// </summary>
        /// <value>
        /// The price type list.
        /// </value>
        public List<Dictionary<string, object>> PriceTypeList { get; set; }

        /// <summary>
        /// Gets or sets the customer type list.
        /// </summary>
        /// <value>
        /// The customer type list.
        /// </value>
        public List<Dictionary<string, object>> CustomerTypeList { get; set; }

        /// <summary>
        /// Gets or sets the costing base list.
        /// </summary>
        /// <value>
        /// The costing base list.
        /// </value>
        public List<Dictionary<string, object>> CostingBaseList { get; set; }
        #endregion
    }
}
