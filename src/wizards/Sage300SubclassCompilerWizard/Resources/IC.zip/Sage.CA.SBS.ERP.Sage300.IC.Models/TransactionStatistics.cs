/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources;
using Sage.CA.SBS.ERP.Sage300.IC.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.IC.Models
{
    /// <summary>
    /// Model for Transaction Statistics
    /// </summary>
    public partial class TransactionStatistics : ModelBase
    {
        /// <summary>
        /// Gets or sets Year 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Year", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public int Year { get; set; }

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Period", ResourceType = typeof(ICCommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Int, Size = 2)]
        public int Period { get; set; }

        /// <summary>
        /// Gets or sets NumberofReceipts 
        /// </summary>
        [Display(Name = "NumberofReceipts", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofReceipts, Id = Index.NumberofReceipts, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofReceipts { get; set; }

        /// <summary>
        /// Gets or sets CostofReceipts 
        /// </summary>
        [Display(Name = "CostofReceipts", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.CostofReceipts, Id = Index.CostofReceipts, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofReceipts { get; set; }

        /// <summary>
        /// Gets or sets NumberofReceiptAdjustments 
        /// </summary>
        [Display(Name = "NumberofReceiptAdjustments", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofReceiptAdjustments, Id = Index.NumberofReceiptAdjustments, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofReceiptAdjustments { get; set; }

        /// <summary>
        /// Gets or sets CostofReceiptAdjustments 
        /// </summary>
        [Display(Name = "CostofReceiptAdjustments", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.CostofReceiptAdjustments, Id = Index.CostofReceiptAdjustments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofReceiptAdjustments { get; set; }

        /// <summary>
        /// Gets or sets NumberofReceiptReturns 
        /// </summary>
        [Display(Name = "NumberofReceiptReturns", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofReceiptReturns, Id = Index.NumberofReceiptReturns, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofReceiptReturns { get; set; }

        /// <summary>
        /// Gets or sets CostofReceiptReturns 
        /// </summary>
        [Display(Name = "CostofReceiptReturns", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.CostofReceiptReturns, Id = Index.CostofReceiptReturns, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofReceiptReturns { get; set; }

        /// <summary>
        /// Gets or sets NumberofShipments 
        /// </summary>
        [Display(Name = "NumberofShipments", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofShipments, Id = Index.NumberofShipments, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofShipments { get; set; }

        /// <summary>
        /// Gets or sets CostofShipments 
        /// </summary>
        [Display(Name = "CostofShipments", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.CostofShipments, Id = Index.CostofShipments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofShipments { get; set; }

        /// <summary>
        /// Gets or sets PriceofShipments 
        /// </summary>
        [Display(Name = "PriceofShipments", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.PriceofShipments, Id = Index.PriceofShipments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PriceofShipments { get; set; }

        /// <summary>
        /// Gets or sets NumberofShipmentReturns 
        /// </summary>
        [Display(Name = "NumberofShipmentReturns", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofShipmentReturns, Id = Index.NumberofShipmentReturns, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofShipmentReturns { get; set; }

        /// <summary>
        /// Gets or sets CostofShipmentReturns 
        /// </summary>
        [Display(Name = "CostofShipmentReturns", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.CostofShipmentReturns, Id = Index.CostofShipmentReturns, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofShipmentReturns { get; set; }

        /// <summary>
        /// Gets or sets PriceofShipmentReturns 
        /// </summary>
        [Display(Name = "PriceofShipmentReturns", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.PriceofShipmentReturns, Id = Index.PriceofShipmentReturns, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PriceofShipmentReturns { get; set; }

        /// <summary>
        /// Gets or sets NumberofAdjustments 
        /// </summary>
        [Display(Name = "NumberofAdjustments", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofAdjustments, Id = Index.NumberofAdjustments, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofAdjustments { get; set; }

        /// <summary>
        /// Gets or sets CostofAdjustments 
        /// </summary>
        [Display(Name = "CostofAdjustments", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.CostofAdjustments, Id = Index.CostofAdjustments, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofAdjustments { get; set; }

        /// <summary>
        /// Gets or sets NumberofTransfers 
        /// </summary>
        [Display(Name = "NumberofTransfers", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofTransfers, Id = Index.NumberofTransfers, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofTransfers { get; set; }

        /// <summary>
        /// Gets or sets NumberofInternalUsages 
        /// </summary>
        [Display(Name = "NumberofInternalUsages", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.NumberofInternalUsages, Id = Index.NumberofInternalUsages, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofInternalUsages { get; set; }

        /// <summary>
        /// Gets or sets CostofInternalUsages 
        /// </summary>
        [Display(Name = "CostofInternalUsages", ResourceType = typeof(TransactionStatisticsResx))]
        [ViewField(Name = Fields.CostofInternalUsages, Id = Index.CostofInternalUsages, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofInternalUsages { get; set; }

        /// <summary>
        /// Gets or sets Options
        /// </summary>
        [IgnoreExportImport]
        public Options Options { get; set; }
    }
}
