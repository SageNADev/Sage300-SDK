// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models
{
    /// <summary>
    /// Contains list of NotesSearch Constants
    /// </summary>
    public partial class NotesSearch
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "KN0088";


        #region Properties

        /// <summary>
        /// Contains list of NotesSearch Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for NotesSearchType
            /// </summary>
            public const string NotesSearchType = "TYPE";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for Searchingtags
            /// </summary>
            public const string Searchingtags = "TAGS";

            /// <summary>
            /// Property for NoteID
            /// </summary>
            public const string NoteID = "NOTEUNIQ";

            /// <summary>
            /// Property for EntityID
            /// </summary>
            public const string EntityID = "ENTITYID";

            /// <summary>
            /// Property for PageNumber
            /// </summary>
            public const string PageNumber = "PAGENO";

            /// <summary>
            /// Property for NumberOfrecordsTofetch
            /// </summary>
            public const string NumberOfrecordsTofetch = "PAGESIZE";

            /// <summary>
            /// Property for Cannotbedismissed
            /// </summary>
            public const string Cannotbedismissed = "NODISMISS";

            /// <summary>
            /// Property for NotesPreviewText
            /// </summary>
            public const string NotesPreviewText = "PREVIEW";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of NotesSearch Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for NotesSearchType
            /// </summary>
            public const int NotesSearchType = 1;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 2;

            /// <summary>
            /// Property Indexer for Searchingtags
            /// </summary>
            public const int Searchingtags = 3;

            /// <summary>
            /// Property Indexer for NoteID
            /// </summary>
            public const int NoteID = 4;

            /// <summary>
            /// Property Indexer for EntityID
            /// </summary>
            public const int EntityID = 5;

            /// <summary>
            /// Property Indexer for PageNumber
            /// </summary>
            public const int PageNumber = 6;

            /// <summary>
            /// Property Indexer for NumberOfrecordsTofetch
            /// </summary>
            public const int NumberOfrecordsTofetch = 7;

            /// <summary>
            /// Property Indexer for Cannotbedismissed
            /// </summary>
            public const int Cannotbedismissed = 8;

            /// <summary>
            /// Property Indexer for NotesPreviewText
            /// </summary>
            public const int NotesPreviewText = 9;
        }

        #endregion

    }
}