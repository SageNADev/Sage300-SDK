﻿// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models
{
    /// <summary>
    /// Contains list of NoteDetail Constants
    /// </summary>
    public partial class NoteBlob
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "KN0030";

        public const int Blobdatasize = 3800;

        #region Properties

        /// <summary>
        /// Contains list of NoteDetail Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for NoteUniquifiedKey
            /// </summary>
            public const string NoteUniquifiedKey = "NOTEUNIQ";

            /// <summary>
            /// Property for PartNumber
            /// </summary>
            public const string PartNumber = "PARTNUM";

            /// <summary>
            /// Property for BlobData
            /// </summary>
            public const string BlobData = "BLOBDAT";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of NoteDetail Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for NoteUniquifiedKey
            /// </summary>
            public const int NoteUniquifiedKey = 1;

            /// <summary>
            /// Property Indexer for PartNumber
            /// </summary>
            public const int PartNumber = 2;

            /// <summary>
            /// Property Indexer for BlobData
            /// </summary>
            public const int BlobData = 3;


        }

        #endregion

    }
}