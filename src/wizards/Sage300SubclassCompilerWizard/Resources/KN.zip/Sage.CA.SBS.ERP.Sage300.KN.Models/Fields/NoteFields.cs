// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models
{
    /// <summary>
    /// Contains list of Note Constants
    /// </summary>
    public partial class Note
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "KN0010";


        #region Properties

        /// <summary>
        /// Contains list of Note Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for NoteID
            /// </summary>
            public const string NoteID = "NOTEUNIQ";

            /// <summary>
            /// Property for NoteType
            /// </summary>
            public const string NoteType = "NOTETYPE";

            /// <summary>
            /// Property for EntityID
            /// </summary>
            public const string EntityID = "ENTITYID";

            /// <summary>
            /// Property for CreationDate
            /// </summary>
            public const string CreationDate = "CREATEDATE";

            /// <summary>
            /// Property for CreatedBy
            /// </summary>
            public const string CreatedBy = "CREATEDBY";

            /// <summary>
            /// Property for LastMaintainedDate
            /// </summary>
            public const string LastMaintainedDate = "LASTMNDATE";

            /// <summary>
            /// Property for LastMaintainedBy
            /// </summary>
            public const string LastMaintainedBy = "LASTMNBY";

            /// <summary>
            /// Property for NoteStartDate
            /// </summary>
            public const string NoteStartDate = "NOTESTART";

            /// <summary>
            /// Property for NoteEndDate
            /// </summary>
            public const string NoteEndDate = "NOTEEND";

            /// <summary>
            /// Property for PreviewContent
            /// </summary>
            public const string PreviewContent = "PREVIEW";

            /// <summary>
            /// Property for Tags
            /// </summary>
            public const string Tags = "TAGS";

            /// <summary>
            /// Property for NoteImportance
            /// </summary>
            public const string NoteImportance = "IMPORTANCE";

            /// <summary>
            /// Property for SizeOfthetotalnotedata
            /// </summary>
            public const string SizeOfthetotalnotedata = "DATASIZE";

            /// <summary>
            /// Property for NumberOfrowsusedInKNNTBLOB
            /// </summary>
            public const string NumberOfrowsusedInKNNTBLOB = "NUMOFPARTS";

            /// <summary>
            /// Property for ActiveonSpecificDates
            /// </summary>
            public const string ActiveonSpecificDates = "DATERANGE";

            /// <summary>
            /// Property for CannotbeDismissed
            /// </summary>
            public const string CannotbeDismissed = "NODISMISS";

            /// <summary>
            /// Property for ProcessCommand
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of Note Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for NoteID
            /// </summary>
            public const int NoteID = 1;

            /// <summary>
            /// Property Indexer for NoteType
            /// </summary>
            public const int NoteType = 2;

            /// <summary>
            /// Property Indexer for EntityID
            /// </summary>
            public const int EntityID = 3;

            /// <summary>
            /// Property Indexer for CreationDate
            /// </summary>
            public const int CreationDate = 4;

            /// <summary>
            /// Property Indexer for CreatedBy
            /// </summary>
            public const int CreatedBy = 5;

            /// <summary>
            /// Property Indexer for LastMaintainedDate
            /// </summary>
            public const int LastMaintainedDate = 6;

            /// <summary>
            /// Property Indexer for LastMaintainedBy
            /// </summary>
            public const int LastMaintainedBy = 7;

            /// <summary>
            /// Property Indexer for NoteStartDate
            /// </summary>
            public const int NoteStartDate = 8;

            /// <summary>
            /// Property Indexer for NoteEndDate
            /// </summary>
            public const int NoteEndDate = 9;

            /// <summary>
            /// Property Indexer for PreviewContent
            /// </summary>
            public const int PreviewContent = 10;

            /// <summary>
            /// Property Indexer for Tags
            /// </summary>
            public const int Tags = 11;

            /// <summary>
            /// Property Indexer for NoteImportance
            /// </summary>
            public const int NoteImportance = 12;

            /// <summary>
            /// Property Indexer for SizeOfthetotalnotedata
            /// </summary>
            public const int SizeOfthetotalnotedata = 13;

            /// <summary>
            /// Property Indexer for NumberOfrowsusedInKNNTBLOB
            /// </summary>
            public const int NumberOfrowsusedInKNNTBLOB = 14;

            /// <summary>
            /// Property Indexer for ActiveonSpecificDates
            /// </summary>
            public const int ActiveonSpecificDates = 15;

            /// <summary>
            /// Property Indexer for CannotbeDismissed
            /// </summary>
            public const int CannotbeDismissed = 16;

            /// <summary>
            /// Property Indexer for ProcessCommand
            /// </summary>
            public const int ProcessCommand = 40;


        }

        #endregion

    }
}