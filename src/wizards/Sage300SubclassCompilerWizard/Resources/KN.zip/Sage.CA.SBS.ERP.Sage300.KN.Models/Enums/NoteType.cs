// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.KN.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models.Enums
{
    /// <summary>
    /// Enum for NoteType
    /// </summary>
    public enum NoteType
    {
        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [EnumValue("Customer", typeof(NoteResx))]
        Customer = 1,

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [EnumValue("Vendor", typeof(NoteResx))]
        Vendor = 2,

        /// <summary>
        /// Gets or sets InventoryItem
        /// </summary>
        [EnumValue("InventoryItem", typeof(NoteResx))]
        InventoryItem = 3

    }
}