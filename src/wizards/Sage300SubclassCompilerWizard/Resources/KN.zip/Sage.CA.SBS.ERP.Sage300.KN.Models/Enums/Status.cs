// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.KN.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("Active", typeof(NotesSearchResx))]
        Active = 1,

        /// <summary>
        /// Gets or sets Expired
        /// </summary>
        [EnumValue("Expired", typeof(NotesSearchResx))]
        Expired = 2,

        /// <summary>
        /// Gets or sets Future
        /// </summary>
        [EnumValue("Future", typeof(NotesSearchResx))]
        Future = 3,

        /// <summary>
        /// Gets or sets Dismissed
        /// </summary>
        [EnumValue("Dismissed", typeof(NotesSearchResx))]
        Dismissed = 4

    }
}