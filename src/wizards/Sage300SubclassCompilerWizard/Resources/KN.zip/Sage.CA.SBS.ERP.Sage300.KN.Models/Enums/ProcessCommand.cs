// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.KN.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand
    /// </summary>
    public enum ProcessCommand
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("None", typeof(NoteResx))]
        None = 0,

        /// <summary>
        /// Gets or sets Dismiss
        /// </summary>
        [EnumValue("Dismiss", typeof(NoteResx))]
        Dismiss = 1,

        /// <summary>
        /// Gets or sets Undismiss
        /// </summary>
        [EnumValue("Undismiss", typeof(NoteResx))]
        Undismiss = 2

    }
}