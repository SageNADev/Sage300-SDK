// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.KN.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models.Enums
{
    /// <summary>
    /// Enum for NotesSearchType
    /// </summary>
    public enum NotesSearchType
    {
        /// <summary>
        /// Gets or sets All
        /// </summary>
        [EnumValue("All", typeof(NotesSearchResx))]
        All = 0,

        /// <summary>
        /// Gets or sets Customers
        /// </summary>
        [EnumValue("Customers", typeof(NotesSearchResx))]
        Customers = 1,

        /// <summary>
        /// Gets or sets Vendors
        /// </summary>
        [EnumValue("Vendors", typeof(NotesSearchResx))]
        Vendors = 2,

        /// <summary>
        /// Gets or sets InventoryItems
        /// </summary>
        [EnumValue("InventoryItems", typeof(NotesSearchResx))]
        InventoryItems = 3

    }
}