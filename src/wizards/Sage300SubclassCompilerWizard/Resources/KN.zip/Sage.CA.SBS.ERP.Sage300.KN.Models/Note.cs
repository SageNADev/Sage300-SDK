// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.KN.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.KN.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models
{
    /// <summary>
    /// Partial class for Note
    /// </summary>
    public partial class Note : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public Note()
        {
            int defaultFromToDayRange = 30;
            NoteType = NoteType.Customer;
            ActiveonSpecificDates = false;
            NoteStartDate = DateTime.Now;
            NoteEndDate = NoteStartDate.AddDays(defaultFromToDayRange);
            CannotbeDismissed = true;
            NoteBody = String.Empty;
            NoteTypeList = EnumUtility.GetItemsList<NoteType>();
        }

        /// <summary>
        /// Gets or sets NoteID
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NoteID", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.NoteID, Id = Index.NoteID, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NoteID { get; set; }

        /// <summary>
        /// Gets or sets NoteType
        /// </summary>
        [Display(Name = "NoteType", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.NoteType, Id = Index.NoteType, FieldType = EntityFieldType.Int, Size = 2)]
        public NoteType NoteType { get; set; }

        /// <summary>
        /// Gets or sets EntityID
        /// </summary>
        // NOTE: As a workaround for the problem where the session date in the portal can't
        //       be changed if the Note Editor happens to be hidden (but has a blank EntityID)
        //       we will undo the "Required" attribute (as updating the portal's session date
        //       will attempt to validate the whole portal "form", which includes what's
        //       inside the Note Editor (even if it's hidden).
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntityID", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.EntityID, Id = Index.EntityID, FieldType = EntityFieldType.Char, Size = 50, Mask = "%-12C")]
        public string EntityID { get; set; }

        /// <summary>
        /// Gets or sets CreationDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreationDate", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.CreationDate, Id = Index.CreationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CreationDate { get; set; }

        /// <summary>
        /// Gets or sets CreatedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedBy", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.CreatedBy, Id = Index.CreatedBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string CreatedBy { get; set; }

        /// <summary>
        /// Gets or sets LastMaintainedDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintainedDate", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.LastMaintainedDate, Id = Index.LastMaintainedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintainedDate { get; set; }

        /// <summary>
        /// Gets or sets LastMaintainedBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintainedBy", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.LastMaintainedBy, Id = Index.LastMaintainedBy, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string LastMaintainedBy { get; set; }

        /// <summary>
        /// Gets or sets NoteStartDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NoteStartDate", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.NoteStartDate, Id = Index.NoteStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime NoteStartDate { get; set; }

        /// <summary>
        /// Gets or sets NoteEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NoteEndDate", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.NoteEndDate, Id = Index.NoteEndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime NoteEndDate { get; set; }

        /// <summary>
        /// Gets or sets PreviewContent
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreviewContent", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.PreviewContent, Id = Index.PreviewContent, FieldType = EntityFieldType.Char, Size = 250)]
        public string PreviewContent { get; set; }

        /// <summary>
        /// Gets or sets NoteImportance
        /// </summary>
        //[Display(Name = "NoteImportance", ResourceType = typeof (NoteResx))]
        //[ViewField(Name = Fields.NoteImportance, Id = Index.NoteImportance, FieldType = EntityFieldType.Int, Size = 2)]
        //public int NoteImportance { get; set; }

        /// <summary>
        /// Gets or sets SizeOfthetotalnotedata
        /// </summary>
        [Display(Name = "SizeOfthetotalnotedata", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.SizeOfthetotalnotedata, Id = Index.SizeOfthetotalnotedata, FieldType = EntityFieldType.Long, Size = 4)]
        public int SizeOfthetotalnotedata { get; set; }

        /// <summary>
        /// Gets or sets NumberOfrowsusedInKNNTBLOB
        /// </summary>
        [Display(Name = "NumberOfrowsusedInKNNTBLOB", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.NumberOfrowsusedInKNNTBLOB, Id = Index.NumberOfrowsusedInKNNTBLOB, FieldType = EntityFieldType.Long, Size = 4)]
        public int NumberOfrowsusedInKNNTBLOB { get; set; }

        /// <summary>
        /// Gets or sets ActiveonSpecificDates
        /// </summary>
        [Display(Name = "ActiveonSpecificDates", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.ActiveonSpecificDates, Id = Index.ActiveonSpecificDates, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool ActiveonSpecificDates { get; set; }

        /// <summary>
        /// Gets or sets CannotbeDismissed
        /// </summary>
        [Display(Name = "CannotbeDismissed", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.CannotbeDismissed, Id = Index.CannotbeDismissed, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CannotbeDismissed { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof (NoteResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets NoteBody
        /// </summary>
        [Required(ErrorMessageResourceType = typeof(NoteResx), ErrorMessageResourceName = "EmptyNoteBodyError")]
        [Display(Name = "NoteBody", ResourceType = typeof(NoteResx))]
        [StringLength(38000, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string NoteBody { get; set; }

        /// <summary>
        /// Gets or sets NoteEndDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NoteSessionDate", ResourceType = typeof(NoteResx))]
        public DateTime NoteSessionDate { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets NoteType string value
        /// </summary>
        public string NoteTypeString
        {
         get { return EnumUtility.GetStringValue(NoteType); }
        }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        public string ProcessCommandString
        {
         get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        #endregion

        #region Dynamic Presentation Lists

        /// <summary>
        /// Gets Note Type presentation list (which depends on which applications are activated
        /// and installed)
        /// </summary>
        [Display(Name = "NoteType", ResourceType = typeof(NoteResx))]
        public IEnumerable<CustomSelectList> NoteTypeList { get; set; }

        #endregion
    }
}
