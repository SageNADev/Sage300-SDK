// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.KN.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.KN.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.KN.Models
{
    /// <summary>
    /// Partial class for NotesSearch
    /// </summary>
    public partial class NotesSearch : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public NotesSearch()
        {
            NotesSearchType = Enums.NotesSearchType.All;
            Status = Enums.Status.Active;
            NotesSearchTypeList = EnumUtility.GetItemsList<NotesSearchType>();
        }

        /// <summary>
        /// Gets or sets NotesSearchType
        /// </summary>
        [Display(Name = "NotesSearchType", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.NotesSearchType, Id = Index.NotesSearchType, FieldType = EntityFieldType.Int, Size = 2)]
        public NotesSearchType NotesSearchType { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets NoteID
        /// </summary>
        [Display(Name = "NoteID", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.NoteID, Id = Index.NoteID, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NoteID { get; set; }

        /// <summary>
        /// Gets or sets EntityID
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntityID", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.EntityID, Id = Index.EntityID, FieldType = EntityFieldType.Char, Size = 50, Mask = "%-12C")]
        public string EntityID { get; set; }

        /// <summary>
        /// Gets or sets PageNumber
        /// </summary>
        [Display(Name = "PageNumber", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.PageNumber, Id = Index.PageNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int PageNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberOfrecordsTofetch
        /// </summary>
        [Display(Name = "NumberOfrecordsTofetch", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.NumberOfrecordsTofetch, Id = Index.NumberOfrecordsTofetch, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfrecordsTofetch { get; set; }

        /// <summary>
        /// Gets or sets Cannotbedismissed
        /// </summary>
        [Display(Name = "Cannotbedismissed", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.Cannotbedismissed, Id = Index.Cannotbedismissed, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Cannotbedismissed { get; set; }

        /// <summary>
        /// Gets or sets NotesPreviewText
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NotesPreviewText", ResourceType = typeof (NotesSearchResx))]
        [ViewField(Name = Fields.NotesPreviewText, Id = Index.NotesPreviewText, FieldType = EntityFieldType.Char, Size = 250)]
        public string NotesPreviewText { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets NotesSearchType string value
        /// </summary>
        public string NotesSearchTypeString
        {
         get { return EnumUtility.GetStringValue(NotesSearchType); }
        }

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
         get { return EnumUtility.GetStringValue(Status); }
        }

        #endregion

        #region Dynamic Presentation Lists

        /// <summary>
        /// Gets Notes Search Type presentation list (which depends on which applications are
        /// activated and installed)
        /// </summary>
        [Display(Name = "NotesSearchType", ResourceType = typeof(NotesSearchResx))]
        public IEnumerable<CustomSelectList> NotesSearchTypeList { get; set; }

        #endregion
    }
}
