// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for CustomerBalance
    /// </summary>
    public partial class CustomerBalance : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets CheckCustomerCreditLimit
        /// </summary>
        [ViewField(Name = Fields.CheckCustomerCreditLimit, Id = Index.CheckCustomerCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckCustomerCreditLimit CheckCustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerCreditLimit
        /// </summary>
        [ViewField(Name = Fields.CustomerCreditLimit, Id = Index.CustomerCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalance
        /// </summary>
        public decimal CustomerBalanceVal { get; set; }

        /// <summary>
        /// Gets or sets CalcCustomerOverdue
        /// </summary>
        [ViewField(Name = Fields.CalcCustomerOverdue, Id = Index.CalcCustomerOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public CalcCustomerOverdue CalcCustomerOverdue { get; set; }

        /// <summary>
        /// Gets or sets CustomerDaysOverdue
        /// </summary>
        [ViewField(Name = Fields.CustomerDaysOverdue, Id = Index.CustomerDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets CustomerAmountOverdue
        /// </summary>
        [ViewField(Name = Fields.CustomerAmountOverdue, Id = Index.CustomerAmountOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerAmountOverdue { get; set; }

        /// <summary>
        /// Gets or sets CustomerBalanceOverdue
        /// </summary>
        [ViewField(Name = Fields.CustomerBalanceOverdue, Id = Index.CustomerBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NationalAccountName, Id = Index.NationalAccountName, FieldType = EntityFieldType.Char, Size = 60)]
        public string NationalAccountName { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NationalAccountCurrency, Id = Index.NationalAccountCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string NationalAccountCurrency { get; set; }

        /// <summary>
        /// Gets or sets CheckNatAcctCreditLimit
        /// </summary>
        [ViewField(Name = Fields.CheckNatAcctCreditLimit, Id = Index.CheckNatAcctCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckNatAcctCreditLimit CheckNatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NatAcctCreditLimit
        /// </summary>
        [ViewField(Name = Fields.NatAcctCreditLimit, Id = Index.NatAcctCreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountBalance
        /// </summary>
        [ViewField(Name = Fields.NationalAccountBalance, Id = Index.NationalAccountBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NationalAccountBalance { get; set; }

        /// <summary>
        /// Gets or sets CalcNatAcctOverdue
        /// </summary>
        [ViewField(Name = Fields.CalcNatAcctOverdue, Id = Index.CalcNatAcctOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public CalcNatAcctOverdue CalcNatAcctOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctDaysOverdue
        /// </summary>
        [ViewField(Name = Fields.NatAcctDaysOverdue, Id = Index.NatAcctDaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int NatAcctDaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctAmountOverdue
        /// </summary>
        [ViewField(Name = Fields.NatAcctAmountOverdue, Id = Index.NatAcctAmountOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctAmountOverdue { get; set; }

        /// <summary>
        /// Gets or sets NatAcctBalanceOverdue
        /// </summary>
        [ViewField(Name = Fields.NatAcctBalanceOverdue, Id = Index.NatAcctBalanceOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctBalanceOverdue { get; set; }

        /// <summary>
        /// Gets or sets IncludePendingARTrans
        /// </summary>
        [ViewField(Name = Fields.IncludePendingARTrans, Id = Index.IncludePendingARTrans, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePendingARTrans IncludePendingARTrans { get; set; }

        /// <summary>
        /// Gets or sets IncludePendingOETrans
        /// </summary>
        [ViewField(Name = Fields.IncludePendingOETrans, Id = Index.IncludePendingOETrans, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePendingOETrans IncludePendingOETrans { get; set; }

        /// <summary>
        /// Gets or sets IncludePendingOtherTrans
        /// </summary>
        [ViewField(Name = Fields.IncludePendingOtherTrans, Id = Index.IncludePendingOtherTrans, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePendingOtherTrans IncludePendingOtherTrans { get; set; }

        /// <summary>
        /// Gets or sets PendingARAmount
        /// </summary>
        [ViewField(Name = Fields.PendingARAmount, Id = Index.PendingARAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingARAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingOEAmount
        /// </summary>
        [ViewField(Name = Fields.PendingOEAmount, Id = Index.PendingOEAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingOEAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingOtherAmount
        /// </summary>
        [ViewField(Name = Fields.PendingOtherAmount, Id = Index.PendingOtherAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingOtherAmount { get; set; }

        /// <summary>
        /// Gets or sets CustomerOutstanding
        /// </summary>
        [ViewField(Name = Fields.CustomerOutstanding, Id = Index.CustomerOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerOutstanding { get; set; }

        /// <summary>
        /// Gets or sets NatAcctOutstanding
        /// </summary>
        [ViewField(Name = Fields.NatAcctOutstanding, Id = Index.NatAcctOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctOutstanding { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitLeft
        /// </summary>
        [ViewField(Name = Fields.CustomerLimitLeft, Id = Index.CustomerLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitLeft
        /// </summary>
        [ViewField(Name = Fields.NatAcctLimitLeft, Id = Index.NatAcctLimitLeft, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitLeft { get; set; }

        /// <summary>
        /// Gets or sets CustomerLimitExceeded
        /// </summary>
        [ViewField(Name = Fields.CustomerLimitExceeded, Id = Index.CustomerLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets NatAcctLimitExceeded
        /// </summary>
        [ViewField(Name = Fields.NatAcctLimitExceeded, Id = Index.NatAcctLimitExceeded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NatAcctLimitExceeded { get; set; }

        /// <summary>
        /// Gets or sets CurrentARInvoiceAmount
        /// </summary>
        [ViewField(Name = Fields.CurrentARInvoiceAmount, Id = Index.CurrentARInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentARInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets CurrentARPrepaymentAmount
        /// </summary>
        [ViewField(Name = Fields.CurrentARPrepaymentAmount, Id = Index.CurrentARPrepaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentARPrepaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets ProcessWithoutCreditLimit
        /// </summary>
        [ViewField(Name = Fields.ProcessWithoutCreditLimit, Id = Index.ProcessWithoutCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessWithoutCreditLimit ProcessWithoutCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets Customer Credit Limit Message
        /// </summary>
        public string CustomerCreditMessage { get; set; }

        /// <summary>
        /// Gets or sets National Credit Limit Message
        /// </summary>
        public string NationalCreditMessage { get; set; }

    }
}
