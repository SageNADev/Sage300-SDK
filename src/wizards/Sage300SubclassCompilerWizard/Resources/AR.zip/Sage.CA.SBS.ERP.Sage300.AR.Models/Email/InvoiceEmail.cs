﻿// Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. 

#region 

using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Email
{
    /// <summary>
    /// Class for InvoiceEmail
    /// </summary>
    public class InvoiceEmail : ReportsEmailOption<Reports.Invoice>
    {
    }
}
