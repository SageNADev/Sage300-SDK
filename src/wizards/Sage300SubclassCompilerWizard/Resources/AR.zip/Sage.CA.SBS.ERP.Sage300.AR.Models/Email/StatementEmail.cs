﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region 

using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;
using System.Collections.Generic; 

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Email
{
    /// <summary>
    /// Class for StatementEmail
    /// </summary>
    public class StatementEmail : EmailOption
    {      

        /// <summary>
        /// Gets or Sets Reports
        /// </summary>
        public List<Reports.StatementLetterLabel> Reports { get; set; }
    }
}

