// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for CustomerStatistics
    /// </summary>
	public partial class CustomerStatistics : ModelBase
	{
  		/// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
 		public string CustomerNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Year", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
 		public string Year {get; set;}
		 
  		/// <summary>
        /// Gets or sets Period 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Period", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
 		public string Period {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofInvoices 
        /// </summary>
         [Display(Name = "NumberOfInvoices", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfInvoices, Id = Index.NumberOfInvoices, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofCredits 
        /// </summary>
         [Display(Name = "NumberOfCredits", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.NumberOfCredits, Id = Index.NumberOfCredits, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfCredits {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofDebits 
        /// </summary>
         [Display(Name = "NumberOfDebits", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.NumberOfDebits, Id = Index.NumberOfDebits, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfDebits {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofReceipts 
        /// </summary>
         [Display(Name = "NumberOfReceipts", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfReceipts, Id = Index.NumberOfReceipts, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfReceipts {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofDiscounts 
        /// </summary>
         [Display(Name = "NumberOfDiscounts", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfDiscounts, Id = Index.NumberOfDiscounts, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfDiscounts {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofAdjustments 
        /// </summary>
         [Display(Name = "NumberOfAdjustments", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfAdjustments, Id = Index.NumberOfAdjustments, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfAdjustments {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofWriteOffs 
        /// </summary>
         [Display(Name = "NumberOfWriteOffs", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfWriteOffs, Id = Index.NumberOfWriteOffs, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofInterestCharges 
        /// </summary>
         [Display(Name = "NumberOfInterestCharges", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfInterestCharges, Id = Index.NumberOfInterestCharges, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfInterestCharges {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofReturnedChecks 
        /// </summary>
         [Display(Name = "NumberOfReturnedChecks", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfReturnedChecks, Id = Index.NumberOfReturnedChecks, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfReturnedChecks {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofInvoicesPaid 
        /// </summary>
         [Display(Name = "NumberOfInvoicesPaid", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.NumberOfInvoicesPaid, Id = Index.NumberOfInvoicesPaid, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfInvoicesPaid {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofDaystoPay 
        /// </summary>
         [Display(Name = "NumberofDaystoPay", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.NumberOfDaystoPay, Id = Index.NumberOfDaystoPay, FieldType = EntityFieldType.Decimal, Size = 3)]
 		public decimal NumberOfDaystoPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalInvoicesinFuncCurr 
        /// </summary>
         [Display(Name = "TotalInvoicesInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalInvoicesInFuncCurr, Id = Index.TotalInvoicesInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalCreditsinFuncCurr 
        /// </summary>
         [Display(Name = "TotalCreditsInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalCreditsInFuncCurr, Id = Index.TotalCreditsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalCreditsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDebitsinFuncCurr 
        /// </summary>
         [Display(Name = "TotalDebitsInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalDebitsInFuncCurr, Id = Index.TotalDebitsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDebitsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalReceiptsinFuncCurr 
        /// </summary>
         [Display(Name = "TotalReceiptsInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalReceiptsInFuncCurr, Id = Index.TotalReceiptsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalReceiptsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDiscountsinFuncCurr 
        /// </summary>
         [Display(Name = "TotalDiscountsInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalDiscountsInFuncCurr, Id = Index.TotalDiscountsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDiscountsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalAdjustmentsinFuncCurr 
        /// </summary>
        [Display(Name = "TotalAdjustmentsInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalAdjustmentsInFuncCurr, Id = Index.TotalAdjustmentsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalAdjustmentsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWriteOffsinFuncCurr 
        /// </summary>
        [Display(Name = "TotalWriteOffsInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalWriteOffsInFuncCurr, Id = Index.TotalWriteOffsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWriteOffsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalInterestinFuncCurr 
        /// </summary>
        [Display(Name = "TotalInterestInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalInterestInFuncCurr, Id = Index.TotalInterestInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInterestInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalRetdChecksinFuncCurr 
        /// </summary>
        [Display(Name = "TotalRetdChecksInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalRetdChecksInFuncCurr, Id = Index.TotalRetdChecksInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalRetdChecksInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalInvoicesPdinFuncCurr 
        /// </summary>
        [Display(Name = "TotalInvoicesPdInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalInvoicesPdInFuncCurr, Id = Index.TotalInvoicesPdInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesPdInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalInvoicesinCustCurr 
        /// </summary>
        [Display(Name = "TotalInvoicesInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalInvoicesInCustCurr, Id = Index.TotalInvoicesInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalCreditsinCustCurr 
        /// </summary>
        [Display(Name = "TotalCreditsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalCreditsInCustCurr, Id = Index.TotalCreditsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalCreditsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDebitsinCustCurr 
        /// </summary>
        [Display(Name = "TotalDebitsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalDebitsInCustCurr, Id = Index.TotalDebitsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDebitsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalReceiptsinCustCurr 
        /// </summary>
        [Display(Name = "TotalReceiptsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalReceiptsInCustCurr, Id = Index.TotalReceiptsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalReceiptsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDiscountsinCustCurr 
        /// </summary>
        [Display(Name = "TotalDiscountsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalDiscountsInCustCurr, Id = Index.TotalDiscountsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDiscountsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalAdjustmentsinCustCurr 
        /// </summary>
        [Display(Name = "TotalAdjustmentsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalAdjustmentsInCustCurr, Id = Index.TotalAdjustmentsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalAdjustmentsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWriteOffsinCustCurr 
        /// </summary>
        [Display(Name = "TotalWriteOffsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalWriteOffsInCustCurr, Id = Index.TotalWriteOffsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWriteOffsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalInterestinCustCurr 
        /// </summary>
        [Display(Name = "TotalInterestInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalInterestInCustCurr, Id = Index.TotalInterestInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInterestInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalRetdChecksinCustCurr 
        /// </summary>
        [Display(Name = "TotalRetdChecksInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalRetdChecksInCustCurr, Id = Index.TotalRetdChecksInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalRetdChecksInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalInvoicesPdinCustCurr 
        /// </summary>
        [Display(Name = "TotalInvoicesPdInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalInvoicesPdInCustCurr, Id = Index.TotalInvoicesPdInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoicesPdInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets RevaluationBalinFuncCurr 
        /// </summary>
        [Display(Name = "RevaluationBalInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.RevaluationBalInFuncCurr, Id = Index.RevaluationBalInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal RevaluationBalInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets AverageDaystoPay 
        /// </summary>
 		[ViewField(Name = Fields.AverageDaysToPay, Id = Index.AverageDaysToPay, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 1)]
 		public decimal AverageDaysToPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofRefunds 
        /// </summary>
        [Display(Name = "NumberOfRefunds", ResourceType = typeof(ARCommonResx))]
 		public decimal NumberOfRefunds {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalRefundsinFuncCurr 
        /// </summary>
        [Display(Name = "TotalRefundsInFuncCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalRefundsInFuncCurr, Id = Index.TotalRefundsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalRefundsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalRefundsinCustCurr 
        /// </summary>
        [Display(Name = "TotalRefundsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.TotalRefundsInCustCurr, Id = Index.TotalRefundsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalRefundsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofInvoices 
        /// </summary>
        [Display(Name = "YTDNumberOfInvoices", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfInvoices, Id = Index.YTDNumberOfInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofCredits 
        /// </summary>
        [Display(Name = "YTDNumberOfCredits", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfCredits, Id = Index.YTDNumberOfCredits, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfCredits {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofDebits 
        /// </summary>
        [Display(Name = "YTDNumberOfDebits", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfDebits, Id = Index.YTDNumberOfDebits, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfDebits {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofReceipts 
        /// </summary>
        [Display(Name = "YTDNumberOfReceipts", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfReceipts, Id = Index.YTDNumberOfReceipts, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfReceipts {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofDiscounts 
        /// </summary>
        [Display(Name = "YTDNumberOfDiscounts", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfDiscounts, Id = Index.YTDNumberOfDiscounts, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfDiscounts {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofAdjustments 
        /// </summary>
        [Display(Name = "YTDNumberOfAdjustments", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfAdjustments, Id = Index.YTDNumberOfAdjustments, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfAdjustments {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofWriteOffs 
        /// </summary>
        [Display(Name = "YTDNumberOfWriteOffs", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfWriteOffs, Id = Index.YTDNumberOfWriteOffs, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofInterestCharges 
        /// </summary>
        [Display(Name = "YTDNumberOfInterestCharges", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfInterestCharges, Id = Index.YTDNumberOfInterestCharges, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfInterestCharges {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofReturnedChecks 
        /// </summary>
        [Display(Name = "YTDNumberOfReturnedChecks", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfReturnedChecks, Id = Index.YTDNumberOfReturnedChecks, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfReturnedChecks {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofInvoicesPaid 
        /// </summary>
        [Display(Name = "YTDNumberOfInvoicesPaid", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfInvoicesPaid, Id = Index.YTDNumberOfInvoicesPaid, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfInvoicesPaid {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofRefunds 
        /// </summary>
        [Display(Name = "YTDNumberOfRefunds", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDNumberOfRefunds, Id = Index.YTDNumberOfRefunds, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfRefunds {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofDaystoPay 
        /// </summary>
        [Display(Name = "YTDNumberOfDaysToPay", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDNumberOfDaysToPay, Id = Index.YTDNumberOfDaysToPay, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YTDNumberOfDaysToPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDInvoicesinFuncCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDInvoicesInFuncCurr, Id = Index.YTDInvoicesInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDCreditsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDCreditsInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDCreditsInFuncCurr, Id = Index.YTDCreditsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDCreditsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDDebitsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDDebitsInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDDebitsInFuncCurr, Id = Index.YTDDebitsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDebitsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDReceiptsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDReceiptsInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDReceiptsInFuncCurr, Id = Index.YTDReceiptsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDReceiptsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDDiscountsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDDiscountsInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDDiscountsInFuncCurr, Id = Index.YTDDiscountsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDiscountsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDAdjustmentsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDAdjustmentsInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDAdjustmentsInFuncCurr, Id = Index.YTDAdjustmentsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDAdjustmentsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDWriteOffsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDWriteOffsInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDWriteOffsInFuncCurr, Id = Index.YTDWriteOffsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDWriteOffsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDInterestinFuncCurr 
        /// </summary>
        [Display(Name = "YTDInterestInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDInterestInFuncCurr, Id = Index.YTDInterestInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInterestInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDRetdChecksinFuncCurr 
        /// </summary>
        [Display(Name = "YTDRetdChecksInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDRetdChecksInFuncCurr, Id = Index.YTDRetdChecksInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDRetdChecksInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDInvoicesPdinFuncCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesPdInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDInvoicesPdInFuncCurr, Id = Index.YTDInvoicesPdInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesPdInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDRefundsinFuncCurr 
        /// </summary>
        [Display(Name = "YTDRefundsInFuncCurr", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDRefundsInFuncCurr, Id = Index.YTDRefundsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDRefundsInFuncCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDInvoicesinCustCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDInvoicesInCustCurr, Id = Index.YTDInvoicesInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDCreditsinCustCurr 
        /// </summary>
        [Display(Name = "YTDCreditsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDCreditsInCustCurr, Id = Index.YTDCreditsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDCreditsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDDebitsinCustCurr 
        /// </summary>
        [Display(Name = "YTDDebitsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDDebitsInCustCurr, Id = Index.YTDDebitsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDebitsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDReceiptsinCustCurr 
        /// </summary>
        [Display(Name = "YTDReceiptsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDReceiptsInCustCurr, Id = Index.YTDReceiptsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDReceiptsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDDiscountsinCustCurr 
        /// </summary>
        [Display(Name = "YTDDiscountsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDDiscountsInCustCurr, Id = Index.YTDDiscountsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDDiscountsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDAdjustmentsinCustCurr 
        /// </summary>
        [Display(Name = "YTDAdjustmentsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDAdjustmentsInCustCurr, Id = Index.YTDAdjustmentsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDAdjustmentsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDWriteOffsinCustCurr 
        /// </summary>
        [Display(Name = "YTDWriteOffsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDWriteOffsInCustCurr, Id = Index.YTDWriteOffsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDWriteOffsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDInterestinCustCurr 
        /// </summary>
        [Display(Name = "YTDInterestInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDInterestInCustCurr, Id = Index.YTDInterestInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInterestInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDRetdChecksinCustCurr 
        /// </summary>
        [Display(Name = "YTDRetdChecksInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDRetdChecksInCustCurr, Id = Index.YTDRetdChecksInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDRetdChecksInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDInvoicesPdinCustCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesPdInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDInvoicesPdInCustCurr, Id = Index.YTDInvoicesPdInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDInvoicesPdInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDRefundsinCustCurr 
        /// </summary>
        [Display(Name = "YTDRefundsInCustCurr", ResourceType = typeof(CustomersResx))]
 		[ViewField(Name = Fields.YTDRefundsInCustCurr, Id = Index.YTDRefundsInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YTDRefundsInCustCurr {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDAverageDaystoPay 
        /// </summary>
        [Display(Name = "YTDAverageDaysToPay", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.YTDAverageDaysToPay, Id = Index.YTDAverageDaysToPay, FieldType = EntityFieldType.Decimal, Size = 6, Precision = 1)]
 		public decimal YTDAverageDaysToPay {get; set;}
		 
  		/// <summary>
        /// Gets or sets EnableYTDCalculations 
        /// </summary>
        [Display(Name = "EnableYTDCalculations", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EnableYTDCalculations, Id = Index.EnableYTDCalculations, FieldType = EntityFieldType.Int, Size = 2)]
        public EnableYtdCalculations EnableYTDCalculations { get; set; }

        /// <summary>
        /// Gets and Sets CustStatisticList
        /// </summary>
        public EnumerableResponse<CustomerStatisticGrid> CustomerStatisticList { get; set; }
  
    }

    /// <summary>
    /// Class For Static Grid in Customer 
    /// </summary>
    public class CustomerStatisticGrid : ModelBase
    {
        /// <summary>
        /// Gets and Sets LineNumber
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets and Sets TransactionType
        /// </summary>
        [Display(Name = "TransactionTypes", ResourceType = typeof(ARCommonResx))]
        public string TransactionType { get; set; }

        /// <summary>
        /// Gtes and Sets Amount
        /// </summary>
        public decimal FunctionalCurrencyAmount { get; set; }

        /// <summary>
        /// Gtes and Sets Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(ARCommonResx))]
        public decimal CustomerCurrencyAmount { get; set; }

        /// <summary>
        /// Gets and Sets Count
        /// </summary>
        [Display(Name = "Count", ResourceType = typeof(ARCommonResx))]
        public decimal Count { get; set; }

        /// <summary>
        /// Gets and Sets YTDAmount
        /// </summary>
        public decimal FunctionalCurrencyYtdAmount { get; set; }

        /// <summary>
        /// Gets and Sets YTDAmount
        /// </summary>
        [Display(Name = "YTDAmount", ResourceType = typeof(ARCommonResx))]
        public decimal CustomerCurrencyYtdAmount { get; set; }
        
        /// <summary>
        /// Gets and Sets YTDCount
        /// </summary>
        [Display(Name = "YTDCount", ResourceType = typeof(ARCommonResx))]
        public decimal YtdCount { get; set; }
    }
}
