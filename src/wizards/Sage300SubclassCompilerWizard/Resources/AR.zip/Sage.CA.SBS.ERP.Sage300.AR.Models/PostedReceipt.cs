// Copyright (c) 2015-2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for PostedReceipt
    /// </summary>
    public partial class PostedReceipt : SqlModelBase
    {
        /// <summary>
        /// Gets or sets BankCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Bank", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 1)]
        [GridInfo(30, typeof(ARCommonResx), "Bank")]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 2)]
        [GridInfo(1, typeof(ARCommonResx), "CustomerNumber")]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Customer Name
        /// </summary>
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets CheckReceiptNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckReceiptNo", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 3)]
        [GridInfo(2, typeof(ARCommonResx), "CheckReceiptNo")]
        [ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CheckReceiptNo { get; set; }

        /// <summary>
        /// Gets or sets DepositSerialNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 4)]
        [ViewField(Name = Fields.DepositSerialNumber, Id = Index.DepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long DepositSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DepositLineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 5)]
        [ViewField(Name = Fields.DepositLineNumber, Id = Index.DepositLineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DepositLineNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 6)]
        [GridInfo(3, typeof(ARCommonResx), "ReceiptDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ReceiptDate { get; set; }
        

        /// <summary>
        /// Gets or sets DepositNumber
        /// </summary>
        [Display(Name = "DepositNo", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 7)]
        [GridInfo(31, typeof(ARCommonResx), "DepositNo", Style = "w150 align-right")]
        [ViewField(Name = Fields.DepositNumber, Id = Index.DepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal DepositNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 8)]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BatchDate { get; set; }

        /// <summary>
        /// Gets or sets CustReceiptAmount
        /// </summary>
        [Display(Name = "ReceiptAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 9)]
        [GridInfo(6, typeof(ARCommonResx), "ReceiptAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.CustReceiptAmount, Id = Index.CustReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets BankReceiptAmount
        /// </summary>
        [Display(Name = "BankReceiptAmt", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 10)]
        [GridInfo(16, typeof(ARCommonResx), "BankReceiptAmt", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.BankReceiptAmount, Id = Index.BankReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BankReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets CustDiscountAmount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 11)]
        [GridInfo(7, typeof(ARCommonResx), "DiscountAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.CustDiscountAmount, Id = Index.CustDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCode", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 12)]
        [GridInfo(29, typeof(ARCommonResx), "PaymentCode")]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCurrency", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 13)]
        [GridInfo(14, typeof(ARCommonResx), "BankCurrency")]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BankRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 14)]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate
        /// </summary>
        [Display(Name = "BankExchangeRate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 15)]
        [GridInfo(15, typeof(ARCommonResx), "BankExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        ///// <summary>
        ///// Gets or sets BankRateOverride
        ///// </summary>
        [InquiryField(Id = 16)]
        [ViewField(Name = Fields.BankRateOverride, Id = Index.BankRateOverride, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOverride BankRateOverride { get; set; }

        /// <summary>
        /// Gets or sets ReasonForReturn
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReasonForReturn", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 17)]
        [GridInfo(34, typeof(ARCommonResx), "ReasonForReturn", Style = "w150")]
        [ViewField(Name = Fields.ReasonForReturn, Id = Index.ReasonForReturn, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReasonForReturn { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 18)]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets LastStatementDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 19)]
        [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastStatementDate { get; set; }

        /// <summary>
        /// Gets or sets AmountOfRoundingError
        /// </summary>
        [InquiryField(Id = 20)]
        [ViewField(Name = Fields.AmountOfRoundingError, Id = Index.AmountOfRoundingError, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOfRoundingError { get; set; }

        /// <summary>
        /// Gets or sets BankToFuncRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 21)]
        [ViewField(Name = Fields.BankToFuncRateDate, Id = Index.BankToFuncRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BankToFuncRateDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 22)]
        [GridInfo(22, typeof(ARCommonResx), "Year")]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 23)]
        [GridInfo(23, typeof(ARCommonResx), "Period")]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Payer
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Payer", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 24)]
        [GridInfo(5, typeof(ARCommonResx), "Payer")]
        [ViewField(Name = Fields.Payer, Id = Index.Payer, FieldType = EntityFieldType.Char, Size = 60)]
        public string Payer { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [Display(Name = "Batch", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 25)]
        [GridInfo(35, typeof(ARCommonResx), "Batch")]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber
        /// </summary>
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 26)]
        [GridInfo(36, typeof(ARCommonResx), "EntryNumber")]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckCleared
        /// </summary>
        [Display(Name = "ReceiptStatus", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 27)]
        [ViewField(Name = Fields.CheckCleared, Id = Index.CheckCleared, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckCleared CheckCleared { get; set; }

        /// <summary>
        /// Gets or sets FuncReceiptAmount
        /// </summary>
        [Display(Name = "ReceiptAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 28)]
        [GridInfo(11, typeof(ARCommonResx), "ReceiptAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.FuncReceiptAmount, Id = Index.FuncReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets CustAdjustmentAmount
        /// </summary>
        [Display(Name = "AdjustmentAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 29)]
        [GridInfo(8, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.CustAdjustmentAmount, Id = Index.CustAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets DateCleared
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCleared", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 30)]
        [GridInfo(32, typeof(ARCommonResx), "DateCleared", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [ViewField(Name = Fields.DateCleared, Id = Index.DateCleared, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateCleared { get; set; }

        /// <summary>
        /// Gets or sets DateReturned
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateReversed", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 31)]
        [GridInfo(33, typeof(ARCommonResx), "DateReversed", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [ViewField(Name = Fields.DateReturned, Id = Index.DateReturned, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateReturned { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 32)]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PostedReceiptDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNo", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 33)]
        [GridInfo(25, typeof(ARCommonResx), "DocumentNo", templateSource: GridInfoTemplateLib.PencilIconDrillDown)]
        [ViewField(Name = Fields.DocumentNo, Id = Index.DocumentNo, FieldType = EntityFieldType.Char, Size = 22)]
        public string DocumentNo { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [InquiryField(Id = 34)]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Gets or sets PaymentType
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 35)]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public PaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplicationSource
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 36)]
        [ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string DrillDownApplicationSource { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType
        /// </summary>
        [InquiryField(Id = 37)]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber
        /// </summary>
        [InquiryField(Id = 38)]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets MiscReceiptFlag
        /// </summary>
        [InquiryField(Id = 39)]
        [ViewField(Name = Fields.MiscReceiptFlag, Id = Index.MiscReceiptFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public int MiscReceiptFlag { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [InquiryField(Id = 40)]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 41)]
        [GridInfo(26, typeof(ARCommonResx), "InvoiceNumber", Style = "w150")]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets CalculateTax
        /// </summary>
        [InquiryField(Id = 42)]
        [ViewField(Name = Fields.CalculateTax, Id = Index.CalculateTax, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateTax CalculateTax { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 43)]
        [GridInfo(27, typeof(ARCommonResx), "TaxGroup")]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 44)]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 45)]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 46)]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 47)]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 48)]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [InquiryField(Id = 49)]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [InquiryField(Id = 50)]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [InquiryField(Id = 51)]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [InquiryField(Id = 52)]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [InquiryField(Id = 53)]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [InquiryField(Id = 54)]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [InquiryField(Id = 55)]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [InquiryField(Id = 56)]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [InquiryField(Id = 57)]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [InquiryField(Id = 58)]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [InquiryField(Id = 59)]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [InquiryField(Id = 60)]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [InquiryField(Id = 61)]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [InquiryField(Id = 62)]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [InquiryField(Id = 63)]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal
        /// </summary>
        [Display(Name = "TaxAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 64)]
        [GridInfo(9, typeof(ARCommonResx), "TaxAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DistAmountNetOfTaxes
        /// </summary>
        [InquiryField(Id = 65)]
        [ViewField(Name = Fields.DistAmountNetOfTaxes, Id = Index.DistAmountNetOfTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmountNetOfTaxes { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrency", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 66)]
        [GridInfo(17, typeof(ARCommonResx), "TaxReportingCurrency")]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrencyCode { get; set; }

        ///// <summary>
        ///// Gets or sets TaxReportingCalculateMethod
        ///// </summary>
        [InquiryField(Id = 67)]
        [ViewField(Name = Fields.TaxReportingCalculateMethod, Id = Index.TaxReportingCalculateMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingCalculateMethod TaxReportingCalculateMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 68)]
        [GridInfo(18, typeof(ARCommonResx), "TaxReportingExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 69)]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 70)]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperator
        /// </summary>
        [InquiryField(Id = 71)]
        [ViewField(Name = Fields.TaxReportingRateOperator, Id = Index.TaxReportingRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1
        /// </summary>
        [InquiryField(Id = 72)]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2
        /// </summary>
        [InquiryField(Id = 73)]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3
        /// </summary>
        [InquiryField(Id = 74)]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4
        /// </summary>
        [InquiryField(Id = 75)]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5
        /// </summary>
        [InquiryField(Id = 76)]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotal
        /// </summary>
        [Display(Name = "TaxReportingAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 77)]
        [GridInfo(19, typeof(ARCommonResx), "TaxReportingAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.TaxReportingTotal, Id = Index.TaxReportingTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase1
        /// </summary>
        [InquiryField(Id = 78)]
        [ViewField(Name = Fields.FuncTaxBase1, Id = Index.FuncTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase2
        /// </summary>
        [InquiryField(Id = 79)]
        [ViewField(Name = Fields.FuncTaxBase2, Id = Index.FuncTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase3
        /// </summary>
        [InquiryField(Id = 80)]
        [ViewField(Name = Fields.FuncTaxBase3, Id = Index.FuncTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase4
        /// </summary>
        [InquiryField(Id = 81)]
        [ViewField(Name = Fields.FuncTaxBase4, Id = Index.FuncTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase5
        /// </summary>
        [InquiryField(Id = 82)]
        [ViewField(Name = Fields.FuncTaxBase5, Id = Index.FuncTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1
        /// </summary>
        [InquiryField(Id = 83)]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2
        /// </summary>
        [InquiryField(Id = 84)]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3
        /// </summary>
        [InquiryField(Id = 85)]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4
        /// </summary>
        [InquiryField(Id = 86)]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5
        /// </summary>
        [InquiryField(Id = 87)]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxTotal
        /// </summary>
        [Display(Name = "TaxAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 88)]
        [GridInfo(12, typeof(ARCommonResx), "TaxAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.FuncTaxTotal, Id = Index.FuncTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmountNetOfTaxes
        /// </summary>
        [InquiryField(Id = 89)]
        [ViewField(Name = Fields.FuncDistAmountNetOfTaxes, Id = Index.FuncDistAmountNetOfTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmountNetOfTaxes { get; set; }

        /// <summary>
        /// Gets or sets NumberOfAdvanceCreditClaims
        /// </summary>
        [InquiryField(Id = 90)]
        [ViewField(Name = Fields.NumberOfAdvanceCreditClaims, Id = Index.NumberOfAdvanceCreditClaims, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfAdvanceCreditClaims { get; set; }

        /// <summary>
        /// Gets or sets TotalAdvanceCreditClaim
        /// </summary>
        [Display(Name = "AdvanceCredit", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 91)]
        [GridInfo(10, typeof(ARCommonResx), "AdvanceCredit", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.TotalAdvanceCreditClaim, Id = Index.TotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalAdvanceCreditClaim
        /// </summary>
        [Display(Name = "AdvanceCredit", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 92)]
        [GridInfo(13, typeof(ARCommonResx), "AdvanceCredit", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.FuncTotalAdvanceCreditClaim, Id = Index.FuncTotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 93)]
        [GridInfo(21, typeof(ARCommonResx), "PostingDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PostingDate { get; set; }

        /// <summary>
        /// Gets or sets CreditCardTransactionNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 94)]
        [ViewField(Name = Fields.CreditCardTransactionNumber, Id = Index.CreditCardTransactionNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string CreditCardTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessingCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 95)]
        [ViewField(Name = Fields.ProcessingCode, Id = Index.ProcessingCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string ProcessingCode { get; set; }

        /// <summary>
        /// Gets or sets CardNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CardNumber, Id = Index.CardNumber, FieldType = EntityFieldType.Char, Size = 16)]
        public string CardNumber { get; set; }

        /// <summary>
        /// Gets or sets CardType
        /// </summary>
        [ViewField(Name = Fields.CardType, Id = Index.CardType, FieldType = EntityFieldType.Int, Size = 2)]
        public CardType CardType { get; set; }

        /// <summary>
        /// Gets or Sets Tax Reporting Currency Decimals
        /// </summary>
        public int TaxReportingCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or Sets Bank Currency Decimals
        /// </summary>
        public int BankCurrencyDecimals { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets or sets the Customer Currency
        /// </summary>
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets BankRateOverride string value
        /// </summary>
        public string BankRateOverrideString
        {
            get { return EnumUtility.GetStringValue(BankRateOverride); }
        }

        /// <summary>
        /// Gets CheckCleared string value
        /// </summary>
        [GridInfo(4, typeof(ARCommonResx), "ReceiptStatus")]
        public string CheckClearedString
        {
            get { return EnumUtility.GetStringValue(CheckCleared); }
        }

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        [GridInfo(24, typeof(ARCommonResx), "DocumentType", Style = "w150")]
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets PaymentType string value
        /// </summary>
        [GridInfo(28, typeof(ARCommonResx), "PaymentType", Style = "w150")]
        public string PaymentTypeString
        {
            get { return EnumUtility.GetStringValue(PaymentType); }
        }

        /// <summary>
        /// Gets JobRelated string value
        /// </summary>
        [GridInfo(20, typeof(ARCommonResx), "JobRelated")]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets CalculateTax string value
        /// </summary>
        public string CalculateTaxString
        {
            get { return EnumUtility.GetStringValue(CalculateTax); }
        }

        /// <summary>
        /// Gets TaxReportingCalculateMethod string value
        /// </summary>
        public string TaxReportingCalculateMethodString
        {
            get { return EnumUtility.GetStringValue(TaxReportingCalculateMethod); }
        }

        /// <summary>
        /// Gets CardType string value
        /// </summary>
        public string CardTypeString
        {
            get { return EnumUtility.GetStringValue(CardType); }
        }

        #endregion
    }
}
