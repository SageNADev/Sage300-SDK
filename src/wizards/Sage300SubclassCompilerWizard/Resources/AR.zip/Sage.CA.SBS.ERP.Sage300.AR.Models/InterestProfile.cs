/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for Interest Profile
    /// </summary>
	public partial class InterestProfile : ModelBase
	{
		/// <summary>
        /// Gets or sets Interest Profile Id
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InterestProfile", ResourceType = typeof(InterestProfilesResx))]
        [Key]
        [ViewField(Name = Fields.InterestProfileId, Id = Index.InterestProfileId, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InterestProfileId { get; set; }
	 
		/// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InterestProfileDescription", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }
	 
		/// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "InactiveAsOfDate", ResourceType = typeof(CommonResx))]
		[ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
		public Status Status {get; set;}
	 
		/// <summary>
        /// Gets or sets Inactive Date 
        /// </summary>                
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime InactiveDate {get; set;}
	 
		/// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]       
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }
	 
		/// <summary>
        /// Gets or sets Interest Income Account 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InterestIncomeAcct", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.InterestIncomeAccount, Id = Index.InterestIncomeAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InterestIncomeAccount { get; set; }
        
        /// <summary>
        /// Gets or sets Description 
        /// </summary>        
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InterestIncomeAcctDesc", ResourceType = typeof(InterestProfilesResx))]
        [Editable(false)]
        public string InterestIncomeAccountDescription { get; set; }
	 
		/// <summary>
        /// Gets or sets Calculate Interest By 
        /// </summary>
        [Display(Name = "CalculateInterestBy", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.CalculateInterestBy, Id = Index.CalculateInterestBy, FieldType = EntityFieldType.Int, Size = 2)]
        public CalculateInterestBy CalculateInterestBy { get; set; }
	 
		/// <summary>
        /// Gets or sets Number of Days Over due 
        /// </summary>        
        [Display(Name = "NoofDaysOverdue", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.NumberOfDaysOverdue, Id = Index.NumberOfDaysOverdue, FieldType = EntityFieldType.Decimal, Size = 2)]
        public int NumberOfDaysOverdue { get; set; }
	 
		/// <summary>
        /// Gets or sets Round Up to Minimum 
        /// </summary>
        [Display(Name = "RoundUpToMinimum", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.RoundUptoMinimum, Id = Index.RoundUptoMinimum, FieldType = EntityFieldType.Int, Size = 2)]
        public RoundUptoMinimum RoundUptoMinimum { get; set; }
	 
		/// <summary>
        /// Gets or sets Compound Interest 
        /// </summary>
        [Display(Name = "CompoundInterest", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.CompoundInterest, Id = Index.CompoundInterest, FieldType = EntityFieldType.Int, Size = 2)]
        public RoundUptoMinimum CompoundInterest { get; set; }

        /// <summary>
        /// Get or Set for InterestRatesByCurrency
        /// </summary>
        [IgnoreExportImport]
        public InterestRatesByCurrency InterestRatesByCurrency { get; set; }

        #region "Interest Rates by Currency"
       
        /// <summary>
        /// Gets or sets Interest Rates by Currency.
        /// </summary>
        public EnumerableResponse<InterestRatesByCurrency> InterestProfileDetails { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Get Calculate Interest By String value
        /// </summary>
        public string CalculateInterestByString
        {
            get { return EnumUtility.GetStringValue(CalculateInterestBy); }
        }

        /// <summary>
        /// Get Round Upto Minimun String Value
        /// </summary>
        public string RoundUptoMinimumString
        {
            get { return EnumUtility.GetStringValue(RoundUptoMinimum); }
        }

        /// <summary>
        /// Get Compound Interest String Value
        /// </summary>
        public string CompoundInterestString
        {
            get { return EnumUtility.GetStringValue(CompoundInterest); }
        }
        #endregion
	    }
}
