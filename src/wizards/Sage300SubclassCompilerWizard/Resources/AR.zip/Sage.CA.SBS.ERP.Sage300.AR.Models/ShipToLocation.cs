// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Ship To Location Model
    /// </summary>
    public partial class ShipToLocation : ModelBase
    {
        /// <summary>
        /// Ship To Location Constructor
        /// </summary>
        public ShipToLocation()
        {
            SalesPersonList = new EnumerableResponse<CustomerSalesPerson>();
            ShipToLocationOptionalFields = new EnumerableResponse<ShipToLocationOptionalField>();
            CustomerTaxAuthorityList = new List<CustomerTaxAuthority>();
        }
        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocation 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.ShiptoLocation, Id = Index.ShiptoLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShiptoLocation { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>        
        [Display(Name = "InactiveDate", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>       
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address1", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address2", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address3", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address4", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateOrProv 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.StateOrProv, Id = Index.StateOrProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateOrProv { get; set; }

        /// <summary>
        /// Gets or sets ZipOrPostalCode 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZIPPostal", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets ContactName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets TerritoryCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Territory", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TerritoryCode, Id = Index.TerritoryCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TerritoryCode { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
         [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo1 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegistrationNumber1", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.TaxRegistrationNo1, Id = Index.TaxRegistrationNo1, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo2 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegistrationNumber2", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.TaxRegistrationNo2, Id = Index.TaxRegistrationNo2, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo3 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegistrationNumber3", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.TaxRegistrationNo3, Id = Index.TaxRegistrationNo3, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo4 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegistrationNumber4", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.TaxRegistrationNo4, Id = Index.TaxRegistrationNo4, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo5 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RegistrationNumber5", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.TaxRegistrationNo5, Id = Index.TaxRegistrationNo5, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode1 
        /// </summary>
        [Display(Name = "TaxClassCode1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode1, Id = Index.TaxClassCode1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode2 
        /// </summary>
        [Display(Name = "TaxClassCode2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode2, Id = Index.TaxClassCode2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode3 
        /// </summary>
        [Display(Name = "TaxClassCode3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode3, Id = Index.TaxClassCode3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode4 
        /// </summary>
        [Display(Name = "TaxClassCode4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode4, Id = Index.TaxClassCode4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode5 
        /// </summary>
        [Display(Name = "TaxClassCode5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode5, Id = Index.TaxClassCode5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode5 { get; set; }

        /// <summary>
        /// Gets or sets SpecialInstructions 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SpecialInstructions", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SpecialInstructions, Id = Index.SpecialInstructions, FieldType = EntityFieldType.Char, Size = 60)]
        public string SpecialInstructions { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage1 
        /// </summary>
        [Display(Name = "SalesSplitPercentage1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage1, Id = Index.SalesSplitPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage2 
        /// </summary>
        [Display(Name = "SalesSplitPercentage2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage2, Id = Index.SalesSplitPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage3 
        /// </summary>
        [Display(Name = "SalesSplitPercentage3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage3, Id = Index.SalesSplitPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage4 
        /// </summary>
        [Display(Name = "SalesSplitPercentage4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage4, Id = Index.SalesSplitPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage5 
        /// </summary>
        [Display(Name = "SalesSplitPercentage5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage5, Id = Index.SalesSplitPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerPriceList 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerPriceList", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerPriceList, Id = Index.CustomerPriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CustomerPriceList { get; set; }

        /// <summary>
        /// Gets or sets FreeOnBoard 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FOBPoint", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FreeOnBoard, Id = Index.FreeOnBoard, FieldType = EntityFieldType.Char, Size = 60)]
        public string FreeOnBoard { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipVia", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaDesc", ResourceType = typeof(ShipToLocationResx))]
        [ViewField(Name = Fields.ShipViaDescription, Id = Index.ShipViaDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaDescription { get; set; }

        /// <summary>
        /// Gets or sets PrimaryShipToIndicator 
        /// </summary>
        [Display(Name = "PrimaryShipTo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PrimaryShipToIndicator, Id = Index.PrimaryShipToIndicator, FieldType = EntityFieldType.Int, Size = 2)]
        public PrimaryShipToIndicator PrimaryShipToIndicator { get; set; }

        /// <summary>
        /// Gets or sets Email 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets ContactsPhone 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactPhone", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ContactsPhone, Id = Index.ContactsPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactsFax 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactFax", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ContactsFax, Id = Index.ContactsFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets ContactsEmail 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactEmail", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ContactsEmail, Id = Index.ContactsEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ProcessCommand", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CustGrpProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets InventoryLocation 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InventoryLocation", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InventoryLocation, Id = Index.InventoryLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InventoryLocation { get; set; }

        /// <summary>
        /// Gets or sets SuppressIntegration 
        /// </summary>
        [Display(Name = "Integration", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SuppressIntegration, Id = Index.SuppressIntegration, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SuppressIntegration { get; set; }

        /// <summary>
        /// Gets or sets AOrRVersion 
        /// </summary>
          [IgnoreExportImport]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Version", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.AorRVersion, Id = Index.AorRVersion, FieldType = EntityFieldType.Char, Size = 3)]
        public string AorRVersion { get; set; }

        /// <summary>
        /// Gets or sets Database 
        /// </summary>
          [IgnoreExportImport]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Database, Id = Index.Database, FieldType = EntityFieldType.Char, Size = 6)]
        public string Database { get; set; }

        /// <summary>
        /// Gets or sets Mode 
        /// </summary>
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public Mode Mode { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        public Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets suppress Integration String
        /// </summary>
        [Display(Name = "SuppressIntegration", ResourceType = typeof(CustomersResx))]
        public string SuppressIntegrationString
        {
            get
            {
                if (SuppressIntegration == false)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
            }
        }

        #region Custom Properties
        /// <summary>
        /// Gets or sets List of AR Ship To Location Optional Fields values
        /// </summary>
       [IgnoreExportImport]
        public EnumerableResponse<ShipToLocationOptionalField> ShipToLocationOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets the Tax Authority List
        /// </summary>
        /// <value>The Tax Authority list.</value>
          [IgnoreExportImport]
        public EnumerableResponse<CustomerTaxAuthority> TaxAuthorityList { get; set; }

        /// <summary>
        /// Gets or sets Activity List.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CustomerSalesPerson> SalesPersonList { get; set; }

        /// <summary>
        /// Gets or Sets CustomerTaxAuthorityList
        /// </summary>
          [IgnoreExportImport]
        public List<CustomerTaxAuthority> CustomerTaxAuthorityList { get; set; }
        
        /// <summary>
        /// Gets or sets the property StatusName
        /// </summary>
          [IgnoreExportImport]
        public string StatusName
        {
            get { return EnumUtility.GetStringValue(Status); }
        }
        /// <summary>
        /// Gets or sets the PrimaryShipToIndicatorName
        /// </summary>
          [IgnoreExportImport]
        [Display(Name = "PrimaryShipToIndicator", ResourceType = typeof(ShipToLocationResx))]
        public string PrimaryShipToIndicatorName
        {
            get { return EnumUtility.GetStringValue(PrimaryShipToIndicator); }
        }
        /// <summary>
        /// Gets or sets the ProcessCommandCodeName
        /// </summary>
          [IgnoreExportImport]
        public string ProcessCommandCodeName
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }
        /// <summary>
        /// Gets or sets the ModeName
        /// </summary>
        [IgnoreExportImport]
        public string ModeName
        {
            get { return EnumUtility.GetStringValue(Mode); }
        }

        /// <summary>
        /// Gets or sets the Save Optional lFields
        /// </summary>
        [IgnoreExportImport]
        public bool SaveOptionalFields { get; set; }

        /// <summary>
        /// Get and Sets OptionalFieldString-- this property is used in AR custome inquiry screen.
        /// </summary>
        [IgnoreExportImport]
        public String OptionalFieldString { get; set; }
        #endregion

        /// <summary>
        /// Customer Sales Person (Class For Grid) 
        /// </summary>
        public class CustomerSalesPerson : ModelBase
        {
            /// <summary>
            /// Gets or sets LineNumber
            /// </summary>
            public long LineNumber { get; set; }

            /// <summary>
            /// Gets and Sets SalesPersonCode
            /// </summary>
            [Display(Name = "SalespersonCode", ResourceType = typeof(ARCommonResx))]
            public string SalesPersonCode { get; set; }

            /// <summary>
            ///  Gets and Sets SalesPersonName
            /// </summary>
            [Display(Name = "SalespersonName", ResourceType = typeof(ARCommonResx))]
            public string SalesPersonName { get; set; }

            /// <summary>
            /// Gets and Sets SalesPercentage
            /// </summary>
            [Display(Name = "Percentage", ResourceType = typeof(ARCommonResx))]
            public decimal SalesPercentage { get; set; }
        }

    }
}
