// Copyright (c) 2020 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Process
{
    /// <summary>
    /// Partial class for CreatePaymentsTransactions
    /// </summary>
    public partial class CreatePaymentsTransactions : ModelBase
    {
        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessPaymentsAcceptance ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets PassARIBH
        /// </summary>
        [ViewField(Name = Fields.PassARIBH, Id = Index.PassARIBH, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PassARIBH { get; set; }
    }
}
