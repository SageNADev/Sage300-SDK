// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for RecurringChargeDetail
    /// </summary>
    public partial class RecurringChargeDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets RecurringChargeCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringChargeCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RecurringChargeCode, Id = Index.RecurringChargeCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string RecurringChargeCode { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ARCommonResx))]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [Display(Name = "Cost", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets Price
        /// </summary>
        [Display(Name = "Price", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.Price, Id = Index.Price, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Price { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountWithTip
        /// </summary>
        [Display(Name = "ExtendedAmountwTIP", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ExtendedAmountWithTip, Id = Index.ExtendedAmountWithTip, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedAmountWithTip { get; set; }

        /// <summary>
        /// Gets or sets COGSAmount
        /// </summary>
        [Display(Name = "COGSAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.COGSAmount, Id = Index.COGSAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal COGSAmount { get; set; }

        /// <summary>
        /// Gets or sets ExtendedAmountWithoutTip
        /// </summary>
        [Display(Name = "ExtendedAmountwoTIP", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ExtendedAmountWithoutTip, Id = Index.ExtendedAmountWithoutTip, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedAmountWithoutTip { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAmount
        /// </summary>
        [Display(Name = "TotalTaxAmount", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TotalTaxAmount, Id = Index.TotalTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount1
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount1, Id = Index.EstimatedWithholdingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount2
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount2, Id = Index.EstimatedWithholdingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount3
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount3, Id = Index.EstimatedWithholdingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount4
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount4, Id = Index.EstimatedWithholdingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount5
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount5, Id = Index.EstimatedWithholdingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RevenueAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RevenueAccount, Id = Index.RevenueAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RevenueAccount { get; set; }
        
        /// <summary>
        /// Gets or sets DistributedAmountBeforeTax
        /// </summary>
        [Display(Name = "DistributedAmountBeforeTax", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.DistributedAmountBeforeTax, Id = Index.DistributedAmountBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistributedAmountBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets Discountable
        /// </summary>
        [Display(Name = "Discountable", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public Discountable Discountable { get; set; }


        /// <summary>
        /// Gets or sets InventoryAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InventoryAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InventoryAccount, Id = Index.InventoryAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InventoryAccount { get; set; }

        /// <summary>
        /// Gets or sets COGSAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "COGSAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.COGSAccount, Id = Index.COGSAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string COGSAccount { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets PrintComment
        /// </summary>
        [Display(Name = "PrintComment", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PrintComment, Id = Index.PrintComment, FieldType = EntityFieldType.Int, Size = 2)]
        public int PrintComment { get; set; }

        /// <summary>
        /// Gets or sets PrintCommentString
        /// </summary>
        [Display(Name = "PrintComment", ResourceType = typeof(ARCommonResx))]
        public string PrintCommentString { get; set; }

        /// <summary>
        /// Gets or sets ItemCost
        /// </summary>
        [Display(Name = "ItemCost", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ItemCost, Id = Index.ItemCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ItemCost { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldString
        /// </summary>       
        [Display(Name = "OptionalFields", ResourceType = typeof(RecurringChargeResx))]
        public string OptionalFieldString { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCategoryResource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCategoryResource", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ProjectCategoryResource, Id = Index.ProjectCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TaxIncluded1 string value
        /// </summary>
        public string TaxIncluded1String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded1); }
        }

        /// <summary>
        /// Gets TaxIncluded2 string value
        /// </summary>
        public string TaxIncluded2String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded2); }
        }

        /// <summary>
        /// Gets TaxIncluded3 string value
        /// </summary>
        public string TaxIncluded3String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded3); }
        }

        /// <summary>
        /// Gets TaxIncluded4 string value
        /// </summary>
        public string TaxIncluded4String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded4); }
        }

        /// <summary>
        /// Gets TaxIncluded5 string value
        /// </summary>
        public string TaxIncluded5String
        {
            get { return EnumUtility.GetStringValue(TaxIncluded5); }
        }

        /// <summary>
        /// Gets Discountable string value
        /// </summary>
        public string DiscountableString
        {
            get { return EnumUtility.GetStringValue(Discountable); }
        }

        /// <summary>
        /// Gets ProcessCommandCode string value
        /// </summary>
        public string ProcessCommandCodeString
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString
        {
            get { return EnumUtility.GetStringValue(CostClass); }
        }


        #region Additional Property For Display
        
        /// <summary>
        /// Gets or sets RevenueDescription
        /// This is added to show the description of Revenue Account.
        /// </summary>
        [Display(Name = "RevenueDescription", ResourceType = typeof(ARCommonResx))]
        [IgnoreExportImport]
        public string RevenueAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets InventoryDescription
        /// This is added to show the description of Inventory Account.
        /// </summary>
        [Display(Name = "InventoryDescription", ResourceType = typeof(ARCommonResx))]
        [IgnoreExportImport]
        public string InventoryDescription { get; set; }

        /// <summary>
        /// Gets or sets COGSDescription
        /// This is added to show the description of COGS Account.
        /// </summary>
        [Display(Name = "COGSDescription", ResourceType = typeof(ARCommonResx))]
        [IgnoreExportImport]
        public string COGSDescription { get; set; }

        #endregion Additional Property For Display

        /// <summary>
        /// Gets or sets Sequence Number
        /// </summary>
        [IgnoreExportImport]
        public int? SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets editable state for PJC columns
        /// </summary>
        [IgnoreExportImport]
        public Dictionary<string, bool> PMDisableDictionary { get; set; }

        /// <summary>
        /// Gets or sets value if this detail line is for time and material project
        /// </summary>
        [IgnoreExportImport]
        public bool IsTimeAndMaterialProject { get; set; }

        /// <summary>
        /// Gets or sets value of the unformatted contract code
        /// </summary>
        [IgnoreExportImport]
        public string UnformattedContractCode { get; set; }

        #endregion
    }
}
