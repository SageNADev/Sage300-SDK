/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// ReceiptCreateOpenDocumentDetail
    /// </summary>
    public partial class ReceiptCreateOpenDocumentDetail : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptCreateOpenDocumentDetail"/> class.
        /// </summary>
        public ReceiptCreateOpenDocumentDetail()
        {
            ProcessType = ProcessType.Select;
            ShowType = ShowType.All;
            OrderBy = ReceiptOrderBy.DocumentNumber;
            TextTransactionType = TextTransactionType.Invoice;
            TextTransactionTypeId = TransactionTypeId.InvoiceItemIssued;
            JobRelated = AllowedType.No;

        }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets Countkey 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Count", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.Countkey, Id = Index.Countkey, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal Countkey { get; set; }

        /// <summary>
        /// Gets or sets Countpaymentsscheduled 
        /// </summary>
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Countpaymentsscheduled, Id = Index.Countpaymentsscheduled, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal Countpaymentsscheduled { get; set; }

        /// <summary>
        /// Gets or sets ProcessType 
        /// </summary>
        //[Display(Name = "OrderBy", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessType, Id = Index.ProcessType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessType ProcessType { get; set; }

        /// <summary>
        /// Gets or sets ShowType 
        /// </summary>
        [ViewField(Name = Fields.ShowType, Id = Index.ShowType, FieldType = EntityFieldType.Int, Size = 2)]
        public ShowType ShowType { get; set; }

        /// <summary>
        /// Gets or sets OrderBy 
        /// </summary>
        [Display(Name = "OrderBy", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrderBy, Id = Index.OrderBy, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptOrderBy OrderBy { get; set; }

        /// <summary>
        /// Gets or sets IDCustomer 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.IDCustomer, Id = Index.IDCustomer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string IDCustomer { get; set; }

        /// <summary>
        /// Gets or sets IDInvc 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.IDInvc, Id = Index.IDInvc, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string IDInvc { get; set; }

        /// <summary>
        /// Gets or sets ReceiptID 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Receipt", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceiptID, Id = Index.ReceiptID, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ReceiptID { get; set; }

        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PoNumber, Id = Index.PoNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PoNumber { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Texttransactiontype 
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        public TextTransactionType TextTransactionType { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DueDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets Discountdate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Discountdate, Id = Index.Discountdate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Discountdate { get; set; }

        /// <summary>
        /// Gets or sets Invoicedate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Invoicedate, Id = Index.Invoicedate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime Invoicedate { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmountDue 
        /// </summary>
        [Display(Name = "CurrentBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentAmountDue, Id = Index.PaymentAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmountDue { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmountNet 
        /// </summary>
        [Display(Name = "NetBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentAmountNet, Id = Index.PaymentAmountNet, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmountNet { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmountDiscount 
        /// </summary>
        [Display(Name = "PendDiscTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentAmountDiscount, Id = Index.PaymentAmountDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmountDiscount { get; set; }


        /// <summary>
        /// Gets or sets PAYMAMT 
        /// </summary>
        [Display(Name = "AppliedAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PayAmount, Id = Index.PayAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PayAmount { get; set; }

        /// <summary>
        /// Gets or sets DiscountTakenAmount 
        /// </summary>
        [Display(Name = "DiscountTaken", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DiscountTakenAmount, Id = Index.DiscountTakenAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountTakenAmount { get; set; }

        /// <summary>
        /// Gets or sets Apply 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Apply", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Apply, Id = Index.Apply, FieldType = EntityFieldType.Char, Size = 1)]
        public string Apply { get; set; }

        /// <summary>
        /// Gets or sets TextTransactionType 
        /// </summary>
        [ViewField(Name = Fields.TextTransactionTypeId, Id = Index.TextTransactionTypeId, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionTypeId TextTransactionTypeId { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentAmount 
        /// </summary>
        [Display(Name = "AdjustmentAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AdjustmentAmount, Id = Index.AdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets StartingDocNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartingDocNo", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.StartingDocNumber, Id = Index.StartingDocNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string StartingDocNumber { get; set; }

        /// <summary>
        /// Gets or sets StartingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartingDocDate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.StartingDate, Id = Index.StartingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? StartingDate { get; set; }

        /// <summary>
        /// Gets or sets StartingAmount 
        /// </summary>
        [ViewField(Name = Fields.StartingAmount, Id = Index.StartingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StartingAmount { get; set; }

        /// <summary>
        /// Gets or sets AMTRMIT 
        /// </summary>
        [ViewField(Name = Fields.AmountRemit, Id = Index.AmountRemit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountRemit { get; set; }

        /// <summary>
        /// Gets or sets PaymentDiscountAvailable 
        /// </summary>
        [Display(Name = "DiscountAvailable", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentDiscountAvailable, Id = Index.PaymentDiscountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentDiscountAvailable { get; set; }

        /// <summary>
        /// Gets or sets TCPlinecount 
        /// </summary>
        [ViewField(Name = Fields.TcpLineCount, Id = Index.TcpLineCount, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal TcpLineCount { get; set; }

        /// <summary>
        /// Gets or sets StartingCustomerNo 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartingCustNo", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.StartingCustomerNo, Id = Index.StartingCustomerNo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string StartingCustomerNo { get; set; }

        /// <summary>
        /// Gets or sets OriginalApply 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OriginalApply, Id = Index.OriginalApply, FieldType = EntityFieldType.Char, Size = 1)]
        public string OriginalApply { get; set; }

        /// <summary>
        /// Gets or sets PendingReceiptAmount 
        /// </summary>
        [Display(Name = "PendPaymentTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingReceiptAmount, Id = Index.PendingReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingDiscountAmount 
        /// </summary>
        [Display(Name = "PendingDiscounts", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingDiscountAmount, Id = Index.PendingDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingAdjustmentAmount 
        /// </summary>
        [Display(Name = "PendAdjTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingAdjustmentAmount, Id = Index.PendingAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingBalance 
        /// </summary>
        [Display(Name = "PendingBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingBalance, Id = Index.PendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingBalance { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocumentAmount 
        /// </summary>
        [Display(Name = "OriginalAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalDocumentAmount, Id = Index.OriginalDocumentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalDocumentAmount { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType JobRelated { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalDocument", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1TC, Id = Index.AmtWHD1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2TC, Id = Index.AmtWHD2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3TC, Id = Index.AmtWHD3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4TC, Id = Index.AmtWHD4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5TC, Id = Index.AmtWHD5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Withheld Amount Total
        /// </summary>
        [ViewField(Name = Fields.AmtWHDTot, Id = Index.AmtWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.PndWHD1Tot, Id = Index.PndWHD1Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD1Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.PndWHD2Tot, Id = Index.PndWHD2Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD2Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.PndWHD3Tot, Id = Index.PndWHD3Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD3Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.PndWHD4Tot, Id = Index.PndWHD4Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD4Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.PndWHD5Tot, Id = Index.PndWHD5Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD5Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Total
        /// </summary>
        [ViewField(Name = Fields.PndWHDTot, Id = Index.PndWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Document Tax Authority 1
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax1, Id = Index.CodeTax1, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax1 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 2
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax2, Id = Index.CodeTax2, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax2 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 3
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax3, Id = Index.CodeTax3, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax3 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 4
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax4, Id = Index.CodeTax4, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax4 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 5
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax5, Id = Index.CodeTax5, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 1 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth1Description, Id = Index.TaxAuth1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth1Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 2 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth2Description, Id = Index.TaxAuth2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth2Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 3 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth3Description, Id = Index.TaxAuth3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth3Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 4 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth4Description, Id = Index.TaxAuth4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth4Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 5 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth5Description, Id = Index.TaxAuth5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth5Description { get; set; }

        #region UI
        /// <summary>
        /// Check if the row is edited
        /// </summary>
        public bool IsEdited { get; set; }

        #endregion
    }
}
