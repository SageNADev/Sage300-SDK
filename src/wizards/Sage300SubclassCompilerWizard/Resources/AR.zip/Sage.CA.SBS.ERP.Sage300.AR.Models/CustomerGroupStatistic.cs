/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class CustomerGroupStatistic : ModelBase
    {
        /// <summary>
        /// Constructor for CustomerGroupStatistic class
        /// </summary>
        public CustomerGroupStatistic()
        {
            CustStatisticList = new EnumerableResponse<CustGrpStatisticGrid>();
        }

        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "GroupCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets Year 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Year", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Period", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets NumberOfInvoices 
        /// </summary>
        [Display(Name = "NumberOfInvoices", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfInvoices, Id = Index.NumberOfInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfInvoices { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCreditNotes 
        /// </summary>
        [Display(Name = "NumberOfCreditNotes", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfCreditNotes, Id = Index.NumberOfCreditNotes, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDebitNotes 
        /// </summary>
        [Display(Name = "NumberOfDebitNotes", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfDebitNotes, Id = Index.NumberOfDebitNotes, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets NumberOfReceipts 
        /// </summary>
        [Display(Name = "NumberOfReceipts", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfReceipts, Id = Index.NumberOfReceipts, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfReceipts { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDiscounts 
        /// </summary>
        [Display(Name = "NumberOfDiscounts", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfDiscounts, Id = Index.NumberOfDiscounts, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfDiscounts { get; set; }

        /// <summary>
        /// Gets or sets NumberOfAdjustments 
        /// </summary>
        [Display(Name = "NumberOfAdjustments", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfAdjustments, Id = Index.NumberOfAdjustments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfAdjustments { get; set; }

        /// <summary>
        /// Gets or sets NumberOfWriteOffs 
        /// </summary>
        [Display(Name = "NumberOfWriteOffs", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfWriteOffs, Id = Index.NumberOfWriteOffs, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets NumberOfInterestCharges 
        /// </summary>
        [Display(Name = "NumberOfInterestCharges", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfInterestCharges, Id = Index.NumberOfInterestCharges, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfInterestCharges { get; set; }

        /// <summary>
        /// Gets or sets NumberOfReturnedChecks 
        /// </summary>
        [Display(Name = "NumberOfReturnedChecks", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfReturnedChecks, Id = Index.NumberOfReturnedChecks, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfReturnedChecks { get; set; }

        /// <summary>
        /// Gets or sets NumberOfPaidInvoices 
        /// </summary>
        [Display(Name = "NumberofPaidInvoices", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfPaidInvoices, Id = Index.NumberOfPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDaystoPay 
        /// </summary>
        [Display(Name="TotalDaysToPay",ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfDaystoPay, Id = Index.NumberOfDaystoPay, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberOfDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets TotalInvoiceAmount 
        /// </summary>
        [Display(Name = "TotalInvoiceAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalInvoiceAmount, Id = Index.TotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalCreditNoteAmount 
        /// </summary>
        [Display(Name = "TotalCreditNoteAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalCreditNoteAmount, Id = Index.TotalCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalDebitNoteAmount 
        /// </summary>
        [Display(Name = "TotalDebitNoteAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalDebitNoteAmount, Id = Index.TotalDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalReceiptAmount 
        /// </summary>
        [Display(Name = "TotalReceiptAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalReceiptAmount, Id = Index.TotalReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalDiscountAmount 
        /// </summary>
        [Display(Name = "TotalDiscountAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalDiscountAmount, Id = Index.TotalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalAdjustmentAmount 
        /// </summary>
        [Display(Name = "TotalAdjustmentAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalAdjustmentAmount, Id = Index.TotalAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalWriteOffAmount 
        /// </summary>
        [Display(Name = "TotalWriteOffAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalWriteOffAmount, Id = Index.TotalWriteOffAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWriteOffAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalInterestAmount 
        /// </summary>
        [Display(Name = "TotalInterestAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalInterestAmount, Id = Index.TotalInterestAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInterestAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalAmountofReturnedChecks 
        /// </summary>
        [Display(Name = "TotalAmountofReturnedChecks", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalAmountofReturnedChecks, Id = Index.TotalAmountofReturnedChecks, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmountofReturnedChecks { get; set; }

        /// <summary>
        /// Gets or sets TotalAmountofPaidInvoices 
        /// </summary>
        [Display(Name = "TotalAmountofPaidInvoices", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalAmountofPaidInvoices, Id = Index.TotalAmountofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmountofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets AverageDaystoPay 
        /// </summary>
        [Display(Name = "AverageDaysToPay", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AverageDaystoPay, Id = Index.AverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 1)]
        public decimal AverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets NumberOfRefunds 
        /// </summary>
        [Display(Name = "NumberOfRefunds", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfRefunds, Id = Index.NumberOfRefunds, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberOfRefunds { get; set; }

        /// <summary>
        /// Gets or setsTotalRefundAmount 
        /// </summary>
        [Display(Name = "TotalRefundAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalRefundAmount, Id = Index.TotalRefundAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRefundAmount { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfInvoices 
        /// </summary>
        [Display(Name = "YTDNumberOfInvoices", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfInvoices, Id = Index.YTDNumberOfInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfInvoices { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfCredits 
        /// </summary>
        // ReSharper disable once InconsistentNaming
        [Display(Name = "YTDNumberOfCredits", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfCredits, Id = Index.YTDNumberOfCredits, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfCredits { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfDebits 
        /// </summary>
        [Display(Name = "YTDNumberOfDebits", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfDebits, Id = Index.YTDNumberOfDebits, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfDebits { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfReceipts 
        /// </summary>
        [Display(Name = "YTDNumberOfReceipts", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfReceipts, Id = Index.YTDNumberOfReceipts, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfReceipts { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfDiscounts 
        /// </summary>
        [Display(Name = "YTDNumberOfDiscounts", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfDiscounts, Id = Index.YTDNumberOfDiscounts, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfDiscounts { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfAdjustments 
        /// </summary>
        [Display(Name = "YTDNumberOfAdjustments", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfAdjustments, Id = Index.YTDNumberOfAdjustments, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfAdjustments { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfWriteOffs 
        /// </summary>
        [Display(Name = "YTDNumberOfWriteOffs", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfWriteOffs, Id = Index.YTDNumberOfWriteOffs, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfInterestCharges 
        /// </summary>
        [Display(Name = "YTDNumberOfInterestCharges", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfInterestCharges, Id = Index.YTDNumberOfInterestCharges, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfInterestCharges { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfReturnedChecks 
        /// </summary>
        [Display(Name = "YTDNumberOfReturnedChecks", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfReturnedChecks, Id = Index.YTDNumberOfReturnedChecks, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfReturnedChecks { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfInvoicesPaid 
        /// </summary>
        [Display(Name = "YTDNumberOfInvoicesPaid", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfInvoicesPaid, Id = Index.YTDNumberOfInvoicesPaid, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfInvoicesPaid { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfRefunds 
        /// </summary>
        [Display(Name = "YTDNumberOfRefunds", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfRefunds, Id = Index.YTDNumberOfRefunds, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfRefunds { get; set; }

        /// <summary>
        /// Gets or sets YTDNumberOfDaystoPay 
        /// </summary>
        [Display(Name = "YTDTotalDaysToPay", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDNumberOfDaystoPay, Id = Index.YTDNumberOfDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YTDNumberOfDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets YTDInvoicesInFuncCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDInvoicesInFuncCurr, Id = Index.YTDInvoicesInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDInvoicesInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDCreditsInFuncCurr 
        /// </summary>
        [Display(Name = "YTDCreditsInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDCreditsInFuncCurr, Id = Index.YTDCreditsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDCreditsInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDDebitsInFuncCurr 
        /// </summary>
        [Display(Name = "YTDDebitsInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDDebitsInFuncCurr, Id = Index.YTDDebitsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDDebitsInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDReceiptsInFuncCurr 
        /// </summary>
       [Display(Name = "YTDReceiptsInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDReceiptsInFuncCurr, Id = Index.YTDReceiptsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDReceiptsInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDDiscountsInFuncCurr 
        /// </summary>
        [Display(Name = "YTDDiscountsInFuncCurr", ResourceType = typeof(ARCommonResx))]
       // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDDiscountsInFuncCurr, Id = Index.YTDDiscountsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDDiscountsInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDAdjustmentsInFuncCurr 
        /// </summary>
        [Display(Name = "YTDAdjustmentsInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDAdjustmentsInFuncCurr, Id = Index.YTDAdjustmentsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDAdjustmentsInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDWriteOffsInFuncCurr 
        /// </summary>
        [Display(Name = "YTDWriteOffsInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDWriteOffsInFuncCurr, Id = Index.YTDWriteOffsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDWriteOffsInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDInterestInFuncCurr 
        /// </summary>
        [Display(Name = "YTDInterestInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDInterestInFuncCurr, Id = Index.YTDInterestInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDInterestInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDRetdChecksInFuncCurr 
        /// </summary>
        [Display(Name = "YTDRetdChecksInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDRetdChecksInFuncCurr, Id = Index.YTDRetdChecksInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDRetdChecksInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDInvoicesPdInFuncCurr 
        /// </summary>
        [Display(Name = "YTDInvoicesPdInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDInvoicesPdInFuncCurr, Id = Index.YTDInvoicesPdInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDInvoicesPdInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDRefundsInFuncCurr 
        /// </summary>
        [Display(Name = "YTDRefundsInFuncCurr", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDRefundsInFuncCurr, Id = Index.YTDRefundsInFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YTDRefundsInFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTDAverageDaystoPay 
        /// </summary>
        [Display(Name = "YTDAverageDaysToPay", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.YTDAverageDaystoPay, Id = Index.YTDAverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 6, Precision = 1)]
        public decimal YTDAverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets EnableYTDCalculations 
        /// </summary>
        [Display(Name = "EnableYTDCalculations", ResourceType = typeof(ARCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.EnableYTDCalculations, Id = Index.EnableYTDCalculations, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowEditofCreditLimit EnableYTDCalculations { get; set; }

        /// <summary>
        /// Gets and Sets CustStatisticList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CustGrpStatisticGrid> CustStatisticList { get; set; }

        /// <summary>
        /// Number of Periods 
        /// </summary>
        [IgnoreExportImport]
        public string NumberOfPeriods { get; set; }
    }

    /// <summary>
    /// Class For Static Grid in Customer Group
    /// </summary>
    public class CustGrpStatisticGrid : ModelBase
    {
        ///// <summary>
        ///// Gets and Sets LineNumber
        ///// </summary>
        //public int LineNumber { get; set; }

        /// <summary>
        /// Gets and Sets TransactionType
        /// </summary>
        public string TransactionType { get; set; }

        /// <summary>
        /// Gtes and Sets Amount
        /// </summary>
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets and Sets Count
        /// </summary>
        public decimal Count { get; set; }

        /// <summary>
        /// Gets and Sets YTDAmount
        /// </summary>
        /// ReSharper disable once InconsistentNaming
        public decimal YTDAmount { get; set; }

        /// <summary>
        /// Gets and Sets YTDCount
        /// </summary>
        /// ReSharper disable once InconsistentNaming
        public decimal YTDCount { get; set; }
    }
}
