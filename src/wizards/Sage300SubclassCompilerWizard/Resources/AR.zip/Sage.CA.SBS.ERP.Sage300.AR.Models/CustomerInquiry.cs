﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Models.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// CustomerInquiry model
    /// </summary>
    public class CustomerInquiry : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CustomerInquiry"/> class.
        /// </summary>

        #region Constructor

        public CustomerInquiry()
        {
            Payment = new Payment();
        }

        #endregion
        /// <summary>
        /// Customer Model
        /// </summary>
        public Customer Customer { get; set; }

        /// <summary>
        /// CustomerOptionalFieldValues Model
        /// </summary>
        public CustomerOptionalFieldValues CustomerOptionalFieldValues { get; set; }

        /// <summary>
        /// Activity Model
        /// </summary>
        public Activity Activity { get; set; }

        /// <summary>
        /// CustomerStatistics Model
        /// </summary>
        public CustomerStatistics CustomerStatistics { get; set; }

        /// <summary>
        /// CustomerStatisticGrid Model
        /// </summary>
        public CustomerStatisticGrid CustomerStatisticGrid { get; set; }

        /// <summary>
        /// Payment Model
        /// </summary>
        public Payment Payment { get; set; }

        /// <summary>
        /// PostedReceipt Model
        /// </summary>
        public PostedReceipt PostedReceipt { get; set; }

        /// <summary>
        /// AgeDocument Model
        /// </summary>
        public AgeDocument AgeDocument { get; set; } 
    }
}
