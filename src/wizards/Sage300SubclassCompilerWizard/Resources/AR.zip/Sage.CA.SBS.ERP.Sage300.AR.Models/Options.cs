// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for Company Options
    /// </summary>
    public partial class Options : ModelBase
    {
        #region "Company-Options Properties"

        /// <summary>
        /// Gets or sets Company Options Key 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CompanyOptionsKey, Id = Index.CompanyOptionsKey, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CompanyOptionsKey { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Contact Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets Telephone Number 
        /// </summary>
        [Display(Name = "Phone", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.TelephoneNumber, Id = Index.TelephoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string TelephoneNumber { get; set; }

        /// <summary>
        /// Gets or sets Fax Number 
        /// </summary>
        [Display(Name = "Fax", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency 
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets Process Recurring Charges 
        /// </summary>
        [Display(Name = "ProcessRecurChgs", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ProcessRecurringCharges, Id = Index.ProcessRecurringCharges, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ProcessRecurringCharges { get; set; }

        /// <summary>
        /// Gets or sets Edit Imported Batches 
        /// </summary>
        [Display(Name = "AllowEditImported", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EditImportedBatches, Id = Index.EditImportedBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditImportedBatches { get; set; }

        /// <summary>
        /// Gets or sets Force Listing of Batches 
        /// </summary>
        [Display(Name = "ForceBatchListing", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ForceListingofBatches, Id = Index.ForceListingofBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ForceListingofBatches { get; set; }

        /// <summary>
        /// Gets or sets Reserved 
        /// </summary>
        public decimal Reserved { get; set; }

        /// <summary>
        /// Gets or sets Edit Customer Statistics 
        /// </summary>
        [Display(Name = "AllowEditOfStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EditCustStatistics, Id = Index.EditCustStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditCustStatistics { get; set; }

        /// <summary>
        /// Gets or sets Include Tax in Customer Statistics 
        /// </summary>
        [Display(Name = "InclTaxInStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.IncTaxinCustStatistics, Id = Index.IncTaxinCustStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public IncTaxinStatistics IncTaxinCustStatistics { get; set; }

        /// <summary>
        /// Gets or sets Customer Statistics Year Type 
        /// </summary>
        [Display(Name = "AccumulateBy", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.CustStatisticsYearType, Id = Index.CustStatisticsYearType, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsAccumulateYearType CustStatisticsYearType { get; set; }

        /// <summary>
        /// Gets or sets Customer Statistics Period Type 
        /// </summary>
        [Display(Name = "PeriodType", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.CustStatisticsPeriodType, Id = Index.CustStatisticsPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriodType CustStatisticsPeriodType { get; set; }

        /// <summary>
        /// Gets or sets Keep Item Statistics 
        /// </summary>
        [Display(Name = "KeepStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.KeepItemStatistics, Id = Index.KeepItemStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType KeepItemStatistics { get; set; }

        /// <summary>
        /// Gets or sets Edit Item Statistics 
        /// </summary>
        [Display(Name = "AllowEditOfStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EditItemStatistics, Id = Index.EditItemStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditItemStatistics { get; set; }

        /// <summary>
        /// Gets or sets Include Tax in Item Statistics 
        /// </summary>
        [Display(Name = "InclTaxInStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.IncTaxinItemStatistics, Id = Index.IncTaxinItemStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public IncTaxinStatistics IncTaxinItemStatistics { get; set; }

        /// <summary>
        /// Gets or sets Item Statistics Year Type 
        /// </summary>
        [Display(Name = "AccumulateBy", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.ItemStatisticsYearType, Id = Index.ItemStatisticsYearType, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsAccumulateYearType ItemStatisticsYearType { get; set; }

        /// <summary>
        /// Gets or sets Item Statistics Period Type 
        /// </summary>
        [Display(Name = "PeriodType", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.ItemStatisticsPeriodType, Id = Index.ItemStatisticsPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriodType ItemStatisticsPeriodType { get; set; }

        /// <summary>
        /// Gets or sets Keep Sales person Statistics 
        /// </summary>
        [Display(Name = "KeepStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.KeepSalespersonStatistics, Id = Index.KeepSalespersonStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType KeepSalespersonStatistics { get; set; }

        /// <summary>
        /// Gets or sets Edit Sales person Statistics 
        /// </summary>
        [Display(Name = "AllowEditOfStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EditSalespersonStatistics, Id = Index.EditSalespersonStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditSalespersonStatistics { get; set; }

        /// <summary>
        /// Gets or sets Include Tax in Sales Statistics 
        /// </summary>
        [Display(Name = "InclTaxInStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.IncTaxinSalesStatistics, Id = Index.IncTaxinSalesStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public IncTaxinStatistics IncTaxinSalesStatistics { get; set; }

        /// <summary>
        /// Gets or sets Sales Statistics Year Type 
        /// </summary>
        [Display(Name = "AccumulateBy", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.SalesStatisticsYearType, Id = Index.SalesStatisticsYearType, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsAccumulateYearType SalesStatisticsYearType { get; set; }

        /// <summary>
        /// Gets or sets Sales Statistics Period Type 
        /// </summary>
        [Display(Name = "PeriodType", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.SalesStatisticsPeriodType, Id = Index.SalesStatisticsPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriodType SalesStatisticsPeriodType { get; set; }

        /// <summary>
        /// Gets or sets Next Revaluation Posting Sequence 
        /// </summary>
        [Display(Name = "NextRevlPostSeq", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextRevaluationPostingSeq, Id = Index.NextRevaluationPostingSeq, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRevaluationPostingSeq { get; set; }

        /// <summary>
        /// Gets or sets Keep History 
        /// </summary>
        [ViewField(Name = Fields.KeepHistory, Id = Index.KeepHistory, FieldType = EntityFieldType.Int, Size = 2)]
        public int KeepHistory { get; set; }

        /// <summary>
        /// Gets or sets Keep Customer Statistics 
        /// </summary>
        [Display(Name = "KeepStatistics", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.KeepCustomerStatistics, Id = Index.KeepCustomerStatistics, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType KeepCustomerStatistics { get; set; }

        /// <summary>
        /// Gets or sets Edit External Batches 
        /// </summary>
        [Display(Name = "AllowEditExternalBatches", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EditExternalBatches, Id = Index.EditExternalBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditExternalBatches { get; set; }

        #endregion

        #region"Company-Options extended properties for UI"

        /// <summary>
        /// Multicurrency Activated Switch Disable for UI to freeze control
        /// </summary>
        public bool MultiCurrActivatedSwitchDisable
        {
            get { return Multicurrency != Multicurrency.No; }
        }

        /// <summary>
        /// Multicurrency Activated Switch for UI
        /// </summary>
        public bool MultiCurrActivatedSwitch
        {
            get { return Multicurrency != Multicurrency.No; }
            set { Multicurrency = value ? Multicurrency.Yes : Multicurrency.No; }
        }

        /// <summary>
        /// Process Recurring Charges Yes/No for UI
        /// </summary>
        public bool ProcessRecurrCharges
        {
            get { return ProcessRecurringCharges != AllowedType.No; }
            set { ProcessRecurringCharges = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Force Listing of Batches Yes/No for UI
        /// </summary>
        public bool ForceListofBatches
        {
            get { return ForceListingofBatches != AllowedType.No; }
            set { ForceListingofBatches = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Edit Imported Batches Yes/No for UI
        /// </summary>
        public bool EditImpBatches
        {
            get { return EditImportedBatches != AllowedType.No; }
            set { EditImportedBatches = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Edit External Batches Yes/No for UI
        /// </summary>
        public bool EditExtBatches
        {
            get { return EditExternalBatches != AllowedType.No; }
            set { EditExternalBatches = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Keep Customer Statistics Yes/No for UI 
        /// </summary>
        public bool KeepCustomerStatis
        {
            get { return KeepCustomerStatistics != AllowedType.No; }
            set { KeepCustomerStatistics = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Edit Of Customer Statistics Yes/No for UI
        /// </summary>
        public bool EditCustStatis
        {
            get { return EditCustStatistics != AllowedType.No; }
            set { EditCustStatistics = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Include Tax in Customer Statistics Yes/No for UI
        /// </summary>
        public bool IncTaxinCustStatis
        {
            get { return IncTaxinCustStatistics != IncTaxinStatistics.NotIncluded; }
            set { IncTaxinCustStatistics = value ? IncTaxinStatistics.Included : IncTaxinStatistics.NotIncluded; }
        }

        /// <summary>
        /// Keep Item Statistics Yes/No for UI 
        /// </summary>
        public bool KeepItemStatis
        {
            get { return KeepItemStatistics != AllowedType.No; }
            set { KeepItemStatistics = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Edit Of Item Statistics Yes/No for UI
        /// </summary>
        public bool EditItemStatis
        {
            get { return EditItemStatistics != AllowedType.No; }
            set { EditItemStatistics = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Include Tax in Item Statistics Yes/No for UI
        /// </summary>
        public bool IncTaxinItemStatis
        {
            get { return IncTaxinItemStatistics != IncTaxinStatistics.NotIncluded; }
            set { IncTaxinItemStatistics = value ? IncTaxinStatistics.Included : IncTaxinStatistics.NotIncluded; }
        }

        /// <summary>
        /// Keep Salesperson Statistics Yes/No for UI 
        /// </summary>
        public bool KeepSalespersonStatis
        {
            get { return KeepSalespersonStatistics != AllowedType.No; }
            set { KeepSalespersonStatistics = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Edit Of Salesperson Statistics Yes/No for UI
        /// </summary>
        public bool EditSalespersonStatis
        {
            get { return EditSalespersonStatistics != AllowedType.No; }
            set { EditSalespersonStatistics = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Include Tax in Salesperson Statistics Yes/No for UI
        /// </summary>
        public bool IncTaxinSalespersonStatis
        {
            get { return IncTaxinSalesStatistics != IncTaxinStatistics.NotIncluded; }
            set { IncTaxinSalesStatistics = value ? IncTaxinStatistics.Included : IncTaxinStatistics.NotIncluded; }
        }

        #endregion

        #region "Company-Profile"

        /// <summary>
        /// Gets or sets Company Profile
        /// </summary>
        public CompanyProfile CompanyProfile { get; set; }

        #endregion

        #region "Invoicing-Options"

        /// <summary>
        /// Gets or Sets Invoicing Options
        /// </summary>
        public OptionsInvoicing OptionsInvoicing { get; set; }

        #endregion

        #region "Receipt-Options"

        /// <summary>
        /// Get Or Set Receipt and Adjustment Options
        /// </summary>
        public OptionsReceiptAndAdjustment OptionsReceiptAndAdjustment { get; set; }

        #endregion

        #region "Statement-Options"

        /// <summary>
        /// Get Or Set Statement Processing Options
        /// </summary>
        public OptionsStatementProcessing OptionsStatementProcessing { get; set; }

        #endregion

        #region "Cust/Ship-To Options"

        /// <summary>
        /// Gets or Sets Customer and Ship To Options
        /// </summary>
        public OptionsCustomerAndShipTo OptionsCustomerAndShipTo { get; set; }

        #endregion
    }
}
