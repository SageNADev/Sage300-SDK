// Copyright © 2016 Sage Software, Inc

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for ProcessCreditCardPaymentsDtl
    /// </summary>
    public partial class ProcessCreditCardPaymentsDtl : ModelBase
    {
        /// <summary>
        /// Gets or sets Customer
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.Customer, Id = Index.Customer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Customer { get; set; }

        /// <summary>
        /// Gets or sets Document
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Document, Id = Index.Document, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string Document { get; set; }

        /// <summary>
        /// Gets or sets Payment
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Payment, Id = Index.Payment, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal Payment { get; set; }

        /// <summary>
        /// Gets or sets ProcessingCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessingCode, Id = Index.ProcessingCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string ProcessingCode { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerName", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets AmountDue
        /// </summary>
        [Display(Name = "CurrentBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount
        /// </summary>
        [Display(Name = "DiscountAvailable", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentAmount
        /// </summary>
        [Display(Name = "PaymentAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentAmount, Id = Index.PaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets DueDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DueDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3)]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public SpsTransactionStatus Status { get; set; }

        /// <summary>
        /// Gets or sets Apply
        /// </summary>
        [Display(Name = "Apply", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Apply, Id = Index.Apply, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCcApply Apply { get; set; }

        [IgnoreExportImport]
        public decimal DecimalPlaces { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
         get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets Apply string value
        /// </summary>
        public string ApplyString
        {
         get { return EnumUtility.GetStringValue(Apply); }
        }

        #endregion
    }
}
