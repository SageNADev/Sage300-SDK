// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Partial class for RefundDetailJob
	/// </summary>
	public partial class RefundJobDetail : ModelBase
	{
		/// <summary>
		/// Gets or sets BatchNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "BatchNumber", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal BatchNumber { get; set; }

		/// <summary>
		/// Gets or sets EntryNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "EntryNumber", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
		public decimal EntryNumber { get; set; }

		/// <summary>
		/// Gets or sets LineNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "LineNumber", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
		public decimal LineNumber { get; set; }

		/// <summary>
		/// Gets or sets SeqNo
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "SeqNo", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.SeqNo, Id = Index.SeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
		public decimal SeqNo { get; set; }

		/// <summary>
		/// Gets or sets OriginalLineNumber
		/// </summary>
		[Display(Name = "OriginalLineNumber", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.OriginalLineNumber, Id = Index.OriginalLineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
		public decimal OriginalLineNumber { get; set; }

		/// <summary>
		/// Gets or sets ContractCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Contract", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
		public string ContractCode { get; set; }

		/// <summary>
		/// Gets or sets ProjectCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Project", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
		public string ProjectCode { get; set; }

		/// <summary>
		/// Gets or sets CategoryCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Category", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
		public string CategoryCode { get; set; }

		/// <summary>
		/// Gets or sets ProjectCategoryResource
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ProjectCategoryResource", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.ProjectCategoryResource, Id = Index.ProjectCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
		public string ProjectCategoryResource { get; set; }

		/// <summary>
		/// Gets or sets TransactionNumber
		/// </summary>
		[Display(Name = "TransactionNumber", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long TransactionNumber { get; set; }

		/// <summary>
		/// Gets or sets CostClass
		/// </summary>
		[Display(Name = "CostClass", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
		public CostClass CostClass { get; set; }

		/// <summary>
		/// Gets or sets RefundAmountInCustCurr
		/// </summary>
		[Display(Name = "RefundAmountInCustCurr", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.RefundAmountInCustCurr, Id = Index.RefundAmountInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RefundAmountInCustCurr { get; set; }

		/// <summary>
		/// Gets or sets AmountDueInCustCurr
		/// </summary>
		[Display(Name = "AmountDueInCustCurr", ResourceType = typeof (RefundDetailJobResx))]
		[ViewField(Name = Fields.AmountDueInCustCurr, Id = Index.AmountDueInCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal AmountDueInCustCurr { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets CostClass string value
		/// </summary>
		public string CostClassString
		{
			get { return EnumUtility.GetStringValue(CostClass); }
		}

		#endregion
	}
}
