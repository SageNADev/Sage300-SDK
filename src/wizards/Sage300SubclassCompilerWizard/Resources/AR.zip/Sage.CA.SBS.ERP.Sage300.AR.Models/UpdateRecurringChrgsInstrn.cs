// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for UpdateRecurringChrgsInstrn
    /// </summary>
    public partial class UpdateRecurringChrgsInstrn : ModelBase
    {
        /// <summary>
        /// Gets or sets Key
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Key, Id = Index.Key, FieldType = EntityFieldType.Long, Size = 4)]
        public long Key { get; set; }

        /// <summary>
        /// Gets or sets RecurringChargeCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringChargeCode", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.RecurringChargeCode, Id = Index.RecurringChargeCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string RecurringChargeCode { get; set; }

        /// <summary>
        /// Gets or sets FromCustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromCustNum", ResourceType = typeof(UpdateRecurringChargesResx))]
        [ViewField(Name = Fields.FromCustomerNumber, Id = Index.FromCustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ToCustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToCustNum", ResourceType = typeof(UpdateRecurringChargesResx))]
        [ViewField(Name = Fields.ToCustomerNumber, Id = Index.ToCustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ToCustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ChangeByPercentageOrAmount
        /// </summary>
        [Display(Name = "ChangeBy", ResourceType = typeof(UpdateRecurringChargesResx))]
        [ViewField(Name = Fields.ChangeByType, Id = Index.ChangeByType, FieldType = EntityFieldType.Int, Size = 2)]
        public ChangeByType ChangeByType { get; set; }

        /// <summary>
        /// Gets or sets IncreaseOrDecreaseRCValue
        /// </summary>
        [Display(Name = "IncreaseDecrease", ResourceType = typeof(UpdateRecurringChargesResx))]
        [ViewField(Name = Fields.IncreaseOrDecreaseRcValue, Id = Index.IncreaseOrDecreaseRcValue, FieldType = EntityFieldType.Int, Size = 2)]
        public IncreaseOrDecreaseRcValue IncreaseOrDecreaseRcValue { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets Value to Change By
        /// </summary>
        [Display(Name = "ChangeInDistAmount", ResourceType = typeof(UpdateRecurringChargesResx))]
        public decimal ValueToChangeBy { get; set; }

        /// <summary>
        /// Gets or sets MoneyDistributionMethod
        /// </summary>
        [Display(Name = "Method", ResourceType = typeof(UpdateRecurringChargesResx))]
        [ViewField(Name = Fields.DistributionMethod, Id = Index.DistributionMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DistributionMethod DistributionMethod { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets PercentToChangeMaxAmountBy
        /// </summary>
        [Display(Name = "ChangeInMaxAmount", ResourceType = typeof(UpdateRecurringChargesResx))]
        public decimal ValueToChangeMaxBy { get; set; }

        /// <summary>
        /// Gets or sets HasInstructionBeenProcessed
        /// </summary>
        [ViewField(Name = Fields.HasInstructionBeenProcessed, Id = Index.HasInstructionBeenProcessed, FieldType = EntityFieldType.Int, Size = 2)]
        public HasInstructionBeenProcessed HasInstructionBeenProcessed { get; set; }

        /// <summary>
        /// Gets or sets NumberOfRCRecordsProcessed
        /// </summary>
        [ViewField(Name = Fields.NumberOfRcRecordsProcessed, Id = Index.NumberOfRcRecordsProcessed, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfRcRecordsProcessed { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ChangeByPercentageOrAmount string value
        /// </summary>
        [IsMvcSpecific]
        public string ChangeByTypeString
        {
            get { return EnumUtility.GetStringValue(ChangeByType); }
        }

        /// <summary>
        /// Gets IncreaseOrDecreaseRCValue string value
        /// </summary>
        [IsMvcSpecific]
        public string IncreaseOrDecreaseRcValueString
        {
            get { return EnumUtility.GetStringValue(IncreaseOrDecreaseRcValue); }
        }

        /// <summary>
        /// Gets MoneyDistributionMethod string value
        /// </summary>
        [IsMvcSpecific]
        public string DistributionMethodString
        {
            get { return EnumUtility.GetStringValue(DistributionMethod); }
        }

        /// <summary>
        /// Gets HasInstructionBeenProcessed string value
        /// </summary>
        [IsMvcSpecific]
        public string HasInstructionBeenProcessedString
        {
            get { return EnumUtility.GetStringValue(HasInstructionBeenProcessed); }
        }

        /// <summary>
        /// Gets or sets the list of valid Distribution Methods
        /// </summary>
        [IsMvcSpecific]
        public List<SelectList> DistributionMethodPresentationList { get; set; }

        /// <summary>
        /// Gets the number of decimals
        /// </summary>
        [IsMvcSpecific]
        public int? DecimalPlaces { get; set; }

        /// <summary>
        /// Gets the number of integers
        /// </summary>
        [IsMvcSpecific]
        public int? NumOfIntegers { get; set; }

        #endregion
    }
}
