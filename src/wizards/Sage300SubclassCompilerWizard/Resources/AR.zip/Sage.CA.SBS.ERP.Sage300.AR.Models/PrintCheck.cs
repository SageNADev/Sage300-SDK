// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Partial class for PrintCheck
	/// </summary>
	public partial class PrintCheck : ModelBase
	{
		/// <summary>
		/// Gets or sets Request
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Request, Id = Index.Request, FieldType = EntityFieldType.Int, Size = 2)]
		public Request Request { get; set; }

		/// <summary>
		/// Gets or sets BatchNumber
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal BatchNumber { get; set; }

		/// <summary>
		/// Gets or sets EntryNumber
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
		public decimal EntryNumber { get; set; }

		/// <summary>
		/// Gets or sets ReturnedStatus
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReturnedStatus, Id = Index.ReturnedStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public ReturnedStatus ReturnedStatus { get; set; }

		/// <summary>
		/// Gets or sets RestartState
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RestartState, Id = Index.RestartState, FieldType = EntityFieldType.Int, Size = 2)]
		public RestartState RestartState { get; set; }

        /// <summary>
        /// Gets or sets Message 
        /// </summary>
        public string Message { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Request string value
		/// </summary>
		public string RequestString
		{
			get { return EnumUtility.GetStringValue(Request); }
		}

		/// <summary>
		/// Gets ReturnedStatus string value
		/// </summary>
		public string ReturnedStatusString
		{
			get { return EnumUtility.GetStringValue(ReturnedStatus); }
		}

		/// <summary>
		/// Gets RestartState string value
		/// </summary>
		public string RestartStateString
		{
			get { return EnumUtility.GetStringValue(RestartState); }
		}

		#endregion
	}
}
