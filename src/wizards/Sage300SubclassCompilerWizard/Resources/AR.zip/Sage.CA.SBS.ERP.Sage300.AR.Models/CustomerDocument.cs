// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for Customer Document
    /// </summary>
    public partial class CustomerDocument : SqlModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [GridInfo(1, typeof(ARCommonResx), "CustomerNumber", Style = "w150")]
        [InquiryField(Id = 1)]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
        [GridInfo(6, typeof(ARCommonResx), "DocumentNumber", templateSource: GridInfoTemplateLib.PencilIconDrillDown, Style = "w150")]
        [InquiryField(Id = 2)]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckReceiptNo
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckReceiptNo", ResourceType = typeof(ARCommonResx))]
        [GridInfo(41, typeof(ARCommonResx), "CheckReceiptNo", Style = "w150")]
        [InquiryField(Id = 3)]
        [ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CheckReceiptNo { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [GridInfo(39, typeof(ARCommonResx), "OrderNumber", templateSource: GridInfoTemplateLib.PencilIconDrillDown, Style = "w150")]
        [InquiryField(Id = 4)]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(ARCommonResx))]
        [GridInfo(38, typeof(ARCommonResx), "PONumber", Style = "w150")]
        [InquiryField(Id = 5)]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof(ARCommonResx))]
        [GridInfo(40, typeof(ARCommonResx), "ShipmentNumber", templateSource: GridInfoTemplateLib.PencilIconDrillDown, Style = "w150")]
        [InquiryField(Id = 6)]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets DueDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DueDate", ResourceType = typeof(ARCommonResx))]
        [GridInfo(9, typeof(ARCommonResx), "DueDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [InquiryField(Id = 7)]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DueDate { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 8)]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 9)]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [InquiryField(Id = 10)]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerInquiryTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [InquiryField(Id = 11)]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerInquiryDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets BatchDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 12)]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BatchDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [GridInfo(42, typeof(ARCommonResx), "BatchNumber", Style = "w150 align-right")]
        [InquiryField(Id = 13)]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber
        /// </summary>
        [GridInfo(43, typeof(ARCommonResx), "EntryNumber", Style = "w150 align-right")]
        [InquiryField(Id = 14)]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets GroupCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 15)]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets DocumentDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(11, typeof(ARCommonResx), "Description", Style = "w150")]
        [InquiryField(Id = 16)]
        [ViewField(Name = Fields.DocumentDescription, Id = Index.DocumentDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DocumentDescription { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(8, typeof(ARCommonResx), "DocumentDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [InquiryField(Id = 17)]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets AsofDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 18)]
        [ViewField(Name = Fields.AsofDate, Id = Index.AsofDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? AsofDate { get; set; }

        /// <summary>
        /// Gets or sets Terms
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(33, typeof(ARCommonResx), "Terms", Style = "w150")]
        [InquiryField(Id = 19)]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }
        /// <summary>
        /// Gets or sets DiscountDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(34, typeof(ARCommonResx), "DiscountDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [InquiryField(Id = 20)]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(4, typeof(ARCommonResx), "CurrencyCode", Style = "w150")]
        [InquiryField(Id = 21)]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 22)]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden
        /// </summary>
        [InquiryField(Id = 23)]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [GridInfo(12, typeof(ARCommonResx), "ExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 24)]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyInvoiceAmount
        /// </summary>
        [GridInfo(14, typeof(ARCommonResx), "DocumentTotal", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 25)]
        [ViewField(Name = Fields.FuncCurrencyInvoiceAmount, Id = Index.FuncCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyAmountDue
        /// </summary>
        [GridInfo(18, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 26)]
        [ViewField(Name = Fields.FuncCurrencyAmountDue, Id = Index.FuncCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyTaxableAmount
        /// </summary>
        [InquiryField(Id = 27)]
        [ViewField(Name = Fields.FuncCurrencyTaxableAmount, Id = Index.FuncCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyNonTaxableAmt
        /// </summary>
        [InquiryField(Id = 28)]
        [ViewField(Name = Fields.FuncCurrencyNonTaxableAmt, Id = Index.FuncCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyTaxAmount
        /// </summary>
        [GridInfo(22, typeof(ARCommonResx), "TaxAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 29)]
        [ViewField(Name = Fields.FuncCurrencyTaxAmount, Id = Index.FuncCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyDiscountAmount
        /// </summary>
        [GridInfo(20, typeof(ARCommonResx), "DiscountAvailable", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 30)]
        [ViewField(Name = Fields.FuncCurrencyDiscountAmount, Id = Index.FuncCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyInvoiceAmount
        /// </summary>
        [GridInfo(13, typeof(ARCommonResx), "DocumentTotal", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 31)]
        [ViewField(Name = Fields.CustCurrencyInvoiceAmount, Id = Index.CustCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyAmountDue
        /// </summary>
        [GridInfo(17, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 32)]
        [ViewField(Name = Fields.CustCurrencyAmountDue, Id = Index.CustCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyTaxableAmount
        /// </summary>
        [InquiryField(Id = 33)]
        [ViewField(Name = Fields.CustCurrencyTaxableAmount, Id = Index.CustCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyNonTaxableAmt
        /// </summary>
        [InquiryField(Id = 34)]
        [ViewField(Name = Fields.CustCurrencyNonTaxableAmt, Id = Index.CustCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyTaxAmount
        /// </summary>
        [GridInfo(21, typeof(ARCommonResx), "TaxAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 35)]
        [ViewField(Name = Fields.CustCurrencyTaxAmount, Id = Index.CustCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyDiscountAmount
        /// </summary>
        [GridInfo(19, typeof(ARCommonResx), "DiscountAvailable", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 36)]
        [ViewField(Name = Fields.CustCurrencyDiscountAmount, Id = Index.CustCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FullyPaid
        /// </summary>
        [InquiryField(Id = 37)]
        [ViewField(Name = Fields.FullyPaid, Id = Index.FullyPaid, FieldType = EntityFieldType.Int, Size = 2)]
        public FullyPaid FullyPaid { get; set; }

        /// <summary>
        /// Gets or sets LastActivityDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 38)]
        [ViewField(Name = Fields.LastActivityDate, Id = Index.LastActivityDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastActivityDate { get; set; }

        /// <summary>
        /// Gets or sets LastStatementDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 39)]
        [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastStatementDate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfScheduledPayments
        /// </summary>
        [GridInfo(7, typeof(ARCommonResx), "NumOfPayments", Style = "w150 align-right")]
        [InquiryField(Id = 40)]
        [ViewField(Name = Fields.NumberOfScheduledPayments, Id = Index.NumberOfScheduledPayments, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberOfScheduledPayments { get; set; }

        /// <summary>
        /// Gets or sets LastPaymentNumberPaid
        /// </summary>
        [InquiryField(Id = 41)]
        [ViewField(Name = Fields.LastPaymentNumberPaid, Id = Index.LastPaymentNumberPaid, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastPaymentNumberPaid { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumberonLastStatement
        /// </summary>
        [InquiryField(Id = 42)]
        [ViewField(Name = Fields.PaymentNumberonLastStatement, Id = Index.PaymentNumberonLastStatement, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumberonLastStatement { get; set; }

        /// <summary>
        /// Gets or sets ReceiptAmountApplied
        /// </summary>
        [InquiryField(Id = 43)]
        [ViewField(Name = Fields.ReceiptAmountApplied, Id = Index.ReceiptAmountApplied, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReceiptAmountApplied { get; set; }

        /// <summary>
        /// Gets or sets LastAppliedPaymentSeqNo
        /// </summary>
        [InquiryField(Id = 44)]
        [ViewField(Name = Fields.LastAppliedPaymentSeqNo, Id = Index.LastAppliedPaymentSeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastAppliedPaymentSeqNo { get; set; }

        /// <summary>
        /// Gets or sets TaxOverrideSwitch
        /// </summary>
        [InquiryField(Id = 45)]
        [ViewField(Name = Fields.TaxOverrideSwitch, Id = Index.TaxOverrideSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxOverride TaxOverrideSwitch { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 46)]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 47)]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 48)]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 49)]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 50)]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount1
        /// </summary>
        [InquiryField(Id = 51)]
        [ViewField(Name = Fields.FuncBaseAmount1, Id = Index.FuncBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount2
        /// </summary>
        [InquiryField(Id = 52)]
        [ViewField(Name = Fields.FuncBaseAmount2, Id = Index.FuncBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount3
        /// </summary>
        [InquiryField(Id = 53)]
        [ViewField(Name = Fields.FuncBaseAmount3, Id = Index.FuncBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount4
        /// </summary>
        [InquiryField(Id = 54)]
        [ViewField(Name = Fields.FuncBaseAmount4, Id = Index.FuncBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount5
        /// </summary>
        [InquiryField(Id = 55)]
        [ViewField(Name = Fields.FuncBaseAmount5, Id = Index.FuncBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1
        /// </summary>
        [InquiryField(Id = 56)]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2
        /// </summary>
        [InquiryField(Id = 57)]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3
        /// </summary>
        [InquiryField(Id = 58)]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4
        /// </summary>
        [InquiryField(Id = 59)]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5
        /// </summary>
        [InquiryField(Id = 60)]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount1
        /// </summary>
        [InquiryField(Id = 61)]
        [ViewField(Name = Fields.CustBaseAmount1, Id = Index.CustBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount2
        /// </summary>
        [InquiryField(Id = 62)]
        [ViewField(Name = Fields.CustBaseAmount2, Id = Index.CustBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount3
        /// </summary>
        [InquiryField(Id = 63)]
        [ViewField(Name = Fields.CustBaseAmount3, Id = Index.CustBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount4
        /// </summary>
        [InquiryField(Id = 64)]
        [ViewField(Name = Fields.CustBaseAmount4, Id = Index.CustBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount5
        /// </summary>
        [InquiryField(Id = 65)]
        [ViewField(Name = Fields.CustBaseAmount5, Id = Index.CustBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount1
        /// </summary>
        [InquiryField(Id = 66)]
        [ViewField(Name = Fields.CustTaxAmount1, Id = Index.CustTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount2
        /// </summary>
        [InquiryField(Id = 67)]
        [ViewField(Name = Fields.CustTaxAmount2, Id = Index.CustTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount3
        /// </summary>
        [InquiryField(Id = 68)]
        [ViewField(Name = Fields.CustTaxAmount3, Id = Index.CustTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount4
        /// </summary>
        [InquiryField(Id = 69)]
        [ViewField(Name = Fields.CustTaxAmount4, Id = Index.CustTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount5
        /// </summary>
        [InquiryField(Id = 70)]
        [ViewField(Name = Fields.CustTaxAmount5, Id = Index.CustTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 71)]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 72)]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 73)]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 74)]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 75)]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage1
        /// </summary>
        [InquiryField(Id = 76)]
        [ViewField(Name = Fields.SalesSplitPercentage1, Id = Index.SalesSplitPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage2
        /// </summary>
        [InquiryField(Id = 77)]
        [ViewField(Name = Fields.SalesSplitPercentage2, Id = Index.SalesSplitPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage3
        /// </summary>
        [InquiryField(Id = 78)]
        [ViewField(Name = Fields.SalesSplitPercentage3, Id = Index.SalesSplitPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage4
        /// </summary>
        [InquiryField(Id = 79)]
        [ViewField(Name = Fields.SalesSplitPercentage4, Id = Index.SalesSplitPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage5
        /// </summary>
        [InquiryField(Id = 80)]
        [ViewField(Name = Fields.SalesSplitPercentage5, Id = Index.SalesSplitPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(31, typeof(ARCommonResx), "FiscalYear", Style = "w150")]
        [InquiryField(Id = 81)]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(32, typeof(ARCommonResx), "FiscalPeriod", Style = "w150")]
        [InquiryField(Id = 82)]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets PrepayApplytoDocNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 83)]
        [ViewField(Name = Fields.PrepayApplytoDocNo, Id = Index.PrepayApplytoDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PrepayApplytoDocNo { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(30, typeof(ARCommonResx), "PostingDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [InquiryField(Id = 84)]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PostingDate { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 85)]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [InquiryField(Id = 86)]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Gets or sets LastActivityYearPeriod
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 87)]
        [ViewField(Name = Fields.LastActivityYearPeriod, Id = Index.LastActivityYearPeriod, FieldType = EntityFieldType.Char, Size = 6)]
        public string LastActivityYearPeriod { get; set; }

        /// <summary>
        /// Gets or sets BankCode
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 88)]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets DepositNumber
        /// </summary>
        [InquiryField(Id = 89)]
        [ViewField(Name = Fields.DepositNumber, Id = Index.DepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal DepositNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo
        /// </summary>
        [InquiryField(Id = 90)]
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [InquiryField(Id = 91)]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [InquiryField(Id = 92)]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageOutstanding
        /// </summary>
        [InquiryField(Id = 93)]
        [ViewField(Name = Fields.RetainageOutstanding, Id = Index.RetainageOutstanding, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageOutstanding RetainageOutstanding { get; set; }

        /// <summary>
        /// Gets or sets DateRetainageDue
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(36, typeof(ARCommonResx), "RetainageDueDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
        [InquiryField(Id = 94)]
        [ViewField(Name = Fields.DateRetainageDue, Id = Index.DateRetainageDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrOrigRtngAmt
        /// </summary>
        [GridInfo(25, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 95)]
        [ViewField(Name = Fields.FuncCurrOrigRtngAmt, Id = Index.FuncCurrOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrRetainageAmount
        /// </summary>
        [GridInfo(27, typeof(ARCommonResx), "OutstandingRtg", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 96)]
        [ViewField(Name = Fields.FuncCurrRetainageAmount, Id = Index.FuncCurrRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrOrigRtngAmt
        /// </summary>
        [GridInfo(24, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 97)]
        [ViewField(Name = Fields.CustCurrOrigRtngAmt, Id = Index.CustCurrOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets CustCurrRetainageAmount
        /// </summary>
        [GridInfo(26, typeof(ARCommonResx), "OutstandingRtg", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [InquiryField(Id = 98)]
        [ViewField(Name = Fields.CustCurrRetainageAmount, Id = Index.CustCurrRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(35, typeof(ARCommonResx), "RetainageTerms", Style = "w150")]
        [InquiryField(Id = 99)]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [InquiryField(Id = 100)]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerInquiryRetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(37, typeof(ARCommonResx), "OriginalDocument", Style = "w150")]
        [InquiryField(Id = 101)]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingReceiptAmoun
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingReceiptAmoun, Id = Index.FunctionalPendingReceiptAmoun, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingReceiptAmoun { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingDiscountAmou
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingDiscountAmou, Id = Index.FunctionalPendingDiscountAmou, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingDiscountAmou { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingAdjustmentAm
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingAdjustmentAm, Id = Index.FunctionalPendingAdjustmentAm, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingAdjustmentAm { get; set; }

        /// <summary>
        /// Gets or sets FunctionalPendingBalance
        /// </summary>
        [ViewField(Name = Fields.FunctionalPendingBalance, Id = Index.FunctionalPendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalPendingBalance { get; set; }

        /// <summary>
        /// Gets or sets PendingReceiptAmount
        /// </summary>
        [ViewField(Name = Fields.PendingReceiptAmount, Id = Index.PendingReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingDiscountAmount
        /// </summary>
        [ViewField(Name = Fields.PendingDiscountAmount, Id = Index.PendingDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingAdjustmentAmount
        /// </summary>
        [ViewField(Name = Fields.PendingAdjustmentAmount, Id = Index.PendingAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingBalance
        /// </summary>
        [ViewField(Name = Fields.PendingBalance, Id = Index.PendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingBalance { get; set; }

        /// <summary>
        /// Gets or sets CustomerNoUsedToCalculateP
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerNoUsedToCalculateP, Id = Index.CustomerNoUsedToCalculateP, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNoUsedToCalculateP { get; set; }

        /// <summary>
        /// Gets or sets ShowPendingAmountsSwitch
        /// </summary>
        [ViewField(Name = Fields.ShowPendingAmountsSwitch, Id = Index.ShowPendingAmountsSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public ShowPendingAmountsSwitch ShowPendingAmountsSwitch { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [InquiryField(Id = 102)]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 103)]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ARVersionCreatedIn
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 104)]
        [ViewField(Name = Fields.ARVersionCreatedIn, Id = Index.ARVersionCreatedIn, FieldType = EntityFieldType.Char, Size = 3)]
        public string ARVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [InquiryField(Id = 105)]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets DepositSerialNumber
        /// </summary>
        [InquiryField(Id = 106)]
        [ViewField(Name = Fields.DepositSerialNumber, Id = Index.DepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long DepositSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DepositLineNumber
        /// </summary>
        [InquiryField(Id = 107)]
        [ViewField(Name = Fields.DepositLineNumber, Id = Index.DepositLineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DepositLineNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 108)]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOBLJDetails
        /// </summary>
        [InquiryField(Id = 109)]
        [ViewField(Name = Fields.NumberOfOBLJDetails, Id = Index.NumberOfOBLJDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfOBLJDetails { get; set; }

        /// <summary>
        /// Gets or sets Obsolete
        /// </summary>
        [ViewField(Name = Fields.Obsolete, Id = Index.Obsolete, FieldType = EntityFieldType.Int, Size = 2)]
        public Obsolete Obsolete { get; set; }

        /// <summary>
        /// Gets or sets ShowMembers
        /// </summary>
        [ViewField(Name = Fields.ShowMembers, Id = Index.ShowMembers, FieldType = EntityFieldType.Int, Size = 2)]
        public ShowMembers ShowMembers { get; set; }

        /// <summary>
        /// Misc. Receipt Flag
        /// </summary>
        [InquiryField(Id = 110)]
        public int MiscReceiptFlag { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        [GridInfo(5, typeof(ARCommonResx), "DocumentType", Style = "w150")]
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets RateOverridden string value
        /// </summary>
        public string RateOverriddenString
        {
            get { return EnumUtility.GetStringValue(RateOverridden); }
        }

        /// <summary>
        /// Gets FullyPaid string value
        /// </summary>
        [GridInfo(10, typeof(ARCommonResx), "FullyPaid", Style = "w150")]
        public string FullyPaidString
        {
            get { return EnumUtility.GetStringValue(FullyPaid); }
        }

        /// <summary>
        /// Gets TaxOverrideSwitch string value
        /// </summary>
        public string TaxOverrideSwitchString
        {
            get { return EnumUtility.GetStringValue(TaxOverrideSwitch); }
        }

        /// <summary>
        /// Gets JobRelated string value
        /// </summary>
        [GridInfo(28, typeof(ARCommonResx), "JobRelated", Style = "w150")]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets OptionalFields string value
        /// </summary>
        [GridInfo(29, typeof(CommonResx), "OptionalFields", Style = "w150")]
        public string OptionalFieldsString
        {
            get { return OptionalFields > 0 ? CommonResx.Yes : CommonResx.No; }
        }

        /// <summary>
        /// Gets HasRetainage string value
        /// </summary>
        [GridInfo(23, typeof(ARCommonResx), "Retainage", Style = "w150")]
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets RetainageOutstanding string value
        /// </summary>
        public string RetainageOutstandingString
        {
            get { return EnumUtility.GetStringValue(RetainageOutstanding); }
        }

        /// <summary>
        /// Gets RetainageExchangeRate string value
        /// </summary>
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Gets ShowPendingAmountsSwitch string value
        /// </summary>
        public string ShowPendingAmountsSwitchString
        {
            get { return EnumUtility.GetStringValue(ShowPendingAmountsSwitch); }
        }

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString
        {
            get { return EnumUtility.GetStringValue(InvoiceType); }
        }

        /// <summary>
        /// Gets Obsolete string value
        /// </summary>
        public string ObsoleteString
        {
            get { return EnumUtility.GetStringValue(Obsolete); }
        }

        /// <summary>
        /// Gets ShowMembers string value
        /// </summary>
        public string ShowMembersString
        {
            get { return EnumUtility.GetStringValue(ShowMembers); }
        }

        #region calculated fields
        [GridInfo(15, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        public decimal CustAppliedAmount
        {
            get
            {
                return CustCurrencyAmountDue - CustCurrencyInvoiceAmount;
            }
        }

        [GridInfo(16, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        public decimal FuncAppliedAmount
        {
            get { return FuncCurrencyAmountDue - FuncCurrencyInvoiceAmount; }
        }
        #endregion

        #endregion
    }
}
