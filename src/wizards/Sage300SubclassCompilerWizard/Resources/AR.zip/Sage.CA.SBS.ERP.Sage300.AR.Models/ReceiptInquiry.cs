﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// A class to use in the Search criteria of ReceiptInquiry screen
    /// </summary>
    public class ReceiptInquiry : ModelBase
    {
        private const char Z = 'Z';

        private const int BankToRecurringLength = 8;
        private const int CustomerNumberRecurringLength = 12;
        private const int ReceiptNumberLength = 24;

        /// <summary>
        /// Gets or sets the property of IsMulticurrency
        /// </summary>
        public bool IsMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets the property of FunctionalCurrency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets the property of BankFrom
        /// </summary>
        [Display(Name = "FromBank", ResourceType = typeof(ReceiptInquiryResx))]
        [StringLength(BankToRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string BankFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of BankTo
        /// </summary>
        [Display(Name = "ToBank", ResourceType = typeof(ARCommonResx))]
        [StringLength(BankToRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string BankTo { get; set; }

        /// <summary>
        /// Gets or sets the property of CustomerFrom
        /// </summary>
        [Display(Name = "FromCustomerNumber", ResourceType = typeof(ReceiptInquiryResx))]
        [StringLength(CustomerNumberRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CustomerFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of CustomerTo
        /// </summary>
        [Display(Name = "ToCustomerNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(CustomerNumberRecurringLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CustomerTo { get; set; }

        /// <summary>
        /// Gets or sets the property of ReceiptFrom
        /// </summary>
        [Display(Name = "FromReceiptDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ReceiptFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of ReceiptTo
        /// </summary>
        [Display(Name = "ToReceiptDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ReceiptTo { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalYearFrom
        /// </summary>
        [Display(Name = "FromYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(Decimal), "1000", "9999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalYearFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalYearTo
        /// </summary>
        [Display(Name = "FromYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(Decimal), "1000", "9999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalYearTo { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalPeriodFrom
        /// </summary>
        [Display(Name = "FromYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(Decimal), "1", "99", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalPeriodFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalPeriodTo
        /// </summary>
        [Display(Name = "ToYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(Decimal), "1", "99", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalPeriodTo { get; set; }

        /// <summary>
        /// Gets or sets the ReceiptNumberFrom
        /// </summary>
        [Display(Name = "FromReceiptNumber", ResourceType = typeof(ReceiptInquiryResx))]
        [StringLength(ReceiptNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ReceiptNumberFrom { get; set; }

        /// <summary>
        /// Gets or sets the ReceiptNumberTo
        /// </summary>
        [Display(Name = "ToReceiptNumber", ResourceType = typeof(ReceiptInquiryResx))]
        [StringLength(ReceiptNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ReceiptNumberTo { get; set; }

        #region Constructor

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public ReceiptInquiry()
        {
            BankTo = CommonUtil.Repeat(Z, BankToRecurringLength);
            CustomerTo = CommonUtil.Repeat(Z, CustomerNumberRecurringLength);
            ReceiptNumberTo = CommonUtil.Repeat(Z, ReceiptNumberLength);
            ReceiptTo = DateUtil.GetMaxDate();
        }

        /// <summary>
        /// Gets or sets the property of PaymentType
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
        public PaymentMode PaymentType { get; set; }

        /// <summary>
        /// Gets or sets the property of Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        public ReceiptStatus Status { get; set; }

        /// <summary>
        /// Gets or sets the property of TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        public ReceiptTransactionType TransactionType { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultToYear { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultToPeriod { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultFromYear { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultFromPeriod { get; set; }

        #endregion
    }
}