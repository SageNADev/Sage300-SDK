// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Salesperson
    /// </summary>
    public partial class Salesperson : ModelBase
    {

        private string _salesPersonCode;
        /// <summary>
        /// Constructor
        /// </summary>
        public Salesperson()
        {
            Status = Status.Active;
            SalespersonStatistic = new SalespersonStatistic();

        }

        /// <summary>
        /// Gets or sets Salesperson 
        /// </summary>
        [Display(Name = "SalespersonCode", ResourceType = typeof (SalespersonsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        public string SalesPersonCode
        {
            get { return _salesPersonCode; }
            set
            {
                _salesPersonCode = value;
                SalespersonStatistic.Salesperson = value;
            }
        }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets EmployeeNumber 
        /// </summary>
        [Display(Name = "EmployeeNumber", ResourceType = typeof(SalespersonsResx))]
        [StringLength(15, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EmployeeNumber, Id = Index.EmployeeNumber, FieldType = EntityFieldType.Char, Size = 15)]
        public string EmployeeNumber { get; set; }

        /// <summary>
        /// Gets or sets Name 
        /// </summary>
         [Display(Name = "Name", ResourceType = typeof(CommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets CommissionsPaid 
        /// </summary>
        [Display(Name = "CommissionsPaid", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CommissionsPaid, Id = Index.CommissionsPaid, FieldType = EntityFieldType.Int, Size = 2)]
        public CommissionsPaid CommissionsPaid { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string CommissionsPaidString
        {
            get { return EnumUtility.GetStringValue(CommissionsPaid); }
        }

    /// <summary>
        /// Gets or sets AnnualSalesTarget 
        /// </summary>
         [Display(Name = "AnnualSalesTarget", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.AnnualSalesTarget, Id = Index.AnnualSalesTarget, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AnnualSalesTarget { get; set; }

        /// <summary>
        /// Gets or sets MaximumSalesforRate1 
        /// </summary>
        [Display(Name = "MaximumSalesforRate1", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.MaximumSalesforRate1, Id = Index.MaximumSalesforRate1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumSalesforRate1 { get; set; }

        /// <summary>
        /// Gets or sets MaximumSalesforRate2 
        /// </summary>
        [Display(Name = "MaximumSalesforRate2", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.MaximumSalesforRate2, Id = Index.MaximumSalesforRate2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumSalesforRate2 { get; set; }

        /// <summary>
        /// Gets or sets MaximumSalesforRate3 
        /// </summary>
        [Display(Name = "MaximumSalesforRate3", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.MaximumSalesforRate3, Id = Index.MaximumSalesforRate3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumSalesforRate3 { get; set; }

        /// <summary>
        /// Gets or sets MaximumSalesforRate4 
        /// </summary>
        [Display(Name = "MaximumSalesforRate4", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.MaximumSalesforRate4, Id = Index.MaximumSalesforRate4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumSalesforRate4 { get; set; }

        /// <summary>
        /// Gets or sets CommissionRate1 
        /// </summary>
        [Display(Name = "CommissionRate1", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CommissionRate1, Id = Index.CommissionRate1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionRate1 { get; set; }

        /// <summary>
        /// Gets or sets CommissionRate2 
        /// </summary>
        [Display(Name = "CommissionRate2", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CommissionRate2, Id = Index.CommissionRate2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionRate2 { get; set; }

        /// <summary>
        /// Gets or sets CommissionRate3 
        /// </summary>
        [Display(Name = "CommissionRate3", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CommissionRate3, Id = Index.CommissionRate3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionRate3 { get; set; }

        /// <summary>
        /// Gets or sets CommissionRate4 
        /// </summary>
        [Display(Name = "CommissionRate4", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CommissionRate4, Id = Index.CommissionRate4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionRate4 { get; set; }

        /// <summary>
        /// Gets or sets CommissionRate5 
        /// </summary>
        [Display(Name = "CommissionRate5", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CommissionRate5, Id = Index.CommissionRate5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal CommissionRate5 { get; set; }

        /// <summary>
        /// Gets or sets CommissionableSales 
        /// </summary>
          [IgnoreExportImport]
        [Display(Name = "CommissionableSales", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CommissionableSales, Id = Index.CommissionableSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CommissionableSales { get; set; }

        /// <summary>
        /// Gets or sets CostofCommissionableSales 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CostofCommissionableSales", ResourceType = typeof(SalespersonsResx))]
        [ViewField(Name = Fields.CostofCommissionableSales, Id = Index.CostofCommissionableSales, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CostofCommissionableSales { get; set; }

        /// <summary>
        /// Gets or sets DateLastCleared 
        /// </summary>
         [Display(Name = "DateLastCleared", ResourceType = typeof(SalespersonsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
        [ViewField(Name = Fields.DateLastCleared, Id = Index.DateLastCleared, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastCleared { get; set; }
         /// <summary>
         /// Gets or sets SalespersonStatistic
         /// </summary>
         public SalespersonStatistic SalespersonStatistic { get; set; }
	    
    }
}
