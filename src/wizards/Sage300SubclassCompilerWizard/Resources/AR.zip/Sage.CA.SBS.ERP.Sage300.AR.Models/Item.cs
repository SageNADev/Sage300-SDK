// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 
#region
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Status = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Status;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class for Item
    /// </summary>
    public partial class Item : ModelBase
    {
        /// <summary>
        /// Constructor for Item class.
        /// </summary>
        public Item()
        {
            PricingItems = new EnumerableResponse<ItemPricing>();
            TaxClassItems = new EnumerableResponse<ItemTaxClass>();
            StatisticItems = new EnumerableResponse<ItemStatistic>();
            ItemStatistics=new ItemStatistic();
            ItemPricing = new ItemPricing();
            Status = Status.Active;
            DiscountableVal = true;
        }

        /// <summary>
        /// Gets or sets Item Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ItemNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Commodity Code 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommodityNumber", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.CommodityCode, Id = Index.CommodityCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string CommodityCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets Inactive Date 
        /// </summary>
        [Display(Name = "InactiveAsOfDate", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof(ItemsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Distribution Code 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets Comment 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets Discountable 
        /// </summary>
        [Display(Name = "Discountable", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public Discountable Discountable { get; set; }

        /// <summary>
        /// Gets or sets Revenue Account 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Revenue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RevenueAccount, Id = Index.RevenueAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets Inventory Account 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Inventory", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InventoryAccount, Id = Index.InventoryAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InventoryAccount { get; set; }

        /// <summary>
        /// Gets or sets COGS Account 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CostOfGoodsSold", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CogsAccount, Id = Index.CogsAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CogsAccount { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        [IgnoreExportImport]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// To get the string of Discountable property
        /// </summary>
        [IgnoreExportImport]
        public string DiscountableString
        {
            get { return EnumUtility.GetStringValue(Discountable); }
        }


        /// <summary>
        /// Conversion of Inactive Date into DateTime 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        public DateTime InactiveDateFormated
        {
            get
            {
                return InactiveDate;
            }
        }

        /// <summary>
        /// Conversion of Date Last Maintained into DateTime 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DateLastMaintained", ResourceType = typeof(ItemsResx))]
        public DateTime DateLastMaintainedFormated
        {
            get
            {
                return DateLastMaintained;
            }

        }

        /// <summary>
        /// Gets or sets Distribution Code Description 
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCodeDesc", ResourceType = typeof(DistributionCodesResx))]
        public string DistributionCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets Revenue Description 
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueDescription", ResourceType = typeof(ARCommonResx))]
        public string RevenueDescription { get; set; }

        /// <summary>
        /// Gets or sets Inventory Description 
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InventoryDescription", ResourceType = typeof(ARCommonResx))]
        public string InventoryDescription { get; set; }

        /// <summary>
        /// Gets or sets Cogs Description 
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "COGSDescription", ResourceType = typeof(ItemsResx))]
        public string CogsDescription { get; set; }

        /// <summary>
        /// Discountable Value Property Switch for UI
        /// </summary>
        [IgnoreExportImport]
        public bool DiscountableVal
        {
            get { return Discountable != Discountable.No; }
            set { Discountable = value ? Discountable.Yes : Discountable.No; }
        }


        /// <summary>
        /// Gets or sets Pricing Items
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ItemPricing> PricingItems { get; set; }

        /// <summary>
        /// Gets or sets Tax Class Items
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ItemTaxClass> TaxClassItems { get; set; }

        /// <summary>
        /// Gets or sets Statistic Items
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ItemStatistic> StatisticItems { get; set; }


        /// <summary>
        /// Gets or sets Item Statistics
        /// </summary>
        [IgnoreExportImport]
        public ItemStatistic ItemStatistics { get; set; }


        /// <summary>
        /// Gets or sets Item Pricing
        /// </summary>
        [IgnoreExportImport]
        public ItemPricing ItemPricing { get; set; }

        /// <summary>
        /// Gets Account Type
        /// </summary>
        [IgnoreExportImport]
        public AccountType AccountType { get; set; }

        /// <summary>
        /// Gets list of Tax Included Items
        /// </summary>
        /// <value>Validate.</value>
        [IgnoreExportImport]
        public IEnumerable<CustomSelectList> TaxIncludedItems
        {
            get { return EnumUtility.GetItemsList<TaxIncluded>(); }
        }

    }
}
