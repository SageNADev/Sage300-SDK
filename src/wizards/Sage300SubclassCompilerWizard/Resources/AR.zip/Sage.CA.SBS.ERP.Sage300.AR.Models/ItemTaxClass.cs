// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for Item Tax Class
    /// </summary>
    public partial class ItemTaxClass : ModelBase
    {
        /// <summary>
        /// Gets or sets Item Number
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets Tax Class
        /// </summary>
        [Display(Name = "TaxClass", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClass, Id = Index.TaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass { get; set; }

        /// <summary>
        /// Gets or sets Tax Included
        /// </summary>
        [Display(Name = "TaxIncluded", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxIncluded, Id = Index.TaxIncluded, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxIncluded TaxIncluded { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Tax Included string value
        /// </summary>
        [IgnoreExportImport]
        public string TaxIncludedString
        {
            get { return EnumUtility.GetStringValue(TaxIncluded); }
        }

        /// <summary>
        /// Gets or sets Serial Number
        /// </summary>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

        #endregion
    }
}
