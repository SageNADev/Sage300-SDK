/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Invoice Detail
    /// </summary>
    public partial class InvoiceDetail : BaseInvoiceDetail
    {
        /// <summary>
        /// To get the Enum string of PrintComment property
        /// </summary>
        public string PrintCommentString
        {
            get { return EnumUtility.GetStringValue((Printed)PrintComment); }
        }

        /// <summary>
        /// To get the Enum string of Discountable String property
        /// </summary>
        public new string DiscountableString
        {
            get { return EnumUtility.GetStringValue((Printed)Discountable); }
        }

        /// <summary>
        /// To get the Enum string of Optional Fields String property
        /// </summary>
        public string OptionalFieldsString
        {
            get { return EnumUtility.GetStringValue((Printed)OptionalFields); }
        }

        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [Display(Name = "ContractCode", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode)]
        public override string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [Display(Name = "ProjectCode", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode)]
        public override string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [Display(Name = "CategoryCode", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode)]
        public override string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [Display(Name = "Resource", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource)]
        public override string ProjectOrCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets BillingDate 
        /// </summary>
        [Display(Name = "Date", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.BillingDate, Id = Index.BillingDate)]
        public override DateTime? BillingDate { get; set; }
	}
}
