﻿
/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public class CustomerInfo
    {
        /// <summary>
        /// Gets Vendor Number 
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(CustomersResx))]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Vendor Name.
        /// </summary>
        [Display(Name = "CustomerName", ResourceType = typeof(ARCommonResx))]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets Short Name 
        /// </summary>
        [Display(Name = "ShortName", ResourceType = typeof(ARCommonResx))]
        public string ShortName { get; set; }

        /// <summary>
        /// Gets Address Line1 
        /// </summary>
        [Display(Name = "Address1", ResourceType = typeof(CustomersResx))]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets Address Line2 
        /// </summary>
        [Display(Name = "Address2", ResourceType = typeof(CustomersResx))]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets Address Line3 
        /// </summary>
        [Display(Name = "Address3", ResourceType = typeof(CustomersResx))]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets Address Line4 
        /// </summary>
        [Display(Name = "Address4", ResourceType = typeof(CustomersResx))]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets City 
        /// </summary>
        [Display(Name = "City", ResourceType = typeof(ARCommonResx))]
        public string City { get; set; }

        /// <summary>
        /// Gets State Or Province
        /// </summary>
        [Display(Name = "StateProv", ResourceType = typeof(ARCommonResx))]
        public string StateOrProvince { get; set; }

        /// <summary>
        /// Gets Zip Or Postal Code 
        /// </summary>
        [Display(Name = "ZipPostalCode", ResourceType = typeof(ARCommonResx))]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets Country 
        /// </summary>
        [Display(Name = "Country", ResourceType = typeof(ARCommonResx))]
        public string Country { get; set; }

        /// <summary>
        /// Gets Phone Number 
        /// </summary>
        [Display(Name = "Phone", ResourceType = typeof(ARCommonResx))]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets Fax Number 
        /// </summary>
        [Display(Name = "ContactFax", ResourceType = typeof(ARCommonResx))]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets Email 
        /// </summary>
        [Display(Name = "Email", ResourceType = typeof(ARCommonResx))]
        public string Email { get; set; }

        /// <summary>
        /// Gets Contacts Name
        /// </summary>
        [Display(Name = "ContactsEmail", ResourceType = typeof(CustomersResx))]
        public string ContactsName { get; set; }

        /// <summary>
        /// Gets Contacts Phone
        /// </summary>
        [Display(Name = "ContactsPhone", ResourceType = typeof(CustomersResx))]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets Contacts Fax
        /// </summary>
        [Display(Name = "ContactsFax", ResourceType = typeof(CustomersResx))]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets Contacts Email 
        /// </summary>
        [Display(Name = "ContactsEmail", ResourceType = typeof(CustomersResx))]
        public string ContactsEmail { get; set; }

        //TODO ARRC
        ///// <summary>
        ///// Gets or sets Tax Reporting Type 
        ///// </summary>
        //[Display(Name = "TaxReportingType", ResourceType = typeof(VendorGroupResx))]
        //public TaxReportingType TaxReportingType { get; set; }

        /// <summary>
        /// Gets or sets OnHold 
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(ARCommonResx))]
        public OnHold OnHold { get; set; }
    }
}
