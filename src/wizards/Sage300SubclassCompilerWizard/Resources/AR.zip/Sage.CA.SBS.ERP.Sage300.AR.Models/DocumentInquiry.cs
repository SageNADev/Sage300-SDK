﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// class for Document
    /// </summary>
    public class DocumentInquiry : ModelBase
    {
        /// <summary>
        /// Gets or sets a value indicating whether [gl active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [gl active]; otherwise, <c>false</c>.
        /// </value>
        public bool GLActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [ic active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [ic active]; otherwise, <c>false</c>.
        /// </value>
        public bool ICActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [oe active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [oe active]; otherwise, <c>false</c>.
        /// </value>
        public bool OEActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [pm active].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [pm active]; otherwise, <c>false</c>.
        /// </value>
        public bool PMActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [have optional field license].
        /// </summary>
        /// <value>
        /// <c>true</c> if [have optional field license]; otherwise, <c>false</c>.
        /// </value>
        public bool HaveOptionalFieldLicense { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [have nat acct license].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [have nat acct license]; otherwise, <c>false</c>.
        /// </value>
        public bool HaveNationalAccounttLicense { get; set; }

        /// <summary>
        /// Gets or sets the home currency.
        /// </summary>
        /// <value>
        /// The home currency.
        /// </value>
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [user is admin].
        /// </summary>
        /// <value>
        ///   <c>true</c> if [user is admin]; otherwise, <c>false</c>.
        /// </value>
        public bool UserIsAdmin { get; set; }

    }
}
