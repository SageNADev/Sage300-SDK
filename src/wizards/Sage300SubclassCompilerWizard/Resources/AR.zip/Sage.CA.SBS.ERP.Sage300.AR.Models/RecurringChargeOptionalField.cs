// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Partial class for RecurringChargeOptionalField
	/// </summary>
	public partial class RecurringChargeOptionalField : ModelBase
	{

        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptAdjustmentOptionalFieldDetail"/> class.
        /// </summary>
        public RecurringChargeOptionalField()
        {
            Type = Enums.Type.Text;
            AllowBlank = AllowBlank.No;
            Validate = Validate.No;
            ValueSet = ValueSet.No;
            YesOrNoValue = YesNoValue.No;
        }

		/// <summary>
		/// Gets or sets RecurringChargeCode
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringChargeCode", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.RecurringChargeCode, Id = Index.RecurringChargeCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
		public string RecurringChargeCode { get; set; }

		/// <summary>
		/// Gets or sets CustomerNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string CustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets OptionalField
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(RecurringChargeResx))]
		[ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string OptionalField { get; set; }

		/// <summary>
		/// Gets or sets Value
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
		public string Value { get; set; }

		/// <summary>
		/// Gets or sets Type
		/// </summary>
        [Display(Name = "Type", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
		public Enums.Type Type { get; set; }

		/// <summary>
		/// Gets or sets Length
		/// </summary>
        [Display(Name = "Length", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
		public int Length { get; set; }

		/// <summary>
		/// Gets or sets Decimals
		/// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(RecurringChargeResx))]
		[ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
		public int Decimals { get; set; }

		/// <summary>
		/// Gets or sets AllowBlank
		/// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(RecurringChargeResx))]
		[ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
		public AllowBlank AllowBlank { get; set; }

		/// <summary>
		/// Gets or sets Validate
		/// </summary>
        [Display(Name = "Validate", ResourceType = typeof(RecurringChargeResx))]
		[ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
		public Validate Validate { get; set; }

		/// <summary>
		/// Gets or sets ValueSet
		/// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(RecurringChargeResx))]
		[ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
		public ValueSet ValueSet { get; set; }

		/// <summary>
		/// Gets or sets TypedValueFieldIndex
		/// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(RecurringChargeResx))]
		[ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
		public long TypedValueFieldIndex { get; set; }

		/// <summary>
		/// Gets or sets TextValue
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
		public string TextValue { get; set; }

		/// <summary>
		/// Gets or sets AmountValue
		/// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal AmountValue { get; set; }

		/// <summary>
		/// Gets or sets NumberValue
		/// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal NumberValue { get; set; }

		/// <summary>
		/// Gets or sets IntegerValue
		/// </summary>
        [Display(Name = "IntegerValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
		public long IntegerValue { get; set; }

		/// <summary>
		/// Gets or sets YesNoValue
		/// </summary>
        [Display(Name = "YesOrNoValue", ResourceType = typeof(ARCommonResx))]
		public YesNoValue YesOrNoValue { get; set; }

		/// <summary>
		/// Gets or sets DateValue
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateValue { get; set; }

		/// <summary>
		/// Gets or sets TimeValue
		/// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime TimeValue { get; set; }

		/// <summary>
		/// Gets or sets OptionalFieldDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(RecurringChargeResx))]
		[ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string OptionalFieldDescription { get; set; }

		/// <summary>
		/// Gets or sets ValueDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string ValueDescription { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Type string value
		/// </summary>
		public string TypeString
		{
			get { return EnumUtility.GetStringValue(Type); }
		}

		/// <summary>
		/// Gets AllowBlank string value
		/// </summary>
		public string AllowBlankString
		{
			get { return EnumUtility.GetStringValue(AllowBlank); }
		}

		/// <summary>
		/// Gets Validate string value
		/// </summary>
		public string ValidateString
		{
			get { return EnumUtility.GetStringValue(Validate); }
		}

		/// <summary>
		/// Gets ValueSet string value
		/// </summary>
		public string ValueSetString
		{
			get { return EnumUtility.GetStringValue(ValueSet); }
		}

		/// <summary>
		/// Gets YesNoValue string value
		/// </summary>
		public string YesNoValueString
		{
			get { return EnumUtility.GetStringValue(YesOrNoValue); }
		}

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }

		#endregion
	}
}
