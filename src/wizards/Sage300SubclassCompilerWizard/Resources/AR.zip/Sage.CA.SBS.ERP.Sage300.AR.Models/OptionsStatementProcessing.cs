// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class OptionsStatementProcessing : ModelBase
    {
        /// <summary>
        /// Gets or sets Statement Processing Options Key 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.StatementProcessingOptionsKey, Id = Index.StatementProcessingOptionsKey, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string StatementProcessingOptionsKey { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Aging Period 1 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets Aging Period 2 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets Aging Period 3 
        /// </summary>
        [ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets Age Credit Notes and Debit Notes 
        /// </summary>
        [Display(Name = "AgeUnapCNDN", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AgeCreditNotesandDebitNotes, Id = Index.AgeCreditNotesandDebitNotes, FieldType = EntityFieldType.Int, Size = 2)]
        public AgeCreditNotesandDebitNotes AgeCreditNotesandDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets Age Unapplied Cash Prepayments 
        /// </summary>
        [Display(Name = "AgeUnapCashPP", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AgeUnappliedCashPrepayments, Id = Index.AgeUnappliedCashPrepayments, FieldType = EntityFieldType.Int, Size = 2)]
        public AgeCreditNotesandDebitNotes AgeUnappliedCashPrepayments { get; set; }

        /// <summary>
        /// Gets or sets Current Dunning Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CurrentDunningMessage, Id = Index.CurrentDunningMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string CurrentDunningMessage { get; set; }

        /// <summary>
        /// Gets or sets Period 1 Dunning Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Period1DunningMessage, Id = Index.Period1DunningMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string Period1DunningMessage { get; set; }

        /// <summary>
        /// Gets or sets Period 2 Dunning Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Period2DunningMessage, Id = Index.Period2DunningMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string Period2DunningMessage { get; set; }

        /// <summary>
        /// Gets or sets Period 3 Dunning Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Period3DunningMessage, Id = Index.Period3DunningMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string Period3DunningMessage { get; set; }

        /// <summary>
        /// Gets or sets Over Period 3 Dunning Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.OverPeriod3DunningMessage, Id = Index.OverPeriod3DunningMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string OverPeriod3DunningMessage { get; set; }

        /// <summary>
        /// Gets or sets Print Zero Balance Statements 
        /// </summary>
        [Display(Name = "PrintZeroBalStmts", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.PrintZeroBalanceStatements, Id = Index.PrintZeroBalanceStatements, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType PrintZeroBalanceStatements { get; set; }

        /// <summary>
        /// Print Zero Balance Statements Yes/No for UI
        /// </summary>
        public bool PrntZeroBalanceStatements
        {
            get { return PrintZeroBalanceStatements != AllowedType.No; }
            set { PrintZeroBalanceStatements = value ? AllowedType.Yes : AllowedType.No; }
        }
    }
}
