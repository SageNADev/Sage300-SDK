/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class ARTCT : ModelBase
    {
        /// <summary>
        /// Property for Batch Type 
        /// </summary>
        [Key]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Property for Batch Number 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.CntBtch, Id = Index.CntBtch, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal CntBtch { get; set; } = 0;

        /// <summary>
        /// Property for Entry Number 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.CntEntr, Id = Index.CntEntr, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal CntEntr { get; set; } = 0;

        /// <summary>
        /// Property for Tax Authority 
        /// </summary>
        [Key]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthority", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Authority, Id = Index.Authority, FieldType = EntityFieldType.Char, Size = 12)]
        public string Authority { get; set; }

        /// <summary>
        /// Property for Vend Withheld Amount 
        /// </summary>
        [Display(Name = "TaxWithheld", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.AmtWHDTC, Id = Index.AmtWHDTC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDTC { get; set; } = 0;

        /// <summary>
        /// Property for Func Withheld Amount 
        /// </summary>
        [ViewField(Name = Fields.AmtWHDHC, Id = Index.AmtWHDHC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDHC { get; set; } = 0;
    }
}
