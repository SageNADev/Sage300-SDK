// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	public partial class SalespersonStatistic : ModelBase
	{
       

	    /// <summary>
        /// Gets or sets Salesperson 
        /// </summary>
         [Display(Name = "SalespersonCode", ResourceType = typeof(SalespersonsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		[ViewField(Name = Fields.Salesperson, Id = Index.Salesperson, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
 		public string Salesperson {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year 
        /// </summary>
          [Display(Name = "Year", ResourceType = typeof(CommonResx))]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		[ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
 		public string Year {get; set;}
		 
  		/// <summary>
        /// Gets or sets Period 
        /// </summary>
        [Display(Name = "Period", ResourceType = typeof(CommonResx))]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
 		[ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
 		public string Period {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofInvoices 
        /// </summary>
        [Display(Name = "NumberofInvoices", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.NumberofInvoices, Id = Index.NumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofCreditNotes 
        /// </summary>
        [Display(Name = "NumberofCreditNotes", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.NumberofCreditNotes, Id = Index.NumberofCreditNotes, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofCreditNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofDebitNotes 
        /// </summary>
        [Display(Name = "NumberofDebitNotes", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.NumberofDebitNotes, Id = Index.NumberofDebitNotes, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofDebitNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofReceipts 
        /// </summary>
        [Display(Name = "NumberofReceipts", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.NumberofReceipts, Id = Index.NumberofReceipts, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofReceipts {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofDiscounts 
        /// </summary>
        [Display(Name = "NumberofDiscounts", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.NumberofDiscounts, Id = Index.NumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofDiscounts {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofWriteOffs 
        /// </summary>
        [Display(Name = "NumberofWriteOffs", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.NumberofWriteOffs, Id = Index.NumberofWriteOffs, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalInvoiceAmount 
        /// </summary>
        [Display(Name = "TotalInvoiceAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.TotalInvoiceAmount, Id = Index.TotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalInvoiceAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalCreditNoteAmount 
        /// </summary>
        [Display(Name = "TotalCreditNoteAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.TotalCreditNoteAmount, Id = Index.TotalCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalCreditNoteAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDebitNoteAmount 
        /// </summary>
        [Display(Name = "TotalDebitNoteAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.TotalDebitNoteAmount, Id = Index.TotalDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDebitNoteAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalReceiptAmount 
        /// </summary>
        [Display(Name = "TotalReceiptAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.TotalReceiptAmount, Id = Index.TotalReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalReceiptAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDiscountAmount 
        /// </summary>
        [Display(Name = "TotalDiscountAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.TotalDiscountAmount, Id = Index.TotalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDiscountAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWriteOffAmount 
        /// </summary>
        [Display(Name = "TotalWriteOffAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.TotalWriteOffAmount, Id = Index.TotalWriteOffAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWriteOffAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofInvoices 
        /// </summary>
        [Display(Name = "YtdNumberofInvoices", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdNumberofInvoices, Id = Index.YtdNumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofInvoices {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofCreditNotes 
        /// </summary>
        [Display(Name = "YtdNumberofCreditNotes", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdNumberofCreditNotes, Id = Index.YtdNumberofCreditNotes, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofCreditNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofDebitNotes 
        /// </summary>
        [Display(Name = "YtdNumberofDebitNotes", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdNumberofDebitNotes, Id = Index.YtdNumberofDebitNotes, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofDebitNotes {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofReceipts 
        /// </summary>
        [Display(Name = "YtdNumberofReceipts", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdNumberofReceipts, Id = Index.YtdNumberofReceipts, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofReceipts {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofDiscounts 
        /// </summary>
        [Display(Name = "YtdNumberofDiscounts", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdNumberofDiscounts, Id = Index.YtdNumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofDiscounts {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofWriteOffs 
        /// </summary>
        [Display(Name = "YtdNumberofWriteOffs", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdNumberofWriteOffs, Id = Index.YtdNumberofWriteOffs, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalInvoiceAmount 
        /// </summary>
        [Display(Name = "YtdTotalInvoiceAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdTotalInvoiceAmount, Id = Index.YtdTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalInvoiceAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalCreditNoteAmount 
        /// </summary>
        [Display(Name = "YtdTotalCreditNoteAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdTotalCreditNoteAmount, Id = Index.YtdTotalCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalCreditNoteAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalDebitNoteAmount 
        /// </summary>
        [Display(Name = "YtdTotalDebitNoteAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdTotalDebitNoteAmount, Id = Index.YtdTotalDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalDebitNoteAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalReceiptAmount 
        /// </summary>
        [Display(Name = "YtdTotalReceiptAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdTotalReceiptAmount, Id = Index.YtdTotalReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalReceiptAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalDiscountAmount 
        /// </summary>
        [Display(Name = "YtdTotalDiscountAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdTotalDiscountAmount, Id = Index.YtdTotalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalDiscountAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalWriteOffAmount 
        /// </summary>
        [Display(Name = "YtdTotalWriteOffAmount", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.YtdTotalWriteOffAmount, Id = Index.YtdTotalWriteOffAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalWriteOffAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets EnableYTDCalculations 
        /// </summary>
        [Display(Name = "EnableYtdCalculations", ResourceType = typeof(SalespersonsResx))]
 		[ViewField(Name = Fields.EnableYtdCalculations, Id = Index.EnableYtdCalculations, FieldType = EntityFieldType.Int, Size = 2)]
 		public EnableYtdCalculations EnableYtdCalculations {get; set;}
		    }
}
