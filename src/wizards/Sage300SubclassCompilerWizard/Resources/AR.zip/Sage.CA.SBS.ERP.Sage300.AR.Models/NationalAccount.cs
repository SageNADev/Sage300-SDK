// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for National Account
    /// </summary>
    public partial class NationalAccount : ModelBase
    {
        /// <summary>
        /// Gets or sets National Account Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "NationalAccountNo1", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets Group Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GroupCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets Inactive Date 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets On Hold 
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold OnHold { get; set; }

        /// <summary>
        /// Gets or sets Credit Bureau Number 
        /// </summary>
        [Display(Name = "CreditBureauNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditBureauNumber, Id = Index.CreditBureauNumber, FieldType = EntityFieldType.Char, Size = 9)]
        public string CreditBureauNumber { get; set; }

        /// <summary>
        /// Gets or sets Credit Bureau Rating 
        /// </summary>
        [Display(Name = "CreditBureauRating", ResourceType = typeof(ARCommonResx))]
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditBureauRating, Id = Index.CreditBureauRating, FieldType = EntityFieldType.Char, Size = 5)]
        public string CreditBureauRating { get; set; }

        /// <summary>
        /// Gets or sets Credit Bureau Date 
        /// </summary>
        [Display(Name = "CreditBureauDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditBureauDate, Id = Index.CreditBureauDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? CreditBureauDate { get; set; }

        /// <summary>
        /// Gets or sets National Account Name 
        /// </summary>
        [Display(Name = "NationalAccountName", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NationalAccountName, Id = Index.NationalAccountName, FieldType = EntityFieldType.Char, Size = 60)]
        public string NationalAccountName { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1 
        /// </summary>
        [Display(Name = "Add1", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2 
        /// </summary>
        [Display(Name = "Add2", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3 
        /// </summary>
        [Display(Name = "Add3", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4 
        /// </summary>
        [Display(Name = "Add4", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [Display(Name = "City", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets State Or Prov 
        /// </summary>
        [Display(Name = "StateProv", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StateOrProv, Id = Index.StateOrProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateOrProv { get; set; }

        /// <summary>
        /// Gets or sets Zip Or Postal Code 
        /// </summary>
        [Display(Name = "ZipPostalCode", ResourceType = typeof(ARCommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [Display(Name = "Country", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets Contact Name 
        /// </summary>
        [Display(Name = "Contact", ResourceType = typeof(ARCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets Phone Number 
        /// </summary>
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets Fax Number 
        /// </summary>
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Account Set 
        /// </summary>
        [Display(Name = "AccountSet", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets Autocash Profile 
        /// </summary>
        [Display(Name = "AutocashProfile", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AutocashProfile, Id = Index.AutocashProfile, FieldType = EntityFieldType.Char, Size = 6)]
        public string AutocashProfile { get; set; }

        /// <summary>
        /// Gets or sets Billing Cycle 
        /// </summary>
        [Display(Name = "BillingCycle", ResourceType = typeof(ARCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillingCycle, Id = Index.BillingCycle, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillingCycle { get; set; }

        /// <summary>
        /// Gets or sets Interest Profile 
        /// </summary>
        [Display(Name = "InterestProfile", ResourceType = typeof(ARCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InterestProfile, Id = Index.InterestProfile, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InterestProfile { get; set; }

        /// <summary>
        /// Gets or sets Currency Code 
        /// </summary>
        [Display(Name = "CurrencyCode", ResourceType = typeof(ARCommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets Print Statements 
        /// </summary>
        [Display(Name = "PrintStatements", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PrintStatements, Id = Index.PrintStatements, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold PrintStatements { get; set; }

        /// <summary>
        /// Gets or sets Account Type 
        /// </summary>
        [Display(Name = "AccountType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AccountType, Id = Index.AccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public NationalAccountType AccountType { get; set; }

        /// <summary>
        /// Gets or sets Rate Type 
        /// </summary>
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets Credit Limit 
        /// </summary>
        [Display(Name = "CreditLimit", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CreditLimit, Id = Index.CreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit { get; set; }

        /// <summary>
        /// Gets or sets Balance Due in Cust Currency 
        /// </summary>
        [Display(Name = "BalanceDueinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.BalanceDueinCustCurrency, Id = Index.BalanceDueinCustCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceDueinCustCurrency { get; set; }

        /// <summary>
        /// Gets or sets Balance Due in Func Currency 
        /// </summary>
        [Display(Name = "BalanceDueinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.BalanceDueinFuncCurrency, Id = Index.BalanceDueinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceDueinFuncCurrency { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Statement 
        /// </summary>
        [Display(Name = "DateofLastStatement", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.DateofLastStatement, Id = Index.DateofLastStatement, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastStatement { get; set; }

        /// <summary>
        /// Gets or sets Last Statement Total Cust Curr 
        /// </summary>
        [Display(Name = "LastStatementTotalCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastStatementTotalCustCurr, Id = Index.LastStatementTotalCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastStatementTotalCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Statement Total Func Curr 
        /// </summary>
        [Display(Name = "LastStatementTotalFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastStatementTotalFuncCurr, Id = Index.LastStatementTotalFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastStatementTotalFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Date Balance Forward Begins 
        /// </summary>
        [Display(Name = "DateBalanceForwardBegins", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.DateBalanceForwardBegins, Id = Index.DateBalanceForwardBegins, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateBalanceForwardBegins { get; set; }

        /// <summary>
        /// Gets or sets Balance Forward Cust Curr 
        /// </summary>
        [Display(Name = "BalanceForwardCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.BalanceForwardCustCurr, Id = Index.BalanceForwardCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceForwardCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Balance Forward Func Curr 
        /// </summary>
        [Display(Name = "BalanceForwardFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.BalanceForwardFuncCurr, Id = Index.BalanceForwardFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceForwardFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Number of Open Documents 
        /// </summary>
        [Display(Name = "NumberofOpenDocuments", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofOpenDocuments, Id = Index.NumberofOpenDocuments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofOpenDocuments { get; set; }

        /// <summary>
        /// Gets or sets Number of Paid Invoices 
        /// </summary>
        [Display(Name = "NumberofPaidInvoices", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofPaidInvoices, Id = Index.NumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets Number of Days to Pay 
        /// </summary>
        [Display(Name = "NumberofDaystoPay", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets Average Days to Pay 
        /// </summary>
        [Display(Name = "AverageDaystoPay", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.AverageDaystoPay, Id = Index.AverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 1)]
        public decimal AverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets Date of Largest Invoice 
        /// </summary>
        [Display(Name = "DateofLargestInvoice", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLargestInvoice, Id = Index.DateofLargestInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets Date of Highest Balance 
        /// </summary>
        [Display(Name = "DateofHighestBalance", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofHighestBalance, Id = Index.DateofHighestBalance, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofHighestBalance { get; set; }

        /// <summary>
        /// Gets or sets Date of Largest Invoice Last Yr 
        /// </summary>
        [Display(Name = "DateofLargestInvoiceLastYr", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLargestInvoiceLastYr, Id = Index.DateofLargestInvoiceLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLargestInvoiceLastYr { get; set; }

        /// <summary>
        /// Gets or sets Date of Highest Bal Last Yr 
        /// </summary>
        [Display(Name = "DateofHighestBalLastYr", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofHighestBalLastYr, Id = Index.DateofHighestBalLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofHighestBalLastYr { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Activity 
        /// </summary>
        [Display(Name = "DateofLastActivity", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastActivity, Id = Index.DateofLastActivity, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastActivity { get; set; }

        /// <summary>
        /// Gets or sets DateofLastInvoice 
        /// </summary>
        [Display(Name = "DateofLastInvoice", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastInvoice, Id = Index.DateofLastInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastInvoice { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Credit Note 
        /// </summary>
        [Display(Name = "DateofLastCreditNote", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastCreditNote, Id = Index.DateofLastCreditNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastCreditNote { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Debit Note 
        /// </summary>
        [Display(Name = "DateofLastDebitNote", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastDebitNote, Id = Index.DateofLastDebitNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastDebitNote { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Receipt 
        /// </summary>
        [Display(Name = "DateofLastReceipt", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastReceipt, Id = Index.DateofLastReceipt, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastReceipt { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Discount 
        /// </summary>
        [Display(Name = "DateofLastDiscount", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastDiscount, Id = Index.DateofLastDiscount, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastDiscount { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Adjustment 
        /// </summary>
        [Display(Name = "DateofLastAdjustment", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastAdjustment, Id = Index.DateofLastAdjustment, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastAdjustment { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Write Off 
        /// </summary>
        [Display(Name = "DateofLastWriteOff", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastWriteOff, Id = Index.DateofLastWriteOff, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastWriteOff { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Returned Check 
        /// </summary>
        [Display(Name = "DateofLastReturnedCheck", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastReturnedCheck, Id = Index.DateofLastReturnedCheck, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastReturnedCheck { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Interest Charge 
        /// </summary>
        [Display(Name = "DateofLastInterestCharge", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastInterestCharge, Id = Index.DateofLastInterestCharge, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastInterestCharge { get; set; }

        /// <summary>
        /// Gets or sets Largest Invoice Number 
        /// </summary>
        [Display(Name = "LargestInvoiceNumber", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LargestInvoiceNumber, Id = Index.LargestInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string LargestInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets Largest Invoice Number Last Yr 
        /// </summary>
        [Display(Name = "LargestInvoiceNumberLastYr", ResourceType = typeof(NationalAccountsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LargestInvoiceNumberLastYr, Id = Index.LargestInvoiceNumberLastYr, FieldType = EntityFieldType.Char, Size = 22)]
        public string LargestInvoiceNumberLastYr { get; set; }

        /// <summary>
        /// Gets or sets Largest Invoice Cust Curr 
        /// </summary>
        [Display(Name = "LargestInvoiceCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LargestInvoiceCustCurr, Id = Index.LargestInvoiceCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Highest Balance Cust Curr 
        /// </summary>
        [Display(Name = "HighestBalanceCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.HighestBalanceCustCurr, Id = Index.HighestBalanceCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Lgst Inv Last Yr Cust Curr 
        /// </summary>
        [Display(Name = "LgstInvLastYrCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LgstInvLastYrCustCurr, Id = Index.LgstInvLastYrCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LgstInvLastYrCustCurr { get; set; }

        /// <summary>
        /// Gets or sets High Bal Last Yr Cust Curr 
        /// </summary>
        [Display(Name = "HighBalLastYrCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.HighBalLastYrCustCurr, Id = Index.HighBalLastYrCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYrCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Invoice Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastInvoiceAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastInvoiceAmtCustCurr, Id = Index.LastInvoiceAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Cr Note Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastCrNoteAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastCrNoteAmtCustCurr, Id = Index.LastCrNoteAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Dr Note Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastDrNoteAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastDrNoteAmtCustCurr, Id = Index.LastDrNoteAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Receipt Cust Curr 
        /// </summary>
        [Display(Name = "LastReceiptCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastReceiptCustCurr, Id = Index.LastReceiptCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastReceiptCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Discount Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastDiscountAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastDiscountAmtCustCurr, Id = Index.LastDiscountAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Adj Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastAdjAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastAdjAmtCustCurr, Id = Index.LastAdjAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Write Off Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastWriteOffAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastWriteOffAmtCustCurr, Id = Index.LastWriteOffAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastWriteOffAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Retd Chk Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastRetdChkAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastRetdChkAmtCustCurr, Id = Index.LastRetdChkAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRetdChkAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Int Charge Cust Curr 
        /// </summary>
        [Display(Name = "LastIntChargeCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastIntChargeCustCurr, Id = Index.LastIntChargeCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastIntChargeCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Largest Invoice Func Curr 
        /// </summary>
        [Display(Name = "LargestInvoiceFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LargestInvoiceFuncCurr, Id = Index.LargestInvoiceFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Highest Balance Func Curr 
        /// </summary>
        [Display(Name = "HighestBalanceFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.HighestBalanceFuncCurr, Id = Index.HighestBalanceFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Lgst Inv Last Yr Func Curr 
        /// </summary>
        [Display(Name = "LgstInvLastYrFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LgstInvLastYrFuncCurr, Id = Index.LgstInvLastYrFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LgstInvLastYrFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets High Bal Last Yr Func Curr 
        /// </summary>
        [Display(Name = "HighBalLastYrFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.HighBalLastYrFuncCurr, Id = Index.HighBalLastYrFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYrFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Invoice Amt Func Curr 
        /// </summary>
        [Display(Name = "LastInvoiceAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastInvoiceAmtFuncCurr, Id = Index.LastInvoiceAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Cr Note Amt Func Curr 
        /// </summary>
        [Display(Name = "LastCrNoteAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastCrNoteAmtFuncCurr, Id = Index.LastCrNoteAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Dr Note Amt Func Curr 
        /// </summary>
        [Display(Name = "LastDrNoteAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastDrNoteAmtFuncCurr, Id = Index.LastDrNoteAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Receipt Func Curr 
        /// </summary>
        [Display(Name = "LastReceiptFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastReceiptFuncCurr, Id = Index.LastReceiptFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastReceiptFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Discount Amt Func Curr 
        /// </summary>
        [Display(Name = "LastDiscountAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastDiscountAmtFuncCurr, Id = Index.LastDiscountAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Adj Amt Func Curr 
        /// </summary>
        [Display(Name = "LastAdjAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastAdjAmtFuncCurr, Id = Index.LastAdjAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Write Off Amt Func Curr 
        /// </summary>
        [Display(Name = "LastWriteOffAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastWriteOffAmtFuncCurr, Id = Index.LastWriteOffAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastWriteOffAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Retd Chk Amt Func Curr 
        /// </summary>
        [Display(Name = "LastRetdChkAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastRetdChkAmtFuncCurr, Id = Index.LastRetdChkAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRetdChkAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Int Charge Func Curr 
        /// </summary>
        [Display(Name = "LastIntChargeFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastIntChargeFuncCurr, Id = Index.LastIntChargeFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastIntChargeFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Email 
        /// </summary>
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Web Site 
        /// </summary>
        [Display(Name = "WebSite", ResourceType = typeof(ARCommonResx))]
        [StringLength(100, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.WebSite, Id = Index.WebSite, FieldType = EntityFieldType.Char, Size = 100)]
        public string WebSite { get; set; }

        /// <summary>
        /// Gets or sets Contacts Phone 
        /// </summary>
        [Display(Name = "ContactPhone", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactsPhone, Id = Index.ContactsPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets Contacts Fax 
        /// </summary>
        [Display(Name = "ContactFax", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactsFax, Id = Index.ContactsFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets Contacts Email 
        /// </summary>
        [Display(Name = "ContactEmail", ResourceType = typeof(ARCommonResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactsEmail, Id = Index.ContactsEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets Delivery Method 
        /// </summary>
        [Display(Name = "DeliveryMethod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DeliveryMethod, Id = Index.DeliveryMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DeliveryMethodNationalAccount DeliveryMethod { get; set; }

        /// <summary>
        /// Gets or sets Amount Retained Cust Curr 
        /// </summary>
        [Display(Name = "AmountRetainedCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.AmountRetainedCustCurr, Id = Index.AmountRetainedCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountRetainedCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Amount Retained Func Curr 
        /// </summary>
        [Display(Name = "AmountRetainedFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.AmountRetainedFuncCurr, Id = Index.AmountRetainedFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountRetainedFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Optional Fields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Process Command Code 
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public NationalAccountProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets Date of Last Refund 
        /// </summary>
        [Display(Name = "DateofLastRefund", ResourceType = typeof(NationalAccountsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastRefund, Id = Index.DateofLastRefund, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastRefund { get; set; }

        /// <summary>
        /// Gets or sets Last Refund Amt Cust Curr 
        /// </summary>
        [Display(Name = "LastRefundAmtCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastRefundAmtCustCurr, Id = Index.LastRefundAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRefundAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Last Refund Amt Func Curr 
        /// </summary>
        [Display(Name = "LastRefundAmtFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.LastRefundAmtFuncCurr, Id = Index.LastRefundAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRefundAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Check Credit Limit 
        /// </summary>
        [Display(Name = "CheckCreditLimit", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckCreditLimit, Id = Index.CheckCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold CheckCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets Check Overdue Amounts 
        /// </summary>
        [Display(Name = "CheckOverdueAmounts", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckOverdueAmounts, Id = Index.CheckOverdueAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold CheckOverdueAmounts { get; set; }

        /// <summary>
        /// Gets or sets Days Overdue 
        /// </summary>
        [Display(Name = "DaysOverdue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DaysOverdue, Id = Index.DaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets Amount Overdue 
        /// </summary>
        [Display(Name = "AmountOverdue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountOverdue, Id = Index.AmountOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOverdue { get; set; }

        /// <summary>
        /// Gets or sets the national account optional field
        /// </summary>
        public EnumerableResponse<NationalAccountOptionalField> NationalAccountOptionalFields { get; set; }
        /// <summary>
        /// Gets or sets the national account contact form
        /// </summary>
        public EnumerableResponse<NationalAccountContactForm> NationalAccountContactForms { get; set; }

        #region Finder Properties

        /// <summary>
        /// Gets the status string
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets the on hold string
        /// </summary>
        public string OnHoldString
        {
            get { return EnumUtility.GetStringValue(OnHold); }
        }

        /// <summary>
        /// Gets the account type string
        /// </summary>
        public string AccountTypeString
        {
            get { return EnumUtility.GetStringValue(AccountType); }
        }

        /// <summary>
        /// Gets the print statements string
        /// </summary>
        public string PrintStatementsString
        {
            get { return EnumUtility.GetStringValue(PrintStatements); }
        }

        /// <summary>
        /// Gets the delivery method string
        /// </summary>
        public string DeliveryMethodString
        {
            get { return EnumUtility.GetStringValue(DeliveryMethod); }
        }

        /// <summary>
        /// Gets the process command code string
        /// </summary>
        public string ProcessCommandCodeString
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
        /// Gets the check credit limit string.
        /// </summary>
        public string CheckCreditLimitString
        {
            get { return EnumUtility.GetStringValue(CheckCreditLimit); }
        }

        /// <summary>
        /// Gets the check overdue amounts string
        /// </summary>
        public string CheckOverdueAmountsString
        {
            get { return EnumUtility.GetStringValue(CheckOverdueAmounts); }
        }

        /// <summary>
        /// Gets or sets DeliveryMethodList
        /// </summary>
        public IEnumerable<CustomSelectList> DeliveryMethodList { get; set; }

        #endregion
    }

    /// <summary>
    ///  National Account contact form model
    /// </summary>
    public class NationalAccountContactForm : ModelBase
    {
        public NationalAccountContactForm()
        {
            Columns = new Dictionary<string, string>();
        }
        public Dictionary<string, string> Columns { get; set; }
        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        public long LineNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        public string IDNATACCT { get; set; }

        /// <summary>
        /// Gets or sets contactId
        /// </summary>
        public string IDCONTACT { get; set; }

        /// <summary>
        /// Gets or sets Email address
        /// </summary>
        public string EMAIL { get; set; }
    }
}
