// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class ReprintStatementHeader : ModelBase
    {

        /// <summary>
        /// Gets or sets StatementRunNumber 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.StatementRunNumber, Id = Index.StatementRunNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long StatementRunNumber { get; set; }

        /// <summary>
        /// Gets or sets StatementRunDate 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.StatementRunDate, Id = Index.StatementRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StatementRunDate { get; set; }

        /// <summary>
        ///  Gets or sets StatementRunCompletedFlag
        /// </summary>
        [ViewField(Name = Fields.StatementRunCompletedFlag, Id = Index.StatementRunCompletedFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public StatementRunCompletedFlag StatementRunCompletedFlag { get; set; }

        /// <summary>
        /// Gets or sets StatementRunCompletedFlag for finder
        /// </summary>

        public string StatementRunCompletedFlagDec
        {
            get { return EnumUtility.GetStringValue(StatementRunCompletedFlag); }
        }

        /// <summary>
        /// Gets or sets CutoffDate 
        /// </summary>
       [ViewField(Name = Fields.CutoffDate, Id = Index.CutoffDate, FieldType = EntityFieldType.Date, Size = 5)]
       public DateTime CutoffDate { get; set; }

        /// <summary>
        /// Gets or sets DueDateOrInvoiceDate 
        /// </summary>

        [ViewField(Name = Fields.DueDateOrInvoiceDate, Id = Index.DueDateOrInvoiceDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DueDateOrInvoiceDate DueDateOrInvoiceDate { get; set; }

        /// <summary>
        /// Sets for finder
        /// </summary>
        public string DueDateOrInvoiceDateDesc
        {
            get { return EnumUtility.GetStringValue(DueDateOrInvoiceDate); }
        }

        /// <summary>
        /// Gets or sets IncludeDebitBalances 
        /// </summary>

        [ViewField(Name = Fields.IncludeDebitBalances, Id = Index.IncludeDebitBalances, FieldType = EntityFieldType.Int, Size = 2)]
        public string IncludeDebitBalances { get; set; }

        /// <summary>
        /// Gets or sets IncludeCreditBalances 
        /// </summary>

        [ViewField(Name = Fields.IncludeCreditBalances, Id = Index.IncludeCreditBalances, FieldType = EntityFieldType.Int, Size = 2)]
        public string IncludeCreditBalances { get; set; }

        /// <summary>
        /// Gets or sets IncludeZeroBalances 
        /// </summary>

        [ViewField(Name = Fields.IncludeZeroBalances, Id = Index.IncludeZeroBalances, FieldType = EntityFieldType.Int, Size = 2)]
        public string IncludeZeroBalances { get; set; }

        /// <summary>
        /// Gets or sets IncludeFullyPaidTransactions 
        /// </summary>

        [ViewField(Name = Fields.IncludeFullyPaidTransactions, Id = Index.IncludeFullyPaidTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public string IncludeFullyPaidTransactions { get; set; }

        /// <summary>
        /// Gets or sets IncludeDetails 
        /// </summary>

        [ViewField(Name = Fields.IncludeDetails, Id = Index.IncludeDetails, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludeDetails IncludeDetails { get; set; }

        /// <summary>
        /// Gets for finder
        /// </summary>
        public string IncludeDetailsDesc
        {
            get { return EnumUtility.GetStringValue(IncludeDetails); }
        }

        /// <summary>
        /// Gets or sets RunType 
        /// </summary>

        [ViewField(Name = Fields.RunType, Id = Index.RunType, FieldType = EntityFieldType.Int, Size = 2)]
        public RunType RunType { get; set; }

        /// <summary>
        /// for finder
        /// </summary>
        public string RunTypeDesc
        {
            get { return EnumUtility.GetStringValue(RunType); }
        }

        /// <summary>
        /// Gets or sets DetailSort 
        /// </summary>

        [ViewField(Name = Fields.DetailSort, Id = Index.DetailSort, FieldType = EntityFieldType.Int, Size = 2)]
        public DetailSort DetailSort { get; set; }

        /// <summary>
        /// Sets for finder
        /// </summary>
        public string DetailSortDesc
        {
            get { return EnumUtility.GetStringValue(DetailSort); }
        }

        /// <summary>
        /// Gets or sets DunningMessageCode 
        /// </summary>
       [ViewField(Name = Fields.DunningMessageCode, Id = Index.DunningMessageCode, FieldType = EntityFieldType.Char, Size = 8)]
       public string DunningMessageCode { get; set; }

        /// <summary>
        /// Gets or sets Range1From 
        /// </summary>
       [ViewField(Name = Fields.Range1From, Id = Index.Range1From, FieldType = EntityFieldType.Char, Size = 60)]
       public string Range1From { get; set; }

        /// <summary>
        /// Gets or sets Range1To 
        /// </summary>
       [ViewField(Name = Fields.Range1To, Id = Index.Range1To, FieldType = EntityFieldType.Char, Size = 60)]
       public string Range1To { get; set; }

        /// <summary>
        /// Gets or sets Range1Type 
        /// </summary>

        [ViewField(Name = Fields.Range1Type, Id = Index.Range1Type, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range1Type { get; set; }

        /// <summary>
        /// Gets or sets Range2From 
        /// </summary>
       [ViewField(Name = Fields.Range2From, Id = Index.Range2From, FieldType = EntityFieldType.Char, Size = 60)]
       public string Range2From { get; set; }

        /// <summary>
        /// Gets or sets Range2To 
        /// </summary>
       [ViewField(Name = Fields.Range2To, Id = Index.Range2To, FieldType = EntityFieldType.Char, Size = 60)]
       public string Range2To { get; set; }

        /// <summary>
        /// Gets or sets Range2Type 
        /// </summary>

        [ViewField(Name = Fields.Range2Type, Id = Index.Range2Type, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range2Type { get; set; }

        /// <summary>
        /// Gets or sets Range3From 
        /// </summary>
        [ViewField(Name = Fields.Range3From, Id = Index.Range3From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range3From { get; set; }

        /// <summary>
        /// Gets or sets Range3To 
        /// </summary>
       [ViewField(Name = Fields.Range3To, Id = Index.Range3To, FieldType = EntityFieldType.Char, Size = 60)]
       public string Range3To { get; set; }

        /// <summary>
        /// Gets or sets Range3Type 
        /// </summary>

        [ViewField(Name = Fields.Range3Type, Id = Index.Range3Type, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range3Type { get; set; }

        /// <summary>
        /// Gets or sets Range4From 
        /// </summary>
        [ViewField(Name = Fields.Range4From, Id = Index.Range4From, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4From { get; set; }

        /// <summary>
        /// Gets or sets Range4To 
        /// </summary>
        [ViewField(Name = Fields.Range4To, Id = Index.Range4To, FieldType = EntityFieldType.Char, Size = 60)]
        public string Range4To { get; set; }

        /// <summary>
        /// Gets or sets Range4Type 
        /// </summary>

        [ViewField(Name = Fields.Range4Type, Id = Index.Range4Type, FieldType = EntityFieldType.Int, Size = 2)]
        public int Range4Type { get; set; }

        /// <summary>
        /// Gets or sets ReportName 
        /// </summary>
        [ViewField(Name = Fields.ReportName, Id = Index.ReportName, FieldType = EntityFieldType.Char, Size = 255)]
        public string ReportName { get; set; }

        /// <summary>
        /// Gets or sets DeliveryMethod 
        /// </summary>

        [ViewField(Name = Fields.DeliveryMethod, Id = Index.DeliveryMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public string DeliveryMethod { get; set; }

        /// <summary>
        /// Gets or sets Sortfield1 
        /// </summary>

        [ViewField(Name = Fields.Sortfield1, Id = Index.Sortfield1, FieldType = EntityFieldType.Int, Size = 2)]
        public int Sortfield1 { get; set; }

        /// <summary>
        /// Gets or sets Sortfield2 
        /// </summary>

        [ViewField(Name = Fields.Sortfield2, Id = Index.Sortfield2, FieldType = EntityFieldType.Int, Size = 2)]
        public int Sortfield2 { get; set; }

        /// <summary>
        /// Gets or sets Sortfield3 
        /// </summary>

        [ViewField(Name = Fields.Sortfield3, Id = Index.Sortfield3, FieldType = EntityFieldType.Int, Size = 2)]
        public int Sortfield3 { get; set; }

        /// <summary>
        /// Gets or sets Sortfield4 
        /// </summary>

        [ViewField(Name = Fields.Sortfield4, Id = Index.Sortfield4, FieldType = EntityFieldType.Int, Size = 2)]
        public int Sortfield4 { get; set; }

        /// <summary>
        /// Gets or sets Current 
        /// </summary>

        [ViewField(Name = Fields.Current, Id = Index.Current, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal Current { get; set; }

        /// <summary>
        /// Gets or sets FirstPeriod 
        /// </summary>

        [ViewField(Name = Fields.FirstPeriod, Id = Index.FirstPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal FirstPeriod { get; set; }

        /// <summary>
        /// Gets or sets SecondPeriod 
        /// </summary>

        [ViewField(Name = Fields.SecondPeriod, Id = Index.SecondPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SecondPeriod { get; set; }

        /// <summary>
        /// Gets or sets ThirdPeriod 
        /// </summary>

        [ViewField(Name = Fields.ThirdPeriod, Id = Index.ThirdPeriod, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ThirdPeriod { get; set; }

        /// <summary>
        /// Gets or sets SelectCustomersBasedOnOverdu 
        /// </summary>

        [ViewField(Name = Fields.SelectCustomersBasedOnOverdu, Id = Index.SelectCustomersBasedOnOverdu, FieldType = EntityFieldType.Int, Size = 2)]
        public StatementRunCompletedFlag SelectCustomersBasedOnOverdu { get; set; }

        /// <summary>
        /// Gets or sets NumberofOverdueDaysandLater 
        /// </summary>

        [ViewField(Name = Fields.NumberofOverdueDaysandLater, Id = Index.NumberofOverdueDaysandLater, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofOverdueDaysandLater { get; set; }

        /// <summary>
        /// Gets or sets OpenItemStatementType 
        /// </summary>

        [ViewField(Name = Fields.OpenItemStatementType, Id = Index.OpenItemStatementType, FieldType = EntityFieldType.Int, Size = 2)]
        public OpenItemStatementType OpenItemStatementType { get; set; }

        /// <summary>
        /// Get for Finder 
        /// </summary>
        public string OpenItemStatementTypeDesc
        {
            get { return EnumUtility.GetStringValue(OpenItemStatementType); }
        }
    }
}
