// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.AR.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for JobResourceValidation
    /// </summary>
    public partial class JobResourceValidation : ModelBase
    {
        /// <summary>
        /// Gets or sets ContractCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractCode", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryCode", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Resource", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets FormattedContractCode
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FormattedContractCode", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.FormattedContractCode, Id = Index.FormattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string FormattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [Display(Name = "AccountingMethod", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public int AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [Display(Name = "ProjectType", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProjectType { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BillingsAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingsAccount", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.BillingsAccount, Id = Index.BillingsAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string BillingsAccount { get; set; }

        /// <summary>
        /// Gets or sets RevenueAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RevenueAccount", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.RevenueAccount, Id = Index.RevenueAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets ContractDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContractDescription", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ContractDescription, Id = Index.ContractDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContractDescription { get; set; }

        /// <summary>
        /// Gets or sets ProjectDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectDescription", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ProjectDescription, Id = Index.ProjectDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ProjectDescription { get; set; }

        /// <summary>
        /// Gets or sets CategoryDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CategoryDescription", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.CategoryDescription, Id = Index.CategoryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CategoryDescription { get; set; }

        /// <summary>
        /// Gets or sets ResourceDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ResourceDescription", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ResourceDescription, Id = Index.ResourceDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ResourceDescription { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ContractOpened
        /// </summary>
        [Display(Name = "ContractOpened", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ContractOpened, Id = Index.ContractOpened, FieldType = EntityFieldType.Int, Size = 2)]
        public int ContractOpened { get; set; }

        /// <summary>
        /// Gets or sets ProjectOpened
        /// </summary>
        [Display(Name = "ProjectOpened", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ProjectOpened, Id = Index.ProjectOpened, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProjectOpened { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets SilentMode
        /// </summary>
        [Display(Name = "SilentMode", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.SilentMode, Id = Index.SilentMode, FieldType = EntityFieldType.Int, Size = 2)]
        public int SilentMode { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.JobResourceValidationDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets PercentRetained
        /// </summary>
        [Display(Name = "PercentRetained", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.PercentRetained, Id = Index.PercentRetained, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentRetained { get; set; }

        /// <summary>
        /// Gets or sets DaysRetained
        /// </summary>
        [Display(Name = "DaysRetained", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.DaysRetained, Id = Index.DaysRetained, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysRetained { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTermsCode", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageInvoice
        /// </summary>
        [Display(Name = "RetainageInvoice", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.RetainageInvoice, Id = Index.RetainageInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.RetainageInvoice RetainageInvoice { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [Display(Name = "ProjectStyle", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ARInvoiceType
        /// </summary>
        [Display(Name = "ARInvoiceType", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ARInvoiceType, Id = Index.ARInvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public int ARInvoiceType { get; set; }

        /// <summary>
        /// Gets or sets ProjectInvoicingToMultiCust
        /// </summary>
        [Display(Name = "ProjectInvoicingToMultiCust", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.ProjectInvoicingToMultiCust, Id = Index.ProjectInvoicingToMultiCust, FieldType = EntityFieldType.Int, Size = 2)]
        public Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.ProjectInvoicingToMultiCust ProjectInvoicingToMultiCust { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof (JobResourceValidationResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxGroup { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString
        {
         get { return EnumUtility.GetStringValue(CostClass); }
        }

        /// <summary>
        /// Gets BillingType string value
        /// </summary>
        public string BillingTypeString
        {
         get { return EnumUtility.GetStringValue(BillingType); }
        }

        /// <summary>
        /// Gets InvoiceType string value
        /// </summary>
        public string InvoiceTypeString
        {
         get { return EnumUtility.GetStringValue(InvoiceType); }
        }

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        public string DocumentTypeString
        {
         get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets RetainageInvoice string value
        /// </summary>
        public string RetainageInvoiceString
        {
         get { return EnumUtility.GetStringValue(RetainageInvoice); }
        }

        /// <summary>
        /// Gets ProjectInvoicingToMultiCust string value
        /// </summary>
        public string ProjectInvoicingToMultiCustString
        {
         get { return EnumUtility.GetStringValue(ProjectInvoicingToMultiCust); }
        }

        #endregion
    }
}
