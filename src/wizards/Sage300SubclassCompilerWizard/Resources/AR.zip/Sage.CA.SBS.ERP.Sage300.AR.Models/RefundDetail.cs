// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for RefundDetail
    /// </summary>
    public partial class RefundDetail : ModelBase
    {
        /// <summary>
        /// Constructor for RefundDetail
        /// </summary>
        public RefundDetail()
        {
            PaymentType = RefundPaymentType.Cash;
            CcRateOperator = CcRateOperator.Multiply;
            PaymentTypeList = EnumUtility.GetItemsList<RefundPaymentType>();
        }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber
        /// </summary>
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentType
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public RefundPaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets CCBankAccount
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditCardBank", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcBankAccount, Id = Index.CcBankAccount, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string CcBankAccount { get; set; }

        /// <summary>
        /// Gets or sets CCBankSerialNumber
        /// </summary>
        [Display(Name = "CCBankSerialNumber", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcBankSerialNumber, Id = Index.CcBankSerialNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long CcBankSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets CCPaymentCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CCPaymentCurrency", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcPaymentCurrency, Id = Index.CcPaymentCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CcPaymentCurrency { get; set; }

        /// <summary>
        /// Gets or sets CCRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CCRateType", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcRateType, Id = Index.CcRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CcRateType { get; set; }

        /// <summary>
        /// Gets or sets CCRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CCRateDate", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcRateDate, Id = Index.CcRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? CcRateDate { get; set; }

        /// <summary>
        /// Gets or sets CCExchangeRate
        /// </summary>
        [Display(Name = "CCExchangeRate", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcExchangeRate, Id = Index.CcExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CcExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets CCRateOperator
        /// </summary>
        [Display(Name = "CCRateOperator", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcRateOperator, Id = Index.CcRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public CcRateOperator CcRateOperator { get; set; }

        /// <summary>
        /// Gets or sets CCRateOverrideFlag
        /// </summary>
        [Display(Name = "CCRateOverrideFlag", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcRateOverrideFlag, Id = Index.CcRateOverrideFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public CcRateOverrideFlag CcRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets AmountPayment
        /// </summary>
        [Display(Name = "PaymentAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountPayment, Id = Index.AmountPayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountPayment { get; set; }

        /// <summary>
        /// Gets or sets AmountCustomer
        /// </summary>
        [Display(Name = "CustomerAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountCustomer, Id = Index.AmountCustomer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountCustomer { get; set; }

        /// <summary>
        /// Gets or sets AmountFunctional
        /// </summary>
        [Display(Name = "FunctionalAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountFunctional, Id = Index.AmountFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountFunctional { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod
        /// </summary>
        [Display(Name = "ApplyMethod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets or sets JobAppliedAmount
        /// </summary>
        [Display(Name = "JobAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobAppliedAmount, Id = Index.JobAppliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JobAppliedAmount { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public RefundDetailDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets OriginalAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OriginalAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalAmount, Id = Index.OriginalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalAmount { get; set; }

        /// <summary>
        /// Gets or sets CurrentBalance
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CurrentBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CurrentBalance, Id = Index.CurrentBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentBalance { get; set; }

        /// <summary>
        /// Gets or sets PendingBalance
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PendingBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingBalance, Id = Index.PendingBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingBalance { get; set; }

        /// <summary>
        /// Gets or sets NetBalance
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NetBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NetBalance, Id = Index.NetBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetBalance { get; set; }

        /// <summary>
        /// Gets or sets UnappliedJobAmount
        /// </summary>
        [Display(Name = "UnappliedJobAmount", ResourceType = typeof(RefundEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.UnappliedJobAmount, Id = Index.UnappliedJobAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnappliedJobAmount { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [IgnoreExportImport]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ProcessCommand", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public RefundDetailProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceiptDocumentNumber, Id = Index.ReceiptDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string ReceiptDocumentNumber { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets PaymentType string value
        /// </summary>
        [IgnoreExportImport]
        public string PaymentTypeString
        {
            get { return EnumUtility.GetStringValue(PaymentType); }
        }

        /// <summary>
        /// Gets CCRateOperator string value
        /// </summary>
        [IgnoreExportImport]
        public string CcRateOperatorString
        {
            get { return EnumUtility.GetStringValue(CcRateOperator); }
        }

        /// <summary>
        /// Gets CCRateOverrideFlag string value
        /// </summary>
        [IgnoreExportImport]
        public string CcRateOverrideFlagString
        {
            get { return EnumUtility.GetStringValue(CcRateOverrideFlag); }
        }

        /// <summary>
        /// Gets JobRelated string value
        /// </summary>
        [IgnoreExportImport]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets JobApplyMethod string value
        /// </summary>
        [IgnoreExportImport]
        public string JobApplyMethodString
        {
            get { return EnumUtility.GetStringValue(JobApplyMethod); }
        }

        /// <summary>
        /// Gets DocumentType string value
        /// </summary>
        [IgnoreExportImport]
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets Payment Amount Decima lPlaces value
        /// </summary>
         [IgnoreExportImport]
        public decimal PaymentAmountDecimalPlaces { get; set; }

         /// <summary>
         /// Gets Credit card Bank description value
        /// </summary>
         [IgnoreExportImport]
         public string CcBankDescription { get; set; }
        /// <summary>
        /// Gets Payment Type List
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
         public IEnumerable<CustomSelectList> PaymentTypeList {get;set;}

        #endregion
    }
}
