// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// PostRefunds Model
    /// </summary>
    public partial class PostRefund : ModelBase
    {
        /// <summary>
        /// Gets or sets PostAllBatches 
        /// </summary>
        [ViewField(Name = Fields.PostAllBatches, Id = Index.PostAllBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public PostAllBatches PostAllBatches { get; set; }

        /// <summary>
        /// Gets or sets PostBatchFrom 
        /// </summary>
        [ViewField(Name = Fields.PostBatchFrom, Id = Index.PostBatchFrom, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchFrom { get; set; }

        /// <summary>
        /// Gets or sets PostBatchTo 
        /// </summary>
        [ViewField(Name = Fields.PostBatchTo, Id = Index.PostBatchTo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchTo { get; set; }
    }
}

