// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for National Account Statistics
    /// </summary>
    public partial class NationalAccountStatistic : ModelBase
    {
        /// <summary>
        /// Gets or sets National Account Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "NationalAccountNum", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets Year 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Year", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string Year { get; set; }

        /// <summary>
        /// Gets or sets Period 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Period", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string Period { get; set; }

        /// <summary>
        /// Gets or sets Number of Invoices 
        /// </summary>
        [Display(Name = "NumberofInvoices", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofInvoices, Id = Index.NumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets Number of Credit Notes 
        /// </summary>
        [Display(Name = "NumberofCreditNotes", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofCreditNotes, Id = Index.NumberofCreditNotes, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets Number of Debit Notes 
        /// </summary>
        [Display(Name = "NumberofDebitNotes", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofDebitNotes, Id = Index.NumberofDebitNotes, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets Number of Receipts 
        /// </summary>
        [Display(Name = "NumberofReceipts", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofReceipts, Id = Index.NumberofReceipts, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofReceipts { get; set; }

        /// <summary>
        /// Gets or sets Number of Discounts 
        /// </summary>
        [Display(Name = "NumberofDiscounts", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofDiscounts, Id = Index.NumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofDiscounts { get; set; }

        /// <summary>
        /// Gets or sets Number of Adjustments 
        /// </summary>
        [Display(Name = "NumberofAdjustments", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofAdjustments, Id = Index.NumberofAdjustments, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofAdjustments { get; set; }

        /// <summary>
        /// Gets or sets Number of Write Offs 
        /// </summary>
        [Display(Name = "NumberofWriteOffs", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofWriteOffs, Id = Index.NumberofWriteOffs, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets Number of Interest Charges 
        /// </summary>
        [Display(Name = "NumberofInterestCharges", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofInterestCharges, Id = Index.NumberofInterestCharges, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofInterestCharges { get; set; }

        /// <summary>
        /// Gets or sets Number of Returned Checks 
        /// </summary>
        [Display(Name = "NumberofReturnedChecks", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofReturnedChecks, Id = Index.NumberofReturnedChecks, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofReturnedChecks { get; set; }

        /// <summary>
        /// Gets or sets Number of Invoices Paid 
        /// </summary>
        [Display(Name = "NumberofInvoicesPaid", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofInvoicesPaid, Id = Index.NumberofInvoicesPaid, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofInvoicesPaid { get; set; }

        /// <summary>
        /// Gets or sets Number of Days to Pay 
        /// </summary>
        [Display(Name = "NumberofDaystoPay", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets Average Days to Pay 
        /// </summary>
        [Display(Name = "AverageDaystoPay", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.AverageDaystoPay, Id = Index.AverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 4, Precision = 1)]
        public decimal AverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets Total Invoices in Func Currency 
        /// </summary>
        [Display(Name = "TotalInvoicesinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalInvoicesinFuncCurrency, Id = Index.TotalInvoicesinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoicesinFuncCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Credits in Func Currency 
        /// </summary>
        [Display(Name = "TotalInvoicesinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalCreditsinFuncCurrency, Id = Index.TotalCreditsinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCreditsinFuncCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Debits in Func Currency 
        /// </summary>
        [Display(Name = "TotalDebitsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalDebitsinFuncCurrency, Id = Index.TotalDebitsinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDebitsinFuncCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Receipts in Func Currency 
        /// </summary>
        [Display(Name = "TotalReceiptsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalReceiptsinFuncCurrency, Id = Index.TotalReceiptsinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalReceiptsinFuncCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Discounts in Func Curr 
        /// </summary>
        [Display(Name = "TotalDiscountsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalDiscountsinFuncCurr, Id = Index.TotalDiscountsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscountsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Adjustments in Func Curr 
        /// </summary>
        [Display(Name = "TotalAdjustmentsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalAdjustmentsinFuncCurr, Id = Index.TotalAdjustmentsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdjustmentsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Write Offs in Func Currency
        /// </summary>
        [Display(Name = "TotalWriteOffsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalWriteOffsinFuncCurren, Id = Index.TotalWriteOffsinFuncCurren, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWriteOffsinFuncCurren { get; set; }

        /// <summary>
        /// Gets or sets Total Interest in Func Curr 
        /// </summary>
        [Display(Name = "TotalInterestinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalInterestinFuncCurr, Id = Index.TotalInterestinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInterestinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Retd Checks Func Curr 
        /// </summary>
        [Display(Name = "TotalRetdChecksFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalRetdChecksFuncCurr, Id = Index.TotalRetdChecksFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRetdChecksFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Invoices Paid Func Curr 
        /// </summary>
        [Display(Name = "TotalInvoicesPaidFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalInvoicesPaidFuncCurr, Id = Index.TotalInvoicesPaidFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoicesPaidFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Invoices in Cust Curr 
        /// </summary>
        [Display(Name = "TotalInvoicesinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalInvoicesinCustCurr, Id = Index.TotalInvoicesinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoicesinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Credits in Cust Curr 
        /// </summary>
        [Display(Name = "TotalCreditsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalCreditsinCustCurr, Id = Index.TotalCreditsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCreditsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Debits in Cust Curr 
        /// </summary>
        [Display(Name = "TotalDebitsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalDebitsinCustCurr, Id = Index.TotalDebitsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDebitsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Receipts in Cust Curr 
        /// </summary>
        [Display(Name = "TotalReceiptsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalReceiptsinCustCurr, Id = Index.TotalReceiptsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalReceiptsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Discounts in Cust Curr 
        /// </summary>
        [Display(Name = "TotalDiscountsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalDiscountsinCustCurr, Id = Index.TotalDiscountsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscountsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Adjustments in Cust Curr 
        /// </summary>
        [Display(Name = "TotalAdjustmentsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalAdjustmentsinCustCurr, Id = Index.TotalAdjustmentsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdjustmentsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Write Offs in Cust Curr 
        /// </summary>
        [Display(Name = "TotalWriteOffsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalWriteOffsinCustCurr, Id = Index.TotalWriteOffsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWriteOffsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Interest in Cust Curr 
        /// </summary>
        [Display(Name = "TotalInterestinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalInterestinCustCurr, Id = Index.TotalInterestinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInterestinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Retd Checks Cust Curr 
        /// </summary>
        [Display(Name = "TotalRetdChecksCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalRetdChecksCustCurr, Id = Index.TotalRetdChecksCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRetdChecksCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Total Invoices Paid Cust Curr 
        /// </summary>
        [Display(Name = "TotalInvoicesPaidCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalInvoicesPaidCustCurr, Id = Index.TotalInvoicesPaidCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalInvoicesPaidCustCurr { get; set; }

        /// <summary>
        /// Gets or sets Number of Refunds 
        /// </summary>
        [Display(Name = "NumberofRefunds", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.NumberofRefunds, Id = Index.NumberofRefunds, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofRefunds { get; set; }

        /// <summary>
        /// Gets or sets Total Refunds in Func Currency 
        /// </summary>
        [Display(Name = "TotalRefundsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalRefundsinFuncCurrency, Id = Index.TotalRefundsinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRefundsinFuncCurrency { get; set; }

        /// <summary>
        /// Gets or sets Total Refunds in Cust Currency 
        /// </summary>
        [Display(Name = "TotalRefundsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.TotalRefundsinCustCurrency, Id = Index.TotalRefundsinCustCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRefundsinCustCurrency { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Invoices 
        /// </summary>
        [Display(Name = "YTDNumberofInvoices", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofInvoices, Id = Index.YtdNumberofInvoices, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Credits 
        /// </summary>
        [Display(Name = "YTDNumberofCredits", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofCredits, Id = Index.YtdNumberofCredits, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofCredits { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Debits 
        /// </summary>
        [Display(Name = "YTDNumberofDebits", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofDebits, Id = Index.YtdNumberofDebits, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofDebits { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Receipts 
        /// </summary>
        [Display(Name = "YTDNumberofReceipts", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofReceipts, Id = Index.YtdNumberofReceipts, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofReceipts { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Discounts 
        /// </summary>
        [Display(Name = "YTDNumberofDiscounts", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofDiscounts, Id = Index.YtdNumberofDiscounts, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofDiscounts { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Adjustments 
        /// </summary>
        [Display(Name = "YTDNumberofAdjustments", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofAdjustments, Id = Index.YtdNumberofAdjustments, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofAdjustments { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Write Offs 
        /// </summary>
        [Display(Name = "YTDNumberofWriteOffs", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofWriteOffs, Id = Index.YtdNumberofWriteOffs, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Interest Charges 
        /// </summary>
        [Display(Name = "YTDNumberofInterestChanges", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofInterestCharges, Id = Index.YtdNumberofInterestCharges, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofInterestCharges { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Returned Checks 
        /// </summary>
        [Display(Name = "YTDNumberofReturnedChecks", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofReturnedChecks, Id = Index.YtdNumberofReturnedChecks, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofReturnedChecks { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Invoices Paid 
        /// </summary>
        [Display(Name = "YTDNumberofInvoicesPaid", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofInvoicesPaid, Id = Index.YtdNumberofInvoicesPaid, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofInvoicesPaid { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Refunds 
        /// </summary>
        [Display(Name = "YTDNumberofRefunds", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofRefunds, Id = Index.YtdNumberofRefunds, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofRefunds { get; set; }

        /// <summary>
        /// Gets or sets YTD Number of Days to Pay 
        /// </summary>
        [Display(Name = "YTDNumberofDaystoPay", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdNumberofDaystoPay, Id = Index.YtdNumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal YtdNumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets YTD Invoices in Func Curr 
        /// </summary>
        [Display(Name = "YTDInvoicesinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdInvoicesinFuncCurr, Id = Index.YtdInvoicesinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdInvoicesinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Credits in Func Curr 
        /// </summary>
        [Display(Name = "YTDCreditsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdCreditsinFuncCurr, Id = Index.YtdCreditsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdCreditsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Debits in Func Curr 
        /// </summary>
        [Display(Name = "YTDDebitsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdDebitsinFuncCurr, Id = Index.YtdDebitsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdDebitsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Receipts in Func Curr 
        /// </summary>
        [Display(Name = "YTDReceiptsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdReceiptsinFuncCurr, Id = Index.YtdReceiptsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdReceiptsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Discounts in Func Curr 
        /// </summary>
        [Display(Name = "YTDDiscountsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdDiscountsinFuncCurr, Id = Index.YtdDiscountsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdDiscountsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Adjustments in Func Curr 
        /// </summary>
        [Display(Name = "YTDAdjustmentsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdAdjustmentsinFuncCurr, Id = Index.YtdAdjustmentsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdAdjustmentsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Write Offs in Func Curr 
        /// </summary>
        [Display(Name = "YTDWriteOffsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdWriteOffsinFuncCurr, Id = Index.YtdWriteOffsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdWriteOffsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Interest in Func Curr 
        /// </summary>
        [Display(Name = "YTDInterestinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdInterestinFuncCurr, Id = Index.YtdInterestinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdInterestinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Retd Checks in Func Curr 
        /// </summary>
        [Display(Name = "YTDRetdChecksinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdRetdChecksinFuncCurr, Id = Index.YtdRetdChecksinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdRetdChecksinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Invoices Pd in Func Curr 
        /// </summary>
        [Display(Name = "YTDInvoicesPdinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdInvoicesPdinFuncCurr, Id = Index.YtdInvoicesPdinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdInvoicesPdinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Refunds in Func Curr 
        /// </summary>
        [Display(Name = "YTDRefundsinFuncCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdRefundsinFuncCurr, Id = Index.YtdRefundsinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdRefundsinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Invoices in Cust Curr 
        /// </summary>
        [Display(Name = "YTDInvoicesinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdInvoicesinCustCurr, Id = Index.YtdInvoicesinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdInvoicesinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Credits in Cust Curr 
        /// </summary>
        [Display(Name = "YTDCreditsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdCreditsinCustCurr, Id = Index.YtdCreditsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdCreditsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Debits in Cust Curr 
        /// </summary>
        [Display(Name = "YTDDebitsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdDebitsinCustCurr, Id = Index.YtdDebitsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdDebitsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Receipts in Cust Curr 
        /// </summary>
        [Display(Name = "YTDReceiptsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdReceiptsinCustCurr, Id = Index.YtdReceiptsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdReceiptsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Discounts in Cust Curr 
        /// </summary>
        [Display(Name = "YTDDIscountsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdDiscountsinCustCurr, Id = Index.YtdDiscountsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdDiscountsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Adjustments in Cust Curr 
        /// </summary>
        [Display(Name = "YTDAdjustmentsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdAdjustmentsinCustCurr, Id = Index.YtdAdjustmentsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdAdjustmentsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Write Offs in Cust Curr 
        /// </summary>
        [Display(Name = "YTDWriteOffsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdWriteOffsinCustCurr, Id = Index.YtdWriteOffsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdWriteOffsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Interest in Cust Curr 
        /// </summary>
        [Display(Name = "YTDInterestinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdInterestinCustCurr, Id = Index.YtdInterestinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdInterestinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Retd Checks in Cust Curr 
        /// </summary>
        [Display(Name = "YTDRetdChecksinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdRetdChecksinCustCurr, Id = Index.YtdRetdChecksinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdRetdChecksinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Invoices Pd in Cust Curr 
        /// </summary>
        [Display(Name = "YTDInvoicesPdinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdInvoicesPdinCustCurr, Id = Index.YtdInvoicesPdinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdInvoicesPdinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Refunds in Cust Curr 
        /// </summary>
        [Display(Name = "YTDRefundsinCustCurr", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdRefundsinCustCurr, Id = Index.YtdRefundsinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdRefundsinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets YTD Average Days to Pay 
        /// </summary>
        [Display(Name = "YTDAverageDaystoPay", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.YtdAverageDaystoPay, Id = Index.YtdAverageDaystoPay, FieldType = EntityFieldType.Decimal, Size = 6, Precision = 1)]
        public decimal YtdAverageDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets Enable YTD Calculations 
        /// </summary>
        [Display(Name = "EnableYTDCalculations", ResourceType = typeof(NationalAccountsResx))]
        [ViewField(Name = Fields.EnableYtdCalculations, Id = Index.EnableYtdCalculations, FieldType = EntityFieldType.Int, Size = 2)]
        public EnableYtdCalculations EnableYtdCalculations { get; set; }
    }
}
