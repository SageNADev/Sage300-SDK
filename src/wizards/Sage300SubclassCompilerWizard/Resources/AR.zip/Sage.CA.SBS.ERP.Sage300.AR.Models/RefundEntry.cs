// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for RefundEntry
    /// </summary>
    public partial class RefundEntry : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RefundEntry"/> class.
        /// </summary>
        public RefundEntry()
        {
            RefundDetail = new EnumerableResponse<RefundDetail>();
            RefundOptionalField = new EnumerableResponse<RefundOptionalField>();
            RateOperator = RateOperator.Multiply;
            CashRateOperator =  CashRateOperator.Multiply;
            CheckRateOperator = CheckRateOperator.Multiply;
            CheckLanguage = "ENG";
        }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryDescription", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentDescription, Id = Index.DocumentDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DocumentDescription { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RefundDate", ResourceType = typeof(ARCommonResx))]
        public DateTime ? DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RefundNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets RefundAmountCustomer
        /// </summary>
        [Display(Name = "TotalRefund", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.RefundAmountCustomer, Id = Index.RefundAmountCustomer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RefundAmountCustomer { get; set; }

        /// <summary>
        /// Gets or sets RefundAmountFunctional
        /// </summary>
        [Display(Name = "RefundAmountFunctional", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.RefundAmountFunctional, Id = Index.RefundAmountFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RefundAmountFunctional { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrency { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(ARCommonResx))]
        public DateTime ? RateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperator RateOperator { get; set; }

        /// <summary>
        /// Gets or sets RateOverrideFlag
        /// </summary>
        [Display(Name = "RateOverrideFlag", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.RateOverrideFlag, Id = Index.RateOverrideFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverrideFlag RateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets DateCreated
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCreated", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.DateCreated, Id = Index.DateCreated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or sets DateLastEdited
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastEdited", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DateLastEdited, Id = Index.DateLastEdited, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastEdited { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDetails
        /// </summary>
        [Display(Name = "NumOfDetails", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfDetails, Id = Index.NumberOfDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfDetails { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod
        /// </summary>
        [Display(Name = "ApplyMethod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets or sets NumberOfOptionalFields
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.NumberOfOptionalFields, Id = Index.NumberOfOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ErrorBatch
        /// </summary>
        [Display(Name = "ErrorBatch", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ErrorBatch, Id = Index.ErrorBatch, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorBatch { get; set; }

        /// <summary>
        /// Gets or sets ErrorEntry
        /// </summary>
        [Display(Name = "ErrorEntry", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.ErrorEntry, Id = Index.ErrorEntry, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorEntry { get; set; }

        /// <summary>
        /// Gets or sets CashBankAccount
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CashBankAccount", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashBankAccount, Id = Index.CashBankAccount, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string CashBankAccount { get; set; }

        /// <summary>
        /// Gets or sets CashGLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CashGLAccount", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashGLAccount, Id = Index.CashGLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CashGLAccount { get; set; }

        /// <summary>
        /// Gets or sets CashPaymentCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CashPaymentCurrency", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashPaymentCurrency, Id = Index.CashPaymentCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CashPaymentCurrency { get; set; }

        /// <summary>
        /// Gets or sets CashRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CashRateType", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashRateType, Id = Index.CashRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CashRateType { get; set; }

        /// <summary>
        /// Gets or sets CashRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CashRateDate", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashRateDate, Id = Index.CashRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CashRateDate { get; set; }

        /// <summary>
        /// Gets or sets CashExchangeRate
        /// </summary>
        [Display(Name = "CashExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CashExchangeRate, Id = Index.CashExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CashExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets CashRateOperator
        /// </summary>
        [Display(Name = "CashRateOperator", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashRateOperator, Id = Index.CashRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public CashRateOperator CashRateOperator { get; set; }

        /// <summary>
        /// Gets or sets CashRateOverrideFlag
        /// </summary>
        [Display(Name = "CashRateOverrideFlag", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashRateOverrideFlag, Id = Index.CashRateOverrideFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public CashRateOverrideFlag CashRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets CashAmountPayment
        /// </summary>
        [Display(Name = "CashAmountPayment", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashAmountPayment, Id = Index.CashAmountPayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CashAmountPayment { get; set; }

        /// <summary>
        /// Gets or sets CashAmountCustomer
        /// </summary>
        [Display(Name = "CustomerCashAmount", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashAmountCustomer, Id = Index.CashAmountCustomer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CashAmountCustomer { get; set; }

        /// <summary>
        /// Gets or sets CashAmountFunctional
        /// </summary>
        [Display(Name = "CashAmountFunctional", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CashAmountFunctional, Id = Index.CashAmountFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CashAmountFunctional { get; set; }

        /// <summary>
        /// Gets or sets CheckBankAccount
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckBankAccount", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckBankAccount, Id = Index.CheckBankAccount, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string CheckBankAccount { get; set; }

        /// <summary>
        /// Gets or sets CheckPrintingRequired
        /// </summary>
        [Display(Name = "CheckPrintingRequired", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckPrintingRequired, Id = Index.CheckPrintingRequired, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckPrintingRequired CheckPrintingRequired { get; set; }

        /// <summary>
        /// Gets or sets CheckHasBeenPrinted
        /// </summary>
        [Display(Name = "CheckHasBeenPrinted", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckHasBeenPrinted, Id = Index.CheckHasBeenPrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckHasBeenPrinted CheckHasBeenPrinted { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber
        /// </summary>
        [Display(Name = "CheckNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckSerialNumber
        /// </summary>
        [Display(Name = "CheckSerialNumber", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckSerialNumber, Id = Index.CheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long CheckSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckPaymentCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckPaymentCurrency", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckPaymentCurrency, Id = Index.CheckPaymentCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CheckPaymentCurrency { get; set; }

        /// <summary>
        /// Gets or sets CheckRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckRateType", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckRateType, Id = Index.CheckRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CheckRateType { get; set; }

        /// <summary>
        /// Gets or sets CheckRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckRateDate", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckRateDate, Id = Index.CheckRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CheckRateDate { get; set; }

        /// <summary>
        /// Gets or sets CheckExchangeRate
        /// </summary>
        [Display(Name = "CheckExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckExchangeRate, Id = Index.CheckExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CheckExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets CheckRateOperator
        /// </summary>
        [Display(Name = "CheckRateOperator", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckRateOperator, Id = Index.CheckRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckRateOperator CheckRateOperator { get; set; }

        /// <summary>
        /// Gets or sets CheckRateOverrideFlag
        /// </summary>
        [Display(Name = "CheckRateOverrideFlag", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckRateOverrideFlag, Id = Index.CheckRateOverrideFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckRateOverrideFlag CheckRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountPayment
        /// </summary>
        [Display(Name = "CheckAmountPayment", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckAmountPayment, Id = Index.CheckAmountPayment, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckAmountPayment { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountCustomer
        /// </summary>
        [Display(Name = "CustomerCheckAmount", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckAmountCustomer, Id = Index.CheckAmountCustomer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckAmountCustomer { get; set; }

        /// <summary>
        /// Gets or sets CheckAmountFunctional
        /// </summary>
        [Display(Name = "CheckAmountFunctional", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CheckAmountFunctional, Id = Index.CheckAmountFunctional, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckAmountFunctional { get; set; }

        /// <summary>
        /// Gets or sets RemitToName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitTo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RemitToName, Id = Index.RemitToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToName { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProv
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProv", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.StateProv, Id = Index.StateProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateProv { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets CheckLanguage
        /// </summary>
        [Display(Name = "CheckLanguage", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckLanguage, Id = Index.CheckLanguage, FieldType = EntityFieldType.Char, Size = 3)]
        public string CheckLanguage { get; set; }

        /// <summary>
        /// Gets or sets CCAmountCustomer
        /// </summary>
        [Display(Name = "CustomerCreditCardAmount", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CcAmountCustomer, Id = Index.CcAmountCustomer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CcAmountCustomer { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public RefundEntryProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
        public DateTime ? PostingDate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfSPSCCDetails
        /// </summary>
        [Display(Name = "NumberOfSPSCCDetails", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.NumberOfSpsccDetails, Id = Index.NumberOfSpsccDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfSpsccDetails { get; set; }

        /// <summary>
        /// Gets or sets OriginalCCTransactionNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalCCTransactionNumber", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.OriginalCcTransactionNumber, Id = Index.OriginalCcTransactionNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string OriginalCcTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets PreviousCCTransactionNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreviousCCTransactionNumber", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.PreviousCcTransactionNumber, Id = Index.PreviousCcTransactionNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string PreviousCcTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets PreviousCCProcessStatus
        /// </summary>
        [Display(Name = "PreviousCCProcessStatus", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.PreviousCcProcessStatus, Id = Index.PreviousCcProcessStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PreviousCcProcessStatus PreviousCcProcessStatus { get; set; }

        /// <summary>
        /// Gets or sets CurrentCCTransactionNumber
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentCCTransactionNumber", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CurrentCcTransactionNumber, Id = Index.CurrentCcTransactionNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string CurrentCcTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets CurrentCCProcessStatus
        /// </summary>
        [Display(Name = "CurrentCCProcessStatus", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.CurrentCcProcessStatus, Id = Index.CurrentCcProcessStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CurrentCcProcessStatus CurrentCcProcessStatus { get; set; }

        /// <summary>
        /// Gets or sets ProcessingCode
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessingCode, Id = Index.ProcessingCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string ProcessingCode { get; set; }

        /// <summary>
        /// Refund Detail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RefundDetail> RefundDetail { get; set; }

        /// <summary>
        /// Refund Optional Field Detail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RefundOptionalField> RefundOptionalField { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets RateOperator string value
        /// </summary>
        [IgnoreExportImport]
        public string RateOperatorString
        {
            get { return EnumUtility.GetStringValue(RateOperator); }
        }

        /// <summary>
        /// Gets RateOverrideFlag string value
        /// </summary>
        [IgnoreExportImport]
        public string RateOverrideFlagString
        {
            get { return EnumUtility.GetStringValue(RateOverrideFlag); }
        }

        /// <summary>
        /// Gets JobApplyMethod string value
        /// </summary>
        [IgnoreExportImport]
        public string JobApplyMethodString
        {
            get { return EnumUtility.GetStringValue(JobApplyMethod); }
        }

        /// <summary>
        /// Gets CashRateOverrideFlag string value
        /// </summary>
        [IgnoreExportImport]
        public string CashRateOverrideFlagString
        {
            get { return EnumUtility.GetStringValue(CashRateOverrideFlag); }
        }

        /// <summary>
        /// Gets CheckPrintingRequired string value
        /// </summary>
        [IgnoreExportImport]
        public string CheckPrintingRequiredString
        {
            get { return EnumUtility.GetStringValue(CheckPrintingRequired); }
        }

        /// <summary>
        /// Gets CheckHasBeenPrinted string value
        /// </summary>
        [IgnoreExportImport]
        public string CheckHasBeenPrintedString
        {
            get { return EnumUtility.GetStringValue(CheckHasBeenPrinted); }
        }

        /// <summary>
        /// Gets CheckRateOperator string value
        /// </summary>
        [IgnoreExportImport]
        public string CheckRateOperatorString
        {
            get { return EnumUtility.GetStringValue(CheckRateOperator); }
        }

        /// <summary>
        /// Gets CheckRateOverrideFlag string value
        /// </summary>
        [IgnoreExportImport]
        public string CheckRateOverrideFlagString
        {
            get { return EnumUtility.GetStringValue(CheckRateOverrideFlag); }
        }

        /// <summary>
        /// Gets ProcessCommand string value
        /// </summary>
        [IgnoreExportImport]
        public string ProcessCommandString
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets PreviousCCProcessStatus string value
        /// </summary>
        [IgnoreExportImport]
        public string PreviousCcProcessStatusString
        {
            get { return EnumUtility.GetStringValue(PreviousCcProcessStatus); }
        }

        /// <summary>
        /// Gets CurrentCCProcessStatus string value
        /// </summary>
        [IgnoreExportImport]
        public string CurrentCcProcessStatusString
        {
            get { return EnumUtility.GetStringValue(CurrentCcProcessStatus); }
        }


        /// <summary>
        /// Gets or sets CheckLanguageList
        /// </summary>
        public IEnumerable<CustomSelectList> CheckLanguageList { get; set; }

        #endregion
    }
}
