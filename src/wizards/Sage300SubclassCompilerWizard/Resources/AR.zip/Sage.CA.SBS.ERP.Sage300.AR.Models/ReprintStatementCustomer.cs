// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class ReprintStatementCustomer : ModelBase
    {
        /// <summary>
        /// Gets or sets StatementRunNumber 
        /// </summary>
        [ViewField(Name = Fields.StatementRunNumber, Id = Index.StatementRunNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long StatementRunNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets StatementPrintedFlag 
        /// </summary>
        [ViewField(Name = Fields.StatementPrintedFlag, Id = Index.StatementPrintedFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public StatementPrintedFlag StatementPrintedFlag { get; set; }

        /// <summary>
        /// Gets or sets StatementPrintedFlag description for Finder
        /// </summary>
        public string PrintStatementsDesc
        {
            get { return EnumUtility.GetStringValue(StatementPrintedFlag); }
        }

        /// <summary>
        /// Gets or sets NATStatementSwitch 
        /// </summary>
        [ViewField(Name = Fields.NATStatementSwitch, Id = Index.NATStatementSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public NATStatementSwitch NATStatementSwitch { get; set; }

        /// <summary>
        /// For finder
        /// </summary>
        public string NATStatementSwitchString
        {
            get { return EnumUtility.GetStringValue(NATStatementSwitch); }
        }
        /// <summary>
        /// Gets or sets NationalAccountNumber 
        /// </summary>
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets StatementRunDate 
        /// </summary>
        [ViewField(Name = Fields.StatementRunDate, Id = Index.StatementRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StatementRunDate { get; set; }

        /// <summary>
        /// Gets or sets ShortName 
        /// </summary>
        [ViewField(Name = Fields.ShortName, Id = Index.ShortName, FieldType = EntityFieldType.Char, Size = 10)]
        public string ShortName { get; set; }

        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public int Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets OnHold 
        /// </summary>
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Int, Size = 2)]
        public int OnHold { get; set; }

        /// <summary>
        /// Gets or sets StartDate 
        /// </summary>
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets CreditBureauNumber 
        /// </summary>
        [ViewField(Name = Fields.CreditBureauNumber, Id = Index.CreditBureauNumber, FieldType = EntityFieldType.Char, Size = 9)]
        public string CreditBureauNumber { get; set; }

        /// <summary>
        /// Gets or sets CreditBureauRating 
        /// </summary>
        [ViewField(Name = Fields.CreditBureauRating, Id = Index.CreditBureauRating, FieldType = EntityFieldType.Char, Size = 5)]
        public string CreditBureauRating { get; set; }

        /// <summary>
        /// Gets or sets CreditBureauDate 
        /// </summary>
        [ViewField(Name = Fields.CreditBureauDate, Id = Index.CreditBureauDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string CreditBureauDate { get; set; }

        /// <summary>
        /// Gets or sets CustomerName 
        /// </summary>
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1 
        /// </summary>
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2 
        /// </summary>
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3 
        /// </summary>
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4 
        /// </summary>
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateOrProv 
        /// </summary>
        [ViewField(Name = Fields.StateOrProv, Id = Index.StateOrProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateOrProv { get; set; }

        /// <summary>
        /// Gets or sets ZipOrPostalCode 
        /// </summary>
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets ContactName 
        /// </summary>
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber 
        /// </summary>
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets TerritoryCode 
        /// </summary>
        [ViewField(Name = Fields.TerritoryCode, Id = Index.TerritoryCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TerritoryCode { get; set; }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets AutocashProfile 
        /// </summary>
        [ViewField(Name = Fields.AutocashProfile, Id = Index.AutocashProfile, FieldType = EntityFieldType.Char, Size = 6)]
        public string AutocashProfile { get; set; }

        /// <summary>
        /// Gets or sets BillingCycle 
        /// </summary>
        [ViewField(Name = Fields.BillingCycle, Id = Index.BillingCycle, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillingCycle { get; set; }

        /// <summary>
        /// Gets or sets InterestProfile 
        /// </summary>
        [ViewField(Name = Fields.InterestProfile, Id = Index.InterestProfile, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InterestProfile { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets PrintStatements 
        /// </summary>
        [ViewField(Name = Fields.PrintStatements, Id = Index.PrintStatements, FieldType = EntityFieldType.Int, Size = 2)]
        public StatementPrintedFlag PrintStatements { get; set; }

        /// <summary>
        /// Gets or sets AccountType 
        /// </summary>
        [ViewField(Name = Fields.AccountType, Id = Index.AccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountType AccountType { get; set; }

        /// <summary>
        /// Gets for finder
        /// </summary>
        public string AccountTypeDesc
        {
            get { return EnumUtility.GetStringValue(AccountType); } 
        }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo1 
        /// </summary>
        [ViewField(Name = Fields.TaxRegistrationNo1, Id = Index.TaxRegistrationNo1, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo2 
        /// </summary>
        [ViewField(Name = Fields.TaxRegistrationNo2, Id = Index.TaxRegistrationNo2, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo3 
        /// </summary>
        [ViewField(Name = Fields.TaxRegistrationNo3, Id = Index.TaxRegistrationNo3, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo4 
        /// </summary>
        [ViewField(Name = Fields.TaxRegistrationNo4, Id = Index.TaxRegistrationNo4, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo5 
        /// </summary>
        [ViewField(Name = Fields.TaxRegistrationNo5, Id = Index.TaxRegistrationNo5, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode1 
        /// </summary>
        [ViewField(Name = Fields.TaxClassCode1, Id = Index.TaxClassCode1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode2 
        /// </summary>
        [ViewField(Name = Fields.TaxClassCode2, Id = Index.TaxClassCode2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode3 
        /// </summary>
        [ViewField(Name = Fields.TaxClassCode3, Id = Index.TaxClassCode3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode4 
        /// </summary>
        [ViewField(Name = Fields.TaxClassCode4, Id = Index.TaxClassCode4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode5 
        /// </summary>
        [ViewField(Name = Fields.TaxClassCode5, Id = Index.TaxClassCode5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode5 { get; set; }

        /// <summary>
        /// Gets or sets CreditLimitCustCurr 
        /// </summary>
        [ViewField(Name = Fields.CreditLimitCustCurr, Id = Index.CreditLimitCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimitCustCurr { get; set; }

        /// <summary>
        /// Gets or sets BalanceDueinCustCurr 
        /// </summary>
        [ViewField(Name = Fields.BalanceDueinCustCurr, Id = Index.BalanceDueinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceDueinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets BalanceDueinFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.BalanceDueinFuncCurr, Id = Index.BalanceDueinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceDueinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets DateofLastStatement 
        /// </summary>
        [ViewField(Name = Fields.DateofLastStatement, Id = Index.DateofLastStatement, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastStatement { get; set; }

        /// <summary>
        /// Gets or sets LastStatementTotalCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastStatementTotalCustCurr, Id = Index.LastStatementTotalCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastStatementTotalCustCurr { get; set; }

        /// <summary>
        /// Gets or sets DateofLastBalFwdStatement 
        /// </summary>
        [ViewField(Name = Fields.DateofLastBalFwdStatement, Id = Index.DateofLastBalFwdStatement, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastBalFwdStatement { get; set; }

        /// <summary>
        /// Gets or sets BeginningBalonLastStatement 
        /// </summary>
        [ViewField(Name = Fields.BeginningBalonLastStatement, Id = Index.BeginningBalonLastStatement, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningBalonLastStatement { get; set; }

        /// <summary>
        /// Gets or sets DateofLastRevaluation 
        /// </summary>
        [ViewField(Name = Fields.DateofLastRevaluation, Id = Index.DateofLastRevaluation, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastRevaluation { get; set; }

        /// <summary>
        /// Gets or sets LastRevaluationBalance 
        /// </summary>
        [ViewField(Name = Fields.LastRevaluationBalance, Id = Index.LastRevaluationBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRevaluationBalance { get; set; }

        /// <summary>
        /// Gets or sets NumberofOpenDocuments 
        /// </summary>
        [ViewField(Name = Fields.NumberofOpenDocuments, Id = Index.NumberofOpenDocuments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofOpenDocuments { get; set; }

        /// <summary>
        /// Gets or sets NumberofPaidInvoices 
        /// </summary>
        [ViewField(Name = Fields.NumberofPaidInvoices, Id = Index.NumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets NumberofDaystoPay 
        /// </summary>
        [ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets DateofLargestInvoice 
        /// </summary>
        [ViewField(Name = Fields.DateofLargestInvoice, Id = Index.DateofLargestInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets DateofHighestBalance 
        /// </summary>
        [ViewField(Name = Fields.DateofHighestBalance, Id = Index.DateofHighestBalance, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofHighestBalance { get; set; }

        /// <summary>
        /// Gets or sets DateofLargestInvoiceLastYr 
        /// </summary>
        [ViewField(Name = Fields.DateofLargestInvoiceLastYr, Id = Index.DateofLargestInvoiceLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLargestInvoiceLastYr { get; set; }

        /// <summary>
        /// Gets or sets DateofHighestBalanceLastYr 
        /// </summary>
        [ViewField(Name = Fields.DateofHighestBalanceLastYr, Id = Index.DateofHighestBalanceLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofHighestBalanceLastYr { get; set; }

        /// <summary>
        /// Gets or sets DateofLastActivity 
        /// </summary>
        [ViewField(Name = Fields.DateofLastActivity, Id = Index.DateofLastActivity, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastActivity { get; set; }

        /// <summary>
        /// Gets or sets DateofLastInvoice 
        /// </summary>
        [ViewField(Name = Fields.DateofLastInvoice, Id = Index.DateofLastInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastInvoice { get; set; }

        /// <summary>
        /// Gets or sets DateofLastCreditNote 
        /// </summary>
        [ViewField(Name = Fields.DateofLastCreditNote, Id = Index.DateofLastCreditNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastCreditNote { get; set; }

        /// <summary>
        /// Gets or sets DateofLastDebitNote 
        /// </summary>
        [ViewField(Name = Fields.DateofLastDebitNote, Id = Index.DateofLastDebitNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastDebitNote { get; set; }

        /// <summary>
        /// Gets or sets DateofLastReceipt 
        /// </summary>
        [ViewField(Name = Fields.DateofLastReceipt, Id = Index.DateofLastReceipt, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastReceipt { get; set; }

        /// <summary>
        /// Gets or sets DateofLastDiscount 
        /// </summary>
        [ViewField(Name = Fields.DateofLastDiscount, Id = Index.DateofLastDiscount, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastDiscount { get; set; }

        /// <summary>
        /// Gets or sets DateofLastAdjustment 
        /// </summary>
        [ViewField(Name = Fields.DateofLastAdjustment, Id = Index.DateofLastAdjustment, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastAdjustment { get; set; }

        /// <summary>
        /// Gets or sets DateofLastWriteOff 
        /// </summary>
        [ViewField(Name = Fields.DateofLastWriteOff, Id = Index.DateofLastWriteOff, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastWriteOff { get; set; }

        /// <summary>
        /// Gets or sets DateofLastReturnedCheck 
        /// </summary>
        [ViewField(Name = Fields.DateofLastReturnedCheck, Id = Index.DateofLastReturnedCheck, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastReturnedCheck { get; set; }

        /// <summary>
        /// Gets or sets DateofLastInterestCharge 
        /// </summary>
        [ViewField(Name = Fields.DateofLastInterestCharge, Id = Index.DateofLastInterestCharge, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastInterestCharge { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceNumber 
        /// </summary>
        [ViewField(Name = Fields.LargestInvoiceNumber, Id = Index.LargestInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string LargestInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceNumberLastYr 
        /// </summary>
        [ViewField(Name = Fields.LargestInvoiceNumberLastYr, Id = Index.LargestInvoiceNumberLastYr, FieldType = EntityFieldType.Char, Size = 22)]
        public string LargestInvoiceNumberLastYr { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LargestInvoiceCustCurr, Id = Index.LargestInvoiceCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceCustCurr { get; set; }

        /// <summary>
        /// Gets or sets HighestBalanceCustCurr 
        /// </summary>
        [ViewField(Name = Fields.HighestBalanceCustCurr, Id = Index.HighestBalanceCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LgstInvLastYrCustCurr
        /// </summary>
        [ViewField(Name = Fields.LgstInvLastYrCustCurr, Id = Index.LgstInvLastYrCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LgstInvLastYrCustCurr { get; set; }

        /// <summary>
        /// Gets or sets HighBalLastYrCustCurr 
        /// </summary>
        [ViewField(Name = Fields.HighBalLastYrCustCurr, Id = Index.HighBalLastYrCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYrCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmtCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastInvoiceAmtCustCurr, Id = Index.LastInvoiceAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastCrNoteAmtCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastCrNoteAmtCustCurr, Id = Index.LastCrNoteAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDrNoteAmtCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastDrNoteAmtCustCurr, Id = Index.LastDrNoteAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastReceiptCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastReceiptCustCurr, Id = Index.LastReceiptCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastReceiptCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDiscountAmtCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastDiscountAmtCustCurr, Id = Index.LastDiscountAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastAdjAmtCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastAdjAmtCustCurr, Id = Index.LastAdjAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastWriteOffAmtCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastWriteOffAmtCustCurr, Id = Index.LastWriteOffAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastWriteOffAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastRetdChkAmtCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastRetdChkAmtCustCurr, Id = Index.LastRetdChkAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRetdChkAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastIntChargeCustCurr 
        /// </summary>
        [ViewField(Name = Fields.LastIntChargeCustCurr, Id = Index.LastIntChargeCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastIntChargeCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LargestInvoiceFuncCurr, Id = Index.LargestInvoiceFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets HighestBalanceFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.HighestBalanceFuncCurr, Id = Index.HighestBalanceFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LgstInvLastYrFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LgstInvLastYrFuncCurr, Id = Index.LgstInvLastYrFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LgstInvLastYrFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets HighBalLastYrFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.HighBalLastYrFuncCurr, Id = Index.HighBalLastYrFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYrFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmtFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastInvoiceAmtFuncCurr, Id = Index.LastInvoiceAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastCrNoteAmtFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastCrNoteAmtFuncCurr, Id = Index.LastCrNoteAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDrNoteAmtFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastDrNoteAmtFuncCurr, Id = Index.LastDrNoteAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastReceiptFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastReceiptFuncCurr, Id = Index.LastReceiptFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastReceiptFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDiscountAmtFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastDiscountAmtFuncCurr, Id = Index.LastDiscountAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastAdjAmtFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastAdjAmtFuncCurr, Id = Index.LastAdjAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastWriteOffAmtFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastWriteOffAmtFuncCurr, Id = Index.LastWriteOffAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastWriteOffAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastRetdChkAmtFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastRetdChkAmtFuncCurr, Id = Index.LastRetdChkAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRetdChkAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastIntChargeFuncCurr 
        /// </summary>
        [ViewField(Name = Fields.LastIntChargeFuncCurr, Id = Index.LastIntChargeFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastIntChargeFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1 
        /// </summary>
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2 
        /// </summary>
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3 
        /// </summary>
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4 
        /// </summary>
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5 
        /// </summary>
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage1 
        /// </summary>
        [ViewField(Name = Fields.SalesSplitPercentage1, Id = Index.SalesSplitPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage2 
        /// </summary>
        [ViewField(Name = Fields.SalesSplitPercentage2, Id = Index.SalesSplitPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage3 
        /// </summary>
        [ViewField(Name = Fields.SalesSplitPercentage3, Id = Index.SalesSplitPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage4 
        /// </summary>
        [ViewField(Name = Fields.SalesSplitPercentage4, Id = Index.SalesSplitPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage5 
        /// </summary>
        [ViewField(Name = Fields.SalesSplitPercentage5, Id = Index.SalesSplitPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerPriceList 
        /// </summary>
        [ViewField(Name = Fields.CustomerPriceList, Id = Index.CustomerPriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CustomerPriceList { get; set; }

        /// <summary>
        /// Gets or sets CustomerDiscountType 
        /// </summary>
        [ViewField(Name = Fields.CustomerDiscountType, Id = Index.CustomerDiscountType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerDiscountType CustomerDiscountType { get; set; }

        /// <summary>
        /// Gets or sets AmountPastDue 
        /// </summary>
        [ViewField(Name = Fields.AmountPastDue, Id = Index.AmountPastDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountPastDue { get; set; }

        /// <summary>
        /// Gets or sets DunningMessage 
        /// </summary>
        [ViewField(Name = Fields.DunningMessage, Id = Index.DunningMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string DunningMessage { get; set; }

        /// <summary>
        /// Gets or sets ContactsEmail 
        /// </summary>
        [ViewField(Name = Fields.ContactsEmail, Id = Index.ContactsEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets CustomersEmail 
        /// </summary>
        [ViewField(Name = Fields.CustomersEmail, Id = Index.CustomersEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string CustomersEmail { get; set; }

        /// <summary>
        /// Gets or sets WebSite 
        /// </summary>
        [ViewField(Name = Fields.WebSite, Id = Index.WebSite, FieldType = EntityFieldType.Char, Size = 100)]
        public string WebSite { get; set; }

        /// <summary>
        /// Gets or sets DeliveryMethod 
        /// </summary>
        [ViewField(Name = Fields.DeliveryMethod, Id = Index.DeliveryMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.DeliveryMethod DeliveryMethod { get; set; }

        /// <summary>
        /// Gets or sets ContactsPhone 
        /// </summary>
        [ViewField(Name = Fields.ContactsPhone, Id = Index.ContactsPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactsFax 
        /// </summary>
        [ViewField(Name = Fields.ContactsFax, Id = Index.ContactsFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets AllowPartialShipments 
        /// </summary>
        [ViewField(Name = Fields.AllowPartialShipments, Id = Index.AllowPartialShipments, FieldType = EntityFieldType.Int, Size = 2)]
        public StatementPrintedFlag AllowPartialShipments { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountBeginningBalanceFor 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountBeginningBalanceFor, Id = Index.HDRAmountBeginningBalanceFor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountBeginningBalanceFor { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountEndingBalanceForwar 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountEndingBalanceForwar, Id = Index.HDRAmountEndingBalanceForwar, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountEndingBalanceForwar { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountStatementBalance 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountStatementBalance, Id = Index.HDRAmountStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountStatementBalance { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountDueCurrentPeriod 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountDueCurrentPeriod, Id = Index.HDRAmountDueCurrentPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountDueCurrentPeriod { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountDue1stPeriod 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountDue1stPeriod, Id = Index.HDRAmountDue1stPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountDue1stPeriod { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountDue2ndPeriod 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountDue2ndPeriod, Id = Index.HDRAmountDue2ndPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountDue2ndPeriod { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountDue3rdPeriod 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountDue3rdPeriod, Id = Index.HDRAmountDue3rdPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountDue3rdPeriod { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountDue4thPeriod 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountDue4thPeriod, Id = Index.HDRAmountDue4thPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountDue4thPeriod { get; set; }

        /// <summary>
        /// Gets or sets HDRAmountDueForwardBalance 
        /// </summary>
        [ViewField(Name = Fields.HDRAmountDueForwardBalance, Id = Index.HDRAmountDueForwardBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HDRAmountDueForwardBalance { get; set; }

        /// <summary>
        /// Gets or sets RemitToName 
        /// </summary>
        [ViewField(Name = Fields.RemitToName, Id = Index.RemitToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToName { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress1 
        /// </summary>
        [ViewField(Name = Fields.RemitToAddress1, Id = Index.RemitToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress2 
        /// </summary>
        [ViewField(Name = Fields.RemitToAddress2, Id = Index.RemitToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress3 
        /// </summary>
        [ViewField(Name = Fields.RemitToAddress3, Id = Index.RemitToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress4 
        /// </summary>
        [ViewField(Name = Fields.RemitToAddress4, Id = Index.RemitToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets RemitToCity 
        /// </summary>
        [ViewField(Name = Fields.RemitToCity, Id = Index.RemitToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToCity { get; set; }

        /// <summary>
        /// Gets or sets RemitToStateOrProv 
        /// </summary>
        [ViewField(Name = Fields.RemitToStateOrProv, Id = Index.RemitToStateOrProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToStateOrProv { get; set; }

        /// <summary>
        /// Gets or sets RemitToZipOrPostalCode 
        /// </summary>
        [ViewField(Name = Fields.RemitToZipOrPostalCode, Id = Index.RemitToZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string RemitToZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets RemitToCountry 
        /// </summary>
        [ViewField(Name = Fields.RemitToCountry, Id = Index.RemitToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToCountry { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrencyDecimal 
        /// </summary>
        [ViewField(Name = Fields.CustomerCurrencyDecimal, Id = Index.CustomerCurrencyDecimal, FieldType = EntityFieldType.Int, Size = 2)]
        public int CustomerCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrencySymbol 
        /// </summary>
        [ViewField(Name = Fields.CustomerCurrencySymbol, Id = Index.CustomerCurrencySymbol, FieldType = EntityFieldType.Char, Size = 4)]
        public string CustomerCurrencySymbol { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or Sets Reserved Field
        /// </summary>
        public string Reserved { get; set; }
    }
}
