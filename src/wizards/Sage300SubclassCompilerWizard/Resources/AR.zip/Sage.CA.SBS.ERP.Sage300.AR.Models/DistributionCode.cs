// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for Distribution Codes
    /// </summary>
    public partial class DistributionCodes : ModelBase
    {
        /// <summary>
        /// Constructor for Distribution code
        /// </summary>
        public DistributionCodes()
        {
            Status = Status.Active;
            DiscountableVal = true;
        }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof (DistributionCodesResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DistributionCodeDesc", ResourceType = typeof (DistributionCodesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>        
        [Display(Name = "Status", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "InactiveDate", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof (CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets RevenueAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Revenue", ResourceType = typeof (DistributionCodesResx))]
        [ViewField(Name = Fields.RevenueAccount, Id = Index.RevenueAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets InventoryAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Inventory", ResourceType = typeof (DistributionCodesResx))]
        [ViewField(Name = Fields.InventoryAccount, Id = Index.InventoryAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InventoryAccount { get; set; }

        /// <summary>
        /// Gets or sets CostofGoodsSoldAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "COGSAcct", ResourceType = typeof (DistributionCodesResx))]
        [ViewField(Name = Fields.CostofGoodsSoldAccount, Id = Index.CostofGoodsSoldAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CostofGoodsSoldAccount { get; set; }

        /// <summary>
        /// Gets or sets Discountable 
        /// </summary>
        [Display(Name = "Discountable", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public Discountable Discountable { get; set; }

        #region UI property

        /// <summary>
        /// Gets or sets Revenue Description 
        /// </summary>
        public string RevenueDescription { get; set; }

        /// <summary>
        /// Gets or sets Inventory Description 
        /// </summary>
        public string InventoryDescription { get; set; }

        /// <summary>
        /// Gets or sets Cost of Goods Sold Description 
        /// </summary>
        public string CogsDescription { get; set; }

        /// <summary>
        /// Discountable Property Switch for UI
        /// </summary>
        public bool DiscountableVal
        {
            get { return Discountable != Discountable.No; }
            set { Discountable = value ? Discountable.Yes : Discountable.No; }
        }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// To get the string of Discountable property
        /// </summary>
        public string DiscountableString
        {
            get { return EnumUtility.GetStringValue(Discountable); }
        }

        /// <summary>
        /// Gets AccountType
        /// </summary>
        public AccountType AccountType { get; set; }

        #endregion
    }
}
