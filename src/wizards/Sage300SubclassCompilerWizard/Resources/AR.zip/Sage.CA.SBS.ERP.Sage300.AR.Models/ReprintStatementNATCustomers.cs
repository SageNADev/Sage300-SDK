// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;
using System.ComponentModel.DataAnnotations;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class ReprintStatementNATCustomers : ModelBase
    {

        /// <summary>
        /// Gets or sets StatementRunNumber 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.StatementRunNumber, Id = Index.StatementRunNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long StatementRunNumber { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountNumber 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets StatementRunDate 
        /// </summary>
        [ViewField(Name = Fields.StatementRunDate, Id = Index.StatementRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StatementRunDate { get; set; }

        /// <summary>
        /// Gets or sets StatementPrintedFlag 
        /// </summary>

        [ViewField(Name = Fields.StatementPrintedFlag, Id = Index.StatementPrintedFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public StatementPrintedFlag StatementPrintedFlag { get; set; }

        /// <summary>
        /// Gets or sets StatementPrintedFlag  for finders
        /// </summary>
        public string StatementPrintedFlagDec
        {
            get { return EnumUtility.GetStringValue(StatementPrintedFlag); }
        }

        /// <summary>
        /// Gets or sets NationalAccountName 
        /// </summary>
        [ViewField(Name = Fields.NationalAccountName, Id = Index.NationalAccountName, FieldType = EntityFieldType.Char, Size = 60)]
        public string NationalAccountName { get; set; }

        /// <summary>
        /// Gets or sets NATAddressLine1 
        /// </summary>
        [ViewField(Name = Fields.NATAddressLine1, Id = Index.NATAddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string NATAddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets NATAddressLine2 
        /// </summary>
        [ViewField(Name = Fields.NATAddressLine2, Id = Index.NATAddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string NATAddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets NATAddressLine3 
        /// </summary>
        [ViewField(Name = Fields.NATAddressLine3, Id = Index.NATAddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string NATAddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets NATAddressLine4 
        /// </summary>
        [ViewField(Name = Fields.NATAddressLine4, Id = Index.NATAddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string NATAddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets NATCity 
        /// </summary>
        [ViewField(Name = Fields.NATCity, Id = Index.NATCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string NATCity { get; set; }

        /// <summary>
        /// Gets or sets NATStateOrProv 
        /// </summary>
        [ViewField(Name = Fields.NATStateOrProv, Id = Index.NATStateOrProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string NATStateOrProv { get; set; }

        /// <summary>
        /// Gets or sets NATZipOrPostalCode 
        /// </summary>
        [ViewField(Name = Fields.NATZipOrPostalCode, Id = Index.NATZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string NATZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets NATCountry 
        /// </summary>
        [ViewField(Name = Fields.NATCountry, Id = Index.NATCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string NATCountry { get; set; }

        /// <summary>
        /// Gets or sets NATContactName 
        /// </summary>
        [ViewField(Name = Fields.NATContactName, Id = Index.NATContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string NATContactName { get; set; }

        /// <summary>
        /// Gets or sets NATPhoneNumber 
        /// </summary>
        [ViewField(Name = Fields.NATPhoneNumber, Id = Index.NATPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string NATPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets NATFaxNumber 
        /// </summary>
        [ViewField(Name = Fields.NATFaxNumber, Id = Index.NATFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string NATFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets NATDunningMessage 
        /// </summary>
        [ViewField(Name = Fields.NATDunningMessage, Id = Index.NATDunningMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string NATDunningMessage { get; set; }

        /// <summary>
        /// Gets or sets Email 
        /// </summary>
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountssWebSite 
        /// </summary>
        [ViewField(Name = Fields.NationalAccountssWebSite, Id = Index.NationalAccountssWebSite, FieldType = EntityFieldType.Char, Size = 100)]
        public string NationalAccountssWebSite { get; set; }

        /// <summary>
        /// Gets or sets ContactsPhone 
        /// </summary>
        [ViewField(Name = Fields.ContactsPhone, Id = Index.ContactsPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactsFax 
        /// </summary>
        [ViewField(Name = Fields.ContactsFax, Id = Index.ContactsFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets ContactsEmail 
        /// </summary>
        [ViewField(Name = Fields.ContactsEmail, Id = Index.ContactsEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets DeliveryMethod 
        /// </summary>

        [ViewField(Name = Fields.DeliveryMethod, Id = Index.DeliveryMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DeliveryMethod DeliveryMethod { get; set; }

        /// <summary>
        /// Sets for finder
        /// </summary>
        public string  DeliveryMethodDesc
        {
            get { return EnumUtility.GetStringValue(DeliveryMethod); }
        }

        /// <summary>
        /// Gets or sets AccountType 
        /// </summary>

        [ViewField(Name = Fields.AccountType, Id = Index.AccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public int AccountType { get; set; }

        /// <summary>
        /// Gets or sets NATAmountBeginningBalanceFor 
        /// </summary>

        [ViewField(Name = Fields.NATAmountBeginningBalanceFor, Id = Index.NATAmountBeginningBalanceFor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountBeginningBalanceFor { get; set; }

        /// <summary>
        /// Gets or sets NATAmountEndingBalanceForwar 
        /// </summary>

        [ViewField(Name = Fields.NATAmountEndingBalanceForwar, Id = Index.NATAmountEndingBalanceForwar, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountEndingBalanceForwar { get; set; }

        /// <summary>
        /// Gets or sets NATAmountStatementBalance 
        /// </summary>

        [ViewField(Name = Fields.NATAmountStatementBalance, Id = Index.NATAmountStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountStatementBalance { get; set; }

        /// <summary>
        /// Gets or sets NATAmountDueCurrentPeriod 
        /// </summary>

        [ViewField(Name = Fields.NATAmountDueCurrentPeriod, Id = Index.NATAmountDueCurrentPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountDueCurrentPeriod { get; set; }

        /// <summary>
        /// Gets or sets NATAmountDue1stPeriod 
        /// </summary>

        [ViewField(Name = Fields.NATAmountDue1stPeriod, Id = Index.NATAmountDue1stPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountDue1stPeriod { get; set; }

        /// <summary>
        /// Gets or sets NATAmountDue2ndPeriod 
        /// </summary>

        [ViewField(Name = Fields.NATAmountDue2ndPeriod, Id = Index.NATAmountDue2ndPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountDue2ndPeriod { get; set; }

        /// <summary>
        /// Gets or sets NATAmountDue3rdPeriod 
        /// </summary>

        [ViewField(Name = Fields.NATAmountDue3rdPeriod, Id = Index.NATAmountDue3rdPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountDue3rdPeriod { get; set; }

        /// <summary>
        /// Gets or sets NATAmountDue4thPeriod 
        /// </summary>

        [ViewField(Name = Fields.NATAmountDue4thPeriod, Id = Index.NATAmountDue4thPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountDue4thPeriod { get; set; }

        /// <summary>
        /// Gets or sets NATAmountDueForwardBalance 
        /// </summary>

        [ViewField(Name = Fields.NATAmountDueForwardBalance, Id = Index.NATAmountDueForwardBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NATAmountDueForwardBalance { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit 
        /// </summary>

        [ViewField(Name = Fields.CreditLimit, Id = Index.CreditLimit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }
    }
}
