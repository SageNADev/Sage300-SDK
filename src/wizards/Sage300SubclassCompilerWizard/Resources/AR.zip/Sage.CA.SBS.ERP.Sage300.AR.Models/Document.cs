/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// class for Document
    /// </summary>
    public partial class Document : ModelBase
    {

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckOrReceiptNo 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckOrReceiptNo, Id = Index.CheckOrReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CheckOrReceiptNo { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
         [Display(Name = "DueDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DueDate { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NationalAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocation 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
         [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
         [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public ARDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BatchDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
         [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
       [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GroupCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets DocumentDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDescription", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.DocumentDescription, Id = Index.DocumentDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DocumentDescription { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
         [Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets AsofDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AsOfDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AsofDate, Id = Index.AsofDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? AsofDate { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Terms", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
         [Display(Name = "DiscountDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden 
        /// </summary>
        // [Display(Name = "RateOverridden", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyInvoiceAmount 
        /// </summary>
      //   [Display(Name = "FuncCurrencyInvoiceAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncCurrencyInvoiceAmount, Id = Index.FuncCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyAmountDue 
        /// </summary>
       // [Display(Name = "FuncCurrencyAmountDue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncCurrencyAmountDue, Id = Index.FuncCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyTaxableAmount 
        /// </summary>
   //      [Display(Name = "FuncCurrencyTaxableAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncCurrencyTaxableAmount, Id = Index.FuncCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyNonTaxableAmt 
        /// </summary>
       //  [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncCurrencyNonTaxableAmt, Id = Index.FuncCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyTaxAmount 
        /// </summary>
     //   [Display(Name = "FuncCurrencyTaxAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncCurrencyTaxAmount, Id = Index.FuncCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyDiscountAmount 
        /// </summary>
       //  [Display(Name = "FuncCurrencyDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncCurrencyDiscountAmount, Id = Index.FuncCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyInvoiceAmount 
        /// </summary>
      //   [Display(Name = "CustCurrencyInvoiceAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustCurrencyInvoiceAmount, Id = Index.CustCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyAmountDue 
        /// </summary>
      //  [Display(Name = "CustCurrencyAmountDue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustCurrencyAmountDue, Id = Index.CustCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyTaxableAmount 
        /// </summary>
//[Display(Name = "CustCurrencyTaxableAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustCurrencyTaxableAmount, Id = Index.CustCurrencyTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyNonTaxableAmt 
        /// </summary>
       //  [Display(Name = "CustCurrencyNonTaxableAmt", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustCurrencyNonTaxableAmt, Id = Index.CustCurrencyNonTaxableAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyNonTaxableAmt { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyTaxAmount 
        /// </summary>
       //  [Display(Name = "CustCurrencyTaxAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustCurrencyTaxAmount, Id = Index.CustCurrencyTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyDiscountAmount 
        /// </summary>
       //  [Display(Name = "CustCurrencyDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustCurrencyDiscountAmount, Id = Index.CustCurrencyDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FullyPaid 
        /// </summary>
         [Display(Name = "FullyPaid", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FullyPaid, Id = Index.FullyPaid, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden FullyPaid { get; set; }

        /// <summary>
        /// Gets or sets LastActivityDate 
        /// </summary>
       [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastActivityDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastActivityDate, Id = Index.LastActivityDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastActivityDate { get; set; }

        /// <summary>
        /// Gets or sets LastStatementDate 
        /// </summary>
       [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastStatementDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastStatementDate { get; set; }

        /// <summary>
        /// Gets or sets NumberofScheduledPayments 
        /// </summary>
       //  [Display(Name = "NumberofScheduledPayments", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.NumberofScheduledPayments, Id = Index.NumberofScheduledPayments, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofScheduledPayments { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumberonLastStatement 
        /// </summary>
        //[Display(Name = "PaymentNumberonLastStatement", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentNumberonLastStatement, Id = Index.PaymentNumberonLastStatement, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumberonLastStatement { get; set; }

        /// <summary>
        /// Gets or sets LastAppliedPaymentSeqNo 
        /// </summary>
       //  [Display(Name = "LastAppliedPaymentSeqNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastAppliedPaymentSeqNo, Id = Index.LastAppliedPaymentSeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastAppliedPaymentSeqNo { get; set; }

        /// <summary>
        /// Gets or sets DoNotCalcTax 
        /// </summary>
       //  [Display(Name = "DoNotCalcTax", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DoNotCalcTax, Id = Index.DoNotCalcTax, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden DoNotCalcTax { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount1 
        /// </summary>
       //  [Display(Name = "FuncBaseAmount1", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncBaseAmount1, Id = Index.FuncBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount2 
        /// </summary>
        // [Display(Name = "FuncBaseAmount2", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncBaseAmount2, Id = Index.FuncBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount3 
        /// </summary>
      //  [Display(Name = "FuncBaseAmount3", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncBaseAmount3, Id = Index.FuncBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount4 
        /// </summary>
       //  [Display(Name = "FuncBaseAmount4", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncBaseAmount4, Id = Index.FuncBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncBaseAmount5 
        /// </summary>
       // [Display(Name = "FuncBaseAmount5", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncBaseAmount5, Id = Index.FuncBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1 
        /// </summary>
        // [Display(Name = "FuncTaxAmount1", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2 
        /// </summary>
        // [Display(Name = "FuncTaxAmount2", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3 
        /// </summary>
       //  [Display(Name = "FuncTaxAmount3", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4 
        /// </summary>
      //  [Display(Name = "FuncTaxAmount4", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5 
        /// </summary>
       // [Display(Name = "FuncTaxAmount5", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount1 
        /// </summary>
       //  [Display(Name = "CustBaseAmount1", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustBaseAmount1, Id = Index.CustBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount2 
        /// </summary>
       //  [Display(Name = "CustBaseAmount2", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustBaseAmount2, Id = Index.CustBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount3 
        /// </summary>
       // [Display(Name = "CustBaseAmount3", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustBaseAmount3, Id = Index.CustBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount4 
        /// </summary>
      //   [Display(Name = "CustBaseAmount4", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustBaseAmount4, Id = Index.CustBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustBaseAmount5 
        /// </summary>
        // [Display(Name = "CustBaseAmount5", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustBaseAmount5, Id = Index.CustBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount1 
        /// </summary>
         // [Display(Name = "CustTaxAmount1", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustTaxAmount1, Id = Index.CustTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount2 
        /// </summary>
        //[Display(Name = "CustTaxAmount2", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustTaxAmount2, Id = Index.CustTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount3 
        /// </summary>
        //  [Display(Name = "CustTaxAmount3", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustTaxAmount3, Id = Index.CustTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount4 
        /// </summary>
        // [Display(Name = "CustTaxAmount4", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustTaxAmount4, Id = Index.CustTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustTaxAmount5 
        /// </summary>
        // [Display(Name = "CustTaxAmount5", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.CustTaxAmount5, Id = Index.CustTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage1 
        /// </summary>
         [Display(Name = "SalesSplitPercentage1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage1, Id = Index.SalesSplitPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage1 { get; set; }
        
        /// <summary>
        /// Gets or sets SalesSplitPercentage2 
        /// </summary>
         [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage2, Id = Index.SalesSplitPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage3 
        /// </summary>
        [Display(Name = "SalesSplitPercentage3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage3, Id = Index.SalesSplitPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage4 
        /// </summary>
         [Display(Name = "SalesSplitPercentage4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage4, Id = Index.SalesSplitPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage5 
        /// </summary>
         [Display(Name = "SalesSplitPercentage5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage5, Id = Index.SalesSplitPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets PrepayApplytoDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PrepayApplytoDocNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PrepayApplytoDocNo, Id = Index.PrepayApplytoDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PrepayApplytoDocNo { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PostingDate { get; set; }

        /// <summary>
        /// Gets or sets RateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator 
        /// </summary>
         [Display(Name = "RateOperator", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Gets or sets LastActivityYearOrPeriod 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
       // [Display(Name = "LastActivityYearOrPeriod", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.LastActivityYearOrPeriod, Id = Index.LastActivityYearOrPeriod, FieldType = EntityFieldType.Char, Size = 6)]
        public string LastActivityYearOrPeriod { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets DepositNumber 
        /// </summary>
         [Display(Name = "DepositNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DepositNumber, Id = Index.DepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal DepositNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [Display(Name = "PostingSequenceNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
         [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden JobRelated { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage 
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageOutstanding 
        /// </summary>
        //[Display(Name = "RetainageOutstanding", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageOutstanding, Id = Index.RetainageOutstanding, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RetainageOutstanding { get; set; }

        /// <summary>
        /// Gets or sets DateRetainageDue 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateRetainageDue", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DateRetainageDue, Id = Index.DateRetainageDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrOrigRtngAmt 
        /// </summary>
        // [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncCurrOrigRtngAmt, Id = Index.FuncCurrOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCurrOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrRetainageAmount 
        /// </summary>
        // [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
         [ViewField(Name = Fields.FuncCurrRetainageAmount, Id = Index.FuncCurrRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
         public decimal FuncCurrRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrOrigRtngAmt 
         /// </summary>

        //[Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
         [ViewField(Name = Fields.CustCurrOrigRtngAmt, Id = Index.CustCurrOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
         public decimal CustCurrOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets CustCurrRetainageAmount 
        /// </summary>
       // [Display(Name = "CustCurrRetainageAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustCurrRetainageAmount, Id = Index.CustCurrRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
       // [Display(Name = "RetainageTermsCode", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate 
        /// </summary>
       [Display(Name = "RetainageExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
       // [Display(Name = "OriginalDocNo", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
       [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets AOrRVersionCreatedIn 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
       // [Display(Name = "AOrRVersionCreatedIn", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.AOrRVersionCreatedIn, Id = Index.AOrRVersionCreatedIn, FieldType = EntityFieldType.Char, Size = 3)]
        public string AOrRVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType 
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets DepositSerialNumber 
        /// </summary>
       [Display(Name = "DepositSerialNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DepositSerialNumber, Id = Index.DepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long DepositSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DepositLineNumber 
        /// </summary>
       [Display(Name = "DepositLineNumber", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.DepositLineNumber, Id = Index.DepositLineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DepositLineNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets NumberofOBLJDetails 
        /// </summary>
       // [Display(Name = "NumberofOBLJDetails", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofOBLJDetails, Id = Index.NumberofOBLJDetails, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofOBLJDetails { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyCode", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3)]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate 
        /// </summary>
       [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2)]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperator 
        /// </summary>
        [Display(Name = "TaxReportingRateOperator", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperator, Id = Index.TaxReportingRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOverride 
        /// </summary>
        [Display(Name = "TaxReportingRateOverride", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOverride, Id = Index.TaxReportingRateOverride, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxReportingRateOverride { get; set; }

        /// <summary>
        /// Gets or sets ReportRetainageTax 
        /// </summary>
        //[Display(Name = "ReportRetainageTax", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReportRetainageTax, Id = Index.ReportRetainageTax, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReportRetainageTax { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxStateVersion 
        /// </summary>
       [Display(Name = "TaxStateVersion", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxStateVersion, Id = Index.TaxStateVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxStateVersion { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCalculateMethod 
        /// </summary>
       // [Display(Name = "TaxReportingCalculateMethod", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingCalculateMethod, Id = Index.TaxReportingCalculateMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxReportingCalculateMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
       [Display(Name = "TaxClass1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
      [Display(Name = "TaxClass4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
         [Display(Name = "TaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
       [Display(Name = "TaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
       [Display(Name = "TaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
      [Display(Name = "TaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
       [Display(Name = "TaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets EarliestBackdatedActivityDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
       // [Display(Name = "EarliestBackdatedActivityDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EarliestBackdatedActivityDate, Id = Index.EarliestBackdatedActivityDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? EarliestBackdatedActivityDate { get; set; }

        /// <summary>
        /// Gets or sets LastRevaluationDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastRevaluationDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastRevaluationDate, Id = Index.LastRevaluationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastRevaluationDate { get; set; }

        /// <summary>
        /// Gets or sets OrigExchangeRate 
        /// </summary>
         [Display(Name = "ExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrigExchangeRate, Id = Index.OrigExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OrigExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets OrigRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrigRateType, Id = Index.OrigRateType, FieldType = EntityFieldType.Char, Size = 2)]
        public string OrigRateType { get; set; }

        /// <summary>
        /// Gets or sets OrigRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrigRateDate, Id = Index.OrigRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? OrigRateDate { get; set; }

        /// <summary>
        /// Gets or sets OrigRateOperator 
        /// </summary>
       // [Display(Name = "RateOperator", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrigRateOperator, Id = Index.OrigRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrigRateOperator { get; set; }

        /// <summary>
        /// Gets or sets OrigRateOverrideFlag 
        /// </summary>
         [Display(Name = "RateOverride", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrigRateOverrideFlag, Id = Index.OrigRateOverrideFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden OrigRateOverrideFlag { get; set; }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets DatePaid 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DatePaid", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DatePaid, Id = Index.DatePaid, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DatePaid { get; set; }

        /// <summary>
        /// Gets or sets MiscReceiptFlag 
        /// </summary>
       // [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.MiscReceiptFlag, Id = Index.MiscReceiptFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public int MiscReceiptFlag { get; set; }

        /// <summary>
        /// Gets or sets TerritotyCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
       // [Display(Name = "TerritotyCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TerritotyCode, Id = Index.TerritotyCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TerritotyCode { get; set; }


        #region UI
        /// <summary>
        /// Gets the TransactionType string.
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }
       
        /// <summary>
        /// Gets the DocumentType string.
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
         [Display(Name = "FullyPaid", ResourceType = typeof(ARCommonResx))]
        public string FullyPaidString
        {
            get { return EnumUtility.GetStringValue(FullyPaid); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string InvoiceTypeString
        {
            get { return EnumUtility.GetStringValue(InvoiceType); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string DoNotCalcTaxString
        {
            get { return EnumUtility.GetStringValue(DoNotCalcTax); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }
        
        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string RetainageOutstandingString
        {
            get { return EnumUtility.GetStringValue(RetainageOutstanding); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string TaxReportingRateOverrideString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOverride); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string TaxReportingCalculateMethodString
        {
            get { return EnumUtility.GetStringValue(TaxReportingCalculateMethod); }
        }

        /// <summary>
        /// Gets the FullyPaid string.
        /// </summary>
        public string OrigRateOverrideFlagString
        {
            get { return EnumUtility.GetStringValue(OrigRateOverrideFlag); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is job related.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is job related; otherwise, <c>false</c>.
        /// </value>
        public bool IsJobRelated
        {
            get { return JobRelated == RateOverridden.Yes; }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is has retainage.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is has retainage; otherwise, <c>false</c>.
        /// </value>
        public bool IsHasRetainage
        {
            get { return HasRetainage == RateOverridden.Yes; }
        }
       
        #endregion
    }
}
