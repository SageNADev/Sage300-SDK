﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public class DetailTaxWithheld
    {

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 1
        /// </summary>
        public decimal AmtWHD1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 2
        /// </summary>
        public decimal AmtWHD2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 3
        /// </summary>
        public decimal AmtWHD3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 4
        /// </summary>
        public decimal AmtWHD4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Vend. Tax Withheld Amount 5
        /// </summary>
        public decimal AmtWHD5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Withheld Amount Total
        /// </summary>
        public decimal AmtWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 1
        /// </summary>
        public decimal PndWHD1Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 2
        /// </summary>
        public decimal PndWHD2Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 3
        /// </summary>
        public decimal PndWHD3Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 4
        /// </summary>
        public decimal PndWHD4Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 5
        /// </summary>
        public decimal PndWHD5Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Total
        /// </summary>
        public decimal PndWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Document Tax Authority 1
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CodeTax1 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 2
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CodeTax2 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 3
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CodeTax3 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 4
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CodeTax4 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 5
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CodeTax5 { get; set; }

    }
}
