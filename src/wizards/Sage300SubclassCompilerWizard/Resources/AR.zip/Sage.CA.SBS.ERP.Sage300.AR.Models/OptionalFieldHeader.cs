// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class for Optional Field Header
    /// </summary>
    public partial class OptionalFieldHeader : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the Optional Field Header/> class.
        /// </summary>
        public OptionalFieldHeader()
        {
            OptionalFieldDetails = new EnumerableResponse<OptionalFieldDetail>();
        }

        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "Location", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets NumberofValues 
        /// </summary>
        [Display(Name = "NumberofValues", ResourceType = typeof (OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberofValues, Id = Index.NumberofValues, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofValues { get; set; }

        /// <summary>
        /// Gets or sets OptFields
        /// </summary>
        /// <value>The optional fields.</value>
        public EnumerableResponse<OptionalFieldDetail> OptionalFieldDetails { get; set; }
    }
}
