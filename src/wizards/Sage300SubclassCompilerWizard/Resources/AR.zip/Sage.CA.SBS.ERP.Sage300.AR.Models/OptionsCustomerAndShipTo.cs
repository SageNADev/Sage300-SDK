// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class OptionsCustomerAndShipTo : ModelBase
    {
        /// <summary>
        /// Gets or sets Customer Or Ship To Options Key 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CustOrShipToOptionsKey, Id = Index.CustOrShipToOptionsKey, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustOrShipToOptionsKey { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Default No Days for Expiry 
        /// </summary>
        [Display(Name = "DefaultCommentDays", ResourceType = typeof (OptionsResx))]
        [Range(typeof (decimal), "0", "99999", ErrorMessageResourceName = "Range",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyNumeric)]
        [ViewField(Name = Fields.DefaultNoDaysforExpiry, Id = Index.DefaultNoDaysforExpiry, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal DefaultNoDaysforExpiry { get; set; }

        /// <summary>
        /// Gets or sets Default No Days for FollowUp 
        /// </summary>
        [Display(Name = "DefaultFollowUpDays", ResourceType = typeof (OptionsResx))]
        [Range(typeof (decimal), "0", "99999", ErrorMessageResourceName = "Range",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyNumeric)]
        [ViewField(Name = Fields.DefaultNoDaysforFollowUp, Id = Index.DefaultNoDaysforFollowUp, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal DefaultNoDaysforFollowUp { get; set; }

        /// <summary>
        /// Gets or sets Default Comment Type 
        /// </summary>
        [Display(Name = "DefaultCommentType", ResourceType = typeof (OptionsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DefaultCommentType, Id = Index.DefaultCommentType, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DefaultCommentType { get; set; }

        /// <summary>
        /// Gets or sets Allow Blank Comment Type 
        /// </summary>
        [Display(Name = "AllowBlankCommentType", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AllowBlankCommentType, Id = Index.AllowBlankCommentType, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlankCommentType AllowBlankCommentType { get; set; }

        /// <summary>
        /// Allow Blank Comment Type Yes/No for UI 
        /// </summary>
        public bool AllowBlankComment
        {
            get { return AllowBlankCommentType != AllowBlankCommentType.No; }
            set { AllowBlankCommentType = value ? AllowBlankCommentType.Yes : AllowBlankCommentType.No; }
        }
    }
}
