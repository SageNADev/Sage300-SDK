/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using System;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class TermsCodeHeader : ModelBase
    {
        /// <summary>
        /// Gets or sets TermsCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsCode", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingDescription", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>

       [Display(Name = "Status", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusInText
        {
            get { return EnumUtility.GetStringValue(Status); }
        } 

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; } 
       
        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }  

        /// <summary>
        /// Gets or sets UsePaymentSchedule 
        /// </summary>
        [Display(Name = "UsePaymentSchedule", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.UsePaymentSchedule, Id = Index.UsePaymentSchedule, FieldType = EntityFieldType.Int, Size = 2)]
        public UsePaymentSchedule UsePaymentSchedule { get; set; }

        /// <summary>
        /// Gets UsePaymentScheduleInText string value
        /// </summary>
        public string UsePaymentScheduleInText
        {
            get { return EnumUtility.GetStringValue(UsePaymentSchedule); }
        }

        /// <summary>
        /// Gets or sets CalcBaseforDiscountwithTax 
        /// </summary>
        [Display(Name = "CalcBaseforDiscountwithTax", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.CalcBaseforDiscountwithTax, Id = Index.CalcBaseforDiscountwithTax, FieldType = EntityFieldType.Int, Size = 2)]
        public CalcBaseforDiscountwithTax CalcBaseforDiscountwithTax { get; set; }

        /// <summary>
        /// Gets Use CalcBaseforDiscountwithTax string value
        /// </summary>
        public string CalcBaseforDiscountwithTaxInText
        {
            get { return EnumUtility.GetStringValue(CalcBaseforDiscountwithTax); }
        }

        /// <summary>
        /// Gets or sets DiscountType 
        /// </summary>
        [Display(Name = "DiscountType", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountType, Id = Index.DiscountType, FieldType = EntityFieldType.Int, Size = 2)]
        public DiscountType DiscountType { get; set; }

        /// <summary>
        /// Gets or sets DISCPCT 
        /// </summary>
        [Display(Name = "DISCPCT", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DISCPCT, Id = Index.DISCPCT, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DISCPCT { get; set; }

        /// <summary>
        /// Gets or sets DISCNBR 
        /// </summary>
        [Display(Name = "DISCNBR", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DISCNBR, Id = Index.DISCNBR, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DISCNBR { get; set; }

        /// <summary>
        /// Gets or sets DISCDAY 
        /// </summary>
        [Display(Name = "DISCDAY", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DISCDAY, Id = Index.DISCDAY, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DISCDAY { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay1
        /// </summary>
        [Display(Name = "DiscountTableStartingDay1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay1, Id = Index.DiscountTableStartingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay2 
        /// </summary>
        [Display(Name = "DiscountTableStartingDay2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay2, Id = Index.DiscountTableStartingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay3
        /// </summary>
        [Display(Name = "DiscountTableStartingDay3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay3, Id = Index.DiscountTableStartingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableStartingDay4 
        /// </summary>
        [Display(Name = "DiscountTableStartingDay4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableStartingDay4, Id = Index.DiscountTableStartingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableStartingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay1 
        /// </summary>
        [Display(Name = "DiscountTableEndingDay1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay1, Id = Index.DiscountTableEndingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay2
        /// </summary>
        [Display(Name = "DiscountTableEndingDay2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay2, Id = Index.DiscountTableEndingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay3 
        /// </summary>
        [Display(Name = "DiscountTableEndingDay3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay3, Id = Index.DiscountTableEndingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableEndingDay4
        /// </summary>
        [Display(Name = "DiscountTableEndingDay4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableEndingDay4, Id = Index.DiscountTableEndingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableEndingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableMonthsAdded1 
        /// </summary>
        [Display(Name = "DiscountTableMonthsAdded1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableMonthsAdded1, Id = Index.DiscountTableMonthsAdded1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableMonthsAdded1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableMonthsAdded2 
        /// </summary>
        [Display(Name = "DiscountTableMonthsAdded2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableMonthsAdded2, Id = Index.DiscountTableMonthsAdded2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableMonthsAdded2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableMonthsAdded3
        /// </summary>
        [Display(Name = "DiscountTableMonthsAdded3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableMonthsAdded3, Id = Index.DiscountTableMonthsAdded3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableMonthsAdded3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableMonthsAdded4
        /// </summary>
        [Display(Name = "DiscountTableMonthsAdded4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableMonthsAdded4, Id = Index.DiscountTableMonthsAdded4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableMonthsAdded4 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth1 
        /// </summary>
        [Display(Name = "DiscountTableDayofMonth1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth1, Id = Index.DiscountTableDayofMonth1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth1 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth2 
        /// </summary>
        [Display(Name = "DiscountTableDayofMonth2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth2, Id = Index.DiscountTableDayofMonth2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth2 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth3 
        /// </summary>
        [Display(Name = "DiscountTableDayofMonth3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth3, Id = Index.DiscountTableDayofMonth3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth3 { get; set; }

        /// <summary>
        /// Gets or sets DiscountTableDayofMonth4
        /// </summary>
        [Display(Name = "DiscountTableDayofMonth4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DiscountTableDayofMonth4, Id = Index.DiscountTableDayofMonth4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DiscountTableDayofMonth4 { get; set; }

        /// <summary>
        /// Gets or sets Due Date Type 
        /// </summary>
        [Display(Name = "DueDateType", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateType, Id = Index.DueDateType, FieldType = EntityFieldType.Int, Size = 2)]
        public DueDateType DueDateType { get; set; }

        /// <summary>
        /// Gets or sets CNTDUEDAY 
        /// </summary>
        [Display(Name = "CNTDUEDAY", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.CNTDUEDAY, Id = Index.CNTDUEDAY, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal CNTDUEDAY { get; set; }

        /// <summary>
        /// Gets or sets DUENBRDAYS 
        /// </summary>
        [Display(Name = "DueNumberofDays", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DUENBRDAYS, Id = Index.DUENBRDAYS, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DUENBRDAYS { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableStartingDay1 
        /// </summary>
        [Display(Name = "DueDateTableStartingDay1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableStartingDay1, Id = Index.DueDateTableStartingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableStartingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableStartingDay2
        /// </summary>
        [Display(Name = "DueDateTableStartingDay2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableStartingDay2, Id = Index.DueDateTableStartingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableStartingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableStartingDay3
        /// </summary>
        [Display(Name = "DueDateTableStartingDay3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableStartingDay3, Id = Index.DueDateTableStartingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableStartingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableStartingDay4
        /// </summary>
        [Display(Name = "DueDateTableStartingDay4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableStartingDay4, Id = Index.DueDateTableStartingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableStartingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableEndingDay1
        /// </summary>
        [Display(Name = "DueDateTableEndingDay1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableEndingDay1, Id = Index.DueDateTableEndingDay1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableEndingDay1 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableEndingDay2
        /// </summary>
        [Display(Name = "DueDateTableEndingDay2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableEndingDay2, Id = Index.DueDateTableEndingDay2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableEndingDay2 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableEndingDay3
        /// </summary>
        [Display(Name = "DueDateTableEndingDay3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableEndingDay3, Id = Index.DueDateTableEndingDay3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableEndingDay3 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableEndingDay4 
        /// </summary>
        [Display(Name = "DueDateTableEndingDay4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableEndingDay4, Id = Index.DueDateTableEndingDay4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableEndingDay4 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableMonthsAdded1 
        /// </summary>
        [Display(Name = "DueDateTableMonthsAdded1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableMonthsAdded1, Id = Index.DueDateTableMonthsAdded1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableMonthsAdded1 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableMonthsAdded2 
        /// </summary>
        [Display(Name = "DueDateTableMonthsAdded2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableMonthsAdded2, Id = Index.DueDateTableMonthsAdded2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableMonthsAdded2 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableMonthsAdded3
        /// </summary>
        [Display(Name = "DueDateTableMonthsAdded3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableMonthsAdded3, Id = Index.DueDateTableMonthsAdded3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableMonthsAdded3 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableMonthsAdded4 
        /// </summary>
        [Display(Name = "DueDateTableMonthsAdded4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableMonthsAdded4, Id = Index.DueDateTableMonthsAdded4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableMonthsAdded4 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableDayofMonth1 
        /// </summary>
        [Display(Name = "DueDateTableDayofMonth1", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableDayofMonth1, Id = Index.DueDateTableDayofMonth1, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableDayofMonth1 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableDayofMonth2
        /// </summary>
        [Display(Name = "DueDateTableDayofMonth2", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableDayofMonth2, Id = Index.DueDateTableDayofMonth2, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableDayofMonth2 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableDayofMonth3
        /// </summary>
        [Display(Name = "DueDateTableDayofMonth3", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableDayofMonth3, Id = Index.DueDateTableDayofMonth3, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableDayofMonth3 { get; set; }

        /// <summary>
        /// Gets or sets DueDateTableDayofMonth4 
        /// </summary>
        [Display(Name = "DueDateTableDayofMonth4", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DueDateTableDayofMonth4, Id = Index.DueDateTableDayofMonth4, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DueDateTableDayofMonth4 { get; set; }

        /// <summary>
        /// Gets or sets DTEDUESYNC 
        /// </summary>
        [IgnoreExportImportAttribute]
        [Display(Name = "DTEDUESYNC", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.DTEDUESYNC, Id = Index.DTEDUESYNC, FieldType = EntityFieldType.Int, Size = 2)]
        public int DTEDUESYNC { get; set; }

        /// <summary>
        /// Gets or sets DTEDSCSYNC 
        /// </summary>
        [IgnoreExportImportAttribute]
        [ViewField(Name = Fields.DTEDSCSYNC, Id = Index.DTEDSCSYNC, FieldType = EntityFieldType.Int, Size = 2)]
        public int DTEDSCSYNC { get; set; }

        /// <summary>
        /// Gets or sets NumberofPayments 
        /// </summary>
        [Display(Name = "NumberofPayments", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.NumberofPayments, Id = Index.NumberofPayments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPayments { get; set; }

        /// <summary>
        /// Gets or sets TotalPercentDue 
        /// </summary>
        [Display(Name = "TotalPercentDue", ResourceType = typeof(TermsCodeResx))]
        [ViewField(Name = Fields.TotalPercentDue, Id = Index.TotalPercentDue, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal TotalPercentDue { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDetail.
        /// </summary>
        public EnumerableResponse<TermsCodeDetail> TermsCodeDetails { get; set; }

        /// <summary>
        /// IsStatusActive is for validating the inactive checkbox
        /// </summary> 
        public bool IsStatusActive
        {
            get { return Status == Status.Inactive; }
            set { Status = value == false ? Status.Active : Status.Inactive; }
        }

        /// <summary>
        /// IsMultiplePaymentSchedule is for validating the inactive checkbox.
        /// </summary> 
        public bool IsMultiplePaymentSchedule
        {
            get
            {
                return (UsePaymentSchedule == UsePaymentSchedule.Yes) ? true : false;
            }
            set
            {
                if (value)
                {
                    UsePaymentSchedule = UsePaymentSchedule.Yes;
                }
                else
                {
                    UsePaymentSchedule = UsePaymentSchedule.No;
                }
            }
        }
        /// <summary>
        /// To get TotalResultsCount
        /// </summary>
        /// <value>TotalResultsCount</value>
        public long TotalResultsCount { get; set; }

        /// <summary>
        /// To get the string value of enumeration DiscountType 
        /// </summary>
        public string DiscountTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(DiscountType);
            }
        }

        /// <summary>
        /// To get the string value of enumeration DueDateType 
        /// </summary>
        public string DueDateTypeInText
        {
            get
            {
                return EnumUtility.GetStringValue(DueDateType);
            }
        }
    }
}
