// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// PostReceiptsandAdjustments Model
    /// </summary>
    public partial class PostReceiptsandAdjustment : ModelBase
    {
        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets PostAllBatches 
        /// </summary>
        [ViewField(Name = Fields.PostAllBatches, Id = Index.PostAllBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public PostAllBatches PostAllBatches { get; set; }

        /// <summary>
        /// Gets or sets PostBatchFrom 
        /// </summary>
        [ViewField(Name = Fields.PostBatchFrom, Id = Index.PostBatchFrom, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchFrom { get; set; }

        /// <summary>
        /// Gets or sets PostBatchTo 
        /// </summary>
        [ViewField(Name = Fields.PostBatchTo, Id = Index.PostBatchTo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchTo { get; set; }
    }
}
