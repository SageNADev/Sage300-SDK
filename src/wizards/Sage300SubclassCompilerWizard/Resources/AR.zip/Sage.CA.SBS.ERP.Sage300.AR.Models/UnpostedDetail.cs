// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;


#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for UnpostedDetail
    /// </summary>
    public partial class UnpostedDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets SequenceNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.SequenceNo, Id = Index.SequenceNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets TransType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.TransType, Id = Index.TransType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransType TransType { get; set; }

        /// <summary>
        /// Gets or sets BatchNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.BatchNo, Id = Index.BatchNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNo { get; set; }

        /// <summary>
        /// Gets or sets EntryNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.EntryNo, Id = Index.EntryNo, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNo { get; set; }

        /// <summary>
        /// Gets or sets LineNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.LineNo, Id = Index.LineNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNo { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentNo, Id = Index.DocumentNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNo { get; set; }

        /// <summary>
        /// Gets or sets PaymentNo
        /// </summary>
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentNo, Id = Index.PaymentNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNo { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets Resource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]

        [ViewField(Name = Fields.Resource, Id = Index.Resource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string Resource { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>

        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets ItemNo
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ItemNo, Id = Index.ItemNo, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNo { get; set; }

        /// <summary>
        /// Gets or sets DistCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DistCode, Id = Index.DistCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistCode { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UOM", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets RevenueAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RevenueAccount, Id = Index.RevenueAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RevenueAccount { get; set; }

        /// <summary>
        /// Gets or sets InventoryAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InventoryAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InventoryAccount, Id = Index.InventoryAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string InventoryAccount { get; set; }

        /// <summary>
        /// Gets or sets COGSAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "COGSAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.COGSAccount, Id = Index.COGSAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string COGSAccount { get; set; }

        /// <summary>
        /// Gets or sets Qunatity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Qunatity, Id = Index.Qunatity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Qunatity { get; set; }

        /// <summary>
        /// Gets or sets TransAmt
        /// </summary>
        [Display(Name = "TransactionAmt", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransAmt, Id = Index.TransAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransAmt { get; set; }

        /// <summary>
        /// Gets or sets TransAmtHome
        /// </summary>

        [ViewField(Name = Fields.TransAmtHome, Id = Index.TransAmtHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransAmtHome { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount
        /// </summary>
        [Display(Name = "TaxAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxAmount, Id = Index.TaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountHome
        /// </summary>

        [ViewField(Name = Fields.TaxAmountHome, Id = Index.TaxAmountHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountHome { get; set; }

        /// <summary>
        /// Gets or sets RtgAmount
        /// </summary>

        [ViewField(Name = Fields.RtgAmount, Id = Index.RtgAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgAmount { get; set; }

        /// <summary>
        /// Gets or sets RtgAmountHome
        /// </summary>

        [ViewField(Name = Fields.RtgAmountHome, Id = Index.RtgAmountHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgAmountHome { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>

        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets ForSequenceNo
        /// </summary>

        [ViewField(Name = Fields.ForSequenceNo, Id = Index.ForSequenceNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long ForSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets ForTransactionType
        /// </summary>

        [ViewField(Name = Fields.ForTransactionType, Id = Index.ForTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public ForTransactionType ForTransactionType { get; set; }

        /// <summary>
        /// Gets or sets ForBatchNo
        /// </summary>

        [ViewField(Name = Fields.ForBatchNo, Id = Index.ForBatchNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ForBatchNo { get; set; }

        /// <summary>
        /// Gets or sets ForEntryNo
        /// </summary>

        [ViewField(Name = Fields.ForEntryNo, Id = Index.ForEntryNo, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal ForEntryNo { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TransType string value
        /// </summary>
        public string TransTypeString
        {
            get { return EnumUtility.GetStringValue(TransType); }
        }

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString
        {
            get { return EnumUtility.GetStringValue(CostClass); }
        }

        /// <summary>
        /// Gets ForTransactionType string value
        /// </summary>
        public string ForTransactionTypeString
        {
            get { return EnumUtility.GetStringValue(ForTransactionType); }
        }

        /// <summary>
        /// Gets Account Description For GL Account value
        /// </summary>
        [Display(Name = "AccountDescription", ResourceType = typeof(CommonResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets Account Description For Inventory Account value
        /// </summary>
        [Display(Name = "InventoryDescription", ResourceType = typeof(ARCommonResx))]
        public string InventoryDescription{ get; set; }

        /// <summary>
        /// Gets Account Description For COGS Account value
        /// </summary>
        [Display(Name = "COGSDescription", ResourceType = typeof(ARCommonResx))]
        public string COGSDescription { get; set; }

        /// <summary>
        /// Gets Account Description For Item value
        /// </summary>
        [Display(Name = "ItemDescription", ResourceType = typeof(ARCommonResx))]
        public string ItemDescription { get; set; }
        #endregion
    }
}
