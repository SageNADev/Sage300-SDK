﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using System;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Customer Inquiry User Preferences model.
    /// </summary>
    public class CustomerInquiryPreference
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public CustomerInquiryPreference()
        {
        }

        /// <summary>
        /// CustomerInquiryPreference Constructor
        /// </summary>
        public CustomerInquiryPreference(bool setDefaults)
        {
            if (!setDefaults)
                return;

            SelectedTab = Constant.DefaultValue0;
            AmountsIn = Constant.DefaultValue0;
            ActivityStatistics = new ActivityStatisticsFilter(true);
            PostedReceipt = new PostedReceiptFilter(true);
            UnpostedEntry = new PendingFilter(true);
            Refund = new RefundsFilter(true);
            Orders = new OrderEntryFilter(true);
            OESales = new OESalesFilter(true);
            Adjustment = new AdjustmentsFilter(true);
            ShipTo = new ShipToFilter(true);
            Comments = new CommentsFilter(true);
            Invoice = new InvoiceFilter(true);
            ContractPricing = new ICContractPricing(true);
            RecurringCharge = new RecurringChargesFilter(true);
            CreditStatus = new CreditStatusFilter(true);
        }

        /// <summary>
        /// Gets or Sets AmountsIn
        /// </summary>
        public int AmountsIn { get; set; }

        /// <summary>
        /// Gets or Sets Selected Tab
        /// </summary>
        public int SelectedTab { get; set; }

        /// <summary>
        /// Gets or Sets Posted Receipt Filters
        /// </summary>
        public PostedReceiptFilter PostedReceipt { get; set; }

        /// <summary>
        /// Gets or Sets Unposted Entry
        /// </summary>
        public PendingFilter UnpostedEntry { get; set; }

        /// <summary>
        /// Gets or Sets RefundsFilter
        /// </summary>
        public RefundsFilter Refund { get; set; }

        /// <summary>
        /// Gets or Sets Order Entry and shipment entry
        /// </summary>
        public OrderEntryFilter Orders { get; set; }

        /// <summary>
        /// Gets or Sets ActivityStatisticsFilter
        /// </summary>
        public ActivityStatisticsFilter ActivityStatistics { get; set; }

        /// <summary>
        /// Gets or Sets OESalesFilter
        /// </summary>
        public OESalesFilter OESales { get; set; }

        /// <summary>
        /// Gets or Sets Adjustment Filter
        /// </summary>
        public AdjustmentsFilter Adjustment { get; set; }

        /// <summary>
        /// Gets or Sets ShipTo Filter
        /// </summary>
        public ShipToFilter ShipTo { get; set; }

        /// <summary>
        /// Gets or Sets Comments Filter
        /// </summary>
        public CommentsFilter Comments { get; set; }

        /// <summary>
        /// Gets or Sets Invoice and Credit debit note entry
        /// </summary>
        public InvoiceFilter Invoice { get; set; }

        /// <summary>
        /// Gets or Sets Credit Status
        /// </summary>
        public CreditStatusFilter CreditStatus { get; set; }

        public RecurringChargesFilter RecurringCharge { get; set; }

        /// <summary>
        /// Gets or Sets IC- Contract Pricing
        /// </summary>
        public ICContractPricing ContractPricing { get; set; }
    }

    /// <summary>
    /// Posted Receipt Filters model.
    /// </summary>
    public class PostedReceiptFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public PostedReceiptFilter()
        {
        }

        /// <summary>
        /// PostedReceiptFilter Constructor
        /// </summary>
        public PostedReceiptFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            Outstanding = true;
            Cleared = true;
            Returned = true;
            OrderBy = Constant.DefaultValue0;
            CheckReceiptNo = string.Empty;
            ReceiptDate = null;
        }

        /// <summary>
        /// Get or Set SortDirection
        /// </summary>
        public int SortDirection { get; set; }

        /// <summary>
        /// Gets or Sets Outstanding
        /// </summary>
        public bool Outstanding { get; set; }

        /// <summary>
        /// Gets or Sets Cleared
        /// </summary>
        public bool Cleared { get; set; }

        /// <summary>
        /// Gets or Sets Returned
        /// </summary>
        public bool Returned { get; set; }

        /// <summary>
        /// Gets or Sets OrderBy
        /// </summary>
        public int OrderBy { get; set; }

        /// <summary>
        /// Gets or Sets CheckReceiptNo
        /// </summary>
        public string CheckReceiptNo { get; set; }

        /// <summary>
        /// Gets or Sets ReceiptDate
        /// </summary>
        public DateTime? ReceiptDate { get; set; }
    }

    /// <summary>
    /// Unposted Entry (Pending Tab) UI Class
    /// </summary>
    public class PendingFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public PendingFilter()
        {
        }

        /// <summary>
        /// PendingFilter Constructor
        /// </summary>
        /// <param name="setDefault"></param>
        public PendingFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            Invoice = true;
            DebitNote = true;
            CreditNote = true;
            Interest = true;
            Receipts = true;
            Prepayment = true;
            UnappliedCash = true;
            Apply = true;
            MiscReceipt = true;
            Refund = true;
            Adjustments = true;
            WriteOff = true;
            NationalAccounts = false;
            OrderBy = Constant.DefaultValue0;
            SortDirection = Constant.DefaultValue1;
        }

        /// <summary>
        /// Get or Set SortDirection
        /// </summary>
        public int SortDirection { get; set; }

        /// <summary>
        /// Gets or Sets Invoice
        /// </summary>
        public bool Invoice { get; set; }

        /// <summary>
        /// Gets or Sets Debit-Note
        /// </summary>
        public bool DebitNote { get; set; }

        /// <summary>
        /// Gets or Sets Credit-Note
        /// </summary>
        public bool CreditNote { get; set; }

        /// <summary>
        /// Gets or Sets Interest
        /// </summary>
        public bool Interest { get; set; }

        /// <summary>
        /// Gets or Sets Receipts
        /// </summary>
        public bool Receipts { get; set; }

        /// <summary>
        /// Gets or Sets Prepayment
        /// </summary>
        public bool Prepayment { get; set; }

        /// <summary>
        /// Gets or Sets Unapplied  Cash
        /// </summary>
        public bool UnappliedCash { get; set; }

        /// <summary>
        /// Gets or Sets Apply
        /// </summary>
        public bool Apply { get; set; }

        /// <summary>
        /// Gets or Sets Apply Miscellaneous Receipt
        /// </summary>
        public bool MiscReceipt { get; set; }

        /// <summary>
        /// Gets or Sets Refund
        /// </summary>
        public bool Refund { get; set; }

        /// <summary>
        /// Gets or Sets Adjustments
        /// </summary>
        public bool Adjustments { get; set; }

        /// <summary>
        /// Gets or Sets Write Off
        /// </summary>
        public bool WriteOff { get; set; }

        /// <summary>
        /// Gets or Sets National Account
        /// </summary>
        public bool NationalAccounts { get; set; }

        /// <summary>
        /// Gets or Sets Group By
        /// </summary>
        public bool GroupByCustomer { get; set; }

        /// <summary>
        /// Gets or Sets OrderBy
        /// </summary>
        /// 
        public int OrderBy { get; set; }

        /// <summary>
        /// Gets or Sets Customer Number
        /// </summary>
        public string CustomerNo { get; set; }

        /// <summary>
        /// Gets or Sets Is National Account
        /// </summary>
        public bool IsNationalAccount { get; set; }
    }

    /// <summary>
    /// ICContractPricing
    /// </summary>
    public class ICContractPricing
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public ICContractPricing()
        {
        }

        /// <summary>
        /// PendingFilter Constructor
        /// </summary>
        /// <param name="setDefault"></param>
        public ICContractPricing(bool setDefault)
        {
            if (!setDefault)
                return;

            SortDirection = Constant.DefaultValue1;
        }

        /// <summary>
        /// Get or Set SortDirection
        /// </summary>
        public int SortDirection { get; set; }

    }

    /// <summary>
    /// Refunds Filters model
    /// </summary>
    public class RefundsFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public RefundsFilter()
        {
        }

        /// <summary>
        /// RefundsFilter Constructor
        /// </summary>
        public RefundsFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            Outstanding = true;
            Cleared = true;
            Returned = true;
            Cash = true;
            Check = true;
            CreditCard = true;
            SpsCreditCard = true;
            StartingDocumentValue = string.Empty;
            StartingCheckValue = string.Empty;
            RefundOrderBy = RefundOrderBy.DocumentNumber;
            OrderBy = new OrderBy
            {
                PropertyName = "DocumentNumber",
                SortDirection = SortDirection.Ascending
            };
        }

        /// <summary>
        /// Gets or Sets OrderBy
        /// </summary>
        public OrderBy OrderBy { get; set; }

        /// <summary>
        /// Gets or Sets Outstanding
        /// </summary>
        public bool Outstanding { get; set; }

        /// <summary>
        /// Gets or Sets Cleared
        /// </summary>
        public bool Cleared { get; set; }

        /// <summary>
        /// Gets or Sets Returned
        /// </summary>
        public bool Returned { get; set; }

        /// <summary>
        /// Gets or Sets Cash
        /// </summary>
        public bool Cash { get; set; }

        /// <summary>
        /// Gets or Sets Check
        /// </summary>
        public bool Check { get; set; }

        /// <summary>
        /// Gets or Sets CreditCard
        /// </summary>
        public bool CreditCard { get; set; }

        /// <summary>
        /// Gets or Sets SpsCreditCard
        /// </summary>
        public bool SpsCreditCard { get; set; }

        /// <summary>
        /// Gets or Sets StartingDocumentValue
        /// </summary>
        public string StartingDocumentValue { get; set; }

        /// <summary>
        /// Gets or Sets StartingCheckValue
        /// </summary>
        public string StartingCheckValue { get; set; }

        /// <summary>
        /// Gets or Sets RefundOrderBy
        /// </summary>
        public RefundOrderBy RefundOrderBy { get; set; }
    }

    /// <summary>
    /// This class is used to pass filter from client side in Order Tab
    /// </summary>
    public class OrderEntryFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public OrderEntryFilter() { }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public OrderEntryFilter(bool setDefault)
        {
            if (!setDefault)
                return;
            ShowInvoicedShipment = true;
            ShowOnHoldOrders = true;
            OrderType = OrderTypeInquiry.All;
            OrderBy = new OrderBy
            {
                PropertyName = "OrderNumber",
                SortDirection = SortDirection.Ascending
            };
            ShipmentOrderBy = new OrderBy
            {
                PropertyName = "ShipmentNumber",
                SortDirection = SortDirection.Ascending
            };
        }

        /// <summary>
        /// Gets or sets PageNumber.
        /// </summary>
        public int PageNumber { get; set; }

        /// <summary>
        /// Gets or sets PageSize.
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber.
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets the OrderType.
        /// </summary>
        public OrderTypeInquiry OrderType { get; set; }

        /// <summary>
        /// Gets or sets ShowOnHoldOrders.
        /// </summary>
        /// <value>true/false.</value>
        public bool ShowOnHoldOrders { get; set; }

        /// <summary>
        /// Gets or sets the order by property for order grid.
        /// </summary>
        public OrderBy OrderBy { get; set; }

        /// <summary>
        /// Gets or sets showInvoicedShipment.
        /// </summary>
        /// <value>true/false.</value>
        public bool ShowInvoicedShipment { get; set; }

        /// <summary>
        /// Gets or sets the order by property for shipment grid.
        /// </summary>
        public OrderBy ShipmentOrderBy { get; set; }
    }

    /// <summary>
    /// Activity/Statistics Filters model
    /// </summary>
    public class ActivityStatisticsFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public ActivityStatisticsFilter() { }

        /// <summary>
        /// OESalesFilter Constructor
        /// </summary>
        public ActivityStatisticsFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            FiscalYear = string.Empty;
            Period = string.Empty;
        }

        /// <summary>
        /// Get or Set SortDirection
        /// </summary>
        public int SortDirection { get; set; }

        /// <summary>
        /// Get or Set FiscalYear
        /// </summary>
        public string FiscalYear { get; set; }

        /// <summary>
        /// Get or Set Period
        /// </summary>
        public string Period { get; set; }
    }

    /// <summary>
    /// OESales Filters model
    /// </summary>
    public class OESalesFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public OESalesFilter() { }

        /// <summary>
        /// OESalesFilter Constructor
        /// </summary>
        public OESalesFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            OrderBy = new OrderBy
            {
                PropertyName = "UnformattedItemNumber",
                SortDirection = SortDirection.Ascending
            };
        }

        /// <summary>
        /// Gets or Sets OrderBy
        /// </summary>
        public OrderBy OrderBy { get; set; }
    }

    /// <summary>
    /// Adjustments Filter Model
    /// </summary>
    public class AdjustmentsFilter
    {
        /// <summary>
        /// Adjustments Filter Constructor
        /// </summary>
        public AdjustmentsFilter()
        {

        }

        /// <summary>
        /// Adjustments Filter Constructor
        /// </summary>
        /// <param name="setDefault"> Set Default</param>
        public AdjustmentsFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            OrderBy = 0;
            SortDirection = SortDirection.Ascending;
        }

        /// <summary>
        /// Order By
        /// </summary>
        public int OrderBy { get; set; }

        /// <summary>
        /// Sort Direction
        /// </summary>
        public SortDirection SortDirection { get; set; }
    }

    /// <summary>
    /// ShipTo Filter Model
    /// </summary>
    public class ShipToFilter
    {
        /// <summary>
        /// ShipTo Filter Constructor
        /// </summary>
        public ShipToFilter()
        {

        }

        /// <summary>
        /// ShipTo Filter Constructor
        /// </summary>
        /// <param name="setDefault"> Set Default</param>
        public ShipToFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            OrderBy = new OrderBy
            {
                PropertyName = "ShiptoLocation",
                SortDirection = SortDirection.Ascending
            };
        }

        /// <summary>
        /// Order By
        /// </summary>
        public OrderBy OrderBy { get; set; }
    }

    /// <summary>
    /// Comments Filter Model
    /// </summary>
    public class CommentsFilter
    {
        /// <summary>
        /// Comments Filter Constructor
        /// </summary>
        public CommentsFilter()
        {

        }

        /// <summary>
        /// Comments Filter Constructor
        /// </summary>
        /// <param name="setDefault"> Set Default</param>
        public CommentsFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            OrderBy = new OrderBy
            {
                PropertyName = "DateEntered",
                SortDirection = SortDirection.Ascending
            };
            ShowOnlyCommentType = false;
            ShowOnlyUserID = false;
            ShowOnlyCommentTypeValue = string.Empty;
        }

        /// <summary>
        /// Order By
        /// </summary>
        public OrderBy OrderBy { get; set; }

        /// <summary>
        /// Gets or sets Show Only Comment Type
        /// </summary>
        public bool ShowOnlyCommentType { get; set; }

        /// <summary>
        /// Gets or sets Show Only User Id
        /// </summary>
        public bool ShowOnlyUserID { get; set; }

        /// <summary>
        /// Gets or sets Show Only Comment Type
        /// </summary>
        public string ShowOnlyCommentTypeValue { get; set; }

        /// <summary>
        /// Gets or sets Show Only User Id
        /// </summary>
        public string ShowOnlyUserIDValue { get; set; }
    }

    /// <summary>
    /// This class is used to pass filter from client side in Order Tab
    /// </summary>
    public class InvoiceFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public InvoiceFilter() { }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public InvoiceFilter(bool setDefault)
        {
            if (!setDefault)
                return;
            ShowDayEndProcessedTransactionForInvoice = true;
            ShowDayEndProcessedTransactionForCreditDebitNote = true;
            InvoiceOrderBy = new OrderBy
            {
                PropertyName = "InvoiceNumber",
                SortDirection = SortDirection.Ascending
            };
            CreditDebitNoteOrderBy = new OrderBy
            {
                PropertyName = "CreditDebitNoteNumber",
                SortDirection = SortDirection.Ascending
            };
        }

        /// <summary>
        /// Gets or sets ShowOnHoldOrders.
        /// </summary>
        /// <value>true/false.</value>
        public bool ShowDayEndProcessedTransactionForInvoice { get; set; }

        /// <summary>
        /// Gets or sets the order by property for order grid.
        /// </summary>
        public OrderBy InvoiceOrderBy { get; set; }

        /// <summary>
        /// Gets or sets showInvoicedShipment.
        /// </summary>
        /// <value>true/false.</value>
        public bool ShowDayEndProcessedTransactionForCreditDebitNote { get; set; }

        /// <summary>
        /// Gets or sets the order by property for CreditDebitNote grid.
        /// </summary>
        public OrderBy CreditDebitNoteOrderBy { get; set; }
    }

    /// <summary>
    /// Credit Status Filter Model
    /// </summary>
    public class CreditStatusFilter
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public CreditStatusFilter() { }

        /// <summary>
        /// Default Constructor
        /// </summary>
        public CreditStatusFilter(bool setDefault)
        {
            if (!setDefault)
                return;
            AgeByOrderType = CustomerInquiryAgeBy.None;
        }

        /// <summary>
        /// Gets or sets the AgeByOrderType
        /// </summary>
        public CustomerInquiryAgeBy AgeByOrderType { get; set; }

        /// <summary>
        /// AgeDocument Model
        /// </summary>
        public AgeDocument AgeDocument { get; set; }
    }

    /// <summary>
    /// RecurringCharges Filter Model
    /// </summary>
    public class RecurringChargesFilter
    {
        /// <summary>
        /// ShipTo Filter Constructor
        /// </summary>
        public RecurringChargesFilter()
        {

        }

        /// <summary>
        /// ShipTo Filter Constructor
        /// </summary>
        /// <param name="setDefault"> Set Default</param>
        public RecurringChargesFilter(bool setDefault)
        {
            if (!setDefault)
                return;

            OrderBy = new OrderBy
            {
                PropertyName = "RecurringChargeCode",
                SortDirection = SortDirection.Ascending
            };
        }

        /// <summary>
        /// Order By
        /// </summary>
        public OrderBy OrderBy { get; set; }
    }
}
