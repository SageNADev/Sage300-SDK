// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType
    /// </summary>
    public enum DocumentPaymentType
    {
        /// <summary>
        /// Gets or sets UnappliedCash
        /// </summary>
        [EnumValue("UnappliedCash", typeof(ARCommonResx))]
        UnappliedCash = 5,
        /// <summary>
        /// Gets or sets DebitNoteAppliedTo
        /// </summary>
        [EnumValue("PaymentType_DebitNoteAppliedTo", typeof(EnumerationsResx))]
        DebitNoteAppliedTo = 6,
        /// <summary>
        /// Gets or sets AppliedDebitNote
        /// </summary>
        [EnumValue("PaymentType_AppliedDebitNote", typeof(EnumerationsResx))]
        AppliedDebitNote = 7,
        /// <summary>
        /// Gets or sets CreditNoteAppliedTo
        /// </summary>
        [EnumValue("PaymentType_CreditNoteAppliedTo", typeof(EnumerationsResx))]
        CreditNoteAppliedTo = 8,
        /// <summary>
        /// Gets or sets AppliedCreditNote
        /// </summary>
        [EnumValue("PaymentType_AppliedCreditNote", typeof(EnumerationsResx))]
        AppliedCreditNote = 9,
        /// <summary>
        /// Gets or sets Prepayment
        /// </summary>
        [EnumValue("Prepayments", typeof(ARCommonResx))]
        Prepayment = 10,
        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [EnumValue("Receipt", typeof(ARCommonResx))]
        Receipt = 11,
        /// <summary>
        /// Gets or sets Discount
        /// </summary>
        [EnumValue("Discounts", typeof(ARCommonResx))]
        Discount = 12,
        /// <summary>
        /// Gets or sets Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof(ARCommonResx))]
        Adjustment = 14,
        /// <summary>
        /// Gets or sets ExchangeGainLoss
        /// </summary>
        [EnumValue("ExchangeGainOrLoss", typeof(ReceiptInquiryResx))]
        ExchangeGainLoss = 16,
        /// <summary>
        /// Gets or sets Rounding
        /// </summary>
        [EnumValue("Rounding", typeof(ARCommonResx))]
        Rounding = 17,
        /// <summary>
        /// Gets or sets Refund
        /// </summary>
        [EnumValue("Refund", typeof(ARCommonResx))]
        Refund = 19,
        /// <summary>
        /// Gets or sets Retainage
        /// </summary>
        [EnumValue("Retainage", typeof(ARCommonResx))]
        Retainage = 18,
    }
}
