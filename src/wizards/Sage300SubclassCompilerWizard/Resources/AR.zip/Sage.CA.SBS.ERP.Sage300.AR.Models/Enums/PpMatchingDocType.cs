﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for PPMatchingDocType 
    /// </summary>
    public enum PpMatchingDocType
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("CheckforDuplicateChecks_None", typeof(EnumerationsResx), 1)]
        None = 1,
        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>	
        [EnumValue("DocumentNumber", typeof(ARCommonResx), 1)]
        DocumentNumber = 2,
        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>	
        [EnumValue("PONumber", typeof(ARCommonResx), 1)]
        PONumber = 3,
        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>	
        [EnumValue("OrderNumber", typeof(ARCommonResx), 1)]
        OrderNumber = 4,
        /// <summary>
        /// Gets or sets ShipmentNumber 
        /// </summary>	
        [EnumValue("ShipmentNumber", typeof(ARCommonResx), 1)]
        ShipmentNumber = 9,
    }
}
