 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CheckforDuplicatePOs 
    /// </summary>
	public enum CheckforDuplicatePOs 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        [EnumValue("None", typeof(CommonResx))]
        None = 0,
		/// <summary>
		/// Gets or sets Warning 
		/// </summary>	
        [EnumValue("Warning", typeof(CommonResx))]
        Warning = 1,
		/// <summary>
		/// Gets or sets Error 
		/// </summary>	
        [EnumValue("Error", typeof(CommonResx))]
        Error = 2,
	}
}
