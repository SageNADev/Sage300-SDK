﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType 
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// Gets or sets UnappliedCashPosted 
        /// </summary>	
        UnappliedCashPosted = 2,
        /// <summary>
        /// Gets or sets ReceiptPosted 
        /// </summary>	
        ReceiptPosted = 51,
        /// <summary>
        /// Gets or sets PrepaymentPosted 
        /// </summary>	
        PrepaymentPosted = 57,
        /// <summary>
        /// Gets or sets AdjustmentPosted 
        /// </summary>	
        AdjustmentPosted = 81,
        /// <summary>
        /// Gets or sets WriteOffPosted 
        /// </summary>	
        WriteOffPosted = 80,
    }
}