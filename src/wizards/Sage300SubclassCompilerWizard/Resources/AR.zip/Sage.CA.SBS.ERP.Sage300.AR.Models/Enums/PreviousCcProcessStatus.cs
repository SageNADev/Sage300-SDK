/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for PreviousCcProcessStatus 
    /// </summary>
    public enum PreviousCcProcessStatus
    {
        /// <summary>
        /// Gets or sets SPSTransactionNotStarted 
        /// </summary>	
        SPSTransactionNotStarted = 0,
        /// <summary>
        /// Gets or sets SPSSalesTransactionPending 
        /// </summary>	
        SPSSalesTransactionPending = 1,
        /// <summary>
        /// Gets or sets SPSSalesTransactionCompleted 
        /// </summary>	
        SPSSalesTransactionCompleted = 2,
        /// <summary>
        /// Gets or sets SPSVoidTransactionPending 
        /// </summary>	
        SPSVoidTransactionPending = 7,
        /// <summary>
        /// Gets or sets SPSVoidTransactionCompleted 
        /// </summary>	
        SPSVoidTransactionCompleted = 8,

        /// <summary>
        /// The credit pending
        /// </summary>
        SPSCreditPending = 9,

        /// <summary>
        /// The credit complete
        /// </summary>
        SPSCreditComplete = 10
    }
}