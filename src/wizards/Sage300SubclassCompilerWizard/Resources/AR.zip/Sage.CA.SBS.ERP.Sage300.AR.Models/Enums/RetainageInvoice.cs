// /* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Retainage Invoice 
    /// </summary>
    public enum RetainageInvoice
    {
        /// <summary>
        /// Enum Retainage Invoice for No 
        /// </summary>	
        [EnumValue("No", typeof (EnumerationsResx), 0)]
        No = 0,

        /// <summary>
        /// Enum Retainage Invoice for Yes 
        /// </summary>	
        [EnumValue("Yes", typeof (EnumerationsResx), 1)]
        Yes = 1
    }
}