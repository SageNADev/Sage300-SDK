// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for BatchStatus 
    /// </summary>
    public enum EntryStatus
    {
        /// <summary>
        /// Enum status for EntryStatus - PrintedReadonly
        /// </summary>
        PrintedReadonly = 0,

        /// <summary>
        /// Enum status for EntryStatus - Editable
        /// </summary>
        Editable
    }
}
