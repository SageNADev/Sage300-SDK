/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for BatchType 
    /// </summary>
	public enum BatchType 
	{
	    /// <summary>
		/// Gets or sets Entered 
		/// </summary>	
        [EnumValue("BatchType_Entered", typeof(EnumerationsResx))]
        Entered = 1,
		/// <summary>
		/// Gets or sets Imported 
		/// </summary>	
        [EnumValue("BatchType_Imported", typeof(EnumerationsResx))]
        Imported = 2,
        /// <summary>
        /// Gets or sets Recurring
        /// </summary>      
        [EnumValue("BatchType_Generated", typeof(EnumerationsResx))]
        Generated = 3,
		/// <summary>
		/// Gets or sets Generated 
		/// </summary>	
        [EnumValue("BatchType_External", typeof(EnumerationsResx))]
        External = 4,
	}
}
