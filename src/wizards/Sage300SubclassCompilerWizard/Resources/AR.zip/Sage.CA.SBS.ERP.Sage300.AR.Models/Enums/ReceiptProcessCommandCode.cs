﻿//  Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ReceiptProcessCommandCode 
    /// </summary>
    public enum ReceiptProcessCommandCode
    {
        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("InsertOptionalFields", typeof(ReceiptEntryResx))]
        InsertOptionalFields = 0,

        /// <summary>
        /// Gets or sets CalculateTaxes 
        /// </summary>	
        [EnumValue("CalculateTaxes", typeof(ARCommonResx))]
        CalculateTaxes = 1,

        /// <summary>
        /// Gets or sets DistributeTaxes 
        /// </summary>	
        [EnumValue("DistributeTaxes", typeof(ARCommonResx))]
        DistributeTaxes = 2,

        /// <summary>
        /// Gets or sets DeriveTaxReportingExchangeRate 
        /// </summary>	
        [EnumValue("DeriveTaxReportingExchangeRate", typeof(ReceiptEntryResx))]
        DeriveTaxReportingExchangeRate = 3,
        
        /// <summary>
        /// Gets or sets QuickCharge ARTCR.DLL 
        /// </summary>	
        [EnumValue("QuickCharge", typeof(ReceiptEntryResx))]
        QuickCharge = 4,

        /// <summary>
        /// Gets or sets QuickCharge ARTCR.DLL 
        /// </summary>	
        [EnumValue("QuickhCargePart1", typeof(ReceiptEntryResx))]
        QuickChargePart1 = 41,

        /// <summary>
        /// Gets or sets QuickCharge ARTCR.DLL 
        /// </summary>	
        [EnumValue("QuickChargePart2", typeof(ReceiptEntryResx))]
        QuickChargePart2 = 42
    }
}
