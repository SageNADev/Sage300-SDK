﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for refund detail process command
    /// </summary>
    public enum RefundDetailProcessCommand
    {
        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        ClearJobDistributions = 0,

        /// <summary>
        /// Gets or sets VoidCheck 
        /// </summary>	
        AllocateJobDistributions = 1
    }
}