// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;


namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for SourceTransactionType 
    /// </summary>
    public enum SourceTransactionType
    {
        /// <summary>
        /// Gets or sets Invoice 
        /// </summary>
        [EnumValue("Invoice", typeof(GLIntegrationResx), 1)]
        Invoice = 100,
        /// <summary>
        /// Gets or sets Invoice Detail 
        /// </summary>	
        [EnumValue("InvoiceDetail", typeof(EnumerationsResx), 2)]
        InvoiceDetail = 101,
        /// <summary>
        /// Gets or sets Debit Note 
        /// </summary>	
        [EnumValue("DebitNote", typeof(GLIntegrationResx), 3)]
        DebitNote = 200,
        /// <summary>
        /// Gets or sets Debit Note Detail 
        /// </summary>	
        [EnumValue("DebitNoteDetail", typeof(EnumerationsResx), 4)]
        DebitNoteDetail = 201,
        /// <summary>
        /// Gets or sets Credit Note 
        /// </summary>	
        [EnumValue("CreditNote", typeof(GLIntegrationResx), 5)]
        CreditNote = 300,
        /// <summary>
        /// Gets or sets CreditNoteDetail 
        /// </summary>	
        [EnumValue("CreditNoteDetail", typeof(EnumerationsResx), 6)]
        CreditNoteDetail = 301,
        /// <summary>
        /// Gets or sets Receipt 
        /// </summary>	
        [EnumValue("Receipt", typeof(ARCommonResx), 7)]
        Receipt = 400,
        /// <summary>
        /// Gets or sets ReceiptDetail 
        /// </summary>	
        [EnumValue("ReceiptDetail", typeof(EnumerationsResx), 8)]
        ReceiptDetail = 401,
        /// <summary>
        /// Gets or sets ReceiptAdvanceCreditClaim 
        /// </summary>	
        [EnumValue("ReceiptAdvanceCreditClaim", typeof(EnumerationsResx), 9)]
        ReceiptAdvanceCreditClaim = 402,
        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(ARCommonResx), 10)]
        Prepayment = 500,
        /// <summary>
        /// Gets or sets UnappliedCash 
        /// </summary>	
        [EnumValue("UnappliedCash", typeof(GLIntegrationResx), 11)]
        UnappliedCash = 600,
        /// <summary>
        /// Gets or sets ApplyDocument 
        /// </summary>	
        [EnumValue("ApplyDocument", typeof(ARCommonResx), 12)]
        ApplyDocument = 700,
        /// <summary>
        /// Gets or sets ApplyDocumentDetail 
        /// </summary>	
        [EnumValue("ApplyDocumentDetail", typeof(EnumerationsResx), 13)]
        ApplyDocumentDetail = 701,
        /// <summary>
        /// Gets or sets MiscellaneousReceipt 
        /// </summary>	
        [EnumValue("MiscellaneousReceipt", typeof(ARCommonResx), 14)]
        MiscellaneousReceipt = 800,
        /// <summary>
        /// Gets or sets MiscellaneousReceiptDetail 
        /// </summary>	
        [EnumValue("MiscellaneousReceiptDetail", typeof(EnumerationsResx), 15)]
        MiscellaneousReceiptDetail = 801,
        /// <summary>
        /// Gets or sets MiscellaneousAdjustment 
        /// </summary>	
        [EnumValue("MiscellaneousAdjustment", typeof(EnumerationsResx), 16)]
        MiscellaneousAdjustment = 900,
        /// <summary>
        /// Gets or sets MiscellaneousAdjustmentDetail 
        /// </summary>	
        [EnumValue("MiscellaneousAdjustmentDetail", typeof(EnumerationsResx), 17)]
        MiscellaneousAdjustmentDetail = 901,
        /// <summary>
        /// Gets or sets Adjustment 
        /// </summary>	
        [EnumValue("Adjustment", typeof(GLIntegrationResx), 18)]
        Adjustment = 1000,
        /// <summary>
        /// Gets or sets AdjustmentDetail 
        /// </summary>	
        [EnumValue("AdjustmentDetail", typeof(EnumerationsResx), 19)]
        AdjustmentDetail = 1001,
        /// <summary>
        /// Gets or sets Refund 
        /// </summary>	
        [EnumValue("Refund", typeof(GLIntegrationResx), 20)]
        Refund = 1100,
        /// <summary>
        /// Gets or sets RefundDetail 
        /// </summary>	
        [EnumValue("RefundDetail", typeof(EnumerationsResx), 21)]
        RefundDetail = 1101,
        /// <summary>
        /// Gets or sets ReturnCustomerCheck 
        /// </summary>	
        [EnumValue("Revaluation", typeof(GLIntegrationResx), 22)]
        Revaluation = 1200,
        /// <summary>
        /// Gets or sets ReturnCustomerCheck 
        /// </summary>	
        [EnumValue("ReturnCustomerCheck", typeof(EnumerationsResx), 23)]
        ReturnCustomerCheck = 1300,
	}
}
