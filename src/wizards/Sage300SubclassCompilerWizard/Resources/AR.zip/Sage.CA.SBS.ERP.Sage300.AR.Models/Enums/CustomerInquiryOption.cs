﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CustomerInquiry Tabs
    /// </summary>
    public enum CustomerInquiryOption
    {
        /// <summary>
        /// Profile
        /// </summary>
        [EnumValue("Profile", typeof(CustomerInquiryResx))]
        Profile = 0,

        /// <summary>
        /// Address
        /// </summary>
        [EnumValue("Address", typeof(CustomerInquiryResx))]
        Address = 1,

        /// <summary>
        /// Tax/Sales
        /// </summary>
        [EnumValue("TaxSalesCard", typeof(CustomerInquiryResx))]
        TaxSalesCard = 2,

        /// <summary>
        /// Credit Status
        /// </summary>
        [EnumValue("CreditStatus", typeof(CustomerInquiryResx))]
        CreditStatus = 3,

        /// <summary>
        /// Comments
        /// </summary>
        [EnumValue("Comments", typeof(CustomerInquiryResx))]
        Comments = 4,

        /// <summary>
        /// Optional Fields
        /// </summary>
        [EnumValue("OptionalFields", typeof(CustomerInquiryResx))]
        OptionalFields = 5,

        /// <summary>
        /// Ship To
        /// </summary>
        [EnumValue("ShipTo", typeof(CustomerInquiryResx))]
        ShipTo = 6,

        /// <summary>
        /// Recurring Charges
        /// </summary>
        [EnumValue("RecurringCharges", typeof(CustomerInquiryResx))]
        RecurringCharges = 7,

        /// <summary>
        /// Activity/Stats
        /// </summary>
        [EnumValue("ActivityStats", typeof(CustomerInquiryResx))]
        ActivityStats = 8,

        ///// <summary>
        ///// Documents
        ///// </summary>
        //[EnumValue("Documents", typeof(CustomerInquiryResx))]
        //Documents = 9,

        /// <summary>
        /// Receipts
        /// </summary>
        [EnumValue("Receipts", typeof(CustomerInquiryResx))]
        Receipts = 10,

        /// <summary>
        /// Refunds
        /// </summary>
        [EnumValue("Refunds", typeof(CustomerInquiryResx))]
        Refunds = 11,

        /// <summary>
        /// Adjustments
        /// </summary>
        [EnumValue("Adjustments", typeof(CustomerInquiryResx))]
        Adjustments = 12,

        /// <summary>
        /// Pending
        /// </summary>
        [EnumValue("Pending", typeof(CustomerInquiryResx))]
        Pending = 13,

        /// <summary>
        /// OE Orders
        /// </summary>
        [EnumValue("OEOrders", typeof(CustomerInquiryResx))]
        OEOrders = 14,

        /// <summary>
        /// OE Invoices
        /// </summary>
        [EnumValue("OEInvoices", typeof(CustomerInquiryResx))]
        OEInvoices = 15,

        /// <summary>
        /// OE Sales
        /// </summary>
        [EnumValue("OESales", typeof(CustomerInquiryResx))]
        OESales = 16,

        /// <summary>
        /// IC Contract Pricing
        /// </summary>
        [EnumValue("ICContractPricing", typeof(CustomerInquiryResx))]
        ICContractPricing = 17
    }
}
