// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for ProcessCommandCode 
    /// </summary>
    public enum CustGrpProcessCommandCode 
	{
			/// <summary>
		/// Gets or sets InsertOptionalFields 
		/// </summary>	
        [EnumValue("InsertOptionalFields", typeof(CustomerGroupsResx))]
        InsertOptionalFields = 0,
	}
}
