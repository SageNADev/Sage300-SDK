﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for TransactionTypeId 
    /// </summary>
    public enum TransactionTypeId
    {
        /// <summary>
        /// Gets or sets UnappliedCashPosted 
        /// </summary>	
        UnappliedCashPosted = 1,
        /// <summary>
        /// Gets or sets InvoiceItemIssued 
        /// </summary>	
        InvoiceItemIssued = 11,
        /// <summary>
        /// Gets or sets InvoiceSummaryEntered 
        /// </summary>	
        InvoiceSummaryEntered = 12,
        /// <summary>
        /// Gets or sets InvoiceRecurringCharge 
        /// </summary>	
        InvoiceRecurringCharge = 13,
        /// <summary>
        /// Gets or sets InvoiceSummaryIssued 
        /// </summary>	
        InvoiceSummaryIssued = 14,
        /// <summary>
        /// Gets or sets InvoiceItemEntered 
        /// </summary>	
        InvoiceItemEntered = 15,
        /// <summary>
        /// Gets or sets DebitNoteItemIssued 
        /// </summary>	
        DebitNoteItemIssued = 21,
        /// <summary>
        /// Gets or sets DebitNoteSummaryEntered 
        /// </summary>	
        DebitNoteSummaryEntered = 22,
        /// <summary>
        /// Gets or sets DebitNoteSummaryIssued 
        /// </summary>	
        DebitNoteSummaryIssued = 24,
        /// <summary>
        /// Gets or sets DebitNoteItemEntered 
        /// </summary>	
        DebitNoteItemEntered = 25,
        /// <summary>
        /// Gets or sets DebitNoteAdvanceCreditClaim 
        /// </summary>	
        DebitNoteAdvanceCreditClaim = 26,
        /// <summary>
        /// Gets or sets CreditNoteItemIssued 
        /// </summary>	
        CreditNoteItemIssued = 31,
        /// <summary>
        /// Gets or sets CreditNoteSummaryEntered 
        /// </summary>	
        CreditNoteSummaryEntered = 32,
        /// <summary>
        /// Gets or sets CreditNoteSummaryIssued 
        /// </summary>	
        CreditNoteSummaryIssued = 34,
        /// <summary>
        /// Gets or sets CreditNoteItemEntered 
        /// </summary>	
        CreditNoteItemEntered = 35,
        /// <summary>
        /// Gets or sets InterestCharge 
        /// </summary>	
        InterestCharge = 40,
        /// <summary>
        /// Gets or sets PrepaymentPosted 
        /// </summary>	
        PrepaymentPosted = 50,
        /// <summary>
        /// Gets or sets ReceiptPosted 
        /// </summary>	
        ReceiptPosted = 51,
        /// <summary>
        /// Gets or sets RefundPosted 
        /// </summary>	
        RefundPosted = 73,
    }
}
