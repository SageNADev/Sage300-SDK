// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CustomerDiscountType 
    /// </summary>
	public enum CustomerDiscountType 
	{
		/// <summary>
		/// Gets or sets Base 
		/// </summary>	
       [EnumValue("Base", typeof(CustomersResx))]
        Base = 0,
		/// <summary>
		/// Gets or sets A 
		/// </summary>	
        [EnumValue("A", typeof(CustomersResx))]
        A = 1,
		/// <summary>
		/// Gets or sets B 
		/// </summary>	
        [EnumValue("B", typeof(CustomersResx))]
        B = 2,
		/// <summary>
		/// Gets or sets C 
		/// </summary>	
        [EnumValue("C", typeof(CustomersResx))]
        C = 3,
		/// <summary>
		/// Gets or sets D 
		/// </summary>	
        [EnumValue("D", typeof(CustomersResx))]
        D = 4,
		/// <summary>
		/// Gets or sets E 
		/// </summary>	
        [EnumValue("E", typeof(CustomersResx))]
        E = 5,
	}
}
