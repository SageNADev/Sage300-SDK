// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Default Order of Open Documents 
    /// </summary>
    public enum DefaultOrderofOpenDocuments
    {
        /// <summary>
        /// Gets or sets Document Number 
        /// </summary>	
        [EnumValue("DocumentNumber", typeof (ARCommonResx), 1)] DocumentNumber = 1,

        /// <summary>
        /// Gets or sets PO Number 
        /// </summary>	
        [EnumValue("PONumber", typeof (ARCommonResx), 2)] PONumber = 2,

        /// <summary>
        /// Gets or sets Due Date 
        /// </summary>	
        [EnumValue("DueDate", typeof (ARCommonResx), 3)] DueDate = 3,

        /// <summary>
        /// Gets or sets Order Number 
        /// </summary>	
        [EnumValue("OrderNumber", typeof (ARCommonResx), 4)] OrderNumber = 4,

        /// <summary>
        /// Gets or sets Document Date 
        /// </summary>	
        [EnumValue("DocumentDate", typeof (ARCommonResx), 5)] DocumentDate = 5,

        /// <summary>
        /// Gets or sets Current Balance 
        /// </summary>	
        [EnumValue("CurrentBalance", typeof (ARCommonResx), 6)] CurrentBalance = 6,

        /// <summary>
        /// Gets or sets Shipment Number 
        /// </summary>	
        [EnumValue("ShipmentNumber", typeof (ARCommonResx), 7)] ShipmentNumber = 7,

        /// <summary>
        /// Gets or sets Original Document Number
        /// </summary>	
        [EnumValue("DefaultOrderofOpenDocuments_OriginalDocNo", typeof (EnumerationsResx), 8)] OriginalDocNo = 8,
    }
}