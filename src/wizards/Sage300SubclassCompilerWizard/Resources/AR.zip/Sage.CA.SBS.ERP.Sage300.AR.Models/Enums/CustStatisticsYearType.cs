// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CustStatisticsYearType 
    /// </summary>
    public enum CustStatisticsYearType
    {
        /// <summary>
        /// Gets or sets CalendarYear 
        /// </summary>	
        CalendarYear = 1,

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>	
        FiscalYear = 2,
    }
}