﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Statistics Period Type 
    /// </summary>
    public enum StatisticsPeriodType
    {
        /// <summary>
        /// Gets or sets Weekly 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Weekly", typeof (EnumerationsResx), 1)] Weekly = 1,

        /// <summary>
        /// Gets or sets Sevendays 
        /// </summary>
        [EnumValue("StatisticsPeriod_Sevendays", typeof (EnumerationsResx), 2)] Sevendays = 2,

        /// <summary>
        /// Gets or sets Biweekly 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Biweekly", typeof (EnumerationsResx), 3)] Biweekly = 3,

        /// <summary>
        /// Gets or sets Four weeks 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Fourweeks", typeof (EnumerationsResx), 4)] Fourweeks = 4,

        /// <summary>
        /// Gets or sets Monthly 
        /// </summary>
        [EnumValue("StatisticsPeriod_Monthly", typeof (EnumerationsResx), 5)] Monthly = 5,

        /// <summary>
        /// Gets or sets Bimonthly 
        /// </summary>
        [EnumValue("StatisticsPeriod_Bimonthly", typeof (EnumerationsResx), 6)] Bimonthly = 6,

        /// <summary>
        /// Gets or sets Quarterly 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Quarterly", typeof (EnumerationsResx), 7)] Quarterly = 7,

        /// <summary>
        /// Gets or sets Semiannually 
        /// </summary>	
        [EnumValue("StatisticsPeriod_Semiannually", typeof (EnumerationsResx), 8)] Semiannually = 8,

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>	
        [EnumValue("StatisticsPeriod_FiscalPeriod", typeof (EnumerationsResx), 9)] FiscalPeriod = 9,
    }
}