// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for BillingType
    /// </summary>
    public enum BillingType
    {
        /// <summary>
        /// Gets or sets Nonbillable
        /// </summary>
        [EnumValue("Nonbillable", typeof(JobResourceValidationResx))]
        Nonbillable = 1,
        /// <summary>
        /// Gets or sets Billable
        /// </summary>
        [EnumValue("Billable", typeof(JobResourceValidationResx))]
        Billable = 2,
        /// <summary>
        /// Gets or sets NoCharge
        /// </summary>
        [EnumValue("NoCharge", typeof(JobResourceValidationResx))]
        NoCharge = 3
    }
}