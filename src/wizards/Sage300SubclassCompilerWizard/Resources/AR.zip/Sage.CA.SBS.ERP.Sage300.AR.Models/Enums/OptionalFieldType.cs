// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Type 
    /// </summary>
    public enum OptionalFieldType
    {
        /// <summary>
        /// Gets or sets Text 
        /// </summary>	
        [EnumValue("Text", typeof(ARCommonResx))]
        Text = 1,

        /// <summary>
        /// Gets or sets Amount 
        /// </summary>	
        [EnumValue("Amount", typeof(ARCommonResx))]
        Amount = 100,

        /// <summary>
        /// Gets or sets Number 
        /// </summary>	
        [EnumValue("Number", typeof(ARCommonResx))]
        Number = 6,

        /// <summary>
        /// Gets or sets Integer 
        /// </summary>	
        [EnumValue("Integer", typeof(ARCommonResx))]
        Integer = 8,

        /// <summary>
        /// Gets or sets YesOrNo 
        /// </summary>	
        [EnumValue("YesOrNo", typeof(ARCommonResx))]
        YesOrNo = 9,

        /// <summary>
        /// Gets or sets Date 
        /// </summary>	
        [EnumValue("Date", typeof(ARCommonResx))]
        Date = 3,

        /// <summary>
        /// Gets or sets Time 
        /// </summary>	
        [EnumValue("Time", typeof(ARCommonResx))]
        Time = 4
    }
}