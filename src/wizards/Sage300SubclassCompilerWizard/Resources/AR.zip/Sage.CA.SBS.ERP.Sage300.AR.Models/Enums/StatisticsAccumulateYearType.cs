﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Statistics Accumulate By
    /// </summary>
    public enum StatisticsAccumulateYearType
    {
        /// <summary>
        /// Gets or sets Calendar Year 
        /// </summary>
        [EnumValue("StatisticsAccumulate_CalendarYear", typeof (EnumerationsResx), 1)] CalendarYear = 1,

        /// <summary>
        /// Gets or sets Fiscal Year 
        /// </summary>	
        [EnumValue("StatisticsAccumulate_FiscalYear", typeof (EnumerationsResx), 2)] FiscalYear = 2
    }
}