﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Letter And Label Report Delivery Method
    /// </summary>
    public enum DeliveryMethodType
    {
        /// <summary>
        /// Gets or sets PrintDestination
        /// </summary>	
        [EnumValue("PrintDestination", typeof(ARCommonResx))]
        PrintDestination=0,

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [EnumValue("Customer", typeof(ARCommonResx))]
        Customer=1
    }
}
