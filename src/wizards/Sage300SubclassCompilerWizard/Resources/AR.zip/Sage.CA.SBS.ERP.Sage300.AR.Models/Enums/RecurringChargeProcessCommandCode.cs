﻿//  Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Process Command Codes for AR Recurring Charge screen
    /// </summary>
    public enum RecurringChargeProcessCommandCode
    {
        /// <summary>
        /// Insert Optional Fields command code
        /// </summary>	
        InsertOptionalFields = 0,

        /// <summary>
        /// Calculate Taxes command code
        /// </summary>	
        CalculateTaxes = 1,

        /// <summary>
        /// Distribute Taxes command code
        /// </summary>	
        DistributeTaxes = 2
    }
}
