// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Change By Type
    /// </summary>
    public enum ChangeByType
    {
        /// <summary>
        /// Change By Percentage
        /// </summary>
        [EnumValue("Percentage", typeof(ARCommonResx))]
        Percentage = 1,

        /// <summary>
        /// Change by Amount
        /// </summary>
        [EnumValue("Amount", typeof(ARCommonResx))]
        Amount = 2
    }
}
