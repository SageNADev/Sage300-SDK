﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum document type
    /// </summary>
    public enum DocumentType
    {
        /// <summary>
        /// Invoice
        /// </summary>
        [EnumValue("DocumentType_Invoice", typeof (EnumerationsResx), 1)] Invoice = 1,

        /// <summary>
        /// Debit note
        /// </summary>
        [EnumValue("DocumentType_DebitNote", typeof (EnumerationsResx), 2)] DebitNote = 2,

        /// <summary>
        /// Credit note
        /// </summary>
        [EnumValue("DocumentType_CreditNote", typeof (EnumerationsResx), 3)] CreditNote = 3,

        /// <summary>
        /// Interest invoice
        /// </summary>
        [EnumValue("DocumentType_Interest", typeof (EnumerationsResx), 4)] InterestInvoice = 4,

        /// <summary>
        /// Retainage Invoice
        /// </summary>
        [EnumValue("DocumentType_RetainageInvoice", typeof (EnumerationsResx), 5)] RetainageInvoice = 5,

        /// <summary>
        /// Retainage Debit Note
        /// </summary>
        [EnumValue("DocumentType_RetainageDebitNote", typeof (EnumerationsResx), 6)] RetainageDebitNote = 6,

        /// <summary>
        /// Retainage Credit Note
        /// </summary>
        [EnumValue("DocumentType_RetainageCreditNote", typeof (EnumerationsResx), 7)] RetainageCreditNote = 7,

    }
}
