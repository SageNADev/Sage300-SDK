// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum DocumentPaymentTransactionType
    {
        /// <summary>
        /// Gets or sets UnappliedCashApplied
        /// </summary>
        [EnumValue("DocumentType_UnappliedCashApplied", typeof(EnumerationsResx))]
        UnappliedCashApplied = 3,
        /// <summary>
        /// Gets or sets UnappliedCashReversed
        /// </summary>
        [EnumValue("DocumentType_UnappliedCashReversed", typeof(EnumerationsResx))]
        UnappliedCashReversed = 4,
        /// <summary>
        /// Gets or sets DebitNoteAppliedTo
        /// </summary>
        [EnumValue("DocumentType_DebitNoteAppliedTo", typeof(EnumerationsResx))]
        DebitNoteAppliedTo = 41,
        /// <summary>
        /// Gets or sets AppliedDebitNote
        /// </summary>
        [EnumValue("DocumentType_AppliedDebitNote", typeof(EnumerationsResx))]
        AppliedDebitNote = 42,
        /// <summary>
        /// Gets or sets CreditNoteAppliedTo
        /// </summary>
        [EnumValue("DocumentType_CreditNoteAppliedTo", typeof(EnumerationsResx))]
        CreditNoteAppliedTo = 43,
        /// <summary>
        /// Gets or sets AppliedCreditNote
        /// </summary>
        [EnumValue("DocumentType_AppliedCreditNote", typeof(EnumerationsResx))]
        AppliedCreditNote = 44,
        /// <summary>
        /// Gets or sets ReceiptPosted
        /// </summary>
        [EnumValue("DocumentType_ReceiptPosted", typeof(EnumerationsResx))]
        ReceiptPosted = 51,
        /// <summary>
        /// Gets or sets ReceiptApplied
        /// </summary>
        [EnumValue("DocumentType_ReceiptApplied", typeof(EnumerationsResx))]
        ReceiptApplied = 52,
        /// <summary>
        /// Gets or sets ReceiptReversed
        /// </summary>
        [EnumValue("DocumentType_ReceiptReversed", typeof(EnumerationsResx))]
        ReceiptReversed = 53,
        /// <summary>
        /// Gets or sets PrepaymentApplied
        /// </summary>
        [EnumValue("DocumentType_PrepaymentApplied", typeof(EnumerationsResx))]
        PrepaymentApplied = 58,
        /// <summary>
        /// Gets or sets PrepaymentReversed
        /// </summary>
        [EnumValue("DocumentType_PrepaymentReversed", typeof(EnumerationsResx))]
        PrepaymentReversed = 59,
        /// <summary>
        /// Gets or sets DiscountPosted
        /// </summary>
        [EnumValue("DocumentType_DiscountPosted", typeof(EnumerationsResx))]
        DiscountPosted = 61,
        /// <summary>
        /// Gets or sets DiscountReversed
        /// </summary>
        [EnumValue("DocumentType_DiscountReversed", typeof(EnumerationsResx))]
        DiscountReversed = 63,
        /// <summary>
        /// Gets or sets ExchangeGainLossPosted
        /// </summary>
        [EnumValue("DocumentType_ExchangeGainLossPosted", typeof(EnumerationsResx))]
        ExchangeGainLossPosted = 65,
        /// <summary>
        /// Gets or sets ExchangeGainLossReversed
        /// </summary>
        [EnumValue("DocumentType_ExchangeGainLossReversed", typeof(EnumerationsResx))]
        ExchangeGainLossReversed = 67,
        /// <summary>
        /// Gets or sets RoundingPosted
        /// </summary>
        [EnumValue("DocumentType_RoundingPosted", typeof(EnumerationsResx))]
        RoundingPosted = 91,
        /// <summary>
        /// Gets or sets RoundingReversed
        /// </summary>
        [EnumValue("DocumentType_RoundingReversed", typeof(EnumerationsResx))]
        RoundingReversed = 93,
        /// <summary>
        /// Gets or sets UnrealizedExchangeGainLoss
        /// </summary>
        [EnumValue("DocumentType_UnrealizedExchangeGainLoss", typeof(EnumerationsResx))]
        UnrealizedExchangeGainLoss = 69,
        /// <summary>
        /// Gets or sets WriteOffPosted
        /// </summary>
        [EnumValue("DocumentType_WriteOffPosted", typeof(EnumerationsResx))]
        WriteOffPosted = 80,
        /// <summary>
        /// Gets or sets AdjustmentPosted
        /// </summary>
        [EnumValue("DocumentType_AdjustmentPosted", typeof(EnumerationsResx))]
        AdjustmentPosted = 81,
        /// <summary>
        /// Gets or sets AdjustmentReversed
        /// </summary>
        [EnumValue("DocumentType_AdjustmentReversed", typeof(EnumerationsResx))]
        AdjustmentReversed = 83,
        /// <summary>
        /// Gets or sets RefundPosted
        /// </summary>
        [EnumValue("DocumentType_RefundPosted", typeof(EnumerationsResx))]
        RefundPosted = 73,
        /// <summary>
        /// Gets or sets RefundReversed
        /// </summary>
        [EnumValue("DocumentType_RefundReversed", typeof(EnumerationsResx))]
        RefundReversed = 75,
        /// <summary>
        /// Gets or sets RetainageInvoiced
        /// </summary>
        [EnumValue("DocumentType_RetainageInvoiced", typeof(EnumerationsResx))]
        RetainageInvoiced = 100,
        /// <summary>
        /// Gets or sets RetainageAdjusted
        /// </summary>
        [EnumValue("DocumentType_RetainageAdjusted", typeof(EnumerationsResx))]
        RetainageAdjusted = 101,
        /// <summary>
        /// Gets or sets RetainageRevalued
        /// </summary>
        [EnumValue("DocumentType_RetainageRevalued", typeof(EnumerationsResx))]
        RetainageRevalued = 102,
        /// <summary>
        /// Gets or sets RetainageExchangeGainLoss
        /// </summary>
        [EnumValue("DocumentType_RetainageExchangeGainLoss", typeof(EnumerationsResx))]
        RetainageExchangeGainLoss = 103,
        /// <summary>
        /// Gets or sets RetainageRounding
        /// </summary>
        [EnumValue("DocumentType_RetainageRounding", typeof(EnumerationsResx))]
        RetainageRounding = 104,
        /// <summary>
        /// Gets or sets ReceiptInvoiceReversed
        /// </summary>
        [EnumValue("DocumentType_ReceiptInvoiceReversed", typeof(EnumerationsResx))]
        ReceiptInvoiceReversed = 85,
        /// <summary>
        /// Gets or sets TaxWithheldPosted
        /// </summary>
        [EnumValue("DocumentType_TaxWithheldPosted", typeof(EnumerationsResx))]
        TaxWithheldPosted = 105,
        /// <summary>
        /// Gets or sets TaxWithheldReversed
        /// </summary>
        [EnumValue("DocumentType_TaxWithheldReversed", typeof(EnumerationsResx))]
        TaxWithheldReversed = 106,
    }
}
