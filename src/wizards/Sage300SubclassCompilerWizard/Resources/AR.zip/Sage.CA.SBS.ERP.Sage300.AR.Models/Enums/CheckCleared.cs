// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CheckCleared
    /// </summary>
    public enum CheckCleared
    {
        /// <summary>
        /// Gets or sets Outstanding
        /// </summary>
        [EnumValue("Outstanding", typeof(ARCommonResx))]
        Outstanding = 0,

        /// <summary>
        /// Gets or sets Cleared
        /// </summary>
        [EnumValue("Cleared", typeof(ARCommonResx))]
        Cleared = 1,

        /// <summary>
        /// Gets or sets Returned
        /// </summary>
        [EnumValue("Returned", typeof(ARCommonResx))]
        Returned = 2
    }
}
