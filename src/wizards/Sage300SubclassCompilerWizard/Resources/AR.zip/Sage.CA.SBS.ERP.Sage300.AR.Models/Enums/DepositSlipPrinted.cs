// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for DepositSlipPrinted 
    /// </summary>
	public enum DepositSlipPrinted 
	{
		/// <summary>
		/// Gets or sets No 
		/// </summary>	
        [EnumValue("DepositSlipPrinted_No", typeof(EnumerationsResx))]
        No = 1,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        [EnumValue("DepositSlipPrinted_Yes", typeof(EnumerationsResx))]
        Yes = 2,
	}
}
