/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */
/* Portions co-modified with Claude Code */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Contains List of Options Switch Enum for ARRIB (Create Reverse Invoice Batch)
    /// </summary>
    public enum OptionSwitch
    {
        /// <summary>
        /// The create new batch
        /// </summary>
        CreateNewBatch = 1,

        /// <summary>
        /// The create reverse entry
        /// </summary>
        CreateReverseEntry = 2,

        /// <summary>
        /// The create reverse batch
        /// </summary>
        CreateReverseBatch = 3,
    }
}
