// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for DeliveryMethod 
    /// </summary>
    public enum DeliveryMethodNationalAccount
    {
        /// <summary>
        /// Gets or sets Mail 
        /// </summary>	
        [EnumValue("DeliveryMethod_Mail", typeof(EnumerationsResx), 1)]
        Mail = 0,

        /// <summary>
        /// Gets or sets Email 
        /// </summary>	
        [EnumValue("DeliveryMethod_EmailNationalAccount", typeof(EnumerationsResx), 2)]
        Email = 2,

        /// <summary>
        /// Gets or sets ContactsEmail
        /// </summary>	
        [EnumValue("DeliveryMethod_ContactsEmail", typeof(EnumerationsResx), 3)]
        ContactsEmail = 4,

            /// <summary>
        /// Gets or sets ContactList
        /// </summary>	
        [EnumValue("DeliveryMethod_ContactList", typeof(EnumerationsResx), 4)]
        ContactList = 5
    }
}