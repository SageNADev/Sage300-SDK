 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for ExpirationType 
    /// </summary>
	public enum ExpirationType 
	{
			/// <summary>
		/// Gets or sets NoExpiration 
		/// </summary>
        [EnumValue("NoExpiration", typeof(CommonResx))]
        NoExpiration = 0,

		/// <summary>
		/// Gets or sets SpecificDate 
		/// </summary>
        [EnumValue("SpecificDate", typeof(CommonResx))]	
        SpecificDate = 1,

		/// <summary>
		/// Gets or sets MaximumAmount 
		/// </summary>
        [EnumValue("MaximumAmount", typeof(CommonResx))]	
        MaximumAmount = 2,

		/// <summary>
		/// Gets or sets NumberofInvoices 
		/// </summary>
        [EnumValue("NumberofInvoices", typeof(CommonResx))]	
        NumberofInvoices = 3,
	}
}
