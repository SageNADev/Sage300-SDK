// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for MessageType 
    /// </summary>
    public enum MessageType
    {
        /// <summary>
        /// Gets or sets InvoiceEmail 
        /// </summary>	
        [EnumValue("InvoiceEmail", typeof (EmailMessagesResx), 0)] InvoiceEmail = 0,

        /// <summary>
        /// Gets or sets StatementEmail 
        /// </summary>	
        [EnumValue("StatementEmail", typeof (EmailMessagesResx), 1)] StatementEmail = 1,

        /// <summary>
        /// Gets or sets LetterEmail 
        /// </summary>	
        [EnumValue("LetterEmail", typeof (EmailMessagesResx), 2)] LetterEmail = 2,

        /// <summary>
        /// Gets or sets ReceiptEmail 
        /// </summary>	
        [EnumValue("ReceiptEmail", typeof (EmailMessagesResx), 6)] ReceiptEmail = 6,
    }
}