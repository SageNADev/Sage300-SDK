﻿
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// ToDo : This has to be moved to common Using in KPI and AR Modules
    /// </summary>
    public enum Ageby
    {
        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>	
        [EnumValue("DueDate", typeof(ARCommonResx))]
        DueDate = 0,
        /// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>	
        [EnumValue("DocumentDate", typeof(ARCommonResx))]
        DocumentDate = 1,
    }
}
