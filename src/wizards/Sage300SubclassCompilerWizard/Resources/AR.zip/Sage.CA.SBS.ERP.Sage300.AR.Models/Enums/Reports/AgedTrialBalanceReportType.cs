﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
     /// <summary>
    /// Aged Trial Balance Reports Types
    /// </summary>
    public enum AgedTrialBalanceReportTypes
    {
        /// <summary>
        /// Gets or sets ATB By Due Date
        /// </summary>	
        [EnumValue("ATBByDueDate", typeof(AgedTrialBalanceResx))]
        ATBByDueDate = 1,

        /// <summary>
        /// Gets or sets ATB By Document Date 
        /// </summary>	
        [EnumValue("ATBByDocDate", typeof(AgedTrialBalanceResx))]
        ATBByDocDate = 2,

        /// <summary>
        /// Gets or sets Overdue By Due Date 
        /// </summary>	
        [EnumValue("ORByDueDate", typeof(AgedTrialBalanceResx))]
        ORByDueDate = 3,

        /// <summary>
        ///  Gets or sets Overdue By Document Date 
        /// </summary>
        [EnumValue("ORByDocDate", typeof(AgedTrialBalanceResx))]
        ORByDocDate
        


    }
}