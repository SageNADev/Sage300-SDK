﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region 

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Print Amount In
    /// </summary>
    public enum PrintAmountIn
    {
        /// <summary>
        /// Gets or sets Functional Currency 
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(CommonResx))]
        FunctionalCurrency = 0,

        /// <summary>
        /// Gets or sets Customer Currency 
        /// </summary>
        [EnumValue("CustomerCurrency", typeof(ARCommonResx))]
        CustomerCurrency = 1
    }
}

