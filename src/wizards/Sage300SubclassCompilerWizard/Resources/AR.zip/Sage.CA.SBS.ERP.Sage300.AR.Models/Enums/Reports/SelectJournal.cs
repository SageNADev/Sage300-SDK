﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for SelectJournal
    /// </summary>
    public enum SelectJournal
    {
        #region Enum for SelectJournal

        /// <summary>
        /// The Invoice
        /// </summary>
        [EnumValue("Invoice", typeof (ARCommonResx))] Invoice = 0,

        /// <summary>
        /// The Receipt
        /// </summary>
        [EnumValue("Receipt", typeof (ARCommonResx))] Receipt = 1,

        /// <summary>
        /// The Adjustment
        /// </summary>
        [EnumValue("Adjustment", typeof (ARCommonResx))] Adjustment = 2,

        /// <summary>
        /// The Refund
        /// </summary>
        [EnumValue("Refund", typeof (ARCommonResx))] Refund = 3,

        /// <summary>
        /// The Revaluation
        /// </summary>
        [EnumValue("Revaluation", typeof (ARCommonResx))] Revaluation = 4,

        /// <summary>
        /// The ProvisionalRevaluation
        /// </summary>
        [EnumValue("ProvisionalRevaluation", typeof (ARCommonResx))] ProvisionalRevaluation = 5,

        #endregion
    }
}