// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for ATBOrOverdueRecReport 
    /// </summary>
    public enum AtbOrOverdueRecReport
    {
        #region Enum

        /// <summary>
        /// Gets or sets FutureRetainage 
        /// </summary>	
        [EnumValue("FutureRetainage", typeof(AgedRetainageResx))]
        FutureRetainage = 0,
        /// <summary>
        /// Gets or sets AgedRetainage 
        /// </summary>	
        [EnumValue("Retainage", typeof(AgedRetainageResx))]
        AgedRetainage = 1,
        /// <summary>
        /// Gets or sets OverdueRetainage 
        /// </summary>	
        [EnumValue("OverdueRetainage", typeof(AgedRetainageResx))]
        OverdueRetainage = 2,

        #endregion
    }
}
