﻿using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Report Format Type 1. National Account List 2. National Account Activity Statistics 3. National Account Period Statistics
    /// </summary>
    public enum NationalAccountReportType
    {
        /// <summary>
        /// VendorGroupList
        /// </summary>
        [EnumValue("NationalAccountList", typeof(NationalAccountsReportResx), 0)]
        NationalAccountList = 0,

        /// <summary>
        /// VendorGroupStatistics
        /// </summary>
        [EnumValue("NationalAccountActivityStatistics", typeof(NationalAccountsReportResx), 1)]
        NationalAccountActivityStatistics = 1,

        /// <summary>
        /// VendorGroupStatistics
        /// </summary>
        [EnumValue("NationalAccountPeriodStatistics", typeof(NationalAccountsReportResx), 2)]
        NationalAccountPeriodStatistics = 2
    }
}
