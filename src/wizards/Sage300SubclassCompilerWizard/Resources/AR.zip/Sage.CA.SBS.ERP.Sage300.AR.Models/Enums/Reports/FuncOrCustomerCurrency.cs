// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for FuncOrCustomerCurrency 
    /// </summary>
    public enum FuncOrCustomerCurrency
    {

        #region Enum

        /// <summary>
        /// Gets or sets CustomerCurrency 
        /// </summary>	
        [EnumValue("CustomerCurrency", typeof(ARCommonResx))]
        CustomerCurrency = 0,
        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>	
        [EnumValue("FunctionalCurrency", typeof(ARCommonResx))]
        FunctionalCurrency = 1,

        #endregion
    }
}
