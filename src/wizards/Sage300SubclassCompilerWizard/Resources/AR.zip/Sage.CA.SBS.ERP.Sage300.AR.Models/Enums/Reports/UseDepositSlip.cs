// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
	/// <summary>
    /// Enum for DetailSort 
    /// </summary>
    public enum UseDepositSlip 
	{
        /// <summary>
        /// Gets or sets BKDPST01
        /// </summary>
        [EnumValue("BKDPST01", typeof(DepositSlipResx), 1)]
        BKDPST01 = 0,

        /// <summary>
        /// Gets or sets BKDPST02
        /// </summary>
        [EnumValue("BKDPST02", typeof(DepositSlipResx), 1)]
        BKDPST02 = 1,
	}
}