﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// 
    /// </summary>
    public enum SortByReport
    {
        /// <summary>
        /// The account no
        /// </summary>
        [EnumValue("Statement", typeof(StatementsLettersLabelsResx))]
        Statement = 0,

        /// <summary>
        /// The segment
        /// </summary>
        [EnumValue("Letter", typeof(StatementsLettersLabelsResx))]
        Letter = 1,

        /// <summary>
        /// The account group
        /// </summary>
        [EnumValue("Label", typeof(StatementsLettersLabelsResx))]
        Label = 2
    }
}
