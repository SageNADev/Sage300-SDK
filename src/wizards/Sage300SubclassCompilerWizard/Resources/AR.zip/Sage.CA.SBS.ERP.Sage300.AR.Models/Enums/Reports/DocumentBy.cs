﻿using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Document By Enum
    /// </summary>
    public enum DocumentBy
    {

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>	
        [EnumValue("DocumentNumber", typeof(ARCommonResx))]
        DocumentNumber = 0,

        /// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>	
        [EnumValue("DocumentDate", typeof(ARCommonResx))]
        DocumentDate = 1,
    }
}
