﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum CustomerReportType
    /// </summary>
    public enum CustomerReportType
    {
        /// <summary>
        /// Gets or sets Customers
        /// </summary>
        [EnumValue("Customers", typeof(CustomersReportResx))]
        Customers = 0,

        /// <summary>
        /// Gets or sets Customer Activity Statistics
        /// </summary>
        [EnumValue("CustActStatistics", typeof(CustomersReportResx))]
        CustomerActivityStatistics = 1,

        /// <summary>
        /// Gets or sets Customer Period Statistics
        /// </summary>
        [EnumValue("CustPrdStatistics", typeof(CustomersReportResx))]
        CustomerPeriodStatistics = 2,

        /// <summary>
        /// Gets or sets Customer Comments
        /// </summary>
        [EnumValue("CustComments", typeof(CustomersReportResx))]
        CustomerComments = 3,
    }
}
