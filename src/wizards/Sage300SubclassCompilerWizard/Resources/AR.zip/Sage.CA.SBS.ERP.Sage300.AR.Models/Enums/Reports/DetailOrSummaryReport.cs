// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
	/// <summary>
    /// Enum for DetailOrSummaryReport 
    /// </summary>
	public enum DetailOrSummaryReport 
	{
			/// <summary>
		/// Gets or sets Summary 
		/// </summary>	
        [EnumValue("Summary", typeof(ARCommonResx))]
        Summary = 0,
		/// <summary>
		/// Gets or sets DetailbyDocument 
		/// </summary>	
        [EnumValue("DetailByDocumentNumber", typeof(ARCommonResx))]
        DetailbyDocument = 1,
		/// <summary>
		/// Gets or sets DetailbyDate 
		/// </summary>	
        [EnumValue("DetailByDocumentDate", typeof(ARCommonResx))]
        DetailbyDate = 2,
		/// <summary>
		/// Gets or sets DetailbyRetainageDueDate 
		/// </summary>	
        [EnumValue("DetailByRTGDateDue", typeof(ARCommonResx))]
        DetailbyRetainageDueDate = 3,
	}
}
