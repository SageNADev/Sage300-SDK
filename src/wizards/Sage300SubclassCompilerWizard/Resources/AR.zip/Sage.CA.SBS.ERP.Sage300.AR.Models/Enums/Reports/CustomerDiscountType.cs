﻿
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for CustomerDiscountType 
    /// </summary>
    public enum CustomerDiscountType
    {
        /// <summary>
        /// Gets or sets Base 
        /// </summary>	
        Base = 0,
        /// <summary>
        /// Gets or sets A 
        /// </summary>	
        A = 1,
        /// <summary>
        /// Gets or sets B 
        /// </summary>	
        B = 2,
        /// <summary>
        /// Gets or sets C 
        /// </summary>	
        C = 3,
        /// <summary>
        /// Gets or sets D 
        /// </summary>	
        D = 4,
        /// <summary>
        /// Gets or sets E 
        /// </summary>	
        E = 5,
    }
}
