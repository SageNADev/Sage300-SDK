﻿
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for NATStatementSwitch 
    /// </summary>
    public enum NATStatementSwitch
    {
        /// <summary>
        /// Gets or sets CustomerStatements 
        /// </summary>
        [EnumValue("CustomerStatements", typeof(StatementsLettersLabelsResx))]	
        CustomerStatements = 0,
        /// <summary>
        /// Gets or sets NationalAcctStatements 
        /// </summary>
       [EnumValue("NationalAcctStatements", typeof(StatementsLettersLabelsResx))]		
        NationalAcctStatements = 1,
        /// <summary>
        /// Gets or sets LettersorLabels 
        /// </summary>	
        [EnumValue("LettersorLabels", typeof(StatementsLettersLabelsResx))]	
        LettersorLabels = 2,
    }
}
