﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    ///  Enum for SelectErrorType 
    /// </summary>
    public enum SelectErrorType
    {
        /// <summary>
        ///  Gets or sets Invoice
        /// </summary>
        [Display(Name = "Invoice", ResourceType = typeof(ARCommonResx))]
        Invoice = 0,

        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [Display(Name = "Receipt", ResourceType = typeof(ARCommonResx))]
        Receipt = 1,

        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(ARCommonResx))]
        Adjustment = 2,

        /// <summary>
        /// Gets or sets Refund
        /// </summary>
        [Display(Name = "Refund", ResourceType = typeof(ARCommonResx))]
        Refund = 3
    }
}
