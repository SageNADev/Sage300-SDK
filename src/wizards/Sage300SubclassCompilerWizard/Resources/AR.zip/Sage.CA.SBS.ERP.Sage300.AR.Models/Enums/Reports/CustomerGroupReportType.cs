﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Report Format Type 1. Detail 2. Summary types
    /// </summary>
    public enum CustomerGroupReportType
    {
        /// <summary>
        /// VendorGroupList
        /// </summary>
        [EnumValue("GroupList", typeof(CustomerGroupsReportResx), 0)]
        CustomerGroupList = 0,

        /// <summary>
        /// VendorGroupStatistics
        /// </summary>
        [EnumValue("GroupStatistics", typeof(CustomerGroupsReportResx), 1)]
        CustomerGroupStatistics = 1
    }
}
