﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Customer Transactions Report Type 
    /// </summary>
    public enum CustTransRptType
    {
        /// <summary>
        /// Gets or sets TransByDocDate 
        /// </summary>
        [EnumValue("TransactionsByDocDate", typeof(CustTransRptResx))]
        TransByDocDate = 1,

        /// <summary>
        /// Gets or sets TransByDocNumber 
        /// </summary>
        [EnumValue("TransactionsByDocNumber", typeof(CustTransRptResx))]
        TransByDocNumber = 2,

        /// <summary>
        /// Gets or sets TransByYearPeriod 
        /// </summary>
        [EnumValue("TransactionsByYearPeriod", typeof(CustTransRptResx))]
        TransByYearPeriod = 3
    }
}
