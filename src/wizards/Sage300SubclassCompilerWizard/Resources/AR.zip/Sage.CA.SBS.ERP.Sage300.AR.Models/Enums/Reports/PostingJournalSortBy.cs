﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// enum for PostingJournalSortBy
    /// </summary>
    public enum PostingJournalSortBy
    {
        #region Enum for PostingJournalSortBy

        /// <summary>
        /// The BatchEntryNo
        /// </summary>
        [EnumValue("BatchEntryNo", typeof (ARCommonResx))] BatchEntryNo = 1,

        /// <summary>
        /// The CustomerNumber
        /// </summary>
        [EnumValue("CustomerNo", typeof (ARCommonResx))] CustomerNumber = 2,

        /// <summary>
        /// The DocumentDate
        /// </summary>
        [EnumValue("DocumentDate", typeof (ARCommonResx))] DocumentDate = 3,

        /// <summary>
        /// The DocumentNumber
        /// </summary>
        [EnumValue("DocumentNumber", typeof (ARCommonResx))] DocumentNumber = 4

        #endregion
    }
}