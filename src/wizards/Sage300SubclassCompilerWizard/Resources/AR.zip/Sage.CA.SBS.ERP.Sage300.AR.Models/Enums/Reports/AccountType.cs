﻿using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Account Type Enum
    /// </summary>
    public enum AccountType
    {
        /// <summary>
        /// Gets or sets AllCustomers 
        /// </summary>	
        [EnumValue("AllCustomers", typeof(ARCommonResx))]
        AllCustomers = 0,
        /// <summary>
        /// Gets or sets OpenItem 
        /// </summary>	
        [EnumValue("OpenItem", typeof(ARCommonResx))]
        OpenItem = 1,

        /// <summary>
        /// Gets or sets BalanceForward 
        /// </summary>
        [EnumValue("BalanceForward", typeof(ARCommonResx))]
        BalanceForward = 2,
    }
}
