// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Cutoffby 
    /// </summary>
    public enum Cutoffby
    {
        #region Enum

        /// <summary>
        /// Gets or sets DocDate 
        /// </summary>	
        [EnumValue("CutoffbyDocDate", typeof(AgedRetainageResx))]
        DocDate = 0,
        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>	
        [EnumValue("PostingDate", typeof(ARCommonResx))]
        PostingDate = 1,
        /// <summary>
        /// Gets or sets YearOrPeriod 
        /// </summary>	
        [EnumValue("YearPeriod", typeof(ARCommonResx))]
        YearOrPeriod = 2,

        #endregion
    }
}
