// Copyright (c) 2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType
    /// </summary>
    public enum JobResourceValidationDocumentType
    {
        /// <summary>
        /// Invoice Document
        /// </summary>
        Invoice = 1,

		/// <summary>
		/// Debit Note Document
		/// </summary>
		DebitNote = 2,

		/// <summary>
		/// Credit Note Document
		/// </summary>
		CreditNote = 3,

        /// <summary>
        /// Interest Document
        /// </summary>
        Interest = 4,

        /// <summary>
        /// Receipt Document
        /// </summary>
        Receipt = 5,

        /// <summary>
        /// Prepayment Document
        /// </summary>
        Prepayment = 6,

        /// <summary>
        /// Un-applied Cash Document
        /// </summary>
        UnappliedCash = 7,

        /// <summary>
        /// Applied Document Document
        /// </summary>
        AppliedDocument = 8,

		/// <summary>
		/// Miscellaneous Receipt Document
		/// </summary>
		MiscReceipt = 9,

		/// <summary>
		/// Write-Off Document
		/// </summary>
		WriteOff = 10,

        /// <summary>
        /// Adjustment Document
        /// </summary>
        Adjustment = 11,
    }
}
