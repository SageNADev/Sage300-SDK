// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Default Transaction Type 
    /// </summary>
    public enum DefaultTransactionType
    {
        /// <summary>
        /// Gets or sets Receipt 
        /// </summary>	
        [EnumValue("Receipt", typeof (ARCommonResx), 1)] Receipt = 1,

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof (ARCommonResx), 2)] Prepayment = 2,

        /// <summary>
        /// Gets or sets Unapplied Cash 
        /// </summary>	
        [EnumValue("UnappliedCash", typeof (ARCommonResx), 3)] UnappliedCash = 3,

        /// <summary>
        /// Gets or sets Apply Document 
        /// </summary>	
        [EnumValue("ApplyDocument", typeof (ARCommonResx), 4)] ApplyDocument = 4,

        /// <summary>
        /// Gets or sets Miscellaneous Receipt
        /// </summary>	
        [EnumValue("MiscReceipt", typeof (ARCommonResx), 5)] MiscReceipt = 5,
    }
}