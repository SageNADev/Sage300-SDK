// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for BatchTypeClass 
    /// </summary>
	public enum BatchTypeClass 
	{
		/// <summary>
		/// Gets or sets Adjustment 
		/// </summary>	
        [EnumValue("BatchTypeClass_Adjustment", typeof(EnumerationsResx))]
        Adjustment = 0,
		/// <summary>
		/// Gets or sets WriteOff 
		/// </summary>	
        [EnumValue("BatchTypeClass_WriteOff", typeof(EnumerationsResx))]
        WriteOff = 1,
		/// <summary>
		/// Gets or sets Payment 
		/// </summary>	
        [EnumValue("BatchTypeClass_Payment", typeof(EnumerationsResx))]
        Payment = 2,
	}
}
