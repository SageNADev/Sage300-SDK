﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ReceiptTransType 
    /// </summary>
    public enum ReceiptTransType
    {
        /// <summary>
        /// Gets or sets Receipt 
        /// </summary>	
        [EnumValue("Receipt", typeof(ARCommonResx), 1)]
        Receipt = 1,
        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(ARCommonResx), 1)]
        Prepayment = 2,
        /// <summary>
        /// Gets or sets UnappliedCash 
        /// </summary>	
        [EnumValue("UnappliedCash", typeof(ARCommonResx), 1)]
        UnappliedCash = 3,
        /// <summary>
        /// Gets or sets ApplyDocument 
        /// </summary>	
        [EnumValue("ApplyDocument", typeof(ARCommonResx), 1)]
        ApplyDocument = 4,
        /// <summary>
        /// Gets or sets MiscReceipt 
        /// </summary>	
        [EnumValue("MiscReceipt", typeof(ARCommonResx), 1)]
        MiscReceipt = 5,
        /// <summary>
        /// Gets or sets WriteOff 
        /// </summary>	
        [EnumValue("WriteOff", typeof(ARCommonResx), 1)]
        WriteOff = 6,
        /// <summary>
        /// Gets or sets Adjustment 
        /// </summary>	
        [EnumValue("Adjustment", typeof(ARCommonResx), 1)]
        Adjustment = 7,
    }
}
