/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */
/* Portions co-modified with Claude Code */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum ReverseMode
    /// </summary>
    public enum ReverseMode
    {
        /// <summary>
        /// The entry
        /// </summary>
        Entry = 0,

        /// <summary>
        /// The batch
        /// </summary>
        Batch = 1,
    }
}
