// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand 
    /// </summary>
    public enum LabelProcessCommand
    {
        /// <summary>
        /// Gets or sets GenerateLabelAddresses 
        /// </summary>	
        GenerateLabelAddresses = 0,
        /// <summary>
        /// Gets or sets UpdatePrintedFlag 
        /// </summary>	
        UpdatePrintedFlag = 1,
    }
}
