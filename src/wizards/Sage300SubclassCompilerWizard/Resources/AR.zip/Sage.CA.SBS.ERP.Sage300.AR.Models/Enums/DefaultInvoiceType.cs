/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Default Invoice Type 
    /// </summary>
    public enum DefaultInvoiceType
    {
        /// <summary>
        /// Gets or sets Item 
        /// </summary>	
        [EnumValue("DefaultInvoiceType_Item", typeof (EnumerationsResx), 1)] Item = 1,

        /// <summary>
        /// Gets or sets Summary 
        /// </summary>	
        [EnumValue("Summary", typeof (ARCommonResx), 2)] Summary = 2,
    }
}