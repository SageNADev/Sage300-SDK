﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for DocumentType
    /// </summary>
    public enum PostedReceiptDocumentType
    {
        /// <summary>
        /// Gets or sets UnappliedCash
        /// </summary>
        [EnumValue("UnappliedCash", typeof(ARCommonResx))]
        UnappliedCash = 5,

        /// <summary>
        /// Gets or sets Prepayment
        /// </summary>
        [EnumValue("Prepayment", typeof(ARCommonResx))]
        Prepayment = 10,

        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [EnumValue("Receipt", typeof(ARCommonResx))]
        Receipt = 11
    }
}




