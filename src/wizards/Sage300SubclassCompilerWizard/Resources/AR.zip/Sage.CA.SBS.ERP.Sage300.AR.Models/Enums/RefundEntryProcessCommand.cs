﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum RefundEntryProcessCommand
    {
        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("InsertOptionalFields", typeof(EnumerationsResx))]
        InsertOptionalFields = 0,

        /// <summary>
        /// Gets or sets VoidCheck 
        /// </summary>	
        [EnumValue("VoidCheck", typeof(ARCommonResx))]
        VoidCheck = 1
    }
}