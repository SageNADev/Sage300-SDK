// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for ReceivablesControl 
    /// </summary>
	public enum ReceivablesControl 
	{
		/// <summary>
		/// Gets or sets NotApplicable 
		/// </summary>	
        [EnumValue("NotApplicable", typeof(CommonResx))]
        NotApplicable = 99,

        /// <summary>
       /// Gets or sets No 
       /// </summary>	
       [EnumValue("No", typeof(CommonResx))]
        No = 0,

        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        [EnumValue("Yes", typeof(ARCommonResx))]
        Yes = 1,
	}
}
