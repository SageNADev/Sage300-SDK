// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Report Retainage Tax 
    /// </summary>
    public enum ReportRetainageTax
    {
        /// <summary>
        /// Gets or sets At Time of Original Document 
        /// </summary>	
        [EnumValue("AtTimeofOriginalDocument", typeof (EnumerationsResx), 0)] AtTimeofOriginalDocument = 0,

        /// <summary>
        /// Gets or sets As Per Tax Authority 
        /// </summary>	
        [EnumValue("AsPerTaxAuthority", typeof (EnumerationsResx), 1)] AsPerTaxAuthority = 1,
    }
}