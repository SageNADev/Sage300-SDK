﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for BatchPrintedFlag 
    /// </summary>
    public enum BatchPrintedFlag
    {
        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        [EnumValue("BatchPrintedFlag_No", typeof(EnumerationsResx))]
        No = 0,
        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        [EnumValue("BatchPrintedFlag_Yes", typeof(EnumerationsResx))]
        Yes = 1,
    }
}
