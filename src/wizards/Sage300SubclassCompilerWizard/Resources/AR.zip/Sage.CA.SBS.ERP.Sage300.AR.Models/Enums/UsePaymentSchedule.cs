/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Use Payment Schedule 
    /// </summary>
    public enum UsePaymentSchedule
    {
        /// <summary>
        /// No 
        /// </summary>	
        [EnumValue("No", typeof(CommonResx))]
        No = 0,

        /// <summary>
        /// Yes 
        /// </summary>	
        [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,
    }
}
