/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using EnumerationsResx = Sage.CA.SBS.ERP.Sage300.AR.Resources.EnumerationsResx;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for InvoiceType 
    /// </summary>
    public enum InvoiceType
    {
        /// <summary>
        /// Gets or sets NotApplicable 
        /// </summary>	
        [EnumValue("NotApplicable", typeof(CommonResx), 0)]
        NotApplicable = 0,

        /// <summary>
        /// Gets or sets Item 
        /// </summary>	
        [EnumValue("Item", typeof(EnumerationsResx), 1)]
        Item = 1,

        /// <summary>
        /// Gets or sets Summary 
        /// </summary>	
        [EnumValue("Summary", typeof(EnumerationsResx), 2)]
        Summary = 2,
    }
}
