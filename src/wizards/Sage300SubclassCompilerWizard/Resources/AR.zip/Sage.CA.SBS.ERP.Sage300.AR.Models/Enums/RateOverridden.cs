 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for RateOverridden 
    /// </summary>
	public enum RateOverridden 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>
        [EnumValue("No", typeof(EnumerationsResx))]
        No = 0,

		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        [EnumValue("Yes", typeof(EnumerationsResx))]
        Yes = 1,
	}
}
