﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum CustomerGroupAccountHeaders
    {
        AccountSet=0,
        Terms =1,
        Rate =2,
        BillingCycle =3,
        InterestProfile =4,
        CurrencyCode=5,
        SalesPersonCode =6,
        TaxClass = 7,
    }
}
