/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for Texttransactiontype 
    /// </summary>
    public enum TextTransactionType 
	{
			/// <summary>
		/// Gets or sets Invoice 
		/// </summary>	
        [EnumValue("Invoice", typeof(ARCommonResx), 1)]
        Invoice = 1,
		/// <summary>
		/// Gets or sets DebitNote 
		/// </summary>	
        [EnumValue("DebitNote", typeof(ARCommonResx), 1)]
        DebitNote = 2,
		/// <summary>
		/// Gets or sets CreditNote 
		/// </summary>	
        [EnumValue("CreditNote", typeof(ARCommonResx), 1)]
        CreditNote = 3,
		/// <summary>
		/// Gets or sets Interest 
		/// </summary>	
        [EnumValue("Interest", typeof(ARCommonResx), 1)]
        Interest = 4,
		/// <summary>
		/// Gets or sets UnappliedCash 
		/// </summary>	
        [EnumValue("UnappliedCash", typeof(ARCommonResx), 1)]
        UnappliedCash = 5,
		/// <summary>
		/// Gets or sets Prepayment 
		/// </summary>	
        [EnumValue("Prepayment", typeof(ARCommonResx), 1)]
        Prepayment = 10,
		/// <summary>
		/// Gets or sets Receipt 
		/// </summary>	
        [EnumValue("Receipt", typeof(ARCommonResx), 1)]
        Receipt = 11,
	}
}
