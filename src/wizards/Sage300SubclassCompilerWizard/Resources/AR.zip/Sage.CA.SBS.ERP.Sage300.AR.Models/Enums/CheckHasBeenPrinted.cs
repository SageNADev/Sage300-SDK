// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
	/// Enum for CheckHasBeenPrinted
	/// </summary>
	public enum CheckHasBeenPrinted
	{
		/// <summary>
		/// Gets or sets NotPrinted
		/// </summary>
        [EnumValue("NotPrinted", typeof(ARCommonResx))]
		NotPrinted = 0,

		/// <summary>
		/// Gets or sets Printed
		/// </summary>
        [EnumValue("Printed", typeof(ARCommonResx))]
		Printed = 1
	}
}
