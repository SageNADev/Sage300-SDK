﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    ///  Enum for Range 
    /// </summary>
    public enum Range
    {
        /// <summary>
        /// RangeOne
        /// </summary>
        [EnumValue("RangeOne", typeof (CommonResx))]
        RangeOne = 1,

        /// <summary>
        /// RangeTwo
        /// </summary> 
        [EnumValue("RangeTwo", typeof(CommonResx))]
        RangeTwo = 2,

        /// <summary>
        /// RangeThree
        /// </summary>
        [EnumValue("RangeThree", typeof(CommonResx))]
        RangeThree = 3,

        /// <summary>
        /// RangeFour
        /// </summary>
        [EnumValue("RangeFour", typeof(CommonResx))]
        RangeFour = 4, 

    }
}
