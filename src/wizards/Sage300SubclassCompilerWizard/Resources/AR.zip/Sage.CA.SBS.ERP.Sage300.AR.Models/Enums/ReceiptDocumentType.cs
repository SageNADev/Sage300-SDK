﻿
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ReceiptTransType 
    /// </summary>
    public enum ReceiptDocumentType
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>
        None = 1,
        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>	
        [EnumValue("DocumentNumber", typeof(ARCommonResx), 2)]
        DocumentNumber = 2,
        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>	
        [EnumValue("PONumber", typeof(ARCommonResx), 3)]
        PONumber = 3,
        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>	
        [EnumValue("OrderNumber", typeof(ARCommonResx), 4)]
        OrderNumber = 4,
        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(ARCommonResx), 5)]
        Prepayment = 5,
        /// <summary>
        /// Gets or sets UnappliedCash 
        /// </summary>	
        [EnumValue("UnappliedCash", typeof(ARCommonResx), 6)]
        UnappliedCash = 6,
        /// <summary>
        /// Gets or sets CreditNote 
        /// </summary>	
        [EnumValue("DocumentType_CreditNote", typeof(Resources.EnumerationsResx), 7)]
        CreditNote = 7,
        /// <summary>
        /// Gets or sets Receipt 
        /// </summary>	
        [EnumValue("Receipt", typeof(ARCommonResx), 8)]
        Receipt = 8,
        /// <summary>
        /// Gets or sets ShipmentNumber 
        /// </summary>	
        [EnumValue("ShipmentNumber", typeof(ARCommonResx), 9)]
        ShipmentNumber = 9,
    }
}

