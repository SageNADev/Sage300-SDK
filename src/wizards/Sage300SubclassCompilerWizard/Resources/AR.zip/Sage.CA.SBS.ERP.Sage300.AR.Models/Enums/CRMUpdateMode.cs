 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for Mode 
    /// </summary>
	public enum CRMUpdateMode 
	{
		/// <summary>
		/// Gets or sets NormalMode 
		/// </summary>	
        [EnumValue("UpdateExisting", typeof(CommonResx))]
        UpdateExisting = 1,
        [EnumValue("ReplaceExisting", typeof(CommonResx))]
        ReplaceExisting = 2,
        [EnumValue("New", typeof(CommonResx))]
        New = 3,
	}
}
