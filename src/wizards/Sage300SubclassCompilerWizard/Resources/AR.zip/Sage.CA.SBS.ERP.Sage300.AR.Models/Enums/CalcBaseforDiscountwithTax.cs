
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CalcBaseforDiscountwithTax 
    /// </summary>
	public enum CalcBaseforDiscountwithTax 
	{
			/// <summary>
		/// Gets or sets Included 
		/// </summary>	
       // Included = 1,
        [EnumValue("Included", typeof(EnumerationsResx))]
        Included = 1,

		/// <summary>
		/// Gets or sets Excluded 
		/// </summary>	
       // Excluded = 2,
        [EnumValue("Excluded", typeof(EnumerationsResx))]
        Excluded = 2,
	}
}
