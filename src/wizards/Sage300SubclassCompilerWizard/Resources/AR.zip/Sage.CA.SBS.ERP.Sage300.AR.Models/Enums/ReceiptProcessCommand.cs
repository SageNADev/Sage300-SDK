﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand 
    /// </summary>
    public enum ReceiptProcessCommand
    {
        /// <summary>
        /// Gets or sets Clear 
        /// </summary>	
        Clear = 0,
        /// <summary>
        /// Gets or sets Allocate 
        /// </summary>	
        Allocate = 1,
    }
}
