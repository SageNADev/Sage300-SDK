 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for IncludeOverCreditLimit 
    /// </summary>
	public enum IncludeOverCreditLimit 
	{
			/// <summary>
		/// Gets or sets AllCustomers 
		/// </summary>	
        AllCustomers = 0,
		/// <summary>
		/// Gets or sets Only 
		/// </summary>	
        Only = 1,
	}
}
