﻿// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for RangeType
    /// </summary>
    public enum RecurringChargeRangeType
    {
        /// <summary>
        /// Gets or sets RecurringChargeCode
        /// </summary>
        [EnumValue("RangeType_RecurringChargeCode", typeof(EnumerationsResx))]
        RecurringChargeCode = 1,

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [EnumValue("RangeType_CustomerNumber", typeof(EnumerationsResx))]
        CustomerNumber = 2,

        /// <summary>
        /// Gets or sets CustomerGroup
        /// </summary>
        [EnumValue("RangeType_CustomerGroup", typeof(EnumerationsResx))]
        CustomerGroup = 4,

        /// <summary>
        /// Gets or sets NationalAccount
        /// </summary>
        [EnumValue("RangeType_NationalAccount", typeof(EnumerationsResx))]
        NationalAccount = 5,
        
        /// <summary>
        /// Gets or sets ScheduleLink
        /// </summary>
        [EnumValue("RangeType_ScheduleLink", typeof(EnumerationsResx))]
        ScheduleLink = 6,

        /// <summary>
        /// Gets or sets SpecificRecurringChargeCode
        /// </summary>
        [EnumValue("RangeType_SpecificRecurringChargeCode", typeof(EnumerationsResx))]
        SpecificRecurringChargeCode = 7
    }
 
    /// <summary>
    /// Enum for RecurringChargeRangeType. This is a subset of the above list and is only used to display the dropdown list on the UI
    /// </summary>
    public enum RecurringChargeRangeTypeDropDownList
    {
       /// <summary>
       /// Gets or sets RecurringChargeCode
       /// </summary>
       [EnumValue("RangeType_RecurringChargeCode", typeof(EnumerationsResx))]
       RecurringChargeCode = 1,

       /// <summary>
       /// Gets or sets CustomerNumber
       /// </summary>
       [EnumValue("RangeType_CustomerNumber", typeof(EnumerationsResx))]
       CustomerNumber = 2,

       /// <summary>
       /// Gets or sets CustomerGroup
       /// </summary>
       [EnumValue("RangeType_CustomerGroup", typeof(EnumerationsResx))]
       CustomerGroup = 4,

       /// <summary>
       /// Gets or sets NationalAccount
       /// </summary>
       [EnumValue("RangeType_NationalAccount", typeof(EnumerationsResx))]
       NationalAccount = 5,
    }
 }

