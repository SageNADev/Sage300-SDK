 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CutoffBy 
    /// </summary>
	public enum CutoffBy 
	{
			/// <summary>
		/// Gets or sets DocDate 
		/// </summary>	
        DocDate = 0,
		/// <summary>
		/// Gets or sets PostingDate 
		/// </summary>	
        PostingDate = 1,
		/// <summary>
		/// Gets or sets YearOrPeriod 
		/// </summary>	
        YearOrPeriod = 2,
	}
}
