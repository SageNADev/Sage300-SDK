// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for DateGenerationMethod
	/// </summary>
	public enum DateGenerationMethod
	{
		/// <summary>
		/// Gets or sets RunDate
		/// </summary>
		RunDate = 0,

		/// <summary>
		/// Gets or sets NextScheduleDate
		/// </summary>
		NextScheduleDate = 1,

		/// <summary>
		/// Gets or sets SpecificDate
		/// </summary>
		SpecificDate = 2
	}
}
