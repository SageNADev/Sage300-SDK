// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;


#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for BatchStatus
    /// </summary>
    public enum BatchStatus
    {
        /// <summary>
        /// Gets or sets Open
        /// </summary>
        [EnumValue("BatchStatus_Open", typeof(EnumerationsResx))]
        Open = 1,

        /// <summary>
        /// Gets or sets Posted
        /// </summary>
        [EnumValue("BatchStatus_Posted", typeof(EnumerationsResx))]
        Posted = 3,

        /// <summary>
        /// Gets or sets Deleted
        /// </summary>
        [EnumValue("BatchStatus_Deleted", typeof(EnumerationsResx))]
        Deleted = 4,
        /// <summary>
        /// Gets or sets PostInProgress
        /// </summary>

        [EnumValue("BatchStatus_PostInProgress", typeof(EnumerationsResx))]
        PostInProgress = 5,

        /// <summary>
        /// Gets or sets ReadyToPost
        /// </summary>

        [EnumValue("BatchStatus_ReadyToPost", typeof(EnumerationsResx))]
        ReadyToPost = 7,

        /// <summary>
        /// Gets or sets CheckCreationInProgress
        /// </summary>
        [EnumValue("BatchStatus_CheckCreationInProgress", typeof(EnumerationsResx))]
        CheckCreationInProgress = 8
    }
}
