 
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for OpenItemStatementType 
    /// </summary>
	public enum OpenItemStatementType 
	{
	
		/// <summary>
		/// Gets or sets Version51,52,and53Format 
		/// </summary>	
        [EnumValue("Version5152and53Format", typeof(ARCommonResx))]
        Version5152and53Format = 0,

		/// <summary>
		/// Gets or sets BalanceForward 
		/// </summary>	
        [EnumValue("BalanceForward", typeof(ARCommonResx))]
        BalanceForward = 1,

		/// <summary>
		/// Gets or sets TransactionCurrentOutstandingBalances 
		/// </summary>	
        [EnumValue("TransactionCurrentOutstandingBalances", typeof(ARCommonResx))]
        TransactionCurrentOutstandingBalances = 2,

		/// <summary>
		/// Gets or sets TransactionOpeningBalancesShowingAppliedDetails 
		/// </summary>	
        [EnumValue("TransactionOpeningBalancesAppliedDetails", typeof(ARCommonResx))]
        TransactionOpeningBalancesShowingAppliedDetails = 3,

		/// <summary>
		/// Gets or sets TransactionOpeningBalancesandNewTransactions 
		/// </summary>
        [EnumValue("TransactionOpeningBalancesandNew", typeof(ARCommonResx))]	
        TransactionOpeningBalancesandNewTransactions = 4,

	}
}
