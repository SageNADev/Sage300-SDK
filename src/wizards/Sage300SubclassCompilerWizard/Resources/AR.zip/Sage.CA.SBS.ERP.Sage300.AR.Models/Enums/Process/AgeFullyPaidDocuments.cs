 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for AgeFullyPaidDocuments 
    /// </summary>
	public enum AgeFullyPaidDocuments 
	{
			/// <summary>
		/// Gets or sets Excluded 
		/// </summary>	
        Excluded = 0,
		/// <summary>
		/// Gets or sets Included 
		/// </summary>	
        Included = 1,
	}
}
