// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessInvoiceBatch 
    /// </summary>
    public enum ProcessInvoiceBatch
    {
        /// <summary>
        /// Gets or sets Do Not Post Invoice Batches 
        /// </summary>	
        DoNotPostInvoiceBatches = 0,

        /// <summary>
        /// Gets or sets Post Invoice Batches 
        /// </summary>	
        PostInvoiceBatches = 1,
    }
}