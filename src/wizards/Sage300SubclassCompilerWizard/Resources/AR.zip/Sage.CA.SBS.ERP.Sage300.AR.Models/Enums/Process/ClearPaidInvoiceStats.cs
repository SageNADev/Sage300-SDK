// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ClearPaidInvoiceStats 
    /// </summary>
    public enum ClearPaidInvoiceStats
    {
        /// <summary>
        /// Gets or sets Do not clear paid invoices statistics 
        /// </summary>	
        DoNotClearPaidInvoicesStatistics = 0,

        /// <summary>
        /// Gets or sets Clear paid invoices statistics 
        /// </summary>	
        ClearPaidInvoicesStatistics = 1,
    }
}