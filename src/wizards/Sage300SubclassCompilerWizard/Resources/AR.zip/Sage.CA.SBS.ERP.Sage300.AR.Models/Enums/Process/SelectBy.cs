﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for AccountType 
    /// </summary>
    public enum SelectBy
    {
        /// <summary>
        /// Gets or sets Amount 
        /// </summary>	
        [EnumValue("Amount", typeof(ARCommonResx))]
        Amount = 0,

        /// <summary>
        /// Gets or sets Percentage 
        /// </summary>	
        [EnumValue("Percentage", typeof(ARCommonResx))]
        Percentage = 1

       
    }
}
