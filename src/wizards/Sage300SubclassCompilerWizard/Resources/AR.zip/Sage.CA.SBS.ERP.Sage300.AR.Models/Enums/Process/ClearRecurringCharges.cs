// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ClearRecurringCharges 
    /// </summary>
    public enum ClearRecurringCharges
    {
        /// <summary>
        /// Gets or sets Do not clear recurring charges 
        /// </summary>	
        DoNotClearRecurringCharges = 0,

        /// <summary>
        /// Gets or sets Clear recurring charges 
        /// </summary>	
        ClearRecurringCharges = 1,
    }
}