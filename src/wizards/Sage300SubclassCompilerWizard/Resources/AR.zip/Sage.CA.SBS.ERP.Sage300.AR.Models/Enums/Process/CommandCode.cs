 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
    /// Enum for CommandCode 
    /// </summary>
	public enum CommandCode 
	{
			/// <summary>
		/// Gets or sets InvoiceBatches 
		/// </summary>	
        InvoiceBatches = 20,
		/// <summary>
		/// Gets or sets ReceiptBatches 
		/// </summary>	
        ReceiptBatches = 30,
		/// <summary>
		/// Gets or sets AdjustmentBatches 
		/// </summary>	
        AdjustmentBatches = 40,
		/// <summary>
		/// Gets or sets RefundBatches 
		/// </summary>	
        RefundBatches = 41,
		/// <summary>
		/// Gets or sets InvoicePostingJournal 
		/// </summary>	
        InvoicePostingJournal = 50,
		/// <summary>
		/// Gets or sets ReceiptPostingJournal 
		/// </summary>	
        ReceiptPostingJournal = 60,
		/// <summary>
		/// Gets or sets AdjustmentPostingJournal 
		/// </summary>	
        AdjustmentPostingJournal = 70,
		/// <summary>
		/// Gets or sets RefundPostingJournal 
		/// </summary>	
        RefundPostingJournal = 71,
		/// <summary>
		/// Gets or sets RevaluationPostingJournal 
		/// </summary>	
        RevaluationPostingJournal = 80,
		/// <summary>
		/// Gets or sets InvoicePrintedbyBatchOrEntry 
		/// </summary>	
        InvoicePrintedbyBatchOrEntry = 90,
		/// <summary>
		/// Gets or sets InvoicePrintedbyCustOrDoc 
		/// </summary>	
        InvoicePrintedbyCustOrDoc = 91,
		/// <summary>
		/// Gets or sets ReceiptPrintedbyBatchOrEntry 
		/// </summary>	
        ReceiptPrintedbyBatchOrEntry = 93,
		/// <summary>
		/// Gets or sets ReceiptPrintedbyCustOrCheck 
		/// </summary>	
        ReceiptPrintedbyCustOrCheck = 94,
		/// <summary>
		/// Gets or sets ReceiptPrintedbyCustOrDoc 
		/// </summary>	
        ReceiptPrintedbyCustOrDoc = 95,
	}
}
