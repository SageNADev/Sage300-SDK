// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for IgnoreWarnings
	/// </summary>
	public enum IgnoreWarnings
	{
		/// <summary>
		/// Gets or sets No
		/// </summary>
		No = 0,

		/// <summary>
		/// Gets or sets Yes
		/// </summary>
		Yes = 1
	}
}
