﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    public enum SelectRecordBy
    {

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>	
        [EnumValue("CustomerNumber", typeof(ARCommonResx))]
        CustomerNumber = 0,
        
        /// <summary>
        /// Gets or sets CustomerGroup 
        /// </summary>	
        [EnumValue("DocumentNumber", typeof(ARCommonResx))]
        DocumentNumber = 1,

        /// <summary>
        /// Gets or sets CustomerGroup 
        /// </summary>	
        [EnumValue("CustomerGroup", typeof(ARCommonResx))]
        CustomerGroup = 2,

        /// <summary>
        /// Gets or sets NationalAccount 
        /// </summary>	
        [EnumValue("NationalAccount", typeof(ARCommonResx))]
        NationalAccount = 3,
    }
}
