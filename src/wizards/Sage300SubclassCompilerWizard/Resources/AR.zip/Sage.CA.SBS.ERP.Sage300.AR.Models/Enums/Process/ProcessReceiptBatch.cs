// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessReceiptBatch 
    /// </summary>
    public enum ProcessReceiptBatch
    {
        /// <summary>
        /// Gets or sets Do Not Post Cash Batches 
        /// </summary>	
        DoNotPostCashBatches = 0,

        /// <summary>
        /// Gets or sets Post Cash Batches 
        /// </summary>	
        PostCashBatches = 1,
    }
}