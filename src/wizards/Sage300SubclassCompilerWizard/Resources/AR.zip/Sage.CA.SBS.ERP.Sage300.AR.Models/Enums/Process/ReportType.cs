 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for ReportType 
    /// </summary>
	public enum ReportType 
	{
	    /// <summary>
		/// Gets or sets AgedTrialBalance 
		/// </summary>	
        AgedTrialBalance = 0,
		/// <summary>
		/// Gets or sets OverdueReceivable 
		/// </summary>	
        OverdueReceivable = 1,
	}
}
