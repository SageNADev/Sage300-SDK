 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for DisplayMeter 
    /// </summary>
	public enum DisplayMeter 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        Yes = 1,
	}
}
