// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Process;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for WriteOffType
	/// </summary>
	public enum WriteOffType
	{
		/// <summary>
		/// Gets or sets OutstandingTransactions
		/// </summary>
        [EnumValue("OutstandingTransactions", typeof(CreateWriteOffBatchResx))]
		OutstandingTransactions = 1,

		/// <summary>
		/// Gets or sets OverdueTransactions
		/// </summary>
        [EnumValue("OverdueTransactions", typeof(CreateWriteOffBatchResx))]
		OverdueTransactions = 2,

		/// <summary>
		/// Gets or sets OverdueBalances
		/// </summary>
        [EnumValue("OverdueBalances", typeof(CreateWriteOffBatchResx))]
		OverdueBalances = 3,

		/// <summary>
		/// Gets or sets OutstandingBalances
		/// </summary>
        [EnumValue("OutstandingBalances", typeof(CreateWriteOffBatchResx))]
		OutstandingBalances = 4,

		/// <summary>
		/// Gets or sets OutstandingRetainage
		/// </summary>
        [EnumValue("OutstandingRetainage", typeof(ARCommonResx))]
		OutstandingRetainage = 5
	}
}
