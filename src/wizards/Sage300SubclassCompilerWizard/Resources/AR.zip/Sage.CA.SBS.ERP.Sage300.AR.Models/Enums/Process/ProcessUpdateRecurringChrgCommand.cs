// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessUpdateRecurringChrgCommand
    /// </summary>
    public enum ProcessUpdateRecurringChrgCommand
    {
        /// <summary>
        /// Gets or sets UpdateRecurringCharges
        /// </summary>
        UpdateRecurringCharges = 1,

        /// <summary>
        /// Gets or sets PurgeUpdateRecurringChargesInstructions
        /// </summary>
        PurgeUpdateRecurringChargesInstructions = 2,

        /// <summary>
        /// Gets or sets DeleteCSVReportFile
        /// </summary>
        DeleteCSVReportFile = 3,

        /// <summary>
        /// Gets or sets ResetProcessed
        /// </summary>
        ResetProcessed = 4
    }
}
