﻿using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum CustomerInquiryAgeBy
    {
        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>	
        [EnumValue("DueDate", typeof(ARCommonResx))]
        DueDate = 0, 
      
        /// <summary>
        /// Gets or sets DocDate 
        /// </summary>	
        [EnumValue("DocumentDate", typeof(ARCommonResx))]
        DocDate = 1,

        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof(CustomerInquiryResx))]
        None = 2, 
    } 
}
