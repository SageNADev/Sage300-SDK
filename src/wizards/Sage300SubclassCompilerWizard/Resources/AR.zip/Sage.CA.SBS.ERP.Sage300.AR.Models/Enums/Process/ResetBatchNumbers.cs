// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ResetBatchNumbers 
    /// </summary>
    public enum ResetBatchNumbers
    {
        /// <summary>
        /// Gets or sets Do Not Reset Batch Numbers 
        /// </summary>	
        DoNotResetBatchNumbers = 0,

        /// <summary>
        /// Gets or sets Reset batch Numbers 
        /// </summary>	
        ResetBatchNumbers = 1,
    }
}