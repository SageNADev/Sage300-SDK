// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessAdjustmentBatch 
    /// </summary>
    public enum ProcessAdjustmentBatch
    {
        /// <summary>
        /// Gets or sets Do not post Adjustment batches 
        /// </summary>	
        DoNotPostAdjustmentBatches = 0,

        /// <summary>
        /// Gets or sets Post Adjustment batches 
        /// </summary>	
        PostAdjustmentBatches = 1,
    }
}