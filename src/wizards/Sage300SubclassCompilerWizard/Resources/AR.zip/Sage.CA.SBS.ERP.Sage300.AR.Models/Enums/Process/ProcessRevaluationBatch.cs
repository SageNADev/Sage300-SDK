// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessRevaluationBatch 
    /// </summary>
    public enum ProcessRevaluationBatch
    {
        /// <summary>
        /// Gets or sets Do Not Post Revalue Batches 
        /// </summary>	
        DoNotPostRevalueBatches = 0,

        /// <summary>
        /// Gets or sets Post Revalue Batches 
        /// </summary>	
        PostRevalueBatches = 1,
    }
}