// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for RollCustStatstoLastYear 
    /// </summary>
    public enum RollCustStatstoLastYear
    {
        /// <summary>
        /// Gets or setsDo Not Roll Statistics To Last Year 
        /// </summary>	
        DoNotRollStatisticsToLastYear = 0,

        /// <summary>
        /// Gets or sets Roll Statistics To Last Year 
        /// </summary>	
        RollStatisticsToLastYear = 1,
    }
}