// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for ClearType
	/// </summary>
	public enum ClearType
	{
		/// <summary>
		/// Gets or sets ClearFullyPaidDocuments
		/// </summary>
		ClearFullyPaidDocuments = 0,

		/// <summary>
		/// Gets or sets ClearPrintedPostingJournals
		/// </summary>
		ClearPrintedPostingJournals = 1,

		/// <summary>
		/// Gets or sets ClearPostingErrors
		/// </summary>
		ClearPostingErrors = 2,

		/// <summary>
		/// Gets or sets ClearStatementData
		/// </summary>
		ClearStatementData = 3
	}
}
