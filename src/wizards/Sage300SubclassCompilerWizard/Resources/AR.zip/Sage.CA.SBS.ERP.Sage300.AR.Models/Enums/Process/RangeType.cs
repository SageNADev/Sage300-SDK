
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for RangeType 
    /// </summary>
    public enum RangeType
    {
        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>	
        [EnumValue("CustomerNumber", typeof(ARCommonResx))]
        CustomerNumber = 1,
        /// <summary>
        /// Gets or sets CustomerGroup 
        /// </summary>	
        [EnumValue("CustomerGroup", typeof(ARCommonResx))]
        CustomerGroup = 2,
        /// <summary>
        /// Gets or sets NationalAccount 
        /// </summary>	
        [EnumValue("NationalAccount", typeof(ARCommonResx))]
        NationalAccount = 3,
        /// <summary>
        /// Gets or sets BillingCycle 
        /// </summary>	
        [EnumValue("BillingCycle", typeof(ARCommonResx))]
        BillingCycle = 4,
    }
}
