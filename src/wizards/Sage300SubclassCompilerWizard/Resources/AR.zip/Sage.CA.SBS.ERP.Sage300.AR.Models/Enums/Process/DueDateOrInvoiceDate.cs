 
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for DueDateOrInvoiceDate 
    /// </summary>
	public enum DueDateOrInvoiceDate 
	{
	
		/// <summary>
		/// Gets or sets DueDate 
		/// </summary>	
        [EnumValue("DueDate", typeof(ARCommonResx))]
        DueDate = 0,

		/// <summary>
		/// Gets or sets DocDate 
		/// </summary>	
        [EnumValue("DocumentDate", typeof(ARCommonResx))]
        DocDate = 1,

	}
}
