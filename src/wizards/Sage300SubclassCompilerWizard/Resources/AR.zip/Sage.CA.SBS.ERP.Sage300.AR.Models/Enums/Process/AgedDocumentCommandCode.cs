 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CommandCode 
    /// </summary>
	public enum AgedDocumentCommandCode 
	{
			/// <summary>
		/// Gets or sets Setup 
		/// </summary>	
        Setup = 1,
		/// <summary>
		/// Gets or sets GenerateSortedWorkFile 
		/// </summary>	
        GenerateSortedWorkFile = 51,
		/// <summary>
		/// Gets or sets GenerateUnsortedWorkFile 
		/// </summary>	
        GenerateUnsortedWorkFile = 52,
		/// <summary>
		/// Gets or sets SingleAgeCalculation 
		/// </summary>	
        SingleAgeCalculation = 61,
		/// <summary>
		/// Gets or sets BucketTotalCalculation 
		/// </summary>	
        BucketTotalCalculation = 71,
	}
}
