// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for CheckForBillingCycles 
    /// </summary>
    public enum CheckForBillingCycles
    {
        /// <summary>
        /// Gets or sets Check for outstanding billing cycles 
        /// </summary>	
        Checkforoutstandingbillingcycles = 0,

        /// <summary>
        /// Gets or sets Do not check for outstanding billing cycles 
        /// </summary>	
        Donotcheckforoutstandingbillingcycles = 1,
    }
}