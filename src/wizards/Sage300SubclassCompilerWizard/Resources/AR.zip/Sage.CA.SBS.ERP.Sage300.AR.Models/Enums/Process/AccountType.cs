/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
    /// Enum for AccountType 
    /// </summary>
	public enum AccountType 
	{
		/// <summary>
		/// Gets or sets AllCustomers 
		/// </summary>	
        [EnumValue("AllCustomers", typeof(ARCommonResx))]
        AllCustomers = 0,

		/// <summary>
		/// Gets or sets OpenItem 
		/// </summary>	
       [EnumValue("OpenItem", typeof(ARCommonResx))]
        OpenItem = 1,

		/// <summary>
		/// Gets or sets BalanceForward 
		/// </summary>	
       [EnumValue("BalanceForward", typeof(ARCommonResx))]
        BalanceForward = 2,
	}
}
