// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for IncludeInvoices
	/// </summary>
	public enum IncludeInvoices
	{
		/// <summary>
		/// Gets or sets DoNotInclude
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		DoNotInclude = 0,

		/// <summary>
		/// Gets or sets Include
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		Include = 1
	}
}
