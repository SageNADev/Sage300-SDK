// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for Process
    /// </summary>
    public enum ProcessCreditCardReceipts
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        None = 0,

        /// <summary>
        /// Gets or sets PopulateList
        /// </summary>
        [EnumValue("PopulateList", typeof(ProcessCreditCardPaymentResx))]
        PopulateList = 1,

        /// <summary>
        /// Gets or sets Process
        /// </summary>
        [EnumValue("ProcessPayments", typeof(ProcessCreditCardPaymentResx))]
        Process = 2,

        /// <summary>
        /// Gets or sets RestoreDefault
        /// </summary>
        [EnumValue("RestoreDefaults", typeof(ProcessCreditCardPaymentResx))]
        RestoreDefault = 3,

        /// <summary>
        /// Gets or sets ApplyNone
        /// </summary>
        [EnumValue("ApplyNone", typeof(ProcessCreditCardPaymentResx))]
        ApplyNone = 4,

        /// <summary>
        /// Gets or sets ApplyAll
        /// </summary>
        [EnumValue("ApplyAll", typeof(ProcessCreditCardPaymentResx))]
        ApplyAll = 5,

        /// <summary>
		/// Gets or sets CNA2Process
		/// </summary>
		CNA2Process = 6,

		/// <summary>
		/// Gets or sets CNA2QuickChargePart1
		/// </summary>
		CNA2QuickChargePart1 = 7,

		/// <summary>
		/// Gets or sets CNA2QuickChargePart2
		/// </summary>
		CNA2QuickChargePart2 = 8
    }
}