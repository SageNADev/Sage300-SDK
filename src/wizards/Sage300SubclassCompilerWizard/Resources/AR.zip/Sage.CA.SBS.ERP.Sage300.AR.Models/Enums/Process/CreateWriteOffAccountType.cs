// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for AccountType
	/// </summary>
	public enum CreateWriteOffAccountType
	{
		/// <summary>
		/// Gets or sets OpenItem
		/// </summary>
        [EnumValue("OpenItem", typeof(ARCommonResx))]
		OpenItem = 1,

		/// <summary>
		/// Gets or sets BalanceForward
		/// </summary>
        [EnumValue("BalanceForward", typeof(ARCommonResx))]
		BalanceForward = 2,

		/// <summary>
		/// Gets or sets AllCustomers
		/// </summary>
        [EnumValue("AllCustomers", typeof(ARCommonResx))]
		AllCustomers = 3
	}
}
