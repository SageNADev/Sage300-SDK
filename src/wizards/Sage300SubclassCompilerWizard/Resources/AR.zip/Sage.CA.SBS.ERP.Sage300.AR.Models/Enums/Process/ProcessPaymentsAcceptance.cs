﻿// Copyright (c) 2020 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    public enum ProcessPaymentsAcceptance
    {
        /// <summary>
        /// Gets or sets DownloadPayments
        /// </summary>
        DownloadPayments = 0,

        /// <summary>
        /// Gets or sets RegenerateBatchLinks
        /// </summary>
        RegenerateBatchLinks = 1
    }
}
