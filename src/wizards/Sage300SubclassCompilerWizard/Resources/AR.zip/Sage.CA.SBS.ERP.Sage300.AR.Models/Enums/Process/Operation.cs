 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for Operation 
    /// </summary>
	public enum Operation 
	{
	
		/// <summary>
		/// Gets or sets RunStatements 
		/// </summary>	
        RunStatements = 0,

		/// <summary>
		/// Gets or sets MarkAllTheCustomersAsPrinted 
		/// </summary>	
        MarkAllTheCustomersAsPrinted = 4,

		/// <summary>
		/// Gets or sets MarkTheMailCustomersAsPrinted 
		/// </summary>	
        MarkTheMailCustomersAsPrinted = 5,

		/// <summary>
		/// Gets or sets MarkASingleCustomerAsPrinted 
		/// </summary>	
        MarkASingleCustomerAsPrinted = 6,

		/// <summary>
		/// Gets or sets MarkAllTheNationalAccountsAsPrinted 
		/// </summary>	
        MarkAllTheNationalAccountsAsPrinted = 7,

		/// <summary>
		/// Gets or sets MarkTheMailNationalAccountsAsPrinted 
		/// </summary>	
        MarkTheMailNationalAccountsAsPrinted = 8,

		/// <summary>
		/// Gets or sets MarkASingleNationalAccountAsPrinted 
		/// </summary>	
        MarkASingleNationalAccountAsPrinted = 9,

		/// <summary>
		/// Gets or sets DeleteASingleCustomersStatementData 
		/// </summary>	
        DeleteASingleCustomersStatementData = 11,

		/// <summary>
		/// Gets or sets DeleteANationalAccountCustomersStatementData 
		/// </summary>	
        DeleteANationalAccountCustomersStatementData = 12,

		/// <summary>
		/// Gets or sets PostStatementRun 
		/// </summary>	
        PostStatementRun = 13,

		/// <summary>
		/// Gets or sets DeleteAStatement 
		/// </summary>	
        DeleteAStatement = 14,

	}
}
