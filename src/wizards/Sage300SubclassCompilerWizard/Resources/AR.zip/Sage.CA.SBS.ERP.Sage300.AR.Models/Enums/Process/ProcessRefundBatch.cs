// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
    /// <summary>
    /// Enum for ProcessRefundBatch 
    /// </summary>
    public enum ProcessRefundBatch
    {
        /// <summary>
        /// Gets or sets Do Not Post Refund Batches 
        /// </summary>	
        DoNotPostRefundBatches = 0,

        /// <summary>
        /// Gets or sets Post Refund Batches 
        /// </summary>	
        PostRefundBatches = 1,
    }
}