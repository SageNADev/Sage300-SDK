// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for BatchGenerationMethod
	/// </summary>
	public enum BatchGenerationMethod
	{
		/// <summary>
		/// Gets or sets Default
		/// </summary>
        [EnumValue("BatchCreationType_Default", typeof(EnumerationsResx))]
		Default = 0,

		/// <summary>
		/// Gets or sets CreateaNewBatch
		/// </summary>
        [EnumValue("BatchCreationType_CreateaNewBatch", typeof(EnumerationsResx))]
		CreateaNewBatch = 1,

		/// <summary>
		/// Gets or sets AddToanExistingBatch
		/// </summary>
        [EnumValue("BatchCreationType_AddtoanExistingBatch", typeof(EnumerationsResx))]
		AddToanExistingBatch = 2
	}
}
