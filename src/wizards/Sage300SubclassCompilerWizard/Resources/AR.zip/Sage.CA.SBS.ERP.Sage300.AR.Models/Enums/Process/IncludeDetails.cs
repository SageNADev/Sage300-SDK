
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for IncludeDetails 
    /// </summary>
	public enum IncludeDetails 
	{
	
		/// <summary>
		/// Gets or sets Summary 
		/// </summary>
        [EnumValue("Summary", typeof(EnumerationsResx))]	
        Summary = 0,

		/// <summary>
		/// Gets or sets Detail 
		/// </summary>	
        [EnumValue("Detail", typeof(EnumerationsResx))]	
        Detail = 1,

	}
}
