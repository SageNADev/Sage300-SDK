// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Process
{
	/// <summary>
	/// Enum for Range4Type
	/// </summary>
	public enum Range4Type
	{
        /// <summary>
        /// Gets or sets None
        /// </summary>
        [EnumValue("BrktNoneBrkt", typeof(ARCommonResx))]
        None = 0,

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [EnumValue("CustomerNumber", typeof(ARCommonResx))]
        CustomerNumber = 1,

        /// <summary>
        /// Gets or sets ShortName
        /// </summary>
        [EnumValue("ShortName", typeof(ARCommonResx))]
        ShortName = 2,

        /// <summary>
        /// Gets or sets CustomerGroup
        /// </summary>
        [EnumValue("CustomerGroup", typeof(ARCommonResx))]
        CustomerGroup = 3,

        /// <summary>
        /// Gets or sets NationalAccount
        /// </summary>
        [EnumValue("NationalAccount", typeof(ARCommonResx))]
        NationalAccount = 4,

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [EnumValue("CustomerName", typeof(ARCommonResx))]
        CustomerName = 14,

        /// <summary>
        /// Gets or sets TerritoryCode
        /// </summary>
        [EnumValue("Territory", typeof(ARCommonResx))]
        TerritoryCode = 26,

        /// <summary>
        /// Gets or sets AccountSet
        /// </summary>
        [EnumValue("AccountSet", typeof(ARCommonResx))]
        AccountSet = 27,

        /// <summary>
        /// Gets or sets BillingCycle
        /// </summary>
        [EnumValue("BillingCycle", typeof(ARCommonResx))]
        BillingCycle = 29,

        /// <summary>
        /// Gets or sets Salesperson
        /// </summary>
        [EnumValue("Salesperson", typeof(ARCommonResx))]
        Salesperson = 106
	}
}
