 
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for DiscountType 
    /// </summary>
	public enum DiscountType 
	{
			/// <summary>
		/// Gets or sets DaysFromInvoiceDate 
		/// </summary>
        [EnumValue("DaysFromInvoiceDate", typeof(EnumerationsResx))]	
        DaysFromInvoiceDate = 1,
		/// <summary>
		/// Gets or sets EndofNextMonth 
		/// </summary>
        [EnumValue("EndofNextMonth", typeof(EnumerationsResx))]		
        EndofNextMonth = 2,
		/// <summary>
		/// Gets or sets DayofNextMonth 
		/// </summary>	
        [EnumValue("DayofNextMonth", typeof(EnumerationsResx))]
        DayofNextMonth = 3,
		/// <summary>
		/// Gets or sets DaysFromDayofNextMonth 
		/// </summary>	
        [EnumValue("DaysFromDayofNextMonth", typeof(EnumerationsResx))]
        DaysFromDayofNextMonth = 4,
		/// <summary>
		/// Gets or sets DiscountDateTable 
		/// </summary>	
        [EnumValue("DiscountDateTable", typeof(EnumerationsResx))]
        DiscountDateTable = 5,
	}
}
