﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for OrderType
    /// </summary>
    public enum OrderTypeInquiry
    {
        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("All", typeof(CommonResx), 0)]
        All = 0,
        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("Active", typeof(CommonResx), 1)]
        Active = 1,
        /// <summary>
        /// Gets or sets Future
        /// </summary>
        [EnumValue("Future", typeof(Resources.EnumerationsResx), 2)]
        Future = 2,
        /// <summary>
        /// Gets or sets Standing
        /// </summary>
        [EnumValue("Standing", typeof(Resources.EnumerationsResx), 3)]
        Standing = 3,
        /// <summary>
        /// Gets or sets Quote
        /// </summary>
        [EnumValue("Quote", typeof(Resources.EnumerationsResx), 4)]
        Quote = 4
    }
}
