﻿
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Account Type Enum
    /// </summary>
    public enum AccountSetType
    {
        /// <summary>
        /// ReceivablesControlAccount
        /// </summary>
        [EnumValue("ReControls", typeof(AccountSetsResx))]
        ReceivablesControlAccount=1,

        /// <summary>
        /// PrepaymentLiabilityAccount
        /// </summary>
         [EnumValue("PreLiability", typeof(AccountSetsResx))]
        PrepaymentLiabilityAccount=2,

        /// <summary>
        /// DiscountsAccount
        /// </summary>
         [EnumValue("ReDiscounts", typeof(AccountSetsResx))]
        DiscountsAccount=3,

        /// <summary>
        /// WriteOffsAccount
        /// </summary>
         [EnumValue("WriteOffs", typeof(AccountSetsResx))]
        WriteOffsAccount=4,
        
        /// <summary>
        /// RetainageAccount
        /// </summary>
         [EnumValue("Retainage", typeof(AccountSetsResx))]
        RetainageAccount = 5,

        /// <summary>
        /// UnrealizedExchangeGainAccount
        /// </summary>
         [EnumValue("UnrlzExchGain", typeof(AccountSetsResx))]
        UnrealizedExchangeGainAccount=6,

        /// <summary>
        /// UnrealizedExchangeLossAccount
        /// </summary>
         [EnumValue("UnrlzExchLoss", typeof(AccountSetsResx))]
        UnrealizedExchangeLossAccount=7,

        /// <summary>
        /// ExchangeGainAccount
        /// </summary>
         [EnumValue("RlzExchGain", typeof(AccountSetsResx))]
        ExchangeGainAccount=8,

        /// <summary>
        /// ExchangeLossAccount
        /// </summary>
         [EnumValue("RlzEXchLoss", typeof(AccountSetsResx))]
        ExchangeLossAccount=9,
        
        /// <summary>
        /// ExchangeRoundingAccount
        /// </summary>
         [EnumValue("ExchRounding", typeof(AccountSetsResx))]
        ExchangeRoundingAccount=10,

    }
}
