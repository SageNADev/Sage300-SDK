// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessAllBatches 
    /// </summary>
    public enum PostAllBatches
    {
        // Note: These enums are not displayed in UI hence there is no association with Resouse files.
        /// <summary>
        /// Gets or sets 	Do not post all batches enumerator
        /// </summary>
        Donotpostallbatches = 0,

        /// <summary>
        /// Gets or sets 	Post all batches enumerator
        /// </summary>	
        Postallbatches = 1,
    }
}
