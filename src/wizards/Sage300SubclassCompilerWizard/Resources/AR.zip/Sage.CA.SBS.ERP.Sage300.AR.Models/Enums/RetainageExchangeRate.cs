// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Retainage Exchange Rate 
    /// </summary>
    public enum RetainageExchangeRate
    {
        /// <summary>
        /// Gets or sets Use Original Document Exchange Rate 
        /// </summary>	
        [EnumValue("UseOriginalDocumentExchangeRate", typeof (EnumerationsResx), 0)] UseOriginalDocumentExchangeRate = 0,

        /// <summary>
        /// Gets or sets Use Current Exchange Rate 
        /// </summary>	
        [EnumValue("UseCurrentExchangeRate", typeof (EnumerationsResx), 1)] UseCurrentExchangeRate = 1,
    }
}