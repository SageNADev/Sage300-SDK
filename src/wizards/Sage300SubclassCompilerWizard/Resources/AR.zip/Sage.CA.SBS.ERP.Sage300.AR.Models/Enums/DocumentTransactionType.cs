/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType 
    /// </summary>
    public enum DocumentTransactionType
    {
        /// <summary>
        /// Gets or sets UnappliedCashPosted 
        /// </summary>	
        [EnumValue("UnappliedCashPosted", typeof(EnumerationsResx))]
        UnappliedCashPosted = 1,

        /// <summary>
        /// Gets or sets InvoiceItemIssued 
        /// </summary>	
        [EnumValue("InvoiceItemIssued", typeof(EnumerationsResx))]
        InvoiceItemIssued = 11,

        /// <summary>
        /// Gets or sets InvoiceSummaryEntered 
        /// </summary>	
        [EnumValue("InvoiceSummaryEntered", typeof(EnumerationsResx))]
        InvoiceSummaryEntered = 12,

        /// <summary>
        /// Gets or sets InvoiceRecurringCharge 
        /// </summary>	
        [EnumValue("InvoiceRecurringCharge", typeof(EnumerationsResx))]
        InvoiceRecurringCharge = 13,

        /// <summary>
        /// Gets or sets InvoiceSummaryIssued 
        /// </summary>	
        [EnumValue("InvoiceSummaryIssued", typeof(EnumerationsResx))]
        InvoiceSummaryIssued = 14,

        /// <summary>
        /// Gets or sets InvoiceItemEntered 
        /// </summary>	
        [EnumValue("InvoiceItemEntered", typeof(EnumerationsResx))]
        InvoiceItemEntered = 15,

        /// <summary>
        /// Gets or sets DebitNoteItemIssued 
        /// </summary>	
        [EnumValue("DebitNoteItemIssued", typeof(EnumerationsResx))]
        DebitNoteItemIssued = 21,

        /// <summary>
        /// Gets or sets DebitNoteSummaryEntered 
        /// </summary>	
        [EnumValue("DebitNoteSummaryEntered", typeof(EnumerationsResx))]
        DebitNoteSummaryEntered = 22,

        /// <summary>
        /// Gets or sets DebitNoteSummaryIssued 
        /// </summary>	
        [EnumValue("DebitNoteSummaryIssued", typeof(EnumerationsResx))]
        DebitNoteSummaryIssued = 24,

        /// <summary>
        /// Gets or sets DebitNoteItemEntered 
        /// </summary>	
        [EnumValue("DebitNoteItemEntered", typeof(EnumerationsResx))]
        DebitNoteItemEntered = 25,

        /// <summary>
        /// Gets or sets DebitNoteAdvanceCreditClaim 
        /// </summary>	
        [EnumValue("DebitNoteAdvanceCreditClaim", typeof(EnumerationsResx))]
        DebitNoteAdvanceCreditClaim = 26,

        /// <summary>
        /// Gets or sets CreditNoteItemIssued 
        /// </summary>	
        [EnumValue("CreditNoteItemIssued", typeof(EnumerationsResx))]
        CreditNoteItemIssued = 31,

        /// <summary>
        /// Gets or sets CreditNoteSummaryEntered 
        /// </summary>	
        [EnumValue("CreditNoteSummaryEntered", typeof(EnumerationsResx))]
        CreditNoteSummaryEntered = 32,

        /// <summary>
        /// Gets or sets CreditNoteSummaryIssued 
        /// </summary>	
        [EnumValue("CreditNoteSummaryIssued", typeof(EnumerationsResx))]
        CreditNoteSummaryIssued = 34,

        /// <summary>
        /// Gets or sets CreditNoteItemEntered 
        /// </summary>	
        [EnumValue("CreditNoteItemEntered", typeof(EnumerationsResx))]
        CreditNoteItemEntered = 35,

        /// <summary>
        /// Gets or sets InterestCharge 
        /// </summary>	
        [EnumValue("InterestCharge", typeof(EnumerationsResx))]
        InterestCharge = 40,

        /// <summary>
        /// Gets or sets PrepaymentPosted 
        /// </summary>	
        [EnumValue("PrepaymentPosted", typeof(EnumerationsResx))]
        PrepaymentPosted = 50,

        /// <summary>
        /// Gets or sets ReceiptPosted 
        /// </summary>	
        [EnumValue("ReceiptPosted", typeof(EnumerationsResx))]
        ReceiptPosted = 51,

        /// <summary>
        /// Gets or sets RefundPosted 
        /// </summary>	
        [EnumValue("RefundPosted", typeof(EnumerationsResx))]
        RefundPosted = 73,
    }
}
