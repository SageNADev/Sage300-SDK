﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CustomerInquiry Currency
    /// </summary>
    public enum CustomerInquiryCurrency
    {
        /// <summary>
        /// Gets or sets Bank Currency 
        /// </summary>
        [EnumValue("BankCurrency", typeof(ARCommonResx))]
        BankCurrency = 0,

        /// <summary>
        /// Gets or sets Customer Currency 
        /// </summary>
        [EnumValue("CustomerCurrency", typeof(ARCommonResx))]
        CustomerCurrency = 1,

        /// <summary>
        /// Gets or sets Functional Currency 
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(ARCommonResx))]
        FunctionalCurrency = 2
    }
}
