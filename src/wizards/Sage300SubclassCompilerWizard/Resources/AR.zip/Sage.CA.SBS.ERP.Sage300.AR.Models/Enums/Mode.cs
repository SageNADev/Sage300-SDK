 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for Mode 
    /// </summary>
	public enum Mode 
	{
			/// <summary>
		/// Gets or sets NormalMode 
		/// </summary>	
        [EnumValue("NormalMode", typeof(CommonResx))]
        NormalMode = 0,
		/// <summary>
		/// Gets or sets UnconditionalInsertsOrUpdates 
		/// </summary>	
        [EnumValue("UnconditionalInsertsOrUpdates", typeof(CommonResx))]
        UnconditionalInsertsOrUpdates = 1,
	}
}
