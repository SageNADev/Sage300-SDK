// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for BatchType
    /// </summary>
    public enum BatchTypes
    {
        /// <summary>
        /// Gets or sets ClearInvoiceBatches
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        ClearInvoiceBatches = 1,

        /// <summary>
        /// Gets or sets ClearReceiptBatches
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        ClearReceiptBatches = 2,

        /// <summary>
        /// Gets or sets ClearAdjustmentBatches
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        ClearAdjustmentBatches = 3,

        /// <summary>
        /// Gets or sets ClearRefundBatches
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: Delete TODO statements when complete
        [EnumValue("Generated", typeof(CommonResx))]
        ClearRefundBatches = 4
    }
}
