// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CustomerInquiryTransactionType
	/// </summary>
    public enum CustomerInquiryTransactionType
	{
		/// <summary>
		/// Gets or sets UnappliedCashPosted
		/// </summary>
		UnappliedCashPosted = 1,

		/// <summary>
		/// Gets or sets InvoiceItemIssued
		/// </summary>
		InvoiceItemIssued = 11,

		/// <summary>
		/// Gets or sets InvoiceSummaryEntered
		/// </summary>
		InvoiceSummaryEntered = 12,

		/// <summary>
		/// Gets or sets InvoiceRecurringCharge
		/// </summary>
		InvoiceRecurringCharge = 13,

		/// <summary>
		/// Gets or sets InvoiceSummaryIssued
		/// </summary>
		InvoiceSummaryIssued = 14,

		/// <summary>
		/// Gets or sets InvoiceItemEntered
		/// </summary>
		InvoiceItemEntered = 15,

		/// <summary>
		/// Gets or sets DebitNoteItemIssued
		/// </summary>
		DebitNoteItemIssued = 21,

		/// <summary>
		/// Gets or sets DebitNoteSummaryEntered
		/// </summary>
		DebitNoteSummaryEntered = 22,

		/// <summary>
		/// Gets or sets DebitNoteSummaryIssued
		/// </summary>
		DebitNoteSummaryIssued = 24,

		/// <summary>
		/// Gets or sets DebitNoteItemEntered
		/// </summary>
		DebitNoteItemEntered = 25,

		/// <summary>
		/// Gets or sets CreditNoteItemIssued
		/// </summary>
		CreditNoteItemIssued = 31,

		/// <summary>
		/// Gets or sets CreditNoteSummaryEntered
		/// </summary>
		CreditNoteSummaryEntered = 32,

		/// <summary>
		/// Gets or sets CreditNoteSummaryIssued
		/// </summary>
		CreditNoteSummaryIssued = 34,

		/// <summary>
		/// Gets or sets CreditNoteItemEntered
		/// </summary>
		CreditNoteItemEntered = 35,

		/// <summary>
		/// Gets or sets InterestCharge
		/// </summary>
		InterestCharge = 40,

		/// <summary>
		/// Gets or sets PrepaymentPosted
		/// </summary>
		PrepaymentPosted = 50,

		/// <summary>
		/// Gets or sets ReceiptPosted
		/// </summary>
		ReceiptPosted = 51
	}
}
