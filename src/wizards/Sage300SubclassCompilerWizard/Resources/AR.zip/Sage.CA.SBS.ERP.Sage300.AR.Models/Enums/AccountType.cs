﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum AccountType
    {
        /// <summary>
        /// Revenue
        /// </summary>
        Revenue = 1,

        /// <summary>
        /// Inventory
        /// </summary>
        Inventory = 2,

        /// <summary>
        /// COGS
        /// </summary>
        COGS = 3,
    }
}