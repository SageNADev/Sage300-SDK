// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CheckLanguage 
    /// </summary>
	public enum CheckLanguage 
	{
			/// <summary>
		/// Gets or sets ENG 
		/// </summary>	
        [EnumValue("ENG", typeof(EnumerationsResx))]
        ENG = 1,
		/// <summary>
		/// Gets or sets FRA 
		/// </summary>	
         [EnumValue("FRA", typeof(EnumerationsResx))]
        FRA = 2,
		/// <summary>
		/// Gets or sets ESN 
		/// </summary>	
         [EnumValue("ESN", typeof(EnumerationsResx))]
        ESN = 3,
		/// <summary>
		/// Gets or sets AUS 
		/// </summary>	
         [EnumValue("AUS", typeof(EnumerationsResx))]
        AUS = 4,
		/// <summary>
		/// Gets or sets MEX 
		/// </summary>	
         [EnumValue("MEX", typeof(EnumerationsResx))]
        MEX = 5,
		/// <summary>
		/// Gets or sets CHN 
		/// </summary>	
         [EnumValue("CHN", typeof(EnumerationsResx))]
        CHN = 6,
		/// <summary>
		/// Gets or sets CHT 
		/// </summary>	
        [EnumValue("CHT", typeof(EnumerationsResx))]
        CHT = 7,
	}
}
