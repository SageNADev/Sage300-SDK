﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum PostAllBatchesSwitch
    /// </summary>
    public enum PostAllBatchSwitch
    {
        // Note: These enums are not displayed in UI hence there is no association with Resouse files.
        /// <summary>
        /// The postall batches
        /// </summary>
        PostallBatches = 0,

        /// <summary>
        /// The postby batch range
        /// </summary>
        PostbyBatchRange = 1,
    }
}