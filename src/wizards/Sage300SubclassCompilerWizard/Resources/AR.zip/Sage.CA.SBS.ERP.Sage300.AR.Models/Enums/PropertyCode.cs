 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for PropertyCode 
    /// </summary>
	public enum PropertyCode 
	{
			/// <summary>
		/// Gets or sets ModeNormal1,Batch2 
		/// </summary>	
        ModeNormal1Batch2 = 1,
	}
}
