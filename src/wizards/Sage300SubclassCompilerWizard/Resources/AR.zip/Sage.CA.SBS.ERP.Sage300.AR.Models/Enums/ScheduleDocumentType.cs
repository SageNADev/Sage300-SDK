/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for DocumentType 
    /// </summary>
    public enum ScheduleDocumentType 
	{
			/// <summary>
		/// Gets or sets Invoice 
		/// </summary>	
        [EnumValue("DocumentType_Invoice", typeof(EnumerationsResx), 1)]
        Invoice = 1,
		/// <summary>
		/// Gets or sets DebitNote 
		/// </summary>	
        [EnumValue("DocumentType_DebitNote", typeof(EnumerationsResx), 2)]
        DebitNote = 2,
		/// <summary>
		/// Gets or sets CreditNote 
		/// </summary>	
        [EnumValue("DocumentType_CreditNote", typeof(EnumerationsResx), 3)]
        CreditNote = 3,
		/// <summary>
		/// Gets or sets Interest 
		/// </summary>	
        [EnumValue("Interest", typeof(ARCommonResx), 4)]
        Interest = 4,
		/// <summary>
		/// Gets or sets UnappliedCash 
		/// </summary>	
        [EnumValue("UnappliedCash", typeof(ARCommonResx), 5)]
        UnappliedCash = 5,
		/// <summary>
		/// Gets or sets Prepayment 
		/// </summary>	
        [EnumValue("Prepayment", typeof(ARCommonResx), 10)]
        Prepayment = 10,
		/// <summary>
		/// Gets or sets Receipt 
		/// </summary>	
        [EnumValue("Receipt", typeof(ARCommonResx), 11)]
        Receipt = 11,
		/// <summary>
		/// Gets or sets Refund 
		/// </summary>	
        [EnumValue("Refund", typeof(ARCommonResx), 19)]
        Refund = 19,
	}
}
