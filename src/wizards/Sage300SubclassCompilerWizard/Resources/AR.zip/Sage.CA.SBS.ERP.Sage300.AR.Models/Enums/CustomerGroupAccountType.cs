
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for AccountType 
    /// </summary>
    public enum CustomerGroupAccountType
    {
        /// <summary>
        /// Gets or sets OpenItem 
        /// </summary>	
        [EnumValue("OpenItem", typeof (ARCommonResx))] OpenItem = 0,

        /// <summary>
        /// Gets or sets BalanceForward 
        /// </summary>	
        [EnumValue("BalanceForward", typeof (ARCommonResx))] BalanceForward = 1,
    }
}
