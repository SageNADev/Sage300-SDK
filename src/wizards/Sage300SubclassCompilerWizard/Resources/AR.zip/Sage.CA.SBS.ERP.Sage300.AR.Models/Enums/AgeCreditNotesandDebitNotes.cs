// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Age Credit Notes and Debit Notes 
    /// </summary>
    public enum AgeCreditNotesandDebitNotes
    {
        /// <summary>
        /// Gets or sets AsCurrent 
        /// </summary>	
        [EnumValue("AsCurrent", typeof (EnumerationsResx), 1)] AsCurrent = 1,

        /// <summary>
        /// Gets or sets ByDate 
        /// </summary>	
        [EnumValue("ByDate", typeof (EnumerationsResx), 2)] ByDate = 2,
    }
}