// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using EnumerationsResx = Sage.CA.SBS.ERP.Sage300.AR.Resources.EnumerationsResx;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Check for Duplicate Checks 
    /// </summary>
    public enum CheckforDuplicateChecks
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("None", typeof (CommonResx), 0)] None = 0,
        /// <summary>
        /// Gets or sets Warning 
        /// </summary>	
        [EnumValue("CheckforDuplicateChecks_Warning", typeof (EnumerationsResx), 1)] Warning = 1,

        /// <summary>
        /// Gets or sets Error 
        /// </summary>	
        [EnumValue("CheckforDuplicateChecks_Error", typeof (EnumerationsResx), 2)] Error = 2,
    }
}