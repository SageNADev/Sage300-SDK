//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for BankRateOperator 
    /// </summary>
	public enum BankRateOperator 
	{
	     /// <summary>
		/// Gets or sets Multiply 
		/// </summary>	
        [EnumValue("BankRateOperator_Multiply", typeof(EnumerationsResx))]
        Multiply = 1,
		/// <summary>
		/// Gets or sets Divide 
		/// </summary>	
        [EnumValue("BankRateOperator_Divide", typeof(EnumerationsResx))]
        Divide = 2,
	}
}
