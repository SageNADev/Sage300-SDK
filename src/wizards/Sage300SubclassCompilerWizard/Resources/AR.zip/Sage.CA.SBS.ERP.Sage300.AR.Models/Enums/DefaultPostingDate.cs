// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Default Posting Date 
    /// </summary>
    public enum DefaultPostingDate
    {
        /// <summary>
        /// Gets or sets Document Date 
        /// </summary>	
        [EnumValue("DocumentDate", typeof (ARCommonResx), 0)] DocumentDate = 0,

        /// <summary>
        /// Gets or sets Batch Date 
        /// </summary>	
        [EnumValue("BatchDate", typeof (ARCommonResx), 1)] BatchDate = 1,

        /// <summary>
        /// Gets or sets Session Date 
        /// </summary>
        [EnumValue("DefaultPostingDate_SessionDate", typeof (EnumerationsResx), 2)] SessionDate = 2,
    }
}