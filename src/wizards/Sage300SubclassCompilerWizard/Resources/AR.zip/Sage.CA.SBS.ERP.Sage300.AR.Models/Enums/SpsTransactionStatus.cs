// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum SpsTransactionStatus
    {
        /// <summary>
        /// Gets or sets SPSTransactionNotStarted
        /// </summary>
        [EnumValue("SPSTransactionNotStarted", typeof(ProcessCreditCardPaymentResx))]
        SPSTransactionNotStarted = 0,

        /// <summary>
        /// Gets or sets SPSSalesTransactionPending
        /// </summary>
        [EnumValue("SPSSalesTransactionPending", typeof(ProcessCreditCardPaymentResx))]
        SPSSalesTransactionPending = 1,

        /// <summary>
        /// Gets or sets SPSSalesTransactionCompleted
        /// </summary>
        [EnumValue("SPSSalesTransactionCompleted", typeof(ProcessCreditCardPaymentResx))]
        SPSSalesTransactionCompleted = 2

    }
}