// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
	/// Enum for DocumentType
	/// </summary>
	public enum PaymentDocumentType
	{
		/// <summary>
		/// Gets or sets Refund
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Refund = 19
	}
}
