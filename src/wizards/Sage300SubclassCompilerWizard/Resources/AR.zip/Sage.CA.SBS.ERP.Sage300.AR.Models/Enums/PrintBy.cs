using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for PrintBy 
    /// </summary>
	public enum PrintBy 
	{
			/// <summary>
		/// Gets or sets CustomerAddress 
		/// </summary>	
         [EnumValue("CustomerAddress", typeof(LabelsResx))]
        CustomerAddress = 0,
		/// <summary>
		/// Gets or sets ShipToLocationAddress 
		/// </summary>	
         [EnumValue("ShipToLocationAddress", typeof(LabelsResx))]
         ShipToLocationAddress = 1,
	}
}
