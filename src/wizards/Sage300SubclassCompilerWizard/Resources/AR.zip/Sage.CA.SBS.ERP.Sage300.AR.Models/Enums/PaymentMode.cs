// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for PaymentMode 
    /// </summary>
    public enum PaymentMode
    {

        /// <summary>
        /// Gets or sets All 
        /// </summary>
        [EnumValue("All", typeof(CommonResx))]
        All = -1,

        /// <summary>
        /// Gets or sets Cash 
        /// </summary>	
        [EnumValue("Cash", typeof (ARCommonResx), 1)] Cash = 1,

        /// <summary>
        /// Gets or sets Check 
        /// </summary>	
        [EnumValue("Check", typeof (ARCommonResx), 2)] Check = 2,

        /// <summary>
        /// Gets or sets CreditCard 
        /// </summary>	
        [EnumValue("CreditCard", typeof (ARCommonResx), 3)] CreditCard = 3,

        /// <summary>
        /// Gets or sets CreditCard 
        /// </summary>	
        [EnumValue("SpsCreditCard", typeof(ARCommonResx), 4)] SpsCreditCard = 5,

        /// <summary>
        /// Gets or sets Other 
        /// </summary>	
        [EnumValue("Other", typeof (ARCommonResx), 5)] Other = 4,
    }
}