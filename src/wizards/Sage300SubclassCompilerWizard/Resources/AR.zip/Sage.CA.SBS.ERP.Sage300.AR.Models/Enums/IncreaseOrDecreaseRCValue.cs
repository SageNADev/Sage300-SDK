// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Increase or decrease Recurring Charge Value
    /// </summary>
    public enum IncreaseOrDecreaseRcValue
    {
        /// <summary>
        /// Gets or sets Increase
        /// </summary>
        [EnumValue("Increase", typeof(UpdateRecurringChargesResx))]
        Increase = 1,

        /// <summary>
        /// Gets or sets Decrease
        /// </summary>
        [EnumValue("Decrease", typeof(UpdateRecurringChargesResx))]
        Decrease = 2
    }
}
