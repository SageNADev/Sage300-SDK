﻿using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum OrderUnpostedEntry
    {
        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [EnumValue("DocumentNo", typeof(ARCommonResx))]
        [Description("DocumentNo")]
        DocumentNo = 0,

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [EnumValue("TransactionDate", typeof(ARCommonResx))]
        [Description("TransactionDate")]
        TransactionDate = 1,

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [EnumValue("PONumber", typeof(ARCommonResx))]
        [Description("PONumber")]
        PONumber = 2,

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [EnumValue("OrderNumber", typeof(ARCommonResx))]
        [Description("OrderNumber")]
        OrderNumber = 3,

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [EnumValue("ShipmentNumber", typeof(ARCommonResx))]
        [Description("ShipmentNumber")]
        ShipmentNo = 4,

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [EnumValue("CheckReceiptNo", typeof(ARCommonResx))]
        [Description("CheckReceiptNo")]
        CheckReceiptNo = 5,

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [EnumValue("TransactionType", typeof(ARCommonResx))]
        [Description("TransactionType")]
        TransBatchEntryNo = 6,

    }
}
