﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CustomerInquiryAdjustmentOrderBy
    /// </summary>
    public enum CustomerInquiryAdjustmentOrderBy
    {
        [EnumValue("AdjustmentNumber", typeof(ARCommonResx))]
        AdjustmentNumber = 0,

        [EnumValue("DocumentNumber", typeof(ARCommonResx))]
        DocumentNumber = 1
    }
}
