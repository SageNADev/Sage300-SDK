﻿/* Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.AR.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum ProcessCcApply
    {
        /// <summary>
        /// Yes
        /// </summary>
        [EnumValue("BatchPrintedFlag_Yes", typeof(EnumerationsResx))]
        Yes = 1,

        /// <summary>
        /// No
        /// </summary>
        [EnumValue("BatchPrintedFlag_No", typeof(EnumerationsResx))]
        No = 0,

        /// <summary>
        /// Pendding
        /// </summary>
        [EnumValue("Pending", typeof(EnumerationsResx))]
        Pending = 98
    }
}
