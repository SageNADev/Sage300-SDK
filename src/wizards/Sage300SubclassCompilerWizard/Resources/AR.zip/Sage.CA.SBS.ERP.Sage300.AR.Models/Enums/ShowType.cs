/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for ShowType 
    /// </summary>
	public enum ShowType 
	{
			/// <summary>
		/// Gets or sets All 
		/// </summary>	
       [EnumValue("All1", typeof(ARCommonResx), 1)]
        All = 1,
		/// <summary>
		/// Gets or sets Invoice 
		/// </summary>	
        [EnumValue("Invoice", typeof(ARCommonResx), 1)]
        Invoice = 2,
		/// <summary>
		/// Gets or sets DebitNote 
		/// </summary>	
        [EnumValue("DebitNote", typeof(ARCommonResx), 1)]
        DebitNote = 3,
		/// <summary>
		/// Gets or sets CreditNote 
		/// </summary>	
        [EnumValue("CreditNote", typeof(ARCommonResx), 1)]
        CreditNote = 4,
	}
}
