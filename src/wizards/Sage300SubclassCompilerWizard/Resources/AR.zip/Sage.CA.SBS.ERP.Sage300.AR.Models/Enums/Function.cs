// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
     /// <summary>
     /// Enum for Function
     /// </summary>
     public enum Function
     {
          /// <summary>
          /// Gets or sets CreateInterestBatchHeader
          /// </summary>
          CreateInterestBatchHeader = 10,
          /// <summary>
          /// Gets or sets CreateInterestBatchDetail
          /// </summary>
          CreateInterestBatchDetail = 11,
          /// <summary>
          /// Gets or sets CreateWriteOffBatchHeader
          /// </summary>
          CreateWriteOffBatchHeader = 20,
     }
}
