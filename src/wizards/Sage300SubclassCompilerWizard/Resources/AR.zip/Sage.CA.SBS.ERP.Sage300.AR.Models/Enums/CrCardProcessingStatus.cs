﻿//Credit card processing status

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Credit Card Processing Status
    /// </summary>
    public enum CrCardProcessingStatus
    {
        /// <summary>
        /// The sale not started
        /// </summary>
        TransactionNotStarted = 0,

        /// <summary>
        /// The sale pending
        /// </summary>
        SalePending = 1,

        /// <summary>
        /// The sale complete
        /// </summary>
        SaleComplete = 2,

        /// <summary>
        /// The void pending
        /// </summary>
        VoidPending = 7,

        /// <summary>
        /// The void complete
        /// </summary>
        VoidComplete = 8,

        /// <summary>
        /// The credit pending
        /// </summary>
        CreditPending = 9,

        /// <summary>
        /// The credit complete
        /// </summary>
        CreditComplete = 10
    }
}
