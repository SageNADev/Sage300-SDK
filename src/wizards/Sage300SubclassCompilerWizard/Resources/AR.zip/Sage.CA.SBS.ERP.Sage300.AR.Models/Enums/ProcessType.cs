/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
 
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for ProcessType 
    /// </summary>
	public enum ProcessType 
	{
		/// <summary>
		/// Gets or sets Select 
		/// </summary>	
        Select = 1,
		/// <summary>
		/// Gets or sets Autocash 
		/// </summary>	
        Autocash = 2,
	}
}
