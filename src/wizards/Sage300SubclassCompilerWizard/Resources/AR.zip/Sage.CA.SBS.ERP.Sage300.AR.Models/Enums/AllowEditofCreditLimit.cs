
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for AllowEditofCreditLimit 
    /// </summary>
    public enum AllowEditofCreditLimit
    {
        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        [EnumValue("No", typeof(EnumerationsResx))]
        No = 0,
        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        [EnumValue("Yes", typeof(EnumerationsResx))]
        Yes = 1,
    }
}
