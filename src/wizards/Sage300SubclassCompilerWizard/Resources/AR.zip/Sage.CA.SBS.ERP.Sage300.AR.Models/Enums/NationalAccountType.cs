﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for NationalAccountType 
    /// </summary>
    public enum NationalAccountType
    {
        /// <summary>
        /// Gets or sets OpenItem 
        /// </summary>	
        [EnumValue("OpenItem", typeof(ARCommonResx), 1)]
        OpenItem = 0,

        /// <summary>
        /// Gets or sets BalanceForward 
        /// </summary>	
        [EnumValue("BalanceForward", typeof(ARCommonResx), 2)]
        BalanceForward = 1
    }
}