// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Retainage Base 
    /// </summary>
    public enum RetainageBase
    {
        /// <summary>
        /// Gets or sets Document Total After Taxes 
        /// </summary>	
        [EnumValue("DocumentTotalAfterTaxes", typeof (EnumerationsResx), 0)] DocumentTotalAfterTaxes = 0,

        /// <summary>
        /// Gets or sets Document Total Before Taxes 
        /// </summary>	
        [EnumValue("DocumentTotalBeforeTaxes", typeof (EnumerationsResx), 1)] DocumentTotalBeforeTaxes = 1,
    }
}