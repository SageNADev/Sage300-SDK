﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespaces
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enumeration for Vendor Currency Type
    /// </summary>
    public enum CustomerCurrencyType
    {
        /// <summary>
        /// Functional 
        /// </summary>
        [EnumValue("Functional", typeof(ARCommonResx))]
        Functional = 0,

        /// <summary>
        ///  Customer 
        /// </summary>
        [EnumValue("Customer", typeof(ARCommonResx))]
        Customer = 1
    }
}