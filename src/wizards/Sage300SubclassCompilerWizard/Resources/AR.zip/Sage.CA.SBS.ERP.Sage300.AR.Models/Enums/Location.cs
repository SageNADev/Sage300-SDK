
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Location 
    /// </summary>
    public enum Location
    {
        /// <summary>
        /// Gets or sets Customers,NationalAccounts,andCustomerGroups 
        /// </summary>	
        [EnumValue("CustomersNationalAccountsandCustomerGroups", typeof(OptionalFieldsResx))]
        CustomersNationalAccountsandCustomerGroups = 0,
        /// <summary>
        /// Gets or sets ShipToLocations 
        /// </summary>	
        [EnumValue("ShipToLocations", typeof(OptionalFieldsResx))]
        ShipToLocations = 1,
        /// <summary>
        /// Gets or sets Invoices 
        /// </summary>	
        [EnumValue("Invoices", typeof(ARCommonResx))]
        Invoices = 2,
        /// <summary>
        /// Gets or sets InvoiceDetails 
        /// </summary>	
        [EnumValue("InvoiceDetails", typeof(OptionalFieldsResx))]
        InvoiceDetails = 3,
        /// <summary>
        /// Gets or sets Receipts 
        /// </summary>	
        [EnumValue("Receipts", typeof(ARCommonResx))]
        Receipts = 4,
        /// <summary>
        /// Gets or sets Adjustments 
        /// </summary>	
        [EnumValue("Adjustments", typeof(ARCommonResx))]
        Adjustments = 5,
        /// <summary>
        /// Gets or sets Revaluation 
        /// </summary>	
        [EnumValue("Revaluation", typeof(ARCommonResx))]
        Revaluation = 6,
        /// <summary>
        /// Gets or sets Refunds 
        /// </summary>	
        [EnumValue("Refunds", typeof(ARCommonResx))]
        Refunds = 7,
    }
}
