﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for recognition of Batch status
    /// </summary>
    public enum EntryBatchStatus
    {
        /// <summary>
        /// Enum Status for Readonly
        /// </summary>
        ReadOnly = 0,

        /// <summary>
        /// Enum status for NoEntry
        /// </summary>
        NoEntry,

        /// <summary>
        /// Enum status of Dirty Entry
        /// </summary>
        DirtyEntry,

        /// <summary>
        /// Enum status for HasEntry
        /// </summary>
        HasEntry,

        /// <summary>
        /// Enum status for Batch date locked
        /// </summary>
        BatchDateLocked,

        /// <summary>
        /// Enum status for Batch Number deposit number
        /// </summary>
        BatchNoDepositNumber,

        /// <summary>
        /// Enum status for Entry readyonly
        /// </summary>
        EntryReadOnly
    }
}
