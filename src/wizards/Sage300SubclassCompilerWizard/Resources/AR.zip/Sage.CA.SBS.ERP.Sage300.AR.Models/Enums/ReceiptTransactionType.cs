﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Receipt TransactionType 
    /// </summary>
    public enum ReceiptTransactionType
    {
        /// <summary>
        /// Gets or sets All 
        /// </summary>
        [EnumValue("All", typeof(CommonResx))]
        All = -1,
        /// <summary>
        /// Gets or sets UnappliedCash 
        /// </summary>	
        [EnumValue("UnappliedCash", typeof(ARCommonResx), 1)]
        UnappliedCash = 5,
        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>	
        [EnumValue("Prepayment", typeof(ARCommonResx), 1)]
        Prepayment = 10,
        /// <summary>
        /// Gets or sets Receipt 
        /// </summary>	
        [EnumValue("Receipt", typeof(ARCommonResx), 1)]
        Receipt = 11,
    }
}