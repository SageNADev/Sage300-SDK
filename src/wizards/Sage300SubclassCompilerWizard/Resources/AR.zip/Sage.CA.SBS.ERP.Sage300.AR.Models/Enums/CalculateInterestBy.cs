// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Calculate Interest By
    /// </summary>
	public enum CalculateInterestBy
	{
        /// <summary>
        /// Gets or sets Document
        /// </summary>		
        [EnumValue("Document1", typeof(ARCommonResx), 1)]
        Document = 1,

        /// <summary>
        /// Gets or sets Balance
        /// </summary>
        [EnumValue("Balance", typeof(InterestProfilesResx), 2)]
        Balance = 2,
	}
}
