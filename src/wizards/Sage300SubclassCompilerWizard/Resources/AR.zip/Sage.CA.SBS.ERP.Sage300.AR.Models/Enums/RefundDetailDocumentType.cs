﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum document type
    /// </summary>
    public enum RefundDetailDocumentType
    {
        /// <summary>
        /// Unknown
        /// </summary>
        [EnumValue("Unknown", typeof(RefundEntryResx))]
        Unknown = 0,

        /// <summary>
        /// Credit note
        /// </summary>
        [EnumValue("CreditNote", typeof(ARCommonResx))]
        CreditNote = 3,

        /// <summary>
        /// Unapplied Cash
        /// </summary>
        [EnumValue("UnappliedCash", typeof(ARCommonResx))]
        UnappliedCash = 5,

        /// <summary>
        /// Prepayment
        /// </summary>
        [EnumValue("Prepayment", typeof(ARCommonResx))]
        Prepayment = 10,

        /// <summary>
        /// Receipt
        /// </summary>
        [EnumValue("Receipt", typeof(ARCommonResx))]
        Receipt = 11,
    }
}
