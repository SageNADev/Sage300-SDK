// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for PaymentStatus
    /// </summary>
    public enum PaymentStatus
    {
        /// <summary>
        /// Returns Enumerated value for All
        /// </summary>
        [EnumValue("All", typeof(CommonResx), 1)]
        All = -1,

        /// <summary>
        /// Gets or sets Outstanding 
        /// </summary>	
        [EnumValue("Outstanding", typeof(ARCommonResx), 2)]
        Outstanding = 0,

        /// <summary>
        /// Gets or sets Cleared 
        /// </summary>	
        [EnumValue("Cleared", typeof(ARCommonResx), 3)]
        Cleared = 1,

        /// <summary>
        /// Gets or sets Reversed
        /// </summary>
        [EnumValue("Reversed", typeof(ARCommonResx), 4)]
        Reversed = 2
    }
}
