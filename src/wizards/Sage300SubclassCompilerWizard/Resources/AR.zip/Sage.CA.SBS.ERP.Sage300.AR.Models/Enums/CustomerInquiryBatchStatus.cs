// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
	/// Enum for BatchStatus
	/// </summary>
	public enum CustomerInquiryBatchStatus
	{
		/// <summary>
		/// Gets or sets Open
		/// </summary>
		[EnumValue("Open", typeof(CommonResx))]
		Open = 0,

		/// <summary>
		/// Gets or sets ReadyToPost
		/// </summary>
        [EnumValue("ReadyToPost", typeof(CommonResx))]
		ReadyToPost = 1,

		/// <summary>
		/// Gets or sets PostInProgress
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		PostInProgress = 2,

		/// <summary>
		/// Gets or sets CheckCreationInProgress
		/// </summary>
		[EnumValue("Generated", typeof(CommonResx))]
		CheckCreationInProgress = 3
	}
}
