﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum PostedReceiptOrderBy
    {
        /// <summary>
        /// Gets or sets Check/Receipt No
        /// </summary>
        [EnumValue("CheckReceiptNo", typeof(ARCommonResx))]
        CheckReceiptNo = 0,

        /// <summary>
        /// Gets or sets Receipt Date
        /// </summary>
        [EnumValue("ReceiptDate", typeof(ARCommonResx))]
        ReceiptDate = 1,
    }
}
