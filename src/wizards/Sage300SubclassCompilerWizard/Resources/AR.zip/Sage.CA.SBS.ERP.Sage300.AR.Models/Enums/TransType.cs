// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
	/// Enum for TransType
	/// </summary>
	public enum TransType
	{
		/// <summary>
		/// Gets or sets Invoice
		/// </summary>
        [EnumValue("Invoice", typeof(ARCommonResx))]
		Invoice = 0,

		/// <summary>
		/// Gets or sets DebitNote
		/// </summary>
        [EnumValue("DebitNote", typeof(ARCommonResx))]
		DebitNote = 1,

		/// <summary>
		/// Gets or sets CreditNote
		/// </summary>
        [EnumValue("CreditNote", typeof(ARCommonResx))]
		CreditNote = 2,

		/// <summary>
		/// Gets or sets Interest
		/// </summary>
        [EnumValue("Interest", typeof(ARCommonResx))]
		Interest = 3,

		/// <summary>
		/// Gets or sets Receipt
		/// </summary>
        [EnumValue("Receipt", typeof(ARCommonResx))]
		Receipt = 4,

		/// <summary>
		/// Gets or sets Prepayment
		/// </summary>
        [EnumValue("Prepayment", typeof(ARCommonResx))]
		Prepayment = 5,

		/// <summary>
		/// Gets or sets UnappliedCash
		/// </summary>
        [EnumValue("UnappliedCash", typeof(ARCommonResx))]
		UnappliedCash = 6,

		/// <summary>
		/// Gets or sets ApplyDocument
		/// </summary>
        [EnumValue("ApplyDocument", typeof(ARCommonResx))]
		ApplyDocument = 7,

		/// <summary>
		/// Gets or sets MiscReceipt
		/// </summary>
        [EnumValue("MiscReceipt", typeof(ARCommonResx))]
		MiscReceipt = 8,

		/// <summary>
		/// Gets or sets Refund
		/// </summary>
        [EnumValue("Refund", typeof(ARCommonResx))]
		Refund = 9,

		/// <summary>
		/// Gets or sets Adjustment
		/// </summary>
        [EnumValue("Adjustment", typeof(ARCommonResx))]
		Adjustment = 10,

		/// <summary>
		/// Gets or sets Writeoff
		/// </summary>
        [EnumValue("Writeoff", typeof(ARCommonResx))]
		Writeoff = 11
	}
}
