using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for SelectBy 
    /// </summary>
	public enum SelectBy 
	{
			/// <summary>
		/// Gets or sets CustomerNumber 
		/// </summary>	
        [EnumValue("CustomerNumber", typeof(ARCommonResx))]
        CustomerNumber = 0,
		/// <summary>
		/// Gets or sets CustomerOrDocumentNumber 
		/// </summary>	
        [EnumValue("CustomerDocumentNo", typeof(ARCommonResx))]
        CustomerOrDocumentNumber = 1,
	}
}
