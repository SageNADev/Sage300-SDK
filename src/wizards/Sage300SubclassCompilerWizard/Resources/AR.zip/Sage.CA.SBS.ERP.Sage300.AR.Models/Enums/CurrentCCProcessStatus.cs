// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
	/// Enum for CurrentCCProcessStatus
	/// </summary>
	public enum CurrentCcProcessStatus
	{
		/// <summary>
		/// Gets or sets SPSTransactionNotStarted
		/// </summary>
		SPSTransactionNotStarted = 0,

		/// <summary>
		/// Gets or sets SPSCreditTransactionPending
		/// </summary>
		SPSCreditTransactionPending = 9,

		/// <summary>
		/// Gets or sets SPSCreditTransactionCompleted
		/// </summary>
		SPSCreditTransactionCompleted = 10,

		/// <summary>
		/// Gets or sets SPSVoidTransactionPending
		/// </summary>
		SPSVoidTransactionPending = 7,

		/// <summary>
		/// Gets or sets SPSVoidTransactionCompleted
		/// </summary>
		SPSVoidTransactionCompleted = 8
	}
}
