/* Copyright (c) 2018 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for Project Invoicing to Multi Cust 
    /// </summary>
	public enum ProjectInvoicingToMultiCust 
	{
        /// <summary>
        /// Enum Project Invoicing to Multi Cust for No 
        /// </summary>	
        [EnumValue("No", typeof(EnumerationsResx), 0)]
        No = 0,

        /// <summary>
        /// Enum Project Invoicing to Multi Cust for Yes 
        /// </summary>	
        [EnumValue("Yes", typeof(EnumerationsResx), 1)]
        Yes = 1,
    }
}
