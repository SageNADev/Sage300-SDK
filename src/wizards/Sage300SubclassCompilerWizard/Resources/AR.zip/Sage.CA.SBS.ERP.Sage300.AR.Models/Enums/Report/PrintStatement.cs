﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Report
{
    /// <summary>
    /// Print Statement Enum
    /// </summary>
    public enum PrintStatement
    {
        /// <summary>
        /// Incomplete Statement Run
        /// </summary>
        [EnumValue("PrintFinishRun", typeof(StatementsLettersLabelsResx))]
        Incomplete = 0,
        /// <summary>
        /// Additional Copy
        /// </summary>
        [EnumValue("AdditionalCopy", typeof(StatementsLettersLabelsResx))]
        AdditionalCopy = 1
    }
}
