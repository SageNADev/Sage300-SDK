 
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for DetailSort 
    /// </summary>
	public enum DetailSort 
	{
	
		/// <summary>
		/// Gets or sets DocNo 
		/// </summary>	
       [EnumValue("DocNo", typeof(StatementsLettersLabelsResx))]
        DocNo = 0,

		/// <summary>
		/// Gets or sets DocDate 
		/// </summary>	
        [EnumValue("DocDate", typeof(StatementsLettersLabelsResx))]
        DocDate = 1,

	}
}
