﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Report
{
    /// <summary>
    /// Enum SelectByType
    /// </summary>
    public enum SelectByType
    {
        /// <summary>
        ///  Gets or sets Batch/EntryNumber 
        /// </summary>
        [EnumValue("Batch/EntryNumber", typeof(ReceiptsResx))]
        BatchNumber = 0, 

        /// <summary>
        ///  Gets or sets Customer/DocumentNumber 
        /// </summary>
        [EnumValue("Customer/DocumentNumber", typeof(ReceiptsResx))]
        CustomerNumber=1,

        /// <summary>
        ///  Gets or sets Customer/DocumentNumber 
        /// </summary>
        [EnumValue("Customer/Check/ReceiptNumber", typeof(ReceiptsResx))]
        ReceiptNumber=2
    }
}
