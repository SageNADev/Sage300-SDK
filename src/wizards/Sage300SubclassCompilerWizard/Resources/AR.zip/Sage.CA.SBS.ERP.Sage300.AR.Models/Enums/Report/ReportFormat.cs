﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Report
{
    /// <summary>
    /// Enum for Report Format
    /// </summary>
    public enum ReportFormat
    {
        /// <summary>
        /// Gets or sets Detail 
        /// </summary>
         [EnumValue("Detail", typeof(ARCommonResx))]
        Detail = 0,
        /// <summary>
         /// Gets or sets Summary 
        /// </summary>
        [EnumValue("Summary", typeof(ARCommonResx))]
        Summary = 1
    }
}
