﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Report
{
    /// <summary>
    /// Enum for Sort By
    /// </summary>
    public enum SortBy
    {
        /// <summary>
        /// Gets or sets AccountNo 
        /// </summary>
        [EnumValue("AccountNo", typeof(GLTransactionsReportResx))]
        AccountNo = 0,

        /// <summary>
        /// Gets or sets YearOrPeriod 
        /// </summary>
        [EnumValue("YearOrPeriod", typeof(ARCommonResx))]
        YearOrPeriod = 1,

        /// <summary>
        /// Gets or sets BatchOrEntryNo 
        /// </summary>
        [EnumValue("BatchOrEntryNo", typeof(GLTransactionsReportResx))]
        BatchOrEntryNo = 2
    }
}
