﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Report
{
    /// <summary>
    /// Enum ReportByType
    /// </summary>
    public enum ReportByType
    {
        /// <summary>
        ///  Gets or sets Detail 
        /// </summary>
        [EnumValue("Detail", typeof(ARCommonResx))]
        Detail = 0,

        /// <summary>
        ///  Gets or sets Summary 
        /// </summary>
        [EnumValue("Summary", typeof(ARCommonResx))]
        Summary = 1
    }
}
