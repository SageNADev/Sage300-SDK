﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Report
{
    /// <summary>
    /// Enum for Currency Type
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// Gets or sets Functional Currency 
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(CommonResx))]
        FunctionalCurrency = 0,

        /// <summary>
        /// Gets or sets Source Currency 
        /// </summary>
        [EnumValue("SourceCurrency", typeof(GLTransactionsReportResx))]
        SourceCurrency = 1
    }
}

