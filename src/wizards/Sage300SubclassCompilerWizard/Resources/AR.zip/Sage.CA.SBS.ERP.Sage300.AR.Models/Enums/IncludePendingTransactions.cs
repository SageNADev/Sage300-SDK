// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Include Pending Transactions 
    /// </summary>
    public enum IncludePendingTransactions
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        [EnumValue("IncludePendingTransactions_None", typeof (EnumerationsResx), 0)] None = 0,

        /// <summary>
        /// Gets or sets Receipts 
        /// </summary>	
        [EnumValue("Receipts", typeof(ARCommonResx), 1)]
        Receipts = 1,

        /// <summary>
        /// Gets or sets Receipts and Adjustments 
        /// </summary>	
        [EnumValue("IncludePendingTransactions_ReceiptsandAdjustments", typeof (EnumerationsResx), 2)] ReceiptsandAdjustments = 2,

        /// <summary>
        /// Gets or sets All Transactions 
        /// </summary>	
        [EnumValue("IncludePendingTransactions_AllTransactions", typeof (EnumerationsResx), 3)] AllTransactions = 3,
    }
}