/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for OrderBy 
    /// </summary>
    public enum ReceiptOrderBy
    {
        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>	
        [EnumValue("DocumentNumber", typeof(ARCommonResx), 1)]
        DocumentNumber = 1,
        /// <summary>
        /// Gets or sets PONumber 
        /// </summary>	
        [EnumValue("PONumber", typeof(ARCommonResx), 1)]
        PONumber = 2,
        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>	
        [EnumValue("DueDate", typeof(ARCommonResx), 1)]
        DueDate = 3,
        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>	
        [EnumValue("OrderNumber", typeof(ARCommonResx), 1)]
        OrderNumber = 4,
        /// <summary>
        /// Gets or sets ShipmentNumber 
        /// </summary>	
        [EnumValue("ShipmentNumber", typeof(ARCommonResx), 1)]
        ShipmentNumber = 7,
        /// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>	
        [EnumValue("DocumentDate", typeof(ARCommonResx), 1)]
        DocumentDate = 5,
        /// <summary>
        /// Gets or sets CurrentBalance 
        /// </summary>	
        [EnumValue("CurrentBalance", typeof(ARCommonResx), 1)]
        CurrentBalance = 6,
        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>	
        [EnumValue("OriginalDocumentNo", typeof(ARCommonResx), 1)]
        OriginalDocNo = 8,
    }
}
