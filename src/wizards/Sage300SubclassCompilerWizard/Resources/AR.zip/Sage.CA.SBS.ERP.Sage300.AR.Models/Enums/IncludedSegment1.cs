// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using EnumerationsResx = Sage.CA.SBS.ERP.Sage300.AR.Resources.EnumerationsResx;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for IncludedSegment1 
    /// </summary>
	public enum IncludedSegment1 
	{
			/// <summary>
		/// Gets or sets None 
		/// </summary>	
        [EnumValue("None", typeof(CommonResx), 1)]
        None = 0,
		/// <summary>
		/// Gets or sets AdjustmentNumber 
		/// </summary>	
        [EnumValue("AdjustmentNumber", typeof(ARCommonResx), 2)]
        AdjustmentNumber = 1,
		/// <summary>
		/// Gets or sets ApplyByDocumentType 
		/// </summary>	
        [EnumValue("ApplyByDocumentType", typeof(EnumerationsResx), 3)]
        ApplyByDocumentType = 2,
		/// <summary>
		/// Gets or sets ApplyToDocumentNumber 
		/// </summary>	
        [EnumValue("ApplyToDocumentNumber", typeof(EnumerationsResx), 4)]
        ApplyToDocumentNumber = 3,
		/// <summary>
		/// Gets or sets BankCode 
		/// </summary>	
        [EnumValue("BankCode", typeof(ARCommonResx), 5)]
        BankCode = 4,
		/// <summary>
		/// Gets or sets BatchNumber 
		/// </summary>	
        [EnumValue("BatchNumber", typeof(ARCommonResx), 6)]
        BatchNumber = 5,
		/// <summary>
		/// Gets or sets BatchType 
		/// </summary>	
        [EnumValue("BatchType", typeof(ARCommonResx), 7)]
        BatchType = 6,
		/// <summary>
		/// Gets or sets Category 
		/// </summary>	
        [EnumValue("Category", typeof(ARCommonResx), 8)]
        Category = 7,
		/// <summary>
		/// Gets or sets CheckDate 
		/// </summary>	
        [EnumValue("CheckDate", typeof(EnumerationsResx), 9)]
        CheckDate = 8,
		/// <summary>
		/// Gets or sets CheckNumber 
		/// </summary>	
        [EnumValue("CheckNumber", typeof(ARCommonResx), 10)]
        CheckNumber = 9,
		/// <summary>
		/// Gets or sets CheckOrReceiptNumber 
		/// </summary>	
        [EnumValue("CheckOrReceiptNumber", typeof(EnumerationsResx), 11)]
        CheckOrReceiptNumber = 10,
		/// <summary>
		/// Gets or sets Comment 
		/// </summary>	
        [EnumValue("Comment", typeof(ARCommonResx), 12)]
        Comment = 11,
		/// <summary>
		/// Gets or sets Contract 
		/// </summary>	
        [EnumValue("Contract", typeof(ARCommonResx), 13)]
        Contract = 12,
		/// <summary>
		/// Gets or sets CustomerName 
		/// </summary>	
        [EnumValue("CustomerName", typeof(ARCommonResx), 14)]
        CustomerName = 13,
		/// <summary>
		/// Gets or sets CustomerNumber 
		/// </summary>	
        [EnumValue("CustomerNumber", typeof(ARCommonResx), 15)]
        CustomerNumber = 14,
		/// <summary>
		/// Gets or sets CustomerShortName 
		/// </summary>	
        [EnumValue("CustomerShortName", typeof(EnumerationsResx), 16)]
        CustomerShortName = 15,
		/// <summary>
		/// Gets or sets DepositNumber 
		/// </summary>	
        [EnumValue("DepositNumber", typeof(ARCommonResx), 17)]
        DepositNumber = 39,
		/// <summary>
		/// Gets or sets Description 
		/// </summary>	
        [EnumValue("Description", typeof(ARCommonResx), 18)]
        Description = 16,
		/// <summary>
		/// Gets or sets DetailDescription 
		/// </summary>	
        [EnumValue("DetailDescription", typeof(EnumerationsResx), 19)]
        DetailDescription = 17,
		/// <summary>
		/// Gets or sets DetailReference 
		/// </summary>	
        [EnumValue("DetailReference", typeof(EnumerationsResx), 20)]
        DetailReference = 18,
		/// <summary>
		/// Gets or sets DistributionCode 
		/// </summary>	
        [EnumValue("DistributionCode", typeof(ARCommonResx), 21)]
        DistributionCode = 19,
		/// <summary>
		/// Gets or sets DocumentNumber 
		/// </summary>	
        [EnumValue("DocumentNumber", typeof(ARCommonResx), 22)]
        DocumentNumber = 20,
		/// <summary>
		/// Gets or sets DocumentType 
		/// </summary>	
        [EnumValue("DocumentType", typeof(ARCommonResx), 23)]
        DocumentType = 21,
		/// <summary>
		/// Gets or sets EntryNumber 
		/// </summary>	
        [EnumValue("EntryNumber", typeof(ARCommonResx), 24)]
        EntryNumber = 22,
		/// <summary>
		/// Gets or sets InvoiceNumber 
		/// </summary>	
        [EnumValue("InvoiceNumber", typeof(ARCommonResx), 25)]
        InvoiceNumber = 23,
		/// <summary>
		/// Gets or sets ItemNumberOrDistributionCode 
		/// </summary>	
        [EnumValue("ItemNumberOrDistributionCode", typeof(EnumerationsResx), 26)]
        ItemNumberOrDistributionCode = 24,
		/// <summary>
		/// Gets or sets OrderNumber 
		/// </summary>	
        [EnumValue("OrderNumber", typeof(ARCommonResx), 27)]
        OrderNumber = 25,
		/// <summary>
		/// Gets or sets Payer 
		/// </summary>	
        [EnumValue("Payer", typeof(ARCommonResx), 28)]
        Payer = 26,
		/// <summary>
		/// Gets or sets PaymentCode 
		/// </summary>	
        [EnumValue("PaymentCode", typeof(ARCommonResx), 29)]
        PaymentCode = 27,
		/// <summary>
		/// Gets or sets PaymentType 
		/// </summary>	
        [EnumValue("PaymentType", typeof(ARCommonResx), 30)]
        PaymentType = 28,
		/// <summary>
		/// Gets or sets PostingSequence 
		/// </summary>	
        [EnumValue("PostingSequence", typeof(ARCommonResx), 31)]
        PostingSequence = 29,
		/// <summary>
		/// Gets or sets Project 
		/// </summary>	
        [EnumValue("Project", typeof(EnumerationsResx), 32)]
        Project = 30,
		/// <summary>
		/// Gets or sets PurchaseOrderNumber 
		/// </summary>	
        [EnumValue("PurchaseOrderNumber", typeof(EnumerationsResx), 33)]
        PurchaseOrderNumber = 31,
		/// <summary>
		/// Gets or sets Reference 
		/// </summary>	
        [EnumValue("Reference", typeof(ARCommonResx), 34)]
        Reference = 32,
		/// <summary>
		/// Gets or sets Resource 
		/// </summary>	
        [EnumValue("Resource", typeof(ARCommonResx), 35)]
        Resource = 33,
		/// <summary>
		/// Gets or sets ReversalDate 
		/// </summary>	
        [EnumValue("ReversalDate", typeof(EnumerationsResx), 36)]
        ReversalDate = 34,
		/// <summary>
		/// Gets or sets ReversalDescription 
		/// </summary>	
        [EnumValue("ReversalDescription", typeof(EnumerationsResx), 37)]
        ReversalDescription = 35,
		/// <summary>
		/// Gets or sets ShipToLocation 
		/// </summary>	
        [EnumValue("ShipToLocation", typeof(EnumerationsResx), 38)]
        ShipToLocation = 36,
		/// <summary>
		/// Gets or sets TaxGroup 
		/// </summary>	
        [EnumValue("TaxGroup", typeof(ARCommonResx), 39)]
        TaxGroup = 37,
		/// <summary>
		/// Gets or sets TransactionType 
		/// </summary>	
        [EnumValue("TransactionType", typeof(ARCommonResx), 40)]
        TransactionType = 38,
	}
}
