﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.ExportImport
{
    /// <summary>
    /// Enum for National Account Export/Import Options.
    /// </summary>
    public enum NationalAccountExportOptions
    {
        [EnumValue("NationalAccount", typeof(ARCommonResx))]
        NationalAccount = 1,

        [EnumValue("Statistics", typeof(ARCommonResx))]
        Statistics = 2
    }
}