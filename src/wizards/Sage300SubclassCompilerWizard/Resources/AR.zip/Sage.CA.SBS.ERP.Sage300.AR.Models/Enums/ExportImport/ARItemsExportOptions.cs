﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.ExportImport
{
    /// <summary>
    /// Enum for Salesperson Export Options
    /// </summary>
    public enum ArItemsExportOptions
    {
        /// <summary>
        /// Used to Set Profile
        /// </summary>
        [EnumValue("ItemInformation", typeof(ItemsResx), 1)]
        ItemInformation = 1,

        /// <summary>
        /// Used to Set Statistics
        /// </summary>
        [EnumValue("ItemStatistics", typeof(ARCommonResx), 2)]
        ItemStatistics = 2,
    }
}
