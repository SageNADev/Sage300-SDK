﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.ExportImport
{
    /// <summary>
    /// Enum for Salesperson Export Options
    /// </summary>
    public enum SalesPersonExportOptions
    {
        /// <summary>
        /// Used to Set Profile
        /// </summary>
        [EnumValue("Profile", typeof(ARCommonResx), 1)]
        Profile = 1,

        /// <summary>
        /// Used to Set Statistics
        /// </summary>
        [EnumValue("Statistics", typeof(SalespersonsResx), 2)]
        Statistics = 2,
    }
}
