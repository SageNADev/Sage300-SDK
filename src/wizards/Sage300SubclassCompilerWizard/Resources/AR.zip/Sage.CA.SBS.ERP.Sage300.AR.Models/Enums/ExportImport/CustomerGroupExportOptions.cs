﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.ExportImport
{
    /// <summary>
    /// Enum for Customer Group Export/Import Options.
    /// </summary>
    public enum CustomerGroupExportOptions
    {
        [EnumValue("GroupInformation", typeof(CustomerGroupsResx))]
        GroupInformation = 1,
        [EnumValue("GroupStatistics", typeof(CustomerGroupsResx))]
        GroupStatistics = 2
    }
}
