﻿using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.ExportImport
{
        /// <summary>
        /// Enum for National Account Export/Import Options.
        /// </summary>
        public enum CustomerExportOptions
        {
            [EnumValue("Customer", typeof(ARCommonResx))]
            Customer = 1,

            [EnumValue("Statistics", typeof(ARCommonResx))]
            Statistics = 2,
           
            [EnumValue("Comments", typeof(ARCommonResx))]
            Comments = 3
        }
  
}
