// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
	/// Enum for RestartState
	/// </summary>
	public enum RestartState
	{
		/// <summary>
		/// Gets or sets None
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		None = 0,

		/// <summary>
		/// Gets or sets GenerateBankCheckRegister
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		GenerateBankCheckRegister = 1,

		/// <summary>
		/// Gets or sets PrintCheck
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		PrintCheck = 2,

		/// <summary>
		/// Gets or sets UpdateStatus
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		UpdateStatus = 3,

         /// <summary>
        /// When the Print Check screen is open and we have to execute the Update after it
        /// </summary>
        IntermediateState = 99,
	}
}
