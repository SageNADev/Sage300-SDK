
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for DeferCreateGLBatch 
    /// </summary>
    public enum DeferCreateGLBatch
    {
        /// <summary>
        /// Gets or sets DuringPosting 
        /// </summary>	
        DuringPosting = 0,
        /// <summary>
        /// Gets or sets OnRequestUsingCreateGLBatchIcon 
        /// </summary>	
        OnRequestUsingCreateGLBatchIcon = 1,
    }
}
