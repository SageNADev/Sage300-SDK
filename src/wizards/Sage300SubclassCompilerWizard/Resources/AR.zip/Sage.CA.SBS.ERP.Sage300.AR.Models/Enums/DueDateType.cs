/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Due Date Type 
    /// </summary>
    public enum DueDateType
    {
        /// <summary>
        /// From Invoice Date 
        /// </summary>	
        [EnumValue("DaysFromInvoiceDate", typeof(EnumerationsResx))]
        DaysFromInvoiceDate = 1,

        /// <summary>
        /// End o fNext Month 
        /// </summary>	
        [EnumValue("EndofNextMonth", typeof(EnumerationsResx))]
        EndofNextMonth = 2,

        /// <summary>
        /// Day of Next Month 
        /// </summary>	
        [EnumValue("DayofNextMonth", typeof(EnumerationsResx))]
        DayofNextMonth = 3,

        /// <summary>
        /// Days From Day of Next Month 
        /// </summary>	
        [EnumValue("DaysFromDayofNextMonth", typeof(EnumerationsResx))]
        DaysFromDayofNextMonth = 4,

        /// <summary>
        /// Due Date Table 
        /// </summary>	
        [EnumValue("DueDateTable", typeof(EnumerationsResx))]
        DueDateTable = 5,
    }
}
