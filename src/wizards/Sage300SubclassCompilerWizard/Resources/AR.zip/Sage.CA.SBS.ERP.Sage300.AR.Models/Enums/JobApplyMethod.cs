﻿/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Represents the several methods for applying amounts to the contracts, projects, categories, 
    /// and projects on the invoice.
    /// </summary>
    public enum JobApplyMethod
    {
        /// <summary>
        /// Applies a receipt amount proportionately to all invoice details, based on the relative 
        /// amounts of the details.
        /// </summary>	
        [EnumValue("JobApplyMethod_ProratebyAmount", typeof(EnumerationsResx), 1)]
        ProratebyAmount = 0,
        /// <summary>
        /// Applies an amount automatically to invoice details beginning with the first detail 
        /// (contract-project-category-resource) on an invoice until the amount is fully applied.
        /// </summary>	
        [EnumValue("JobApplyMethod_TopDown", typeof(EnumerationsResx), 1)]
        TopDown = 1,
    }
}
