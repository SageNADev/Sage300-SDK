﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CostClass 
    /// </summary>
	public enum CostClass 
	{
        /// <summary>
        /// Gets or sets  
        /// </summary>	
        [EnumValue("EmptyString", typeof(CommonResx))]
        None = 0,
        /// <summary>
        /// Gets or sets Labor 
        /// </summary>	
        [EnumValue("Labor", typeof(ARCommonResx))]
        Labor = 1,
        /// <summary>
        /// Gets or sets Material 
        /// </summary>	
        [EnumValue("Material", typeof(CommonResx))]
        Material = 2,
        /// <summary>
        /// Gets or sets Equipment 
        /// </summary>	
        [EnumValue("Equipment", typeof(CommonResx))]
        Equipment = 3,
        /// <summary>
        /// Gets or sets Subcontractor 
        /// </summary>	
        [EnumValue("Subcontractor", typeof(CommonResx))]
        Subcontractor = 4,
        /// <summary>
        /// Gets or sets Overhead 
        /// </summary>	
        [EnumValue("Overhead", typeof(ARCommonResx))]
        Overhead = 5,
        /// <summary>
        /// Gets or sets Miscellaneous 
        /// </summary>	
        [EnumValue("Miscellaneous", typeof(CommonResx))]
        Miscellaneous = 6,
	}
}