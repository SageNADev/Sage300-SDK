// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
	/// Enum for ReturnedStatus
	/// </summary>
	public enum ReturnedStatus
	{
        /// <summary>
        /// Gets or sets Successful 
        /// </summary>	
        Successful = 0,

        /// <summary>
        /// Gets or sets Aborted 
        /// </summary>	
        Aborted = 1,

        /// <summary>
        /// Gets or sets Suspended 
        /// </summary>	
        Suspended = 2,

        /// <summary>
        /// Gets or sets the Default value for Print Check
        /// </summary>
        None = 99,
	}
}
