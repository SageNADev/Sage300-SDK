﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum CustomerCheckFields
    {
        NationalAccount=0,
        CustomerGroup=1,
        AccountSet =2,
        TaxGroup=3,
        TaxClass=4,
        SalesPersonCode=5,
        TotalDaysToPay=6,
    }
}
