// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for Sort Checks By 
    /// </summary>
    public enum SortChecksBy
    {
        /// <summary>
        /// Gets or sets Transaction Entry Number 
        /// </summary>	
        [EnumValue("SortChecksBy_TransactionEntryNumber", typeof (EnumerationsResx), 0)] TransactionEntryNumber = 0,

        /// <summary>
        /// Gets or sets Customer Number 
        /// </summary>	
        [EnumValue("SortChecksBy_CustomerNumber", typeof (EnumerationsResx), 1)] CustomerNumber = 1,

        /// <summary>
        /// Gets or sets Payee Name 
        /// </summary>	
        [EnumValue("SortChecksBy_PayeeName", typeof (EnumerationsResx), 2)] PayeeName = 2,

        /// <summary>
        /// Gets or sets Payee Country 
        /// </summary>	
        [EnumValue("SortChecksBy_PayeeCountry", typeof (EnumerationsResx), 3)] PayeeCountry = 3,

        /// <summary>
        /// Gets or sets Payee Zip Or Postal Code 
        /// </summary>	
        [EnumValue("SortChecksBy_PayeeZipOrPostalCode", typeof (EnumerationsResx), 4)] PayeeZipOrPostalCode = 4,
    }
}