// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CustStatisticsPeriodType 
    /// </summary>
    public enum CustStatisticsPeriodType
    {
        /// <summary>
        /// Gets or sets Weekly 
        /// </summary>	
        Weekly = 1,

        /// <summary>
        /// Gets or sets Sevendays 
        /// </summary>	
        Sevendays = 2,

        /// <summary>
        /// Gets or sets Biweekly 
        /// </summary>	
        Biweekly = 3,

        /// <summary>
        /// Gets or sets Fourweeks 
        /// </summary>	
        Fourweeks = 4,

        /// <summary>
        /// Gets or sets Monthly 
        /// </summary>	
        Monthly = 5,

        /// <summary>
        /// Gets or sets Bimonthly 
        /// </summary>	
        Bimonthly = 6,

        /// <summary>
        /// Gets or sets Quarterly 
        /// </summary>	
        Quarterly = 7,

        /// <summary>
        /// Gets or sets Semiannually 
        /// </summary>	
        Semiannually = 8,

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>	
        FiscalPeriod = 9,
    }
}