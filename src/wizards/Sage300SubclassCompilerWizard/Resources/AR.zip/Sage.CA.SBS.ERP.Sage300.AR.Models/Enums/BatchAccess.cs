﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for recognition of Batch access
    /// </summary>
    public enum BatchAccess
    {
        /// <summary>
        /// Enum Batch access for Invalid
        /// </summary>
        Invalid = 0,

        /// <summary>
        /// Enum Batch access for Delete Readonly
        /// </summary>
        DeleteReadonly,

        /// <summary>
        /// Enum Batch access for User Readyonly
        /// </summary>
        UserReadonly,

        /// <summary>
        /// Enum Batch access for Status Readonly
        /// </summary>
        StatusReadonly,

        /// <summary>
        /// Enum Batch access for Import Readonly
        /// </summary>
        ImportReadonly,

        /// <summary>
        /// Enum Batch access for External Readonly
        /// </summary>
        ExternalReadonly,

        /// <summary>
        /// Enum Batch access for Deposit Readonly
        /// </summary>
        DepositReadonly,

        /// <summary>
        /// Enum Batch access for State Readonly
        /// </summary>
        StateReadonly,

        /// <summary>
        /// Enum Batch access for Editable
        /// </summary>
        Editable
    }
}
