// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for IncTaxinStatistics 
    /// </summary>
    public enum IncTaxinStatistics
    {
        /// <summary>
        /// Gets or sets NotIncluded 
        /// </summary>	
        NotIncluded = 0,

        /// <summary>
        /// Gets or sets Included 
        /// </summary>	
        Included = 1,
    }
}