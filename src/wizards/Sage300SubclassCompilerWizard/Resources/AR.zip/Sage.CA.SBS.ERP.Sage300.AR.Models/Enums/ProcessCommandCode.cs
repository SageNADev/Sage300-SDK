﻿//  Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode 
    /// </summary>
    public enum ProcessCommandCode
    {
        /// <summary>
        /// Gets or sets UnlockBatchResource 
        /// </summary>	
        [EnumValue("ProcessCommandCode_UnlockBatchResource", typeof(EnumerationsResx))]
        UnlockBatchResource = 0,
        /// <summary>
        /// Gets or sets LockBatchResourceShared 
        /// </summary>	
        [EnumValue("ProcessCommandCode_LockBatchResourceShared", typeof(EnumerationsResx))]
        LockBatchResourceShared = 1,
        /// <summary>
        /// Gets or sets LockBatchResourceExclusive 
        /// </summary>
        [EnumValue("ProcessCommandCode_LockBatchResourceExclusive", typeof(EnumerationsResx))]
        LockBatchResourceExclusive = 2,
    }
}
