﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode 
    /// </summary>
    public enum NationalAccountProcessCommandCode
    {
        /// <summary>
        /// Gets or sets InsertOptionalFields 
        /// </summary>	
        [EnumValue("InsertOptionalFields", typeof(EnumerationsResx))]
        InsertOptionalFields = 0
    }
}