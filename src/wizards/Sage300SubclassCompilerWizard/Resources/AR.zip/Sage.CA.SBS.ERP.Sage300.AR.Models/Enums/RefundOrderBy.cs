﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    public enum RefundOrderBy
    {
        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [EnumValue("DocumentNumber", typeof(ARCommonResx))]
        DocumentNumber = 0,

        /// <summary>
        /// 
        /// </summary>
        [EnumValue("BankCheckNumber", typeof(CustomerInquiryResx))]
        BankCheckNumber = 1,
    }
}
