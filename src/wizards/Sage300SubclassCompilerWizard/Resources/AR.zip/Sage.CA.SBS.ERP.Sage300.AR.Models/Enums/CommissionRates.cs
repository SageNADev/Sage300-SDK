﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for CommissionRates 
    /// </summary>
    public enum CommissionRates
    {
        /// <summary>
        /// One
        /// </summary>
        [EnumValue("Value1", typeof(SalespersonsResx))]
        One = 1,

        /// <summary>
        /// Two
        /// </summary>
        [EnumValue("Value2", typeof(SalespersonsResx))]
        Two = 2,

        /// <summary>
        /// Three
        /// </summary>
        [EnumValue("Value3", typeof(SalespersonsResx))]
        Three = 3,

         /// <summary>
        /// Four
        /// </summary>
        [EnumValue("Value4", typeof(SalespersonsResx))]
        Four = 4,

        /// <summary>
        /// Five
        /// </summary>
        [EnumValue("Value5", typeof(SalespersonsResx))]
        Five = 5

    }
}