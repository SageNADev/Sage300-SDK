﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum PostAllBatchesSwitch
    /// </summary>
    public enum PostBatchTypeSwitch
    {
        /// <summary>
        /// Invoice Type batch
        /// </summary>
        [EnumValue("Invoice", typeof(PostBatchesResx))]
        Invoice = 1,

        /// <summary>
        /// Receipt  Type batch
        /// </summary>
        [EnumValue("Receipt", typeof(PostBatchesResx))]
        Receipt = 2,

        /// <summary>
        ///Adjustment Type batch
        /// </summary>
        [EnumValue("Adjustment", typeof(PostBatchesResx))]
        Adjustment = 3,

        /// <summary>
        ///Refund Type batch
        /// </summary>
        [EnumValue("Refund", typeof(PostBatchesResx))]
        Refund = 4,
    }
}