// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for AllowPrintingofDepositSlips 
    /// </summary>
    public enum AllowPrintingofDepositSlips
    {
        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        No = 0,

        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        Yes = 1,
    }
}