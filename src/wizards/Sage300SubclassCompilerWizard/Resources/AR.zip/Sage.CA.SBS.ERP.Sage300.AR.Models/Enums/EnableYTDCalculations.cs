// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for EnableYTDCalculations 
    /// </summary>
    public enum EnableYtdCalculations
    {
        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        [EnumValue("EnableYTDCalculations_No", typeof(EnumerationsResx), 1)]
        No = 0,

        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        [EnumValue("EnableYTDCalculations_Yes", typeof(EnumerationsResx), 2)]
        Yes = 1
    }
}