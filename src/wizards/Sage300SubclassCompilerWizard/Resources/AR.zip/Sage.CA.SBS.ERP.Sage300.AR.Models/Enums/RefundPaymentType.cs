﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpaces
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion NameSpaces

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for RefundPaymentType 
    /// </summary>
    public enum RefundPaymentType
    {
        /// <summary>
        /// Gets or sets Cash 
        /// </summary>	
        [EnumValue("Cash", typeof(ARCommonResx))]
        Cash = 1,

        /// <summary>
        /// Gets or sets Check 
        /// </summary>	
        [EnumValue("Check", typeof(ARCommonResx), 1)]
        Check = 2,

        /// <summary>
        /// Gets or sets CreditCard 
        /// </summary>	
        [EnumValue("CreditCard", typeof(ARCommonResx))]
        CreditCard = 3,

        /// <summary>
        /// Gets or sets CreditCard 
        /// </summary>	
        [EnumValue("SpsCreditCard", typeof(ARCommonResx))]
        SpsCreditCard = 5,
    }
}