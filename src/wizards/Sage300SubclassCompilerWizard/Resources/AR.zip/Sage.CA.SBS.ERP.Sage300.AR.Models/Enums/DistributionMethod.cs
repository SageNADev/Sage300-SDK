﻿// Copyright (c) 1994-2016 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
    /// <summary>
    /// Enum for DistributionMethod 
    /// </summary>
    public enum DistributionMethod
    {
        /// <summary>
        /// Gets or sets All Details
        /// </summary>
        [EnumValue("AllDetails", typeof(UpdateRecurringChargesResx))]
        AllDetails = 1,
        /// <summary>
        /// Gets or sets Specific Distribution Code for Percentage
        /// </summary>
        [EnumValue("SpecificDistributionCode", typeof(UpdateRecurringChargesResx))]
        SpecificDistributionCodePercentage = 2,
        /// <summary>
        /// Gets or sets Spread Evenly
        /// </summary>
        [EnumValue("SpreadEvenly", typeof(UpdateRecurringChargesResx))]
        SpreadEvenly = 3,
        /// <summary>
        /// Gets or sets Prorate
        /// </summary>
        [EnumValue("Prorate", typeof(UpdateRecurringChargesResx))]
        Prorate = 4,
        /// <summary>
        /// Gets or sets Specific Distribution Code for Amount
        /// </summary>
        [EnumValue("SpecificDistributionCode", typeof(UpdateRecurringChargesResx))]
        SpecificDistributionCodeAmount = 5
    }
}
