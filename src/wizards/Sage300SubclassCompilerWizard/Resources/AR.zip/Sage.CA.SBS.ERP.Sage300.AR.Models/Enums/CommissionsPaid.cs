 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Enums
{
	/// <summary>
    /// Enum for CommissionsPaid 
    /// </summary>
	public enum CommissionsPaid 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>
        [EnumValue("No", typeof(CommonResx))]
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
       [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,
	}
}
