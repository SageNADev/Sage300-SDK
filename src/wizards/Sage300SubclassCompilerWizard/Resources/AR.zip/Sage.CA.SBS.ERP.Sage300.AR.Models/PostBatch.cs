﻿/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Post Batch Model 
    /// </summary>
    public class PostBatch : ModelBase
    {
        /// <summary>
        /// Gets or sets PostAllBatchesSwitch
        /// </summary>
        /// <value>The post all batches switch.</value>
        public PostAllBatchSwitch PostAllBatchSwitch { get; set; }

        /// <summary>
        /// Gets or sets ProvisionalPostSwitch
        /// </summary>
        /// <value>The provisional post switch.</value>
        public PostBatchTypeSwitch PostBatchTypeSwitch { get; set; }

        /// <summary>
        /// Gets or sets FromBatchNumber
        /// </summary>
        /// <value>From batch number.</value>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromBatchNumber", ResourceType = typeof(PostBatchesResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets ToBatchNumber
        /// </summary>
        /// <value>To batch number.</value>
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToBatchNumber", ResourceType = typeof(PostBatchesResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBatchNumber { get; set; }

        /// <summary>
        /// Invoice button  enabled
        /// </summary>
        public bool IsInvoiceEnabled { get; set; }

        /// <summary>
        /// Receipt button  enabled
        /// </summary>
        public bool IsReceiptEnabled { get; set; }

        /// <summary>
        /// Adjustment button  enabled
        /// </summary>
        public bool IsAdjustmentEnabled { get; set; }

        /// <summary>
        /// Refund button  enabled
        /// </summary>
        public bool IsRefundEnabled { get; set; }

    }
}
