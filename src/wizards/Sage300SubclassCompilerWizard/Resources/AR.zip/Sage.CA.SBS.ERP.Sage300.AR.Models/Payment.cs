// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Customization.Validators;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Partial class for Payment
	/// </summary>
    public partial class Payment : SqlModelBase
	{
		/// <summary>
		/// Gets or sets CustomerNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 1)]
        [GridInfo(1, typeof(ARCommonResx), "CustomerNumber")]
		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string CustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets DocumentNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DocumentNo", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 2)]
        [GridInfo(2, typeof(CustomerInquiryResx), "DocumentNo", templateSource: GridInfoTemplateLib.PencilIconDrillDown, Style = "w150")]
		[ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string DocumentNumber { get; set; }

		/// <summary>
		/// Gets or sets SeqNo
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "SequenceNo", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 3)]
		[ViewField(Name = Fields.SeqNo, Id = Index.SeqNo, FieldType = EntityFieldType.Long, Size = 4)]
		public long SeqNo { get; set; }

		/// <summary>
		/// Gets or sets PaymentCode
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PaymentCode", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 4)]
		[ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string PaymentCode { get; set; }

		/// <summary>
		/// Gets or sets PaymentType
		/// </summary>
		[Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 5)]
		[ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
		public PaymentType PaymentType { get; set; }

		/// <summary>
		/// Gets or sets DocumentDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 6)]
        [GridInfo(3, typeof(ARCommonResx), "DocumentDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
		[ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? DocumentDate { get; set; }

		/// <summary>
		/// Gets or sets FiscalYear
		/// </summary>
		[StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 7)]
        [GridInfo(12, typeof(ARCommonResx), "FiscalYear")]
		[ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
		public string FiscalYear { get; set; }

		/// <summary>
		/// Gets or sets FiscalPeriod
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 8)]
        [GridInfo(13, typeof(ARCommonResx), "FiscalPeriod")]
		[ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
		public string FiscalPeriod { get; set; }

		/// <summary>
		/// Gets or sets BankCode
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "BankCode", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 9)]
        [GridInfo(16, typeof(ARCommonResx), "BankCode")]
		[ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string BankCode { get; set; }

		/// <summary>
		/// Gets or sets CheckNumber
		/// </summary>
		[Display(Name = "CheckNumber", ResourceType = typeof (ARCommonResx))]
        [InquiryField(Id = 10)]
        [GridInfo(17, typeof(ARCommonResx), "CheckNumber", templateSource: GridInfoTemplateLib.HideZeroTemplate)]
		[ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
		public decimal CheckNumber { get; set; }

		/// <summary>
		/// Gets or sets CheckSerialNumber
		/// </summary>
		[Display(Name = "CheckSerialNumber", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 11)]
		[ViewField(Name = Fields.CheckSerialNumber, Id = Index.CheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
		public long CheckSerialNumber { get; set; }

		/// <summary>
		/// Gets or sets GLAccountTobeCredited
		/// </summary>
		[StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "GLAccountTobeCredited", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 12)]
        [GridInfo(14, typeof(CustomerInquiryResx), "GLAccountTobeCredited")]
		[ViewField(Name = Fields.GLAccountTobeCredited, Id = Index.GLAccountTobeCredited, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
		public string GLAccountTobeCredited { get; set; }

		//Added to get Account Description
		/// <summary>
		/// Gets or sets GLAccountTobeCredited
		/// </summary>
		[StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "AccountDescription", ResourceType = typeof(CustomerInquiryResx))]
		public string AccountDescription { get; set; }

		/// <summary>
		/// Gets or sets NameonCheck
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "NameonCheck", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 13)]
        [GridInfo(5, typeof(CustomerInquiryResx), "Payee")]
		[ViewField(Name = Fields.NameonCheck, Id = Index.NameonCheck, FieldType = EntityFieldType.Char, Size = 60)]
		public string NameonCheck { get; set; }

		/// <summary>
		/// Gets or sets CheckLanguage
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CheckLanguage", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 14)]
		[ViewField(Name = Fields.CheckLanguage, Id = Index.CheckLanguage, FieldType = EntityFieldType.Char, Size = 3)]
		public string CheckLanguage { get; set; }

		/// <summary>
		/// Gets or sets PaymentCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PaymentCurrency", ResourceType = typeof (ARCommonResx))]
        [InquiryField(Id = 15)]
        [GridInfo(8, typeof(ARCommonResx), "PaymentCurrency")]
		[ViewField(Name = Fields.PaymentCurrency, Id = Index.PaymentCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string PaymentCurrency { get; set; }

		/// <summary>
		/// Gets or sets RateType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 16)]
		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string RateType { get; set; }

		/// <summary>
		/// Gets or sets RateDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "RateDate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 17)]
		[ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? RateDate { get; set; }

		/// <summary>
		/// Gets or sets ExchangeRate
		/// </summary>
        [InquiryField(Id = 18)]
        [GridInfo(9, typeof(ARCommonResx), "ExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", Style = "w150 numeric")]
		[ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal ExchangeRate { get; set; }

		/// <summary>
		/// Gets or sets RateOperator
		/// </summary>
		[Display(Name = "RateOperator", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 19)]
		[ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
		public RateOperator RateOperator { get; set; }

		/// <summary>
		/// Gets or sets RateOverrideFlag
		/// </summary>
		[Display(Name = "RateOverrideFlag", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 20)]
		[ViewField(Name = Fields.RateOverrideFlag, Id = Index.RateOverrideFlag, FieldType = EntityFieldType.Int, Size = 2)]
		public RateOverrideFlag RateOverrideFlag { get; set; }

		/// <summary>
		/// Gets or sets PaymentAmount
		/// </summary>
		[Display(Name = "PaymentAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 21)]
        [GridInfo(10, typeof(ARCommonResx), "PaymentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
		[ViewField(Name = Fields.PaymentAmount, Id = Index.PaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal PaymentAmount { get; set; }

		/// <summary>
		/// UI related PaymountAmountDecimal
		/// </summary>
		public string PaymentAmountDecimal { get; set; }

		/// <summary>
		/// Gets or sets CustomerAmount
		/// </summary>
		[Display(Name = "CustomerAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 22)]
        [GridInfo(6, typeof(ARCommonResx), "CustomerAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
		[ViewField(Name = Fields.CustomerAmount, Id = Index.CustomerAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal CustomerAmount { get; set; }

		/// <summary>
		/// Gets or sets FunctionalAmount
		/// </summary>
		[Display(Name = "FunctionalAmount", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 23)]
        [GridInfo(7, typeof(ARCommonResx), "FunctionalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", Style = "w150 numeric")]
        [ViewField(Name = Fields.FunctionalAmount, Id = Index.FunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAmount { get; set; }

		/// <summary>
		/// Gets or sets PostingSequenceNumber
		/// </summary>
		[Display(Name = "PostingSequenceNo", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 24)]
        [GridInfo(21, typeof(ARCommonResx), "PostingSequenceNo")]
		[ViewField(Name = Fields.PostingSequenceNumber, Id = Index.PostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal PostingSequenceNumber { get; set; }

		/// <summary>
		/// Gets or sets BatchNumber
		/// </summary>
		[Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 25)]
        [GridInfo(22, typeof(ARCommonResx), "BatchNumber")]
		[ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal BatchNumber { get; set; }

		/// <summary>
		/// Gets or sets EntryNumber
		/// </summary>
		[Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 26)]
        [GridInfo(23, typeof(ARCommonResx), "EntryNumber")]
		[ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
		public decimal EntryNumber { get; set; }

		/// <summary>
		/// Gets or sets PaymentStatus
		/// </summary>
		[Display(Name = "PaymentStatus", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 27)]
		[ViewField(Name = Fields.PaymentStatus, Id = Index.PaymentStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public PaymentStatus PaymentStatus { get; set; }

		/// <summary>
		/// Gets or sets OrderBy
		/// </summary>
		/// <value>Type</value>
		[Display(Name = "OrderBy", ResourceType = typeof(ARCommonResx))]
		public RefundOrderBy OrderBy { get; set; }

		//CheckBox for RefundStatus
		/// <summary>
		/// Gets or sets Refund Status
		/// </summary>
		[ValidateListForSelection]
		[Display(Name = "RefundStatus", ResourceType = typeof(ARCommonResx))]
		public List<MultiSelect> RefundStatus { get; set; }

		//Check Box for Payment Type
		/// <summary>
		/// Gets or sets PaymentTypeMultiSelect
		/// </summary>
		[ValidateListForSelection]
		[Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
		public List<MultiSelect> PaymentTypeMultiSelect { get; set; }

		/// <summary>
		/// Gets or sets DateCleared
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DateCleared", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 28)]
        [GridInfo(18, typeof(ARCommonResx), "DateCleared", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
		[ViewField(Name = Fields.DateCleared, Id = Index.DateCleared, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? DateCleared { get; set; }

		/// <summary>
		/// Gets or sets DateReversed
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "DateReversed", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 29)]
        [GridInfo(19, typeof(ARCommonResx), "DateReversed", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
		[ViewField(Name = Fields.DateReversed, Id = Index.DateReversed, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? DateReversed { get; set; }

		/// <summary>
		/// Gets or sets ReasonForReturn
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ReasonForReturn", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 30)]
        [GridInfo(20, typeof(ARCommonResx), "ReasonForReturn")]
		[ViewField(Name = Fields.ReasonForReturn, Id = Index.ReasonForReturn, FieldType = EntityFieldType.Char, Size = 60)]
		public string ReasonForReturn { get; set; }

		/// <summary>
		/// Gets or sets DocumentType
		/// </summary>
		[Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 31)]
		[ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
		public PaymentDocumentType DocumentType { get; set; }

		/// <summary>
		/// Gets or sets ClientUniqueID
		/// </summary>
		[Display(Name = "ClientUniqueID", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 32)]
		[ViewField(Name = Fields.ClientUniqueID, Id = Index.ClientUniqueID, FieldType = EntityFieldType.Long, Size = 4)]
		public long ClientUniqueID { get; set; }

		/// <summary>
		/// Gets or sets PostingDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 33)]
        [GridInfo(11, typeof(ARCommonResx), "PostingDate", templateSource: GridInfoTemplateLib.FormattedDate, Style = "w150")]
		[ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime? PostingDate { get; set; }

		/// <summary>
		/// Gets or sets CreditCardTransactionNumber
		/// </summary>
		[StringLength(36, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CreditCardTransactionNumber", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 34)]
		[ViewField(Name = Fields.CreditCardTransactionNumber, Id = Index.CreditCardTransactionNumber, FieldType = EntityFieldType.Char, Size = 36)]
		public string CreditCardTransactionNumber { get; set; }

		/// <summary>
		/// Gets or sets ProcessingCode
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "ProcessingCode", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 35)]
		[ViewField(Name = Fields.ProcessingCode, Id = Index.ProcessingCode, FieldType = EntityFieldType.Char, Size = 12)]
		public string ProcessingCode { get; set; }

		#region Custom Properties

		/// <summary>
		/// This properties was added for currenecy code of associated customer number
		/// Gets or sets the Customer Currency
		/// </summary>
		[ViewField(Name = Fields.CustomerCurrency, Id = Index.CustomerCurrency, FieldType = EntityFieldType.Char, Size = 3)]
		public string CustomerCurrency { get; set; }

		#endregion

		#region UI Strings

		/// <summary>
		/// Gets PaymentType string value
		/// </summary>
        [GridInfo(15, typeof(ARCommonResx), "PaymentType")]
		public string PaymentTypeString
		{
			get { return EnumUtility.GetStringValue(PaymentType); }
		}

		/// <summary>
		/// Gets RateOperator string value
		/// </summary>
		public string RateOperatorString
		{
			get { return EnumUtility.GetStringValue(RateOperator); }
		}

		/// <summary>
		/// Gets RateOverrideFlag string value
		/// </summary>
		public string RateOverrideFlagString
		{
			get { return EnumUtility.GetStringValue(RateOverrideFlag); }
		}

		/// <summary>
		/// Gets PaymentStatus string value
		/// </summary>
        [GridInfo(4, typeof(ARCommonResx), "RefundStatus")]
		public string PaymentStatusString
		{
			get { return EnumUtility.GetStringValue(PaymentStatus); }
		}

		/// <summary>
		/// Gets DocumentType string value
		/// </summary>
		public string DocumentTypeString
		{
			get { return EnumUtility.GetStringValue(DocumentType); }
		}

		//Added Extra property BatchEntryNo to concatenate BatchNUmber and EntryNumber
		/// <summary>
		/// BatchEntryNo
		/// </summary>
		[Display(Name = "BatchEntryNo", ResourceType = typeof(ARCommonResx))]
		public string BatchEntryNo
		{
			get { return (BatchNumber + "-" + EntryNumber); }
		}

		#endregion
	}
}
