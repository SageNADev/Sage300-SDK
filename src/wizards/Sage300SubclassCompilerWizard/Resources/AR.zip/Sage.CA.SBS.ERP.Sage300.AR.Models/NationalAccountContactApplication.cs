// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Status = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Status;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for NationalAccount
    /// </summary>
    public partial class NationalAccountContactApplication : ModelBase
    {
        /// <summary>
        /// Gets or sets NationalAccountNumber
        /// </summary>
        [Display(Name = "NationalAccountNumber", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets ContactCode
        /// </summary>
        [Display(Name = "ContactCode", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.ContactCode, Id = Index.ContactCode, FieldType = EntityFieldType.Char, Size = 24)]
        public string ContactCode { get; set; }

        /// <summary>
        /// Gets or sets ApplicationID
        /// </summary>
        [Display(Name = "ApplicationID", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.ApplicationID, Id = Index.ApplicationID, FieldType = EntityFieldType.Char, Size = 2)]
        public string ApplicationID { get; set; }

        /// <summary>
        /// Gets or sets FormID
        /// </summary>
        [Display(Name = "FormID", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.FormID, Id = Index.FormID, FieldType = EntityFieldType.Int, Size = 2)]
        public int FormID { get; set; }

        /// <summary>
        /// Gets or sets Selected
        /// </summary>
        [Display(Name = "Selected", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.Selected, Id = Index.Selected, FieldType = EntityFieldType.Bool, Size = 2)]
        public int Selected { get; set; }

        #region Properties for finder
        #endregion Properties for finder
    }

}
