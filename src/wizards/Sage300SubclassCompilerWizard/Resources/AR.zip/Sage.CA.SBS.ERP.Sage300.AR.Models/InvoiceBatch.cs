/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Invoice Batch Class 
    /// </summary>
    public partial class InvoiceBatch : BaseInvoiceBatch
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="InvoiceBatch"/> class.
        /// </summary>
        public InvoiceBatch()
        {
            PostInvoice = new PostInvoice();
        }
        
        /// <summary>
        /// Entries related to posting a Invoice
        /// </summary>
        /// <value>The post Invoice.</value>
        public PostInvoice PostInvoice { get; set; }

        /// <summary>
        /// Set Up Data
        /// </summary>
        public InvoiceBatchSetup InvoiceBatchSetUp { get; set; }

        /// <summary>
        /// Gets and sets IsInquiryMode
        /// </summary>
        public bool IsInquiryMode { get; set; }
    }

    /// <summary>
    /// Invoice Batch Setup
    /// </summary>
    public class InvoiceBatchSetup : ModelBase
    {
        /// <summary>
        /// OE Module
        /// </summary>
        public const string OEModule = "OE";

        /// <summary>
        /// GL Module
        /// </summary>
        public const string GLModule = "GL";

        /// <summary>
        /// PM Module
        /// </summary>
        public const string PMModule = "PM";

        /// <summary>
        /// IC Module
        /// </summary>
        public const string ICModule = "IC";

        /// <summary>
        /// PO Module
        /// </summary>
        public const string POModule = "PO";

        /// <summary>
        /// Gets or Sets Is Company Multi-Currency
        /// </summary>
        public bool IsMultiCurrency;

        /// <summary>
        /// Gets or sets the currencydecimals.
        /// </summary>
        public string CurrencyDecimals;

        /// <summary>
        /// OE Exist
        /// </summary>
        public bool OEExist;
        
        /// <summary>
        /// GL Exist
        /// </summary>
        public bool GLExist;

        /// <summary>
        /// PM Exist
        /// </summary>
        public bool PMExist;
        
        /// <summary>
        /// IC Exist
        /// </summary>
        public bool ICExist;
        
        /// <summary>
        /// PO Exist
        /// </summary>
        public bool POExist;

        /// <summary>
        /// Can Prepay Inquire
        /// </summary>
        public bool CanPrepayInquire;

        /// <summary>
        /// Transaction Optional Fields
        /// </summary>
        public bool TransactionOptionalFields;
       
        /// <summary>
        /// Is Quantities enabled
        /// </summary>
        public bool HasQuantities;

        /// <summary>
        /// Spread value
        /// </summary>
        public decimal Spread;

        /// <summary>
        /// Has Optional Field license
        /// </summary>
        public bool HasOptionalFields;
    }
}
