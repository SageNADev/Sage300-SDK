// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Model for Receipts/Adjustments (rotoview AR0042 - ARTCR).
    /// </summary>
    public partial class ReceiptAdjustmentHeader : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        public ReceiptAdjustmentHeader()
        {
            ReceiptAppliedAdjustmentDetail = new EnumerableResponse<ReceiptAppliedAdjustmentDetail>();
            ReceiptAdjustmentGLDistributionDetail = new EnumerableResponse<ReceiptAdjustmentGLDistributionDetail>();
            ReceiptMiscellaneousDetail = new EnumerableResponse<ReceiptMiscellaneousDetail>();
            ReceiptCreateOpenDocumentDetail = new EnumerableResponse<ReceiptCreateOpenDocumentDetail>();
            ReceiptAdjustmentOptionalFieldDetail = new EnumerableResponse<ReceiptAdjustmentOptionalFieldDetail> { Items = new List<ReceiptAdjustmentOptionalFieldDetail>() };
            ReceiptAdvanceCreditDetail = new EnumerableResponse<ReceiptAdvanceCreditDetail>();
            CreateOpenDocumentDetail = new ReceiptCreateOpenDocumentDetail();
            AppliedAdjustmentDetail = new ReceiptAppliedAdjustmentDetail();
            MiscellaneousDetail = new ReceiptMiscellaneousDetail();
            ReceiptTransType = ReceiptTransType.Receipt;
            DocumentType = ReceiptDocumentType.None;
            BankRateOperator = BankRateOperator.Multiply;
            CustomerRateOperator = BankRateOperator.Multiply;
            BankExchangeRate = BankExchangeRate == 0 ? 1 : BankExchangeRate;
            CustExchangeRate = CustExchangeRate == 0 ? 1 : CustExchangeRate;
            ShowType = ShowType.All;
            OrderBy = ReceiptOrderBy.DocumentNumber;
            TaxReportingRateOperator = BankRateOperator.Multiply;
            CustRateOverridden = BatchPrintedFlag.No;
            BankRateOverridden = BatchPrintedFlag.No;
            PaymentType = ReceiptPaymentType.Cash;
            JobRelated = AllowedType.No;
            JobRelatedChked = false;
            JobApplyMethod = JobApplyMethod.ProratebyAmount;
            ProcessCommandCode = ReceiptProcessCommandCode.InsertOptionalFields;
            ReceiptPrinted = AllowedType.No;
            CalculateTax = BatchPrintedFlag.No;
            TaxReportingCalculateMethod = BatchPrintedFlag.No;
            TaxReportingRateOperator = BankRateOperator.Multiply;
            TaxReportingRateOverride = BatchPrintedFlag.No;
            PreviousCcProcessStatus = PreviousCcProcessStatus.SPSTransactionNotStarted;
            CurrentCcProcessStatus = PreviousCcProcessStatus.SPSTransactionNotStarted;

        }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckOrReceiptNo 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckReceiptNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckOrReceiptNo, Id = Index.CheckOrReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CheckOrReceiptNo { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDateOrAdjustmentDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDateOrAdjustmentDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceiptDateOrAdjustmentDate, Id = Index.ReceiptDateOrAdjustmentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ReceiptDateOrAdjustmentDate { get; set; }

        /// <summary>
        /// Conversion of ReceiptDateOrAdjustmentDate into DateTime 
        /// </summary>
        public DateTime ReceiptOrAdjustmentDate
        {
            get { return DateUtil.GetDate(ReceiptDateOrAdjustmentDate, DateUtil.GetMinDate()); }
        }

        /// <summary>
        /// Gets or sets EntryDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryDescription", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EntryDescription, Id = Index.EntryDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string EntryDescription { get; set; }

        /// <summary>
        /// Gets or sets EntryReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryReference", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EntryReference, Id = Index.EntryReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string EntryReference { get; set; }

        /// <summary>
        /// Gets or sets ReceiptAppliedAdjustmentDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptAppliedAdjustmentDetail> ReceiptAppliedAdjustmentDetail { get; set; }

        /// <summary>
        /// Gets or sets ReceiptAdjustmentGLDistributionDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptAdjustmentGLDistributionDetail> ReceiptAdjustmentGLDistributionDetail { get; set; }

        /// <summary>
        /// Gets or sets ReceiptMiscellaneousDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptMiscellaneousDetail> ReceiptMiscellaneousDetail { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCreateOpenDocumentDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptCreateOpenDocumentDetail> ReceiptCreateOpenDocumentDetail { get; set; }

        /// <summary>
        /// Gets or sets ReceiptAdjustmentOptionalFieldDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptAdjustmentOptionalFieldDetail> ReceiptAdjustmentOptionalFieldDetail { get; set; }

        /// <summary>
        /// Gets or sets ReceiptAdvanceCreditDetail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptAdvanceCreditDetail> ReceiptAdvanceCreditDetail { get; set; }

        /// <summary>
        /// Gets or sets BankReceiptAmount 
        /// </summary>
        [Display(Name = "BankReceiptAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankReceiptAmount, Id = Index.BankReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BankReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets CustReceiptAmount 
        /// </summary>
        [Display(Name = "CustReceiptAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustReceiptAmount, Id = Index.CustReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets CustExchangeRate 
        /// </summary>
        [Display(Name = "CustExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustExchangeRate, Id = Index.CustExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal CustExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets CustRateOverridden 
        /// </summary>
        [Display(Name = "CustRateOverridden", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustRateOverridden, Id = Index.CustRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchPrintedFlag CustRateOverridden { get; set; }

        /// <summary>
        /// Gets string CustRateOverridden Enum
        /// </summary>
        public string CustRateOverriddenString
        {
            get { return EnumUtility.GetStringValue(CustRateOverridden); }
        }

        /// <summary>
        /// Gets or sets NumberofDocumentsAppliedto 
        /// </summary>
        [Display(Name = "NumberofDocumentsAppliedto", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.NumberofDocumentsAppliedto, Id = Index.NumberofDocumentsAppliedto, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NumberofDocumentsAppliedto { get; set; }

        /// <summary>
        /// Gets or sets TotalCustAmountApplied 
        /// </summary>
        [Display(Name = "TotalCustAmountApplied", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalCustAmountApplied, Id = Index.TotalCustAmountApplied, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCustAmountApplied { get; set; }

        /// <summary>
        /// Gets or sets TotalCustDiscountAmount 
        /// </summary>
        [Display(Name = "TotalCustDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalCustDiscountAmount, Id = Index.TotalCustDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCustDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerCurrency", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerCurrencyCode, Id = Index.CustomerCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BankRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        [Display(Name = "BankExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets BankRateOverridden 
        /// </summary>
        [Display(Name = "BankRateOverridden", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankRateOverridden, Id = Index.BankRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchPrintedFlag BankRateOverridden { get; set; }

        /// <summary>
        /// Gets string BankRateOverridden Enum
        /// </summary>
        public string BankRateOverriddenString
        {
            get { return EnumUtility.GetStringValue(BankRateOverridden); }
        }

        /// <summary>
        /// Gets or sets ReceiptTransType 
        /// </summary>
        [Display(Name = "ReceiptTransType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceiptTransType, Id = Index.ReceiptTransType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptTransType ReceiptTransType { get; set; }

        /// <summary>
        /// Gets string ReceiptTransType Enum
        /// </summary>
        public string ReceiptTransTypeString
        {
            get { return EnumUtility.GetStringValue(ReceiptTransType); }
        }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets string DocumentType Enum
        /// </summary>
        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }

        /// <summary>
        /// Gets or sets MatchingDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MatchingDocumentNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.MatchingDocumentNumber, Id = Index.MatchingDocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string MatchingDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets LastLineNumber 
        /// </summary>
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastLineNumber, Id = Index.LastLineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastLineNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Fiscal Year and Period in Dispaly format
        /// </summary>
        [Display(Name = "FiscalYearAndPeriod", ResourceType = typeof(ARCommonResx))]
        public string FiscalYearPeriod
        {
            get { return (FiscalYear ?? "0000") + "-" + (FiscalPeriod ?? "00"); }
        }

        /// <summary>
        /// Gets or sets Payer 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Payer", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Payer, Id = Index.Payer, FieldType = EntityFieldType.Char, Size = 60)]
        public string Payer { get; set; }

        /// <summary>
        /// Gets or sets CustRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustRateDate, Id = Index.CustRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? CustRateDate { get; set; }

        /// <summary>
        /// Gets or sets CustRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustRateType, Id = Index.CustRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string CustRateType { get; set; }

        /// <summary>
        /// Gets or sets CustAdjustmentAmount 
        /// </summary>
        [Display(Name = "AdjustmentAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustAdjustmentAmount, Id = Index.CustAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets BankRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankRateDate, Id = Index.BankRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BankRateDate { get; set; }

        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptPaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets string PaymentType Enum
        /// </summary>
        public string PaymentTypeString
        {
            get { return EnumUtility.GetStringValue(PaymentType); }
        }

        /// <summary>
        /// Gets or sets CustUnappliedAmount 
        /// </summary>
        [Display(Name = "CustomerUnapplied", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustUnappliedAmount, Id = Index.CustUnappliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustUnappliedAmount { get; set; }

        /// <summary>
        /// Gets or sets BankUnappliedAmount 
        /// </summary>
        [Display(Name = "ReceiptUnapplied", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BankUnappliedAmount, Id = Index.BankUnappliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BankUnappliedAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncReceiptAmount 
        /// </summary>
        [Display(Name = "FunctionalAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncReceiptAmount, Id = Index.FuncReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets FuncAdjustmentAmount 
        /// </summary>
        [Display(Name = "FuncAdjustmentAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncAdjustmentAmount, Id = Index.FuncAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets BankRateOperator 
        /// </summary>
        [Display(Name = "BankRateOperator", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankRateOperator, Id = Index.BankRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOperator BankRateOperator { get; set; }

        /// <summary>
        /// Gets the BankRateOperator string.
        /// </summary>
        public string BankRateOperatorString
        {
            get { return EnumUtility.GetStringValue(BankRateOperator); }
        }

        /// <summary>
        /// Gets or sets CustomerRateOperator 
        /// </summary>
        [Display(Name = "CustomerRateOperator", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustomerRateOperator, Id = Index.CustomerRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOperator CustomerRateOperator { get; set; }

        /// <summary>
        /// Gets the CustomerRateOperator string.
        /// </summary>
        public string CustomerRateOperatorString
        {
            get { return EnumUtility.GetStringValue(CustomerRateOperator); }
        }

        /// <summary>
        /// Gets or sets TotalFuncDiscountAmount 
        /// </summary>
        [Display(Name = "TotalFuncDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalFuncDiscountAmount, Id = Index.TotalFuncDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalFuncDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalFuncDebitAmount 
        /// </summary>
        [Display(Name = "TotalFuncDebitAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalFuncDebitAmount, Id = Index.TotalFuncDebitAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalFuncDebitAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalFuncCreditAmount 
        /// </summary>
        [Display(Name = "TotalFuncCreditAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalFuncCreditAmount, Id = Index.TotalFuncCreditAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalFuncCreditAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalCustDebitAmount 
        /// </summary>
        [Display(Name = "TotalCustDebitAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalCustDebitAmount, Id = Index.TotalCustDebitAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCustDebitAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalCustCreditAmount 
        /// </summary>
        [Display(Name = "TotalCustCreditAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalCustCreditAmount, Id = Index.TotalCustCreditAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCustCreditAmount { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType JobRelated { get; set; }

        /// <summary>
        /// Gets the JobRelated string
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets or sets JobApplyMethod 
        /// </summary>
        [Display(Name = "ApplyMethod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets the JobApplyMethod string
        /// </summary>
        public string JobApplyMethodString
        {
            get { return EnumUtility.GetStringValue(JobApplyMethod); }
        }

        /// <summary>
        /// Gets or sets ErrorBatch 
        /// </summary>
        [Display(Name = "ErrorBatch", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ErrorBatch, Id = Index.ErrorBatch, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorBatch { get; set; }

        /// <summary>
        /// Gets or sets ErrorEntry 
        /// </summary>
        [Display(Name = "ErrorEntry", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ErrorEntry, Id = Index.ErrorEntry, FieldType = EntityFieldType.Long, Size = 4)]
        public long ErrorEntry { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or Sets OptionalFieldString
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        public string OptionalFieldString { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets the ProcessCommandCode string
        /// </summary>
        public string ProcessCommandCodeString
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets BankCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCurrency", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankCurrencyCode, Id = Index.BankCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BankCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets DrillDownApplicationSource 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DrillDownApplicationSource", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DrillDownApplicationSource, Id = Index.DrillDownApplicationSource, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string DrillDownApplicationSource { get; set; }

        /// <summary>
        /// Gets or sets DrillDownType 
        /// </summary>
        [Display(Name = "DrillDownType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DrillDownType, Id = Index.DrillDownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrillDownType { get; set; }

        /// <summary>
        /// Gets or sets DrillDownLinkNumber 
        /// </summary>
        [Display(Name = "DrillDownLinkNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DrillDownLinkNumber, Id = Index.DrillDownLinkNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrillDownLinkNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptPrinted 
        /// </summary>
        [Display(Name = "ReceiptPrinted", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptPrinted, Id = Index.ReceiptPrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ReceiptPrinted { get; set; }

        /// <summary>
        /// Get or Set Receipt printed
        /// </summary>
        public string ReceiptPrintedString
        {
            get { return EnumUtility.GetStringValue(ReceiptPrinted); }
        }

        /// <summary>
        /// Gets or sets CalculateTax 
        /// </summary>
        [Display(Name = "CalculateTax", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CalculateTax, Id = Index.CalculateTax, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchPrintedFlag CalculateTax { get; set; }

        /// <summary>
        /// Get or Set CalculateTax String
        /// </summary>
        public string CalculateTaxString
        {
            get { return EnumUtility.GetStringValue(CalculateTax); }
        }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxStateVersion 
        /// </summary>
        [Display(Name = "StateTax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxStateVersion, Id = Index.TaxStateVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxStateVersion { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3 
        /// </summary>
        [Display(Name = "TaxAuthority3", ResourceType = typeof(ReceiptEntryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "DistAmountNetofTaxes", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DistAmountNetofTaxes, Id = Index.DistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets DepositSerialNumber 
        /// </summary>
        [Display(Name = "DepositSerialNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DepositSerialNumber, Id = Index.DepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long DepositSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DepositLineNumber 
        /// </summary>
        [Display(Name = "DepositLineNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DepositLineNumber, Id = Index.DepositLineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DepositLineNumber { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyCode", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCalculateMethod 
        /// </summary>
        [Display(Name = "CalculateTaxReporting", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxReportingCalculateMethod, Id = Index.TaxReportingCalculateMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchPrintedFlag TaxReportingCalculateMethod { get; set; }

        /// <summary>
        /// Get or Set TaxReportingCalculateMethod String
        /// </summary>
        public string TaxReportingCalculateMethodString
        {
            get { return EnumUtility.GetStringValue(TaxReportingCalculateMethod); }
        }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate 
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperator 
        /// </summary>
        [Display(Name = "TaxReportingRateOperator", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperator, Id = Index.TaxReportingRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOperator TaxReportingRateOperator { get; set; }

        /// <summary>
        /// Get or Set TaxReportingRateOperator String
        /// </summary>
        public string TaxReportingRateOperatorString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOperator); }
        }

        /// <summary>
        /// Gets or sets TaxReportingRateOverride 
        /// </summary>
        [Display(Name = "TaxReportingRateOverride", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOverride, Id = Index.TaxReportingRateOverride, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchPrintedFlag TaxReportingRateOverride { get; set; }

        /// <summary>
        /// Get or Set TaxReportingRateOverride String
        /// </summary>
        public string TaxReportingRateOverrideString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOverride); }
        }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotal 
        /// </summary>
        [Display(Name = "TaxReportingTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxReportingTotal, Id = Index.TaxReportingTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotal { get; set; }

        /// <summary>
        /// Gets or sets NumberofAdvanceCreditClaims 
        /// </summary>
        [Display(Name = "NumberofAdvanceCreditClaims", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.NumberofAdvanceCreditClaims, Id = Index.NumberofAdvanceCreditClaims, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofAdvanceCreditClaims { get; set; }

        /// <summary>
        /// Gets or sets TotalAdvanceCreditClaim 
        /// </summary>
        [Display(Name = "AdvanceCredit", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalAdvanceCreditClaim, Id = Index.TotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalAdvanceCreditClaim 
        /// </summary>
        [Display(Name = "FuncTotalAdvanceCreditClaim", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTotalAdvanceCreditClaim, Id = Index.FuncTotalAdvanceCreditClaim, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalAdvanceCreditClaim { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalCustAmountApplied 
        /// </summary>
        [Display(Name = "FuncTotalCustAmountApplied", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTotalCustAmountApplied, Id = Index.FuncTotalCustAmountApplied, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalCustAmountApplied { get; set; }

        /// <summary>
        /// Gets or sets FuncCustUnappliedAmount 
        /// </summary>
        [Display(Name = "FuncCustUnappliedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncCustUnappliedAmount, Id = Index.FuncCustUnappliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCustUnappliedAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase1 
        /// </summary>
        [Display(Name = "FuncTaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase1, Id = Index.FuncTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase2 
        /// </summary>
        [Display(Name = "FuncTaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase2, Id = Index.FuncTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase3 
        /// </summary>
        [Display(Name = "FuncTaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase3, Id = Index.FuncTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase4 
        /// </summary>
        [Display(Name = "FuncTaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase4, Id = Index.FuncTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase5 
        /// </summary>
        [Display(Name = "FuncTaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase5, Id = Index.FuncTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1 
        /// </summary>
        [Display(Name = "FuncTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2 
        /// </summary>
        [Display(Name = "FuncTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3 
        /// </summary>
        [Display(Name = "FuncTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4 
        /// </summary>
        [Display(Name = "FuncTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5 
        /// </summary>
        [Display(Name = "FuncTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxTotal 
        /// </summary>
        [Display(Name = "FuncTaxTotal", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxTotal, Id = Index.FuncTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "FuncDistAmountNetofTaxes", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncDistAmountNetofTaxes, Id = Index.FuncDistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets AorRVersionCreatedIn
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARVersionCreatedIn", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.AorRVersionCreatedIn, Id = Index.AorRVersionCreatedIn, FieldType = EntityFieldType.Char, Size = 3)]
        public string AorRVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PostingDate { get; set; }

        /// <summary>
        /// Conversion of ReceiptDateOrAdjustmentDate into DateTime 
        /// </summary>
        public DateTime PostingDateTime
        {
            get { return DateUtil.GetDate(PostingDate, DateUtil.GetMinDate()); }
        }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets PreviousCCTransactionNumber 
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreviousCCTransactionNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.PreviousCcTransactionNumber, Id = Index.PreviousCcTransactionNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string PreviousCcTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets PreviousCCProcessStatus 
        /// </summary>
        [Display(Name = "PreviousCCProcessStatus", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.PreviousCcProcessStatus, Id = Index.PreviousCcProcessStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PreviousCcProcessStatus PreviousCcProcessStatus { get; set; }

        /// <summary>
        /// Get or Set PreviousCcProcessStatus String
        /// </summary>
        public string PreviousCcProcessStatusString
        {
            get { return EnumUtility.GetStringValue(PreviousCcProcessStatus); }
        }

        /// <summary>
        /// Gets or sets CurrentCCTransactionNumber 
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentCCTransactionNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CurrentCcTransactionNumber, Id = Index.CurrentCcTransactionNumber, FieldType = EntityFieldType.Char, Size = 36)]
        public string CurrentCcTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets CurrentCCProcessStatus 
        /// </summary>
        [Display(Name = "PreviousCCProcessStatus", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CurrentCcProcessStatus, Id = Index.CurrentCcProcessStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public PreviousCcProcessStatus CurrentCcProcessStatus { get; set; }

        /// <summary>
        /// Gets or sets CurrentCCProcessStatus 
        /// </summary>
        [Display(Name = "PreviousCCProcessStatus", ResourceType = typeof(ReceiptEntryResx))]
        public CurrentCcProcessStatus CurrentCcProcessStatusQuickStatus { get; set; }

        /// <summary>
        /// Get or Set CurrentCCProcessStatus String
        /// </summary>
        public string CurrentCcProcessStatusString
        {
            get { return EnumUtility.GetStringValue(CurrentCcProcessStatus); }
        }
        
        /// <summary>
        /// Get or Set AuthorizationCode String
        /// </summary>
        public string  AuthorizationCode { get; set; }

        /// <summary>
        /// Gets or sets ProcessingCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProcessingCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessingCode, Id = Index.ProcessingCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string ProcessingCode { get; set; }

        public bool JobRelatedChked
        {
            get
            {
                return JobRelated == Common.Models.Enums.AllowedType.Yes;
            }
            set 
            {
                JobRelated = value 
                ? Common.Models.Enums.AllowedType.Yes
                : Common.Models.Enums.AllowedType.No;
            }
        }

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHT1TC, Id = Index.AmtWHT1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHT2TC, Id = Index.AmtWHT2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHT3TC, Id = Index.AmtWHT3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHT4TC, Id = Index.AmtWHT4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHT5TC, Id = Index.AmtWHT5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT5TC { get; set; } = 0;

        #region UI

        /// <summary>
        /// Gets or sets PPMatchingDocNo 
        /// </summary>
        [Display(Name = "PPMatchingDocNo", ResourceType = typeof(ReceiptEntryResx))]
        public string PpMatchingDocType { get; set; }

        /// <summary>
        /// Gets or sets ShowType 
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        public ShowType ShowType { get; set; }

        /// <summary>
        /// Gets or sets OrderBy 
        /// </summary>
        [Display(Name = "OrderBy", ResourceType = typeof(ARCommonResx))]
        public ReceiptOrderBy OrderBy { get; set; }

        /// <summary>
        /// Create OpenDocument Detail
        /// </summary>
        [IgnoreExportImport]
        public ReceiptCreateOpenDocumentDetail CreateOpenDocumentDetail { get; set; }

        /// <summary>
        /// Applied Adjustment Detail
        /// </summary>
        [IgnoreExportImport]
        public ReceiptAppliedAdjustmentDetail AppliedAdjustmentDetail { get; set; }

        /// <summary>
        /// Gets or sets OrderBy 
        /// </summary>
        [Display(Name = "AutoApply", ResourceType = typeof(ReceiptEntryResx))]
        public bool AutoApply { get; set; }

        /// <summary>
        /// checks if batch date is valid
        /// </summary>
        public bool BatchDateValid { get; set; }

        /// <summary>
        /// Applied Adjustment Detail
        /// </summary>
        [IgnoreExportImport]
        public ReceiptMiscellaneousDetail MiscellaneousDetail { get; set; }

        /// <summary>
        /// Gets or sets Tax Group Description
        /// </summary>
        [Display(Name = "TaxGroupDesc", ResourceType = typeof(ReceiptEntryResx))]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// TransactionStatus
        /// </summary>
        [IgnoreExportImport]
        public string TransactionStatus { get; set; }

        /// <summary>
        /// Bank Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string BankCurrencyDecimal { get; set; }

        /// <summary>
        /// Customer Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string CustCurrencyDecimal { get; set; }

        #endregion
    }
}
