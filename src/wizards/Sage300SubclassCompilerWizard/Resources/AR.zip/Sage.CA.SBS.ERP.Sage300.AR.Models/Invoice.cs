/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using System;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Invoice Model
    /// </summary>
    public partial class Invoice : BaseInvoice
    {
        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated)]
        public override AllowedType JobRelated { get; set; }

        /// <summary>
        /// Gets Batch Number as numeric
        /// </summary>
        [Display(Name = "NBatchNumber", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber)]
        public long NBatchNumber
        {
            get
            {
                long ret = 0;
                return long.TryParse(BatchNumber, out ret) ? ret : 0;
            }
        }

        /// <summary>
        /// Gets Batch Number as numeric
        /// </summary>
        [Display(Name = "NEntryNumber", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber)]
        public int NEntryNumber
        {
            get
            {
                int ret = 0;
                return int.TryParse(EntryNumber, out ret) ? ret : 0;
            }
        }
    }
}
