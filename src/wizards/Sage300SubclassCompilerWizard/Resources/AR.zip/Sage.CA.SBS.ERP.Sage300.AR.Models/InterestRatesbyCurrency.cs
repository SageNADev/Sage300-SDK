/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class InterestRatesByCurrency : ModelBase
    {

        /// <summary>
        /// Gets or sets Interest Profile 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "InterestProfile", ResourceType = typeof(InterestProfilesResx))]
        [Key]
        [ViewField(Name = Fields.InterestProfile, Id = Index.InterestProfile, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InterestProfile { get; set; }

        /// <summary>
        /// Gets or sets Currency Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "CannotBeBlankMessage", ErrorMessageResourceType = typeof(CommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets Minimum Interest Charge 
        /// </summary>
        [Display(Name = "MinimumInterestCharge", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.MinimumInterestCharge, Id = Index.MinimumInterestCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MinimumInterestCharge { get; set; }

        /// <summary>
        /// Gets or sets Annual Interest Rate 
        /// </summary>
        [Display(Name = "AnnualInterestRate", ResourceType = typeof(InterestProfilesResx))]
        [ViewField(Name = Fields.AnnualInterestRate, Id = Index.AnnualInterestRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal AnnualInterestRate { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Get or sets CurrencyCodeDecimalPlace
        /// </summary>
        public int CurrencyCodeDecimalPlace { get; set; }
    }
}
