// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class OptionsInvoicing : ModelBase
    {
        /// <summary>
        /// Gets or sets Invoicing Options Key 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.InvoicingOptionsKey, Id = Index.InvoicingOptionsKey, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string InvoicingOptionsKey { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Next Invoice Batch Number 
        /// </summary>
        [Display(Name = "NextInvcBatchNumber", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextInvoiceBatchNumber, Id = Index.NextInvoiceBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextInvoiceBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets Invoice 
        /// </summary>
        [Display(Name = "Invoice", ResourceType = typeof (OptionsResx))]
        public string Invoice { get; set; }

        /// <summary>
        /// Gets or sets Invoice Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.InvoicePrefix, Id = Index.InvoicePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string InvoicePrefix { get; set; }

        /// <summary>
        /// Gets or sets Invoice Number Length 
        /// </summary>
        [ViewField(Name = Fields.InvoiceNumberLength, Id = Index.InvoiceNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal InvoiceNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Invoice Number 
        /// </summary>
        [ViewField(Name = Fields.NextInvoiceNumber, Id = Index.NextInvoiceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets Credit Note 
        /// </summary>
        [Display(Name = "CreditNote", ResourceType = typeof (OptionsResx))]
        public string CreditNote { get; set; }

        /// <summary>
        /// Gets or sets Credit Note Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CreditNotePrefix, Id = Index.CreditNotePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CreditNotePrefix { get; set; }

        /// <summary>
        /// Gets or sets Credit Note Number Length 
        /// </summary>
        [ViewField(Name = Fields.CreditNoteNumberLength, Id = Index.CreditNoteNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal CreditNoteNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Credit Note Number 
        /// </summary>
        [ViewField(Name = Fields.NextCreditNoteNumber, Id = Index.NextCreditNoteNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextCreditNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets Debit Note 
        /// </summary>
        [Display(Name = "DebitNote", ResourceType = typeof (OptionsResx))]
        public string DebitNote { get; set; }

        /// <summary>
        /// Gets or sets Debit Note Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DebitNotePrefix, Id = Index.DebitNotePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string DebitNotePrefix { get; set; }

        /// <summary>
        /// Gets or sets Debit Note Number Length 
        /// </summary>
        [ViewField(Name = Fields.DebitNoteNumberLength, Id = Index.DebitNoteNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal DebitNoteNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Debit Note Number 
        /// </summary>
        [ViewField(Name = Fields.NextDebitNoteNumber, Id = Index.NextDebitNoteNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextDebitNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets Interest Invoice 
        /// </summary>
        [Display(Name = "InterestInvoice", ResourceType = typeof (OptionsResx))]
        public string InterestInvoice { get; set; }

        /// <summary>
        /// Gets or sets Interest Invoice Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.InterestInvoicePrefix, Id = Index.InterestInvoicePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string InterestInvoicePrefix { get; set; }

        /// <summary>
        /// Gets or sets Interest Invoice Number Length 
        /// </summary>
        [ViewField(Name = Fields.InterestInvoiceNumberLength, Id = Index.InterestInvoiceNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal InterestInvoiceNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Interest Invoice Number 
        /// </summary>
        [ViewField(Name = Fields.NextInterestInvoiceNumber, Id = Index.NextInterestInvoiceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextInterestInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets Recurring Charges 
        /// </summary>
        [Display(Name = "RecurringCharge", ResourceType = typeof (OptionsResx))]
        public string RecurringCharge { get; set; }

        /// <summary>
        /// Gets or sets Recurring Charge Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RecurringChargePrefix, Id = Index.RecurringChargePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RecurringChargePrefix { get; set; }

        /// <summary>
        /// Gets or sets Recurring Charge Number Length 
        /// </summary>
        [ViewField(Name = Fields.RecurringChargeNumberLength, Id = Index.RecurringChargeNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RecurringChargeNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Recurring Charge Number 
        /// </summary>
        [ViewField(Name = Fields.NextRecurringChargeNumber, Id = Index.NextRecurringChargeNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRecurringChargeNumber { get; set; }

        /// <summary>
        /// Gets or sets Invoice Printing 
        /// </summary>
        [Display(Name = "AllowPrintingInvcs", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.InvoicePrinting, Id = Index.InvoicePrinting, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType InvoicePrinting { get; set; }

        //TODO: The naming convention of this property has to be relooked

        /// <summary>
        /// Gets or sets SWALOWDISC 
        /// </summary>
        [ViewField(Name = Fields.SWALOWDISC, Id = Index.SWALOWDISC, FieldType = EntityFieldType.Int, Size = 2)]
        public int SWALOWDISC { get; set; }

        /// <summary>
        /// Gets or sets Edit After Invoice Printed 
        /// </summary>
        [Display(Name = "AllowEditPrtInvcs", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.EditAfterInvoicePrinted, Id = Index.EditAfterInvoicePrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType EditAfterInvoicePrinted { get; set; }

        //TODO: The naming convention of this property has to be relooked

        /// <summary>
        /// Gets or sets SWALOWIVPS 
        /// </summary>
        [ViewField(Name = Fields.SWALOWIVPS, Id = Index.SWALOWIVPS, FieldType = EntityFieldType.Int, Size = 2)]
        public int SWALOWIVPS { get; set; }

        /// <summary>
        /// Gets or sets Use Item Commentas Default 
        /// </summary>
        [Display(Name = "UseItemCmmtAsDef", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseItemCommentasDefault, Id = Index.UseItemCommentasDefault, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType UseItemCommentasDefault { get; set; }

        /// <summary>
        /// Gets or sets Show Item Cost 
        /// </summary>
        [Display(Name = "ShowItemCost", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ShowItemCost, Id = Index.ShowItemCost, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ShowItemCost { get; set; }

        /// <summary>
        /// Gets or sets Next Invoice Posting Sequence Number 
        /// </summary>
        [Display(Name = "NextInvcPostingSeq", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextInvoicePostingSeqNumber, Id = Index.NextInvoicePostingSeqNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextInvoicePostingSeqNumber { get; set; }

        /// <summary>
        /// Gets or sets Manual Tax Processing Default 
        /// </summary>
        [Display(Name = "CalculateTaxesAuto", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ManualTaxProcessingDefault, Id = Index.ManualTaxProcessingDefault, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType ManualTaxProcessingDefault { get; set; }

        /// <summary>
        /// Gets or sets Default Invoice Type 
        /// </summary>
        [Display(Name = "DefaultInvoiceType", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultInvoiceType, Id = Index.DefaultInvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultInvoiceType DefaultInvoiceType { get; set; }

        /// <summary>
        /// Gets or sets Use Separate Numbers 
        /// </summary>
        [Display(Name = "UseSeparateDocuments", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseSeparateNumbers, Id = Index.UseSeparateNumbers, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType UseSeparateNumbers { get; set; }

        /// <summary>
        /// Gets or sets Retainage Invoice Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RetainageInvoicePrefix, Id = Index.RetainageInvoicePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RetainageInvoicePrefix { get; set; }

        /// <summary>
        /// Gets or sets Retainage Invoice Length 
        /// </summary>
        [ViewField(Name = Fields.RetainageInvoiceLength, Id = Index.RetainageInvoiceLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RetainageInvoiceLength { get; set; }

        /// <summary>
        /// Gets or sets Next Retainage Invoice 
        /// </summary>
        [ViewField(Name = Fields.NextRetainageInvoice, Id = Index.NextRetainageInvoice, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRetainageInvoice { get; set; }

        /// <summary>
        /// Gets or sets Retainage Credit Note Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RetainageCreditNotePrefix, Id = Index.RetainageCreditNotePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RetainageCreditNotePrefix { get; set; }

        /// <summary>
        /// Gets or sets Retainage Credit Note Length 
        /// </summary>
        [ViewField(Name = Fields.RetainageCreditNoteLength, Id = Index.RetainageCreditNoteLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RetainageCreditNoteLength { get; set; }

        /// <summary>
        /// Gets or sets Next Retainage Credit Note 
        /// </summary>
        [ViewField(Name = Fields.NextRetainageCreditNote, Id = Index.NextRetainageCreditNote, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRetainageCreditNote { get; set; }

        /// <summary>
        /// Gets or sets Retainage Debit Note Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RetainageDebitNotePrefix, Id = Index.RetainageDebitNotePrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RetainageDebitNotePrefix { get; set; }

        /// <summary>
        /// Gets or sets Retainage Debit Note Length 
        /// </summary>
        [ViewField(Name = Fields.RetainageDebitNoteLength, Id = Index.RetainageDebitNoteLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RetainageDebitNoteLength { get; set; }

        /// <summary>
        /// Gets or sets Next Retainage Debit Note 
        /// </summary>
        [ViewField(Name = Fields.NextRetainageDebitNote, Id = Index.NextRetainageDebitNote, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRetainageDebitNote { get; set; }

        /// <summary>
        /// Gets or sets Use Retainage 
        /// </summary>
        [Display(Name = "UseRetainage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.UseRetainage, Id = Index.UseRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType UseRetainage { get; set; }

        /// <summary>
        /// Gets or sets Retainage Base 
        /// </summary>
        [Display(Name = "BaseRetainageAmountOn", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.RetainageBase, Id = Index.RetainageBase, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageBase RetainageBase { get; set; }

        /// <summary>
        /// Gets or sets Retainage Schedule 
        /// </summary>
        [Display(Name = "ScheduleToUse", ResourceType = typeof (OptionsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RetainageSchedule, Id = Index.RetainageSchedule, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string RetainageSchedule { get; set; }

        /// <summary>
        /// Gets or sets Retainage Schedule Link 
        /// </summary>
        [ViewField(Name = Fields.RetainageScheduleLink, Id = Index.RetainageScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RetainageScheduleLink { get; set; }

        /// <summary>
        /// Gets or sets Date Retainage Schduled Last Run 
        /// </summary>
        [Display(Name = "LastInvoiced", ResourceType = typeof (ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DateRetainageSchedLastRun, Id = Index.DateRetainageSchedLastRun, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateRetainageSchedLastRun { get; set; }

        /// <summary>
        /// Gets or sets Days Retained 
        /// </summary>
        [Display(Name = "DefaultPeriod", ResourceType = typeof (OptionsResx))]
        [Range(typeof (int), "0", "32767", ErrorMessageResourceName = "Range",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DaysRetained, Id = Index.DaysRetained, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysRetained { get; set; }

        /// <summary>
        /// Gets or sets Percent Retained 
        /// </summary>
        [Display(Name = "DefaultPercentage", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.PercentRetained, Id = Index.PercentRetained, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentRetained { get; set; }

        /// <summary>
        /// Gets or sets Days Before Retainage Due 
        /// </summary>
        [Display(Name = "DaysInAdvance", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.DaysBeforeRetainageDue, Id = Index.DaysBeforeRetainageDue, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysBeforeRetainageDue { get; set; }

        /// <summary>
        /// Gets or sets Retainage Exchange Rate 
        /// </summary>
        [Display(Name = "DefaultRetainageExchangeRate", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets Include Pending A/R Transaction
        /// </summary>
        [Display(Name = "InARPendTransInCreditCheck", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.IncludePendingAorRTrans, Id = Index.IncludePendingAorRTrans, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType IncludePendingAorRTrans { get; set; }

        /// <summary>
        /// Gets or sets Include Pending O/E Transaction 
        /// </summary>
        [Display(Name = "InOEPendTransInCreditCheck", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.IncludePendingOorETrans, Id = Index.IncludePendingOorETrans, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType IncludePendingOorETrans { get; set; }

        /// <summary>
        /// Gets or sets Include Pending Other Transaction
        /// </summary>
        [Display(Name = "InXXPendTransInCreditCheck", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.IncludePendingOtherTrans, Id = Index.IncludePendingOtherTrans, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType IncludePendingOtherTrans { get; set; }

        /// <summary>
        /// Gets or sets Default Tax Reporting Control 
        /// </summary>
        [Display(Name = "CalculateTaxReportingAuto", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultTaxReportingControl, Id = Index.DefaultTaxReportingControl, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType DefaultTaxReportingControl { get; set; }

        /// <summary>
        /// Gets or sets Report Retainage Tax 
        /// </summary>
        [Display(Name = "ReportTax", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.ReportRetainageTax, Id = Index.ReportRetainageTax, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportRetainageTax ReportRetainageTax { get; set; }

        /// <summary>
        /// Gets or sets Default Detail Tax Class 
        /// </summary>
        [Display(Name = "DefaultDetailTaxClassTo1", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultDetailTaxClass, Id = Index.DefaultDetailTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultDetailTaxClass DefaultDetailTaxClass { get; set; }

        /// <summary>
        /// Gets or sets Default Posting Date 
        /// </summary>
        [Display(Name = "DefaultPostingDate", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; }

        /// <summary>
        /// Use Retainage Yes/No for UI
        /// </summary>
        public bool UseRetain
        {
            get { return UseRetainage != AllowedType.No; }
            set { UseRetainage = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Include Pending A/R Transactions in Credit Check Yes/No for UI 
        /// </summary>
        public bool IncPendingAorRTrans
        {
            get { return IncludePendingAorRTrans != AllowedType.No; }
            set { IncludePendingAorRTrans = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Include Pending O/E Transactions in Credit Check Yes/No for UI 
        /// </summary>
        public bool IncPendingOorETrans
        {
            get { return IncludePendingOorETrans != AllowedType.No; }
            set { IncludePendingOorETrans = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        /// Include Pending Other Transactions in Credit Check Yes/No for UI 
        /// </summary>
        public bool IncPendingOtherTrans
        {
            get { return IncludePendingOtherTrans != AllowedType.No; }
            set { IncludePendingOtherTrans = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        ///  Use Separate Document Numbers When Creating Retainage Documents Check Yes/No for UI 
        /// </summary>
        public bool UseSeparateNum
        {
            get { return UseSeparateNumbers != AllowedType.No; }
            set { UseSeparateNumbers = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        ///  Calculate Taxe Amount Automatically Check Yes/No for UI 
        /// </summary>
        public bool ManualTaxProcessDefault
        {
            get { return ManualTaxProcessingDefault != AllowedType.Yes; }
            set { ManualTaxProcessingDefault = value ? AllowedType.No : AllowedType.Yes; }
        }

        /// <summary>
        ///  Calculate Tax Reporting Amount Automatically Check Yes/No for UI 
        /// </summary>
        public bool DefaultTaxReportControl
        {
            get { return DefaultTaxReportingControl != AllowedType.No; }
            set { DefaultTaxReportingControl = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        ///  Default Detail Tax Class To 1 Check Yes/No for UI 
        /// </summary>
        public bool DetailTaxClass
        {
            get { return DefaultDetailTaxClass != DefaultDetailTaxClass.DefaulttoCustomerTaxClass; }
            set
            {
                DefaultDetailTaxClass = value
                    ? DefaultDetailTaxClass.Defaultto1
                    : DefaultDetailTaxClass.DefaulttoCustomerTaxClass;
            }
        }

        /// <summary>
        ///  Use Item Comment a sDefault Check Yes/No for UI 
        /// </summary>
        public bool UseItemComasDefault
        {
            get { return UseItemCommentasDefault != AllowedType.No; }
            set { UseItemCommentasDefault = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        ///  Show Item Cost Check Yes/No for UI 
        /// </summary>
        public bool ShowItemCst
        {
            get { return ShowItemCost != AllowedType.No; }
            set { ShowItemCost = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        ///  Allow Printing Of Invoice Check Yes/No for UI 
        /// </summary>
        public bool InvoicePrint
        {
            get { return InvoicePrinting != AllowedType.No; }
            set { InvoicePrinting = value ? AllowedType.Yes : AllowedType.No; }
        }

        /// <summary>
        ///  Allow Printing Of Invoice Check Yes/No for UI 
        /// </summary>
        public bool EditInvoicePrinted
        {
            get { return EditAfterInvoicePrinted != AllowedType.No; }
            set { EditAfterInvoicePrinted = value ? AllowedType.Yes : AllowedType.No; }
        }
    }
}
