// /* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class OptionsReceiptAndAdjustment : ModelBase
    {
        /// <summary>
        /// Gets or sets Receipt Or Adjustment Options Key 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptOrAdjustmentOptionsKey, Id = Index.ReceiptOrAdjustmentOptionsKey, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ReceiptOrAdjustmentOptionsKey { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained 
        /// </summary>       
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Next Receipt Batch Number 
        /// </summary>
        [Display(Name = "NextRcptBatchNum", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextReceiptBatchNumber, Id = Index.NextReceiptBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextReceiptBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets Next Adjustment Batch Number 
        /// </summary>
        [Display(Name = "NextAdjtBatchNum", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextAdjustmentBatchNumber, Id = Index.NextAdjustmentBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextAdjustmentBatchNumber { get; set; }

        //TODO: The naming convention of this property has to be relooked

        /// <summary>
        /// Gets or sets ADJTRX 
        /// </summary>
        [ViewField(Name = Fields.ADJTRX, Id = Index.ADJTRX, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal ADJTRX { get; set; }

        /// <summary>
        /// Gets or sets Allow Printing of Deposit Slips 
        /// </summary>
        [Display(Name = "AllowPrintingOfDeposits", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.AllowPrintingofDepositSlips, Id = Index.AllowPrintingofDepositSlips, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPrintingofDepositSlips AllowPrintingofDepositSlips { get; set; }

        /// <summary>
        /// Gets or sets Edit After Deposit Slip Printed 
        /// </summary>
        [ViewField(Name = Fields.EditAfterDepSlipPrinted, Id = Index.EditAfterDepSlipPrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPrintingofDepositSlips EditAfterDepSlipPrinted { get; set; }

        /// <summary>
        /// Gets or sets Force Printing of Deposit Slips 
        /// </summary>
        [ViewField(Name = Fields.ForcePrintingofDepositSlips, Id = Index.ForcePrintingofDepositSlips, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPrintingofDepositSlips ForcePrintingofDepositSlips { get; set; }

        /// <summary>
        /// Gets or sets Default Order of Open Documents 
        /// </summary>
        [Display(Name = "DefaultOrderOpenDocs", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultOrderofOpenDocuments, Id = Index.DefaultOrderofOpenDocuments, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultOrderofOpenDocuments DefaultOrderofOpenDocuments { get; set; }

        /// <summary>
        /// Gets or sets Next Receipt Posting Sequence
        /// </summary>
        [Display(Name = "NextRcptPostSeq", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextReceiptPostingSeq, Id = Index.NextReceiptPostingSeq, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextReceiptPostingSeq { get; set; }

        /// <summary>
        /// Gets or sets Next Adjustment Posting Sequence 
        /// </summary>
        [Display(Name = "NextAdjtPostSeq", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextAdjustmentPostingSeq, Id = Index.NextAdjustmentPostingSeq, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextAdjustmentPostingSeq { get; set; }

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>
        [Display(Name = "Prepayment", ResourceType = typeof (OptionsResx))]
        public string Prepayment { get; set; }

        /// <summary>
        /// Gets or sets Prepayment Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PrepaymentPrefix, Id = Index.PrepaymentPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string PrepaymentPrefix { get; set; }

        /// <summary>
        /// Gets or sets Prepayment Number Length 
        /// </summary>
        [ViewField(Name = Fields.PrepaymentNumberLength, Id = Index.PrepaymentNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal PrepaymentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Prepayment Number 
        /// </summary>
        [ViewField(Name = Fields.NextPrepaymentNumber, Id = Index.NextPrepaymentNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextPrepaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets Next Prepayment Number 
        /// </summary>
        [Display(Name = "UnappliedCash", ResourceType = typeof (OptionsResx))]
        public string UnappliedCash { get; set; }

        /// <summary>
        /// Gets or sets Unapplied Cash Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.UnappliedCashPrefix, Id = Index.UnappliedCashPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string UnappliedCashPrefix { get; set; }

        /// <summary>
        /// Gets or sets Unapplied Cash Number Length 
        /// </summary>
        [ViewField(Name = Fields.UnappliedCashNumberLength, Id = Index.UnappliedCashNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal UnappliedCashNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Unapplied Cash Number 
        /// </summary>
        [ViewField(Name = Fields.NextUnappliedCashNumber, Id = Index.NextUnappliedCashNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextUnappliedCashNumber { get; set; }

        //TODO: The naming convention of this property has to be relooked

        /// <summary>
        /// Gets or sets DFRATETYPE 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DFRATETYPE, Id = Index.DFRATETYPE, FieldType = EntityFieldType.Char, Size = 2)]
        public string DFRATETYPE { get; set; }

        /// <summary>
        /// Gets or sets Allow Adjustment in Receipt Batch 
        /// </summary>
        [ViewField(Name = Fields.AllowAdjinReceiptBatch, Id = Index.AllowAdjinReceiptBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPrintingofDepositSlips AllowAdjinReceiptBatch { get; set; }

        /// <summary>
        /// Gets or sets Adjustment 
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof (OptionsResx))]
        public string Adjustment { get; set; }

        /// <summary>
        /// Gets or sets Adjustment Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.AdjustmentPrefix, Id = Index.AdjustmentPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string AdjustmentPrefix { get; set; }

        /// <summary>
        /// Gets or sets Adjustment Number Length 
        /// </summary>
        [ViewField(Name = Fields.AdjustmentNumberLength, Id = Index.AdjustmentNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal AdjustmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Adjustment Number 
        /// </summary>
        [ViewField(Name = Fields.NextAdjustmentNumber, Id = Index.NextAdjustmentNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextAdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Default Transaction Type 
        /// </summary>
        [Display(Name = "DefaultTrxType", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultTransactionType, Id = Index.DefaultTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultTransactionType DefaultTransactionType { get; set; }

        /// <summary>
        /// Gets or sets Next Statement Number 
        /// </summary>
        [ViewField(Name = Fields.NextStatementNumber, Id = Index.NextStatementNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextStatementNumber { get; set; }

        /// <summary>
        /// Gets or sets Receipt 
        /// </summary>
        [Display(Name = "Receipt", ResourceType = typeof (OptionsResx))]
        public string Receipt { get; set; }

        /// <summary>
        /// Gets or sets Receipt Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptPrefix, Id = Index.ReceiptPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReceiptPrefix { get; set; }

        /// <summary>
        /// Gets or sets Receipt Number Length 
        /// </summary>
        [ViewField(Name = Fields.ReceiptNumberLength, Id = Index.ReceiptNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal ReceiptNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Receipt Number 
        /// </summary>
        [ViewField(Name = Fields.NextReceiptNumber, Id = Index.NextReceiptNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets Next Refund Batch Number 
        /// </summary>
        [Display(Name = "NextRefundBatchNum", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextRefundBatchNumber, Id = Index.NextRefundBatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRefundBatchNumber { get; set; }

        /// <summary>
        /// Gets or sets Refund 
        /// </summary>
        [Display(Name = "Refund", ResourceType = typeof (OptionsResx))]
        public string Refund { get; set; }

        /// <summary>
        /// Gets or sets Refund Prefix 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RefundPrefix, Id = Index.RefundPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RefundPrefix { get; set; }

        /// <summary>
        /// Gets or sets Refund Number Length 
        /// </summary>
        [ViewField(Name = Fields.RefundNumberLength, Id = Index.RefundNumberLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal RefundNumberLength { get; set; }

        /// <summary>
        /// Gets or sets Next Refund Number 
        /// </summary>
        [ViewField(Name = Fields.NextRefundNumber, Id = Index.NextRefundNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRefundNumber { get; set; }

        /// <summary>
        /// Gets or sets Next Refund Posting Sequence 
        /// </summary>
        [Display(Name = "NextRefundPostSeq", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.NextRefundPostingSeq, Id = Index.NextRefundPostingSeq, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextRefundPostingSeq { get; set; }

        /// <summary>
        /// Gets or sets Edit After Receipt Printed 
        /// </summary>
        [ViewField(Name = Fields.EditAfterReceiptPrinted, Id = Index.EditAfterReceiptPrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPrintingofDepositSlips EditAfterReceiptPrinted { get; set; }

        /// <summary>
        /// Gets or sets Create Deposit Automatically 
        /// </summary>
        [ViewField(Name = Fields.CreateDepositAutomatically, Id = Index.CreateDepositAutomatically, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowPrintingofDepositSlips CreateDepositAutomatically { get; set; }

        /// <summary>
        /// Gets or sets Check for Duplicate Checks 
        /// </summary>
        [Display(Name = "CheckForDuplicateChecks", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.CheckforDuplicateChecks, Id = Index.CheckforDuplicateChecks, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckforDuplicateChecks CheckforDuplicateChecks { get; set; }

        /// <summary>
        /// Gets or sets Include Pending Transactions 
        /// </summary>
        [Display(Name = "CheckForPendingPayment", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.IncludePendingTransactions, Id = Index.IncludePendingTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public IncludePendingTransactions IncludePendingTransactions { get; set; }

        /// <summary>
        /// Gets or sets Default Posting Date 
        /// </summary>
        [Display(Name = "DefaultPostingDate", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; }

        /// <summary>
        /// Gets or sets Sort Checks By 
        /// </summary>
        [Display(Name = "SortChecksBy", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.SortChecksBy, Id = Index.SortChecksBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SortChecksBy SortChecksBy { get; set; }

        /// <summary>
        ///  Allow Printing of Deposit Slips Check Yes/No for UI 
        /// </summary>
        [Display(Name = "AllowPrintingOfDeposits", ResourceType = typeof (OptionsResx))]
        public bool AllowPrintofDepositSlips
        {
            get { return AllowPrintingofDepositSlips != AllowPrintingofDepositSlips.No; }
            set
            {
                AllowPrintingofDepositSlips = value ? AllowPrintingofDepositSlips.Yes : AllowPrintingofDepositSlips.No;
            }
        }

        /// <summary>
        ///  Create Deposit Slip When Reciept Batch Is Created Check Yes/No for UI 
        /// </summary>
        [Display(Name = "CreateDepositAutomatically", ResourceType = typeof (OptionsResx))]
        public bool CreateDepositAuto
        {
            get { return CreateDepositAutomatically != AllowPrintingofDepositSlips.No; }
            set
            {
                CreateDepositAutomatically = value ? AllowPrintingofDepositSlips.Yes : AllowPrintingofDepositSlips.No;
            }
        }

        /// <summary>
        ///  Allow Edit After Deposit Slip Printed Check Yes/No for UI 
        /// </summary>
        [Display(Name = "AllowEditAftDepPrt", ResourceType = typeof (OptionsResx))]
        public bool EditAfterDepSlipPrint
        {
            get { return EditAfterDepSlipPrinted != AllowPrintingofDepositSlips.No; }
            set { EditAfterDepSlipPrinted = value ? AllowPrintingofDepositSlips.Yes : AllowPrintingofDepositSlips.No; }
        }

        /// <summary>
        ///  Force Printing of Deposit Slips Check Yes/No for UI 
        /// </summary>
        [Display(Name = "ForcePrtDepSlips", ResourceType = typeof (OptionsResx))]
        public bool ForcePrintofDepositSlips
        {
            get { return ForcePrintingofDepositSlips != AllowPrintingofDepositSlips.No; }
            set
            {
                ForcePrintingofDepositSlips = value ? AllowPrintingofDepositSlips.Yes : AllowPrintingofDepositSlips.No;
            }
        }

        /// <summary>
        ///  Allow Adjustment in Receipt Batch Check Yes/No for UI 
        /// </summary>
        [Display(Name = "AllowAdjInRcptBtch", ResourceType = typeof (OptionsResx))]
        public bool AllowAdjustinReceiptBatch
        {
            get { return AllowAdjinReceiptBatch != AllowPrintingofDepositSlips.No; }
            set { AllowAdjinReceiptBatch = value ? AllowPrintingofDepositSlips.Yes : AllowPrintingofDepositSlips.No; }
        }

        /// <summary>
        ///  Allow Edit After Receipt Printed Check Yes/No for UI 
        /// </summary>
        [Display(Name = "AllowEditPrtRcpts", ResourceType = typeof (OptionsResx))]
        public bool EditAfterReceiptPrint
        {
            get { return EditAfterReceiptPrinted != AllowPrintingofDepositSlips.No; }
            set { EditAfterReceiptPrinted = value ? AllowPrintingofDepositSlips.Yes : AllowPrintingofDepositSlips.No; }
        }

        #region"Transactions-Options extended properties for UI"

        /// <summary>
        /// Gets or sets Default Payment Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DefaultPaymCode", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultPaymentCode, Id = Index.DefaultPaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string DefaultPaymentCode { get; set; }

        /// <summary>
        /// Gets or sets Default Payment Code Description 
        /// </summary>        
        [Display(Name = "PaymentCodeDescription", ResourceType = typeof (OptionsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string DefaultPaymentCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets Default Bank Code 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DefaultBankCode", ResourceType = typeof (OptionsResx))]
        [ViewField(Name = Fields.DefaultBankCode, Id = Index.DefaultBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DefaultBankCode { get; set; }

        /// <summary>
        /// Gets or sets Default Bank Code Description 
        /// </summary>        
        [Display(Name = "BankCodeDesc", ResourceType = typeof (OptionsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string DefaultBankCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets Payments Acceptance Default Bank Code
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentsAcceptanceDefaultBankCode", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.PaymentsAcceptanceDefaultBankCode, Id = Index.PaymentsAcceptanceDefaultBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string PaymentsAcceptanceDefaultBankCode { get; set; }

        /// <summary>
        /// Gets or sets Default Bank Code Description 
        /// </summary>        
        [Display(Name = "PaymentsAcceptanceDefaultBankCodeDesc", ResourceType = typeof(OptionsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string PaymentsAcceptanceDefaultBankCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets Payments Acceptance Enabled
        /// </summary>
        [ViewField(Name = Fields.PaymentsAcceptanceEnabled, Id = Index.PaymentsAcceptanceEnabled, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PaymentsAcceptanceEnabled { get; set; }

        #endregion
    }
}
