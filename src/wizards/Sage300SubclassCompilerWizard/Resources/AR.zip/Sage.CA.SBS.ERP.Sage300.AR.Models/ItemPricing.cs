// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

#region
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class for Item Pricing
    /// </summary>
	public partial class ItemPricing : ModelBase
	{	 
  		/// <summary>
        /// Gets or sets Item Number 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNo", ResourceType = typeof(ARCommonResx))]
        [Key]
 		[ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
 		public string ItemNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets Currency Code 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Currency", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
 		public string CurrencyCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets Unit Of Measure 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
 		public string UnitofMeasure {get; set;}
		 
  		/// <summary>
        /// Gets or sets Item Cost 
        /// </summary> 
        [Display(Name = "ItemCost", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.ItemCost, Id = Index.ItemCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
 		public decimal ItemCost {get; set;}
		 
  		/// <summary>
        /// Gets or sets Item Price 
        /// </summary>  
       [Display(Name = "ItemPrice", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.ItemPrice, Id = Index.ItemPrice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
 		public decimal ItemPrice {get; set;}

	    /// <summary>
	    /// Gets or sets Tax Base 
	    /// </summary>   
       [Display(Name = "AltTaxBase", ResourceType = typeof(ItemsResx))] 
	    [ViewField(Name = Fields.TaxBase, Id = Index.TaxBase, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
	    public decimal TaxBase { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
       /// <value>The serial number.</value>
       [IgnoreExportImport]
        public long SerialNumber { get; set; }

        
	}
}
