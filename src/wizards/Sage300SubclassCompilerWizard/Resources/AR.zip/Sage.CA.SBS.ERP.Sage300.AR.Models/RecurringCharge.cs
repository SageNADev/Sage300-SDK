// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. 

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    ///RecurringCharge Model
    /// </summary>
    public partial class RecurringCharge : ModelBase
    {
        public RecurringCharge()
        {
            RecurringChargeDetails = new EnumerableResponse<RecurringChargeDetail>();
            RecurringChargeDetailOptionalFields = new EnumerableResponse<RecurringChargeDetailOptionalField>();
            RecurringChargeOptionalFields = new EnumerableResponse<RecurringChargeOptionalField>();
            ShipToLocationInfo = new ShipToInfo();
        }

        /// <summary>
        /// Gets or sets RecurringChargeCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "RecurringChargeCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RecurringChargeCode, Id = Index.RecurringChargeCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string RecurringChargeCode { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecurringChargeDescription", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets Status Description for showing status as text instead of numeric
        /// </summary> 
        [Display(Name = "Status", ResourceType = typeof(RecurringChargeResx))]
        public string StatusDescription { get { return EnumUtility.GetStringValue(Status); } }

        /// <summary>
        /// Gets or set IsStatusActive for validating the inactive checkbox
        /// </summary> 
        [IgnoreExportImport]
        public bool IsStatusActive
        {
            get { return Status == Status.Inactive; }
            set { Status = value == false ? Status.Active : Status.Inactive; }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceDateGenerated 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastInvoiceDateGenerated", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastInvoiceDateGenerated, Id = Index.LastInvoiceDateGenerated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastInvoiceDateGenerated { get; set; }

        /// <summary>
        /// Gets or sets EffectiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StartDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EffectiveDate, Id = Index.EffectiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? EffectiveDate { get; set; }

        /// <summary>
        /// Gets or sets ExpirationDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpirationDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets MaximumTotalInvoiceAmount 
        /// </summary>
        [Display(Name = "MaximumTotalInvoiceAmount", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.MaximumTotalInvoiceAmount, Id = Index.MaximumTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal MaximumTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets YtdTotalInvoiceAmount 
        /// </summary>
        [Display(Name = "YTDTotalInvoiceAmount", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.YtdTotalInvoiceAmount, Id = Index.YtdTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal YtdTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocation 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets SpecialInstructions 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SpecialInstructions", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SpecialInstructions, Id = Index.SpecialInstructions, FieldType = EntityFieldType.Char, Size = 60)]
        public string SpecialInstructions { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PoNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PoNumber, Id = Index.PoNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PoNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceDescription", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.InvoiceDescription, Id = Index.InvoiceDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string InvoiceDescription { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name="RateType",ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Terms", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets LastLineNumber 
        /// </summary>
        [Display(Name = "LastLineNumber", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastLineNumber, Id = Index.LastLineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LastLineNumber { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage1 
        /// </summary>
        [Display(Name = "SalesSplitPercentage1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage1, Id = Index.SalesSplitPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage2 
        /// </summary>
        [Display(Name = "SalesSplitPercentage2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage2, Id = Index.SalesSplitPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage3 
        /// </summary>
        [Display(Name = "SalesSplitPercentage3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage3, Id = Index.SalesSplitPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage4 
        /// </summary>
        [Display(Name = "SalesSplitPercentage4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage4, Id = Index.SalesSplitPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage5 
        /// </summary>
        [Display(Name = "SalesSplitPercentage5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage5, Id = Index.SalesSplitPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets Taxable 
        /// </summary>
        [Display(Name = "Taxable", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.Taxable, Id = Index.Taxable, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable Taxable { get; set; }

        /// <summary>
        /// Gets or sets Taxable Description for showing taxable as text instead of numeric
        /// </summary> 
        [Display(Name = "Taxable", ResourceType = typeof(RecurringChargeResx))]
        public string TaxableString { get { return EnumUtility.GetStringValue(Taxable); } }

        /// <summary>
        /// Gets or sets TaxOverride 
        /// </summary>
        [Display(Name = "TaxOverride", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxOverride, Id = Index.TaxOverride, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxOverride TaxOverride { get; set; }

        /// <summary>
        /// Indicates whether the taxes are automatically calculated or manual
        /// </summary> 
        [IgnoreExportImport]
        public bool IsAutoTax
        {
            get { return TaxOverride == TaxOverride.No; }
            set { TaxOverride = value ? TaxOverride.No : TaxOverride.Yes; }
        }

        /// <summary>
        /// Gets or sets TaxOverride Description for showing TaxOverride as text instead of numeric
        /// </summary> 
        [Display(Name = "TaxOverride", ResourceType = typeof (RecurringChargeResx))]
        public string TaxOverrideString
        {
            get { return EnumUtility.GetStringValue(TaxOverride); }
        }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount1
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount1", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount1, Id = Index.EstimatedWithholdingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount2
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount2", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount2, Id = Index.EstimatedWithholdingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount3
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount3", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount3, Id = Index.EstimatedWithholdingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount4
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount4", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount4, Id = Index.EstimatedWithholdingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmount5
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmount5", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmount5, Id = Index.EstimatedWithholdingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets EstimatedWithholdingAmountTotal
        /// </summary>
        [Display(Name = "EstimatedWithholdingAmountTotal", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.EstimatedWithholdingAmountTotal, Id = Index.EstimatedWithholdingAmountTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal EstimatedWithholdingAmountTotal { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmountPosted 
        /// </summary>
        [Display(Name = "LastInvoiceAmountPosted", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastInvoiceAmountPosted, Id = Index.LastInvoiceAmountPosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmountPosted { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSubtotal 
        /// </summary>
        [Display(Name = "InvoiceSubtotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InvoiceSubtotal, Id = Index.InvoiceSubtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceSubtotal { get; set; }

        /// <summary>
        /// Gets the value of excluded taxes
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExcludedTaxesC", ResourceType = typeof(ARCommonResx))]
        public decimal ExcludedTaxes
        {
            get { return InvoiceTotalIncludingTax - InvoiceSubtotal; }
        }

        /// <summary>
        /// Gets the value of excluded taxes
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IncludedTaxesC", ResourceType = typeof(ARCommonResx))]
        public decimal IncludedTaxes
        {
            get { return InvoiceSubtotal - InvoiceTotalBeforeTax; }
        }

        /// <summary>
        /// Gets or sets MaximumNumberofInvoices 
        /// </summary>
        [Display(Name = "MaximumNumberOfInvoices", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.MaximumNumberofInvoices, Id = Index.MaximumNumberofInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int MaximumNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets YtdNumberofInvoice 
        /// </summary>
        [Display(Name = "YTDNumberOfInvoices", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.YtdNumberofInvoice, Id = Index.YtdNumberofInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public int YtdNumberofInvoice { get; set; }

        /// <summary>
        /// Gets or sets Schedule 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Schedule", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Schedule, Id = Index.Schedule, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Schedule { get; set; }

        /// <summary>
        /// Gets or sets ScheduleLink 
        /// </summary>
        [Display(Name = "ScheduleLink", ResourceType = typeof(RecurringChargeResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ScheduleLink, Id = Index.ScheduleLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ScheduleLink { get; set; }

        /// <summary>
        /// Gets or sets ExpirationType 
        /// </summary>
        [Display(Name = "ExpirationType", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ExpirationType, Id = Index.ExpirationType, FieldType = EntityFieldType.Int, Size = 2)]
        public ExpirationType ExpirationType { get; set; }

        /// <summary>
        /// Gets or sets ExpirationType Description for showing ExpirationType as text instead of numeric
        /// </summary> 
        [Display(Name = "ExpirationType", ResourceType = typeof(RecurringChargeResx))]
        public string ExpirationTypeString { get { return EnumUtility.GetStringValue(ExpirationType); } }


        /// <summary>
        /// Gets or sets ShipViaCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipVia", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaDescription", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.ShipViaDescription, Id = Index.ShipViaDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaDescription { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalBeforeTax 
        /// </summary>
        [Display(Name = "InvoiceTotalBeforeTax", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.InvoiceTotalBeforeTax, Id = Index.InvoiceTotalBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets InvoiceTotalIncludingTax 
        /// </summary>
        [Display(Name = "InvoiceTotalIncludingTax", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.InvoiceTotalIncludingTax, Id = Index.InvoiceTotalIncludingTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal InvoiceTotalIncludingTax { get; set; }


        /// <summary>
        /// Gets or sets TotalTaxAmount 
        /// </summary>
        [Display(Name = "TotalTaxAmount", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.TotalTaxAmount, Id = Index.TotalTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets InvoiceType 
        /// </summary>
        [Display(Name = "InvoiceType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InvoiceType, Id = Index.InvoiceType, FieldType = EntityFieldType.Int, Size = 2)]
        public InvoiceType InvoiceType { get; set; }

        /// <summary>
        /// Gets or sets NumberofOptionalFields 
        /// </summary>
        [Display(Name = "NumberOfOptionalFields", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.NumberofOptionalFields, Id = Index.NumberofOptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberofOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode Description for showing ProcessCommandCode as text instead of numeric
        /// </summary> 
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(ARCommonResx))]
        public string ProcessCommandCodeString { get { return EnumUtility.GetStringValue(ProcessCommandCode); } }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobRelated Description for showing JobRelated as text instead of numeric
        /// </summary> 
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        public string JobRelatedString { get { return EnumUtility.GetStringValue(JobRelated); } }

        /// <summary>
        /// Gets or set IsJobRelated for the job related checkbox
        /// </summary> 
        [IgnoreExportImport]
        public bool IsJobRelated
        {
            get { return JobRelated == JobRelated.Yes; }
            set { JobRelated = value == true ? JobRelated.Yes : JobRelated.No; }
        }

        /// <summary>
        /// Gets or sets NextScheduledDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextScheduledDate", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.NextScheduledDate, Id = Index.NextScheduledDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? NextScheduledDate { get; set; }

        /// <summary>
        /// Gets or sets UnpostedNumberofInvoices 
        /// </summary>
        [Display(Name = "UnpostedNumberofInvoices", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.UnpostedNumberofInvoices, Id = Index.UnpostedNumberofInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int UnpostedNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets UnpostedTotalInvoiceAmount 
        /// </summary>
        [Display(Name = "UnpostedTotalInvoiceAmount", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.UnpostedTotalInvoiceAmount, Id = Index.UnpostedTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnpostedTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets PostedNumberofInvoices 
        /// </summary>
        [Display(Name = "PostedNumberOfInvoices", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.PostedNumberofInvoices, Id = Index.PostedNumberofInvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public int PostedNumberofInvoices { get; set; }

        /// <summary>
        /// Gets or sets PostedTotalInvoiceAmount 
        /// </summary>
        [Display(Name = "PostedTotalInvoiceAmount", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.PostedTotalInvoiceAmount, Id = Index.PostedTotalInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PostedTotalInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceDatePosted 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastInvoiceDatePosted", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastInvoiceDatePosted, Id = Index.LastInvoiceDatePosted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastInvoiceDatePosted { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceNumberPosted 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastInvoiceNumberPosted", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastInvoiceNumberPosted, Id = Index.LastInvoiceNumberPosted, FieldType = EntityFieldType.Char, Size = 22)]
        public string LastInvoiceNumberPosted { get; set; }

        /// <summary>
        /// Gets or sets LastBatchNumberPosted 
        /// </summary>
        [Display(Name = "LastBatchNumberPosted", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastBatchNumberPosted, Id = Index.LastBatchNumberPosted, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal LastBatchNumberPosted { get; set; }

        /// <summary>
        /// Gets or sets LastEntryNumberPosted 
        /// </summary>
        [Display(Name = "LastEntryNumberPosted", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastEntryNumberPosted, Id = Index.LastEntryNumberPosted, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal LastEntryNumberPosted { get; set; }

        /// <summary>
        /// Gets or sets LastPostingSequenceNumber 
        /// </summary>
        [Display(Name = "LastPostingSequenceNumber", ResourceType = typeof(RecurringChargeResx))]
        [ViewField(Name = Fields.LastPostingSequenceNumber, Id = Index.LastPostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal LastPostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        #region extra fields

        /// <summary>
        /// Gets and sets RecurringChargeDetails
        /// </summary>
        public EnumerableResponse<RecurringChargeDetail> RecurringChargeDetails { get; set; }

        /// <summary>
        /// Return Optional Field
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RecurringChargeOptionalField> RecurringChargeOptionalFields { get; set; }

        /// <summary>
        /// Return Optional Field Detail
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RecurringChargeDetailOptionalField> RecurringChargeDetailOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets VendorDetails
        /// </summary>
        [IgnoreExportImport]
        public CustomerInfo CustomerDetails { get; set; }

        /// <summary>
        /// Gets or sets RemitToLocations
        /// </summary>
        [IgnoreExportImport]
        public ShipToInfo ShipToLocationInfo { get; set; }

        /// <summary>
        /// Gets and Sets Sales Split
        /// </summary>
        [IgnoreExportImport]
        public List<SalesSplitTable> SalesSplit { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Line Number
        /// </summary>
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or Sets String conversion of LastInvoiceDatePosted
        /// </summary>
        [IgnoreExportImport]
        public string LastInvDateString
        {
            get
            {
                return DateUtil.GetShortDate(LastInvoiceDatePosted, string.Empty);
            }
        }

        #endregion
    }
}
