/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region namespace

using System;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Model for Receipt Applied Receipts/Adjustment (rotoview AR0044 - ARTCP).
    /// </summary>
    public partial class ReceiptAppliedAdjustmentDetail : ModelBase
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptAppliedAdjustmentDetail"/> class.
        /// </summary>
        public ReceiptAppliedAdjustmentDetail()
        {
            TransactionType = TransactionType.UnappliedCashPosted;
            PpMatchingDocType = PpMatchingDocType.None;
            JobRelated = AllowedType.No;
            JobApplyMethod = JobApplyMethod.ProratebyAmount;
            RetainageExchangeRate = RetainageExchangeRate.UseOriginalDocumentExchangeRate;
            ProcessCommand = ReceiptProcessCommand.Clear;
            TransactionTypeId = TransactionTypeId.UnappliedCashPosted;
            ReceiptTransType = ReceiptTransType.Receipt;
            HasRetainage = AllowBlank.No;

        }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber 
        /// </summary>
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets PaymentResolution 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentResolution", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.PaymentResolution, Id = Index.PaymentResolution, FieldType = EntityFieldType.Char, Size = 2)]
        public string PaymentResolution { get; set; }

        /// <summary>
        /// Gets or sets CustReceiptAmount 
        /// </summary>
        [Display(Name = "AppliedAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustReceiptAmount, Id = Index.CustReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets CustDiscountAmountTaken 
        /// </summary>
        [Display(Name = "DiscountTaken", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustDiscountAmountTaken, Id = Index.CustDiscountAmountTaken, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustDiscountAmountTaken { get; set; }

        /// <summary>
        /// Gets or sets NextAdjSeqNo 
        /// </summary>
        [Display(Name = "NextAdjSeqNo", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.NextAdjSeqNo, Id = Index.NextAdjSeqNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal NextAdjSeqNo { get; set; }

        /// <summary>
        /// Gets or sets CustAdjustmentTotal 
        /// </summary>
        [Display(Name = "AdjustmentAmt", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustAdjustmentTotal, Id = Index.CustAdjustmentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustAdjustmentTotal { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumber 
        /// </summary>
        [Display(Name = "AdjustmentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AdjustmentNumber, Id = Index.AdjustmentNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal AdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets GeneratedPPOrUCNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GeneratedPPUCNo", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.GeneratedPporUcNo, Id = Index.GeneratedPporUcNo, FieldType = EntityFieldType.Char, Size = 22)]
        public string GeneratedPporUcNo { get; set; }

        /// <summary>
        /// Gets or sets PPMatchingDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PPMatchingDocNo", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.PpMatchingDocNo, Id = Index.PpMatchingDocNo, FieldType = EntityFieldType.Char, Size = 22)]
        public string PpMatchingDocNo { get; set; }

        /// <summary>
        /// Gets or sets PPMatchingDocType 
        /// </summary>
        [Display(Name = "PPMatchingDocType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.PpMatchingDocType, Id = Index.PpMatchingDocType, FieldType = EntityFieldType.Int, Size = 2)]
        public PpMatchingDocType PpMatchingDocType { get; set; }

        /// <summary>
        /// Gets or sets DocumentAmountDue 
        /// </summary>
        [Display(Name = "CurrentBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentAmountDue, Id = Index.DocumentAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentAmountDue { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmountAvailable 
        /// </summary>
        [Display(Name = "DiscountAvailable", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountAmountAvailable, Id = Index.DiscountAmountAvailable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmountAvailable { get; set; }

        /// <summary>
        /// Gets or sets DocumentNetBalance 
        /// </summary>
        [Display(Name = "NetBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentNetBalance, Id = Index.DocumentNetBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentNetBalance { get; set; }

        /// <summary>
        /// Gets or sets PendingReceiptAmount 
        /// </summary>
        [Display(Name = "PendPaymentTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingReceiptAmount, Id = Index.PendingReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingDiscountAmount 
        /// </summary>
        [Display(Name = "PendDiscTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingDiscountAmount, Id = Index.PendingDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets PendingAdjustmentAmount 
        /// </summary>
        [Display(Name = "PendAdjTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PendingAdjustmentAmount, Id = Index.PendingAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PendingAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalCustDebitAmount 
        /// </summary>
        [Display(Name = "TotalCustDebitAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalCustDebitAmount, Id = Index.TotalCustDebitAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCustDebitAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalCustCreditAmount 
        /// </summary>
        [Display(Name = "TotalCustCreditAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalCustCreditAmount, Id = Index.TotalCustCreditAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCustCreditAmount { get; set; }

        /// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DocumentType { get; set; }

        /// <summary>
        /// Gets or sets JobRelated 
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType JobRelated { get; set; }

        /// <summary>
        /// Gets or sets JobTotalPaymentAmount 
        /// </summary>
        [Display(Name = "JobTotalPaymentAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.JobTotalPaymentAmount, Id = Index.JobTotalPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JobTotalPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets JobTotalDiscountAmount 
        /// </summary>
        [Display(Name = "JobTotalDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.JobTotalDiscountAmount, Id = Index.JobTotalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal JobTotalDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets JobApplyMethod 
        /// </summary>
        [Display(Name = "JobApplyMethod", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.JobApplyMethod, Id = Index.JobApplyMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public JobApplyMethod JobApplyMethod { get; set; }

        /// <summary>
        /// Gets or sets RtgDebitAmtCustCurr 
        /// </summary>
        [Display(Name = "RtgDebitAmtCustCurr", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RtgDebitAmtCustCurr, Id = Index.RtgDebitAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgDebitAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets RtgCreditAmtCustCurr 
        /// </summary>
        [Display(Name = "RtgCreditAmtCustCurr", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RtgCreditAmtCustCurr, Id = Index.RtgCreditAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgCreditAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount 
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageDueDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTerms", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate 
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand 
        /// </summary>
        [Display(Name = "ProcessCommand", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets UnappliedJobPaymentAmount 
        /// </summary>
        [Display(Name = "UnappliedJobPaymentAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.UnappliedJobPaymentAmount, Id = Index.UnappliedJobPaymentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnappliedJobPaymentAmount { get; set; }

        /// <summary>
        /// Gets or sets UnappliedJobDiscountAmount 
        /// </summary>
        [Display(Name = "UnappliedJobDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.UnappliedJobDiscountAmount, Id = Index.UnappliedJobDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnappliedJobDiscountAmount { get; set; }


        /// <summary>
        /// Gets or sets TRXTYPEID 
        /// </summary>
        [Display(Name = "TransactionTypeID", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TransactionTypeId, Id = Index.TransactionTypeId, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionTypeId TransactionTypeId { get; set; }

        /// <summary>
        /// Gets or sets ReceiptTransType 
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceiptTransType, Id = Index.ReceiptTransType, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptTransType ReceiptTransType { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage 
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageBalance 
        /// </summary>
        [Display(Name = "RetainageBalance", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageBalance, Id = Index.RetainageBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageBalance { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalDocument", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets ReceivablesAdjustmentTotal 
        /// </summary>
        [Display(Name = "ReceivablesAdjustmentTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceivablesAdjustmentTotal, Id = Index.ReceivablesAdjustmentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReceivablesAdjustmentTotal { get; set; }

        /// <summary>
        /// Gets or sets OriginalExchangeRate 
        /// </summary>
        [Display(Name = "OriginalExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalExchangeRate, Id = Index.OriginalExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal OriginalExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets FuncReceiptAmount 
        /// </summary>
        [Display(Name = "FuncReceiptAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncReceiptAmount, Id = Index.FuncReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalDiscountAmount 
        /// </summary>
        [Display(Name = "TotalFuncDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTotalDiscountAmount, Id = Index.FuncTotalDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalAdjustmentAmount 
        /// </summary>
        [Display(Name = "FuncTotalAdjustmentAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTotalAdjustmentAmount, Id = Index.FuncTotalAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageAmount 
        /// </summary>
        [Display(Name = "FuncRetainageAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncRetainageAmount, Id = Index.FuncRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets DocumentVersionCreatedIn 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentVersionCreatedIn", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DocumentVersionCreatedIn, Id = Index.DocumentVersionCreatedIn, FieldType = EntityFieldType.Char, Size = 3)]
        public string DocumentVersionCreatedIn { get; set; }

        /// <summary>
        /// Gets or sets CustomerCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerCurrency", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerCurrencyCode, Id = Index.CustomerCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CustomerCurrencyCode { get; set; }

         /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1TC, Id = Index.AmtWHD1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2TC, Id = Index.AmtWHD2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3TC, Id = Index.AmtWHD3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4TC, Id = Index.AmtWHD4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5TC, Id = Index.AmtWHD5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1HC, Id = Index.AmtWHD1HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2HC, Id = Index.AmtWHD2HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3HC, Id = Index.AmtWHD3HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4HC, Id = Index.AmtWHD4HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5HC, Id = Index.AmtWHD5HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1DT, Id = Index.AmtWHD1DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2DT, Id = Index.AmtWHD2DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3DT, Id = Index.AmtWHD3DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4DT, Id = Index.AmtWHD4DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Job Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5DT, Id = Index.AmtWHD5DT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5DT { get; set; } = 0;

        /// <summary>
        /// Gets or sets Document Tax Authority 1
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax1, Id = Index.CodeTax1, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax1 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 2
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax2, Id = Index.CodeTax2, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax2 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 3
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax3, Id = Index.CodeTax3, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax3 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 4
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax4, Id = Index.CodeTax4, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax4 { get; set; }

        /// <summary>
        /// Gets or sets Document Tax Authority 5
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CodeTax5, Id = Index.CodeTax5, FieldType = EntityFieldType.Char, Size = 12)]
        public string CodeTax5 { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 1 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth1Description, Id = Index.TaxAuth1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth1Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 2 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth2Description, Id = Index.TaxAuth2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth2Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 3 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth3Description, Id = Index.TaxAuth3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth3Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 4 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth4Description, Id = Index.TaxAuth4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth4Description { get; set; }

        /// <summary>
        /// Gets or sets Tax Auth 5 Description
        /// </summary>
        [ViewField(Name = Fields.TaxAuth5Description, Id = Index.TaxAuth5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuth5Description { get; set; }

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.PndWHD1Tot, Id = Index.PndWHD1Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD1Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.PndWHD2Tot, Id = Index.PndWHD2Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD2Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.PndWHD3Tot, Id = Index.PndWHD3Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD3Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.PndWHD4Tot, Id = Index.PndWHD4Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD4Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.PndWHD5Tot, Id = Index.PndWHD5Tot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHD5Tot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Pending Tax Withheld Total
        /// </summary>
        [ViewField(Name = Fields.PndWHDTot, Id = Index.PndWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PndWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Withheld Amount Total
        /// </summary>
        [ViewField(Name = Fields.AmtWHDTot, Id = Index.AmtWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDTot { get; set; } = 0;

       #region UI
        /// <summary>
        /// Check if the row is edited
        /// </summary>
        public bool IsEdited { get; set; }

        /// <summary>
        /// Gets or sets ObljCount  for grid 
        /// </summary>      
        public decimal ObljCount { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is advance document.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is advance document; otherwise, <c>false</c>.
        /// </value>
        public bool IsAdvanceDocument { get; set; }

        /// <summary>
        /// Gets or sets Miscellaneous Adjustment Entry  for sleceted applied adjustment Detail 
        /// </summary>      
        public bool HasAdjGlDistributionDetail { get; set; }

        /// <summary>
        /// Gets RetainageExchangeRate string value
        /// </summary>
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        #endregion
    }
}
