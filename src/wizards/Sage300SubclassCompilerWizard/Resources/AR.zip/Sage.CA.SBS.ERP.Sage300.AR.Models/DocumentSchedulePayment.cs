// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Globalization;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for DocumentSched.Payment
    /// </summary>
    public partial class DocumentSchedulePayment : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets DueDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DueDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets FullyPaidSwitch
        /// </summary>
        [Display(Name = "FullyPaidSwitch", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FullyPaidSwitch, Id = Index.FullyPaidSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public FullyPaidSwitch FullyPaidSwitch { get; set; }

        /// <summary>
        /// Gets or sets OriginalAmountFunc
        /// </summary>
        [Display(Name = "OriginalAmountFunc", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalAmountFunc, Id = Index.OriginalAmountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalAmountFunc { get; set; }

        /// <summary>
        /// Gets or sets OriginalDiscountFunc
        /// </summary>
        [Display(Name = "OriginalDiscountFunc", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalDiscountFunc, Id = Index.OriginalDiscountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalDiscountFunc { get; set; }

        /// <summary>
        /// Gets or sets RemainingDiscountFunc
        /// </summary>
        [Display(Name = "RemainingDiscountFunc", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RemainingDiscountFunc, Id = Index.RemainingDiscountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingDiscountFunc { get; set; }

        /// <summary>
        /// Gets or sets RemainingAmountFunc
        /// </summary>
        [Display(Name = "RemainingAmountFunc", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RemainingAmountFunc, Id = Index.RemainingAmountFunc, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingAmountFunc { get; set; }

        /// <summary>
        /// Gets or sets OriginalAmount
        /// </summary>
        [Display(Name = "OriginalAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalAmount, Id = Index.OriginalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalAmount { get; set; }

        /// <summary>
        /// Gets or sets OriginalDiscount
        /// </summary>
        [Display(Name = "OriginalDiscount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalDiscount, Id = Index.OriginalDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OriginalDiscount { get; set; }

        /// <summary>
        /// Gets or sets RemainingDiscount
        /// </summary>
        [Display(Name = "RemainingDiscount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RemainingDiscount, Id = Index.RemainingDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingDiscount { get; set; }

        /// <summary>
        /// Gets or sets RemainingAmount
        /// </summary>
        [Display(Name = "RemainingAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RemainingAmount, Id = Index.RemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets NationalAccountNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NationalAccountNum", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NationalAccountNumber, Id = Index.NationalAccountNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets GroupCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GroupCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets PrepayApplytoDocNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PrepayApplytoDocNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PrepayApplytoDocNo, Id = Index.PrepayApplytoDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PrepayApplytoDocNo { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public ScheduleDocumentType DocumentType { get; set; }

        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentDate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDaysToPay
        /// </summary> 
        [Display(Name = "NumberOfDaysToPay", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberOfDaysToPay, Id = Index.NumberOfDaysToPay, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfDaysToPay { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumber
        /// </summary>
        [Display(Name = "ShipmentNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipmentNumber, Id = Index.ShipmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string ShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo
        /// </summary>
        [Display(Name = "OriginalDocumentNo", ResourceType = typeof(ARCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }


        #region UI

        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        public string FullyPaidSwitchString
        {
            get { return EnumUtility.GetStringValue(FullyPaidSwitch); }
        }

        public string DocumentTypeString
        {
            get { return EnumUtility.GetStringValue(DocumentType); }
        }
        #endregion
    }
}
