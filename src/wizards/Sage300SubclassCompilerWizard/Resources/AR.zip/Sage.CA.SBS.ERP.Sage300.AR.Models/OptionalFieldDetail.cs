// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Type = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.OptionalFieldType;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class OptionalFieldDetail.
    /// </summary>
    public partial class OptionalFieldDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Location 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Location", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets OptionalField 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "OptionalField", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length 
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals 
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank 
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate 
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank Validate { get; set; }

        /// <summary>
        /// Gets or sets AutoInsert 
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank AutoInsert { get; set; }

        /// <summary>
        /// Gets or sets ReceivablesControl 
        /// </summary>
        [Display(Name = "ReceivablesControl", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceivablesControl, Id = Index.ReceivablesControl, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ReceivablesControl { get; set; }

        /// <summary>
        /// Gets or sets Retainage 
        /// </summary>
        [Display(Name = "Retainage", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Retainage, Id = Index.Retainage, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Retainage { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDiscount 
        /// </summary>
        [Display(Name = "ReceiptDiscount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReceiptDiscount, Id = Index.ReceiptDiscount, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ReceiptDiscount { get; set; }

        /// <summary>
        /// Gets or sets TaxLiability 
        /// </summary>
        [Display(Name = "TaxLiability", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxLiability, Id = Index.TaxLiability, FieldType = EntityFieldType.Int, Size = 2)]
        public bool TaxLiability { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGain 
        /// </summary>
        [Display(Name = "ExchangeGain", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ExchangeGain, Id = Index.ExchangeGain, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLoss 
        /// </summary>
        [Display(Name = "ExchangeLoss", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ExchangeLoss, Id = Index.ExchangeLoss, FieldType = EntityFieldType.Int, Size = 2)]
        public bool ExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGain 
        /// </summary>
        [Display(Name = "UnrealizedExchangeGain", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.UnrealizedExchangeGain, Id = Index.UnrealizedExchangeGain, FieldType = EntityFieldType.Int, Size = 2)]
        public bool UnrealizedExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLoss 
        /// </summary>
        [Display(Name = "UnrealizedExchangeLoss", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.UnrealizedExchangeLoss, Id = Index.UnrealizedExchangeLoss, FieldType = EntityFieldType.Int, Size = 2)]
        public bool UnrealizedExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets Rounding 
        /// </summary>
        [Display(Name = "Rounding", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Rounding, Id = Index.Rounding, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Rounding { get; set; }

        /// <summary>
        /// Gets or sets Revenue 
        /// </summary>
        [Display(Name = "Revenue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Revenue, Id = Index.Revenue, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Revenue { get; set; }

        /// <summary>
        /// Gets or sets Prepayment 
        /// </summary>
        [Display(Name = "Prepayment", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Prepayment, Id = Index.Prepayment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Prepayment { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousReceipt 
        /// </summary>
        [Display(Name = "MiscellaneousReceipt", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.MiscellaneousReceipt, Id = Index.MiscellaneousReceipt, FieldType = EntityFieldType.Int, Size = 2)]
        public bool MiscellaneousReceipt { get; set; }

        /// <summary>
        /// Gets or sets Bank 
        /// </summary>
        [Display(Name = "Bank", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Bank, Id = Index.Bank, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Bank { get; set; }

        /// <summary>
        /// Gets or sets Adjustment 
        /// </summary>
        [Display(Name = "Adjustment", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Adjustment, Id = Index.Adjustment, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Adjustment { get; set; }

        /// <summary>
        /// Gets or sets InventoryControl 
        /// </summary>
        [Display(Name = "InventoryControl", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InventoryControl, Id = Index.InventoryControl, FieldType = EntityFieldType.Int, Size = 2)]
        public bool InventoryControl { get; set; }

        /// <summary>
        /// Gets or sets CostofGoodsSold 
        /// </summary>
        [Display(Name = "CostofGoodsSold", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.CostofGoodsSold, Id = Index.CostofGoodsSold, FieldType = EntityFieldType.Int, Size = 2)]
        public bool CostofGoodsSold { get; set; }

        /// <summary>
        /// Gets or sets BillingsOrCosts 
        /// </summary>
        [Display(Name = "BillingsOrCosts", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.BillingsOrCosts, Id = Index.BillingsOrCosts, FieldType = EntityFieldType.Int, Size = 2)]
        public bool BillingsOrCosts { get; set; }

        /// <summary>
        /// Gets or sets Required 
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank Required { get; set; }

        /// <summary>
        /// Gets or sets ValueSet 
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank ValueSet { get; set; }

        /// <summary>
        /// Gets or sets Labor 
        /// </summary>
        [Display(Name = "Labor", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Labor, Id = Index.Labor, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Labor { get; set; }

        /// <summary>
        /// Gets or sets Overhead 
        /// </summary>
        [Display(Name = "Overhead", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Overhead, Id = Index.Overhead, FieldType = EntityFieldType.Int, Size = 2)]
        public bool Overhead { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex 
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets DefaultTextValue 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultTextValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultAmountValue 
        /// </summary>
        [Display(Name = "DefaultAmountValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberValue 
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultIntegerValue 
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long DefaultIntegerValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultYesOrNoValue 
        /// </summary>
        [Display(Name = "DefaultYesOrNoValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultYesOrNoValue, Id = Index.DefaultYesOrNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank DefaultYesOrNoValue { get; set; }

        ///// <summary>
        ///// Gets or sets DefaultDateValue 
        ///// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldsResx))]
        //[ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        //public string DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue 
        /// </summary>
        [Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldsResx))]
        public DateTime DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue 
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValueDescription { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [IgnoreExportImport]
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [IgnoreExportImport]
        public bool RetainageAccount { get; set; }

        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFields DefaultOptionFieldValue { get; set; }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        [IgnoreExportImport]
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// To get the string of ValueSet property
        /// </summary>
        [IgnoreExportImport]
        public string ValueSetString
        {
            get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        /// To get the string of AllowBlank property
        /// </summary>
        [IgnoreExportImport]
        public string AllowBlankString
        {
            get { return EnumUtility.GetStringValue(AllowBlank); }
        }

        /// <summary>
        /// To get the string of Validate property
        /// </summary>
        [IgnoreExportImport]
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(Validate); }
        }

        /// <summary>
        /// To get the string of AutoInsert property
        /// </summary>
        [IgnoreExportImport]
        public string AutoInsertString
        {
            get { return EnumUtility.GetStringValue(AutoInsert); }
        }

        /// <summary>
        /// To get the string of Required property
        /// </summary>
        [IgnoreExportImport]
        public string RequiredString
        {
            get { return EnumUtility.GetStringValue(Required); }
        }

        /// <summary>
        /// To get the string of DefaultYesOrNoValue property
        /// </summary>
        [IgnoreExportImport]
        public string DefaultYesOrNoValueString
        {
            get { return EnumUtility.GetStringValue(DefaultYesOrNoValue); }
        }

        /// <summary>
        /// To get the string of Location property
        /// </summary>
        [IgnoreExportImport]
        public string LocationString
        {
            get { return EnumUtility.GetStringValue(Location); }
        }

        /// <summary>
        /// Gets or sets ReceivablesControl1 for Finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl ReceivablesControl1 { get; set; }

        /// <summary>
        /// Gets or sets Retainage1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Retainage1 { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDiscount1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl ReceiptDiscount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxLiability1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl TaxLiability1 { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGain1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl ExchangeGain1 { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLoss1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl ExchangeLoss1 { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGain1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl UnrealizedExchangeGain1 { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLoss1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl UnrealizedExchangeLoss1 { get; set; }

        /// <summary>
        /// Gets or sets Rounding1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Rounding1 { get; set; }

        /// <summary>
        /// Gets or sets Revenue1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Revenue1 { get; set; }

        /// <summary>
        /// Gets or sets Prepayment1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Prepayment1 { get; set; }

        /// <summary>
        /// Gets or sets MiscellaneousReceipt1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl MiscellaneousReceipt1 { get; set; }

        /// <summary>
        /// Gets or sets Bank1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Bank1 { get; set; }

        /// <summary>
        /// Gets or sets Adjustment1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Adjustment1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControl1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl InventoryControl1 { get; set; }

        /// <summary>
        /// Gets or sets CostofGoodsSold1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl CostofGoodsSold1 { get; set; }

        /// <summary>
        /// Gets or sets BillingsOrCosts1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl BillingsOrCosts1 { get; set; }

        /// <summary>
        /// Gets or sets Labor1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Labor1 { get; set; }

        /// <summary>
        /// Gets or sets Overhead1 for finder 
        /// </summary>
        [IgnoreExportImport]
        public ReceivablesControl Overhead1 { get; set; }

        /// <summary>
        /// Gets or sets ReceivablesControlString for Finder 
        /// </summary>
        [IgnoreExportImport]
        public string ReceivablesControlString
        {
            get { return EnumUtility.GetStringValue(ReceivablesControl1); }
        }

        /// <summary>
        /// Gets or sets RetainageString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string RetainageString
        {
            get { return EnumUtility.GetStringValue(Retainage1); }
        }

        /// <summary>
        /// Gets or sets ReceiptDiscountString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string ReceiptDiscountString
        {
            get { return EnumUtility.GetStringValue(ReceiptDiscount1); }
        }

        /// <summary>
        /// Gets or sets TaxLiabilityString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string TaxLiabilityString
        {
            get { return EnumUtility.GetStringValue(TaxLiability1); }
        }

        /// <summary>
        /// Gets or sets ExchangeGainString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeGainString
        {
            get { return EnumUtility.GetStringValue(ExchangeGain1); }
        }

        /// <summary>
        /// Gets or sets ExchangeLossString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeLossString
        {
            get { return EnumUtility.GetStringValue(ExchangeLoss1); }
        }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGainString for finder 
        /// </summary>
        [IgnoreExportImport]
        public String UnrealizedExchangeGainString
        {
            get { return EnumUtility.GetStringValue(UnrealizedExchangeGain1); }
        }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLossString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string UnrealizedExchangeLossString
        {
            get { return EnumUtility.GetStringValue(UnrealizedExchangeLoss1); }
        }

        /// <summary>
        /// Gets or sets RoundingString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string RoundingString
        {
            get { return EnumUtility.GetStringValue(Rounding1); }
        }

        /// <summary>
        /// Gets or sets RevenueString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string RevenueString
        {
            get { return EnumUtility.GetStringValue(Revenue1); }

        }

        /// <summary>
        /// Gets or sets PrepaymentString for finder 
        /// </summary>
        [IgnoreExportImport]
        public String PrepaymentString
        {
            get { return EnumUtility.GetStringValue(Prepayment1); }
        }

        /// <summary>
        /// Gets or sets MiscellaneousReceiptString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string MiscellaneousReceiptString
        {
            get { return EnumUtility.GetStringValue(MiscellaneousReceipt1); }
        }

        /// <summary>
        /// Gets or sets BankString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string BankString
        {
            get { return EnumUtility.GetStringValue(Bank1); }
        }

        /// <summary>
        /// Gets or sets AdjustmentString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string AdjustmentString
        {
            get { return EnumUtility.GetStringValue(Adjustment1); }
        }

        /// <summary>
        /// Gets or sets InventoryControlString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string InventoryControlString
        {
            get { return EnumUtility.GetStringValue(InventoryControl1); }
        }

        /// <summary>
        /// Gets or sets CostofGoodsSoldString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string CostofGoodsSoldString
        {
            get { return EnumUtility.GetStringValue(CostofGoodsSold1); }
        }

        /// <summary>
        /// Gets or sets BillingsOrCostsString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string BillingsOrCostsString
        {
            get { return EnumUtility.GetStringValue(BillingsOrCosts1); }
        }

        /// <summary>
        /// Gets or sets LaborString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string LaborString
        {
            get { return EnumUtility.GetStringValue(Labor1); }
        }

        /// <summary>
        /// Gets or sets OverheadString for finder 
        /// </summary>
        [IgnoreExportImport]
        public string OverheadString
        {
            get { return EnumUtility.GetStringValue(Overhead1); }
        }
    }
}
