/* Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved. */

#region namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry;
using BillingType = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.BillingType;
using CostClass = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.CostClass;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Model for Receipt Adjustment G/L Distributions (rotoview AR0045 - ARTCU).
    /// </summary>
    public partial class ReceiptAdjustmentGLDistributionDetail : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptAdjustmentGLDistributionDetail"/> class.
        /// </summary>
        public ReceiptAdjustmentGLDistributionDetail()
        {
            CostClass = CostClass.None;
            HasRetainage = AllowBlank.No;
        }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets SequenceNo 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNo", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.SequenceNo, Id = Index.SequenceNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DistributionAmount 
        /// </summary>
        [Display(Name = "DistributionAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DistributionAmount, Id = Index.DistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets DistributionGOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionGLAccount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DistributionGorLAccount, Id = Index.DistributionGorLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DistributionGorLAccount { get; set; }

        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCategoryResource", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectOrCategoryResource { get; set; }
        
        /// <summary>
        /// Gets or sets TransactionNumber 
        /// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets CostClass 
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString
        {
            get { return EnumUtility.GetStringValue(CostClass); }
        }

        /// <summary>
        /// Gets or sets DiscountAmount 
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets AppliedAmount 
        /// </summary>
        [Display(Name = "AppliedAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AppliedAmount, Id = Index.AppliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AppliedAmount { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitofMeasure 
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitofMeasure { get; set; }

        /// <summary>
        /// Gets or sets Quantity 
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Cost 
        /// </summary>
        [Display(Name = "Cost", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets BillingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BillingDate, Id = Index.BillingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BillingDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount 
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageDueDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage 
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets FuncDistributionAmount 
        /// </summary>
        [Display(Name = "FuncDistAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncDistributionAmount, Id = Index.FuncDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncDiscountAmount 
        /// </summary>
        [Display(Name = "FuncDiscountAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncDiscountAmount, Id = Index.FuncDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncAppliedAmount 
        /// </summary>
        [Display(Name = "FunctionalApplied", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncAppliedAmount, Id = Index.FuncAppliedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAppliedAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageAmount 
        /// </summary>
        [Display(Name = "FuncRetainageAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncRetainageAmount, Id = Index.FuncRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets DocumentLineNumber 
        /// </summary>
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentLineNumber, Id = Index.DocumentLineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal DocumentLineNumber { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyAmountDue 
        /// </summary>
        [Display(Name = "CustCurrencyAmountDue", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CustCurrencyAmountDue, Id = Index.CustCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1TC, Id = Index.AmtWHD1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2TC, Id = Index.AmtWHD2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3TC, Id = Index.AmtWHD3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4TC, Id = Index.AmtWHD4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Customer Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5TC, Id = Index.AmtWHD5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHD1HC, Id = Index.AmtWHD1HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD1HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHD2HC, Id = Index.AmtWHD2HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD2HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHD3HC, Id = Index.AmtWHD3HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD3HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHD4HC, Id = Index.AmtWHD4HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD4HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Func. Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHD5HC, Id = Index.AmtWHD5HC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHD5HC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Tax Withheld Amount Total
        /// </summary>
        [ViewField(Name = Fields.AmtWHDTot, Id = Index.AmtWHDTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHDTot { get; set; } = 0;

        /// <summary>
        /// Gets or sets editable status for PJC columns
        /// </summary>
        [IgnoreExportImport]
        public Dictionary<string, bool> PMDisableDictionary { get; set; }

        #region UI

        /// <summary>
        /// Gets or sets AccountDescription 
        /// </summary>
        [Display(Name = "AccountDesc", ResourceType = typeof(ReceiptEntryResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets DebitAmount  for grid 
        /// </summary>      
        public decimal DebitAmount { get; set; }

        /// <summary>
        /// Gets or sets creditAmount  for grid 
        /// </summary>      
        public decimal CreditAmount { get; set; }

        /// <summary>
        /// Gets or sets DebitRetainageAmount  for grid 
        /// </summary>      
        public decimal DebitRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets creditRetainageAmount  for grid 
        /// </summary>      
        public decimal CreditRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets unformatted contract code
        /// </summary>
        [IgnoreExportImport]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets project type
        /// </summary>
        [IgnoreExportImport]
        public int ProjectType { get; set; } = 0;

        /// <summary>
        /// Gets or sets billing type
        /// </summary>
        [IgnoreExportImport]
        public BillingType BillType { get; set; } = BillingType.Nonbillable;

        /// <summary>
        /// Gets or sets accounting method
        /// </summary>
        [IgnoreExportImport]
        public AccountingMethod AccountingMethod { get; set; } = AccountingMethod.None;

        /// <summary>
        /// Gets or sets time and material project
        /// </summary>
        [IgnoreExportImport]
        public bool TimeAndMaterialProject { get; set; } = false;

        /// <summary>
        /// Gets or sets whether the dynamic attribute fields are disabled
        /// </summary>
        [IgnoreExportImport]
        public Dictionary<string, bool> FieldDisabledAttributes { get; set; }
        #endregion
    }
}
