// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class BillingCycle : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public BillingCycle()
        {
            Status = Status.Active;
        }

        /// <summary>
        /// Gets or sets BillingCycleId 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BillingCycle", ResourceType = typeof (ARCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.BillingCycleId, Id = Index.BillingCycleId, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillingCycleId { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BillingCycleDesc", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "InactiveDate", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "LastMaintained", ResourceType = typeof (CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets DateStatementsLastPrinted 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "StatementsLastPrinted", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.DateStatementsLastPrinted, Id = Index.DateStatementsLastPrinted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateStatementsLastPrinted { get; set; }

        /// <summary>
        /// Gets or sets DateIntInvoicesLastPosted 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [Display(Name = "InterestLastInvoiced", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.DateIntInvoicesLastPosted, Id = Index.DateIntInvoicesLastPosted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateIntInvoicesLastPosted { get; set; }

        /// <summary>
        /// Gets or sets BillingCycleFrequency 
        /// </summary>
        [Display(Name = "Frequency", ResourceType = typeof (BillingCyclesResx))]
        [Range(typeof (decimal), "0", "999")]
        [ViewField(Name = Fields.BillingCycleFrequency, Id = Index.BillingCycleFrequency, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal BillingCycleFrequency { get; set; }

        /// <summary>
        /// Gets or sets RemitToName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "RemitTo", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToName, Id = Index.RemitToName, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToName { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToAddress1, Id = Index.RemitToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToAddress2, Id = Index.RemitToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToAddress3, Id = Index.RemitToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToAddress4, Id = Index.RemitToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets RemitToCity 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToCity, Id = Index.RemitToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToCity { get; set; }

        /// <summary>
        /// Gets or sets RemitToStateOrProv 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToStateOrProv, Id = Index.RemitToStateOrProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToStateOrProv { get; set; }

        /// <summary>
        /// Gets or sets RemitToZipOrPostalCode 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToZipOrPostalCode, Id = Index.RemitToZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string RemitToZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets RemitToCountry 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof (BillingCyclesResx))]
        [ViewField(Name = Fields.RemitToCountry, Id = Index.RemitToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToCountry { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }
    }
}
