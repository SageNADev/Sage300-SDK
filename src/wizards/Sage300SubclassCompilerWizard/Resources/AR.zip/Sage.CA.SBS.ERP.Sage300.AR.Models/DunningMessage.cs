/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class DunningMessage : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public DunningMessage()
        {
            Status = Status.Active;
        }

        /// <summary>
        /// Gets or sets DunningMessageCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DunningMessageCode", ResourceType = typeof(DunningMessagesResx))]
        [Key]
        [ViewField(Name = Fields.DunningMessageCode, Id = Index.DunningMessageCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DunningMessageCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DunningMessageDesc", ResourceType = typeof(DunningMessagesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets CurrentMessage 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentMessage", ResourceType = typeof(DunningMessagesResx))]
        [ViewField(Name = Fields.CurrentMessage, Id = Index.CurrentMessage, FieldType = EntityFieldType.Char, Size = 45)]
        public string CurrentMessage { get; set; }

        /// <summary>
        /// Gets or sets Period1Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period1Message", ResourceType = typeof(DunningMessagesResx))]
        [ViewField(Name = Fields.Period1Message, Id = Index.Period1Message, FieldType = EntityFieldType.Char, Size = 45)]
        public string Period1Message { get; set; }

        /// <summary>
        /// Gets or sets Period2Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period2Message", ResourceType = typeof(DunningMessagesResx))]
        [ViewField(Name = Fields.Period2Message, Id = Index.Period2Message, FieldType = EntityFieldType.Char, Size = 45)]
        public string Period2Message { get; set; }

        /// <summary>
        /// Gets or sets Period3Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period3Message", ResourceType = typeof(DunningMessagesResx))]
        [ViewField(Name = Fields.Period3Message, Id = Index.Period3Message, FieldType = EntityFieldType.Char, Size = 45)]
        public string Period3Message { get; set; }

        /// <summary>
        /// Gets or sets OverPeriod3Message 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OverPeriod3Message", ResourceType = typeof(DunningMessagesResx))]
        [ViewField(Name = Fields.OverPeriod3Message, Id = Index.OverPeriod3Message, FieldType = EntityFieldType.Char, Size = 45)]
        public string OverPeriod3Message { get; set; }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }
    }
}
