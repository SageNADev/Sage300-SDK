// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.GLIntegration;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using ARGLIntegrationResx = Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms.GLIntegrationResx;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class for GL Integration Options
    /// </summary>
    public partial class GLIntegrationOptions : BaseGLIntegrationOptions
    {
        /// <summary>
        /// Gets or sets Last Receipt Posting Sequence to GL 
        /// </summary>
        [ViewField(Name = Fields.LastReceiptPostingSeqToGL, Id = Index.LastReceiptPostingSeqToGL, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal LastReceiptPostingSeqToGL { get; set; }

        /// <summary>
        /// Gets or sets Last Refund Posting Sequence to GL 
        /// </summary>
        [ViewField(Name = Fields.LastRefundPostingSeqToGL, Id = Index.LastRefundPostingSeqToGL, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal LastRefundPostingSeqToGL { get; set; }

        /// <summary>
        /// Gets or sets GL Source Code Payment Received 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentReceived", ResourceType = typeof(ARGLIntegrationResx))]
        [ViewField(Name = Fields.GLSrcCodePaymentReceived, Id = Index.GLSrcCodePaymentReceived, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string GLSrcCodePaymentReceived { get; set; }

        /// <summary>
        /// Gets or sets GL Source Code Write Off 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WriteOff", ResourceType = typeof(ARGLIntegrationResx))]
        [ViewField(Name = Fields.GLSrcCodeWriteOff, Id = Index.GLSrcCodeWriteOff, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string GLSrcCodeWriteOff { get; set; }

        /// <summary>
        /// Gets or sets GL Source Code Unapplied Cash 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnappliedCash", ResourceType = typeof(ARGLIntegrationResx))]
        [ViewField(Name = Fields.GLSrcCodeUnappliedCash, Id = Index.GLSrcCodeUnappliedCash, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string GLSrcCodeUnappliedCash { get; set; }

        /// <summary>
        /// Gets or sets GL Source Code Refund 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Refund", ResourceType = typeof(ARGLIntegrationResx))]
        [ViewField(Name = Fields.GLSrcCodeRefund, Id = Index.GLSrcCodeRefund, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string GLSrcCodeRefund { get; set; }

        /// <summary>
        /// Gets or sets GL Source Code Refund Reversal 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RefundReversal", ResourceType = typeof(ARGLIntegrationResx))]
        [ViewField(Name = Fields.GLSrcCodeRefundReversal, Id = Index.GLSrcCodeRefundReversal, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string GLSrcCodeRefundReversal { get; set; }

    }
}
