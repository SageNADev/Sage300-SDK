// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Printed = Sage.CA.SBS.ERP.Sage300.Common.Models.Enums.InvoiceEntry.Printed;
using ProcessCommand = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.ProcessCommand;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Model for Receipt and Adjustment Batches (rotoview AR0041 - ARBTA).    
    /// </summary>
    public partial class ReceiptEntryBatch : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptAdjustmentHeader"/> class
        /// </summary>
        public ReceiptEntryBatch()
        {
            ReceiptAdjustmentHeader = new ReceiptAdjustmentHeader();
            ReceiptAdjustments = new EnumerableResponse<ReceiptAdjustmentHeader>();
            BatchType = BatchType.Entered;
            BatchStatus = BatchStatus.Open;
            DepositSlipPrinted = DepositSlipPrinted.No;
            BankRateOperator = BankRateOperator.Multiply;
            BatchTypeClass = BatchTypeClass.Adjustment;
            BatchPrintedFlag = BatchPrintedFlag.No;
            BankRateOverridden = BatchPrintedFlag.No;
            ProcessCommand = ProcessCommand.CreateNewDepositSlip;
            PostReceiptsandAdjustment = new PostReceiptsandAdjustment();
        }

        /// <summary>
        /// Gets or sets Entries related to posting an Adjustment.
        /// </summary>
        public PostReceiptsandAdjustment PostReceiptsandAdjustment { get; set; }

        /// <summary>
        /// Gets or sets PaymentType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.PaymentType, Id = Index.PaymentType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PaymentType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Conversion of BatchDate into DateTime 
        /// </summary>
        public DateTime BatchDateTime
        {
            get { return BatchDate; }
        }
        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Receipt Adjustment Header related to the Receipt Entry Batch
        /// </summary>
        public ReceiptAdjustmentHeader ReceiptAdjustmentHeader { get; set; }
        
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptAdjustmentHeader> ReceiptAdjustments { get; set; }

        /// <summary>
        /// Gets or sets NumberofEntries 
        /// </summary>
        [Display(Name = "NumberofEntries", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofEntries, Id = Index.NumberofEntries, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofEntries { get; set; }

        /// <summary>
        /// Gets or sets BatchTotal 
        /// </summary>
        [Display(Name = "TotalAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchTotal, Id = Index.BatchTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BatchTotal { get; set; }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchType BatchType { get; set; }

        /// <summary>
        /// To get the string of Batch Type Enum
        /// </summary>
        /// <value>Batch Type</value>
        [Display(Name = "Type", ResourceType = typeof(ARCommonResx))]
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(BatchType); }
        }

        /// <summary>
        /// Gets or sets BatchStatus 
        /// </summary>
        [Display(Name = "BatchStatus", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchStatus, Id = Index.BatchStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchStatus BatchStatus { get; set; }

        /// <summary>
        /// To get the string of BatchStatus Enum
        /// </summary>
        /// <value>BatchStatus</value>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(BatchStatus); }
        }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Bank", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets DepositSlipPrinted 
        /// </summary>
        [Display(Name = "DepositSlipPrinted", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DepositSlipPrinted, Id = Index.DepositSlipPrinted, FieldType = EntityFieldType.Int, Size = 2)]
        public DepositSlipPrinted DepositSlipPrinted { get; set; }

        /// <summary>
        /// To get the string of DepositSlipPrinted Enum
        /// </summary>
        /// <value>DepositSlipPrinted</value>
        public string Printed
        {
            get { return EnumUtility.GetStringValue(DepositSlipPrinted); }
        }

        /// <summary>
        /// Gets or sets DefaultBankCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultCurrency", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DefaultBankCurrency, Id = Index.DefaultBankCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string DefaultBankCurrency { get; set; }

        /// Gets or sets BankCurrencyCode 

        [StringLength(3, ErrorMessageResourceName = "MaxLength",
            ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(ARCommonResx))]
        public string BankCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets BankRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankRateDate, Id = Index.BankRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BankRateDate { get; set; }

        /// <summary>
        /// Conversion of BankRateDate into DateTime 
        /// </summary>
        public DateTime RateDateBank
        {
            get { return BankRateDate; }
        }
        /// <summary>
        /// Gets or sets LastEntryNumber 
        /// </summary>
        [ViewField(Name = Fields.LastEntryNumber, Id = Index.LastEntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal LastEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets BankRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankRateType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BankRateType, Id = Index.BankRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BankRateType { get; set; }

        /// <summary>
        /// Gets or sets BankExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.BankExchangeRate, Id = Index.BankExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal BankExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets DepositNumber 
        /// </summary>
        [Display(Name = "DepositNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DepositNumber, Id = Index.DepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal DepositNumber { get; set; }

        /// <summary>
        /// Gets or sets DepositSerialNumber 
        /// </summary>
        [ViewField(Name = Fields.DepositSerialNumber, Id = Index.DepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long DepositSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets FuncAdjustmentAmount 
        /// </summary>
        [ViewField(Name = Fields.FuncAdjustmentAmount, Id = Index.FuncAdjustmentAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAdjustmentAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncAppliedDocAmount 
        /// </summary>
        [ViewField(Name = Fields.FuncAppliedDocAmount, Id = Index.FuncAppliedDocAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAppliedDocAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncBatchTotal 
        /// </summary>
        [ViewField(Name = Fields.FuncBatchTotal, Id = Index.FuncBatchTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncBatchTotal { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [Display(Name = "PostingSequence", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets NumberofErrors 
        /// </summary>
        [Display(Name = "NumberofErrors", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofErrors, Id = Index.NumberofErrors, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NumberofErrors { get; set; }

        /// <summary>
        /// Gets or sets DateLastEdited 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastEdited", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DateLastEdited, Id = Index.DateLastEdited, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastEdited { get; set; }

        /// <summary>
        /// Conversion of DateLastEdited into DateTime 
        /// </summary>
        public DateTime LastEditedDate
        {
            get { return DateLastEdited; }

        }
        /// <summary>
        /// Gets or sets BatchTypeClass 
        /// </summary>
        [ViewField(Name = Fields.BatchTypeClass, Id = Index.BatchTypeClass, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchTypeClass BatchTypeClass { get; set; }

        /// <summary>
        /// To get the string of BatchTypeClass Enum
        /// </summary>
        /// <value>BatchTypeClass</value>
        public string TypeClass
        {
            get { return EnumUtility.GetStringValue(BatchTypeClass); }
        }

        /// <summary>
        /// Gets or sets BatchPrintedFlag 
        /// </summary>
        [ViewField(Name = Fields.BatchPrintedFlag, Id = Index.BatchPrintedFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchPrintedFlag BatchPrintedFlag { get; set; }

        /// <summary>
        /// To get the string of BatchPrintedFlag Enum
        /// </summary>
        /// <value>BatchPrintedFlag</value>
        public string PrintedFlag
        {
            get { return EnumUtility.GetStringValue(BatchPrintedFlag); }
        }

        /// <summary>
        /// Gets or sets BankRateOperator 
        /// </summary>
        [ViewField(Name = Fields.BankRateOperator, Id = Index.BankRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public BankRateOperator BankRateOperator { get; set; }

        /// <summary>
        /// To get the string of BankRateOperator Enum
        /// </summary>
        /// <value>BankRateOperator</value>
        public string RateOperator
        {
            get { return EnumUtility.GetStringValue(BankRateOperator); }
        }

        /// <summary>
        /// Gets or sets BankRateOverridden 
        /// </summary>
        [ViewField(Name = Fields.BankRateOverridden, Id = Index.BankRateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchPrintedFlag BankRateOverridden { get; set; }

        /// <summary>
        /// To get the string of BankRateOverridden Enum
        /// </summary>
        /// <value>BankRateOverridden</value>
        public string RateOverridden
        {
            get { return EnumUtility.GetStringValue(BankRateOverridden); }
        }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand 
        /// </summary>
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommand ProcessCommand { get; set; }

        /// <summary>
        /// To get the string of ProcessCommand Enum
        /// </summary>
        /// <value>ProcessCommand</value>
        public string Command
        {
            get { return EnumUtility.GetStringValue(ProcessCommand); }
        }

        /// <summary>
        /// Gets or sets DepositDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DepositDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DepositDate, Id = Index.DepositDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DepositDate { get; set; }

        /// <summary>
        /// Conversion of DepositDate into DateTime 
        /// </summary>
        public DateTime DateDeposit
        {
            get { return DateUtil.GetDate(DepositDate, DateUtil.GetMinDate()); }
        }

        /// <summary>
        /// Gets or sets DepositComment 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DepositComment, Id = Index.DepositComment, FieldType = EntityFieldType.Char, Size = 60)]
        public string DepositComment { get; set; }

        /// <summary>
        /// Gets or sets NumberofReapplies 
        /// </summary>
        [ViewField(Name = Fields.NumberofReapplies, Id = Index.NumberofReapplies, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofReapplies { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        public short SessionWarnDays { get; set; }

        //Added Extra Property for ReadyToPost in AdjustmentBatchList
        /// <summary>
        /// Gets or sets ReadyToPost
        /// </summary>
        [Display(Name = "ReadyToPost", ResourceType = typeof(ARCommonResx))]
        public Printed ReadyToPost { get; set; }


        #region UI

        /// <summary>
        /// Gets or sets HandleLockedFiscalPeriod
        /// </summary>
        public string HandleLockedFiscalPeriod { get; set; }

        #endregion

        #region Security

        /// <summary>
        /// Gets or sets GL module Active
        /// </summary>
        public bool IsGlActive { get; set; }

        /// <summary>
        /// Gets or sets YP module Active
        /// </summary>
        public bool IsYpActive { get; set; }

        /// <summary>
        /// Gets or sets PM module Active
        /// </summary>
        public bool IsPMActive { get; set; }

        /// <summary>
        /// Gets or sets IC module Active
        /// </summary>
        public bool IsICActive { get; set; }

        /// <summary>
        /// Gets or sets PO module Active
        /// </summary>
        public bool IsPOActive { get; set; }

        /// <summary>
        /// Gets or sets Optional Field License detail
        /// </summary>
        public bool HaveOptFldLicense { get; set; }

        #endregion
    }
}
