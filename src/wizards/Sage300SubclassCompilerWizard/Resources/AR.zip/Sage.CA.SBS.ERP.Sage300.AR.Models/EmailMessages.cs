// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class EmailMessages : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public EmailMessages()
        {
            Status = Status.Active;
        }
        /// <summary>
        /// Gets or sets MessageType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "MessageType", ResourceType = typeof (EmailMessagesResx))]
        [ViewField(Name = Fields.MessageType, Id = Index.MessageType, FieldType = EntityFieldType.Int, Size = 2)]
        public MessageType MessageType { get; set; }

        /// <summary>
        /// Gets or sets MessageID 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "MessageID",ResourceType = typeof(EmailMessagesResx))]
        [ViewField(Name = Fields.MessageID, Id = Index.MessageID, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string MessageID { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "MessageDesc", ResourceType = typeof(EmailMessagesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof (ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof (CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets EmailSubject 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EmailSubject", ResourceType = typeof(EmailMessagesResx))]
        [ViewField(Name = Fields.EmailSubject, Id = Index.EmailSubject, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailSubject { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText1of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText1Of10, Id = Index.EmailBodyText1Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText1Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText2of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText2Of10, Id = Index.EmailBodyText2Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText2Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText3of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText3Of10, Id = Index.EmailBodyText3Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText3Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText4of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText4Of10, Id = Index.EmailBodyText4Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText4Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText5of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText5Of10, Id = Index.EmailBodyText5Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText5Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText6of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText6Of10, Id = Index.EmailBodyText6Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText6Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText7of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText7Of10, Id = Index.EmailBodyText7Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText7Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText8of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText8Of10, Id = Index.EmailBodyText8Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText8Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText9of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText9Of10, Id = Index.EmailBodyText9Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText9Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBodyText10of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText10Of10, Id = Index.EmailBodyText10Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText10Of10 { get; set; }

        /// <summary>
        /// Gets or sets EmailBody 
        /// </summary>
        [StringLength(2500, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "EmailBody", ResourceType = typeof(EmailMessagesResx))]
        [ViewField(Name = Fields.EmailBody, Id = Index.EmailBody, FieldType = EntityFieldType.Char, Size = 2500)]
        public string EmailBody { get; set; }

        /// <summary>
        /// Gets string value of the MessageType enum
        /// </summary>       
        public string MessageTypeString
        {
            get { return EnumUtility.GetStringValue(MessageType); }
        }

   }
}
