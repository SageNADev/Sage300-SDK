// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Status = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Status;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for Customer
    /// </summary>
    public partial class Customer : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ShortName
        /// </summary>
        [Display(Name = "ShortName", ResourceType = typeof(ARCommonResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ShortName, Id = Index.ShortName, FieldType = EntityFieldType.Char, Size = 10)]
        public string ShortName { get; set; }

        /// <summary>
        /// Gets or sets GroupCode
        /// </summary>
        [Display(Name = "GroupCode", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets NationalAccount
        /// </summary>
        [Display(Name = "NationalAccount", ResourceType = typeof(ARCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.NationalAccount, Id = Index.NationalAccount, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccount { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [GridColumn]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }        

        /// <summary>
        /// Gets or sets InactiveDate
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets OnHold
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold OnHold { get; set; }

        /// <summary>
        /// Gets or sets StartDate
        /// </summary>
        [Display(Name = "StartDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.StartDate, Id = Index.StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StartDate { get; set; }

        /// <summary>
        /// Gets or sets CreditBureauNumber
        /// </summary>
        [Display(Name = "CreditBureauNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(9, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.CreditBureauNumber, Id = Index.CreditBureauNumber, FieldType = EntityFieldType.Char, Size = 9)]
        public string CreditBureauNumber { get; set; }

        /// <summary>
        /// Gets or sets CreditBureauRating
        /// </summary>
        [Display(Name = "CreditBureauRating", ResourceType = typeof(ARCommonResx))]
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.CreditBureauRating, Id = Index.CreditBureauRating, FieldType = EntityFieldType.Char, Size = 5)]
        public string CreditBureauRating { get; set; }

        /// <summary>
        /// Gets or sets CreditBureauDate
        /// </summary>
        [Display(Name = "CreditBureauDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.CreditBureauDate, Id = Index.CreditBureauDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? CreditBureauDate { get; set; }

        /// <summary>
        /// Gets or sets CustomerName
        /// </summary>
        [Display(Name = "CustomerName", ResourceType = typeof(ARCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.CustomerName, Id = Index.CustomerName, FieldType = EntityFieldType.Char, Size = 60)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1
        /// </summary>
        [Display(Name = "Address1", ResourceType = typeof(CustomersResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2
        /// </summary>
        [Display(Name = "Address2", ResourceType = typeof(CustomersResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3
        /// </summary>
        [Display(Name = "Address3", ResourceType = typeof(CustomersResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4
        /// </summary>
        [Display(Name = "Address4", ResourceType = typeof(CustomersResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [Display(Name = "City", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateOrProv
        /// </summary>
        [Display(Name = "StateProv", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.StateOrProv, Id = Index.StateOrProv, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateOrProv { get; set; }

        /// <summary>
        /// Gets or sets ZipOrPostalCode
        /// </summary>
        [Display(Name = "ZipPostalCode", ResourceType = typeof(ARCommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [Display(Name = "Country", ResourceType = typeof(ARCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets ContactName
        /// </summary>
        [Display(Name = "ContactName", ResourceType = typeof(CustomersResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        [Display(Name = "Phone", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets TerritoryCode
        /// </summary>
        [Display(Name = "TerritoryCode", ResourceType = typeof(CustomersResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.TerritoryCode, Id = Index.TerritoryCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TerritoryCode { get; set; }

        /// <summary>
        /// Gets or sets AccountSet
        /// </summary>
        [Display(Name = "AccountSet", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets AutocashProfile
        /// </summary>
        [Display(Name = "AutocashProfile", ResourceType = typeof(ARCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.AutocashProfile, Id = Index.AutocashProfile, FieldType = EntityFieldType.Char, Size = 6)]
        public string AutocashProfile { get; set; }

        /// <summary>
        /// Gets or sets BillingCycle
        /// </summary>
        [Display(Name = "BillingCycle", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.BillingCycle, Id = Index.BillingCycle, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillingCycle { get; set; }

        /// <summary>
        /// Gets or sets InterestProfile
        /// </summary>
        [Display(Name = "InterestProfile", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.InterestProfile, Id = Index.InterestProfile, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InterestProfile { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [Display(Name = "CurrencyCode", ResourceType = typeof(ARCommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets PrintStatements
        /// </summary>
        [Display(Name = "PrintStatements", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.PrintStatements, Id = Index.PrintStatements, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold PrintStatements { get; set; }

        /// <summary>
        /// Gets or sets AccountType
        /// </summary>
        [Display(Name = "AccountType", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.AccountType, Id = Index.AccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerGroupAccountType AccountType { get; set; }

        /// <summary>
        /// Gets or sets Terms
        /// </summary>
        [Display(Name = "Terms", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [Display(Name = "TaxGroup", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo1
        /// </summary>
        [Display(Name = "TaxRegistrationNo1", ResourceType = typeof(CustomersResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxRegistrationNo1, Id = Index.TaxRegistrationNo1, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo2
        /// </summary>
        [Display(Name = "TaxRegistrationNo2", ResourceType = typeof(CustomersResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxRegistrationNo2, Id = Index.TaxRegistrationNo2, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo3
        /// </summary>
        [Display(Name = "TaxRegistrationNo3", ResourceType = typeof(CustomersResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxRegistrationNo3, Id = Index.TaxRegistrationNo3, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo4
        /// </summary>
        [Display(Name = "TaxRegistrationNo4", ResourceType = typeof(CustomersResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxRegistrationNo4, Id = Index.TaxRegistrationNo4, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRegistrationNo5
        /// </summary>
        [Display(Name = "TaxRegistrationNo5", ResourceType = typeof(CustomersResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxRegistrationNo5, Id = Index.TaxRegistrationNo5, FieldType = EntityFieldType.Char, Size = 20)]
        public string TaxRegistrationNo5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode1
        /// </summary>
        [Display(Name = "TaxClassCode1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode1, Id = Index.TaxClassCode1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode2
        /// </summary>
        [Display(Name = "TaxClassCode2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode2, Id = Index.TaxClassCode2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode3
        /// </summary>
        [Display(Name = "TaxClassCode3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode3, Id = Index.TaxClassCode3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode4
        /// </summary>
        [Display(Name = "TaxClassCode4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode4, Id = Index.TaxClassCode4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode5
        /// </summary>
        [Display(Name = "TaxClassCode5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode5, Id = Index.TaxClassCode5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode5 { get; set; }

        /// <summary>
        /// Gets or sets CreditLimitCustCurr
        /// </summary>
        [Display(Name = "CreditLimitCustCurr", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.CreditLimitCustCurr, Id = Index.CreditLimitCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimitCustCurr { get; set; }

        /// <summary>
        /// Gets or sets BalanceDueinCustCurr
        /// </summary>
        [Display(Name = "BalanceDueinCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BalanceDueinCustCurr, Id = Index.BalanceDueinCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceDueinCustCurr { get; set; }

        /// <summary>
        /// Gets or sets BalanceDueinFuncCurr
        /// </summary>
        [Display(Name = "BalanceDueinFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BalanceDueinFuncCurr, Id = Index.BalanceDueinFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BalanceDueinFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets DateofLastStatement
        /// </summary>
        [Display(Name = "DateofLastStatement", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastStatement, Id = Index.DateofLastStatement, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastStatement { get; set; }

        /// <summary>
        /// Gets or sets LastStatementTotalCustCurr
        /// </summary>
        [Display(Name = "LastStatementTotalCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastStatementTotalCustCurr, Id = Index.LastStatementTotalCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastStatementTotalCustCurr { get; set; }

        /// <summary>
        /// Gets or sets DateofLastBalFwdStatement
        /// </summary>
        [Display(Name = "DateofLastBalFwdStatement", ResourceType = typeof(CustomersResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastBalFwdStatement, Id = Index.DateofLastBalFwdStatement, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateofLastBalFwdStatement { get; set; }

        /// <summary>
        /// Gets or sets BeginningBalonLastStatement
        /// </summary>
        [Display(Name = "BeginningBalonLastStatement", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.BeginningBalonLastStatement, Id = Index.BeginningBalonLastStatement, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BeginningBalonLastStatement { get; set; }

        /// <summary>
        /// Gets or sets DateofLastRevaluation
        /// </summary>
        [Display(Name = "DateofLastRevaluation", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastRevaluation, Id = Index.DateofLastRevaluation, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastRevaluation { get; set; }

        /// <summary>
        /// Gets or sets LastRevaluationBalance
        /// </summary>
        [Display(Name = "LastRevaluationBalance", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.LastRevaluationBalance, Id = Index.LastRevaluationBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRevaluationBalance { get; set; }

        /// <summary>
        /// Gets or sets NumberofOpenDocuments
        /// </summary>
        [Display(Name = "NumberofOpenDocuments", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofOpenDocuments, Id = Index.NumberofOpenDocuments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofOpenDocuments { get; set; }

        /// <summary>
        /// Gets or sets NumberofPaidInvoices
        /// </summary>
        [Display(Name = "NumberofPaidInvoices", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofPaidInvoices, Id = Index.NumberofPaidInvoices, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPaidInvoices { get; set; }

        /// <summary>
        /// Gets or sets NumberofDaystoPay
        /// </summary>
        [Display(Name = "NumberofDaystoPay", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofDaystoPay, Id = Index.NumberofDaystoPay, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofDaystoPay { get; set; }

        /// <summary>
        /// Gets or sets DateofLargestInvoice
        /// </summary>
        [Display(Name = "DateofLargestInvoice", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLargestInvoice, Id = Index.DateofLargestInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets DateofHighestBalance
        /// </summary>
        [Display(Name = "DateofHighestBalance", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofHighestBalance, Id = Index.DateofHighestBalance, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofHighestBalance { get; set; }

        /// <summary>
        /// Gets or sets DateofLargestInvoiceLastYr
        /// </summary>
        [Display(Name = "DateofLargestInvoiceLastYr", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLargestInvoiceLastYr, Id = Index.DateofLargestInvoiceLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLargestInvoiceLastYr { get; set; }

        /// <summary>
        /// Gets or sets DateofHighestBalanceLastYr
        /// </summary>
        [Display(Name = "DateofHighestBalanceLastYr", ResourceType = typeof(CustomersResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofHighestBalanceLastYr, Id = Index.DateofHighestBalanceLastYr, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofHighestBalanceLastYr { get; set; }

        /// <summary>
        /// Gets or sets DateofLastActivity
        /// </summary>
        [Display(Name = "DateofLastActivity", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastActivity, Id = Index.DateofLastActivity, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastActivity { get; set; }

        /// <summary>
        /// Gets or sets DateofLastInvoice
        /// </summary>
        [Display(Name = "DateofLastInvoice", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastInvoice, Id = Index.DateofLastInvoice, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastInvoice { get; set; }

        /// <summary>
        /// Gets or sets DateofLastCreditNote
        /// </summary>
        [Display(Name = "DateofLastCreditNote", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastCreditNote, Id = Index.DateofLastCreditNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastCreditNote { get; set; }

        /// <summary>
        /// Gets or sets DateofLastDebitNote
        /// </summary>
        [Display(Name = "DateofLastDebitNote", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastDebitNote, Id = Index.DateofLastDebitNote, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastDebitNote { get; set; }

        /// <summary>
        /// Gets or sets DateofLastReceipt
        /// </summary>
        [Display(Name = "DateofLastReceipt", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastReceipt, Id = Index.DateofLastReceipt, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastReceipt { get; set; }

        /// <summary>
        /// Gets or sets DateofLastDiscount
        /// </summary>
        [Display(Name = "DateofLastDiscount", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastDiscount, Id = Index.DateofLastDiscount, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastDiscount { get; set; }

        /// <summary>
        /// Gets or sets DateofLastAdjustment
        /// </summary>
        [Display(Name = "DateofLastAdjustment", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastAdjustment, Id = Index.DateofLastAdjustment, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastAdjustment { get; set; }

        /// <summary>
        /// Gets or sets DateofLastWriteOff
        /// </summary>
        [Display(Name = "DateofLastWriteOff", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastWriteOff, Id = Index.DateofLastWriteOff, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastWriteOff { get; set; }

        /// <summary>
        /// Gets or sets DateofLastReturnedCheck
        /// </summary>
        [Display(Name = "DateofLargestInvoice", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastReturnedCheck, Id = Index.DateofLastReturnedCheck, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastReturnedCheck { get; set; }

        /// <summary>
        /// Gets or sets DateofLastInterestCharge
        /// </summary>
        [Display(Name = "DateofLastInterestCharge", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastInterestCharge, Id = Index.DateofLastInterestCharge, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastInterestCharge { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceNumber
        /// </summary>
        [Display(Name = "LargestInvoiceNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LargestInvoiceNumber, Id = Index.LargestInvoiceNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string LargestInvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceNumberLastYr
        /// </summary>
        [Display(Name = "LargestInvoiceNumberLastYr", ResourceType = typeof(ARCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LargestInvoiceNumberLastYr, Id = Index.LargestInvoiceNumberLastYr, FieldType = EntityFieldType.Char, Size = 22)]
        public string LargestInvoiceNumberLastYr { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceCustCurr
        /// </summary>
        [Display(Name = "LargestInvoiceCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LargestInvoiceCustCurr, Id = Index.LargestInvoiceCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceCustCurr { get; set; }

        /// <summary>
        /// Gets or sets HighestBalanceCustCurr
        /// </summary>
        [Display(Name = "HighestBalanceCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.HighestBalanceCustCurr, Id = Index.HighestBalanceCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LgstInvLastYrCustCurr
        /// </summary>
        [Display(Name = "LgstInvLastYrCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LgstInvLastYrCustCurr, Id = Index.LgstInvLastYrCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LgstInvLastYrCustCurr { get; set; }

        /// <summary>
        /// Gets or sets HighBalLastYrCustCurr
        /// </summary>
        [Display(Name = "HighBalLastYrCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.HighBalLastYrCustCurr, Id = Index.HighBalLastYrCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYrCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmtCustCurr
        /// </summary>
        [Display(Name = "LastInvoiceAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastInvoiceAmtCustCurr, Id = Index.LastInvoiceAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastCrNoteAmtCustCurr
        /// </summary>
        [Display(Name = "LastCrNoteAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastCrNoteAmtCustCurr, Id = Index.LastCrNoteAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDrNoteAmtCustCurr
        /// </summary>
        [Display(Name = "LastDrNoteAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastDrNoteAmtCustCurr, Id = Index.LastDrNoteAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastReceiptCustCurr
        /// </summary>
        [Display(Name = "LastReceiptCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastReceiptCustCurr, Id = Index.LastReceiptCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastReceiptCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDiscountAmtCustCurr
        /// </summary>
        [Display(Name = "LastDiscountAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastDiscountAmtCustCurr, Id = Index.LastDiscountAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastAdjAmtCustCurr
        /// </summary>
        [Display(Name = "LastAdjAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastAdjAmtCustCurr, Id = Index.LastAdjAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastWriteOffAmtCustCurr
        /// </summary>
        [Display(Name = "LastWriteOffAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastWriteOffAmtCustCurr, Id = Index.LastWriteOffAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastWriteOffAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastRetdChkAmtCustCurr
        /// </summary>
        [Display(Name = "LastRetdChkAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastRetdChkAmtCustCurr, Id = Index.LastRetdChkAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRetdChkAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastIntChargeCustCurr
        /// </summary>
        [Display(Name = "LastIntChargeCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastIntChargeCustCurr, Id = Index.LastIntChargeCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastIntChargeCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceFuncCurr
        /// </summary>
        [Display(Name = "LargestInvoiceFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LargestInvoiceFuncCurr, Id = Index.LargestInvoiceFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LargestInvoiceFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets HighestBalanceFuncCurr
        /// </summary>
        [Display(Name = "HighestBalanceFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.HighestBalanceFuncCurr, Id = Index.HighestBalanceFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighestBalanceFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LgstInvLastYrFuncCurr
        /// </summary>
        [Display(Name = "LgstInvLastYrFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LgstInvLastYrFuncCurr, Id = Index.LgstInvLastYrFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LgstInvLastYrFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets HighBalLastYrFuncCurr
        /// </summary>
        [Display(Name = "HighBalLastYrFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.HighBalLastYrFuncCurr, Id = Index.HighBalLastYrFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal HighBalLastYrFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastInvoiceAmtFuncCurr
        /// </summary>
        [Display(Name = "LastInvoiceAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastInvoiceAmtFuncCurr, Id = Index.LastInvoiceAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastInvoiceAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastCrNoteAmtFuncCurr
        /// </summary>
        [Display(Name = "LastCrNoteAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastCrNoteAmtFuncCurr, Id = Index.LastCrNoteAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastCrNoteAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDrNoteAmtFuncCurr
        /// </summary>
        [Display(Name = "LastDrNoteAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastDrNoteAmtFuncCurr, Id = Index.LastDrNoteAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDrNoteAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastReceiptFuncCurr
        /// </summary>
        [Display(Name = "LastReceiptFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastReceiptFuncCurr, Id = Index.LastReceiptFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastReceiptFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastDiscountAmtFuncCurr
        /// </summary>
        [Display(Name = "LastDiscountAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastDiscountAmtFuncCurr, Id = Index.LastDiscountAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastDiscountAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastAdjAmtFuncCurr
        /// </summary>
        [Display(Name = "LastAdjAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastAdjAmtFuncCurr, Id = Index.LastAdjAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAdjAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastWriteOffAmtFuncCurr
        /// </summary>
        [Display(Name = "LastWriteOffAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastWriteOffAmtFuncCurr, Id = Index.LastWriteOffAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastWriteOffAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastRetdChkAmtFuncCurr
        /// </summary>
        [Display(Name = "LastRetdChkAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastRetdChkAmtFuncCurr, Id = Index.LastRetdChkAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRetdChkAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets LastIntChargeFuncCurr
        /// </summary>
        [Display(Name = "LastIntChargeFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastIntChargeFuncCurr, Id = Index.LastIntChargeFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastIntChargeFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1
        /// </summary>
        [Display(Name = "Salesperson1", ResourceType = typeof(ARCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2
        /// </summary>
        [Display(Name = "Salesperson2", ResourceType = typeof(ARCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3
        /// </summary>
        [Display(Name = "Salesperson3", ResourceType = typeof(ARCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4
        /// </summary>
        [Display(Name = "Salesperson4", ResourceType = typeof(ARCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5
        /// </summary>
        [Display(Name = "Salesperson5", ResourceType = typeof(ARCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage1
        /// </summary>
        [Display(Name = "SalesSplitPercentage1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage1, Id = Index.SalesSplitPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage2
        /// </summary>
        [Display(Name = "SalesSplitPercentage2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage2, Id = Index.SalesSplitPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage3
        /// </summary>
        [Display(Name = "SalesSplitPercentage3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage3, Id = Index.SalesSplitPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage4
        /// </summary>
        [Display(Name = "SalesSplitPercentage4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage4, Id = Index.SalesSplitPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage5
        /// </summary>
        [Display(Name = "SalesSplitPercentage5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage5, Id = Index.SalesSplitPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets AverageDaysToPay
        /// </summary>
        [Display(Name = "AverageDaysToPay", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AverageDaysToPay, Id = Index.AverageDaysToPay, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 1)]
        public decimal AverageDaysToPay { get; set; }

        /// <summary>
        /// Gets or sets CustomerPriceList
        /// </summary>
        [Display(Name = "CustomerPriceList", ResourceType = typeof(ARCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerPriceList, Id = Index.CustomerPriceList, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CustomerPriceList { get; set; }

        /// <summary>
        /// Gets or sets CustomerDiscountType
        /// </summary>
        [Display(Name = "CustomerDiscountType", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.CustomerDiscountType, Id = Index.CustomerDiscountType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerDiscountType CustomerDiscountType { get; set; }

        /// <summary>
        /// Gets or sets AmountPastDue
        /// </summary>
        [Display(Name = "AmountPastDue", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.AmountPastDue, Id = Index.AmountPastDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountPastDue { get; set; }

        /// <summary>
        /// Gets or sets ContactsEmail
        /// </summary>
        [Display(Name = "ContactsEmail", ResourceType = typeof(CustomersResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactsEmail, Id = Index.ContactsEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactsEmail { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [Display(Name = "Email", ResourceType = typeof(ARCommonResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets WebSite
        /// </summary>
        [Display(Name = "WebSite", ResourceType = typeof(ARCommonResx))]
        [StringLength(100, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.WebSite, Id = Index.WebSite, FieldType = EntityFieldType.Char, Size = 100)]
        public string WebSite { get; set; }

        /// <summary>
        /// Gets or sets BillingMethod
        /// </summary>
        [Display(Name = "BillingMethod", ResourceType = typeof(CustomersResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillingMethod, Id = Index.BillingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public int BillingMethod { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode
        /// </summary>
        [Display(Name = "PaymentCode", ResourceType = typeof(ARCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets FreeOnBoard
        /// </summary>
        [Display(Name = "FreeOnBoard", ResourceType = typeof(CustomersResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FreeOnBoard, Id = Index.FreeOnBoard, FieldType = EntityFieldType.Char, Size = 60)]
        public string FreeOnBoard { get; set; }

        /// <summary>
        /// Gets or sets ShipViaCode
        /// </summary>
        [Display(Name = "ShipViaCode", ResourceType = typeof(CustomersResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaCode, Id = Index.ShipViaCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipViaCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaDescription
        /// </summary>
        [Display(Name = "ShipViaDescription", ResourceType = typeof(CustomersResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaDescription, Id = Index.ShipViaDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaDescription { get; set; }

        /// <summary>
        /// Gets or sets DeliveryMethod
        /// </summary>
        [Display(Name = "DeliveryMethod", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DeliveryMethod, Id = Index.DeliveryMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DeliveryMethod DeliveryMethod { get; set; }

        /// <summary>
        /// Gets or sets PrimaryShipToLocation
        /// </summary>
        [Display(Name = "PrimaryShipToLocation", ResourceType = typeof(CustomersResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PrimaryShipToLocation, Id = Index.PrimaryShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string PrimaryShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets ContactsPhone
        /// </summary>
        [Display(Name = "ContactsPhone", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.ContactsPhone, Id = Index.ContactsPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactsFax
        /// </summary>
        [Display(Name = "ContactsFax", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.ContactsFax, Id = Index.ContactsFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactsFax { get; set; }

        /// <summary>
        /// Gets or sets AllowPartialShipments
        /// </summary>
        [Display(Name = "AllowPartialShipments", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.AllowPartialShipments, Id = Index.AllowPartialShipments, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold AllowPartialShipments { get; set; }

        /// <summary>
        /// Gets or sets AllowWebStoreShopping
        /// </summary>
        [Display(Name = "AllowWebStoreShopping", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.AllowWebStoreShopping, Id = Index.AllowWebStoreShopping, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold AllowWebStoreShopping { get; set; }

        /// <summary>
        /// Gets or sets PercentRetained
        /// </summary>
        [Display(Name = "PercentRetained", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PercentRetained, Id = Index.PercentRetained, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal PercentRetained { get; set; }

        /// <summary>
        /// Gets or sets DaysRetained
        /// </summary>
        [Display(Name = "DaysRetained", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.DaysRetained, Id = Index.DaysRetained, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysRetained { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode
        /// </summary>
        [Display(Name = "RetainageTermsCode", ResourceType = typeof(CustomersResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets AmountRetainedCustCurr
        /// </summary>
        [Display(Name = "AmountRetainedCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountRetainedCustCurr, Id = Index.AmountRetainedCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountRetainedCustCurr { get; set; }

        /// <summary>
        /// Gets or sets AmountRetainedFuncCurr
        /// </summary>
        [Display(Name = "AmountRetainedFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountRetainedFuncCurr, Id = Index.AmountRetainedFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountRetainedFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CustGrpProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets NumberofOpenPrepayments
        /// </summary>
        [Display(Name = "NumberofOpenPrepayments", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.NumberofOpenPrepayments, Id = Index.NumberofOpenPrepayments, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofOpenPrepayments { get; set; }

        /// <summary>
        /// Gets or sets AmountPrepaidCustCurr
        /// </summary>
        [Display(Name = "AmountPrepaidCustCurr", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.AmountPrepaidCustCurr, Id = Index.AmountPrepaidCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountPrepaidCustCurr { get; set; }

        /// <summary>
        /// Gets or sets AmountPrepaidFuncCurr
        /// </summary>
        [Display(Name = "AmountPrepaidFuncCurr", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.AmountPrepaidFuncCurr, Id = Index.AmountPrepaidFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountPrepaidFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets DateofLastRefund
        /// </summary>
        [Display(Name = "DateofLastRefund", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateofLastRefund, Id = Index.DateofLastRefund, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateofLastRefund { get; set; }

        /// <summary>
        /// Gets or sets LastRefundAmtCustCurr
        /// </summary>
        [Display(Name = "LastRefundAmtCustCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastRefundAmtCustCurr, Id = Index.LastRefundAmtCustCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRefundAmtCustCurr { get; set; }

        /// <summary>
        /// Gets or sets LastRefundAmtFuncCurr
        /// </summary>
        [Display(Name = "LastRefundAmtFuncCurr", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastRefundAmtFuncCurr, Id = Index.LastRefundAmtFuncCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastRefundAmtFuncCurr { get; set; }

        /// <summary>
        /// Gets or sets CheckLanguage
        /// </summary>
        [Display(Name = "CheckLanguage", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckLanguage, Id = Index.CheckLanguage, FieldType = EntityFieldType.Char, Size = 3)]
        public CheckLanguage CheckLanguage { get; set; }

        /// <summary>
        /// Gets or sets NextClientUniqueID
        /// </summary>
        [Display(Name = "NextClientUniqueID", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.NextClientUniqueID, Id = Index.NextClientUniqueID, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextClientUniqueID { get; set; }

        /// <summary>
        /// Gets or sets InventoryLocation
        /// </summary>
        [Display(Name = "InventoryLocation", ResourceType = typeof(ARCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InventoryLocation, Id = Index.InventoryLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InventoryLocation { get; set; }

        /// <summary>
        /// Gets or sets CheckCreditLimit
        /// </summary>
        [Display(Name = "CheckCreditLimit", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckCreditLimit, Id = Index.CheckCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold CheckCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckOverdueAmounts
        /// </summary>
        [Display(Name = "CheckOverdueAmounts", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckOverdueAmounts, Id = Index.CheckOverdueAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold CheckOverdueAmounts { get; set; }

        /// <summary>
        /// Gets or sets DaysOverdue
        /// </summary>
        [Display(Name = "DaysOverdue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DaysOverdue, Id = Index.DaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets AmountOverdue
        /// </summary>
        [Display(Name = "AmountOverdue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountOverdue, Id = Index.AmountOverdue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOverdue { get; set; }

        /// <summary>
        /// Gets or sets AllowBackorderQuantities
        /// </summary>
        [Display(Name = "AllowBackorderQuantities", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.AllowBackorderQuantities, Id = Index.AllowBackorderQuantities, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold AllowBackorderQuantities { get; set; }

        /// <summary>
        /// Gets or sets CheckforDuplicatePOs
        /// </summary>
        [Display(Name = "CheckforDuplicatePOs", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.CheckforDuplicatePOs, Id = Index.CheckforDuplicatePOs, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckforDuplicatePOs CheckforDuplicatePOs { get; set; }

        /// <summary>
        /// Gets or sets SuppressIntegration
        /// </summary>
        [Display(Name = "SuppressIntegration", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.SuppressIntegration, Id = Index.SuppressIntegration, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SuppressIntegration { get; set; }

        /// <summary>
        /// Gets or sets AOrRVersion
        /// </summary>
        [Display(Name = "AOrRVersion", ResourceType = typeof(CustomersResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AOrRVersion, Id = Index.AOrRVersion, FieldType = EntityFieldType.Char, Size = 3)]
        public string AOrRVersion { get; set; }

        /// <summary>
        /// Gets or sets Database
        /// </summary>
        [Display(Name = "Database", ResourceType = typeof(CustomersResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Database, Id = Index.Database, FieldType = EntityFieldType.Char, Size = 6)]
        public string Database { get; set; }

        /// <summary>
        /// Gets or sets Mode
        /// </summary>
        [Display(Name = "Mode", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.Mode, Id = Index.Mode, FieldType = EntityFieldType.Int, Size = 2)]
        public Mode Mode { get; set; }

        /// <summary>
        /// Gets or sets SageBillingandPaymentCustomer
        /// </summary>
        [Display(Name = "SageBillingPaymentCustomer", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.SageBillingandPaymentCustomer, Id = Index.SageBillingandPaymentCustomer, FieldType = EntityFieldType.Int, Size = 2)]
        public OnHold SageBillingandPaymentCustomer { get; set; }

        /// <summary>
        /// Gets or sets BusinessRegistrationNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BusinessRegistrationNumber", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.BusinessRegistrationNumber, Id = Index.BusinessRegistrationNumber, FieldType = EntityFieldType.Char, Size = 30)]
        public string BusinessRegistrationNumber { get; set; }

        /// <summary>
        /// Gets or sets CRM Update Mode
        /// </summary>
        [Display(Name = "CRMUpdateMode", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.CRMUpdateMode, Id = Index.CRMUpdateMode, FieldType = EntityFieldType.Int, Size = 2)]
        public CRMUpdateMode CRMUpdateMode { get; set; }

        /// <summary>
        /// Gets or sets List of AR Customer contact form list
        /// </summary>
        /// <value>The recurring entries.</value>
        public EnumerableResponse<CustomerContactForm> CustomerContact { get; set; }

        /// <summary>
        /// Gets or sets List of AR Customer Optional Fields values
        /// </summary>
        /// <value>The recurring entries.</value>
        public EnumerableResponse<CustomerOptionalFieldValues> CustomerOptionalFieldValues { get; set; }

        /// <summary>
        /// Gets or Sets CreditCurrencyList
        /// </summary>
        public EnumerableResponse<CustGrpCurrency> CreditCurrencyList { get; set; }

        /// <summary>
        /// Gets and sets FunctionalCurrency(Added to get the Functional Currency Set in CS Company Profile)
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Fiscal Period Start  year
        /// </summary>
        public string StartYear { get; set; }

        /// <summary>
        /// Fiscal Period End year
        /// </summary>
        public string EndYear { get; set; }

        /// <summary>
        /// Fiscal Year
        /// </summary>
        [Display(Name = "FiscalYear", ResourceType = typeof(ARCommonResx))]
        public DateTime FiscalYear { get; set; }

        /// <summary>
        /// Fiscal Period
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(ARCommonResx))]
        public string FiscalPeriod { get; set; }

        #region Properties for finder

        /// <summary>
        /// Gets the status string
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets the on hold string
        /// </summary>
        public string OnHoldString
        {
            get { return EnumUtility.GetStringValue(OnHold); }
        }

        /// <summary>
        /// Gets the on hold string
        /// </summary>
        public string ModeString
        {
            get { return EnumUtility.GetStringValue(Mode); }
        }

        /// <summary>
        /// Gets the check for duplicate POs string
        /// </summary>
        public string CheckforDuplicatePOsString
        {
            get { return EnumUtility.GetStringValue(CheckforDuplicatePOs); }
        }

        /// <summary>
        /// Gets the check language string
        /// </summary>
        public string CheckLanguageString
        {
            get { return EnumUtility.GetStringValue(CheckLanguage); }
        }

        /// <summary>
        /// Gets the check language string
        /// </summary>
        public string CustomerDiscountTypeString
        {
            get { return EnumUtility.GetStringValue(CustomerDiscountType); }
        }

        /// <summary>
        /// Gets the account type string
        /// </summary>
        public string AccountTypeString
        {
            get { return EnumUtility.GetStringValue(AccountType); }
        }

        /// <summary>
        /// Gets the print statements string
        /// </summary>
        public string PrintStatementsString
        {
            get { return EnumUtility.GetStringValue(PrintStatements); }
        }

        /// <summary>
        /// Gets the delivery method string
        /// </summary>
        public string DeliveryMethodString
        {
            get { return EnumUtility.GetStringValue(DeliveryMethod); }
        }

        /// <summary>
        /// Gets the process command code string
        /// </summary>
        public string ProcessCommandCodeString
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
        /// Gets the check credit limit string
        /// </summary>
        public string CheckCreditLimitString
        {
            get { return EnumUtility.GetStringValue(CheckCreditLimit); }
        }

        /// <summary>
        /// Gets the check overdue amounts string
        /// </summary>
        public string CheckOverdueAmountsString
        {
            get { return EnumUtility.GetStringValue(CheckOverdueAmounts); }
        }

        /// <summary>
        /// Gets the allow partial shipments string
        /// </summary>
        public string AllowPartialShipmentsString
        {
            get { return EnumUtility.GetStringValue(AllowPartialShipments); }
        }

        /// <summary>
        /// Gets the allow webStore shopping string
        /// </summary>
        public string AllowWebStoreShoppingString
        {
            get { return EnumUtility.GetStringValue(AllowWebStoreShopping); }
        }

        /// <summary>
        /// Gets the allow backorder quantities string
        /// </summary>
        public string AllowBackorderQuantitiesString
        {
            get { return EnumUtility.GetStringValue(AllowBackorderQuantities); }
        }

        /// <summary>
        /// Gets the sage billing and payment customer string
        /// </summary>
        public string SageBillingandPaymentCustomerString
        {
            get { return EnumUtility.GetStringValue(SageBillingandPaymentCustomer); }
        }

        /// <summary>
        /// Gets suppress Integration String
        /// </summary>
        [Display(Name = "SuppressIntegration", ResourceType = typeof(CustomersResx))]
        public string SuppressIntegrationString
        {
            get
            {
                if (SuppressIntegration == false)
                {
                    return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.False);
                }
                return EnumUtility.GetStringValue(Common.Models.Enums.BooleanType.True);
            }
        }

        /// <summary>
        /// Gets or sets DeliveryMethodList
        /// </summary>
        public IEnumerable<CustomSelectList> DeliveryMethodList { get; set; }

        #endregion Properties for finder
    }

    /// <summary>
    /// Customer Sales Person (Class For Grid)
    /// </summary>
    public class CustomerSalesPerson : ModelBase
    {
        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets and Sets SalesPersonCode
        /// </summary>
        [Display(Name = "SalespersonCode", ResourceType = typeof(ARCommonResx))]
        public string SalesPersonCode { get; set; }

        /// <summary>
        ///  Gets and Sets SalesPersonName
        /// </summary>
        [Display(Name = "SalespersonName", ResourceType = typeof(ARCommonResx))]
        public string SalesPersonName { get; set; }

        /// <summary>
        /// Gets and Sets SalesPercentage
        /// </summary>
        [Display(Name = "Percentage", ResourceType = typeof(ARCommonResx))]
        public decimal SalesPercentage { get; set; }
    }

    /// <summary>
    /// Customer Tax Authority (Class For Grid)
    /// </summary>
    public class CustomerTaxAuthority : ModelBase
    {
        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets and Sets TaxAuthority
        /// </summary>
       [Display(Name = "TaxAuthority", ResourceType = typeof(ARCommonResx))]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets and Sets TaxAuthorityDescription
        /// </summary>
         [Display(Name = "TaxAuthorityDescription", ResourceType = typeof(CustomerInquiryResx))]
        public string TaxAuthorityDescription { get; set; }

        /// <summary>
        /// Gets and Sets TaxClass for the TaxAuthority
        /// </summary>
        [Display(Name = "TaxClass", ResourceType = typeof(ARCommonResx))]
        public int TaxClass { get; set; }

        /// <summary>
        /// Gets and Sets Registration Number
        /// </summary>
        [Display(Name = "RegistrationNumber", ResourceType = typeof(ARCommonResx))]
        public string RegistrationNumber { get; set; }

        /// <summary>
        /// Gets or Sets Tax Class Description
        /// </summary>
        [Display(Name = "TaxClassDescription", ResourceType = typeof(CustomerInquiryResx))]
        public string TaxClassDescription { get; set; }
    }

    /// <summary>
    ///  Customer Activity (Class For Grid)
    /// </summary>
    public class Activity : ModelBase
    {
        /// <summary>
        /// Gets or sets Vendor Number
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Currency Type
        /// </summary>
        public string CurrencyType { get; set; }

        /// <summary>
        /// Gets or sets Statistics
        /// </summary>
        public string Statistics { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        public decimal FunctionalCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets the customer currency amount
        /// </summary>
        public decimal CustomerCurrencyAmount { get; set; }

        /// <summary>
        /// Gets or sets Document Date
        /// </summary>
        [Display(Name = "DocumentDate", ResourceType = typeof(ARCommonResx))]
        public DateTime? DocumentDate { get; set; }
    }

    /// <summary>
    ///  Customer Active application to check
    /// </summary>
    public class CustomerActiveApplication : ModelBase
    {
        /// <summary>
        /// Checks YP Is Installed
        /// </summary>
        public bool IsYPEnabled { get; set; }

        /// <summary>
        /// Checks IC Is Installed
        /// </summary>
        public bool IsICEnabled { get; set; }

        /// <summary>
        /// Checks OE Is Installed
        /// </summary>
        public bool IsOEEnabled { get; set; }
    }

    /// <summary>
    ///  Customer Active application to check
    /// </summary>
    public class CustomerVerifyField : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets GroupCode
        /// </summary>
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets NationalAccount
        /// </summary>
        public string NationalAccount { get; set; }

        /// <summary>
        /// Gets or sets AccountSet
        /// </summary>
        public string AccountSet { get; set; }
    }

    /// <summary>
    ///  Customer Active application to check
    /// </summary>
    public class CustomerContactForm : ModelBase
    {
        public CustomerContactForm()
        {
            Columns = new Dictionary<string, string>();
        }
        public Dictionary<string, string> Columns { get; set; }
        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        public long LineNumber { get; set; }

        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        public string IDCUST { get; set; }

        /// <summary>
        /// Gets or sets contactId
        /// </summary>
        public string IDCONTACT { get; set; }

        /// <summary>
        /// Gets or sets Email address
        /// </summary>
        public string EMAIL { get; set; }
    }
}
