// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
     /// <summary>
     /// Contains list of DocumentPayment Constants
     /// </summary>
     public partial class DocumentPayment
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "AR0038";

          #region Properties
          /// <summary>
          /// Contains list of DocumentPayment Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CustomerNumber
               /// </summary>
               public const string CustomerNumber = "IDCUST";

               /// <summary>
               /// Property for DocumentNumber
               /// </summary>
               public const string DocumentNumber = "IDINVC";

               /// <summary>
               /// Property for PaymentNumber
               /// </summary>
               public const string PaymentNumber = "CNTPAYMNBR";

               /// <summary>
               /// Property for CheckReceiptNo
               /// </summary>
               public const string CheckReceiptNo = "IDRMIT";

               /// <summary>
               /// Property for PostingDate
               /// </summary>
               public const string PostingDate = "DATEBUS";

               /// <summary>
               /// Property for DocumentType
               /// </summary>
               public const string DocumentType = "TRANSTYPE";

               /// <summary>
               /// Property for SequenceNo
               /// </summary>
               public const string SequenceNo = "CNTSEQNCE";

               /// <summary>
               /// Property for DepositNumber
               /// </summary>
               public const string DepositNumber = "DEPSTNBR";

               /// <summary>
               /// Property for BatchNumber
               /// </summary>
               public const string BatchNumber = "CNTBTCH";

               /// <summary>
               /// Property for BatchDate
               /// </summary>
               public const string BatchDate = "DATEBTCH";

               /// <summary>
               /// Property for FuncReceiptAmount
               /// </summary>
               public const string FuncReceiptAmount = "AMTPAYMHC";

               /// <summary>
               /// Property for CustReceiptAmount
               /// </summary>
               public const string CustReceiptAmount = "AMTPAYMTC";

               /// <summary>
               /// Property for CurrencyCode
               /// </summary>
               public const string CurrencyCode = "CODECURN";

               /// <summary>
               /// Property for RateType
               /// </summary>
               public const string RateType = "IDRATETYPE";

               /// <summary>
               /// Property for ExchangeRate
               /// </summary>
               public const string ExchangeRate = "RATEEXCHHC";

               /// <summary>
               /// Property for RateOverridden
               /// </summary>
               public const string RateOverridden = "SWOVRDRATE";

               /// <summary>
               /// Property for BankCode
               /// </summary>
               public const string BankCode = "IDBANK";

               /// <summary>
               /// Property for TransactionType
               /// </summary>
               public const string TransactionType = "TRXTYPE";

               /// <summary>
               /// Property for ReferenceDocumentNo
               /// </summary>
               public const string ReferenceDocumentNo = "IDMEMOXREF";

               /// <summary>
               /// Property for DeleteInvoiceSwitch
               /// </summary>
               public const string DeleteInvoiceSwitch = "SWINVCDEL";

               /// <summary>
               /// Property for LastStatementDate
               /// </summary>
               public const string LastStatementDate = "DATELSTSTM";

               /// <summary>
               /// Property for PrepayApplytoDocNo
               /// </summary>
               public const string PrepayApplytoDocNo = "IDPREPAID";

               /// <summary>
               /// Property for RemittingCustomerNo
               /// </summary>
               public const string RemittingCustomerNo = "IDCUSTRMIT";

               /// <summary>
               /// Property for ReceiptDate
               /// </summary>
               public const string ReceiptDate = "DATERMIT";

               /// <summary>
               /// Property for EntryNumber
               /// </summary>
               public const string EntryNumber = "CNTITEM";

               /// <summary>
               /// Property for FiscalYear
               /// </summary>
               public const string FiscalYear = "FISCYR";

               /// <summary>
               /// Property for FiscalPeriod
               /// </summary>
               public const string FiscalPeriod = "FISCPER";

               /// <summary>
               /// Property for RateDate
               /// </summary>
               public const string RateDate = "RATEDATE";

               /// <summary>
               /// Property for RateOperator
               /// </summary>
               public const string RateOperator = "RATEOP";

               /// <summary>
               /// Property for StatementRunNo
               /// </summary>
               public const string StatementRunNo = "STMTSEQ";

               /// <summary>
               /// Property for PaymentCUID
               /// </summary>
               public const string PaymentCUID = "PYMCUID";

               /// <summary>
               /// Property for DepositSerialNumber
               /// </summary>
               public const string DepositSerialNumber = "DEPSEQ";

               /// <summary>
               /// Property for DepositLineNumber
               /// </summary>
               public const string DepositLineNumber = "DEPLINE";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of DocumentPayment Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CustomerNumber
               /// </summary>
               public const int CustomerNumber = 1;

               /// <summary>
               /// Property Indexer for DocumentNumber
               /// </summary>
               public const int DocumentNumber = 2;

               /// <summary>
               /// Property Indexer for PaymentNumber
               /// </summary>
               public const int PaymentNumber = 3;

               /// <summary>
               /// Property Indexer for CheckReceiptNo
               /// </summary>
               public const int CheckReceiptNo = 4;

               /// <summary>
               /// Property Indexer for PostingDate
               /// </summary>
               public const int PostingDate = 5;

               /// <summary>
               /// Property Indexer for DocumentType
               /// </summary>
               public const int DocumentType = 6;

               /// <summary>
               /// Property Indexer for SequenceNo
               /// </summary>
               public const int SequenceNo = 7;

               /// <summary>
               /// Property Indexer for DepositNumber
               /// </summary>
               public const int DepositNumber = 8;

               /// <summary>
               /// Property Indexer for BatchNumber
               /// </summary>
               public const int BatchNumber = 9;

               /// <summary>
               /// Property Indexer for BatchDate
               /// </summary>
               public const int BatchDate = 10;

               /// <summary>
               /// Property Indexer for FuncReceiptAmount
               /// </summary>
               public const int FuncReceiptAmount = 11;

               /// <summary>
               /// Property Indexer for CustReceiptAmount
               /// </summary>
               public const int CustReceiptAmount = 12;

               /// <summary>
               /// Property Indexer for CurrencyCode
               /// </summary>
               public const int CurrencyCode = 13;

               /// <summary>
               /// Property Indexer for RateType
               /// </summary>
               public const int RateType = 14;

               /// <summary>
               /// Property Indexer for ExchangeRate
               /// </summary>
               public const int ExchangeRate = 15;

               /// <summary>
               /// Property Indexer for RateOverridden
               /// </summary>
               public const int RateOverridden = 16;

               /// <summary>
               /// Property Indexer for BankCode
               /// </summary>
               public const int BankCode = 17;

               /// <summary>
               /// Property Indexer for TransactionType
               /// </summary>
               public const int TransactionType = 18;

               /// <summary>
               /// Property Indexer for ReferenceDocumentNo
               /// </summary>
               public const int ReferenceDocumentNo = 19;

               /// <summary>
               /// Property Indexer for DeleteInvoiceSwitch
               /// </summary>
               public const int DeleteInvoiceSwitch = 20;

               /// <summary>
               /// Property Indexer for LastStatementDate
               /// </summary>
               public const int LastStatementDate = 21;

               /// <summary>
               /// Property Indexer for PrepayApplytoDocNo
               /// </summary>
               public const int PrepayApplytoDocNo = 22;

               /// <summary>
               /// Property Indexer for RemittingCustomerNo
               /// </summary>
               public const int RemittingCustomerNo = 23;

               /// <summary>
               /// Property Indexer for ReceiptDate
               /// </summary>
               public const int ReceiptDate = 24;

               /// <summary>
               /// Property Indexer for EntryNumber
               /// </summary>
               public const int EntryNumber = 25;

               /// <summary>
               /// Property Indexer for FiscalYear
               /// </summary>
               public const int FiscalYear = 26;

               /// <summary>
               /// Property Indexer for FiscalPeriod
               /// </summary>
               public const int FiscalPeriod = 27;

               /// <summary>
               /// Property Indexer for RateDate
               /// </summary>
               public const int RateDate = 28;

               /// <summary>
               /// Property Indexer for RateOperator
               /// </summary>
               public const int RateOperator = 29;

               /// <summary>
               /// Property Indexer for StatementRunNo
               /// </summary>
               public const int StatementRunNo = 31;

               /// <summary>
               /// Property Indexer for PaymentCUID
               /// </summary>
               public const int PaymentCUID = 32;

               /// <summary>
               /// Property Indexer for DepositSerialNumber
               /// </summary>
               public const int DepositSerialNumber = 33;

               /// <summary>
               /// Property Indexer for DepositLineNumber
               /// </summary>
               public const int DepositLineNumber = 34;

          }
          #endregion

          #region Keys Properties
          /// <summary>
          /// Contains list of Document Payment Keys Constants, used for order by
          /// This Keys class is added for Order By in Customer Inquiry
          /// </summary>
          public class Keys
          {
              /// <summary>
              /// Property Indexer for PaymentNumber 
              /// </summary>
              public const int PaymentNumber = 3;

              /// <summary>
              /// Property Indexer for PostingDate 
              /// </summary>
              public const int PostingDate = 5;
          }
          #endregion
     }
}
