// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BillingCycles Constants 
    /// </summary>
    public partial class BillingCycle
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0014";

        /// <summary>
        /// Contains list of BillingCycles Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BillingCycleId 
            /// </summary>
            public const string BillingCycleId = "IDCYCL";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTVSW";

            /// <summary>
            /// Property for StatusString 
            /// Added for finder filter
            /// </summary>
            public const string StatusString = "ACTVSW";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINAC";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "LASTMNTN";

            /// <summary>
            /// Property for DateStatementsLastPrinted 
            /// </summary>
            public const string DateStatementsLastPrinted = "LASTSTMT";

            /// <summary>
            /// Property for DateIntInvoicesLastPosted 
            /// </summary>
            public const string DateIntInvoicesLastPosted = "LASTINTT";

            /// <summary>
            /// Property for BillingCycleFrequency 
            /// </summary>
            public const string BillingCycleFrequency = "DAYSCYCL";

            /// <summary>
            /// Property for RemitToName 
            /// </summary>
            public const string RemitToName = "NAME";

            /// <summary>
            /// Property for RemitToAddress1 
            /// </summary>
            public const string RemitToAddress1 = "STREET1";

            /// <summary>
            /// Property for RemitToAddress2 
            /// </summary>
            public const string RemitToAddress2 = "STREET2";

            /// <summary>
            /// Property for RemitToAddress3 
            /// </summary>
            public const string RemitToAddress3 = "STREET3";

            /// <summary>
            /// Property for RemitToAddress4 
            /// </summary>
            public const string RemitToAddress4 = "STREET4";

            /// <summary>
            /// Property for RemitToCity 
            /// </summary>
            public const string RemitToCity = "CITY";

            /// <summary>
            /// Property for RemitToStateOrProv 
            /// </summary>
            public const string RemitToStateOrProv = "STATE";

            /// <summary>
            /// Property for RemitToZipOrPostalCode 
            /// </summary>
            public const string RemitToZipOrPostalCode = "POSTCODE";

            /// <summary>
            /// Property for RemitToCountry 
            /// </summary>
            public const string RemitToCountry = "CNTYCODE";

            #endregion
        }

        /// <summary>
        /// Contains list of BillingCycles Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BillingCycleId 
            /// </summary>
            public const int BillingCycleId = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;

            /// <summary>
            /// Property Indexer for DateStatementsLastPrinted 
            /// </summary>
            public const int DateStatementsLastPrinted = 6;

            /// <summary>
            /// Property Indexer for DateIntInvoicesLastPosted 
            /// </summary>
            public const int DateIntInvoicesLastPosted = 7;

            /// <summary>
            /// Property Indexer for BillingCycleFrequency 
            /// </summary>
            public const int BillingCycleFrequency = 9;

            /// <summary>
            /// Property Indexer for RemitToName 
            /// </summary>
            public const int RemitToName = 10;

            /// <summary>
            /// Property Indexer for RemitToAddress1 
            /// </summary>
            public const int RemitToAddress1 = 11;

            /// <summary>
            /// Property Indexer for RemitToAddress2 
            /// </summary>
            public const int RemitToAddress2 = 12;

            /// <summary>
            /// Property Indexer for RemitToAddress3 
            /// </summary>
            public const int RemitToAddress3 = 13;

            /// <summary>
            /// Property Indexer for RemitToAddress4 
            /// </summary>
            public const int RemitToAddress4 = 14;

            /// <summary>
            /// Property Indexer for RemitToCity 
            /// </summary>
            public const int RemitToCity = 15;

            /// <summary>
            /// Property Indexer for RemitToStateOrProv 
            /// </summary>
            public const int RemitToStateOrProv = 16;

            /// <summary>
            /// Property Indexer for RemitToZipOrPostalCode 
            /// </summary>
            public const int RemitToZipOrPostalCode = 17;

            /// <summary>
            /// Property Indexer for RemitToCountry 
            /// </summary>
            public const int RemitToCountry = 18;

            #endregion
        }
    }
}