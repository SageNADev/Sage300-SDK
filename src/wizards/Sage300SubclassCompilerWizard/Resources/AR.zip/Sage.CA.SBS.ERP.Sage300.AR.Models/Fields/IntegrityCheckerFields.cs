// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class Integrity Checker
    /// </summary>
    public partial class IntegrityChecker
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0057";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of Integrity Checker Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for RecordID 
            /// </summary>
            public const string RecordID = "RECID";

            /// <summary>
            /// Property for CheckOrphans 
            /// </summary>
            public const string CheckOrphans = "CHKORPHAN";

            /// <summary>
            /// Property for FixOrphans 
            /// </summary>
            public const string FixOrphans = "FIXORPHAN";

            /// <summary>
            /// Property for CheckSetupTables 
            /// </summary>
            public const string CheckSetupTables = "CHKSETUP";

            /// <summary>
            /// Property for FixSetupTables 
            /// </summary>
            public const string FixSetupTables = "FIXSETUP";

            /// <summary>
            /// Property for CheckOpenBatches 
            /// </summary>
            public const string CheckOpenBatches = "CHKBATCH";

            /// <summary>
            /// Property for FixOpenBatches 
            /// </summary>
            public const string FixOpenBatches = "FIXBATCH";

            /// <summary>
            /// Property for CheckCustomerDocuments 
            /// </summary>
            public const string CheckCustomerDocuments = "CHKCUSDOC";

            /// <summary>
            /// Property for FixCustomerDocuments 
            /// </summary>
            public const string FixCustomerDocuments = "FIXCUSDOC";

            /// <summary>
            /// Property for FromCustomer 
            /// </summary>
            public const string FromCustomer = "FRCUSDOC";

            /// <summary>
            /// Property for ToCustomer 
            /// </summary>
            public const string ToCustomer = "TOCUSDOC";

            /// <summary>
            /// Property for CheckPostingJournal 
            /// </summary>
            public const string CheckPostingJournal = "CHKJOURNAL";

            /// <summary>
            /// Property for FixPostingJournal 
            /// </summary>
            public const string FixPostingJournal = "FIXJOURNAL";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of Integrity Checker Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for RecordID 
            /// </summary>
            /// 
            public const int RecordID = 1;

            /// <summary>
            /// Property Indexer for CheckOrphans 
            /// </summary>
            /// 
            public const int CheckOrphans = 2;

            /// <summary>
            /// Property Indexer for FixOrphans 
            /// </summary>
            /// 
            public const int FixOrphans = 3;

            /// <summary>
            /// Property Indexer for CheckSetupTables 
            /// </summary>
            public const int CheckSetupTables = 4;

            /// <summary>
            /// Property Indexer for FixSetupTables 
            /// </summary>
            public const int FixSetupTables = 5;

            /// <summary>
            /// Property Indexer for CheckOpenBatches 
            /// </summary>
            public const int CheckOpenBatches = 6;

            /// <summary>
            /// Property Indexer for FixOpenBatches 
            /// </summary>
            public const int FixOpenBatches = 7;

            /// <summary>
            /// Property Indexer for CheckCustomerDocuments 
            /// </summary>
            public const int CheckCustomerDocuments = 8;

            /// <summary>
            /// Property Indexer for FixCustomerDocuments 
            /// </summary>
            public const int FixCustomerDocuments = 9;

            /// <summary>
            /// Property Indexer for FromCustomer 
            /// </summary>
            public const int FromCustomer = 10;

            /// <summary>
            /// Property Indexer for ToCustomer 
            /// </summary>
            public const int ToCustomer = 11;

            /// <summary>
            /// Property Indexer for CheckPostingJournal 
            /// </summary>
            public const int CheckPostingJournal = 12;

            /// <summary>
            /// Property Indexer for FixPostingJournal 
            /// </summary>
            public const int FixPostingJournal = 13;

            #endregion
        }

        #endregion
    }
}