// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Contains list of PrintCheck Constants
	/// </summary>
	public partial class PrintCheck
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "AR0461";

		#region Properties

		/// <summary>
		/// Contains list of PrintCheck Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Request
			/// </summary>
			public const string Request = "SWREQTYPE";

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBATCHNO";

			/// <summary>
			/// Property for EntryNumber
			/// </summary>
			public const string EntryNumber = "CNTENTRYNO";

			/// <summary>
			/// Property for ReturnedStatus
			/// </summary>
			public const string ReturnedStatus = "SWRTRNSTTS";

			/// <summary>
			/// Property for RestartState
			/// </summary>
			public const string RestartState = "STATE";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of PrintCheck Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Request
			/// </summary>
			public const int Request = 1;

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 2;

			/// <summary>
			/// Property Indexer for EntryNumber
			/// </summary>
			public const int EntryNumber = 3;

			/// <summary>
			/// Property Indexer for ReturnedStatus
			/// </summary>
			public const int ReturnedStatus = 4;

			/// <summary>
			/// Property Indexer for RestartState
			/// </summary>
			public const int RestartState = 5;

		}

		#endregion

	}
}
