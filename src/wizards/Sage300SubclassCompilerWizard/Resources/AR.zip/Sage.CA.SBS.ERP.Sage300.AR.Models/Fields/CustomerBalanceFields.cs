// Copyright (c) 2014-2017 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of CustomerBalance Constants
    /// </summary>
    public partial class CustomerBalance
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0160";

        /// <summary>
        /// Contains list of CustomerBalance Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "NAMECUST";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "CURNCUST";

            /// <summary>
            /// Property for CheckCustomerCreditLimit
            /// </summary>
            public const string CheckCustomerCreditLimit = "SWCHKCUST";

            /// <summary>
            /// Property for CustomerCreditLimit
            /// </summary>
            public const string CustomerCreditLimit = "AMTLIMITC";

            /// <summary>
            /// Property for CustomerBalance
            /// </summary>
            public const string CustomerBalance = "AMTBALCUST";

            /// <summary>
            /// Property for CalcCustomerOverdue
            /// </summary>
            public const string CalcCustomerOverdue = "SWCHKOVERC";

            /// <summary>
            /// Property for CustomerDaysOverdue
            /// </summary>
            public const string CustomerDaysOverdue = "OVERDAYSC";

            /// <summary>
            /// Property for CustomerAmountOverdue
            /// </summary>
            public const string CustomerAmountOverdue = "OVERAMTC";

            /// <summary>
            /// Property for CustomerBalanceOverdue
            /// </summary>
            public const string CustomerBalanceOverdue = "OVERBALC";

            /// <summary>
            /// Property for NationalAccountNumber
            /// </summary>
            public const string NationalAccountNumber = "IDNATACCT";

            /// <summary>
            /// Property for NationalAccountName
            /// </summary>
            public const string NationalAccountName = "NAMEACCT";

            /// <summary>
            /// Property for NationalAccountCurrency
            /// </summary>
            public const string NationalAccountCurrency = "CURNACCT";

            /// <summary>
            /// Property for CheckNatAcctCreditLimit
            /// </summary>
            public const string CheckNatAcctCreditLimit = "SWCHKACCT";

            /// <summary>
            /// Property for NatAcctCreditLimit
            /// </summary>
            public const string NatAcctCreditLimit = "AMTLIMITA";

            /// <summary>
            /// Property for NationalAccountBalance
            /// </summary>
            public const string NationalAccountBalance = "AMTBALACCT";

            /// <summary>
            /// Property for CalcNatAcctOverdue
            /// </summary>
            public const string CalcNatAcctOverdue = "SWCHKOVERA";

            /// <summary>
            /// Property for NatAcctDaysOverdue
            /// </summary>
            public const string NatAcctDaysOverdue = "OVERDAYSA";

            /// <summary>
            /// Property for NatAcctAmountOverdue
            /// </summary>
            public const string NatAcctAmountOverdue = "OVERAMTA";

            /// <summary>
            /// Property for NatAcctBalanceOverdue
            /// </summary>
            public const string NatAcctBalanceOverdue = "OVERBALA";

            /// <summary>
            /// Property for IncludePendingARTrans
            /// </summary>
            public const string IncludePendingARTrans = "SWARPEND";

            /// <summary>
            /// Property for IncludePendingOETrans
            /// </summary>
            public const string IncludePendingOETrans = "SWOEPEND";

            /// <summary>
            /// Property for IncludePendingOtherTrans
            /// </summary>
            public const string IncludePendingOtherTrans = "SWXXPEND";

            /// <summary>
            /// Property for PendingARAmount
            /// </summary>
            public const string PendingARAmount = "AMTARPEND";

            /// <summary>
            /// Property for PendingOEAmount
            /// </summary>
            public const string PendingOEAmount = "AMTOEPEND";

            /// <summary>
            /// Property for PendingOtherAmount
            /// </summary>
            public const string PendingOtherAmount = "AMTXXPEND";

            /// <summary>
            /// Property for CustomerOutstanding
            /// </summary>
            public const string CustomerOutstanding = "AMTTOTCUST";

            /// <summary>
            /// Property for NatAcctOutstanding
            /// </summary>
            public const string NatAcctOutstanding = "AMTTOTACCT";

            /// <summary>
            /// Property for CustomerLimitLeft
            /// </summary>
            public const string CustomerLimitLeft = "AMTLEFTC";

            /// <summary>
            /// Property for NatAcctLimitLeft
            /// </summary>
            public const string NatAcctLimitLeft = "AMTLEFTA";

            /// <summary>
            /// Property for CustomerLimitExceeded
            /// </summary>
            public const string CustomerLimitExceeded = "AMTOVERC";

            /// <summary>
            /// Property for NatAcctLimitExceeded
            /// </summary>
            public const string NatAcctLimitExceeded = "AMTOVERA";

            /// <summary>
            /// Property for CurrentARInvoiceAmount
            /// </summary>
            public const string CurrentARInvoiceAmount = "AMTARINVC";

            /// <summary>
            /// Property for CurrentARPrepaymentAmount
            /// </summary>
            public const string CurrentARPrepaymentAmount = "AMTARPPD";

            /// <summary>
            /// Property for ProcessWithoutCreditLimit
            /// </summary>
            public const string ProcessWithoutCreditLimit = "SWNOLIMIT";

            #endregion
        }

        /// <summary>
        /// Contains list of CustomerBalance Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 2;

            /// <summary>
            /// Property Indexer for CustomerCurrency
            /// </summary>
            public const int CustomerCurrency = 3;

            /// <summary>
            /// Property Indexer for CheckCustomerCreditLimit
            /// </summary>
            public const int CheckCustomerCreditLimit = 4;

            /// <summary>
            /// Property Indexer for CustomerCreditLimit
            /// </summary>
            public const int CustomerCreditLimit = 5;

            /// <summary>
            /// Property Indexer for CustomerBalance
            /// </summary>
            public const int CustomerBalance = 6;

            /// <summary>
            /// Property Indexer for CalcCustomerOverdue
            /// </summary>
            public const int CalcCustomerOverdue = 7;

            /// <summary>
            /// Property Indexer for CustomerDaysOverdue
            /// </summary>
            public const int CustomerDaysOverdue = 8;

            /// <summary>
            /// Property Indexer for CustomerAmountOverdue
            /// </summary>
            public const int CustomerAmountOverdue = 9;

            /// <summary>
            /// Property Indexer for CustomerBalanceOverdue
            /// </summary>
            public const int CustomerBalanceOverdue = 10;

            /// <summary>
            /// Property Indexer for NationalAccountNumber
            /// </summary>
            public const int NationalAccountNumber = 11;

            /// <summary>
            /// Property Indexer for NationalAccountName
            /// </summary>
            public const int NationalAccountName = 12;

            /// <summary>
            /// Property Indexer for NationalAccountCurrency
            /// </summary>
            public const int NationalAccountCurrency = 13;

            /// <summary>
            /// Property Indexer for CheckNatAcctCreditLimit
            /// </summary>
            public const int CheckNatAcctCreditLimit = 14;

            /// <summary>
            /// Property Indexer for NatAcctCreditLimit
            /// </summary>
            public const int NatAcctCreditLimit = 15;

            /// <summary>
            /// Property Indexer for NationalAccountBalance
            /// </summary>
            public const int NationalAccountBalance = 16;

            /// <summary>
            /// Property Indexer for CalcNatAcctOverdue
            /// </summary>
            public const int CalcNatAcctOverdue = 17;

            /// <summary>
            /// Property Indexer for NatAcctDaysOverdue
            /// </summary>
            public const int NatAcctDaysOverdue = 18;

            /// <summary>
            /// Property Indexer for NatAcctAmountOverdue
            /// </summary>
            public const int NatAcctAmountOverdue = 19;

            /// <summary>
            /// Property Indexer for NatAcctBalanceOverdue
            /// </summary>
            public const int NatAcctBalanceOverdue = 20;

            /// <summary>
            /// Property Indexer for IncludePendingARTrans
            /// </summary>
            public const int IncludePendingARTrans = 21;

            /// <summary>
            /// Property Indexer for IncludePendingOETrans
            /// </summary>
            public const int IncludePendingOETrans = 22;

            /// <summary>
            /// Property Indexer for IncludePendingOtherTrans
            /// </summary>
            public const int IncludePendingOtherTrans = 23;

            /// <summary>
            /// Property Indexer for PendingARAmount
            /// </summary>
            public const int PendingARAmount = 24;

            /// <summary>
            /// Property Indexer for PendingOEAmount
            /// </summary>
            public const int PendingOEAmount = 25;

            /// <summary>
            /// Property Indexer for PendingOtherAmount
            /// </summary>
            public const int PendingOtherAmount = 26;

            /// <summary>
            /// Property Indexer for CustomerOutstanding
            /// </summary>
            public const int CustomerOutstanding = 27;

            /// <summary>
            /// Property Indexer for NatAcctOutstanding
            /// </summary>
            public const int NatAcctOutstanding = 28;

            /// <summary>
            /// Property Indexer for CustomerLimitLeft
            /// </summary>
            public const int CustomerLimitLeft = 29;

            /// <summary>
            /// Property Indexer for NatAcctLimitLeft
            /// </summary>
            public const int NatAcctLimitLeft = 30;

            /// <summary>
            /// Property Indexer for CustomerLimitExceeded
            /// </summary>
            public const int CustomerLimitExceeded = 31;

            /// <summary>
            /// Property Indexer for NatAcctLimitExceeded
            /// </summary>
            public const int NatAcctLimitExceeded = 32;

            /// <summary>
            /// Property Indexer for CurrentARInvoiceAmount
            /// </summary>
            public const int CurrentARInvoiceAmount = 33;

            /// <summary>
            /// Property Indexer for CurrentARPrepaymentAmount
            /// </summary>
            public const int CurrentARPrepaymentAmount = 34;

            /// <summary>
            /// Property Indexer for ProcessWithoutCreditLimit
            /// </summary>
            public const int ProcessWithoutCreditLimit = 35;

            #endregion
        }
    }
}
