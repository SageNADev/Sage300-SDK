// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Item Constants 
    /// </summary>
	public partial class Item 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AR0010";

        /// <summary>
        /// Contains list of Item Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for ItemNumber 
        /// </summary>
	    public const string ItemNumber  = "IDITEM";
	            /// <summary>
        /// Property for CommodityCode 
        /// </summary>
	    public const string CommodityCode  = "CODECMDY";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "TEXTDESC";
	            /// <summary>
        /// Property for Status 
        /// </summary>
	    public const string Status  = "SWACTV";
	            /// <summary>
        /// Property for InactiveDate 
        /// </summary>
	    public const string InactiveDate  = "DATEINAC";
	            /// <summary>
        /// Property for DateLastMaintained 
        /// </summary>
	    public const string DateLastMaintained  = "DATELASTMN";
	            /// <summary>
        /// Property for DistributionCode 
        /// </summary>
	    public const string DistributionCode  = "IDDIST";
	            /// <summary>
        /// Property for Comment 
        /// </summary>
	    public const string Comment  = "TEXTCMNT";
	            /// <summary>
        /// Property for Discountable 
        /// </summary>
	    public const string Discountable  = "SWDISCABL";
	            /// <summary>
        /// Property for RevenueAccount 
        /// </summary>
	    public const string RevenueAccount  = "IDACCTREV";
	            /// <summary>
        /// Property for InventoryAccount 
        /// </summary>
	    public const string InventoryAccount  = "IDACCTINV";
	            /// <summary>
        /// Property for COGSAccount 
        /// </summary>
	    public const string CogsAccount  = "IDACCTCOGS";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of Item Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for ItemNumber 
        /// </summary>
	    public const int ItemNumber  = 1;
	             /// <summary>
        /// Property Indexer for CommodityCode 
        /// </summary>
	    public const int CommodityCode  = 2;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 3;
	             /// <summary>
        /// Property Indexer for Status 
        /// </summary>
	    public const int Status  = 4;
	             /// <summary>
        /// Property Indexer for InactiveDate 
        /// </summary>
	    public const int InactiveDate  = 5;
	             /// <summary>
        /// Property Indexer for DateLastMaintained 
        /// </summary>
	    public const int DateLastMaintained  = 6;
	             /// <summary>
        /// Property Indexer for DistributionCode 
        /// </summary>
	    public const int DistributionCode  = 7;
	             /// <summary>
        /// Property Indexer for Comment 
        /// </summary>
	    public const int Comment  = 8;
	             /// <summary>
        /// Property Indexer for Discountable 
        /// </summary>
	    public const int Discountable  = 9;
	             /// <summary>
        /// Property Indexer for RevenueAccount 
        /// </summary>
	    public const int RevenueAccount  = 10;
	             /// <summary>
        /// Property Indexer for InventoryAccount 
        /// </summary>
	    public const int InventoryAccount  = 11;
	             /// <summary>
        /// Property Indexer for COGSAccount 
        /// </summary>
	    public const int CogsAccount  = 12;
	     
        #endregion
	    }

	
	}
}
	