﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of ItemTaxClass
    ///  Constants
    /// </summary>
    public partial class ItemTaxClass
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0011";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of ItemTaxClasse Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "IDITEM";

            /// <summary>
            /// Property for TaxAuthority
            /// </summary>
            public const string TaxAuthority = "CODETAX";

            /// <summary>
            /// Property for TaxClass
            /// </summary>
            public const string TaxClass = "TAXSTTS";

            /// <summary>
            /// Property for TaxIncluded
            /// </summary>
            public const string TaxIncluded = "SWTAXINCL";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ItemTaxClasse Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 1;

            /// <summary>
            /// Property Indexer for TaxAuthority
            /// </summary>
            public const int TaxAuthority = 2;

            /// <summary>
            /// Property Indexer for TaxClass
            /// </summary>
            public const int TaxClass = 3;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 4;

        }

        #endregion

    }
}
