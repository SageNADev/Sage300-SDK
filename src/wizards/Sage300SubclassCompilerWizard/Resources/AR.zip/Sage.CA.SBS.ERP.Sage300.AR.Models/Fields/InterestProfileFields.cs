/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of Interest Profile Constants 
    /// </summary>
    public partial class InterestProfile
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0020";

        /// <summary>
        /// Contains list of Interest Profile Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for InterestProfileId 
            /// </summary>
            public const string InterestProfileId = "CODESVCCHR";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTVSW";
            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "INACDATE";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATEMNTN";
            /// <summary>
            /// Property for InterestIncomeAccount 
            /// </summary>
            public const string InterestIncomeAccount = "IDACCTCHRG";
            /// <summary>
            /// Property for TermsCode 
            /// </summary>
            public const string TermsCode = "TERMCODE";
            /// <summary>
            /// Property for CalculateInterestBy 
            /// </summary>
            public const string CalculateInterestBy = "SVCTYPE";
            /// <summary>
            /// Property for NumberofDaysOverdue 
            /// </summary>
            public const string NumberOfDaysOverdue = "PDUEDAYS";
            /// <summary>
            /// Property for RoundUptoMinimum 
            /// </summary>
            public const string RoundUptoMinimum = "RNDGUPSW";
            /// <summary>
            /// Property for CompoundInterest 
            /// </summary>
            public const string CompoundInterest = "CHRGCMPDSW";

            #region finderColumns
            /// <summary>
            /// Property for StatusString 
            /// </summary>
            public const string StatusString = "ACTVSW";
            /// <summary>
            /// Property for CalculateInterestByString 
            /// </summary>
            public const string CalculateInterestByString = "SVCTYPE";
            /// <summary>
            /// Property for RoundUptoMinimumString 
            /// </summary>
            public const string RoundUptoMinimumString = "RNDGUPSW";
            /// <summary>
            /// Property for CompoundInterestString 
            /// </summary>
            public const string CompoundInterestString = "CHRGCMPDSW";
            #endregion

            #endregion
        }

        /// <summary>
        /// Contains list of Interest Profile Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for InterestProfileId 
            /// </summary>
            public const int InterestProfileId = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;
            /// <summary>
            /// Property Indexer for InterestIncomeAccount 
            /// </summary>
            public const int InterestIncomeAccount = 6;
            /// <summary>
            /// Property Indexer for TermsCode 
            /// </summary>
            public const int TermsCode = 7;
            /// <summary>
            /// Property Indexer for CalculateInterestBy 
            /// </summary>
            public const int CalculateInterestBy = 8;
            /// <summary>
            /// Property Indexer for NumberofDaysOverdue 
            /// </summary>
            public const int NumberOfDaysOverdue = 9;
            /// <summary>
            /// Property Indexer for RoundUptoMinimum 
            /// </summary>
            public const int RoundUptoMinimum = 10;
            /// <summary>
            /// Property Indexer for CompoundInterest 
            /// </summary>
            public const int CompoundInterest = 11;

            #endregion
        }


    }
}
