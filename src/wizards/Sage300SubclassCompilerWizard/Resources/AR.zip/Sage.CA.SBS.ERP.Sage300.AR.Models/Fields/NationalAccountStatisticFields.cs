// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of National Account Statistics Constants 
    /// </summary>
    public partial class NationalAccountStatistic
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0029";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of National Account Statistics Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for National Account Number 
            /// </summary>
            public const string NationalAccountNumber = "IDNATLACCT";

            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "CNTYR";

            /// <summary>
            /// Property for Period 
            /// </summary>
            public const string Period = "CNTPERD";

            /// <summary>
            /// Property for Number of Invoices 
            /// </summary>
            public const string NumberofInvoices = "CNTINVC";

            /// <summary>
            /// Property for Number of Credit Notes 
            /// </summary>
            public const string NumberofCreditNotes = "CNTCR";

            /// <summary>
            /// Property for Number of Debit Notes 
            /// </summary>
            public const string NumberofDebitNotes = "CNTDR";

            /// <summary>
            /// Property for Number of Receipts 
            /// </summary>
            public const string NumberofReceipts = "CNTPAYM";

            /// <summary>
            /// Property for Number of Discounts 
            /// </summary>
            public const string NumberofDiscounts = "CNTDISC";

            /// <summary>
            /// Property for Number of Adjustments 
            /// </summary>
            public const string NumberofAdjustments = "CNTADJ";

            /// <summary>
            /// Property for Number of Write Offs 
            /// </summary>
            public const string NumberofWriteOffs = "CNTWROF";

            /// <summary>
            /// Property for Number of Interest Charges 
            /// </summary>
            public const string NumberofInterestCharges = "CNTINTT";

            /// <summary>
            /// Property for Number of Returned Checks 
            /// </summary>
            public const string NumberofReturnedChecks = "CNTRIF";

            /// <summary>
            /// Property for Number of Invoices Paid 
            /// </summary>
            public const string NumberofInvoicesPaid = "CNTINVCPD";

            /// <summary>
            /// Property for Number of Days to Pay 
            /// </summary>
            public const string NumberofDaystoPay = "CNTDYTOPY";

            /// <summary>
            /// Property for Average Days to Pay 
            /// </summary>
            public const string AverageDaystoPay = "AVGDYTOPY";

            /// <summary>
            /// Property for Total Invoices in Func Currency 
            /// </summary>
            public const string TotalInvoicesinFuncCurrency = "AMTINVHCUR";

            /// <summary>
            /// Property for Total Credits in Func Currency 
            /// </summary>
            public const string TotalCreditsinFuncCurrency = "AMTCRHCUR";

            /// <summary>
            /// Property for Total Debits in Func Currency 
            /// </summary>
            public const string TotalDebitsinFuncCurrency = "AMTDRHCUR";

            /// <summary>
            /// Property for Total Receipts in Func Currency 
            /// </summary>
            public const string TotalReceiptsinFuncCurrency = "AMTPYMHCUR";

            /// <summary>
            /// Property for Total Discounts in Func Curr 
            /// </summary>
            public const string TotalDiscountsinFuncCurr = "AMTDSCHCUR";

            /// <summary>
            /// Property for Total Adjustments in Func Curr 
            /// </summary>
            public const string TotalAdjustmentsinFuncCurr = "AMTADJHCUR";

            /// <summary>
            /// Property for Total Write Offs in Func Currency 
            /// </summary>
            public const string TotalWriteOffsinFuncCurren = "AMTWRFHCUR";

            /// <summary>
            /// Property for Total Interest in Func Curr 
            /// </summary>
            public const string TotalInterestinFuncCurr = "AMTINTHCUR";

            /// <summary>
            /// Property for Total Retd Checks Func Curr 
            /// </summary>
            public const string TotalRetdChecksFuncCurr = "AMTRIFHCUR";

            /// <summary>
            /// Property for Total Invoices Paid Func Curr 
            /// </summary>
            public const string TotalInvoicesPaidFuncCurr = "AMTINVPD";

            /// <summary>
            /// Property for Total Invoices in Cust Curr 
            /// </summary>
            public const string TotalInvoicesinCustCurr = "AMTINVTCUR";

            /// <summary>
            /// Property for Total Credits in Cust Curr 
            /// </summary>
            public const string TotalCreditsinCustCurr = "AMTCRTCUR";

            /// <summary>
            /// Property for Total Debits in Cust Curr 
            /// </summary>
            public const string TotalDebitsinCustCurr = "AMTDRTCUR";

            /// <summary>
            /// Property for Total Receipts in Cust Curr 
            /// </summary>
            public const string TotalReceiptsinCustCurr = "AMTPYMTCUR";

            /// <summary>
            /// Property for Total Discounts in Cust Curr 
            /// </summary>
            public const string TotalDiscountsinCustCurr = "AMTDSCTCUR";

            /// <summary>
            /// Property for Total Adjustments in Cust Curr 
            /// </summary>
            public const string TotalAdjustmentsinCustCurr = "AMTADJTCUR";

            /// <summary>
            /// Property for Total Write Offs in Cust Curr 
            /// </summary>
            public const string TotalWriteOffsinCustCurr = "AMTWRFTCUR";

            /// <summary>
            /// Property for Total Interest in Cust Curr 
            /// </summary>
            public const string TotalInterestinCustCurr = "AMTINTTCUR";

            /// <summary>
            /// Property for Total Retd Checks Cust Curr 
            /// </summary>
            public const string TotalRetdChecksCustCurr = "AMTRIFTCUR";

            /// <summary>
            /// Property for Total Invoices Paid Cust Curr 
            /// </summary>
            public const string TotalInvoicesPaidCustCurr = "AMTINVPTHC";

            /// <summary>
            /// Property for Number of Refunds 
            /// </summary>
            public const string NumberofRefunds = "CNTRF";

            /// <summary>
            /// Property for Total Refunds in Func Currency 
            /// </summary>
            public const string TotalRefundsinFuncCurrency = "AMTRFHC";

            /// <summary>
            /// Property for Total Refunds in Cust Currency 
            /// </summary>
            public const string TotalRefundsinCustCurrency = "AMTRFTC";

            /// <summary>
            /// Property for Ytd Number of Invoices 
            /// </summary>
            public const string YtdNumberofInvoices = "YTDCNTIN";

            /// <summary>
            /// Property for YTD Number of Credits 
            /// </summary>
            public const string YtdNumberofCredits = "YTDCNTCR";

            /// <summary>
            /// Property for YTD Number of Debits 
            /// </summary>
            public const string YtdNumberofDebits = "YTDCNTDR";

            /// <summary>
            /// Property for YTD Number of Receipts 
            /// </summary>
            public const string YtdNumberofReceipts = "YTDCNTPY";

            /// <summary>
            /// Property for YTD Number of Discounts 
            /// </summary>
            public const string YtdNumberofDiscounts = "YTDCNTED";

            /// <summary>
            /// Property for YTD Number of Adjustments 
            /// </summary>
            public const string YtdNumberofAdjustments = "YTDCNTAD";

            /// <summary>
            /// Property for YTD Number of Write Offs 
            /// </summary>
            public const string YtdNumberofWriteOffs = "YTDCNTWO";

            /// <summary>
            /// Property for YTD Number of Interest Charges 
            /// </summary>
            public const string YtdNumberofInterestCharges = "YTDCNTIT";

            /// <summary>
            /// Property for YTD Number of Returned Checks 
            /// </summary>
            public const string YtdNumberofReturnedChecks = "YTDCNTRIF";

            /// <summary>
            /// Property for YTD Number of Invoices Paid 
            /// </summary>
            public const string YtdNumberofInvoicesPaid = "YTDCNTINPD";

            /// <summary>
            /// Property for YTD Number of Refunds 
            /// </summary>
            public const string YtdNumberofRefunds = "YTDCNTRF";

            /// <summary>
            /// Property for YTD Number of Days to Pay 
            /// </summary>
            public const string YtdNumberofDaystoPay = "YTDCNTDTP";

            /// <summary>
            /// Property for YTD Invoices in Func Curr 
            /// </summary>
            public const string YtdInvoicesinFuncCurr = "YTDHCIN";

            /// <summary>
            /// Property for YTD Credits in Func Curr 
            /// </summary>
            public const string YtdCreditsinFuncCurr = "YTDHCCR";

            /// <summary>
            /// Property for YTD Debits in Func Curr 
            /// </summary>
            public const string YtdDebitsinFuncCurr = "YTDHCDR";

            /// <summary>
            /// Property for YTD Receipts in Func Curr 
            /// </summary>
            public const string YtdReceiptsinFuncCurr = "YTDHCPY";

            /// <summary>
            /// Property for YTD Discounts in Func Curr 
            /// </summary>
            public const string YtdDiscountsinFuncCurr = "YTDHCED";

            /// <summary>
            /// Property for YTD Adjustments in Func Curr 
            /// </summary>
            public const string YtdAdjustmentsinFuncCurr = "YTDHCAD";

            /// <summary>
            /// Property for YTD Write Offs in Func Curr 
            /// </summary>
            public const string YtdWriteOffsinFuncCurr = "YTDHCWO";

            /// <summary>
            /// Property for YTD Interest in Func Curr 
            /// </summary>
            public const string YtdInterestinFuncCurr = "YTDHCIT";

            /// <summary>
            /// Property for YTD Retd Checks in Func Curr 
            /// </summary>
            public const string YtdRetdChecksinFuncCurr = "YTDHCRIF";

            /// <summary>
            /// Property for YTD Invoices Pd in Func Curr 
            /// </summary>
            public const string YtdInvoicesPdinFuncCurr = "YTDHCINPD";

            /// <summary>
            /// Property for YTD Refunds in Func Curr 
            /// </summary>
            public const string YtdRefundsinFuncCurr = "YTDHCRF";

            /// <summary>
            /// Property for YTD Invoices in Cust Curr 
            /// </summary>
            public const string YtdInvoicesinCustCurr = "YTDTCIN";

            /// <summary>
            /// Property for YTD Credits in Cust Curr 
            /// </summary>
            public const string YtdCreditsinCustCurr = "YTDTCCR";

            /// <summary>
            /// Property for YTD Debits in Cust Curr 
            /// </summary>
            public const string YtdDebitsinCustCurr = "YTDTCDR";

            /// <summary>
            /// Property for YTD Receipts in Cust Curr 
            /// </summary>
            public const string YtdReceiptsinCustCurr = "YTDTCPY";

            /// <summary>
            /// Property for YTD Discounts in Cust Curr 
            /// </summary>
            public const string YtdDiscountsinCustCurr = "YTDTCED";

            /// <summary>
            /// Property for YTD Adjustments in Cust Curr 
            /// </summary>
            public const string YtdAdjustmentsinCustCurr = "YTDTCAD";

            /// <summary>
            /// Property for YTD Write Offs in Cust Curr 
            /// </summary>
            public const string YtdWriteOffsinCustCurr = "YTDTCWO";

            /// <summary>
            /// Property for YTD Interest in Cust Curr 
            /// </summary>
            public const string YtdInterestinCustCurr = "YTDTCIT";

            /// <summary>
            /// Property for YTD Retd Checks in Cust Curr 
            /// </summary>
            public const string YtdRetdChecksinCustCurr = "YTDTCRIF";

            /// <summary>
            /// Property for YTD Invoices Pd in Cust Curr 
            /// </summary>
            public const string YtdInvoicesPdinCustCurr = "YTDTCINPD";

            /// <summary>
            /// Property for YTD Refunds in Cust Curr 
            /// </summary>
            public const string YtdRefundsinCustCurr = "YTDTCRF";

            /// <summary>
            /// Property for YTD Average Days to Pay 
            /// </summary>
            public const string YtdAverageDaystoPay = "YTDCNTADTP";

            /// <summary>
            /// Property for Enable YTD Calculations 
            /// </summary>
            public const string EnableYtdCalculations = "YTDACTIVE";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of National Account Statistics Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for National Account Number 
            /// </summary>
            public const int NationalAccountNumber = 1;

            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 2;

            /// <summary>
            /// Property Indexer for Period 
            /// </summary>
            public const int Period = 3;

            /// <summary>
            /// Property Indexer for Number of Invoices 
            /// </summary>
            public const int NumberofInvoices = 4;

            /// <summary>
            /// Property Indexer for Number of Credit Notes 
            /// </summary>
            public const int NumberofCreditNotes = 5;

            /// <summary>
            /// Property Indexer for Number of Debit Notes 
            /// </summary>
            public const int NumberofDebitNotes = 6;

            /// <summary>
            /// Property Indexer for Number of Receipts 
            /// </summary>
            public const int NumberofReceipts = 7;

            /// <summary>
            /// Property Indexer for Number of Discounts 
            /// </summary>
            public const int NumberofDiscounts = 8;

            /// <summary>
            /// Property Indexer for Number of Adjustments 
            /// </summary>
            public const int NumberofAdjustments = 9;

            /// <summary>
            /// Property Indexer for Number of Write Offs 
            /// </summary>
            public const int NumberofWriteOffs = 10;

            /// <summary>
            /// Property Indexer for Number of Interest Charges 
            /// </summary>
            public const int NumberofInterestCharges = 11;

            /// <summary>
            /// Property Indexer for Number of Returned Checks 
            /// </summary>
            public const int NumberofReturnedChecks = 12;

            /// <summary>
            /// Property Indexer for Number of Invoices Paid 
            /// </summary>
            public const int NumberofInvoicesPaid = 13;

            /// <summary>
            /// Property Indexer for Number of Days to Pay 
            /// </summary>
            public const int NumberofDaystoPay = 14;

            /// <summary>
            /// Property Indexer for Average Days to Pay 
            /// </summary>
            public const int AverageDaystoPay = 15;

            /// <summary>
            /// Property Indexer for Total Invoices in Func Currency 
            /// </summary>
            public const int TotalInvoicesinFuncCurrency = 16;

            /// <summary>
            /// Property Indexer for Total Credits in Func Currency 
            /// </summary>
            public const int TotalCreditsinFuncCurrency = 17;

            /// <summary>
            /// Property Indexer for Total Debits in Func Currency 
            /// </summary>
            public const int TotalDebitsinFuncCurrency = 18;

            /// <summary>
            /// Property Indexer for Total Receipts in Func Currency 
            /// </summary>
            public const int TotalReceiptsinFuncCurrency = 19;

            /// <summary>
            /// Property Indexer for Total Discounts in Func Curr 
            /// </summary>
            public const int TotalDiscountsinFuncCurr = 20;

            /// <summary>
            /// Property Indexer for Total Adjustments in Func Curr 
            /// </summary>
            public const int TotalAdjustmentsinFuncCurr = 21;

            /// <summary>
            /// Property Indexer for Total Write Offs in Func Currency 
            /// </summary>
            public const int TotalWriteOffsinFuncCurren = 22;

            /// <summary>
            /// Property Indexer for Total Interest in Func Curr 
            /// </summary>
            public const int TotalInterestinFuncCurr = 23;

            /// <summary>
            /// Property Indexer for Total Retd Checks Func Curr 
            /// </summary>
            public const int TotalRetdChecksFuncCurr = 24;

            /// <summary>
            /// Property Indexer for Total Invoices Paid Func Curr 
            /// </summary>
            public const int TotalInvoicesPaidFuncCurr = 25;

            /// <summary>
            /// Property Indexer for Total Invoices in Cust Curr 
            /// </summary>
            public const int TotalInvoicesinCustCurr = 26;

            /// <summary>
            /// Property Indexer for Total Credits in Cust Curr 
            /// </summary>
            public const int TotalCreditsinCustCurr = 27;

            /// <summary>
            /// Property Indexer for Total Debits in Cust Curr 
            /// </summary>
            public const int TotalDebitsinCustCurr = 28;

            /// <summary>
            /// Property Indexer for Total Receipts in Cust Curr 
            /// </summary>
            public const int TotalReceiptsinCustCurr = 29;

            /// <summary>
            /// Property Indexer for Total Discounts in Cust Curr 
            /// </summary>
            public const int TotalDiscountsinCustCurr = 30;

            /// <summary>
            /// Property Indexer for Total Adjustments in Cust Curr 
            /// </summary>
            public const int TotalAdjustmentsinCustCurr = 31;

            /// <summary>
            /// Property Indexer for Total Write Offs in Cust Curr 
            /// </summary>
            public const int TotalWriteOffsinCustCurr = 32;

            /// <summary>
            /// Property Indexer for Total Interest in Cust Curr 
            /// </summary>
            public const int TotalInterestinCustCurr = 33;

            /// <summary>
            /// Property Indexer for Total Retd Checks Cust Curr 
            /// </summary>
            public const int TotalRetdChecksCustCurr = 34;

            /// <summary>
            /// Property Indexer for Total Invoices Paid Cust Curr 
            /// </summary>
            public const int TotalInvoicesPaidCustCurr = 35;

            /// <summary>
            /// Property Indexer for Number of Refunds 
            /// </summary>
            public const int NumberofRefunds = 36;

            /// <summary>
            /// Property Indexer for Total Refunds in Func Currency 
            /// </summary>
            public const int TotalRefundsinFuncCurrency = 37;

            /// <summary>
            /// Property Indexer for Total Refunds in Cust Currency 
            /// </summary>
            public const int TotalRefundsinCustCurrency = 38;

            /// <summary>
            /// Property Indexer for YTD Number of Invoices 
            /// </summary>
            public const int YtdNumberofInvoices = 39;

            /// <summary>
            /// Property Indexer for YTD Number of Credits 
            /// </summary>
            public const int YtdNumberofCredits = 40;

            /// <summary>
            /// Property Indexer for Ytd Number of Debits 
            /// </summary>
            public const int YtdNumberofDebits = 41;

            /// <summary>
            /// Property Indexer for Ytd Number of Receipts 
            /// </summary>
            public const int YtdNumberofReceipts = 42;

            /// <summary>
            /// Property Indexer for Ytd Number of Discounts 
            /// </summary>
            public const int YtdNumberofDiscounts = 43;

            /// <summary>
            /// Property Indexer for Ytd Number of Adjustments 
            /// </summary>
            public const int YtdNumberofAdjustments = 44;

            /// <summary>
            /// Property Indexer for Ytd Number of Write Offs 
            /// </summary>
            public const int YtdNumberofWriteOffs = 45;

            /// <summary>
            /// Property Indexer for Ytd Number of Interest Charges 
            /// </summary>
            public const int YtdNumberofInterestCharges = 46;

            /// <summary>
            /// Property Indexer for Ytd Number of Returned Checks 
            /// </summary>
            public const int YtdNumberofReturnedChecks = 47;

            /// <summary>
            /// Property Indexer for Ytd Number of Invoices Paid 
            /// </summary>
            public const int YtdNumberofInvoicesPaid = 48;

            /// <summary>
            /// Property Indexer for Ytd Number of Refunds 
            /// </summary>
            public const int YtdNumberofRefunds = 49;

            /// <summary>
            /// Property Indexer for Ytd Number of Days to Pay 
            /// </summary>
            public const int YtdNumberofDaystoPay = 50;

            /// <summary>
            /// Property Indexer for Ytd Invoices in Func Curr 
            /// </summary>
            public const int YtdInvoicesinFuncCurr = 51;

            /// <summary>
            /// Property Indexer for Ytd Credits in Func Curr 
            /// </summary>
            public const int YtdCreditsinFuncCurr = 52;

            /// <summary>
            /// Property Indexer for Ytd Debits in Func Curr 
            /// </summary>
            public const int YtdDebitsinFuncCurr = 53;

            /// <summary>
            /// Property Indexer for Ytd Receipts in Func Curr 
            /// </summary>
            public const int YtdReceiptsinFuncCurr = 54;

            /// <summary>
            /// Property Indexer for Ytd Discounts in Func Curr 
            /// </summary>
            public const int YtdDiscountsinFuncCurr = 55;

            /// <summary>
            /// Property Indexer for Ytd Adjustments in Func Curr 
            /// </summary>
            public const int YtdAdjustmentsinFuncCurr = 56;

            /// <summary>
            /// Property Indexer for Ytd Write Off sin Func Curr 
            /// </summary>
            public const int YtdWriteOffsinFuncCurr = 57;

            /// <summary>
            /// Property Indexer for Ytd Interest in Func Curr 
            /// </summary>
            public const int YtdInterestinFuncCurr = 58;

            /// <summary>
            /// Property Indexer for Ytd Retd Checks in Func Curr 
            /// </summary>
            public const int YtdRetdChecksinFuncCurr = 59;

            /// <summary>
            /// Property Indexer for Ytd Invoices Pd in Func Curr 
            /// </summary>
            public const int YtdInvoicesPdinFuncCurr = 60;

            /// <summary>
            /// Property Indexer for Ytd Refunds in Func Curr 
            /// </summary>
            public const int YtdRefundsinFuncCurr = 61;

            /// <summary>
            /// Property Indexer for Ytd Invoices in Cust Curr 
            /// </summary>
            public const int YtdInvoicesinCustCurr = 62;

            /// <summary>
            /// Property Indexer for Ytd Credits in Cust Curr 
            /// </summary>
            public const int YtdCreditsinCustCurr = 63;

            /// <summary>
            /// Property Indexer for Ytd Debits in Cust Curr 
            /// </summary>
            public const int YtdDebitsinCustCurr = 64;

            /// <summary>
            /// Property Indexer for Ytd Receipts in Cust Curr 
            /// </summary>
            public const int YtdReceiptsinCustCurr = 65;

            /// <summary>
            /// Property Indexer for Ytd Discounts in Cust Curr 
            /// </summary>
            public const int YtdDiscountsinCustCurr = 66;

            /// <summary>
            /// Property Indexer for Ytd Adjustments in Cust Curr 
            /// </summary>
            public const int YtdAdjustmentsinCustCurr = 67;

            /// <summary>
            /// Property Indexer for Ytd Write Offs in Cust Curr 
            /// </summary>
            public const int YtdWriteOffsinCustCurr = 68;

            /// <summary>
            /// Property Indexer for Ytd Interest in Cust Curr 
            /// </summary>
            public const int YtdInterestinCustCurr = 69;

            /// <summary>
            /// Property Indexer for Ytd Retd Checks in Cust Curr 
            /// </summary>
            public const int YtdRetdChecksinCustCurr = 70;

            /// <summary>
            /// Property Indexer for Ytd Invoices Pd in Cust Curr 
            /// </summary>
            public const int YtdInvoicesPdinCustCurr = 71;

            /// <summary>
            /// Property Indexer for Ytd Refunds in Cust Curr 
            /// </summary>
            public const int YtdRefundsinCustCurr = 72;

            /// <summary>
            /// Property Indexer for Ytd Average Days to Pay 
            /// </summary>
            public const int YtdAverageDaystoPay = 73;

            /// <summary>
            /// Property Indexer for Enable Ytd Calculations 
            /// </summary>
            public const int EnableYtdCalculations = 74;

            #endregion
        }

        #endregion
    }
}