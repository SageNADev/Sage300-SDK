// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Customer Contact Applications Constants
    /// </summary>
    public partial class CustomerContactApplication
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0221";

        /// <summary>
        /// Contains list of Customer Contact Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for ContactCode
            /// </summary>
            public const string ContactCode = "IDCONTACT";

            /// <summary>
            /// Property for ApplicationID
            /// </summary>
            public const string ApplicationID = "IDAPP";

            /// <summary>
            /// Property for FormID
            /// </summary>
            public const string FormID = "IDFORM";

            /// <summary>
            /// Property for Selected
            /// </summary>
            public const string Selected = "SELECTED";

	    #endregion
        }

        /// <summary>
        /// Contains list of Customers Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for ContactCode
            /// </summary>
            public const int ContactCode = 2;

            /// <summary>
            /// Property Indexer for ApplicationID
            /// </summary>
            public const int ApplicationID = 3;

            /// <summary>
            /// Property Indexer for FormID
            /// </summary>
            public const int FormID = 4;

            /// <summary>
            /// Property Indexer for Selected
            /// </summary>
            public const int Selected = 5;

            #endregion Properties
        }
    }
}