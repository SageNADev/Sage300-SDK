/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of AdvanceCredits Constants 
    /// </summary>
    public partial class ReceiptAdvanceCreditDetail 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AR0170";

        /// <summary>
        /// Contains list of AdvanceCredits Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for BatchType 
        /// </summary>
	    public const string BatchType  = "CODEPAYM";
	            /// <summary>
        /// Property for BatchNumber 
        /// </summary>
	    public const string BatchNumber  = "CNTBTCH";
	            /// <summary>
        /// Property for EntryNumber 
        /// </summary>
	    public const string EntryNumber  = "CNTITEM";
	            /// <summary>
        /// Property for LineNumber 
        /// </summary>
	    public const string LineNumber  = "CNTLINE";
	            /// <summary>
        /// Property for DocumentNumber 
        /// </summary>
	    public const string DocumentNumber  = "DOCNBR";
	            /// <summary>
        /// Property for Description 
        /// </summary>
	    public const string Description  = "TEXTDESC";
	            /// <summary>
        /// Property for Reference 
        /// </summary>
	    public const string Reference  = "TEXTREF";
	            /// <summary>
        /// Property for ClaimAmount 
        /// </summary>
	    public const string ClaimAmount  = "AMTACCTC";
	            /// <summary>
        /// Property for FuncClaimAmount 
        /// </summary>
	    public const string FuncClaimAmount  = "AMTACCHC";
	            /// <summary>
        /// Property for CustomerNumber 
        /// </summary>
	    public const string CustomerNumber  = "IDCUST";
	     
        #endregion

	    }


		/// <summary>
        /// Contains list of AdvanceCredits Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for BatchType 
        /// </summary>
	    public const int BatchType  = 1;
	             /// <summary>
        /// Property Indexer for BatchNumber 
        /// </summary>
	    public const int BatchNumber  = 2;
	             /// <summary>
        /// Property Indexer for EntryNumber 
        /// </summary>
	    public const int EntryNumber  = 3;
	             /// <summary>
        /// Property Indexer for LineNumber 
        /// </summary>
	    public const int LineNumber  = 4;
	             /// <summary>
        /// Property Indexer for DocumentNumber 
        /// </summary>
	    public const int DocumentNumber  = 5;
	             /// <summary>
        /// Property Indexer for Description 
        /// </summary>
	    public const int Description  = 6;
	             /// <summary>
        /// Property Indexer for Reference 
        /// </summary>
	    public const int Reference  = 7;
	             /// <summary>
        /// Property Indexer for ClaimAmount 
        /// </summary>
	    public const int ClaimAmount  = 8;
	             /// <summary>
        /// Property Indexer for FuncClaimAmount 
        /// </summary>
	    public const int FuncClaimAmount  = 9;
	             /// <summary>
        /// Property Indexer for CustomerNumber 
        /// </summary>
	    public const int CustomerNumber  = 10;
	     
        #endregion

	    }

	
	}
}
	