/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CommentType Constants 
    /// </summary>
    public partial class CommentType
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0094";

        /// <summary>
        /// Contains list of CommentType Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CommentTypeKey 
            /// </summary>
            public const string CommentTypeKey = "CMNTTYPE";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTVSW";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "INACTDATE";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DTELSTMTN";

            /// <summary>
            ///  Property for StatusString 
            /// </summary>
            public const string StatusString = "ACTVSW";

            #endregion
        }

        /// <summary>
        /// Contains list of CommentType Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for CommentTypeKey 
            /// </summary>
            public const int CommentTypeKey = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;

            #endregion
        }


    }
}
