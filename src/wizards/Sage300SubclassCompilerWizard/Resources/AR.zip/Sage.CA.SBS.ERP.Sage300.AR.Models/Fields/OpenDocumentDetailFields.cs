// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of OpenDocumentDetail Constants
    /// </summary>
    public partial class OpenDocumentDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0200";

        #region Properties
        /// <summary>
        /// Contains list of OpenDocumentDetail Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "IDINVC";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "CNTLINE";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CATEGORY";

            /// <summary>
            /// Property for ProjectCategoryResource
            /// </summary>
            public const string ProjectCategoryResource = "RESOURCE";

            /// <summary>
            /// Property for TransactionNumber
            /// </summary>
            public const string TransactionNumber = "TRANSNBR";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for DistributionCode
            /// </summary>
            public const string DistributionCode = "IDDIST";

            /// <summary>
            /// Property for GLAccount
            /// </summary>
            public const string GLAccount = "IDGLACCT";

            /// <summary>
            /// Property for CustCurrencyInvoiceAmount
            /// </summary>
            public const string CustomerCurrencyInvoiceAmount = "AMTINVCTC";

            /// <summary>
            /// Property for CustCurrencyAmountDue
            /// </summary>
            public const string CustomerCurrencyAmountDue = "AMTDUETC";

            /// <summary>
            /// Property for FuncCurrencyInvoiceAmount
            /// </summary>
            public const string FunctionalCurrencyInvoiceAmount = "AMTINVCHC";

            /// <summary>
            /// Property for FuncCurrencyAmountDue
            /// </summary>
            public const string FunctionalCurrencyAmountDue = "AMTDUEHC";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "IDITEM";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNITMEAS";

            /// <summary>
            /// Property for Quantity
            /// </summary>
            public const string Quantity = "QTYINVC";

            /// <summary>
            /// Property for Cost
            /// </summary>
            public const string Cost = "AMTCOST";

            /// <summary>
            /// Property for BillingDate
            /// </summary>
            public const string BillingDate = "BILLDATE";

            /// <summary>
            /// Property for Discountable
            /// </summary>
            public const string Discountable = "SWDISCABL";

            /// <summary>
            /// Property for DateRetainageDue
            /// </summary>
            public const string DateRetainageDue = "RTGDATEDUE";
          
            /// <summary>
            /// Property for FuncCurrOrigRtngAmt
            /// </summary>
            public const string FunctionalCurrencyOrigRtngAmt = "RTGOAMTHC";

            /// <summary>
            /// Property for FuncCurrRetainageAmount
            /// </summary>
            public const string FunctionalCurrencyRetainageAmount = "RTGAMTHC";

            /// <summary>
            /// Property for CustCurrOrigRtngAmt
            /// </summary>
            public const string CustomerCurrencyOrigRtngAmt = "RTGOAMTTC";

            /// <summary>
            /// Property for CustCurrRetainageAmount
            /// </summary>
            public const string CustomerCurrencyRetainageAmount = "RTGAMTTC";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for RetainageDistributionAmount
            /// </summary>
            public const string RetainageDistributionAmount = "RTGDISTTC";

            /// <summary>
            /// Property for RetainageCOGSAmount
            /// </summary>
            public const string RetainageCOGSAmount = "RTGCOGSTC";

            /// <summary>
            /// Property for RetainageAlternateBaseAmount
            /// </summary>
            public const string RetainageAlternateBaseAmount = "RTGALTBTC";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "SWTAXINCL1";

            /// <summary>
            /// Property for TaxIncluded2
            /// </summary>
            public const string TaxIncluded2 = "SWTAXINCL2";

            /// <summary>
            /// Property for TaxIncluded3
            /// </summary>
            public const string TaxIncluded3 = "SWTAXINCL3";

            /// <summary>
            /// Property for TaxIncluded4
            /// </summary>
            public const string TaxIncluded4 = "SWTAXINCL4";

            /// <summary>
            /// Property for TaxIncluded5
            /// </summary>
            public const string TaxIncluded5 = "SWTAXINCL5";

            /// <summary>
            /// Property for TaxRate1
            /// </summary>
            public const string TaxRate1 = "TXRATE1";

            /// <summary>
            /// Property for TaxRate2
            /// </summary>
            public const string TaxRate2 = "TXRATE2";

            /// <summary>
            /// Property for TaxRate3
            /// </summary>
            public const string TaxRate3 = "TXRATE3";

            /// <summary>
            /// Property for TaxRate4
            /// </summary>
            public const string TaxRate4 = "TXRATE4";

            /// <summary>
            /// Property for TaxRate5
            /// </summary>
            public const string TaxRate5 = "TXRATE5";

            /// <summary>
            /// Property for CustRetainageTaxBase1
            /// </summary>
            public const string CustomerRetainageTaxBase1 = "TXBSERT1TC";

            /// <summary>
            /// Property for CustRetainageTaxBase2
            /// </summary>
            public const string CustomerRetainageTaxBase2 = "TXBSERT2TC";

            /// <summary>
            /// Property for CustRetainageTaxBase3
            /// </summary>
            public const string CustomerRetainageTaxBase3 = "TXBSERT3TC";

            /// <summary>
            /// Property for CustRetainageTaxBase4
            /// </summary>
            public const string CustomerRetainageTaxBase4 = "TXBSERT4TC";

            /// <summary>
            /// Property for CustRetainageTaxBase5
            /// </summary>
            public const string CustomerRetainageTaxBase5 = "TXBSERT5TC";

            /// <summary>
            /// Property for CustRetainageTaxAmount1
            /// </summary>
            public const string CustomerRetainageTaxAmount1 = "TXAMTRT1TC";

            /// <summary>
            /// Property for CustRetainageTaxAmount2
            /// </summary>
            public const string CustomerRetainageTaxAmount2 = "TXAMTRT2TC";

            /// <summary>
            /// Property for CustRetainageTaxAmount3
            /// </summary>
            public const string CustomerRetainageTaxAmount3 = "TXAMTRT3TC";

            /// <summary>
            /// Property for CustRetainageTaxAmount4
            /// </summary>
            public const string CustomerRetainageTaxAmount4 = "TXAMTRT4TC";

            /// <summary>
            /// Property for CustRetainageTaxAmount5
            /// </summary>
            public const string CustomerRetainageTaxAmount5 = "TXAMTRT5TC";

            /// <summary>
            /// Property for FuncRetainageTaxAmount1
            /// </summary>
            public const string FunctionalRetainageTaxAmount1 = "TXAMTRT1HC";

            /// <summary>
            /// Property for FuncRetainageTaxAmount2
            /// </summary>
            public const string FunctionalRetainageTaxAmount2 = "TXAMTRT2HC";

            /// <summary>
            /// Property for FuncRetainageTaxAmount3
            /// </summary>
            public const string FunctionalRetainageTaxAmount3 = "TXAMTRT3HC";

            /// <summary>
            /// Property for FuncRetainageTaxAmount4
            /// </summary>
            public const string FunctionalRetainageTaxAmount4 = "TXAMTRT4HC";

            /// <summary>
            /// Property for FuncRetainageTaxAmount5
            /// </summary>
            public const string FunctionalRetainageTaxAmount5 = "TXAMTRT5HC";

            /// <summary>
            /// Property for LastAppliedPaymentSeqNo
            /// </summary>
            public const string LastAppliedPaymentSeqNo = "CNTLASTSEQ";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of OpenDocumentDetail Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 2;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 3;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 4;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 5;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 6;

            /// <summary>
            /// Property Indexer for ProjectCategoryResource
            /// </summary>
            public const int ProjectCategoryResource = 7;

            /// <summary>
            /// Property Indexer for TransactionNumber
            /// </summary>
            public const int TransactionNumber = 8;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 9;

            /// <summary>
            /// Property Indexer for DistributionCode
            /// </summary>
            public const int DistributionCode = 10;

            /// <summary>
            /// Property Indexer for GLAccount
            /// </summary>
            public const int GLAccount = 11;

            /// <summary>
            /// Property Indexer for CustCurrencyInvoiceAmount
            /// </summary>
            public const int CustomerCurrencyInvoiceAmount = 12;

            /// <summary>
            /// Property Indexer for CustCurrencyAmountDue
            /// </summary>
            public const int CustomerCurrencyAmountDue = 13;

            /// <summary>
            /// Property Indexer for FuncCurrencyInvoiceAmount
            /// </summary>
            public const int FunctionalCurrencyInvoiceAmount = 14;

            /// <summary>
            /// Property Indexer for FuncCurrencyAmountDue
            /// </summary>
            public const int FunctionalCurrencyAmountDue = 15;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 16;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 17;

            /// <summary>
            /// Property Indexer for Quantity
            /// </summary>
            public const int Quantity = 18;

            /// <summary>
            /// Property Indexer for Cost
            /// </summary>
            public const int Cost = 19;

            /// <summary>
            /// Property Indexer for BillingDate
            /// </summary>
            public const int BillingDate = 20;

            /// <summary>
            /// Property Indexer for Discountable
            /// </summary>
            public const int Discountable = 21;

            /// <summary>
            /// Property Indexer for DateRetainageDue
            /// </summary>
            public const int DateRetainageDue = 22;

            /// <summary>
            /// Property Indexer for FuncCurrOrigRtngAmt
            /// </summary>
            public const int FunctionalCurrencyOrigRtngAmt = 23;

            /// <summary>
            /// Property Indexer for FuncCurrRetainageAmount
            /// </summary>
            public const int FunctionalCurrencyRetainageAmount = 24;

            /// <summary>
            /// Property Indexer for CustCurrOrigRtngAmt
            /// </summary>
            public const int CustomerCurrencyOrigRtngAmt = 25;

            /// <summary>
            /// Property Indexer for CustCurrRetainageAmount
            /// </summary>
            public const int CustomerCurrencyRetainageAmount = 26;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 27;

            /// <summary>
            /// Property Indexer for RetainageDistributionAmount
            /// </summary>
            public const int RetainageDistributionAmount = 28;

            /// <summary>
            /// Property Indexer for RetainageCOGSAmount
            /// </summary>
            public const int RetainageCOGSAmount = 29;

            /// <summary>
            /// Property Indexer for RetainageAlternateBaseAmount
            /// </summary>
            public const int RetainageAlternateBaseAmount = 30;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 31;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 32;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 33;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 34;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 35;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 36;

            /// <summary>
            /// Property Indexer for TaxIncluded2
            /// </summary>
            public const int TaxIncluded2 = 37;

            /// <summary>
            /// Property Indexer for TaxIncluded3
            /// </summary>
            public const int TaxIncluded3 = 38;

            /// <summary>
            /// Property Indexer for TaxIncluded4
            /// </summary>
            public const int TaxIncluded4 = 39;

            /// <summary>
            /// Property Indexer for TaxIncluded5
            /// </summary>
            public const int TaxIncluded5 = 40;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 41;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 42;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 43;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 44;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 45;

            /// <summary>
            /// Property Indexer for CustRetainageTaxBase1
            /// </summary>
            public const int CustomerRetainageTaxBase1 = 46;

            /// <summary>
            /// Property Indexer for CustRetainageTaxBase2
            /// </summary>
            public const int CustomerRetainageTaxBase2 = 47;

            /// <summary>
            /// Property Indexer for CustRetainageTaxBase3
            /// </summary>
            public const int CustomerRetainageTaxBase3 = 48;
                             
            /// <summary>
            /// Property Indexer for CustRetainageTaxBase4
            /// </summary>
            public const int CustomerRetainageTaxBase4 = 49;
                             
            /// <summary>
            /// Property Indexer for CustRetainageTaxBase5
            /// </summary>
            public const int CustomerRetainageTaxBase5 = 50;
                             
            /// <summary>
            /// Property Indexer for CustRetainageTaxAmount1
            /// </summary>
            public const int CustomerRetainageTaxAmount1 = 51;
                             
            /// <summary>
            /// Property Indexer for CustRetainageTaxAmount2
            /// </summary>
            public const int CustomerRetainageTaxAmount2 = 52;
                             
            /// <summary>
            /// Property Indexer for CustRetainageTaxAmount3
            /// </summary>
            public const int CustomerRetainageTaxAmount3 = 53;
                             
            /// <summary>
            /// Property Indexer for CustRetainageTaxAmount4
            /// </summary>
            public const int CustomerRetainageTaxAmount4 = 54;

            /// <summary>
            /// Property Indexer for CustRetainageTaxAmount5
            /// </summary>
            public const int CustomerRetainageTaxAmount5 = 55;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount1
            /// </summary>
            public const int FunctionalRetainageTaxAmount1 = 56;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount2
            /// </summary>
            public const int FunctionalRetainageTaxAmount2 = 57;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount3
            /// </summary>
            public const int FunctionalRetainageTaxAmount3 = 58;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount4
            /// </summary>
            public const int FunctionalRetainageTaxAmount4 = 59;

            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount5
            /// </summary>
            public const int FunctionalRetainageTaxAmount5 = 60;

            /// <summary>
            /// Property Indexer for LastAppliedPaymentSeqNo
            /// </summary>
            public const int LastAppliedPaymentSeqNo = 61;

        }
        #endregion

    }
}
