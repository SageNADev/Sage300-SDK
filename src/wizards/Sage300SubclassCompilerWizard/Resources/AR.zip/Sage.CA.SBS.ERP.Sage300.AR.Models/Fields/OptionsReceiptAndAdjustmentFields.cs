// /* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Receipt and Adjustment Options Constants 
    /// </summary>
    public partial class OptionsReceiptAndAdjustment
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0003";

        /// <summary>
        /// Contains list of ReceiptandAdjustmentOptions Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Receipt Or Adjustment Options Key 
            /// </summary>
            public const string ReceiptOrAdjustmentOptionsKey = "IDR03";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATEMNTN";

            /// <summary>
            /// Property for Next Receipt Batch Number 
            /// </summary>
            public const string NextReceiptBatchNumber = "PAYMBTCH";

            /// <summary>
            /// Property for Next Adjustment Batch Number 
            /// </summary>
            public const string NextAdjustmentBatchNumber = "ADJBTCH";

            /// <summary>
            /// Property for ADJTRX 
            /// </summary>
            public const string ADJTRX = "ADJTRX";

            /// <summary>
            /// Property for Default Payment Code 
            /// </summary>
            public const string DefaultPaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for Default Bank Code 
            /// </summary>
            public const string DefaultBankCode = "BANKID";

            /// <summary>
            /// Property for Allow Printing of Deposit Slips 
            /// </summary>
            public const string AllowPrintingofDepositSlips = "PRTDEPS";

            /// <summary>
            /// Property for Edit After Dep Slip Printed 
            /// </summary>
            public const string EditAfterDepSlipPrinted = "PAYMEDIT";

            /// <summary>
            /// Property for Force Printing of Deposit Slips 
            /// </summary>
            public const string ForcePrintingofDepositSlips = "PAYMPOST";

            /// <summary>
            /// Property for Default Order of Open Documents 
            /// </summary>
            public const string DefaultOrderofOpenDocuments = "OBLORDR";

            /// <summary>
            /// Property for Next Receipt Posting Sequence 
            /// </summary>
            public const string NextReceiptPostingSeq = "ATRPAYMSEQ";

            /// <summary>
            /// Property for Next Adjustment Posting Sequence 
            /// </summary>
            public const string NextAdjustmentPostingSeq = "ATRADJSEQ";

            /// <summary>
            /// Property for Prepayment Prefix 
            /// </summary>
            public const string PrepaymentPrefix = "PPDPREFIX";

            /// <summary>
            /// Property for Prepayment Number Length 
            /// </summary>
            public const string PrepaymentNumberLength = "PPDPFXLEN";

            /// <summary>
            /// Property for Next Prepayment Number 
            /// </summary>
            public const string NextPrepaymentNumber = "CNTPPDSEQ";

            /// <summary>
            /// Property for Unapplied Cash Prefix 
            /// </summary>
            public const string UnappliedCashPrefix = "UCPREFIX";

            /// <summary>
            /// Property for Unapplied Cash Number Length 
            /// </summary>
            public const string UnappliedCashNumberLength = "UCPFXLEN";

            /// <summary>
            /// Property for Next Unapplied Cash Number 
            /// </summary>
            public const string NextUnappliedCashNumber = "CNTUCSEQ";

            /// <summary>
            /// Property for DFRATETYPE 
            /// </summary>
            public const string DFRATETYPE = "DFRATETYPE";

            /// <summary>
            /// Property for Allow Adjustment in Receipt Batch 
            /// </summary>
            public const string AllowAdjinReceiptBatch = "SWALOWADJ";

            /// <summary>
            /// Property for Adjustment Prefix 
            /// </summary>
            public const string AdjustmentPrefix = "ADPREFIX";

            /// <summary>
            /// Property for Adjustment Number Length 
            /// </summary>
            public const string AdjustmentNumberLength = "ADPFXLEN";

            /// <summary>
            /// Property for Next Adjustment Number 
            /// </summary>
            public const string NextAdjustmentNumber = "CNTADSEQ";

            /// <summary>
            /// Property for Default Transaction Type 
            /// </summary>
            public const string DefaultTransactionType = "RMITTYPE";

            /// <summary>
            /// Property for Next Statement Number 
            /// </summary>
            public const string NextStatementNumber = "STMTSEQ";

            /// <summary>
            /// Property for Receipt Prefix 
            /// </summary>
            public const string ReceiptPrefix = "PYPREFIX";

            /// <summary>
            /// Property for Receipt Number Length 
            /// </summary>
            public const string ReceiptNumberLength = "PYPFXLEN";

            /// <summary>
            /// Property for Next Receipt Number 
            /// </summary>
            public const string NextReceiptNumber = "CNTPYSEQ";

            /// <summary>
            /// Property for Next Refund Batch Number 
            /// </summary>
            public const string NextRefundBatchNumber = "RFBTCH";

            /// <summary>
            /// Property for Refund Prefix 
            /// </summary>
            public const string RefundPrefix = "RFPREFIX";

            /// <summary>
            /// Property for Refund Number Length 
            /// </summary>
            public const string RefundNumberLength = "RFPFXLEN";

            /// <summary>
            /// Property for Next Refund Number 
            /// </summary>
            public const string NextRefundNumber = "CNTRFSEQ";

            /// <summary>
            /// Property for Next Refund Posting Sequence 
            /// </summary>
            public const string NextRefundPostingSeq = "ATRRFSEQ";

            /// <summary>
            /// Property for Edit After Receipt Printed 
            /// </summary>
            public const string EditAfterReceiptPrinted = "SWALOWRCED";

            /// <summary>
            /// Property for Create Deposit Automatically 
            /// </summary>
            public const string CreateDepositAutomatically = "SWCREATDEP";

            /// <summary>
            /// Property for Check for Duplicate Checks 
            /// </summary>
            public const string CheckforDuplicateChecks = "SWCHKDUP";

            /// <summary>
            /// Property for Include Pending Transactions 
            /// </summary>
            public const string IncludePendingTransactions = "SWSHRCPND";

            /// <summary>
            /// Property for Default Posting Date 
            /// </summary>
            public const string DefaultPostingDate = "SWDATEBUS";

            /// <summary>
            /// Property for Sort Checks By 
            /// </summary>
            public const string SortChecksBy = "SORTCHKBY";

            /// <summary>
            /// Property for Payments Acceptance Default Bank Code
            /// </summary>
            public const string PaymentsAcceptanceDefaultBankCode = "SFPABANKID";

            /// <summary>
            /// Property for Payments Acceptance Enabled
            /// </summary>
            public const string PaymentsAcceptanceEnabled = "SFPAENABLE";

            #endregion
        }

        /// <summary>
        /// Contains list of Receipt and Adjustment Options Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Receipt Or Adjustment Options Key 
            /// </summary>
            public const int ReceiptOrAdjustmentOptionsKey = 1;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for Next Receipt Batch Number 
            /// </summary>
            public const int NextReceiptBatchNumber = 3;

            /// <summary>
            /// Property Indexer for Next Adjustment Batch Number 
            /// </summary>
            public const int NextAdjustmentBatchNumber = 4;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for ADJTRX 
            /// </summary>
            public const int ADJTRX = 5;

            /// <summary>
            /// Property Indexer for Default Payment Code 
            /// </summary>
            public const int DefaultPaymentCode = 6;

            /// <summary>
            /// Property Indexer for Default Bank Code 
            /// </summary>
            public const int DefaultBankCode = 7;

            /// <summary>
            /// Property Indexer for Allow Printing of Deposit Slips 
            /// </summary>
            public const int AllowPrintingofDepositSlips = 8;

            /// <summary>
            /// Property Indexer for Edit After Deposit Slip Printed 
            /// </summary>
            public const int EditAfterDepSlipPrinted = 9;

            /// <summary>
            /// Property Indexer for Force Printing of Deposit Slips 
            /// </summary>
            public const int ForcePrintingofDepositSlips = 10;

            /// <summary>
            /// Property Indexer for Default Order of Open Documents 
            /// </summary>
            public const int DefaultOrderofOpenDocuments = 11;

            /// <summary>
            /// Property Indexer for Next Receipt Posting Seq 
            /// </summary>
            public const int NextReceiptPostingSeq = 12;

            /// <summary>
            /// Property Indexer for Next Adjustment Posting Seq 
            /// </summary>
            public const int NextAdjustmentPostingSeq = 13;

            /// <summary>
            /// Property Indexer for Prepayment Prefix 
            /// </summary>
            public const int PrepaymentPrefix = 14;

            /// <summary>
            /// Property Indexer for Prepayment Number Length 
            /// </summary>
            public const int PrepaymentNumberLength = 15;

            /// <summary>
            /// Property Indexer for Next  Prepayment Number 
            /// </summary>
            public const int NextPrepaymentNumber = 16;

            /// <summary>
            /// Property Indexer for Unapplied Cash Prefix 
            /// </summary>
            public const int UnappliedCashPrefix = 17;

            /// <summary>
            /// Property Indexer for Unapplied Cash Number Length 
            /// </summary>
            public const int UnappliedCashNumberLength = 18;

            /// <summary>
            /// Property Indexer for Next Unapplied Cash Number 
            /// </summary>
            public const int NextUnappliedCashNumber = 19;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for DFRATETYPE 
            /// </summary>
            public const int DFRATETYPE = 20;

            /// <summary>
            /// Property Indexer for Allow Adjustment in ReceiptBatch 
            /// </summary>
            public const int AllowAdjinReceiptBatch = 21;

            /// <summary>
            /// Property Indexer for Adjustment Prefix 
            /// </summary>
            public const int AdjustmentPrefix = 22;

            /// <summary>
            /// Property Indexer for Adjustment Number Length 
            /// </summary>
            public const int AdjustmentNumberLength = 23;

            /// <summary>
            /// Property Indexer for Next Adjustment Number 
            /// </summary>
            public const int NextAdjustmentNumber = 24;

            /// <summary>
            /// Property Indexer for Default Transaction Type 
            /// </summary>
            public const int DefaultTransactionType = 25;

            /// <summary>
            /// Property Indexer for Next Statement Number 
            /// </summary>
            public const int NextStatementNumber = 26;

            /// <summary>
            /// Property Indexer for Receipt Prefix 
            /// </summary>
            public const int ReceiptPrefix = 27;

            /// <summary>
            /// Property Indexer for Receipt Number Length 
            /// </summary>
            public const int ReceiptNumberLength = 28;

            /// <summary>
            /// Property Indexer for Next Receipt Number 
            /// </summary>
            public const int NextReceiptNumber = 29;

            /// <summary>
            /// Property Indexer for Next Refund Batch Number 
            /// </summary>
            public const int NextRefundBatchNumber = 30;

            /// <summary>
            /// Property Indexer for Refund Prefix 
            /// </summary>
            public const int RefundPrefix = 31;

            /// <summary>
            /// Property Indexer for Refund Number Length 
            /// </summary>
            public const int RefundNumberLength = 32;

            /// <summary>
            /// Property Indexer for Next Refund Number 
            /// </summary>
            public const int NextRefundNumber = 33;

            /// <summary>
            /// Property Indexer for Next Refund Posting Sequence 
            /// </summary>
            public const int NextRefundPostingSeq = 34;

            /// <summary>
            /// Property Indexer for Edit After Receipt Printed 
            /// </summary>
            public const int EditAfterReceiptPrinted = 35;

            /// <summary>
            /// Property Indexer for Create Deposit Automatically 
            /// </summary>
            public const int CreateDepositAutomatically = 36;

            /// <summary>
            /// Property Indexer for Check for Duplicate Checks 
            /// </summary>
            public const int CheckforDuplicateChecks = 37;

            /// <summary>
            /// Property Indexer for Include Pending Transactions 
            /// </summary>
            public const int IncludePendingTransactions = 38;

            /// <summary>
            /// Property Indexer for Default Posting Date 
            /// </summary>
            public const int DefaultPostingDate = 39;

            /// <summary>
            /// Property Indexer for Sort Checks By 
            /// </summary>
            public const int SortChecksBy = 40;

            /// <summary>
            /// Property Indexer for Payments Acceptance Default Bank Code
            /// </summary>
            public const int PaymentsAcceptanceDefaultBankCode = 41;

            /// <summary>
            /// Property Indexer for Payments Acceptance Enabled
            /// </summary>
            public const int PaymentsAcceptanceEnabled = 80;

            #endregion
        }
    }
}