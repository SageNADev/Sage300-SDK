﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class PostingJournal
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0409";

        /// <summary>
        /// Contains list of PostingJournals Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "TYPEBTCH";
            /// <summary>
            /// Property for PostingSequenceNo 
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNCE";
            /// <summary>
            /// Property for SystemDate 
            /// </summary>
            public const string SystemDate = "DATEPOSTED";
            /// <summary>
            /// Property for DatePostedinAOrR 
            /// </summary>
            public const string DatePostedinAOrR = "DATEBUS";
            /// <summary>
            /// Property for Printed? 
            /// </summary>
            public const string Printed = "SWPRINTED";
            /// <summary>
            /// Property for PostedtoGOrL? 
            /// </summary>
            public const string PostedtoGOrL = "SWPOSTGL";
            /// <summary>
            /// Property for DatePostedtoGOrL 
            /// </summary>
            public const string DatePostedtoGOrL = "DATEPOSTGL";
            /// <summary>
            /// Property for ConsolidatedforGOrL? 
            /// </summary>
            public const string ConsolidatedforGOrL = "SWGLCONSL";
            /// <summary>
            /// Property for ProgramVersion 
            /// </summary>
            public const string ProgramVersion = "PGMVER";

            #endregion
        }


        /// <summary>
        /// Contains list of PostingJournals Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for PostingSequenceNo 
            /// </summary>
            public const int PostingSequenceNo = 2;
            /// <summary>
            /// Property Indexer for SystemDate 
            /// </summary>
            public const int SystemDate = 3;
            /// <summary>
            /// Property Indexer for DatePostedinAOrR 
            /// </summary>
            public const int DatePostedinAOrR = 4;
            /// <summary>
            /// Property Indexer for Printed? 
            /// </summary>
            public const int Printed = 5;
            /// <summary>
            /// Property Indexer for PostedtoGOrL? 
            /// </summary>
            public const int PostedtoGOrL = 6;
            /// <summary>
            /// Property Indexer for DatePostedtoGOrL 
            /// </summary>
            public const int DatePostedtoGOrL = 7;
            /// <summary>
            /// Property Indexer for ConsolidatedforGOrL? 
            /// </summary>
            public const int ConsolidatedforGOrL = 8;
            /// <summary>
            /// Property Indexer for ProgramVersion 
            /// </summary>
            public const int ProgramVersion = 9;

            #endregion
        }

    }
}
