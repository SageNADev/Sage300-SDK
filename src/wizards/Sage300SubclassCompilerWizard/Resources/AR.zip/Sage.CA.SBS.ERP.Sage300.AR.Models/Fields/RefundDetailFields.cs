// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
	/// <summary>
	/// Contains list of RefundDetail Constants
	/// </summary>
	public partial class RefundDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "AR0142";

		#region Properties Fields

		/// <summary>
		/// Contains list of RefundDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBTCH";

			/// <summary>
			/// Property for EntryNumber
			/// </summary>
			public const string EntryNumber = "CNTITEM";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "CNTLINE";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "IDINVC";

			/// <summary>
			/// Property for PaymentNumber
			/// </summary>
			public const string PaymentNumber = "CNTPAYM";

			/// <summary>
			/// Property for PaymentType
			/// </summary>
			public const string PaymentType = "PAYMTYPE";

			/// <summary>
			/// Property for CcBankAccount
			/// </summary>
			public const string CcBankAccount = "IDBANK";

			/// <summary>
			/// Property for CcBankSerialNumber
			/// </summary>
			public const string CcBankSerialNumber = "LONGSERIAL";

			/// <summary>
			/// Property for CcPaymentCurrency
			/// </summary>
			public const string CcPaymentCurrency = "CODECURN";

			/// <summary>
			/// Property for CcRateType
			/// </summary>
			public const string CcRateType = "RATETYPE";

			/// <summary>
			/// Property for CcRateDate
			/// </summary>
			public const string CcRateDate = "RATEDATE";

			/// <summary>
			/// Property for CcExchangeRate
			/// </summary>
			public const string CcExchangeRate = "RATEEXCH";

			/// <summary>
			/// Property for CcRateOperator
			/// </summary>
			public const string CcRateOperator = "RATEOP";

			/// <summary>
			/// Property for CcRateOverrideFlag
			/// </summary>
			public const string CcRateOverrideFlag = "SWRATE";

			/// <summary>
			/// Property for AmountPayment
			/// </summary>
			public const string AmountPayment = "AMTPC";

			/// <summary>
			/// Property for AmountCustomer
			/// </summary>
			public const string AmountCustomer = "AMTTC";

			/// <summary>
			/// Property for AmountFunctional
			/// </summary>
			public const string AmountFunctional = "AMTHC";

			/// <summary>
			/// Property for JobRelated
			/// </summary>
			public const string JobRelated = "SWJOB";

			/// <summary>
			/// Property for JobApplyMethod
			/// </summary>
			public const string JobApplyMethod = "APPLYMETH";

			/// <summary>
			/// Property for JobAppliedAmount
			/// </summary>
			public const string JobAppliedAmount = "AMTJOB";

			/// <summary>
			/// Property for DocumentType
			/// </summary>
			public const string DocumentType = "TRXTYPETXT";

			/// <summary>
			/// Property for DocumentDate
			/// </summary>
			public const string DocumentDate = "DATEINVC";

			/// <summary>
			/// Property for OriginalAmount
			/// </summary>
			public const string OriginalAmount = "ORGDOCAMT";

			/// <summary>
			/// Property for CurrentBalance
			/// </summary>
			public const string CurrentBalance = "CURBAL";

			/// <summary>
			/// Property for PendingBalance
			/// </summary>
			public const string PendingBalance = "PNDBAL";

			/// <summary>
			/// Property for NetBalance
			/// </summary>
			public const string NetBalance = "NETBAL";

			/// <summary>
			/// Property for UnappliedJobAmount
			/// </summary>
			public const string UnappliedJobAmount = "UNAPLAMT";

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "IDCUST";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

			/// <summary>
			/// Property for ReceiptDocumentNumber
			/// </summary>
			public const string ReceiptDocumentNumber = "CCRCPTNO";

		}

		#endregion

		#region Properties Index

		/// <summary>
		/// Contains list of RefundDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 1;

			/// <summary>
			/// Property Indexer for EntryNumber
			/// </summary>
			public const int EntryNumber = 2;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 3;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 4;

			/// <summary>
			/// Property Indexer for PaymentNumber
			/// </summary>
			public const int PaymentNumber = 5;

			/// <summary>
			/// Property Indexer for PaymentType
			/// </summary>
			public const int PaymentType = 6;

			/// <summary>
			/// Property Indexer for CcBankAccount
			/// </summary>
			public const int CcBankAccount = 7;

			/// <summary>
			/// Property Indexer for CcBankSerialNumber
			/// </summary>
			public const int CcBankSerialNumber = 8;

			/// <summary>
			/// Property Indexer for CcPaymentCurrency
			/// </summary>
			public const int CcPaymentCurrency = 9;

			/// <summary>
			/// Property Indexer for CcRateType
			/// </summary>
			public const int CcRateType = 10;

			/// <summary>
			/// Property Indexer for CcRateDate
			/// </summary>
			public const int CcRateDate = 11;

			/// <summary>
			/// Property Indexer for CcExchangeRate
			/// </summary>
			public const int CcExchangeRate = 12;

			/// <summary>
			/// Property Indexer for CcRateOperator
			/// </summary>
			public const int CcRateOperator = 13;

			/// <summary>
			/// Property Indexer for CcRateOverrideFlag
			/// </summary>
			public const int CcRateOverrideFlag = 14;

			/// <summary>
			/// Property Indexer for AmountPayment
			/// </summary>
			public const int AmountPayment = 20;

			/// <summary>
			/// Property Indexer for AmountCustomer
			/// </summary>
			public const int AmountCustomer = 21;

			/// <summary>
			/// Property Indexer for AmountFunctional
			/// </summary>
			public const int AmountFunctional = 22;

			/// <summary>
			/// Property Indexer for JobRelated
			/// </summary>
			public const int JobRelated = 23;

			/// <summary>
			/// Property Indexer for JobApplyMethod
			/// </summary>
			public const int JobApplyMethod = 24;

			/// <summary>
			/// Property Indexer for JobAppliedAmount
			/// </summary>
			public const int JobAppliedAmount = 25;

			/// <summary>
			/// Property Indexer for DocumentType
			/// </summary>
			public const int DocumentType = 50;

			/// <summary>
			/// Property Indexer for DocumentDate
			/// </summary>
			public const int DocumentDate = 51;

			/// <summary>
			/// Property Indexer for OriginalAmount
			/// </summary>
			public const int OriginalAmount = 52;

			/// <summary>
			/// Property Indexer for CurrentBalance
			/// </summary>
			public const int CurrentBalance = 53;

			/// <summary>
			/// Property Indexer for PendingBalance
			/// </summary>
			public const int PendingBalance = 54;

			/// <summary>
			/// Property Indexer for NetBalance
			/// </summary>
			public const int NetBalance = 55;

			/// <summary>
			/// Property Indexer for UnappliedJobAmount
			/// </summary>
			public const int UnappliedJobAmount = 56;

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 57;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 59;

			/// <summary>
			/// Property Indexer for ReceiptDocumentNumber
			/// </summary>
			public const int ReceiptDocumentNumber = 60;

		}

		#endregion

	}
}
