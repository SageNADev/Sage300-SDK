// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of National Account Constants 
    /// </summary>
    public partial class NationalAccount
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0028";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of National Account Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for National Account Number 
            /// </summary>
            public const string NationalAccountNumber = "IDNATACCT";

            /// <summary>
            /// Property for Group Code 
            /// </summary>
            public const string GroupCode = "IDGRP";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for Inactive Date 
            /// </summary>
            public const string InactiveDate = "DATEINAC";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATELSTMTN";

            /// <summary>
            /// Property for On Hold 
            /// </summary>
            public const string OnHold = "SWHOLD";

            /// <summary>
            /// Property for Credit Bureau Number 
            /// </summary>
            public const string CreditBureauNumber = "CODEDAB";

            /// <summary>
            /// Property for Credit Bureau Rating 
            /// </summary>
            public const string CreditBureauRating = "DABRTG";

            /// <summary>
            /// Property for Credit Bureau Date 
            /// </summary>
            public const string CreditBureauDate = "DATEDAB";

            /// <summary>
            /// Property for National Account Name 
            /// </summary>
            public const string NationalAccountName = "NAMEACCT";

            /// <summary>
            /// Property for Address Line1 
            /// </summary>
            public const string AddressLine1 = "TEXTSTRE1";

            /// <summary>
            /// Property for Address Line2 
            /// </summary>
            public const string AddressLine2 = "TEXTSTRE2";

            /// <summary>
            /// Property for Address Line3 
            /// </summary>
            public const string AddressLine3 = "TEXTSTRE3";

            /// <summary>
            /// Property for Address Line4 
            /// </summary>
            public const string AddressLine4 = "TEXTSTRE4";

            /// <summary>
            /// Property for City 
            /// </summary>
            public const string City = "NAMECITY";

            /// <summary>
            /// Property for State Or Prov 
            /// </summary>
            public const string StateOrProv = "CODESTATE";

            /// <summary>
            /// Property for Zip Or PostalCode 
            /// </summary>
            public const string ZipOrPostalCode = "CODEPOST";

            /// <summary>
            /// Property for Country 
            /// </summary>
            public const string Country = "CODECTRY";

            /// <summary>
            /// Property for Contact Name 
            /// </summary>
            public const string ContactName = "NAMECTAC";

            /// <summary>
            /// Property for Phone Number 
            /// </summary>
            public const string PhoneNumber = "TEXTPHON1";

            /// <summary>
            /// Property for Fax Number 
            /// </summary>
            public const string FaxNumber = "TEXTPHON2";

            /// <summary>
            /// Property for Account Set 
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            /// <summary>
            /// Property for Autocash Profile 
            /// </summary>
            public const string AutocashProfile = "IDAUTOCASH";

            /// <summary>
            /// Property for Billing Cycle 
            /// </summary>
            public const string BillingCycle = "IDBILLCYCL";

            /// <summary>
            /// Property for Interest Profile 
            /// </summary>
            public const string InterestProfile = "IDSVCCHRG";

            /// <summary>
            /// Property for Currency Code 
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for Print Statements 
            /// </summary>
            public const string PrintStatements = "SWPRTSTMT";

            /// <summary>
            /// Property for Account Type 
            /// </summary>
            public const string AccountType = "SWBALFWD";

            /// <summary>
            /// Property for Rate Type 
            /// </summary>
            public const string RateType = "IDRATETYPE";

            /// <summary>
            /// Property for Credit Limit 
            /// </summary>
            public const string CreditLimit = "AMTCRLIMIT";

            /// <summary>
            /// Property for Balance Due in Cust Currency 
            /// </summary>
            public const string BalanceDueinCustCurrency = "AMTBALDUTC";

            /// <summary>
            /// Property for Balance Due in Func Currency 
            /// </summary>
            public const string BalanceDueinFuncCurrency = "AMTBALDUHC";

            /// <summary>
            /// Property for Date of Last Statement 
            /// </summary>
            public const string DateofLastStatement = "DATELSTSTM";

            /// <summary>
            /// Property for Last Statement Total Cust Curr 
            /// </summary>
            public const string LastStatementTotalCustCurr = "AMTLSTSTTC";

            /// <summary>
            /// Property for Last Statement Total Func Curr 
            /// </summary>
            public const string LastStatementTotalFuncCurr = "AMTLSTSTHC";

            /// <summary>
            /// Property for Date Balance Forward Begins 
            /// </summary>
            public const string DateBalanceForwardBegins = "DATEBALFWD";

            /// <summary>
            /// Property for Balance Forward Cust Curr 
            /// </summary>
            public const string BalanceForwardCustCurr = "AMTBLFWDTC";

            /// <summary>
            /// Property for Balance Forward Func Curr 
            /// </summary>
            public const string BalanceForwardFuncCurr = "AMTBLFWDHC";

            /// <summary>
            /// Property for Number of Open Documents 
            /// </summary>
            public const string NumberofOpenDocuments = "CNTOPENINV";

            /// <summary>
            /// Property for Number of Paid Invoices 
            /// </summary>
            public const string NumberofPaidInvoices = "CNTINVPAID";

            /// <summary>
            /// Property for Number of Days to Pay 
            /// </summary>
            public const string NumberofDaystoPay = "CNTDAYSPAY";

            /// <summary>
            /// Property for Average Days to Pay 
            /// </summary>
            public const string AverageDaystoPay = "AVGDAYSPAY";

            /// <summary>
            /// Property for Date of Largest Invoice 
            /// </summary>
            public const string DateofLargestInvoice = "DATEINVCHI";

            /// <summary>
            /// Property for Date of Highest Balance 
            /// </summary>
            public const string DateofHighestBalance = "DATEBALHI";

            /// <summary>
            /// Property for Date of Largest Invoice Last Yr 
            /// </summary>
            public const string DateofLargestInvoiceLastYr = "DATEINVHIL";

            /// <summary>
            /// Property for Date of Highest Bal Last Yr 
            /// </summary>
            public const string DateofHighestBalLastYr = "DATEBALHIL";

            /// <summary>
            /// Property for Date of Last Activity 
            /// </summary>
            public const string DateofLastActivity = "DATELASTAC";

            /// <summary>
            /// Property for Date of Last Invoice 
            /// </summary>
            public const string DateofLastInvoice = "DATELASTIN";

            /// <summary>
            /// Property for Date of Last Credit Note 
            /// </summary>
            public const string DateofLastCreditNote = "DATELASTCR";

            /// <summary>
            /// Property for Date of Last Debit Note 
            /// </summary>
            public const string DateofLastDebitNote = "DATELASTDR";

            /// <summary>
            /// Property for Date of Last Receipt 
            /// </summary>
            public const string DateofLastReceipt = "DATELASTPA";

            /// <summary>
            /// Property for Date of Last Discount 
            /// </summary>
            public const string DateofLastDiscount = "DATELASTDI";

            /// <summary>
            /// Property for Date of Last Adjustment 
            /// </summary>
            public const string DateofLastAdjustment = "DATELASTAD";

            /// <summary>
            /// Property for Date of Last Write Off 
            /// </summary>
            public const string DateofLastWriteOff = "DATELASTWR";

            /// <summary>
            /// Property for Date of Last Returned Check 
            /// </summary>
            public const string DateofLastReturnedCheck = "DATELASTRI";

            /// <summary>
            /// Property for Date of Last Interest Charge 
            /// </summary>
            public const string DateofLastInterestCharge = "DATELSTINT";

            /// <summary>
            /// Property for Largest Invoice Number 
            /// </summary>
            public const string LargestInvoiceNumber = "IDINVCHIGH";

            /// <summary>
            /// Property for Largest Invoice Number Last Yr 
            /// </summary>
            public const string LargestInvoiceNumberLastYr = "IDINVCHILY";

            /// <summary>
            /// Property for Largest Invoice Cust Curr 
            /// </summary>
            public const string LargestInvoiceCustCurr = "AMTINVHITC";

            /// <summary>
            /// Property for Highest Balance Cust Curr 
            /// </summary>
            public const string HighestBalanceCustCurr = "AMTBALHITC";

            /// <summary>
            /// Property for Lgst Inv Last Yr Cust Curr 
            /// </summary>
            public const string LgstInvLastYrCustCurr = "AMTINVHLIT";

            /// <summary>
            /// Property for High Bal Last Yr Cust Curr 
            /// </summary>
            public const string HighBalLastYrCustCurr = "AMTBALHILT";

            /// <summary>
            /// Property for Last Invoice Amt Cust Curr 
            /// </summary>
            public const string LastInvoiceAmtCustCurr = "AMTINVTC";

            /// <summary>
            /// Property for Last Cr Note Amt Cust Curr 
            /// </summary>
            public const string LastCrNoteAmtCustCurr = "AMTCRTC";

            /// <summary>
            /// Property for Last Dr Note Amt Cust Curr 
            /// </summary>
            public const string LastDrNoteAmtCustCurr = "AMTDRTC";

            /// <summary>
            /// Property for Last Receipt Cust Curr 
            /// </summary>
            public const string LastReceiptCustCurr = "AMTPAYMTC";

            /// <summary>
            /// Property for Last Discount Amt Cust Curr 
            /// </summary>
            public const string LastDiscountAmtCustCurr = "AMTDISCTC";

            /// <summary>
            /// Property for Last Adj Amt Cust Curr 
            /// </summary>
            public const string LastAdjAmtCustCurr = "AMTADJTC";

            /// <summary>
            /// Property for Last Write Off Amt Cust Curr 
            /// </summary>
            public const string LastWriteOffAmtCustCurr = "AMTWROFTC";

            /// <summary>
            /// Property for Last Retd Chk Amt Cust Curr 
            /// </summary>
            public const string LastRetdChkAmtCustCurr = "AMTRIFTC";

            /// <summary>
            /// Property for Last Int Charge Cust Curr 
            /// </summary>
            public const string LastIntChargeCustCurr = "AMTINTTTC";

            /// <summary>
            /// Property for Largest Invoice Func Curr 
            /// </summary>
            public const string LargestInvoiceFuncCurr = "AMTINVHIHC";

            /// <summary>
            /// Property for Highest Balance Func Curr 
            /// </summary>
            public const string HighestBalanceFuncCurr = "AMTBALHIHC";

            /// <summary>
            /// Property for Lgst Inv Last Yr Func Curr 
            /// </summary>
            public const string LgstInvLastYrFuncCurr = "AMTINVHILH";

            /// <summary>
            /// Property for High Bal Last Yr Func Curr 
            /// </summary>
            public const string HighBalLastYrFuncCurr = "AMTBALHILH";

            /// <summary>
            /// Property for Last Invoice Amt Func Curr 
            /// </summary>
            public const string LastInvoiceAmtFuncCurr = "AMTINVHC";

            /// <summary>
            /// Property for Last Cr Note Amt Func Curr 
            /// </summary>
            public const string LastCrNoteAmtFuncCurr = "AMTCRHC";

            /// <summary>
            /// Property for Last Dr Note Amt Func Curr 
            /// </summary>
            public const string LastDrNoteAmtFuncCurr = "AMTDRHC";

            /// <summary>
            /// Property for Last Receipt Func Curr 
            /// </summary>
            public const string LastReceiptFuncCurr = "AMTPAYMHC";

            /// <summary>
            /// Property for Last Discount Amt Func Curr 
            /// </summary>
            public const string LastDiscountAmtFuncCurr = "AMTDISCHC";

            /// <summary>
            /// Property for Last Adj Amt Func Curr 
            /// </summary>
            public const string LastAdjAmtFuncCurr = "AMTADJHC";

            /// <summary>
            /// Property for Last Write Off Amt Func Curr 
            /// </summary>
            public const string LastWriteOffAmtFuncCurr = "AMTWROFHC";

            /// <summary>
            /// Property for Last Retd Chk Amt Func Curr 
            /// </summary>
            public const string LastRetdChkAmtFuncCurr = "AMTRIFHC";

            /// <summary>
            /// Property for Last Int Charge Func Curr 
            /// </summary>
            public const string LastIntChargeFuncCurr = "AMTINTTHC";

            /// <summary>
            /// Property for Email 
            /// </summary>
            public const string Email = "EMAIL";

            /// <summary>
            /// Property for Web Site 
            /// </summary>
            public const string WebSite = "WEBSITE";

            /// <summary>
            /// Property for Contacts Phone 
            /// </summary>
            public const string ContactsPhone = "CTACPHONE";

            /// <summary>
            /// Property for Contacts Fax 
            /// </summary>
            public const string ContactsFax = "CTACFAX";

            /// <summary>
            /// Property for Contacts Email 
            /// </summary>
            public const string ContactsEmail = "CTACEMAIL";

            /// <summary>
            /// Property for Delivery Method 
            /// </summary>
            public const string DeliveryMethod = "DELMETHOD";

            /// <summary>
            /// Property for Amount Retained Cust Curr 
            /// </summary>
            public const string AmountRetainedCustCurr = "RTGAMTTC";

            /// <summary>
            /// Property for Amount Retained Func Curr 
            /// </summary>
            public const string AmountRetainedFuncCurr = "RTGAMTHC";

            /// <summary>
            /// Property for Optional Fields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Process Command Code 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for Date of Last Refund 
            /// </summary>
            public const string DateofLastRefund = "DATELASTRF";

            /// <summary>
            /// Property for Last Refund Amt Cust Curr 
            /// </summary>
            public const string LastRefundAmtCustCurr = "AMTLASTRFT";

            /// <summary>
            /// Property for Last Refund Amt Func Curr 
            /// </summary>
            public const string LastRefundAmtFuncCurr = "AMTLASTRFH";

            /// <summary>
            /// Property for Check Credit Limit 
            /// </summary>
            public const string CheckCreditLimit = "SWCHKLIMIT";

            /// <summary>
            /// Property for Check Overdue Amounts 
            /// </summary>
            public const string CheckOverdueAmounts = "SWCHKOVER";

            /// <summary>
            /// Property for Days Overdue 
            /// </summary>
            public const string DaysOverdue = "OVERDAYS";

            /// <summary>
            /// Property for Amount Overdue 
            /// </summary>
            public const string AmountOverdue = "OVERAMT";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of NationalAccounts Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for NationalAccountNumber 
            /// </summary>
            public const int NationalAccountNumber = 1;

            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
            public const int GroupCode = 2;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for Inactive Date 
            /// </summary>
            public const int InactiveDate = 4;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 5;

            /// <summary>
            /// Property Indexer for On Hold 
            /// </summary>
            public const int OnHold = 6;

            /// <summary>
            /// Property Indexer for Credit Bureau Number 
            /// </summary>
            public const int CreditBureauNumber = 7;

            /// <summary>
            /// Property Indexer for CreditBureauRating 
            /// </summary>
            public const int CreditBureauRating = 8;

            /// <summary>
            /// Property Indexer for Credit Bureau Date 
            /// </summary>
            public const int CreditBureauDate = 9;

            /// <summary>
            /// Property Indexer for National Account Name 
            /// </summary>
            public const int NationalAccountName = 10;

            /// <summary>
            /// Property Indexer for Address Line1 
            /// </summary>
            public const int AddressLine1 = 11;

            /// <summary>
            /// Property Indexer for Address Line2 
            /// </summary>
            public const int AddressLine2 = 12;

            /// <summary>
            /// Property Indexer for Address Line3 
            /// </summary>
            public const int AddressLine3 = 13;

            /// <summary>
            /// Property Indexer for Address Line4 
            /// </summary>
            public const int AddressLine4 = 14;

            /// <summary>
            /// Property Indexer for City 
            /// </summary>
            public const int City = 15;

            /// <summary>
            /// Property Indexer for State Or Prov 
            /// </summary>
            public const int StateOrProv = 16;

            /// <summary>
            /// Property Indexer for Zip Or Postal Code 
            /// </summary>
            public const int ZipOrPostalCode = 17;

            /// <summary>
            /// Property Indexer for Country 
            /// </summary>
            public const int Country = 18;

            /// <summary>
            /// Property Indexer for Contact Name 
            /// </summary>
            public const int ContactName = 19;

            /// <summary>
            /// Property Indexer for Phone Number 
            /// </summary>
            public const int PhoneNumber = 20;

            /// <summary>
            /// Property Indexer for Fax Number 
            /// </summary>
            public const int FaxNumber = 21;

            /// <summary>
            /// Property Indexer for Account Set 
            /// </summary>
            public const int AccountSet = 22;

            /// <summary>
            /// Property Indexer for Autocash Profile 
            /// </summary>
            public const int AutocashProfile = 23;

            /// <summary>
            /// Property Indexer for Billing Cycle 
            /// </summary>
            public const int BillingCycle = 24;

            /// <summary>
            /// Property Indexer for Interest Profile 
            /// </summary>
            public const int InterestProfile = 25;

            /// <summary>
            /// Property Indexer for Currency Code 
            /// </summary>
            public const int CurrencyCode = 27;

            /// <summary>
            /// Property Indexer for Print Statements 
            /// </summary>
            public const int PrintStatements = 28;

            /// <summary>
            /// Property Indexer for Account Type 
            /// </summary>
            public const int AccountType = 30;

            /// <summary>
            /// Property Indexer for Rate Type 
            /// </summary>
            public const int RateType = 31;

            /// <summary>
            /// Property Indexer for Credit Limit 
            /// </summary>
            public const int CreditLimit = 32;

            /// <summary>
            /// Property Indexer for Balance Due in Cust Currency 
            /// </summary>
            public const int BalanceDueinCustCurrency = 33;

            /// <summary>
            /// Property Indexer for Balance Due in Func Currency 
            /// </summary>
            public const int BalanceDueinFuncCurrency = 34;

            /// <summary>
            /// Property Indexer for Date of Last Statement 
            /// </summary>
            public const int DateofLastStatement = 35;

            /// <summary>
            /// Property Indexer for Last Statement Total Cust Curr 
            /// </summary>
            public const int LastStatementTotalCustCurr = 36;

            /// <summary>
            /// Property Indexer for Last Statement Total Func Curr 
            /// </summary>
            public const int LastStatementTotalFuncCurr = 37;

            /// <summary>
            /// Property Indexer for Date Balance Forward Begins 
            /// </summary>
            public const int DateBalanceForwardBegins = 38;

            /// <summary>
            /// Property Indexer for Balance Forward Cust Curr 
            /// </summary>
            public const int BalanceForwardCustCurr = 39;

            /// <summary>
            /// Property Indexer for Balance Forward Func Curr 
            /// </summary>
            public const int BalanceForwardFuncCurr = 40;

            /// <summary>
            /// Property Indexer for Number of Open Documents 
            /// </summary>
            public const int NumberofOpenDocuments = 43;

            /// <summary>
            /// Property Indexer for Number of Paid Invoices 
            /// </summary>
            public const int NumberofPaidInvoices = 44;

            /// <summary>
            /// Property Indexer for Number of Days to Pay 
            /// </summary>
            public const int NumberofDaystoPay = 45;

            /// <summary>
            /// Property Indexer for Average Days to Pay 
            /// </summary>
            public const int AverageDaystoPay = 46;

            /// <summary>
            /// Property Indexer for Date of Largest Invoice 
            /// </summary>
            public const int DateofLargestInvoice = 47;

            /// <summary>
            /// Property Indexer for Date of Highest Balance 
            /// </summary>
            public const int DateofHighestBalance = 48;

            /// <summary>
            /// Property Indexer for Date of Largest Invoice Last Yr 
            /// </summary>
            public const int DateofLargestInvoiceLastYr = 49;

            /// <summary>
            /// Property Indexer for Date of Highest Bal Last Yr 
            /// </summary>
            public const int DateofHighestBalLastYr = 50;

            /// <summary>
            /// Property Indexer for Date of Last Activity 
            /// </summary>
            public const int DateofLastActivity = 51;

            /// <summary>
            /// Property Indexer for Date of Last Invoice 
            /// </summary>
            public const int DateofLastInvoice = 52;

            /// <summary>
            /// Property Indexer for Date of Last Credit Note 
            /// </summary>
            public const int DateofLastCreditNote = 53;

            /// <summary>
            /// Property Indexer for Date of Last Debit Note 
            /// </summary>
            public const int DateofLastDebitNote = 54;

            /// <summary>
            /// Property Indexer for Date of Last Receipt 
            /// </summary>
            public const int DateofLastReceipt = 55;

            /// <summary>
            /// Property Indexer for Date of Last Discount 
            /// </summary>
            public const int DateofLastDiscount = 56;

            /// <summary>
            /// Property Indexer for Date of Last Adjustment 
            /// </summary>
            public const int DateofLastAdjustment = 57;

            /// <summary>
            /// Property Indexer for Date of Last Write Off 
            /// </summary>
            public const int DateofLastWriteOff = 58;

            /// <summary>
            /// Property Indexer for Date of Last Returned Check 
            /// </summary>
            public const int DateofLastReturnedCheck = 59;

            /// <summary>
            /// Property Indexer for Date of Last Interest Charge 
            /// </summary>
            public const int DateofLastInterestCharge = 60;

            /// <summary>
            /// Property Indexer for Largest Invoice Number 
            /// </summary>
            public const int LargestInvoiceNumber = 62;

            /// <summary>
            /// Property Indexer for Largest Invoice Number Last Yr 
            /// </summary>
            public const int LargestInvoiceNumberLastYr = 63;

            /// <summary>
            /// Property Indexer for Largest Invoice Cust Curr 
            /// </summary>
            public const int LargestInvoiceCustCurr = 64;

            /// <summary>
            /// Property Indexer for Highest Balance Cust Curr 
            /// </summary>
            public const int HighestBalanceCustCurr = 65;

            /// <summary>
            /// Property Indexer for Lgst Inv Last Yr Cust Curr 
            /// </summary>
            public const int LgstInvLastYrCustCurr = 66;

            /// <summary>
            /// Property Indexer for High Bal Last Yr Cust Curr 
            /// </summary>
            public const int HighBalLastYrCustCurr = 67;

            /// <summary>
            /// Property Indexer for Last Invoice Amt Cust Curr 
            /// </summary>
            public const int LastInvoiceAmtCustCurr = 68;

            /// <summary>
            /// Property Indexer for Last Cr Note Amt Cust Curr 
            /// </summary>
            public const int LastCrNoteAmtCustCurr = 69;

            /// <summary>
            /// Property Indexer for Last Dr Note Amt Cust Curr 
            /// </summary>
            public const int LastDrNoteAmtCustCurr = 70;

            /// <summary>
            /// Property Indexer for Last Receipt Cust Curr 
            /// </summary>
            public const int LastReceiptCustCurr = 71;

            /// <summary>
            /// Property Indexer for Last Discount Amt Cust Curr 
            /// </summary>
            public const int LastDiscountAmtCustCurr = 72;

            /// <summary>
            /// Property Indexer for Last Adj Amt Cust Curr 
            /// </summary>
            public const int LastAdjAmtCustCurr = 73;

            /// <summary>
            /// Property Indexer for Last Write Off Amt Cust Curr 
            /// </summary>
            public const int LastWriteOffAmtCustCurr = 74;

            /// <summary>
            /// Property Indexer for Last Retd Chk Amt Cust Curr 
            /// </summary>
            public const int LastRetdChkAmtCustCurr = 75;

            /// <summary>
            /// Property Indexer for Last Int Charge Cust Curr 
            /// </summary>
            public const int LastIntChargeCustCurr = 76;

            /// <summary>
            /// Property Indexer for Largest Invoice Func Curr 
            /// </summary>
            public const int LargestInvoiceFuncCurr = 77;

            /// <summary>
            /// Property Indexer for Highest Balance Func Curr 
            /// </summary>
            public const int HighestBalanceFuncCurr = 78;

            /// <summary>
            /// Property Indexer for Lgst Inv Last Yr Func Curr 
            /// </summary>
            public const int LgstInvLastYrFuncCurr = 79;

            /// <summary>
            /// Property Indexer for High Bal Last Yr Func Curr 
            /// </summary>
            public const int HighBalLastYrFuncCurr = 80;

            /// <summary>
            /// Property Indexer for Last Invoice Amt Func Curr 
            /// </summary>
            public const int LastInvoiceAmtFuncCurr = 81;

            /// <summary>
            /// Property Indexer for Last Cr Note Amt Func Curr 
            /// </summary>
            public const int LastCrNoteAmtFuncCurr = 82;

            /// <summary>
            /// Property Indexer for Last Dr Note Amt Func Curr 
            /// </summary>
            public const int LastDrNoteAmtFuncCurr = 83;

            /// <summary>
            /// Property Indexer for Last Receipt Func Curr 
            /// </summary>
            public const int LastReceiptFuncCurr = 84;

            /// <summary>
            /// Property Indexer for Last Discount Amt Func Curr 
            /// </summary>
            public const int LastDiscountAmtFuncCurr = 85;

            /// <summary>
            /// Property Indexer for Last Adj Amt Func Curr 
            /// </summary>
            public const int LastAdjAmtFuncCurr = 86;

            /// <summary>
            /// Property Indexer for Last Write Off Amt Func Curr 
            /// </summary>
            public const int LastWriteOffAmtFuncCurr = 87;

            /// <summary>
            /// Property Indexer for Last Retd Chk Amt Func Curr 
            /// </summary>
            public const int LastRetdChkAmtFuncCurr = 88;

            /// <summary>
            /// Property Indexer for Last Int Charge Func Curr 
            /// </summary>
            public const int LastIntChargeFuncCurr = 89;

            /// <summary>
            /// Property Indexer for Email 
            /// </summary>
            public const int Email = 98;

            /// <summary>
            /// Property Indexer for Web Site 
            /// </summary>
            public const int WebSite = 99;

            /// <summary>
            /// Property Indexer for Contacts Phone 
            /// </summary>
            public const int ContactsPhone = 100;

            /// <summary>
            /// Property Indexer for Contacts Fax 
            /// </summary>
            public const int ContactsFax = 101;

            /// <summary>
            /// Property Indexer for Contacts Email 
            /// </summary>
            public const int ContactsEmail = 102;

            /// <summary>
            /// Property Indexer for Delivery Method 
            /// </summary>
            public const int DeliveryMethod = 103;

            /// <summary>
            /// Property Indexer for Amount Retained Cust Curr 
            /// </summary>
            public const int AmountRetainedCustCurr = 104;

            /// <summary>
            /// Property Indexer for Amount Retained Func Curr 
            /// </summary>
            public const int AmountRetainedFuncCurr = 105;

            /// <summary>
            /// Property Indexer for Optional Fields 
            /// </summary>
            public const int OptionalFields = 106;

            /// <summary>
            /// Property Indexer for Process Command Code 
            /// </summary>
            public const int ProcessCommandCode = 107;

            /// <summary>
            /// Property Indexer for Date of Last Refund 
            /// </summary>
            public const int DateofLastRefund = 108;

            /// <summary>
            /// Property Indexer for Last Refund Amt Cust Curr 
            /// </summary>
            public const int LastRefundAmtCustCurr = 109;

            /// <summary>
            /// Property Indexer for Last Refund Amt Func Curr 
            /// </summary>
            public const int LastRefundAmtFuncCurr = 110;

            /// <summary>
            /// Property Indexer for Check Credit Limit 
            /// </summary>
            public const int CheckCreditLimit = 111;

            /// <summary>
            /// Property Indexer for Check Overdue Amounts 
            /// </summary>
            public const int CheckOverdueAmounts = 112;

            /// <summary>
            /// Property Indexer for Days Overdue 
            /// </summary>
            public const int DaysOverdue = 113;

            /// <summary>
            /// Property Indexer for Amount Overdue 
            /// </summary>
            public const int AmountOverdue = 114;

            #endregion
        }

        #endregion
    }
}