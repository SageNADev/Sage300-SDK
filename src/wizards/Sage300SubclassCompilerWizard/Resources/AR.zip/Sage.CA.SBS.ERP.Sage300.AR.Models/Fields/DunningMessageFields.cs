/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of DunningMessages Constants 
    /// </summary>
    public partial class DunningMessage
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0008";

        /// <summary>
        /// Contains list of DunningMessages Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for DunningMessageCode 
            /// </summary>
            public const string DunningMessageCode = "CODESTMT";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTIVESW";

            /// <summary>
            /// Property for Status String
            /// Added for Finder Filter
            /// </summary>
            public const string StatusString = "ACTIVESW";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINAC";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DTELSTMNTN";
            /// <summary>
            /// Property for CurrentMessage 
            /// </summary>
            public const string CurrentMessage = "TEXTSTMT1";
            /// <summary>
            /// Property for Period1Message 
            /// </summary>
            public const string Period1Message = "TEXTSTMT2";
            /// <summary>
            /// Property for Period2Message 
            /// </summary>
            public const string Period2Message = "TEXTSTMT3";
            /// <summary>
            /// Property for Period3Message 
            /// </summary>
            public const string Period3Message = "TEXTSTMT4";
            /// <summary>
            /// Property for OverPeriod3Message 
            /// </summary>
            public const string OverPeriod3Message = "TEXTSTMT5";

            #endregion
        }


        /// <summary>
        /// Contains list of DunningMessages Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for DunningMessageCode 
            /// </summary>
            public const int DunningMessageCode = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;
            /// <summary>
            /// Property Indexer for CurrentMessage 
            /// </summary>
            public const int CurrentMessage = 6;
            /// <summary>
            /// Property Indexer for Period1Message 
            /// </summary>
            public const int Period1Message = 7;
            /// <summary>
            /// Property Indexer for Period2Message 
            /// </summary>
            public const int Period2Message = 8;
            /// <summary>
            /// Property Indexer for Period3Message 
            /// </summary>
            public const int Period3Message = 9;
            /// <summary>
            /// Property Indexer for OverPeriod3Message 
            /// </summary>
            public const int OverPeriod3Message = 10;

            #endregion
        }


    }
}
