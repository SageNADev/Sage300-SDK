// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Contains list of DocumentDetailPayment Constants
	/// </summary>
	public partial class DocumentDetailPayment
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AR0088";

		#region Properties

		/// <summary>
		/// Contains list of DocumentDetailPayment Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "IDCUST";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "IDINVC";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "CNTLINE";

			/// <summary>
			/// Property for SequenceNumber
			/// </summary>
			public const string SequenceNumber = "CNTSEQENCE";

			/// <summary>
			/// Property for TransactionNumber
			/// </summary>
			public const string TransactionNumber = "TRANSNBR";

			/// <summary>
			/// Property for PostingDate
			/// </summary>
			public const string PostingDate = "DATEBUS";

			/// <summary>
			/// Property for DocumentType
			/// </summary>
			public const string DocumentType = "TRANSTYPE";

			/// <summary>
			/// Property for TransactionType
			/// </summary>
			public const string TransactionType = "TRXTYPE";

			/// <summary>
			/// Property for BatchType
			/// </summary>
			public const string BatchType = "TYPEBTCH";

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBTCH";

			/// <summary>
			/// Property for EntryNumber
			/// </summary>
			public const string EntryNumber = "CNTITEM";

			/// <summary>
			/// Property for BatchDate
			/// </summary>
			public const string BatchDate = "DATEBTCH";

			/// <summary>
			/// Property for FuncReceiptAmount
			/// </summary>
			public const string FunctionalReceiptAmount = "AMTPAYMHC";

			/// <summary>
			/// Property for CustReceiptAmount
			/// </summary>
			public const string CustomerReceiptAmount = "AMTPAYMTC";

			/// <summary>
			/// Property for FuncRetainageTaxInvoiced
			/// </summary>
			public const string FunctionalRetainageTaxInvoiced = "TXTOTRTHC";

			/// <summary>
			/// Property for CustRetainageTaxInvoiced
			/// </summary>
			public const string CustomerRetainageTaxInvoiced = "TXTOTRTTC";

			/// <summary>
			/// Property for CurrencyCode
			/// </summary>
			public const string CurrencyCode = "CODECURN";

			/// <summary>
			/// Property for RateType
			/// </summary>
			public const string RateType = "IDRATETYPE";

			/// <summary>
			/// Property for ExchangeRate
			/// </summary>
			public const string ExchangeRate = "RATEEXCHHC";

			/// <summary>
			/// Property for RateDate
			/// </summary>
			public const string RateDate = "RATEDATE";

			/// <summary>
			/// Property for RateOperator
			/// </summary>
			public const string RateOperator = "RATEOP";

			/// <summary>
			/// Property for BankCode
			/// </summary>
			public const string BankCode = "IDBANK";

			/// <summary>
			/// Property for RemittingCustomerNumber
			/// </summary>
			public const string RemittingCustomerNumber = "IDCUSTRMIT";

			/// <summary>
			/// Property for CheckReceiptNo
			/// </summary>
			public const string CheckReceiptNo = "IDRMIT";

			/// <summary>
			/// Property for DepositSerialNumber
			/// </summary>
			public const string DepositSerialNumber = "DEPSEQ";

			/// <summary>
			/// Property for DepositLineNumber
			/// </summary>
			public const string DepositLineNumber = "DEPLINE";

			/// <summary>
			/// Property for ReceiptDate
			/// </summary>
			public const string ReceiptDate = "DATERMIT";

			/// <summary>
			/// Property for PaymentCUID
			/// </summary>
            public const string PaymentCustomerId = "PYMCUID";

			/// <summary>
			/// Property for ReferenceDocumentNumber
			/// </summary>
			public const string ReferenceDocumentNumber = "IDMEMOXREF";

			/// <summary>
			/// Property for FiscalYear
			/// </summary>
			public const string FiscalYear = "FISCYR";

			/// <summary>
			/// Property for FiscalPeriod
			/// </summary>
			public const string FiscalPeriod = "FISCPER";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of DocumentDetailPayment Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 1;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 2;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 3;

			/// <summary>
			/// Property Indexer for SequenceNumber
			/// </summary>
			public const int SequenceNumber = 4;

			/// <summary>
			/// Property Indexer for TransactionNumber
			/// </summary>
			public const int TransactionNumber = 5;

			/// <summary>
			/// Property Indexer for PostingDate
			/// </summary>
			public const int PostingDate = 6;

			/// <summary>
			/// Property Indexer for DocumentType
			/// </summary>
			public const int DocumentType = 7;

			/// <summary>
			/// Property Indexer for TransactionType
			/// </summary>
			public const int TransactionType = 8;

			/// <summary>
			/// Property Indexer for BatchType
			/// </summary>
			public const int BatchType = 9;

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 10;

			/// <summary>
			/// Property Indexer for EntryNumber
			/// </summary>
			public const int EntryNumber = 11;

			/// <summary>
			/// Property Indexer for BatchDate
			/// </summary>
			public const int BatchDate = 12;

			/// <summary>
			/// Property Indexer for FuncReceiptAmount
			/// </summary>
            public const int FunctionalReceiptAmount = 13;

			/// <summary>
			/// Property Indexer for CustReceiptAmount
			/// </summary>
            public const int CustomerReceiptAmount = 14;

			/// <summary>
			/// Property Indexer for FuncRetainageTaxInvoiced
			/// </summary>
            public const int FunctionalRetainageTaxInvoiced = 15;

			/// <summary>
			/// Property Indexer for CustRetainageTaxInvoiced
			/// </summary>
            public const int CustomerRetainageTaxInvoiced = 16;

			/// <summary>
			/// Property Indexer for CurrencyCode
			/// </summary>
			public const int CurrencyCode = 17;

			/// <summary>
			/// Property Indexer for RateType
			/// </summary>
			public const int RateType = 18;

			/// <summary>
			/// Property Indexer for ExchangeRate
			/// </summary>
			public const int ExchangeRate = 19;

			/// <summary>
			/// Property Indexer for RateDate
			/// </summary>
			public const int RateDate = 20;

			/// <summary>
			/// Property Indexer for RateOperator
			/// </summary>
			public const int RateOperator = 21;

			/// <summary>
			/// Property Indexer for BankCode
			/// </summary>
			public const int BankCode = 22;

			/// <summary>
			/// Property Indexer for RemittingCustomerNumber
			/// </summary>
			public const int RemittingCustomerNumber = 23;

			/// <summary>
			/// Property Indexer for CheckReceiptNo
			/// </summary>
			public const int CheckReceiptNo = 24;

			/// <summary>
			/// Property Indexer for DepositSerialNumber
			/// </summary>
			public const int DepositSerialNumber = 25;

			/// <summary>
			/// Property Indexer for DepositLineNumber
			/// </summary>
			public const int DepositLineNumber = 26;

			/// <summary>
			/// Property Indexer for ReceiptDate
			/// </summary>
			public const int ReceiptDate = 27;

			/// <summary>
			/// Property Indexer for PaymentCUID
			/// </summary>
            public const int PaymentCustomerId = 28;

			/// <summary>
			/// Property Indexer for ReferenceDocumentNumber
			/// </summary>
			public const int ReferenceDocumentNumber = 29;

			/// <summary>
			/// Property Indexer for FiscalYear
			/// </summary>
			public const int FiscalYear = 30;

			/// <summary>
			/// Property Indexer for FiscalPeriod
			/// </summary>
			public const int FiscalPeriod = 31;

		}

		#endregion

	}
}
