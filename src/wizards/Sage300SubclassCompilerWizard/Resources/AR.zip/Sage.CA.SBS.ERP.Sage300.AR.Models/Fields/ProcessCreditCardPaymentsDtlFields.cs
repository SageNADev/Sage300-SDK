// Copyright © 2016 Sage Software, Inc

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of ProcessCreditCardPaymentsDtl Constants
    /// </summary>
    public partial class ProcessCreditCardPaymentsDtl
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0211";


        #region Properties

        /// <summary>
        /// Contains list of ProcessCreditCardPaymentsDtl Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Customer
            /// </summary>
            public const string Customer = "IDCUST";

            /// <summary>
            /// Property for Document
            /// </summary>
            public const string Document = "IDINVC";

            /// <summary>
            /// Property for Payment
            /// </summary>
            public const string Payment = "CNTPAYM";

            /// <summary>
            /// Property for ProcessingCode
            /// </summary>
            public const string ProcessingCode = "YPPROCCODE";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "CUSTNAME";

            /// <summary>
            /// Property for AmountDue
            /// </summary>
            public const string AmountDue = "AMTDIST";

            /// <summary>
            /// Property for DiscountAmount
            /// </summary>
            public const string DiscountAmount = "AMTDISC";

            /// <summary>
            /// Property for PaymentAmount
            /// </summary>
            public const string PaymentAmount = "AMTPAYM";

            /// <summary>
            /// Property for DocumentDate
            /// </summary>
            public const string DocumentDate = "DATEINVC";

            /// <summary>
            /// Property for DiscountDate
            /// </summary>
            public const string DiscountDate = "DATEDISC";

            /// <summary>
            /// Property for DueDate
            /// </summary>
            public const string DueDate = "DATEDUE";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CODECURN";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "STATUS";

            /// <summary>
            /// Property for Apply
            /// </summary>
            public const string Apply = "SWAPPLY";

        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ProcessCreditCardPaymentsDtl Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for Customer
            /// </summary>
            public const int Customer = 1;

            /// <summary>
            /// Property Indexer for Document
            /// </summary>
            public const int Document = 2;

            /// <summary>
            /// Property Indexer for Payment
            /// </summary>
            public const int Payment = 3;

            /// <summary>
            /// Property Indexer for ProcessingCode
            /// </summary>
            public const int ProcessingCode = 4;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 5;

            /// <summary>
            /// Property Indexer for AmountDue
            /// </summary>
            public const int AmountDue = 6;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 7;

            /// <summary>
            /// Property Indexer for PaymentAmount
            /// </summary>
            public const int PaymentAmount = 8;

            /// <summary>
            /// Property Indexer for DocumentDate
            /// </summary>
            public const int DocumentDate = 9;

            /// <summary>
            /// Property Indexer for DiscountDate
            /// </summary>
            public const int DiscountDate = 10;

            /// <summary>
            /// Property Indexer for DueDate
            /// </summary>
            public const int DueDate = 11;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 12;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 13;

            /// <summary>
            /// Property Indexer for Apply
            /// </summary>
            public const int Apply = 15;


        }

        #endregion

    }
}