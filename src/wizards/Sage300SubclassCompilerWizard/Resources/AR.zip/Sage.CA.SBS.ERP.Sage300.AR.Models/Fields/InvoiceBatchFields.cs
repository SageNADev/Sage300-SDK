/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of InvoiceBatches Constants 
    /// </summary>
    public partial class InvoiceBatch
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0031";

        /// <summary>
        /// Contains list of InvoiceBatches Fields Constants
        /// </summary>
        public class Fields : BaseFields
        {
            #region Properties

            /// <summary>
            /// Property for ProcessCommand 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            #endregion
        }

        /// <summary>
        /// Contains list of InvoiceBatches Index Constants
        /// </summary>
        public class Index : BaseIndex
        {
            #region Properties

            /// <summary>
            /// Property Indexer for ProcessCommand 
            /// </summary>
            public const int ProcessCommand = 15;

            #endregion
        }
    }
}
