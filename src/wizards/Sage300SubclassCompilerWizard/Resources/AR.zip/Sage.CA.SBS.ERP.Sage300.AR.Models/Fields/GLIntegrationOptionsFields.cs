// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of G/L Integration Options Constants 
    /// </summary>
    public partial class GLIntegrationOptions
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0006";

        /// <summary>
        /// Contains list of G/L Integration Options Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for Integration Options Key 
            /// </summary>
            public const string IntegrationOptionsKey = "IDR06";
            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";
            /// <summary>
            /// Property for DeferCreateGLBatch 
            /// </summary>
            public const string DeferCreateGLBatch = "SWGLPSTDFR";
            /// <summary>
            /// Property for Create GL Transactions By 
            /// </summary>
            public const string CreateGLTransactionsBy = "SWGLAPDBTH";
            /// <summary>
            /// Property for Consolidate GL Transactions 
            /// </summary>
            public const string ConsolidateGLTransactions = "SWGLPSTCON";
            /// <summary>
            /// Property for Last Receipt Posting Sequence To GL 
            /// </summary>
            public const string LastReceiptPostingSeqToGL = "GLPAYMPOST";
            /// <summary>
            /// Property for Last Invoice Posting Sequence To GL 
            /// </summary>
            public const string LastInvoicePostingSeqToGL = "GLINVCPOST";
            /// <summary>
            /// Property for Last Adj Posting Sequence To GL 
            /// </summary>
            public const string LastAdjPostingSeqToGL = "GLADJPOST";
            /// <summary>
            /// Property for Last Reval Posting Sequence To GL 
            /// </summary>
            public const string LastRevalPostingSeqToGL = "GLRVALPOST";
            /// <summary>
            /// Property for Last Refund Posting Sequence To GL 
            /// </summary>
            public const string LastRefundPostingSeqToGL = "GLRFPOST";
            /// <summary>
            /// Property for GL Src Code Invoice 
            /// </summary>
            public const string GLSrcCodeInvoice = "SRCTYPEIN";
            /// <summary>
            /// Property for GL Src Code Debit Note 
            /// </summary>
            public const string GLSrcCodeDebitNote = "SRCTYPEDB";
            /// <summary>
            /// Property for GL Src Code Credit Note 
            /// </summary>
            public const string GLSrcCodeCreditNote = "SRCTYPECR";
            /// <summary>
            /// Property for GL Src Code Interest 
            /// </summary>
            public const string GLSrcCodeInterest = "SRCTYPEIT";
            /// <summary>
            /// Property for GL Src Code Payment Received 
            /// </summary>
            public const string GLSrcCodePaymentReceived = "SRCTYPEPY";
            /// <summary>
            /// Property for GL Src Code Discount 
            /// </summary>
            public const string GLSrcCodeDiscount = "SRCTYPEED";
            /// <summary>
            /// Property for GL Src Code Revaluation 
            /// </summary>
            public const string GLSrcCodeRevaluation = "SRCTYPEGL";
            /// <summary>
            /// Property for GL Src Code Adjustment 
            /// </summary>
            public const string GLSrcCodeAdjustment = "SRCTYPEAD";
            /// <summary>
            /// Property for GL Src Code Consolidation 
            /// </summary>
            public const string GLSrcCodeConsolidation = "SRCTYPECO";
            /// <summary>
            /// Property for GL Src Code Write Off 
            /// </summary>
            public const string GLSrcCodeWriteOff = "SRCTYPEWO";
            /// <summary>
            /// Property for GL Src Code Prepayment 
            /// </summary>
            public const string GLSrcCodePrepayment = "SRCTYPEPI";
            /// <summary>
            /// Property for GL Src Code Unapplied Cash 
            /// </summary>
            public const string GLSrcCodeUnappliedCash = "SRCTYPEUC";
            /// <summary>
            /// Property for GL Src Code Refund 
            /// </summary>
            public const string GLSrcCodeRefund = "SRCTYPERF";
            /// <summary>
            /// Property for GL Src Code Rounding 
            /// </summary>
            public const string GLSrcCodeRounding = "SRCTYPERD";
            /// <summary>
            /// Property for GL Src Code Payment Reversal 
            /// </summary>
            public const string GLSrcCodePaymentReversal = "SRCTYPEPYR";
            /// <summary>
            /// Property for GL Src Code Refund Reversal 
            /// </summary>
            public const string GLSrcCodeRefundReversal = "SRCTYPERFR";
            /// <summary>
            /// Property for Process Command 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            #endregion
        }


        /// <summary>
        /// Contains list of G/L Integration Options Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for Integration Options Key 
            /// </summary>
            public const int IntegrationOptionsKey = 1;
            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 2;
            /// <summary>
            /// Property Indexer for Defer Create GL Batch 
            /// </summary>
            public const int DeferCreateGLBatch = 3;
            /// <summary>
            /// Property Indexer for Create GL Transactions By 
            /// </summary>
            public const int CreateGLTransactionsBy = 4;
            /// <summary>
            /// Property Indexer for Consolidate GL Transactions 
            /// </summary>
            public const int ConsolidateGLTransactions = 5;
            /// <summary>
            /// Property Indexer for Last Receipt Posting Sequence To GL 
            /// </summary>
            public const int LastReceiptPostingSeqToGL = 8;
            /// <summary>
            /// Property Indexer for Last Invoice Posting Sequence To GL 
            /// </summary>
            public const int LastInvoicePostingSeqToGL = 9;
            /// <summary>
            /// Property Indexer for Last Adj Posting Sequence To GL 
            /// </summary>
            public const int LastAdjPostingSeqToGL = 10;
            /// <summary>
            /// Property Indexer for Last Reval Posting Sequence To GL 
            /// </summary>
            public const int LastRevalPostingSeqToGL = 11;
            /// <summary>
            /// Property Indexer for Last Refund Posting Sequence To GL 
            /// </summary>
            public const int LastRefundPostingSeqToGL = 12;
            /// <summary>
            /// Property Indexer for GL Src Code Invoice 
            /// </summary>
            public const int GLSrcCodeInvoice = 13;
            /// <summary>
            /// Property Indexer for GL Src Code Debit Note 
            /// </summary>
            public const int GLSrcCodeDebitNote = 14;
            /// <summary>
            /// Property Indexer for GL Src Code Credi tNote 
            /// </summary>
            public const int GLSrcCodeCreditNote = 15;
            /// <summary>
            /// Property Indexer for GL Src Code Interest 
            /// </summary>
            public const int GLSrcCodeInterest = 16;
            /// <summary>
            /// Property Indexer for GL Src Code Payment Received 
            /// </summary>
            public const int GLSrcCodePaymentReceived = 17;
            /// <summary>
            /// Property Indexer for GL Src Code Discount 
            /// </summary>
            public const int GLSrcCodeDiscount = 18;
            /// <summary>
            /// Property Indexer for GL Src Code Revaluation 
            /// </summary>
            public const int GLSrcCodeRevaluation = 19;
            /// <summary>
            /// Property Indexer for GL Src Code Adjustment 
            /// </summary>
            public const int GLSrcCodeAdjustment = 20;
            /// <summary>
            /// Property Indexer for GL SrcCode Consolidation 
            /// </summary>
            public const int GLSrcCodeConsolidation = 21;
            /// <summary>
            /// Property Indexer for GL Src Code Write Off 
            /// </summary>
            public const int GLSrcCodeWriteOff = 22;
            /// <summary>
            /// Property Indexer for GL Src Code Prepayment 
            /// </summary>
            public const int GLSrcCodePrepayment = 23;
            /// <summary>
            /// Property Indexer for GL Src Code Unapplied Cash 
            /// </summary>
            public const int GLSrcCodeUnappliedCash = 24;
            /// <summary>
            /// Property Indexer for GL Src Code Refund 
            /// </summary>
            public const int GLSrcCodeRefund = 25;
            /// <summary>
            /// Property Indexer for GL Src Code Rounding 
            /// </summary>
            public const int GLSrcCodeRounding = 26;
            /// <summary>
            /// Property Indexer for GL Src Code Payment Reversal 
            /// </summary>
            public const int GLSrcCodePaymentReversal = 27;
            /// <summary>
            /// Property Indexer for GL Src Code Refund Reversal 
            /// </summary>
            public const int GLSrcCodeRefundReversal = 28;
            /// <summary>
            /// Property Indexer for Process Command 
            /// </summary>
            public const int ProcessCommand = 29;

            #endregion
        }


    }
}
