// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Invoicing Options Constants 
    /// </summary>
    public partial class OptionsInvoicing
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0002";

        /// <summary>
        /// Contains list of Invoicing Options Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Invoicing Options Key 
            /// </summary>
            public const string InvoicingOptionsKey = "IDR02";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for Next Invoice Batch Number 
            /// </summary>
            public const string NextInvoiceBatchNumber = "INVCBTCH";

            /// <summary>
            /// Property for Invoice Prefix 
            /// </summary>
            public const string InvoicePrefix = "TEXTIVPF";

            /// <summary>
            /// Property for Invoice Number Length 
            /// </summary>
            public const string InvoiceNumberLength = "CNTIVPFLEN";

            /// <summary>
            /// Property for Next Invoice Number 
            /// </summary>
            public const string NextInvoiceNumber = "CNTIVSEQ";

            /// <summary>
            /// Property for Credit Note Prefix 
            /// </summary>
            public const string CreditNotePrefix = "TEXTCRPF";

            /// <summary>
            /// Property for Credit Note Number Length 
            /// </summary>
            public const string CreditNoteNumberLength = "CNTCRPFLEN";

            /// <summary>
            /// Property for Next Credit Note Number 
            /// </summary>
            public const string NextCreditNoteNumber = "CNTCRSEQ";

            /// <summary>
            /// Property for Debit Note Prefix 
            /// </summary>
            public const string DebitNotePrefix = "TEXTDRPF";

            /// <summary>
            /// Property for Debit Note Number Length 
            /// </summary>
            public const string DebitNoteNumberLength = "CNTDRPFLEN";

            /// <summary>
            /// Property for Next Debit Note Number 
            /// </summary>
            public const string NextDebitNoteNumber = "CNTDRSEQ";

            /// <summary>
            /// Property for Interest Invoice Prefix 
            /// </summary>
            public const string InterestInvoicePrefix = "TEXTITPF";

            /// <summary>
            /// Property for Interest Invoice Number Length 
            /// </summary>
            public const string InterestInvoiceNumberLength = "CNTITPFLEN";

            /// <summary>
            /// Property for Next Interest Invoice Number 
            /// </summary>
            public const string NextInterestInvoiceNumber = "CNTITSEQ";

            /// <summary>
            /// Property for Recurring Charge Prefix 
            /// </summary>
            public const string RecurringChargePrefix = "TEXTRCPF";

            /// <summary>
            /// Property for Recurring Charge Number Length 
            /// </summary>
            public const string RecurringChargeNumberLength = "CNTRCPFLEN";

            /// <summary>
            /// Property for Next Recurring Charge Number 
            /// </summary>
            public const string NextRecurringChargeNumber = "CNTRCSEQ";

            /// <summary>
            /// Property for Invoice Printing 
            /// </summary>
            public const string InvoicePrinting = "SWPRTINVC";

            /// <summary>
            /// Property for SWALOWDISC 
            /// </summary>
            public const string SWALOWDISC = "SWALOWDISC";

            /// <summary>
            /// Property for Edit After Invoice Printed 
            /// </summary>
            public const string EditAfterInvoicePrinted = "SWALOWIVED";

            /// <summary>
            /// Property for SWALOWIVPS 
            /// </summary>
            public const string SWALOWIVPS = "SWALOWIVPS";

            /// <summary>
            /// Property for Use Item Comment as Default 
            /// </summary>
            public const string UseItemCommentasDefault = "SWUSEITCMT";

            /// <summary>
            /// Property for Show Item Cost 
            /// </summary>
            public const string ShowItemCost = "SWDPLYITCS";

            /// <summary>
            /// Property for Next Invoice Posting Sequence Number 
            /// </summary>
            public const string NextInvoicePostingSeqNumber = "ATRINVCSEQ";

            /// <summary>
            /// Property for Manual Tax Processing Default 
            /// </summary>
            public const string ManualTaxProcessingDefault = "SWMANTAX";

            /// <summary>
            /// Property for Default Invoice Type 
            /// </summary>
            public const string DefaultInvoiceType = "INVCTYPE";

            /// <summary>
            /// Property for Use Separate Numbers 
            /// </summary>
            public const string UseSeparateNumbers = "SWUSESDOCS";

            /// <summary>
            /// Property for Retainage Invoice Prefix 
            /// </summary>
            public const string RetainageInvoicePrefix = "TEXTRIPF";

            /// <summary>
            /// Property for Retainage Invoice Length 
            /// </summary>
            public const string RetainageInvoiceLength = "CNTRIPFLEN";

            /// <summary>
            /// Property for Next Retainage Invoice 
            /// </summary>
            public const string NextRetainageInvoice = "CNTRISEQ";

            /// <summary>
            /// Property for Retainage Credit Note Prefix 
            /// </summary>
            public const string RetainageCreditNotePrefix = "TEXTRXPF";

            /// <summary>
            /// Property for Retainage Credit Note Length 
            /// </summary>
            public const string RetainageCreditNoteLength = "CNTRXPFLEN";

            /// <summary>
            /// Property for Next Retainage Credit Note 
            /// </summary>
            public const string NextRetainageCreditNote = "CNTRXSEQ";

            /// <summary>
            /// Property for Retainage Debit Note Prefix 
            /// </summary>
            public const string RetainageDebitNotePrefix = "TEXTRDPF";

            /// <summary>
            /// Property for Retainage Debit Note Length 
            /// </summary>
            public const string RetainageDebitNoteLength = "CNTRDPFLEN";

            /// <summary>
            /// Property for Next Retainage Debit Note 
            /// </summary>
            public const string NextRetainageDebitNote = "CNTRDSEQ";

            /// <summary>
            /// Property for Use Retainage 
            /// </summary>
            public const string UseRetainage = "SWRTG";

            /// <summary>
            /// Property for Retainage Base 
            /// </summary>
            public const string RetainageBase = "SWRTGBASE";

            /// <summary>
            /// Property for Retainage Schedule 
            /// </summary>
            public const string RetainageSchedule = "RTGSCHDKEY";

            /// <summary>
            /// Property for Retainage Schedule Link 
            /// </summary>
            public const string RetainageScheduleLink = "RTGSCHDLNK";

            /// <summary>
            /// Property for Date Retainage Sched Last Run 
            /// </summary>
            public const string DateRetainageSchedLastRun = "RTGLASTRUN";

            /// <summary>
            /// Property for Days Retained 
            /// </summary>
            public const string DaysRetained = "RTGDAYS";

            /// <summary>
            /// Property for Percent Retained 
            /// </summary>
            public const string PercentRetained = "RTGPERCENT";

            /// <summary>
            /// Property for Days Before Retainage Due 
            /// </summary>
            public const string DaysBeforeRetainageDue = "RTGADVDAYS";

            /// <summary>
            /// Property for Retainage Exchange Rate 
            /// </summary>
            public const string RetainageExchangeRate = "SWRTGRATE";

            /// <summary>
            /// Property for Include Pending A/R Transaction
            /// </summary>
            public const string IncludePendingAorRTrans = "SWARPEND";

            /// <summary>
            /// Property for Include Pending O/E Transaction
            /// </summary>
            public const string IncludePendingOorETrans = "SWOEPEND";

            /// <summary>
            /// Property for Include Pending Other Transaction 
            /// </summary>
            public const string IncludePendingOtherTrans = "SWXXPEND";

            /// <summary>
            /// Property for Default Tax Reporting Control 
            /// </summary>
            public const string DefaultTaxReportingControl = "SWTXCTLRC";

            /// <summary>
            /// Property for Report Retainage Tax 
            /// </summary>
            public const string ReportRetainageTax = "SWTXRTGRPT";

            /// <summary>
            /// Property for Default Detail Tax Class 
            /// </summary>
            public const string DefaultDetailTaxClass = "SWTXDTLCLS";

            /// <summary>
            /// Property for Default Posting Date 
            /// </summary>
            public const string DefaultPostingDate = "SWDATEBUS";

            #endregion
        }

        /// <summary>
        /// Contains list of InvoicingOptions Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Invoicing Options Key 
            /// </summary>
            public const int InvoicingOptionsKey = 1;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for Next Invoice Batch Number 
            /// </summary>
            public const int NextInvoiceBatchNumber = 3;

            /// <summary>
            /// Property Indexer for Invoice Prefix 
            /// </summary>
            public const int InvoicePrefix = 4;

            /// <summary>
            /// Property Indexer for Invoice Number Length 
            /// </summary>
            public const int InvoiceNumberLength = 5;

            /// <summary>
            /// Property Indexer for Next Invoice Number 
            /// </summary>
            public const int NextInvoiceNumber = 6;

            /// <summary>
            /// Property Indexer for Credit Note Prefix 
            /// </summary>
            public const int CreditNotePrefix = 7;

            /// <summary>
            /// Property Indexer for Credit Note Number Length 
            /// </summary>
            public const int CreditNoteNumberLength = 8;

            /// <summary>
            /// Property Indexer for Next Credit Note Number 
            /// </summary>
            public const int NextCreditNoteNumber = 9;

            /// <summary>
            /// Property Indexer for Debit Note Prefix 
            /// </summary>
            public const int DebitNotePrefix = 10;

            /// <summary>
            /// Property Indexer for Debit Note Number Length 
            /// </summary>
            public const int DebitNoteNumberLength = 11;

            /// <summary>
            /// Property Indexer for Next Debit Note Number 
            /// </summary>
            public const int NextDebitNoteNumber = 12;

            /// <summary>
            /// Property Indexer for Interest Invoice Prefix 
            /// </summary>
            public const int InterestInvoicePrefix = 13;

            /// <summary>
            /// Property Indexer for Interest Invoice Number Length 
            /// </summary>
            public const int InterestInvoiceNumberLength = 14;

            /// <summary>
            /// Property Indexer for Next Interest Invoice Number 
            /// </summary>
            public const int NextInterestInvoiceNumber = 15;

            /// <summary>
            /// Property Indexer for Recurring Charge Prefix 
            /// </summary>
            public const int RecurringChargePrefix = 16;

            /// <summary>
            /// Property Indexer for Recurring Charge Number Length 
            /// </summary>
            public const int RecurringChargeNumberLength = 17;

            /// <summary>
            /// Property Indexer for Next Recurring Charge Number 
            /// </summary>
            public const int NextRecurringChargeNumber = 18;

            /// <summary>
            /// Property Indexer for Invoice Printing 
            /// </summary>
            public const int InvoicePrinting = 19;

            //TODO: The naming convention of this property has to be relooked                      
            /// <summary>
            /// Property Indexer for SWALOWDISC 
            /// </summary>
            public const int SWALOWDISC = 20;

            /// <summary>
            /// Property Indexer for Edit After Invoice Printed 
            /// </summary>
            public const int EditAfterInvoicePrinted = 21;

            //TODO: The naming convention of this property has to be relooked          
            /// <summary>
            /// Property Indexer for SWALOWIVPS 
            /// </summary>
            public const int SWALOWIVPS = 22;

            /// <summary>
            /// Property Indexer for Use Item Comment as Default 
            /// </summary>
            public const int UseItemCommentasDefault = 23;

            /// <summary>
            /// Property Indexer for Show Item Cost 
            /// </summary>
            public const int ShowItemCost = 24;

            /// <summary>
            /// Property Indexer for Next Invoice Posting Seq Number 
            /// </summary>
            public const int NextInvoicePostingSeqNumber = 49;

            /// <summary>
            /// Property Indexer for Manual Tax Processing Default 
            /// </summary>
            public const int ManualTaxProcessingDefault = 50;

            /// <summary>
            /// Property Indexer for Default Invoice Type 
            /// </summary>
            public const int DefaultInvoiceType = 51;

            /// <summary>
            /// Property Indexer for Use Separate Numbers 
            /// </summary>
            public const int UseSeparateNumbers = 52;

            /// <summary>
            /// Property Indexer for Retainage Invoice Prefix 
            /// </summary>
            public const int RetainageInvoicePrefix = 53;

            /// <summary>
            /// Property Indexer for Retainage Invoice Length 
            /// </summary>
            public const int RetainageInvoiceLength = 54;

            /// <summary>
            /// Property Indexer for Next Retainage Invoice 
            /// </summary>
            public const int NextRetainageInvoice = 55;

            /// <summary>
            /// Property Indexer for Retainage Credit Note Prefix 
            /// </summary>
            public const int RetainageCreditNotePrefix = 56;

            /// <summary>
            /// Property Indexer for Retainage Credit Note Length 
            /// </summary>
            public const int RetainageCreditNoteLength = 57;

            /// <summary>
            /// Property Indexer for Next Retainage Credit Note 
            /// </summary>
            public const int NextRetainageCreditNote = 58;

            /// <summary>
            /// Property Indexer for Retainage Debit Note Prefix 
            /// </summary>
            public const int RetainageDebitNotePrefix = 59;

            /// <summary>
            /// Property Indexer for Retainage Debit Note Length 
            /// </summary>
            public const int RetainageDebitNoteLength = 60;

            /// <summary>
            /// Property Indexer for Next Retainage Debit Note 
            /// </summary>
            public const int NextRetainageDebitNote = 61;

            /// <summary>
            /// Property Indexer for Use Retainage 
            /// </summary>
            public const int UseRetainage = 62;

            /// <summary>
            /// Property Indexer for Retainage Base 
            /// </summary>
            public const int RetainageBase = 63;

            /// <summary>
            /// Property Indexer for Retainage Schedule 
            /// </summary>
            public const int RetainageSchedule = 64;

            /// <summary>
            /// Property Indexer for Retainage Schedule Link 
            /// </summary>
            public const int RetainageScheduleLink = 65;

            /// <summary>
            /// Property Indexer for Date Retainage Sched Last Run 
            /// </summary>
            public const int DateRetainageSchedLastRun = 66;

            /// <summary>
            /// Property Indexer for Days Retained 
            /// </summary>
            public const int DaysRetained = 67;

            /// <summary>
            /// Property Indexer for Percent Retained 
            /// </summary>
            public const int PercentRetained = 68;

            /// <summary>
            /// Property Indexer for Days Before Retainage Due 
            /// </summary>
            public const int DaysBeforeRetainageDue = 69;

            /// <summary>
            /// Property Indexer for Retainage Exchange Rate 
            /// </summary>
            public const int RetainageExchangeRate = 70;

            /// <summary>
            /// Property Indexer for Include Pending A/R Transaction
            /// </summary>
            public const int IncludePendingAorRTrans = 71;

            /// <summary>
            /// Property Indexer for Include Pending O/E Transaction
            /// </summary>
            public const int IncludePendingOorETrans = 72;

            /// <summary>
            /// Property Indexer for Include Pending Other Transaction 
            /// </summary>
            public const int IncludePendingOtherTrans = 73;

            /// <summary>
            /// Property Indexer for Default Tax Reporting Control 
            /// </summary>
            public const int DefaultTaxReportingControl = 74;

            /// <summary>
            /// Property Indexer for Report Retainage Tax 
            /// </summary>
            public const int ReportRetainageTax = 75;

            /// <summary>
            /// Property Indexer for Default Detail Tax Class 
            /// </summary>
            public const int DefaultDetailTaxClass = 76;

            /// <summary>
            /// Property Indexer for Default Posting Date 
            /// </summary>
            public const int DefaultPostingDate = 77;

            #endregion
        }
    }
}