// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Statement Processing Options Constants 
    /// </summary>
    public partial class OptionsStatementProcessing
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0004";

        /// <summary>
        /// Contains list of Statement Processing Options Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Statement Processing Options Key 
            /// </summary>
            public const string StatementProcessingOptionsKey = "IDR04";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATEMNTN";

            /// <summary>
            /// Property for Aging Period 1 
            /// </summary>
            public const string AgingPeriod1 = "AGINPERD1";

            /// <summary>
            /// Property for Aging Period 2 
            /// </summary>
            public const string AgingPeriod2 = "AGINPERD2";

            /// <summary>
            /// Property for Aging Period 3 
            /// </summary>
            public const string AgingPeriod3 = "AGINPERD3";

            /// <summary>
            /// Property for Age Credit Notes and Debit Notes 
            /// </summary>
            public const string AgeCreditNotesandDebitNotes = "AGECR";

            /// <summary>
            /// Property for Age Unapplied Cash Prepayments 
            /// </summary>
            public const string AgeUnappliedCashPrepayments = "AGEUAPL";

            /// <summary>
            /// Property for Current Dunning Message 
            /// </summary>
            public const string CurrentDunningMessage = "TEXTSTMT1";

            /// <summary>
            /// Property for Period 1 Dunning Message 
            /// </summary>
            public const string Period1DunningMessage = "TEXTSTMT2";

            /// <summary>
            /// Property for Period 2 Dunning Message 
            /// </summary>
            public const string Period2DunningMessage = "TEXTSTMT3";

            /// <summary>
            /// Property for Period 3 Dunning Message 
            /// </summary>
            public const string Period3DunningMessage = "TEXTSTMT4";

            /// <summary>
            /// Property for Over Period 3 Dunning Message 
            /// </summary>
            public const string OverPeriod3DunningMessage = "TEXTSTMT5";

            /// <summary>
            /// Property for Print Zero Balance Statements 
            /// </summary>
            public const string PrintZeroBalanceStatements = "PRTZEROBAL";

            #endregion
        }

        /// <summary>
        /// Contains list of Statement Processing Options Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Statement Processing Options Key 
            /// </summary>
            public const int StatementProcessingOptionsKey = 1;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for Aging Period 1 
            /// </summary>
            public const int AgingPeriod1 = 3;

            /// <summary>
            /// Property Indexer for Aging Period 2 
            /// </summary>
            public const int AgingPeriod2 = 4;

            /// <summary>
            /// Property Indexer for Aging Period 3 
            /// </summary>
            public const int AgingPeriod3 = 5;

            /// <summary>
            /// Property Indexer for Age Credit Notes and Debit Notes 
            /// </summary>
            public const int AgeCreditNotesandDebitNotes = 6;

            /// <summary>
            /// Property Indexer for Age Unapplied Cash Prepayments 
            /// </summary>
            public const int AgeUnappliedCashPrepayments = 7;

            /// <summary>
            /// Property Indexer for Current Dunning Message 
            /// </summary>
            public const int CurrentDunningMessage = 8;

            /// <summary>
            /// Property Indexer for Period 1 Dunning Message 
            /// </summary>
            public const int Period1DunningMessage = 9;

            /// <summary>
            /// Property Indexer for Period 2 Dunning Message 
            /// </summary>
            public const int Period2DunningMessage = 10;

            /// <summary>
            /// Property Indexer for Period 3 Dunning Message 
            /// </summary>
            public const int Period3DunningMessage = 11;

            /// <summary>
            /// Property Indexer for Over Period 3 Dunning Message 
            /// </summary>
            public const int OverPeriod3DunningMessage = 12;

            /// <summary>
            /// Property Indexer for Print Zero Balance Statements 
            /// </summary>
            public const int PrintZeroBalanceStatements = 13;

            #endregion
        }
    }
}