// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Contains list of PostedReceipt Constants
	/// </summary>
	public partial class PostedReceipt
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AR0040";

		#region Properties

		/// <summary>
		/// Contains list of PostedReceipt Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for BankCode
			/// </summary>
			public const string BankCode = "IDBANK";

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "IDCUST";

			/// <summary>
			/// Property for CheckReceiptNo
			/// </summary>
			public const string CheckReceiptNo = "IDRMIT";

			/// <summary>
			/// Property for DepositSerialNumber
			/// </summary>
			public const string DepositSerialNumber = "DEPSEQ";

			/// <summary>
			/// Property for DepositLineNumber
			/// </summary>
			public const string DepositLineNumber = "DEPLINE";

			/// <summary>
			/// Property for ReceiptDate
			/// </summary>
			public const string ReceiptDate = "DATERMIT";

			/// <summary>
			/// Property for DepositNumber
			/// </summary>
			public const string DepositNumber = "DEPSTNBR";

			/// <summary>
			/// Property for BatchDate
			/// </summary>
			public const string BatchDate = "DATEBTCH";

			/// <summary>
			/// Property for CustReceiptAmount
			/// </summary>
			public const string CustReceiptAmount = "AMTRMITTC";

			/// <summary>
			/// Property for BankReceiptAmount
			/// </summary>
			public const string BankReceiptAmount = "AMTPAYM";

			/// <summary>
			/// Property for CustDiscountAmount
			/// </summary>
			public const string CustDiscountAmount = "AMTDISC";

			/// <summary>
			/// Property for PaymentCode
			/// </summary>
			public const string PaymentCode = "PAYMCODE";

			/// <summary>
			/// Property for CurrencyCode
			/// </summary>
			public const string CurrencyCode = "CODECURN";

			/// <summary>
			/// Property for BankRateType
			/// </summary>
			public const string BankRateType = "IDRATETYPE";

			/// <summary>
			/// Property for BankExchangeRate
			/// </summary>
			public const string BankExchangeRate = "RATEEXCHHC";

			/// <summary>
			/// Property for BankRateOverride
			/// </summary>
			public const string BankRateOverride = "SWOVRDRATE";

			/// <summary>
			/// Property for ReasonForReturn
			/// </summary>
			public const string ReasonForReturn = "TEXTRETRN";

			/// <summary>
			/// Property for DateLastMaintained
			/// </summary>
			public const string DateLastMaintained = "DATELSTMTN";

			/// <summary>
			/// Property for LastStatementDate
			/// </summary>
			public const string LastStatementDate = "DATELSTSTM";

			/// <summary>
			/// Property for AmountOfRoundingError
			/// </summary>
			public const string AmountOfRoundingError = "AMTROUNDER";

			/// <summary>
			/// Property for BankToFuncRateDate
			/// </summary>
			public const string BankToFuncRateDate = "DATERATE";

			/// <summary>
			/// Property for FiscalYear
			/// </summary>
			public const string FiscalYear = "FISCYR";

			/// <summary>
			/// Property for FiscalPeriod
			/// </summary>
			public const string FiscalPeriod = "FISCPER";

			/// <summary>
			/// Property for Payer
			/// </summary>
			public const string Payer = "NAMERMIT";

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBTCH";

			/// <summary>
			/// Property for EntryNumber
			/// </summary>
			public const string EntryNumber = "CNTITEM";

			/// <summary>
			/// Property for CheckCleared
			/// </summary>
			public const string CheckCleared = "SWCHKCLRD";

			/// <summary>
			/// Property for FuncReceiptAmount
			/// </summary>
			public const string FuncReceiptAmount = "AMTRMITHC";

			/// <summary>
			/// Property for CustAdjustmentAmount
			/// </summary>
			public const string CustAdjustmentAmount = "AMTADJ";

			/// <summary>
			/// Property for DateCleared
			/// </summary>
			public const string DateCleared = "DATECLRD";

			/// <summary>
			/// Property for DateReturned
			/// </summary>
			public const string DateReturned = "DATERVRSD";

			/// <summary>
			/// Property for DocumentType
			/// </summary>
			public const string DocumentType = "TRXTYPETXT";

			/// <summary>
			/// Property for DocumentNo
			/// </summary>
			public const string DocumentNo = "IDINVC";

			/// <summary>
			/// Property for RateOperator
			/// </summary>
			public const string RateOperator = "RATEOP";

			/// <summary>
			/// Property for PaymentType
			/// </summary>
			public const string PaymentType = "PAYMTYPE";

			/// <summary>
			/// Property for DrillDownApplicationSource
			/// </summary>
			public const string DrillDownApplicationSource = "DRILLAPP";

			/// <summary>
			/// Property for DrillDownType
			/// </summary>
			public const string DrillDownType = "DRILLTYPE";

			/// <summary>
			/// Property for DrillDownLinkNumber
			/// </summary>
			public const string DrillDownLinkNumber = "DRILLDWNLK";

			/// <summary>
			/// Property for MiscReceiptFlag
			/// </summary>
			public const string MiscReceiptFlag = "SWNONRCVBL";

			/// <summary>
			/// Property for JobRelated
			/// </summary>
			public const string JobRelated = "SWJOB";

			/// <summary>
			/// Property for InvoiceNumber
			/// </summary>
			public const string InvoiceNumber = "IDINVCMTCH";

			/// <summary>
			/// Property for CalculateTax
			/// </summary>
			public const string CalculateTax = "SWTXAMTCTL";

			/// <summary>
			/// Property for TaxGroup
			/// </summary>
			public const string TaxGroup = "CODETAXGRP";

			/// <summary>
			/// Property for TaxAuthority1
			/// </summary>
			public const string TaxAuthority1 = "CODETAX1";

			/// <summary>
			/// Property for TaxAuthority2
			/// </summary>
			public const string TaxAuthority2 = "CODETAX2";

			/// <summary>
			/// Property for TaxAuthority3
			/// </summary>
			public const string TaxAuthority3 = "CODETAX3";

			/// <summary>
			/// Property for TaxAuthority4
			/// </summary>
			public const string TaxAuthority4 = "CODETAX4";

			/// <summary>
			/// Property for TaxAuthority5
			/// </summary>
			public const string TaxAuthority5 = "CODETAX5";

			/// <summary>
			/// Property for TaxClass1
			/// </summary>
			public const string TaxClass1 = "TAXCLASS1";

			/// <summary>
			/// Property for TaxClass2
			/// </summary>
			public const string TaxClass2 = "TAXCLASS2";

			/// <summary>
			/// Property for TaxClass3
			/// </summary>
			public const string TaxClass3 = "TAXCLASS3";

			/// <summary>
			/// Property for TaxClass4
			/// </summary>
			public const string TaxClass4 = "TAXCLASS4";

			/// <summary>
			/// Property for TaxClass5
			/// </summary>
			public const string TaxClass5 = "TAXCLASS5";

			/// <summary>
			/// Property for TaxBase1
			/// </summary>
			public const string TaxBase1 = "TXBSE1TC";

			/// <summary>
			/// Property for TaxBase2
			/// </summary>
			public const string TaxBase2 = "TXBSE2TC";

			/// <summary>
			/// Property for TaxBase3
			/// </summary>
			public const string TaxBase3 = "TXBSE3TC";

			/// <summary>
			/// Property for TaxBase4
			/// </summary>
			public const string TaxBase4 = "TXBSE4TC";

			/// <summary>
			/// Property for TaxBase5
			/// </summary>
			public const string TaxBase5 = "TXBSE5TC";

			/// <summary>
			/// Property for TaxAmount1
			/// </summary>
			public const string TaxAmount1 = "TXAMT1TC";

			/// <summary>
			/// Property for TaxAmount2
			/// </summary>
			public const string TaxAmount2 = "TXAMT2TC";

			/// <summary>
			/// Property for TaxAmount3
			/// </summary>
			public const string TaxAmount3 = "TXAMT3TC";

			/// <summary>
			/// Property for TaxAmount4
			/// </summary>
			public const string TaxAmount4 = "TXAMT4TC";

			/// <summary>
			/// Property for TaxAmount5
			/// </summary>
			public const string TaxAmount5 = "TXAMT5TC";

			/// <summary>
			/// Property for TaxTotal
			/// </summary>
			public const string TaxTotal = "TXTOTTC";

			/// <summary>
			/// Property for DistAmountNetOfTaxes
			/// </summary>
			public const string DistAmountNetOfTaxes = "AMTNETTC";

			/// <summary>
			/// Property for TaxReportingCurrencyCode
			/// </summary>
			public const string TaxReportingCurrencyCode = "CODECURNRC";

			/// <summary>
			/// Property for TaxReportingCalculateMethod
			/// </summary>
			public const string TaxReportingCalculateMethod = "SWTXCTLRC";

			/// <summary>
			/// Property for TaxReportingExchangeRate
			/// </summary>
			public const string TaxReportingExchangeRate = "RATERC";

			/// <summary>
			/// Property for TaxReportingRateType
			/// </summary>
			public const string TaxReportingRateType = "RATETYPERC";

			/// <summary>
			/// Property for TaxReportingRateDate
			/// </summary>
			public const string TaxReportingRateDate = "RATEDATERC";

			/// <summary>
			/// Property for TaxReportingRateOperator
			/// </summary>
			public const string TaxReportingRateOperator = "RATEOPRC";

			/// <summary>
			/// Property for TaxReportingAmount1
			/// </summary>
			public const string TaxReportingAmount1 = "TXAMT1RC";

			/// <summary>
			/// Property for TaxReportingAmount2
			/// </summary>
			public const string TaxReportingAmount2 = "TXAMT2RC";

			/// <summary>
			/// Property for TaxReportingAmount3
			/// </summary>
			public const string TaxReportingAmount3 = "TXAMT3RC";

			/// <summary>
			/// Property for TaxReportingAmount4
			/// </summary>
			public const string TaxReportingAmount4 = "TXAMT4RC";

			/// <summary>
			/// Property for TaxReportingAmount5
			/// </summary>
			public const string TaxReportingAmount5 = "TXAMT5RC";

			/// <summary>
			/// Property for TaxReportingTotal
			/// </summary>
			public const string TaxReportingTotal = "TXTOTRC";

			/// <summary>
			/// Property for FuncTaxBase1
			/// </summary>
			public const string FuncTaxBase1 = "TXBSE1HC";

			/// <summary>
			/// Property for FuncTaxBase2
			/// </summary>
			public const string FuncTaxBase2 = "TXBSE2HC";

			/// <summary>
			/// Property for FuncTaxBase3
			/// </summary>
			public const string FuncTaxBase3 = "TXBSE3HC";

			/// <summary>
			/// Property for FuncTaxBase4
			/// </summary>
			public const string FuncTaxBase4 = "TXBSE4HC";

			/// <summary>
			/// Property for FuncTaxBase5
			/// </summary>
			public const string FuncTaxBase5 = "TXBSE5HC";

			/// <summary>
			/// Property for FuncTaxAmount1
			/// </summary>
			public const string FuncTaxAmount1 = "TXAMT1HC";

			/// <summary>
			/// Property for FuncTaxAmount2
			/// </summary>
			public const string FuncTaxAmount2 = "TXAMT2HC";

			/// <summary>
			/// Property for FuncTaxAmount3
			/// </summary>
			public const string FuncTaxAmount3 = "TXAMT3HC";

			/// <summary>
			/// Property for FuncTaxAmount4
			/// </summary>
			public const string FuncTaxAmount4 = "TXAMT4HC";

			/// <summary>
			/// Property for FuncTaxAmount5
			/// </summary>
			public const string FuncTaxAmount5 = "TXAMT5HC";

			/// <summary>
			/// Property for FuncTaxTotal
			/// </summary>
			public const string FuncTaxTotal = "TXTOTHC";

			/// <summary>
			/// Property for FuncDistAmountNetOfTaxes
			/// </summary>
			public const string FuncDistAmountNetOfTaxes = "AMTNETHC";

			/// <summary>
			/// Property for NumberOfAdvanceCreditClaims
			/// </summary>
			public const string NumberOfAdvanceCreditClaims = "CNTACC";

			/// <summary>
			/// Property for TotalAdvanceCreditClaim
			/// </summary>
			public const string TotalAdvanceCreditClaim = "AMTACCTC";

			/// <summary>
			/// Property for FuncTotalAdvanceCreditClaim
			/// </summary>
			public const string FuncTotalAdvanceCreditClaim = "AMTACCHC";

			/// <summary>
			/// Property for PostingDate
			/// </summary>
			public const string PostingDate = "DATEBUS";

			/// <summary>
			/// Property for CreditCardTransactionNumber
			/// </summary>
			public const string CreditCardTransactionNumber = "CCTRANID";

			/// <summary>
			/// Property for ProcessingCode
			/// </summary>
			public const string ProcessingCode = "PROCESSCOD";

			/// <summary>
			/// Property for CardNumber
			/// </summary>
			public const string CardNumber = "LAST4";

			/// <summary>
			/// Property for CardType
			/// </summary>
			public const string CardType = "CARDTYPE";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "CUSTCURN";

        }

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of PostedReceipt Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for BankCode
			/// </summary>
			public const int BankCode = 1;

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 2;

			/// <summary>
			/// Property Indexer for CheckReceiptNo
			/// </summary>
			public const int CheckReceiptNo = 3;

			/// <summary>
			/// Property Indexer for DepositSerialNumber
			/// </summary>
			public const int DepositSerialNumber = 28;

			/// <summary>
			/// Property Indexer for DepositLineNumber
			/// </summary>
			public const int DepositLineNumber = 38;

			/// <summary>
			/// Property Indexer for ReceiptDate
			/// </summary>
			public const int ReceiptDate = 4;

			/// <summary>
			/// Property Indexer for DepositNumber
			/// </summary>
			public const int DepositNumber = 5;

			/// <summary>
			/// Property Indexer for BatchDate
			/// </summary>
			public const int BatchDate = 6;

			/// <summary>
			/// Property Indexer for CustReceiptAmount
			/// </summary>
			public const int CustReceiptAmount = 7;

			/// <summary>
			/// Property Indexer for BankReceiptAmount
			/// </summary>
			public const int BankReceiptAmount = 8;

			/// <summary>
			/// Property Indexer for CustDiscountAmount
			/// </summary>
			public const int CustDiscountAmount = 9;

			/// <summary>
			/// Property Indexer for PaymentCode
			/// </summary>
			public const int PaymentCode = 10;

			/// <summary>
			/// Property Indexer for CurrencyCode
			/// </summary>
			public const int CurrencyCode = 11;

			/// <summary>
			/// Property Indexer for BankRateType
			/// </summary>
			public const int BankRateType = 12;

			/// <summary>
			/// Property Indexer for BankExchangeRate
			/// </summary>
			public const int BankExchangeRate = 13;

			/// <summary>
			/// Property Indexer for BankRateOverride
			/// </summary>
			public const int BankRateOverride = 14;

			/// <summary>
			/// Property Indexer for ReasonForReturn
			/// </summary>
			public const int ReasonForReturn = 15;

			/// <summary>
			/// Property Indexer for DateLastMaintained
			/// </summary>
			public const int DateLastMaintained = 16;

			/// <summary>
			/// Property Indexer for LastStatementDate
			/// </summary>
			public const int LastStatementDate = 17;

			/// <summary>
			/// Property Indexer for AmountOfRoundingError
			/// </summary>
			public const int AmountOfRoundingError = 18;

			/// <summary>
			/// Property Indexer for BankToFuncRateDate
			/// </summary>
			public const int BankToFuncRateDate = 19;

			/// <summary>
			/// Property Indexer for FiscalYear
			/// </summary>
			public const int FiscalYear = 20;

			/// <summary>
			/// Property Indexer for FiscalPeriod
			/// </summary>
			public const int FiscalPeriod = 21;

			/// <summary>
			/// Property Indexer for Payer
			/// </summary>
			public const int Payer = 22;

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 23;

			/// <summary>
			/// Property Indexer for EntryNumber
			/// </summary>
			public const int EntryNumber = 24;

			/// <summary>
			/// Property Indexer for CheckCleared
			/// </summary>
			public const int CheckCleared = 25;

			/// <summary>
			/// Property Indexer for FuncReceiptAmount
			/// </summary>
			public const int FuncReceiptAmount = 26;

			/// <summary>
			/// Property Indexer for CustAdjustmentAmount
			/// </summary>
			public const int CustAdjustmentAmount = 27;

			/// <summary>
			/// Property Indexer for DateCleared
			/// </summary>
			public const int DateCleared = 29;

			/// <summary>
			/// Property Indexer for DateReturned
			/// </summary>
			public const int DateReturned = 30;

			/// <summary>
			/// Property Indexer for DocumentType
			/// </summary>
			public const int DocumentType = 31;

			/// <summary>
			/// Property Indexer for DocumentNo
			/// </summary>
			public const int DocumentNo = 32;

			/// <summary>
			/// Property Indexer for RateOperator
			/// </summary>
			public const int RateOperator = 33;

			/// <summary>
			/// Property Indexer for PaymentType
			/// </summary>
			public const int PaymentType = 34;

			/// <summary>
			/// Property Indexer for DrillDownApplicationSource
			/// </summary>
			public const int DrillDownApplicationSource = 35;

			/// <summary>
			/// Property Indexer for DrillDownType
			/// </summary>
			public const int DrillDownType = 36;

			/// <summary>
			/// Property Indexer for DrillDownLinkNumber
			/// </summary>
			public const int DrillDownLinkNumber = 37;

			/// <summary>
			/// Property Indexer for MiscReceiptFlag
			/// </summary>
			public const int MiscReceiptFlag = 43;

			/// <summary>
			/// Property Indexer for JobRelated
			/// </summary>
			public const int JobRelated = 44;

			/// <summary>
			/// Property Indexer for InvoiceNumber
			/// </summary>
			public const int InvoiceNumber = 45;

			/// <summary>
			/// Property Indexer for CalculateTax
			/// </summary>
			public const int CalculateTax = 46;

			/// <summary>
			/// Property Indexer for TaxGroup
			/// </summary>
			public const int TaxGroup = 47;

			/// <summary>
			/// Property Indexer for TaxAuthority1
			/// </summary>
			public const int TaxAuthority1 = 48;

			/// <summary>
			/// Property Indexer for TaxAuthority2
			/// </summary>
			public const int TaxAuthority2 = 49;

			/// <summary>
			/// Property Indexer for TaxAuthority3
			/// </summary>
			public const int TaxAuthority3 = 50;

			/// <summary>
			/// Property Indexer for TaxAuthority4
			/// </summary>
			public const int TaxAuthority4 = 51;

			/// <summary>
			/// Property Indexer for TaxAuthority5
			/// </summary>
			public const int TaxAuthority5 = 52;

			/// <summary>
			/// Property Indexer for TaxClass1
			/// </summary>
			public const int TaxClass1 = 53;

			/// <summary>
			/// Property Indexer for TaxClass2
			/// </summary>
			public const int TaxClass2 = 54;

			/// <summary>
			/// Property Indexer for TaxClass3
			/// </summary>
			public const int TaxClass3 = 55;

			/// <summary>
			/// Property Indexer for TaxClass4
			/// </summary>
			public const int TaxClass4 = 56;

			/// <summary>
			/// Property Indexer for TaxClass5
			/// </summary>
			public const int TaxClass5 = 57;

			/// <summary>
			/// Property Indexer for TaxBase1
			/// </summary>
			public const int TaxBase1 = 58;

			/// <summary>
			/// Property Indexer for TaxBase2
			/// </summary>
			public const int TaxBase2 = 59;

			/// <summary>
			/// Property Indexer for TaxBase3
			/// </summary>
			public const int TaxBase3 = 60;

			/// <summary>
			/// Property Indexer for TaxBase4
			/// </summary>
			public const int TaxBase4 = 61;

			/// <summary>
			/// Property Indexer for TaxBase5
			/// </summary>
			public const int TaxBase5 = 62;

			/// <summary>
			/// Property Indexer for TaxAmount1
			/// </summary>
			public const int TaxAmount1 = 63;

			/// <summary>
			/// Property Indexer for TaxAmount2
			/// </summary>
			public const int TaxAmount2 = 64;

			/// <summary>
			/// Property Indexer for TaxAmount3
			/// </summary>
			public const int TaxAmount3 = 65;

			/// <summary>
			/// Property Indexer for TaxAmount4
			/// </summary>
			public const int TaxAmount4 = 66;

			/// <summary>
			/// Property Indexer for TaxAmount5
			/// </summary>
			public const int TaxAmount5 = 67;

			/// <summary>
			/// Property Indexer for TaxTotal
			/// </summary>
			public const int TaxTotal = 68;

			/// <summary>
			/// Property Indexer for DistAmountNetOfTaxes
			/// </summary>
			public const int DistAmountNetOfTaxes = 69;

			/// <summary>
			/// Property Indexer for TaxReportingCurrencyCode
			/// </summary>
			public const int TaxReportingCurrencyCode = 70;

			/// <summary>
			/// Property Indexer for TaxReportingCalculateMethod
			/// </summary>
			public const int TaxReportingCalculateMethod = 71;

			/// <summary>
			/// Property Indexer for TaxReportingExchangeRate
			/// </summary>
			public const int TaxReportingExchangeRate = 72;

			/// <summary>
			/// Property Indexer for TaxReportingRateType
			/// </summary>
			public const int TaxReportingRateType = 73;

			/// <summary>
			/// Property Indexer for TaxReportingRateDate
			/// </summary>
			public const int TaxReportingRateDate = 74;

			/// <summary>
			/// Property Indexer for TaxReportingRateOperator
			/// </summary>
			public const int TaxReportingRateOperator = 75;

			/// <summary>
			/// Property Indexer for TaxReportingAmount1
			/// </summary>
			public const int TaxReportingAmount1 = 76;

			/// <summary>
			/// Property Indexer for TaxReportingAmount2
			/// </summary>
			public const int TaxReportingAmount2 = 77;

			/// <summary>
			/// Property Indexer for TaxReportingAmount3
			/// </summary>
			public const int TaxReportingAmount3 = 78;

			/// <summary>
			/// Property Indexer for TaxReportingAmount4
			/// </summary>
			public const int TaxReportingAmount4 = 79;

			/// <summary>
			/// Property Indexer for TaxReportingAmount5
			/// </summary>
			public const int TaxReportingAmount5 = 80;

			/// <summary>
			/// Property Indexer for TaxReportingTotal
			/// </summary>
			public const int TaxReportingTotal = 81;

			/// <summary>
			/// Property Indexer for FuncTaxBase1
			/// </summary>
			public const int FuncTaxBase1 = 82;

			/// <summary>
			/// Property Indexer for FuncTaxBase2
			/// </summary>
			public const int FuncTaxBase2 = 83;

			/// <summary>
			/// Property Indexer for FuncTaxBase3
			/// </summary>
			public const int FuncTaxBase3 = 84;

			/// <summary>
			/// Property Indexer for FuncTaxBase4
			/// </summary>
			public const int FuncTaxBase4 = 85;

			/// <summary>
			/// Property Indexer for FuncTaxBase5
			/// </summary>
			public const int FuncTaxBase5 = 86;

			/// <summary>
			/// Property Indexer for FuncTaxAmount1
			/// </summary>
			public const int FuncTaxAmount1 = 87;

			/// <summary>
			/// Property Indexer for FuncTaxAmount2
			/// </summary>
			public const int FuncTaxAmount2 = 88;

			/// <summary>
			/// Property Indexer for FuncTaxAmount3
			/// </summary>
			public const int FuncTaxAmount3 = 89;

			/// <summary>
			/// Property Indexer for FuncTaxAmount4
			/// </summary>
			public const int FuncTaxAmount4 = 90;

			/// <summary>
			/// Property Indexer for FuncTaxAmount5
			/// </summary>
			public const int FuncTaxAmount5 = 91;

			/// <summary>
			/// Property Indexer for FuncTaxTotal
			/// </summary>
			public const int FuncTaxTotal = 92;

			/// <summary>
			/// Property Indexer for FuncDistAmountNetOfTaxes
			/// </summary>
			public const int FuncDistAmountNetOfTaxes = 93;

			/// <summary>
			/// Property Indexer for NumberOfAdvanceCreditClaims
			/// </summary>
			public const int NumberOfAdvanceCreditClaims = 94;

			/// <summary>
			/// Property Indexer for TotalAdvanceCreditClaim
			/// </summary>
			public const int TotalAdvanceCreditClaim = 95;

			/// <summary>
			/// Property Indexer for FuncTotalAdvanceCreditClaim
			/// </summary>
			public const int FuncTotalAdvanceCreditClaim = 96;

			/// <summary>
			/// Property Indexer for PostingDate
			/// </summary>
			public const int PostingDate = 97;

			/// <summary>
			/// Property Indexer for CreditCardTransactionNumber
			/// </summary>
			public const int CreditCardTransactionNumber = 98;

			/// <summary>
			/// Property Indexer for ProcessingCode
			/// </summary>
			public const int ProcessingCode = 99;

			/// <summary>
			/// Property Indexer for CardNumber
			/// </summary>
			public const int CardNumber = 100;

			/// <summary>
			/// Property Indexer for CardType
			/// </summary>
			public const int CardType = 101;

            /// <summary>
            /// Property Indexer for Customer Currency
            /// </summary>
            public const int CustomerCurrency = 107;

        }

		#endregion

        #region Keys

        /// <summary>
        /// PostedReceipt Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Check Receipt Number Key
            /// </summary>
            public const int CheckReceiptNo = 1;

            /// <summary>
            /// Receipt Date Key
            /// </summary>
            public const int ReceiptDate = 5;
        }

        #endregion
	}
}
