﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of MiscellaneousReceipts Constants 
    /// </summary>
    public partial class ReceiptMiscellaneousDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0043";

        /// <summary>
        /// Contains list of MiscellaneousReceipts Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "CODEPAYM";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDISTCODE";
            /// <summary>
            /// Property for AccountNumber 
            /// </summary>
            public const string AccountNumber = "IDACCT";
            /// <summary>
            /// Property for G/LReference 
            /// </summary>
            public const string GorLReference = "GLREF";
            /// <summary>
            /// Property for G/LDescription 
            /// </summary>
            public const string GorLDescription = "GLDESC";
            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";
            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";
            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";
            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";
            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";
            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1 = "SWTAXINCL1";
            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
            public const string TaxIncluded2 = "SWTAXINCL2";
            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
            public const string TaxIncluded3 = "SWTAXINCL3";
            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
            public const string TaxIncluded4 = "SWTAXINCL4";
            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
            public const string TaxIncluded5 = "SWTAXINCL5";
            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "TXBSE1TC";
            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "TXBSE2TC";
            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "TXBSE3TC";
            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "TXBSE4TC";
            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "TXBSE5TC";
            /// <summary>
            /// Property for TaxRate1 
            /// </summary>
            public const string TaxRate1 = "RATETAX1";
            /// <summary>
            /// Property for TaxRate2 
            /// </summary>
            public const string TaxRate2 = "RATETAX2";
            /// <summary>
            /// Property for TaxRate3 
            /// </summary>
            public const string TaxRate3 = "RATETAX3";
            /// <summary>
            /// Property for TaxRate4 
            /// </summary>
            public const string TaxRate4 = "RATETAX4";
            /// <summary>
            /// Property for TaxRate5 
            /// </summary>
            public const string TaxRate5 = "RATETAX5";
            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "TXAMT1TC";
            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "TXAMT2TC";
            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "TXAMT3TC";
            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "TXAMT4TC";
            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "TXAMT5TC";
            /// <summary>
            /// Property for TaxTotal 
            /// </summary>
            public const string TaxTotal = "TXTOTTC";
            /// <summary>
            /// Property for DistAmount 
            /// </summary>
            public const string DistAmount = "AMTDISTTC";
            /// <summary>
            /// Property for DistAmountNetofTaxes 
            /// </summary>
            public const string DistAmountNetofTaxes = "AMTNETTC";
            /// <summary>
            /// Property for FuncDistAmount 
            /// </summary>
            public const string FuncDistAmount = "AMTDISTHC";
            /// <summary>
            /// Property for FuncDistAmountNetofTaxes 
            /// </summary>
            public const string FuncDistAmountNetofTaxes = "AMTNETHC";
            /// <summary>
            /// Property for COGSAmount 
            /// </summary>
            public const string CogsAmount = "AMTCOGS";
            /// <summary>
            /// Property for AlternateTaxBaseAmount 
            /// </summary>
            public const string AlternateTaxBaseAmount = "ALTBASETAX";
            /// <summary>
            /// Property for TaxReportingAmount1 
            /// </summary>
            public const string TaxReportingAmount1 = "TXAMT1RC";
            /// <summary>
            /// Property for TaxReportingAmount2 
            /// </summary>
            public const string TaxReportingAmount2 = "TXAMT2RC";
            /// <summary>
            /// Property for TaxReportingAmount3 
            /// </summary>
            public const string TaxReportingAmount3 = "TXAMT3RC";
            /// <summary>
            /// Property for TaxReportingAmount4 
            /// </summary>
            public const string TaxReportingAmount4 = "TXAMT4RC";
            /// <summary>
            /// Property for TaxReportingAmount5 
            /// </summary>
            public const string TaxReportingAmount5 = "TXAMT5RC";
            /// <summary>
            /// Property for TaxReportingTotal 
            /// </summary>
            public const string TaxReportingTotal = "TXTOTRC";
            /// <summary>
            /// Property for FuncTaxBase1 
            /// </summary>
            public const string FuncTaxBase1 = "TXBSE1HC";
            /// <summary>
            /// Property for FuncTaxBase2 
            /// </summary>
            public const string FuncTaxBase2 = "TXBSE2HC";
            /// <summary>
            /// Property for FuncTaxBase3 
            /// </summary>
            public const string FuncTaxBase3 = "TXBSE3HC";
            /// <summary>
            /// Property for FuncTaxBase4 
            /// </summary>
            public const string FuncTaxBase4 = "TXBSE4HC";
            /// <summary>
            /// Property for FuncTaxBase5 
            /// </summary>
            public const string FuncTaxBase5 = "TXBSE5HC";
            /// <summary>
            /// Property for FuncTaxAmount1 
            /// </summary>
            public const string FuncTaxAmount1 = "TXAMT1HC";
            /// <summary>
            /// Property for FuncTaxAmount2 
            /// </summary>
            public const string FuncTaxAmount2 = "TXAMT2HC";
            /// <summary>
            /// Property for FuncTaxAmount3 
            /// </summary>
            public const string FuncTaxAmount3 = "TXAMT3HC";
            /// <summary>
            /// Property for FuncTaxAmount4 
            /// </summary>
            public const string FuncTaxAmount4 = "TXAMT4HC";
            /// <summary>
            /// Property for FuncTaxAmount5 
            /// </summary>
            public const string FuncTaxAmount5 = "TXAMT5HC";
            /// <summary>
            /// Property for FuncTaxTotal 
            /// </summary>
            public const string FuncTaxTotal = "TXTOTHC";
            /// <summary>
            /// Property for ContractCode 
            /// </summary>
            public const string ContractCode = "CONTRACT";
            /// <summary>
            /// Property for ProjectCode 
            /// </summary>
            public const string ProjectCode = "PROJECT";
            /// <summary>
            /// Property for CategoryCode 
            /// </summary>
            public const string CategoryCode = "CATEGORY";
            /// <summary>
            /// Property for ProjectOrCategoryResource 
            /// </summary>
            public const string ProjectOrCategoryResource = "RESOURCE";
            /// <summary>
            /// Property for CostClass 
            /// </summary>
            public const string CostClass = "COSTCLASS";
            /// <summary>
            /// Property for BillingDate 
            /// </summary>
            public const string BillingDate = "BILLDATE";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHT1TC = "AMTWHT1TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHT2TC = "AMTWHT2TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHT3TC = "AMTWHT3TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHT4TC = "AMTWHT4TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHT5TC = "AMTWHT5TC";

            #endregion
        }


        /// <summary>
        /// Contains list of MiscellaneousReceipts Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 4;
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 6;
            /// <summary>
            /// Property Indexer for AccountNumber 
            /// </summary>
            public const int AccountNumber = 7;
            /// <summary>
            /// Property Indexer for G/LReference 
            /// </summary>
            public const int GorLReference = 8;
            /// <summary>
            /// Property Indexer for G/LDescription 
            /// </summary>
            public const int GorLDescription = 9;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 10;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 11;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 12;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 13;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 14;
            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
            public const int TaxIncluded1 = 15;
            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
            public const int TaxIncluded2 = 16;
            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
            public const int TaxIncluded3 = 17;
            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
            public const int TaxIncluded4 = 18;
            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
            public const int TaxIncluded5 = 19;
            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 20;
            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 21;
            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 22;
            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 23;
            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 24;
            /// <summary>
            /// Property Indexer for TaxRate1 
            /// </summary>
            public const int TaxRate1 = 25;
            /// <summary>
            /// Property Indexer for TaxRate2 
            /// </summary>
            public const int TaxRate2 = 26;
            /// <summary>
            /// Property Indexer for TaxRate3 
            /// </summary>
            public const int TaxRate3 = 27;
            /// <summary>
            /// Property Indexer for TaxRate4 
            /// </summary>
            public const int TaxRate4 = 28;
            /// <summary>
            /// Property Indexer for TaxRate5 
            /// </summary>
            public const int TaxRate5 = 29;
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 30;
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 31;
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 32;
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 33;
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 34;
            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 35;
            /// <summary>
            /// Property Indexer for DistAmount 
            /// </summary>
            public const int DistAmount = 36;
            /// <summary>
            /// Property Indexer for DistAmountNetofTaxes 
            /// </summary>
            public const int DistAmountNetofTaxes = 37;
            /// <summary>
            /// Property Indexer for FuncDistAmount 
            /// </summary>
            public const int FuncDistAmount = 38;
            /// <summary>
            /// Property Indexer for FuncDistAmountNetofTaxes 
            /// </summary>
            public const int FuncDistAmountNetofTaxes = 39;
            /// <summary>
            /// Property Indexer for COGSAmount 
            /// </summary>
            public const int CogsAmount = 40;
            /// <summary>
            /// Property Indexer for AlternateTaxBaseAmount 
            /// </summary>
            public const int AlternateTaxBaseAmount = 41;
            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 42;
            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 43;
            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 44;
            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 45;
            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 46;
            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 47;
            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 48;
            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 49;
            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 50;
            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 51;
            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 52;
            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 53;
            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 54;
            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 55;
            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 56;
            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 57;
            /// <summary>
            /// Property Indexer for FuncTaxTotal 
            /// </summary>
            public const int FuncTaxTotal = 58;
            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 59;
            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 60;
            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 61;
            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 62;
            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 63;
            /// <summary>
            /// Property Indexer for BillingDate 
            /// </summary>
            public const int BillingDate = 64;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHT1TC = 65;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHT2TC = 66;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHT3TC = 67;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHT4TC = 68;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHT5TC = 69;

            #endregion
        }
    }
}