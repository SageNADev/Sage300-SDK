// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
     /// <summary>
     /// Contains list of FunctionParametersHeader Constants
     /// </summary>
     public partial class FunctionParametersHeader
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "AR0504";

          #region Properties
          /// <summary>
          /// Contains list of FunctionParametersHeader Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Function
               /// </summary>
               public const string Function = "FUNCTION";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of FunctionParametersHeader Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Function
               /// </summary>
               public const int Function = 1;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 2;

          }
          #endregion

     }
}
