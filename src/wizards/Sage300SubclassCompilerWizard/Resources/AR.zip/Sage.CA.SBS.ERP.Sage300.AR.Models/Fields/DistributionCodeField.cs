// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of DistributionCodes Constants 
    /// </summary>
    public partial class DistributionCodes
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0015";

        /// <summary>
        /// Contains list of DistributionCodes Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDIST";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for Status String
            /// Added for Finder filter
            /// </summary>
            public const string StatusString = "SWACTV";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINAC";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for RevenueAccount 
            /// </summary>
            public const string RevenueAccount = "IDACCTREV";

            /// <summary>
            /// Property for InventoryAccount 
            /// </summary>
            public const string InventoryAccount = "IDACCTINV";

            /// <summary>
            /// Property for CostofGoodsSoldAccount 
            /// </summary>
            public const string CostofGoodsSoldAccount = "IDACCTCOGS";

            /// <summary>
            /// Property for Discountable 
            /// </summary>
            public const string Discountable = "SWDISCABL";

            /// <summary>
            /// Property for Discountable String
            /// Added for Finder Filter
            /// </summary>
            public const string DiscountableString = "SWDISCABL";
            #endregion
        }

        /// <summary>
        /// Contains list of DistributionCodes Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 1;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;

            /// <summary>
            /// Property Indexer for RevenueAccount 
            /// </summary>
            public const int RevenueAccount = 6;

            /// <summary>
            /// Property Indexer for InventoryAccount 
            /// </summary>
            public const int InventoryAccount = 7;

            /// <summary>
            /// Property Indexer for CostofGoodsSoldAccount 
            /// </summary>
            public const int CostofGoodsSoldAccount = 8;

            /// <summary>
            /// Property Indexer for Discountable 
            /// </summary>
            public const int Discountable = 9;

            #endregion
        }
    }
}