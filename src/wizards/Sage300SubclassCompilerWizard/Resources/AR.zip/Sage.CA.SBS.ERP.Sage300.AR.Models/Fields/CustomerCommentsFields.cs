// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CustomerComments Constants 
    /// </summary>
    public partial class CustomerComments
    {

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0021";

        /// <summary>
        /// Contains list of CustomerComments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CustomerNumber 
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for DateEntered 
            /// </summary>
            public const string DateEntered = "DATEENTR";

            /// <summary>
            /// Property for CommentNumber 
            /// </summary>
            public const string CommentNumber = "CNTUNIQ";

            /// <summary>
            /// Property for ExpirationDate 
            /// </summary>
            public const string ExpirationDate = "DATEEXPR";

            /// <summary>
            /// Property for FollowupDate 
            /// </summary>
            public const string FollowupDate = "DATEFLUP";

            /// <summary>
            /// Property for Comments 
            /// </summary>
            public const string Comments = "TEXTCMNT";

            /// <summary>
            /// Property for ReverseCount 
            /// </summary>
            public const string ReverseCount = "REVCOM";

            /// <summary>
            /// Property for Comments1Of10 
            /// </summary>
            public const string Comments1Of10 = "TEXTCMNT1";

            /// <summary>
            /// Property for Comments2Of10 
            /// </summary>
            public const string Comments2Of10 = "TEXTCMNT2";

            /// <summary>
            /// Property for Comments3Of10 
            /// </summary>
            public const string Comments3Of10 = "TEXTCMNT3";

            /// <summary>
            /// Property for Comments4Of10 
            /// </summary>
            public const string Comments4Of10 = "TEXTCMNT4";

            /// <summary>
            /// Property for Comments5Of10 
            /// </summary>
            public const string Comments5Of10 = "TEXTCMNT5";

            /// <summary>
            /// Property for Comments6Of10 
            /// </summary>
            public const string Comments6Of10 = "TEXTCMNT6";

            /// <summary>
            /// Property for Comments7Of10 
            /// </summary>
            public const string Comments7Of10 = "TEXTCMNT7";

            /// <summary>
            /// Property for Comments8Of10 
            /// </summary>
            public const string Comments8Of10 = "TEXTCMNT8";

            /// <summary>
            /// Property for Comments9Of10 
            /// </summary>
            public const string Comments9Of10 = "TEXTCMNT9";

            /// <summary>
            /// Property for Comments10Of10
            /// </summary>
            public const string Comments10Of10 = "TEXTCMNT10";

            /// <summary>
            /// Property for CommentType 
            /// </summary>
            public const string CommentType = "CMNTTYPE";

            /// <summary>
            /// Property for UserID 
            /// </summary>
            public const string UserID = "USERID";

            #endregion
        }

        /// <summary>
        /// Contains list of CustomerComments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CustomerNumber 
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for DateEntered 
            /// </summary>
            public const int DateEntered = 2;

            /// <summary>
            /// Property Indexer for CommentNumber 
            /// </summary>
            public const int CommentNumber = 3;

            /// <summary>
            /// Property Indexer for ExpirationDate 
            /// </summary>
            public const int ExpirationDate = 4;

            /// <summary>
            /// Property Indexer for FollowupDate 
            /// </summary>
            public const int FollowupDate = 5;

            /// <summary>
            /// Property Indexer for Comments 
            /// </summary>
            public const int Comments = 6;

            /// <summary>
            /// Property Indexer for ReverseCount 
            /// </summary>
            public const int ReverseCount = 7;

            /// <summary>
            /// Property Indexer for Comments1Of10 
            /// </summary>
            public const int Comments1Of10 = 8;

            /// <summary>
            /// Property Indexer for Comments2Of10 
            /// </summary>
            public const int Comments2Of10 = 9;

            /// <summary>
            /// Property Indexer for Comments3Of10 
            /// </summary>
            public const int Comments3Of10 = 10;

            /// <summary>
            /// Property Indexer for Comments4Of10 
            /// </summary>
            public const int Comments4Of10 = 11;

            /// <summary>
            /// Property Indexer for Comments5Of10 
            /// </summary>
            public const int Comments5Of10 = 12;

            /// <summary>
            /// Property Indexer for Comments6Of10 
            /// </summary>
            public const int Comments6Of10 = 13;

            /// <summary>
            /// Property Indexer for Comments7Of10 
            /// </summary>
            public const int Comments7Of10 = 14;

            /// <summary>
            /// Property Indexer for Comments8Of10 
            /// </summary>
            public const int Comments8Of10 = 15;

            /// <summary>
            /// Property Indexer for Comments9Of10 
            /// </summary>
            public const int Comments9Of10 = 16;

            /// <summary>
            /// Property Indexer for Comments10Of10 
            /// </summary>
            public const int Comments10Of10 = 17;

            /// <summary>
            /// Property Indexer for CommentType 
            /// </summary>
            public const int CommentType = 18;

            /// <summary>
            /// Property Indexer for UserID 
            /// </summary>
            public const int UserID = 19;

            #endregion
        }
    }
}