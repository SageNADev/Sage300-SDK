// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of PostRefundsFields Constants 
    /// </summary>
    public partial class PostRefund
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0150";

        /// <summary>
        /// Contains list of PostPaymentsandAdjustments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for PostAllBatches 
            /// </summary>
            public const string PostAllBatches = "SWALLBTCH";

            /// <summary>
            /// Property for PostBatchFrom 
            /// </summary>
            public const string PostBatchFrom = "BATCHIDFR";

            /// <summary>
            /// Property for PostBatchTo 
            /// </summary>
            public const string PostBatchTo = "BATCHIDTO";

            #endregion
        }

        /// <summary>
        /// Contains list of PostPaymentsandAdjustments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for PostAllBatches 
            /// </summary>
            public const int PostAllBatches = 1;

            /// <summary>
            /// Property Indexer for PostBatchFrom 
            /// </summary>
            public const int PostBatchFrom = 2;

            /// <summary>
            /// Property Indexer for PostBatchTo 
            /// </summary>
            public const int PostBatchTo = 3;

            #endregion
        }
    }
}
