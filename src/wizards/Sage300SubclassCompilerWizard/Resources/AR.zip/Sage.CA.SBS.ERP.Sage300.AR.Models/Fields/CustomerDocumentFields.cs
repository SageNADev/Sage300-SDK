// Copyright (c) 2015-2017 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of Document Constants
    /// </summary>
    public partial class CustomerDocument
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0130";

        #region Properties

        /// <summary>
        /// Contains list of Document Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "IDINVC";

            /// <summary>
            /// Property for CheckReceiptNo
            /// </summary>
            public const string CheckReceiptNo = "IDRMIT";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "IDORDERNBR";

            /// <summary>
            /// Property for PONumber
            /// </summary>
            public const string PONumber = "IDCUSTPO";

            /// <summary>
            /// Property for ShipmentNumber
            /// </summary>
            public const string ShipmentNumber = "IDSHIPNBR";

            /// <summary>
            /// Property for DueDate
            /// </summary>
            public const string DueDate = "DATEDUE";

            /// <summary>
            /// Property for NationalAccountNumber
            /// </summary>
            public const string NationalAccountNumber = "IDNATACCT";

            /// <summary>
            /// Property for ShipToLocation
            /// </summary>
            public const string ShipToLocation = "IDCUSTSHPT";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRXTYPEID";

            /// <summary>
            /// Property for DocumentType
            /// </summary>
            public const string DocumentType = "TRXTYPETXT";

            /// <summary>
            /// Property for BatchDate
            /// </summary>
            public const string BatchDate = "DATEBTCH";

            /// <summary>
            /// Property for BatchNumber
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for EntryNumber
            /// </summary>
            public const string EntryNumber = "CNTITEM";

            /// <summary>
            /// Property for GroupCode
            /// </summary>
            public const string GroupCode = "IDGRP";

            /// <summary>
            /// Property for DocumentDescription
            /// </summary>
            public const string DocumentDescription = "DESCINVC";

            /// <summary>
            /// Property for DocumentDate
            /// </summary>
            public const string DocumentDate = "DATEINVC";

            /// <summary>
            /// Property for AsofDate
            /// </summary>
            public const string AsofDate = "DATEASOF";

            /// <summary>
            /// Property for Terms
            /// </summary>
            public const string Terms = "CODETERM";

            /// <summary>
            /// Property for DiscountDate
            /// </summary>
            public const string DiscountDate = "DATEDISC";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "IDRATETYPE";

            /// <summary>
            /// Property for RateOverridden
            /// </summary>
            public const string RateOverridden = "SWRATEOVRD";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "EXCHRATEHC";

            /// <summary>
            /// Property for FuncCurrencyInvoiceAmount
            /// </summary>
            public const string FuncCurrencyInvoiceAmount = "AMTINVCHC";

            /// <summary>
            /// Property for FuncCurrencyAmountDue
            /// </summary>
            public const string FuncCurrencyAmountDue = "AMTDUEHC";

            /// <summary>
            /// Property for FuncCurrencyTaxableAmount
            /// </summary>
            public const string FuncCurrencyTaxableAmount = "AMTTXBLHC";

            /// <summary>
            /// Property for FuncCurrencyNonTaxableAmt
            /// </summary>
            public const string FuncCurrencyNonTaxableAmt = "AMTNONTXHC";

            /// <summary>
            /// Property for FuncCurrencyTaxAmount
            /// </summary>
            public const string FuncCurrencyTaxAmount = "AMTTAXHC";

            /// <summary>
            /// Property for FuncCurrencyDiscountAmount
            /// </summary>
            public const string FuncCurrencyDiscountAmount = "AMTDISCHC";

            /// <summary>
            /// Property for CustCurrencyInvoiceAmount
            /// </summary>
            public const string CustCurrencyInvoiceAmount = "AMTINVCTC";

            /// <summary>
            /// Property for CustCurrencyAmountDue
            /// </summary>
            public const string CustCurrencyAmountDue = "AMTDUETC";

            /// <summary>
            /// Property for CustCurrencyTaxableAmount
            /// </summary>
            public const string CustCurrencyTaxableAmount = "AMTTXBLTC";

            /// <summary>
            /// Property for CustCurrencyNonTaxableAmt
            /// </summary>
            public const string CustCurrencyNonTaxableAmt = "AMTNONTXTC";

            /// <summary>
            /// Property for CustCurrencyTaxAmount
            /// </summary>
            public const string CustCurrencyTaxAmount = "AMTTAXTC";

            /// <summary>
            /// Property for CustCurrencyDiscountAmount
            /// </summary>
            public const string CustCurrencyDiscountAmount = "AMTDISCTC";

            /// <summary>
            /// Property for FullyPaid
            /// </summary>
            public const string FullyPaid = "SWPAID";

            /// <summary>
            /// Property for LastActivityDate
            /// </summary>
            public const string LastActivityDate = "DATELSTACT";

            /// <summary>
            /// Property for LastStatementDate
            /// </summary>
            public const string LastStatementDate = "DATELSTSTM";

            /// <summary>
            /// Property for NumberOfScheduledPayments
            /// </summary>
            public const string NumberOfScheduledPayments = "CNTTOTPAYM";

            /// <summary>
            /// Property for LastPaymentNumberPaid
            /// </summary>
            public const string LastPaymentNumberPaid = "CNTLSTPAID";

            /// <summary>
            /// Property for PaymentNumberonLastStatement
            /// </summary>
            public const string PaymentNumberonLastStatement = "CNTLSTPYST";

            /// <summary>
            /// Property for ReceiptAmountApplied
            /// </summary>
            public const string ReceiptAmountApplied = "AMTREMIT";

            /// <summary>
            /// Property for LastAppliedPaymentSeqNo
            /// </summary>
            public const string LastAppliedPaymentSeqNo = "CNTLASTSEQ";

            /// <summary>
            /// Property for TaxOverrideSwitch
            /// </summary>
            public const string TaxOverrideSwitch = "SWTAXINPUT";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "CODETAX1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "CODETAX2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "CODETAX3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "CODETAX4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "CODETAX5";

            /// <summary>
            /// Property for FuncBaseAmount1
            /// </summary>
            public const string FuncBaseAmount1 = "AMTBASE1HC";

            /// <summary>
            /// Property for FuncBaseAmount2
            /// </summary>
            public const string FuncBaseAmount2 = "AMTBASE2HC";

            /// <summary>
            /// Property for FuncBaseAmount3
            /// </summary>
            public const string FuncBaseAmount3 = "AMTBASE3HC";

            /// <summary>
            /// Property for FuncBaseAmount4
            /// </summary>
            public const string FuncBaseAmount4 = "AMTBASE4HC";

            /// <summary>
            /// Property for FuncBaseAmount5
            /// </summary>
            public const string FuncBaseAmount5 = "AMTBASE5HC";

            /// <summary>
            /// Property for FuncTaxAmount1
            /// </summary>
            public const string FuncTaxAmount1 = "AMTTAX1HC";

            /// <summary>
            /// Property for FuncTaxAmount2
            /// </summary>
            public const string FuncTaxAmount2 = "AMTTAX2HC";

            /// <summary>
            /// Property for FuncTaxAmount3
            /// </summary>
            public const string FuncTaxAmount3 = "AMTTAX3HC";

            /// <summary>
            /// Property for FuncTaxAmount4
            /// </summary>
            public const string FuncTaxAmount4 = "AMTTAX4HC";

            /// <summary>
            /// Property for FuncTaxAmount5
            /// </summary>
            public const string FuncTaxAmount5 = "AMTTAX5HC";

            /// <summary>
            /// Property for CustBaseAmount1
            /// </summary>
            public const string CustBaseAmount1 = "AMTBASE1TC";

            /// <summary>
            /// Property for CustBaseAmount2
            /// </summary>
            public const string CustBaseAmount2 = "AMTBASE2TC";

            /// <summary>
            /// Property for CustBaseAmount3
            /// </summary>
            public const string CustBaseAmount3 = "AMTBASE3TC";

            /// <summary>
            /// Property for CustBaseAmount4
            /// </summary>
            public const string CustBaseAmount4 = "AMTBASE4TC";

            /// <summary>
            /// Property for CustBaseAmount5
            /// </summary>
            public const string CustBaseAmount5 = "AMTBASE5TC";

            /// <summary>
            /// Property for CustTaxAmount1
            /// </summary>
            public const string CustTaxAmount1 = "AMTTAX1TC";

            /// <summary>
            /// Property for CustTaxAmount2
            /// </summary>
            public const string CustTaxAmount2 = "AMTTAX2TC";

            /// <summary>
            /// Property for CustTaxAmount3
            /// </summary>
            public const string CustTaxAmount3 = "AMTTAX3TC";

            /// <summary>
            /// Property for CustTaxAmount4
            /// </summary>
            public const string CustTaxAmount4 = "AMTTAX4TC";

            /// <summary>
            /// Property for CustTaxAmount5
            /// </summary>
            public const string CustTaxAmount5 = "AMTTAX5TC";

            /// <summary>
            /// Property for Salesperson1
            /// </summary>
            public const string Salesperson1 = "CODESLSP1";

            /// <summary>
            /// Property for Salesperson2
            /// </summary>
            public const string Salesperson2 = "CODESLSP2";

            /// <summary>
            /// Property for Salesperson3
            /// </summary>
            public const string Salesperson3 = "CODESLSP3";

            /// <summary>
            /// Property for Salesperson4
            /// </summary>
            public const string Salesperson4 = "CODESLSP4";

            /// <summary>
            /// Property for Salesperson5
            /// </summary>
            public const string Salesperson5 = "CODESLSP5";

            /// <summary>
            /// Property for SalesSplitPercentage1
            /// </summary>
            public const string SalesSplitPercentage1 = "PCTSASPLT1";

            /// <summary>
            /// Property for SalesSplitPercentage2
            /// </summary>
            public const string SalesSplitPercentage2 = "PCTSASPLT2";

            /// <summary>
            /// Property for SalesSplitPercentage3
            /// </summary>
            public const string SalesSplitPercentage3 = "PCTSASPLT3";

            /// <summary>
            /// Property for SalesSplitPercentage4
            /// </summary>
            public const string SalesSplitPercentage4 = "PCTSASPLT4";

            /// <summary>
            /// Property for SalesSplitPercentage5
            /// </summary>
            public const string SalesSplitPercentage5 = "PCTSASPLT5";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPER";

            /// <summary>
            /// Property for PrepayApplytoDocNo
            /// </summary>
            public const string PrepayApplytoDocNo = "IDPREPAID";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperator
            /// </summary>
            public const string RateOperator = "RATEOP";

            /// <summary>
            /// Property for LastActivityYearPeriod
            /// </summary>
            public const string LastActivityYearPeriod = "YPLASTACT";

            /// <summary>
            /// Property for BankCode
            /// </summary>
            public const string BankCode = "IDBANK";

            /// <summary>
            /// Property for DepositNumber
            /// </summary>
            public const string DepositNumber = "DEPSTNBR";

            /// <summary>
            /// Property for PostingSequenceNo
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNCE";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for HasRetainage
            /// </summary>
            public const string HasRetainage = "SWRTG";

            /// <summary>
            /// Property for RetainageOutstanding
            /// </summary>
            public const string RetainageOutstanding = "SWRTGOUT";

            /// <summary>
            /// Property for DateRetainageDue
            /// </summary>
            public const string DateRetainageDue = "RTGDATEDUE";

            /// <summary>
            /// Property for FuncCurrOrigRtngAmt
            /// </summary>
            public const string FuncCurrOrigRtngAmt = "RTGOAMTHC";

            /// <summary>
            /// Property for FuncCurrRetainageAmount
            /// </summary>
            public const string FuncCurrRetainageAmount = "RTGAMTHC";

            /// <summary>
            /// Property for CustCurrOrigRtngAmt
            /// </summary>
            public const string CustCurrOrigRtngAmt = "RTGOAMTTC";

            /// <summary>
            /// Property for CustCurrRetainageAmount
            /// </summary>
            public const string CustCurrRetainageAmount = "RTGAMTTC";

            /// <summary>
            /// Property for RetainageTermsCode
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";

            /// <summary>
            /// Property for RetainageExchangeRate
            /// </summary>
            public const string RetainageExchangeRate = "SWRTGRATE";

            /// <summary>
            /// Property for OriginalDocNo
            /// </summary>
            public const string OriginalDocNo = "RTGAPPLYTO";

            /// <summary>
            /// Property for FunctionalPendingReceiptAmoun
            /// </summary>
            public const string FunctionalPendingReceiptAmoun = "PNDPAYTOTH";

            /// <summary>
            /// Property for FunctionalPendingDiscountAmou
            /// </summary>
            public const string FunctionalPendingDiscountAmou = "PNDDSCTOTH";

            /// <summary>
            /// Property for FunctionalPendingAdjustmentAm
            /// </summary>
            public const string FunctionalPendingAdjustmentAm = "PNDADJTOTH";

            /// <summary>
            /// Property for FunctionalPendingBalance
            /// </summary>
            public const string FunctionalPendingBalance = "PENDNGBALH";

            /// <summary>
            /// Property for PendingReceiptAmount
            /// </summary>
            public const string PendingReceiptAmount = "PNDPAYTOT";

            /// <summary>
            /// Property for PendingDiscountAmount
            /// </summary>
            public const string PendingDiscountAmount = "PNDDSCTOT";

            /// <summary>
            /// Property for PendingAdjustmentAmount
            /// </summary>
            public const string PendingAdjustmentAmount = "PNDADJTOT";

            /// <summary>
            /// Property for PendingBalance
            /// </summary>
            public const string PendingBalance = "PENDNGBAL";

            /// <summary>
            /// Property for CustomerNoUsedToCalculateP
            /// </summary>
            public const string CustomerNoUsedToCalculateP = "IDCUSTPEND";

            /// <summary>
            /// Property for ShowPendingAmountsSwitch
            /// </summary>
            public const string ShowPendingAmountsSwitch = "SWSHOWPEND";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for SourceApplication
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";

            /// <summary>
            /// Property for ARVersionCreatedIn
            /// </summary>
            public const string ARVersionCreatedIn = "ARVERSION";

            /// <summary>
            /// Property for InvoiceType
            /// </summary>
            public const string InvoiceType = "INVCTYPE";

            /// <summary>
            /// Property for DepositSerialNumber
            /// </summary>
            public const string DepositSerialNumber = "DEPSEQ";

            /// <summary>
            /// Property for DepositLineNumber
            /// </summary>
            public const string DepositLineNumber = "DEPLINE";

            /// <summary>
            /// Property for BatchType
            /// </summary>
            public const string BatchType = "TYPEBTCH";

            /// <summary>
            /// Property for NumberOfOBLJDetails
            /// </summary>
            public const string NumberOfOBLJDetails = "CNTOBLJ";

            /// <summary>
            /// Property for Obsolete
            /// </summary>
            public const string Obsolete = "SWSHOWPAID";

            /// <summary>
            /// Property for ShowMembers
            /// </summary>
            public const string ShowMembers = "SWMEMBERS";

            /// <summary>
            /// Property for MiscReceiptFlag
            /// </summary>
            public const string MiscReceiptFlag = "SWNONRCVBL";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of Document Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 2;

            /// <summary>
            /// Property Indexer for CheckReceiptNo
            /// </summary>
            public const int CheckReceiptNo = 3;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 4;

            /// <summary>
            /// Property Indexer for PONumber
            /// </summary>
            public const int PONumber = 5;

            /// <summary>
            /// Property Indexer for ShipmentNumber
            /// </summary>
            public const int ShipmentNumber = 6;

            /// <summary>
            /// Property Indexer for DueDate
            /// </summary>
            public const int DueDate = 7;

            /// <summary>
            /// Property Indexer for NationalAccountNumber
            /// </summary>
            public const int NationalAccountNumber = 8;

            /// <summary>
            /// Property Indexer for ShipToLocation
            /// </summary>
            public const int ShipToLocation = 9;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 10;

            /// <summary>
            /// Property Indexer for DocumentType
            /// </summary>
            public const int DocumentType = 11;

            /// <summary>
            /// Property Indexer for BatchDate
            /// </summary>
            public const int BatchDate = 12;

            /// <summary>
            /// Property Indexer for BatchNumber
            /// </summary>
            public const int BatchNumber = 13;

            /// <summary>
            /// Property Indexer for EntryNumber
            /// </summary>
            public const int EntryNumber = 14;

            /// <summary>
            /// Property Indexer for GroupCode
            /// </summary>
            public const int GroupCode = 15;

            /// <summary>
            /// Property Indexer for DocumentDescription
            /// </summary>
            public const int DocumentDescription = 16;

            /// <summary>
            /// Property Indexer for DocumentDate
            /// </summary>
            public const int DocumentDate = 17;

            /// <summary>
            /// Property Indexer for AsofDate
            /// </summary>
            public const int AsofDate = 18;

            /// <summary>
            /// Property Indexer for Terms
            /// </summary>
            public const int Terms = 19;

            /// <summary>
            /// Property Indexer for DiscountDate
            /// </summary>
            public const int DiscountDate = 20;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 21;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 22;

            /// <summary>
            /// Property Indexer for RateOverridden
            /// </summary>
            public const int RateOverridden = 23;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 24;

            /// <summary>
            /// Property Indexer for FuncCurrencyInvoiceAmount
            /// </summary>
            public const int FuncCurrencyInvoiceAmount = 25;

            /// <summary>
            /// Property Indexer for FuncCurrencyAmountDue
            /// </summary>
            public const int FuncCurrencyAmountDue = 26;

            /// <summary>
            /// Property Indexer for FuncCurrencyTaxableAmount
            /// </summary>
            public const int FuncCurrencyTaxableAmount = 27;

            /// <summary>
            /// Property Indexer for FuncCurrencyNonTaxableAmt
            /// </summary>
            public const int FuncCurrencyNonTaxableAmt = 28;

            /// <summary>
            /// Property Indexer for FuncCurrencyTaxAmount
            /// </summary>
            public const int FuncCurrencyTaxAmount = 29;

            /// <summary>
            /// Property Indexer for FuncCurrencyDiscountAmount
            /// </summary>
            public const int FuncCurrencyDiscountAmount = 30;

            /// <summary>
            /// Property Indexer for CustCurrencyInvoiceAmount
            /// </summary>
            public const int CustCurrencyInvoiceAmount = 31;

            /// <summary>
            /// Property Indexer for CustCurrencyAmountDue
            /// </summary>
            public const int CustCurrencyAmountDue = 32;

            /// <summary>
            /// Property Indexer for CustCurrencyTaxableAmount
            /// </summary>
            public const int CustCurrencyTaxableAmount = 33;

            /// <summary>
            /// Property Indexer for CustCurrencyNonTaxableAmt
            /// </summary>
            public const int CustCurrencyNonTaxableAmt = 34;

            /// <summary>
            /// Property Indexer for CustCurrencyTaxAmount
            /// </summary>
            public const int CustCurrencyTaxAmount = 35;

            /// <summary>
            /// Property Indexer for CustCurrencyDiscountAmount
            /// </summary>
            public const int CustCurrencyDiscountAmount = 36;

            /// <summary>
            /// Property Indexer for FullyPaid
            /// </summary>
            public const int FullyPaid = 37;

            /// <summary>
            /// Property Indexer for LastActivityDate
            /// </summary>
            public const int LastActivityDate = 38;

            /// <summary>
            /// Property Indexer for LastStatementDate
            /// </summary>
            public const int LastStatementDate = 39;

            /// <summary>
            /// Property Indexer for NumberOfScheduledPayments
            /// </summary>
            public const int NumberOfScheduledPayments = 42;

            /// <summary>
            /// Property Indexer for LastPaymentNumberPaid
            /// </summary>
            public const int LastPaymentNumberPaid = 43;

            /// <summary>
            /// Property Indexer for PaymentNumberonLastStatement
            /// </summary>
            public const int PaymentNumberonLastStatement = 44;

            /// <summary>
            /// Property Indexer for ReceiptAmountApplied
            /// </summary>
            public const int ReceiptAmountApplied = 45;

            /// <summary>
            /// Property Indexer for LastAppliedPaymentSeqNo
            /// </summary>
            public const int LastAppliedPaymentSeqNo = 46;

            /// <summary>
            /// Property Indexer for TaxOverrideSwitch
            /// </summary>
            public const int TaxOverrideSwitch = 47;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 48;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 49;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 50;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 51;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 52;

            /// <summary>
            /// Property Indexer for FuncBaseAmount1
            /// </summary>
            public const int FuncBaseAmount1 = 53;

            /// <summary>
            /// Property Indexer for FuncBaseAmount2
            /// </summary>
            public const int FuncBaseAmount2 = 54;

            /// <summary>
            /// Property Indexer for FuncBaseAmount3
            /// </summary>
            public const int FuncBaseAmount3 = 55;

            /// <summary>
            /// Property Indexer for FuncBaseAmount4
            /// </summary>
            public const int FuncBaseAmount4 = 56;

            /// <summary>
            /// Property Indexer for FuncBaseAmount5
            /// </summary>
            public const int FuncBaseAmount5 = 57;

            /// <summary>
            /// Property Indexer for FuncTaxAmount1
            /// </summary>
            public const int FuncTaxAmount1 = 58;

            /// <summary>
            /// Property Indexer for FuncTaxAmount2
            /// </summary>
            public const int FuncTaxAmount2 = 59;

            /// <summary>
            /// Property Indexer for FuncTaxAmount3
            /// </summary>
            public const int FuncTaxAmount3 = 60;

            /// <summary>
            /// Property Indexer for FuncTaxAmount4
            /// </summary>
            public const int FuncTaxAmount4 = 61;

            /// <summary>
            /// Property Indexer for FuncTaxAmount5
            /// </summary>
            public const int FuncTaxAmount5 = 62;

            /// <summary>
            /// Property Indexer for CustBaseAmount1
            /// </summary>
            public const int CustBaseAmount1 = 63;

            /// <summary>
            /// Property Indexer for CustBaseAmount2
            /// </summary>
            public const int CustBaseAmount2 = 64;

            /// <summary>
            /// Property Indexer for CustBaseAmount3
            /// </summary>
            public const int CustBaseAmount3 = 65;

            /// <summary>
            /// Property Indexer for CustBaseAmount4
            /// </summary>
            public const int CustBaseAmount4 = 66;

            /// <summary>
            /// Property Indexer for CustBaseAmount5
            /// </summary>
            public const int CustBaseAmount5 = 67;

            /// <summary>
            /// Property Indexer for CustTaxAmount1
            /// </summary>
            public const int CustTaxAmount1 = 68;

            /// <summary>
            /// Property Indexer for CustTaxAmount2
            /// </summary>
            public const int CustTaxAmount2 = 69;

            /// <summary>
            /// Property Indexer for CustTaxAmount3
            /// </summary>
            public const int CustTaxAmount3 = 70;

            /// <summary>
            /// Property Indexer for CustTaxAmount4
            /// </summary>
            public const int CustTaxAmount4 = 71;

            /// <summary>
            /// Property Indexer for CustTaxAmount5
            /// </summary>
            public const int CustTaxAmount5 = 72;

            /// <summary>
            /// Property Indexer for Salesperson1
            /// </summary>
            public const int Salesperson1 = 73;

            /// <summary>
            /// Property Indexer for Salesperson2
            /// </summary>
            public const int Salesperson2 = 74;

            /// <summary>
            /// Property Indexer for Salesperson3
            /// </summary>
            public const int Salesperson3 = 75;

            /// <summary>
            /// Property Indexer for Salesperson4
            /// </summary>
            public const int Salesperson4 = 76;

            /// <summary>
            /// Property Indexer for Salesperson5
            /// </summary>
            public const int Salesperson5 = 77;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage1
            /// </summary>
            public const int SalesSplitPercentage1 = 78;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage2
            /// </summary>
            public const int SalesSplitPercentage2 = 79;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage3
            /// </summary>
            public const int SalesSplitPercentage3 = 80;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage4
            /// </summary>
            public const int SalesSplitPercentage4 = 81;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage5
            /// </summary>
            public const int SalesSplitPercentage5 = 82;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 90;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 91;

            /// <summary>
            /// Property Indexer for PrepayApplytoDocNo
            /// </summary>
            public const int PrepayApplytoDocNo = 92;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 93;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 94;

            /// <summary>
            /// Property Indexer for RateOperator
            /// </summary>
            public const int RateOperator = 95;

            /// <summary>
            /// Property Indexer for LastActivityYearPeriod
            /// </summary>
            public const int LastActivityYearPeriod = 96;

            /// <summary>
            /// Property Indexer for BankCode
            /// </summary>
            public const int BankCode = 97;

            /// <summary>
            /// Property Indexer for DepositNumber
            /// </summary>
            public const int DepositNumber = 98;

            /// <summary>
            /// Property Indexer for PostingSequenceNo
            /// </summary>
            public const int PostingSequenceNo = 99;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 100;

            /// <summary>
            /// Property Indexer for HasRetainage
            /// </summary>
            public const int HasRetainage = 101;

            /// <summary>
            /// Property Indexer for RetainageOutstanding
            /// </summary>
            public const int RetainageOutstanding = 102;

            /// <summary>
            /// Property Indexer for DateRetainageDue
            /// </summary>
            public const int DateRetainageDue = 103;

            /// <summary>
            /// Property Indexer for FuncCurrOrigRtngAmt
            /// </summary>
            public const int FuncCurrOrigRtngAmt = 104;

            /// <summary>
            /// Property Indexer for FuncCurrRetainageAmount
            /// </summary>
            public const int FuncCurrRetainageAmount = 105;

            /// <summary>
            /// Property Indexer for CustCurrOrigRtngAmt
            /// </summary>
            public const int CustCurrOrigRtngAmt = 106;

            /// <summary>
            /// Property Indexer for CustCurrRetainageAmount
            /// </summary>
            public const int CustCurrRetainageAmount = 107;

            /// <summary>
            /// Property Indexer for RetainageTermsCode
            /// </summary>
            public const int RetainageTermsCode = 108;

            /// <summary>
            /// Property Indexer for RetainageExchangeRate
            /// </summary>
            public const int RetainageExchangeRate = 109;

            /// <summary>
            /// Property Indexer for OriginalDocNo
            /// </summary>
            public const int OriginalDocNo = 110;

            /// <summary>
            /// Property Indexer for FunctionalPendingReceiptAmoun
            /// </summary>
            public const int FunctionalPendingReceiptAmoun = 111;

            /// <summary>
            /// Property Indexer for FunctionalPendingDiscountAmou
            /// </summary>
            public const int FunctionalPendingDiscountAmou = 112;

            /// <summary>
            /// Property Indexer for FunctionalPendingAdjustmentAm
            /// </summary>
            public const int FunctionalPendingAdjustmentAm = 113;

            /// <summary>
            /// Property Indexer for FunctionalPendingBalance
            /// </summary>
            public const int FunctionalPendingBalance = 114;

            /// <summary>
            /// Property Indexer for PendingReceiptAmount
            /// </summary>
            public const int PendingReceiptAmount = 115;

            /// <summary>
            /// Property Indexer for PendingDiscountAmount
            /// </summary>
            public const int PendingDiscountAmount = 116;

            /// <summary>
            /// Property Indexer for PendingAdjustmentAmount
            /// </summary>
            public const int PendingAdjustmentAmount = 117;

            /// <summary>
            /// Property Indexer for PendingBalance
            /// </summary>
            public const int PendingBalance = 118;

            /// <summary>
            /// Property Indexer for CustomerNoUsedToCalculateP
            /// </summary>
            public const int CustomerNoUsedToCalculateP = 119;

            /// <summary>
            /// Property Indexer for ShowPendingAmountsSwitch
            /// </summary>
            public const int ShowPendingAmountsSwitch = 120;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 121;

            /// <summary>
            /// Property Indexer for SourceApplication
            /// </summary>
            public const int SourceApplication = 122;

            /// <summary>
            /// Property Indexer for ARVersionCreatedIn
            /// </summary>
            public const int ARVersionCreatedIn = 123;

            /// <summary>
            /// Property Indexer for InvoiceType
            /// </summary>
            public const int InvoiceType = 124;

            /// <summary>
            /// Property Indexer for DepositSerialNumber
            /// </summary>
            public const int DepositSerialNumber = 125;

            /// <summary>
            /// Property Indexer for DepositLineNumber
            /// </summary>
            public const int DepositLineNumber = 126;

            /// <summary>
            /// Property Indexer for BatchType
            /// </summary>
            public const int BatchType = 127;

            /// <summary>
            /// Property Indexer for NumberOfOBLJDetails
            /// </summary>
            public const int NumberOfOBLJDetails = 128;

            /// <summary>
            /// Property Indexer for Obsolete
            /// </summary>
            public const int Obsolete = 129;

            /// <summary>
            /// Property Indexer for ShowMembers
            /// </summary>
            public const int ShowMembers = 130;

            /// <summary>
            /// Property Indexer for MiscReceiptFlag
            /// </summary>
            public const int MiscReceiptFlag = 155;
        }

        #endregion

    }
}
