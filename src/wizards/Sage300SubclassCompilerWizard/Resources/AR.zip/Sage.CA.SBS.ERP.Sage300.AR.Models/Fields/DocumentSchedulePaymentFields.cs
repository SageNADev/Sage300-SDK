// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using System.Globalization;
// ReSharper disable CheckNamespace


namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of DocumentSchedulePayment Constants
     /// </summary>
     public partial class DocumentSchedulePayment
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "AR0037";

          #region Properties
          /// <summary>
          /// Contains list of DocumentSched.Payment Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CustomerNumber
               /// </summary>
               public const string CustomerNumber = "IDCUST";

               /// <summary>
               /// Property for DocumentNumber
               /// </summary>
               public const string DocumentNumber = "IDINVC";

               /// <summary>
               /// Property for PaymentNumber
               /// </summary>
               public const string PaymentNumber = "CNTPAYM";

               /// <summary>
               /// Property for ReceiptNumber
               /// </summary>
               public const string ReceiptNumber = "IDRMIT";

               /// <summary>
               /// Property for DueDate
               /// </summary>
               public const string DueDate = "DATEDUE";

               /// <summary>
               /// Property for DiscountDate
               /// </summary>
               public const string DiscountDate = "DATEDISC";

               /// <summary>
               /// Property for FullyPaidSwitch
               /// </summary>
               public const string FullyPaidSwitch = "SWPAID";

               /// <summary>
               /// Property for OriginalAmountFunc
               /// </summary>
               public const string OriginalAmountFunc = "AMTDUEHC";

               /// <summary>
               /// Property for OriginalDiscountFunc
               /// </summary>
               public const string OriginalDiscountFunc = "AMTDISCHC";

               /// <summary>
               /// Property for RemainingDiscountFunc
               /// </summary>
               public const string RemainingDiscountFunc = "AMTDCSRMHC";

               /// <summary>
               /// Property for RemainingAmountFunc
               /// </summary>
               public const string RemainingAmountFunc = "AMTPYMRMHC";

               /// <summary>
               /// Property for OriginalAmount
               /// </summary>
               public const string OriginalAmount = "AMTDUETC";

               /// <summary>
               /// Property for OriginalDiscount
               /// </summary>
               public const string OriginalDiscount = "AMTDISCTC";

               /// <summary>
               /// Property for RemainingDiscount
               /// </summary>
               public const string RemainingDiscount = "AMTDSCRMTC";

               /// <summary>
               /// Property for RemainingAmount
               /// </summary>
               public const string RemainingAmount = "AMTPYMRMTC";

               /// <summary>
               /// Property for OrderNumber
               /// </summary>
               public const string OrderNumber = "IDORDRNBR";

               /// <summary>
               /// Property for PONumber
               /// </summary>
               public const string PONumber = "IDCUSTPO";

               /// <summary>
               /// Property for NationalAccountNumber
               /// </summary>
               public const string NationalAccountNumber = "IDNATACCT";

               /// <summary>
               /// Property for GroupCode
               /// </summary>
               public const string GroupCode = "IDGRP";

               /// <summary>
               /// Property for PrepayApplytoDocNo
               /// </summary>
               public const string PrepayApplytoDocNo = "IDPREPAID";

               /// <summary>
               /// Property for TransactionType
               /// </summary>
               public const string TransactionType = "IDTRXTYPE";

               /// <summary>
               /// Property for DocumentType
               /// </summary>
               public const string DocumentType = "TXTTRXTYPE";

               /// <summary>
               /// Property for DocumentDate
               /// </summary>
               public const string DocumentDate = "DATEINVC";

               /// <summary>
               /// Property for NumberOfDaysToPay
               /// </summary>
               public const string NumberOfDaysToPay = "DAYSTOPAY";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelated = "SWJOB";

               /// <summary>
               /// Property for ShipmentNumber
               /// </summary>
               public const string ShipmentNumber = "IDSHIPNBR";

               /// <summary>
               /// Property for OriginalDocNo
               /// </summary>
               public const string OriginalDocNo = "RTGAPPLYTO";

              #region UI

               /// <summary>
               /// Property for DocumentType
               /// </summary>
               public const string DocumentTypeString = "TXTTRXTYPE";

               /// <summary>
               /// Property for FullyPaidSwitch
               /// </summary>
               public const string FullyPaidSwitchString = "SWPAID";

               /// <summary>
               /// Property for TransactionType
               /// </summary>
               public const string TransactionTypeString = "IDTRXTYPE";

               /// <summary>
               /// Property for JobRelated
               /// </summary>
               public const string JobRelatedString = "SWJOB";

              #endregion

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of DocumentSched.Payment Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CustomerNumber
               /// </summary>
               public const int CustomerNumber = 1;

               /// <summary>
               /// Property Indexer for DocumentNumber
               /// </summary>
               public const int DocumentNumber = 2;

               /// <summary>
               /// Property Indexer for PaymentNumber
               /// </summary>
               public const int PaymentNumber = 3;

               /// <summary>
               /// Property Indexer for ReceiptNumber
               /// </summary>
               public const int ReceiptNumber = 4;

               /// <summary>
               /// Property Indexer for DueDate
               /// </summary>
               public const int DueDate = 5;

               /// <summary>
               /// Property Indexer for DiscountDate
               /// </summary>
               public const int DiscountDate = 6;

               /// <summary>
               /// Property Indexer for FullyPaidSwitch
               /// </summary>
               public const int FullyPaidSwitch = 7;

               /// <summary>
               /// Property Indexer for OriginalAmountFunc
               /// </summary>
               public const int OriginalAmountFunc = 9;

               /// <summary>
               /// Property Indexer for OriginalDiscountFunc
               /// </summary>
               public const int OriginalDiscountFunc = 10;

               /// <summary>
               /// Property Indexer for RemainingDiscountFunc
               /// </summary>
               public const int RemainingDiscountFunc = 11;

               /// <summary>
               /// Property Indexer for RemainingAmountFunc
               /// </summary>
               public const int RemainingAmountFunc = 12;

               /// <summary>
               /// Property Indexer for OriginalAmount
               /// </summary>
               public const int OriginalAmount = 13;

               /// <summary>
               /// Property Indexer for OriginalDiscount
               /// </summary>
               public const int OriginalDiscount = 14;

               /// <summary>
               /// Property Indexer for RemainingDiscount
               /// </summary>
               public const int RemainingDiscount = 15;

               /// <summary>
               /// Property Indexer for RemainingAmount
               /// </summary>
               public const int RemainingAmount = 16;

               /// <summary>
               /// Property Indexer for OrderNumber
               /// </summary>
               public const int OrderNumber = 17;

               /// <summary>
               /// Property Indexer for PONumber
               /// </summary>
               public const int PONumber = 18;

               /// <summary>
               /// Property Indexer for NationalAccountNumber
               /// </summary>
               public const int NationalAccountNumber = 19;

               /// <summary>
               /// Property Indexer for GroupCode
               /// </summary>
               public const int GroupCode = 20;

               /// <summary>
               /// Property Indexer for PrepayApplytoDocNo
               /// </summary>
               public const int PrepayApplytoDocNo = 21;

               /// <summary>
               /// Property Indexer for TransactionType
               /// </summary>
               public const int TransactionType = 22;

               /// <summary>
               /// Property Indexer for DocumentType
               /// </summary>
               public const int DocumentType = 23;

               /// <summary>
               /// Property Indexer for DocumentDate
               /// </summary>
               public const int DocumentDate = 24;

               /// <summary>
               /// Property Indexer for NumberOfDaysToPay
               /// </summary>
               public const int NumberOfDaysToPay = 25;

               /// <summary>
               /// Property Indexer for JobRelated
               /// </summary>
               public const int JobRelated = 26;

               /// <summary>
               /// Property Indexer for ShipmentNumber
               /// </summary>
               public const int ShipmentNumber = 27;

               /// <summary>
               /// Property Indexer for OriginalDocNo
               /// </summary>
               public const int OriginalDocNo = 28;

          }
          #endregion

     }
}
