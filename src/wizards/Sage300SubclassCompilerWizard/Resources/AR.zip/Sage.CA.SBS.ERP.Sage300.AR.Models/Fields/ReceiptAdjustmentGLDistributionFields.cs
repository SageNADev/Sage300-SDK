/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{  
    /// <summary>
    /// Field-name, field-index and entity constants for business entity Receipt Adjustment G/L Distributions (rotoview AR0045 - ARTCU).
    /// </summary>
    public partial class ReceiptAdjustmentGLDistributionDetail
    {

        /// <summary>
        /// The Roto ID of the underlying view (AR0045).
        /// </summary>
        /// <remarks>
        /// The name of the underlying view is ARTCU.
        /// </remarks>
        public const string EntityName = "AR0045";

        /// <summary>
        /// Contains list of AdjustmentGLDistributions Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "CODEPAYM";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";
            /// <summary>
            /// Property for SequenceNo 
            /// </summary>
            public const string SequenceNo = "CNTSEQ";
            /// <summary>
            /// Property for TransactionType 
            /// </summary>
            public const string TransactionType = "CODTRXTYPE";
            /// <summary>
            /// Property for DistributionAmount 
            /// </summary>
            public const string DistributionAmount = "AMTDIST";
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDISTCODE";
            /// <summary>
            /// Property for DistributionGOrLAccount 
            /// </summary>
            public const string DistributionGorLAccount = "IDACCT";
            /// <summary>
            /// Property for ContractCode 
            /// </summary>
            public const string ContractCode = "CONTRACT";
            /// <summary>
            /// Property for ProjectCode 
            /// </summary>
            public const string ProjectCode = "PROJECT";
            /// <summary>
            /// Property for CategoryCode 
            /// </summary>
            public const string CategoryCode = "CATEGORY";
            /// <summary>
            /// Property for ProjectOrCategoryResource 
            /// </summary>
            public const string ProjectOrCategoryResource = "RESOURCE";
            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNBR";
            /// <summary>
            /// Property for CostClass 
            /// </summary>
            public const string CostClass = "COSTCLASS";
            /// <summary>
            /// Property for DiscountAmount 
            /// </summary>
            public const string DiscountAmount = "AMTDISC";
            /// <summary>
            /// Property for AppliedAmount 
            /// </summary>
            public const string AppliedAmount = "AMTPAYM";
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "IDITEM";
            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UNITMEAS";
            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "QTYINVC";
            /// <summary>
            /// Property for Cost 
            /// </summary>
            public const string Cost = "AMTCOST";
            /// <summary>
            /// Property for BillingDate 
            /// </summary>
            public const string BillingDate = "BILLDATE";
            /// <summary>
            /// Property for RetainageAmount 
            /// </summary>
            public const string RetainageAmount = "RTGAMT";
            /// <summary>
            /// Property for RetainageDueDate 
            /// </summary>
            public const string RetainageDueDate = "RTGDATEDUE";
            /// <summary>
            /// Property for HasRetainage 
            /// </summary>
            public const string HasRetainage = "SWRTG";
            /// <summary>
            /// Property for FuncDistributionAmount 
            /// </summary>
            public const string FuncDistributionAmount = "AMTDISTHC";
            /// <summary>
            /// Property for FuncDiscountAmount 
            /// </summary>
            public const string FuncDiscountAmount = "AMTDISCHC";
            /// <summary>
            /// Property for FuncAppliedAmount 
            /// </summary>
            public const string FuncAppliedAmount = "AMTPAYMHC";
            /// <summary>
            /// Property for FuncRetainageAmount 
            /// </summary>
            public const string FuncRetainageAmount = "RTGAMTHC";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "TEXTREF";
            /// <summary>
            /// Property for DocumentLineNumber 
            /// </summary>
            public const string DocumentLineNumber = "DOCLINE";
            /// <summary>
            /// Property for CustCurrencyAmountDue 
            /// </summary>
            public const string CustCurrencyAmountDue = "AMTDUETC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1TC = "AMTWHD1TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2TC = "AMTWHD2TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3TC = "AMTWHD3TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4TC = "AMTWHD4TC";

            /// <summary>
            /// Property For Vend. Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5TC = "AMTWHD5TC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1HC = "AMTWHD1HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2HC = "AMTWHD2HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3HC = "AMTWHD3HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4HC = "AMTWHD4HC";

            /// <summary>
            /// Property For Func. Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5HC = "AMTWHD5HC";

            /// <summary>
            /// Property For Tax Withheld Amount Total
            /// </summary>
            public const string AmtWHDTot = "AMTWHDTOT";

            #endregion
        }

        /// <summary>
        /// Contains list of AdjustmentGLDistributions Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 4;
            /// <summary>
            /// Property Indexer for SequenceNo 
            /// </summary>
            public const int SequenceNo = 5;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 6;
            /// <summary>
            /// Property Indexer for DistributionAmount 
            /// </summary>
            public const int DistributionAmount = 7;
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 8;
            /// <summary>
            /// Property Indexer for DistributionGOrLAccount 
            /// </summary>
            public const int DistributionGorLAccount = 9;   
            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 10;
            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 11;
            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 12;
            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 13;
            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 14;
            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 15;
            /// <summary>
            /// Property Indexer for DiscountAmount 
            /// </summary>
            public const int DiscountAmount = 16;
            /// <summary>
            /// Property Indexer for AppliedAmount 
            /// </summary>
            public const int AppliedAmount = 17;
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 18;
            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 19;
            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 20;
            /// <summary>
            /// Property Indexer for Cost 
            /// </summary>
            public const int Cost = 21;
            /// <summary>
            /// Property Indexer for BillingDate 
            /// </summary>
            public const int BillingDate = 22;
            /// <summary>
            /// Property Indexer for RetainageAmount 
            /// </summary>
            public const int RetainageAmount = 23;
            /// <summary>
            /// Property Indexer for RetainageDueDate 
            /// </summary>
            public const int RetainageDueDate = 24;
            /// <summary>
            /// Property Indexer for HasRetainage 
            /// </summary>
            public const int HasRetainage = 25;
            /// <summary>
            /// Property Indexer for FuncDistributionAmount 
            /// </summary>
            public const int FuncDistributionAmount = 26;
            /// <summary>
            /// Property Indexer for FuncDiscountAmount 
            /// </summary>
            public const int FuncDiscountAmount = 27;
            /// <summary>
            /// Property Indexer for FuncAppliedAmount 
            /// </summary>
            public const int FuncAppliedAmount = 28;
            /// <summary>
            /// Property Indexer for FuncRetainageAmount 
            /// </summary>
            public const int FuncRetainageAmount = 29;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 30;
            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 31;
            /// <summary>
            /// Property Indexer for DocumentLineNumber 
            /// </summary>
            public const int DocumentLineNumber = 32;
            /// <summary>
            /// Property Indexer for CustCurrencyAmountDue 
            /// </summary>
            public const int CustCurrencyAmountDue = 33;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1TC = 34;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2TC = 35;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3TC = 36;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4TC = 37;

            /// <summary>
            /// Indexer For Vend. Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5TC = 38;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1HC = 39;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2HC = 40;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3HC = 41;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4HC = 42;

            /// <summary>
            /// Indexer For Func. Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5HC = 43;

            /// <summary>
            /// Indexer For Tax Withheld Amount Total
            /// </summary>
            public const int AmtWHDTot = 44;

            #endregion
        }


    }
}
