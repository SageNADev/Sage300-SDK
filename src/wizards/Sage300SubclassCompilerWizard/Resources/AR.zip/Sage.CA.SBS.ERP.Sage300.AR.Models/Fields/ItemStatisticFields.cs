// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ItemStatistic Constants 
    /// </summary>
	public partial class ItemStatistic 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AR0027";

        /// <summary>
        /// Contains list of ItemStatistic Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for ItemNumber 
        /// </summary>
	    public const string ItemNumber  = "IDITEM";
	            /// <summary>
        /// Property for UnitofMeasure 
        /// </summary>
	    public const string UnitofMeasure  = "IDUOM";
	            /// <summary>
        /// Property for Year 
        /// </summary>
	    public const string Year  = "CNTYR";
	            /// <summary>
        /// Property for Period 
        /// </summary>
	    public const string Period  = "CNTPERD";
	            /// <summary>
        /// Property for DateofLastSale 
        /// </summary>
	    public const string DateofLastSale  = "LASTSALE";
	            /// <summary>
        /// Property for NumberofSales 
        /// </summary>
	    public const string NumberofSales  = "CNTINVC";
	            /// <summary>
        /// Property for NumberofReturns 
        /// </summary>
	    public const string NumberofReturns  = "CNTCR";
	            /// <summary>
        /// Property for TotalAmountSold 
        /// </summary>
	    public const string TotalAmountSold  = "AMTINVC";
	            /// <summary>
        /// Property for TotalAmountReturned 
        /// </summary>
	    public const string TotalAmountReturned  = "AMTCR";
	            /// <summary>
        /// Property for TotalCostofGoodsSold 
        /// </summary>
	    public const string TotalCostofGoodsSold  = "AMTCOG";
	            /// <summary>
        /// Property for TotalGrossMargin 
        /// </summary>
	    public const string TotalGrossMargin  = "AMTGRO";
	            /// <summary>
        /// Property for QuantitySold 
        /// </summary>
	    public const string QuantitySold  = "QTYSOLD";
	            /// <summary>
        /// Property for YTDNumberofSales 
        /// </summary>
	    public const string YtdNumberofSales  = "YTDCNTIN";
	            /// <summary>
        /// Property for YTDNumberofReturns 
        /// </summary>
	    public const string YtdNumberofReturns  = "YTDCNTCR";
	            /// <summary>
        /// Property for YTDTotalAmountSold 
        /// </summary>
	    public const string YtdTotalAmountSold  = "YTDHCIN";
	            /// <summary>
        /// Property for YTDTotalAmountReturned 
        /// </summary>
	    public const string YtdTotalAmountReturned  = "YTDHCCR";
	            /// <summary>
        /// Property for YTDTotalCostofGoodsSold 
        /// </summary>
	    public const string YtdTotalCostofGoodsSold  = "YTDHCCOG";
	            /// <summary>
        /// Property for YTDTotalGrossMargin 
        /// </summary>
	    public const string YtdTotalGrossMargin  = "YTDHCGRO";
	            /// <summary>
        /// Property for YTDQuantitySold 
        /// </summary>
	    public const string YtdQuantitySold  = "YTDQTYSOLD";
	            /// <summary>
        /// Property for YTDDateofLastSale 
        /// </summary>
	    public const string YtdDateofLastSale  = "YTDLSTSALE";
	            /// <summary>
        /// Property for EnableYTDCalculations 
        /// </summary>
	    public const string EnableYtdCalculations  = "YTDACTIVE";
	     
        #endregion
	    }


		/// <summary>
        /// Contains list of ItemStatistic Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for ItemNumber 
        /// </summary>
	    public const int ItemNumber  = 1;
	             /// <summary>
        /// Property Indexer for UnitofMeasure 
        /// </summary>
	    public const int UnitofMeasure  = 2;
	             /// <summary>
        /// Property Indexer for Year 
        /// </summary>
	    public const int Year  = 3;
	             /// <summary>
        /// Property Indexer for Period 
        /// </summary>
	    public const int Period  = 4;
	             /// <summary>
        /// Property Indexer for DateofLastSale 
        /// </summary>
	    public const int DateofLastSale  = 5;
	             /// <summary>
        /// Property Indexer for NumberofSales 
        /// </summary>
	    public const int NumberofSales  = 6;
	             /// <summary>
        /// Property Indexer for NumberofReturns 
        /// </summary>
	    public const int NumberofReturns  = 7;
	             /// <summary>
        /// Property Indexer for TotalAmountSold 
        /// </summary>
	    public const int TotalAmountSold  = 9;
	             /// <summary>
        /// Property Indexer for TotalAmountReturned 
        /// </summary>
	    public const int TotalAmountReturned  = 10;
	             /// <summary>
        /// Property Indexer for TotalCostofGoodsSold 
        /// </summary>
	    public const int TotalCostofGoodsSold  = 11;
	             /// <summary>
        /// Property Indexer for TotalGrossMargin 
        /// </summary>
	    public const int TotalGrossMargin  = 12;
	             /// <summary>
        /// Property Indexer for QuantitySold 
        /// </summary>
	    public const int QuantitySold  = 14;
	             /// <summary>
        /// Property Indexer for YTDNumberofSales 
        /// </summary>
	    public const int YtdNumberofSales  = 15;
	             /// <summary>
        /// Property Indexer for YTDNumberofReturns 
        /// </summary>
	    public const int YtdNumberofReturns  = 16;
	             /// <summary>
        /// Property Indexer for YTDTotalAmountSold 
        /// </summary>
        public const int YtdTotalAmountSold = 17;
	             /// <summary>
        /// Property Indexer for YTDTotalAmountReturned 
        /// </summary>
	    public const int YtdTotalAmountReturned  = 18;
	             /// <summary>
        /// Property Indexer for YTDTotalCostofGoodsSold 
        /// </summary>
	    public const int YtdTotalCostofGoodsSold  = 19;
	             /// <summary>
        /// Property Indexer for YTDTotalGrossMargin 
        /// </summary>
	    public const int YtdTotalGrossMargin  = 20;
	             /// <summary>
        /// Property Indexer for YTDQuantitySold 
        /// </summary>
	    public const int YtdQuantitySold  = 21;
	             /// <summary>
        /// Property Indexer for YTDDateofLastSale 
        /// </summary>
	    public const int YtdDateofLastSale  = 22;
	             /// <summary>
        /// Property Indexer for EnableYTDCalculations 
        /// </summary>
	    public const int EnableYtdCalculations  = 23;
	     
        #endregion
	    }

	
	}
}
	