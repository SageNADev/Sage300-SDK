// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of OptionalFields Detail Constants 
    /// </summary>
    public partial class OptionalFieldDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0500";

        /// <summary>
        /// Contains list of OptionalFields Detail Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Location 
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for OptionalField 
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for DefaultValue 
            /// </summary>
            public const string DefaultValue = "DEFVAL";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for AllowBlank 
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for Validate 
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for AutoInsert 
            /// </summary>
            public const string AutoInsert = "INITFLAG";

            /// <summary>
            /// Property for ReceivablesControl 
            /// </summary>
            public const string ReceivablesControl = "SWCONTROL";

            /// <summary>
            /// Property for Retainage 
            /// </summary>
            public const string Retainage = "SWRTG";

            /// <summary>
            /// Property for ReceiptDiscount 
            /// </summary>
            public const string ReceiptDiscount = "SWDISCOUNT";

            /// <summary>
            /// Property for TaxLiability 
            /// </summary>
            public const string TaxLiability = "SWTAXLIAB";

            /// <summary>
            /// Property for ExchangeGain 
            /// </summary>
            public const string ExchangeGain = "SWREXCHG";

            /// <summary>
            /// Property for ExchangeLoss 
            /// </summary>
            public const string ExchangeLoss = "SWREXCHL";

            /// <summary>
            /// Property for UnrealizedExchangeGain 
            /// </summary>
            public const string UnrealizedExchangeGain = "SWUREXCHG";

            /// <summary>
            /// Property for UnrealizedExchangeLoss 
            /// </summary>
            public const string UnrealizedExchangeLoss = "SWUREXCHL";

            /// <summary>
            /// Property for Rounding 
            /// </summary>
            public const string Rounding = "SWROUND";

            /// <summary>
            /// Property for Revenue 
            /// </summary>
            public const string Revenue = "SWREVENUE";

            /// <summary>
            /// Property for Prepayment 
            /// </summary>
            public const string Prepayment = "SWPREPAY";

            /// <summary>
            /// Property for MiscellaneousReceipt 
            /// </summary>
            public const string MiscellaneousReceipt = "SWMISCRCPT";

            /// <summary>
            /// Property for Bank 
            /// </summary>
            public const string Bank = "SWBANK";

            /// <summary>
            /// Property for Adjustment 
            /// </summary>
            public const string Adjustment = "SWADJ";

            /// <summary>
            /// Property for InventoryControl 
            /// </summary>
            public const string InventoryControl = "SWIC";

            /// <summary>
            /// Property for CostofGoodsSold 
            /// </summary>
            public const string CostofGoodsSold = "SWCOGS";

            /// <summary>
            /// Property for BillingsOrCosts 
            /// </summary>
            public const string BillingsOrCosts = "SWPM";

            /// <summary>
            /// Property for Required 
            /// </summary>
            public const string Required = "SWREQUIRED";

            /// <summary>
            /// Property for ValueSet 
            /// </summary>
            public const string ValueSet = "SWSET";

            /// <summary>
            /// Property for Labor 
            /// </summary>
            public const string Labor = "SWLABOUR";

            /// <summary>
            /// Property for Overhead 
            /// </summary>
            public const string Overhead = "SWOHEAD";

            /// <summary>
            /// Property for TypedDefaultValueFieldIndex 
            /// </summary>
            public const string TypedDefaultValueFieldIndex = "DVINDEX";

            /// <summary>
            /// Property for DefaultTextValue 
            /// </summary>
            public const string DefaultTextValue = "DVIFTEXT";

            /// <summary>
            /// Property for DefaultAmountValue 
            /// </summary>
            public const string DefaultAmountValue = "DVIFMONEY";

            /// <summary>
            /// Property for DefaultNumberValue 
            /// </summary>
            public const string DefaultNumberValue = "DVIFNUM";

            /// <summary>
            /// Property for DefaultIntegerValue 
            /// </summary>
            public const string DefaultIntegerValue = "DVIFLONG";

            /// <summary>
            /// Property for DefaultYesOrNoValue 
            /// </summary>
            public const string DefaultYesOrNoValue = "DVIFBOOL";

            /// <summary>
            /// Property for DefaultDateValue 
            /// </summary>
            public const string DefaultDateValue = "DVIFDATE";

            /// <summary>
            /// Property for DefaultTimeValue 
            /// </summary>
            public const string DefaultTimeValue = "DVIFTIME";

            /// <summary>
            /// Property for OptionalFieldDescription 
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";

            /// <summary>
            /// Property for DefaultValueDescription 
            /// </summary>
            public const string DefaultValueDescription = "VDESC";

            /// <summary>
            /// Property for ReceivablesControl1 
            /// </summary>
            public const string ReceivablesControl1 = "SWCONTROL";

            /// <summary>
            /// Property for Retainage1 
            /// </summary>
            public const string Retainage1 = "SWRTG";

            /// <summary>
            /// Property for ReceiptDiscount1 
            /// </summary>
            public const string ReceiptDiscount1 = "SWDISCOUNT";

            /// <summary>
            /// Property for TaxLiability1
            /// </summary>
            public const string TaxLiability1 = "SWTAXLIAB";

            /// <summary>
            /// Property for ExchangeGain1 
            /// </summary>
            public const string ExchangeGain1 = "SWREXCHG";

            /// <summary>
            /// Property for ExchangeLoss1 
            /// </summary>
            public const string ExchangeLoss1 = "SWREXCHL";

            /// <summary>
            /// Property for UnrealizedExchangeGain1 
            /// </summary>
            public const string UnrealizedExchangeGain1 = "SWUREXCHG";

            /// <summary>
            /// Property for UnrealizedExchangeLoss1 
            /// </summary>
            public const string UnrealizedExchangeLoss1 = "SWUREXCHL";

            /// <summary>
            /// Property for Rounding1 
            /// </summary>
            public const string Rounding1 = "SWROUND";

            /// <summary>
            /// Property for Revenue1 
            /// </summary>
            public const string Revenue1 = "SWREVENUE";

            /// <summary>
            /// Property for Prepayment1 
            /// </summary>
            public const string Prepayment1 = "SWPREPAY";

            /// <summary>
            /// Property for MiscellaneousReceipt1 
            /// </summary>
            public const string MiscellaneousReceipt1 = "SWMISCRCPT";

            /// <summary>
            /// Property for Bank1 
            /// </summary>
            public const string Bank1 = "SWBANK";

            /// <summary>
            /// Property for Adjustment1 
            /// </summary>
            public const string Adjustment1 = "SWADJ";

            /// <summary>
            /// Property for InventoryControl1 
            /// </summary>
            public const string InventoryControl1 = "SWIC";

            /// <summary>
            /// Property for CostofGoodsSold1 
            /// </summary>
            public const string CostofGoodsSold1 = "SWCOGS";

            /// <summary>
            /// Property for BillingsOrCosts1 
            /// </summary>
            public const string BillingsOrCosts1 = "SWPM";

            /// <summary>
            /// Property for Labor1 
            /// </summary>
            public const string Labor1 = "SWLABOUR";

            /// <summary>
            /// Property for Overhead 
            /// </summary>
            public const string Overhead1 = "SWOHEAD";

            #endregion
        }

        /// <summary>
        /// Contains list of OptionalFields Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Location 
            /// </summary>
            public const int Location = 1;

            /// <summary>
            /// Property Indexer for OptionalField 
            /// </summary>
            public const int OptionalField = 2;

            /// <summary>
            /// Property Indexer for DefaultValue 
            /// </summary>
            public const int DefaultValue = 3;

            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Property Indexer for AllowBlank 
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Property Indexer for Validate 
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Property Indexer for AutoInsert 
            /// </summary>
            public const int AutoInsert = 9;

            /// <summary>
            /// Property Indexer for ReceivablesControl 
            /// </summary>
            public const int ReceivablesControl = 10;

            /// <summary>
            /// Property Indexer for Retainage 
            /// </summary>
            public const int Retainage = 11;

            /// <summary>
            /// Property Indexer for ReceiptDiscount 
            /// </summary>
            public const int ReceiptDiscount = 12;

            /// <summary>
            /// Property Indexer for TaxLiability 
            /// </summary>
            public const int TaxLiability = 13;

            /// <summary>
            /// Property Indexer for ExchangeGain 
            /// </summary>
            public const int ExchangeGain = 14;

            /// <summary>
            /// Property Indexer for ExchangeLoss 
            /// </summary>
            public const int ExchangeLoss = 15;

            /// <summary>
            /// Property Indexer for UnrealizedExchangeGain 
            /// </summary>
            public const int UnrealizedExchangeGain = 16;

            /// <summary>
            /// Property Indexer for UnrealizedExchangeLoss 
            /// </summary>
            public const int UnrealizedExchangeLoss = 17;

            /// <summary>
            /// Property Indexer for Rounding 
            /// </summary>
            public const int Rounding = 18;

            /// <summary>
            /// Property Indexer for Revenue 
            /// </summary>
            public const int Revenue = 19;

            /// <summary>
            /// Property Indexer for Prepayment 
            /// </summary>
            public const int Prepayment = 20;

            /// <summary>
            /// Property Indexer for MiscellaneousReceipt 
            /// </summary>
            public const int MiscellaneousReceipt = 21;

            /// <summary>
            /// Property Indexer for Bank 
            /// </summary>
            public const int Bank = 22;

            /// <summary>
            /// Property Indexer for Adjustment 
            /// </summary>
            public const int Adjustment = 23;

            /// <summary>
            /// Property Indexer for InventoryControl 
            /// </summary>
            public const int InventoryControl = 24;

            /// <summary>
            /// Property Indexer for CostofGoodsSold 
            /// </summary>
            public const int CostofGoodsSold = 25;

            /// <summary>
            /// Property Indexer for BillingsOrCosts 
            /// </summary>
            public const int BillingsOrCosts = 26;

            /// <summary>
            /// Property Indexer for Required 
            /// </summary>
            public const int Required = 27;

            /// <summary>
            /// Property Indexer for ValueSet 
            /// </summary>
            public const int ValueSet = 28;

            /// <summary>
            /// Property Indexer for Labor 
            /// </summary>
            public const int Labor = 29;

            /// <summary>
            /// Property Indexer for Overhead 
            /// </summary>
            public const int Overhead = 30;

            /// <summary>
            /// Property Indexer for TypedDefaultValueFieldIndex 
            /// </summary>
            public const int TypedDefaultValueFieldIndex = 35;

            /// <summary>
            /// Property Indexer for DefaultTextValue 
            /// </summary>
            public const int DefaultTextValue = 36;

            /// <summary>
            /// Property Indexer for DefaultAmountValue 
            /// </summary>
            public const int DefaultAmountValue = 37;

            /// <summary>
            /// Property Indexer for DefaultNumberValue 
            /// </summary>
            public const int DefaultNumberValue = 38;

            /// <summary>
            /// Property Indexer for DefaultIntegerValue 
            /// </summary>
            public const int DefaultIntegerValue = 39;

            /// <summary>
            /// Property Indexer for DefaultYesOrNoValue 
            /// </summary>
            public const int DefaultYesOrNoValue = 40;

            /// <summary>
            /// Property Indexer for DefaultDateValue 
            /// </summary>
            public const int DefaultDateValue = 41;

            /// <summary>
            /// Property Indexer for DefaultTimeValue 
            /// </summary>
            public const int DefaultTimeValue = 42;

            /// <summary>
            /// Property Indexer for OptionalFieldDescription 
            /// </summary>
            public const int OptionalFieldDescription = 43;

            /// <summary>
            /// Property Indexer for DefaultValueDescription 
            /// </summary>
            public const int DefaultValueDescription = 44;

            #endregion
        }
    }
}