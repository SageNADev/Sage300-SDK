// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Customer and Ship-To Options Constants 
    /// </summary>
    public partial class OptionsCustomerAndShipTo
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0005";

        /// <summary>
        /// Contains list of Customer and Ship-To Options Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Customer Or Ship To Options Key 
            /// </summary>
            public const string CustOrShipToOptionsKey = "IDR05";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATEMNTN";

            /// <summary>
            /// Property for Default No Days for Expiry 
            /// </summary>
            public const string DefaultNoDaysforExpiry = "CMNTDAYS";

            /// <summary>
            /// Property for Default No Days for Follow Up 
            /// </summary>
            public const string DefaultNoDaysforFollowUp = "FLUPDAYS";

            /// <summary>
            /// Property for Default Comment Type 
            /// </summary>
            public const string DefaultCommentType = "CMNTTYPE";

            /// <summary>
            /// Property for Allow Blank Comment Type 
            /// </summary>
            public const string AllowBlankCommentType = "SWCMNTTYPE";

            #endregion
        }

        /// <summary>
        /// Contains list of Customer and Ship-To Options Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Customer Or Ship To Options Key 
            /// </summary>
            public const int CustOrShipToOptionsKey = 1;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for Default No Days for Expiry 
            /// </summary>
            public const int DefaultNoDaysforExpiry = 3;

            /// <summary>
            /// Property Indexer for Default No Days for Follow Up 
            /// </summary>
            public const int DefaultNoDaysforFollowUp = 52;

            /// <summary>
            /// Property Indexer for Default Comment Type 
            /// </summary>
            public const int DefaultCommentType = 53;

            /// <summary>
            /// Property Indexer for Allow Blank Comment Type 
            /// </summary>
            public const int AllowBlankCommentType = 54;

            #endregion
        }
    }
}