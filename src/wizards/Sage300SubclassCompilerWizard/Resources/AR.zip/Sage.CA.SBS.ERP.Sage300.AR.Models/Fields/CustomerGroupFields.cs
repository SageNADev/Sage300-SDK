// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CustomerGroups Constants 
    /// </summary>
    public partial class CustomerGroup
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0025";

        /// <summary>
        /// Contains list of CustomerGroups Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for GroupCode 
            /// </summary>
            public const string GroupCode = "IDGRP";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";
            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINAC";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";
            /// <summary>
            /// Property for AccountSet 
            /// </summary>
            public const string AccountSet = "IDACCTSET";
            /// <summary>
            /// Property for AutocashProfile 
            /// </summary>
            public const string AutocashProfile = "IDAUTOCASH";
            /// <summary>
            /// Property for BillingCycle 
            /// </summary>
            public const string BillingCycle = "IDBILLCYCL";
            /// <summary>
            /// Property for InterestProfile 
            /// </summary>
            public const string InterestProfile = "IDSVCCHG";
            /// <summary>
            /// Property for AccountType 
            /// </summary>
            public const string AccountType = "SWBALFWD";
            /// <summary>
            /// Property for Terms 
            /// </summary>
            public const string Terms = "CODETERM";
            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "RATETYPE";
            /// <summary>
            /// Property for AllowEditofCreditLimit 
            /// </summary>
            public const string AllowEditofCreditLimit = "SWCROVRD";
            /// <summary>
            /// Property for CreditLimit1Currency 
            /// </summary>
            public const string CreditLimit1Currency = "CDCRLMCUR1";
            /// <summary>
            /// Property for CreditLimit1Amount 
            /// </summary>
            public const string CreditLimit1Amount = "AMCRLMCUR1";
            /// <summary>
            /// Property for CreditLimit2Currency 
            /// </summary>
            public const string CreditLimit2Currency = "CDCRLMCUR2";
            /// <summary>
            /// Property for CreditLimit2Amount 
            /// </summary>
            public const string CreditLimit2Amount = "AMCRLMCUR2";
            /// <summary>
            /// Property for CreditLimit3Currency 
            /// </summary>
            public const string CreditLimit3Currency = "CDCRLMCUR3";
            /// <summary>
            /// Property for CreditLimit3Amount 
            /// </summary>
            public const string CreditLimit3Amount = "AMCRLMCUR3";
            /// <summary>
            /// Property for CreditLimit4Currency 
            /// </summary>
            public const string CreditLimit4Currency = "CDCRLMCUR4";
            /// <summary>
            /// Property for CreditLimit4Amount 
            /// </summary>
            public const string CreditLimit4Amount = "AMCRLMCUR4";
            /// <summary>
            /// Property for CreditLimit5Currency 
            /// </summary>
            public const string CreditLimit5Currency = "CDCRLMCUR5";
            /// <summary>
            /// Property for CreditLimit5Amount 
            /// </summary>
            public const string CreditLimit5Amount = "AMCRLMCUR5";
            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";
            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";
            /// <summary>
            /// Property for TaxClassCode1 
            /// </summary>
            public const string TaxClassCode1 = "TAXSTTS1";
            /// <summary>
            /// Property for TaxClassCode2 
            /// </summary>
            public const string TaxClassCode2 = "TAXSTTS2";
            /// <summary>
            /// Property for TaxClassCode3 
            /// </summary>
            public const string TaxClassCode3 = "TAXSTTS3";
            /// <summary>
            /// Property for TaxClassCode4 
            /// </summary>
            public const string TaxClassCode4 = "TAXSTTS4";
            /// <summary>
            /// Property for TaxClassCode5 
            /// </summary>
            public const string TaxClassCode5 = "TAXSTTS5";
            /// <summary>
            /// Property for Salesperson1 
            /// </summary>
            public const string Salesperson1 = "CODESLSP1";
            /// <summary>
            /// Property for Salesperson2 
            /// </summary>
            public const string Salesperson2 = "CODESLSP2";
            /// <summary>
            /// Property for Salesperson3 
            /// </summary>
            public const string Salesperson3 = "CODESLSP3";
            /// <summary>
            /// Property for Salesperson4 
            /// </summary>
            public const string Salesperson4 = "CODESLSP4";
            /// <summary>
            /// Property for Salesperson5 
            /// </summary>
            public const string Salesperson5 = "CODESLSP5";
            /// <summary>
            /// Property for SalesSplitPercentage1 
            /// </summary>
            public const string SalesSplitPercentage1 = "PCTSASPLT1";
            /// <summary>
            /// Property for SalesSplitPercentage2 
            /// </summary>
            public const string SalesSplitPercentage2 = "PCTSASPLT2";
            /// <summary>
            /// Property for SalesSplitPercentage3 
            /// </summary>
            public const string SalesSplitPercentage3 = "PCTSASPLT3";
            /// <summary>
            /// Property for SalesSplitPercentage4 
            /// </summary>
            public const string SalesSplitPercentage4 = "PCTSASPLT4";
            /// <summary>
            /// Property for SalesSplitPercentage5 
            /// </summary>
            public const string SalesSplitPercentage5 = "PCTSASPLT5";
            /// <summary>
            /// Property for PrintStatements 
            /// </summary>
            public const string PrintStatements = "SWPRTSTMT";
            /// <summary>
            /// Property for CheckCreditLimit 
            /// </summary>
            public const string CheckCreditLimit = "SWCHKLIMIT";
            /// <summary>
            /// Property for CheckOverdueAmounts 
            /// </summary>
            public const string CheckOverdueAmounts = "SWCHKOVER";
            /// <summary>
            /// Property for DaysOverdue 
            /// </summary>
            public const string DaysOverdue = "OVERDAYS";
            /// <summary>
            /// Property for AmountOverdue1 
            /// </summary>
            public const string AmountOverdue1 = "OVERAMT1";
            /// <summary>
            /// Property for AmountOverdue2 
            /// </summary>
            public const string AmountOverdue2 = "OVERAMT2";
            /// <summary>
            /// Property for AmountOverdue3 
            /// </summary>
            public const string AmountOverdue3 = "OVERAMT3";
            /// <summary>
            /// Property for AmountOverdue4 
            /// </summary>
            public const string AmountOverdue4 = "OVERAMT4";
            /// <summary>
            /// Property for AmountOverdue5 
            /// </summary>
            public const string AmountOverdue5 = "OVERAMT5";

            #endregion
        }


        /// <summary>
        /// Contains list of CustomerGroups Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
            public const int GroupCode = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;
            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 6;
            /// <summary>
            /// Property Indexer for AutocashProfile 
            /// </summary>
            public const int AutocashProfile = 7;
            /// <summary>
            /// Property Indexer for BillingCycle 
            /// </summary>
            public const int BillingCycle = 8;
            /// <summary>
            /// Property Indexer for InterestProfile 
            /// </summary>
            public const int InterestProfile = 9;
            /// <summary>
            /// Property Indexer for AccountType 
            /// </summary>
            public const int AccountType = 11;
            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 12;
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 13;
            /// <summary>
            /// Property Indexer for AllowEditofCreditLimit 
            /// </summary>
            public const int AllowEditofCreditLimit = 14;
            /// <summary>
            /// Property Indexer for CreditLimit1Currency 
            /// </summary>
            public const int CreditLimit1Currency = 15;
            /// <summary>
            /// Property Indexer for CreditLimit1Amount 
            /// </summary>
            public const int CreditLimit1Amount = 16;
            /// <summary>
            /// Property Indexer for CreditLimit2Currency 
            /// </summary>
            public const int CreditLimit2Currency = 17;
            /// <summary>
            /// Property Indexer for CreditLimit2Amount 
            /// </summary>
            public const int CreditLimit2Amount = 18;
            /// <summary>
            /// Property Indexer for CreditLimit3Currency 
            /// </summary>
            public const int CreditLimit3Currency = 19;
            /// <summary>
            /// Property Indexer for CreditLimit3Amount 
            /// </summary>
            public const int CreditLimit3Amount = 20;
            /// <summary>
            /// Property Indexer for CreditLimit4Currency 
            /// </summary>
            public const int CreditLimit4Currency = 21;
            /// <summary>
            /// Property Indexer for CreditLimit4Amount 
            /// </summary>
            public const int CreditLimit4Amount = 22;
            /// <summary>
            /// Property Indexer for CreditLimit5Currency 
            /// </summary>
            public const int CreditLimit5Currency = 23;
            /// <summary>
            /// Property Indexer for CreditLimit5Amount 
            /// </summary>
            public const int CreditLimit5Amount = 24;
            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 33;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 34;
            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 35;
            /// <summary>
            /// Property Indexer for TaxClassCode1 
            /// </summary>
            public const int TaxClassCode1 = 36;
            /// <summary>
            /// Property Indexer for TaxClassCode2 
            /// </summary>
            public const int TaxClassCode2 = 37;
            /// <summary>
            /// Property Indexer for TaxClassCode3 
            /// </summary>
            public const int TaxClassCode3 = 38;
            /// <summary>
            /// Property Indexer for TaxClassCode4 
            /// </summary>
            public const int TaxClassCode4 = 39;
            /// <summary>
            /// Property Indexer for TaxClassCode5 
            /// </summary>
            public const int TaxClassCode5 = 40;
            /// <summary>
            /// Property Indexer for Salesperson1 
            /// </summary>
            public const int Salesperson1 = 41;
            /// <summary>
            /// Property Indexer for Salesperson2 
            /// </summary>
            public const int Salesperson2 = 42;
            /// <summary>
            /// Property Indexer for Salesperson3 
            /// </summary>
            public const int Salesperson3 = 43;
            /// <summary>
            /// Property Indexer for Salesperson4 
            /// </summary>
            public const int Salesperson4 = 44;
            /// <summary>
            /// Property Indexer for Salesperson5 
            /// </summary>
            public const int Salesperson5 = 45;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage1 
            /// </summary>
            public const int SalesSplitPercentage1 = 46;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage2 
            /// </summary>
            public const int SalesSplitPercentage2 = 47;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage3 
            /// </summary>
            public const int SalesSplitPercentage3 = 48;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage4 
            /// </summary>
            public const int SalesSplitPercentage4 = 49;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage5 
            /// </summary>
            public const int SalesSplitPercentage5 = 50;
            /// <summary>
            /// Property Indexer for PrintStatements 
            /// </summary>
            public const int PrintStatements = 51;
            /// <summary>
            /// Property Indexer for CheckCreditLimit 
            /// </summary>
            public const int CheckCreditLimit = 52;
            /// <summary>
            /// Property Indexer for CheckOverdueAmounts 
            /// </summary>
            public const int CheckOverdueAmounts = 53;
            /// <summary>
            /// Property Indexer for DaysOverdue 
            /// </summary>
            public const int DaysOverdue = 54;
            /// <summary>
            /// Property Indexer for AmountOverdue1 
            /// </summary>
            public const int AmountOverdue1 = 55;
            /// <summary>
            /// Property Indexer for AmountOverdue2 
            /// </summary>
            public const int AmountOverdue2 = 56;
            /// <summary>
            /// Property Indexer for AmountOverdue3 
            /// </summary>
            public const int AmountOverdue3 = 57;
            /// <summary>
            /// Property Indexer for AmountOverdue4 
            /// </summary>
            public const int AmountOverdue4 = 58;
            /// <summary>
            /// Property Indexer for AmountOverdue5 
            /// </summary>
            public const int AmountOverdue5 = 59;

            #endregion
        }


    }
}
