﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.


// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace

{
    /// <summary>
    /// Contains list of RefundBatches Constants 
    /// </summary>
    public partial class RefundBatch
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0140";

        /// <summary>
        /// Contains list of RefundBatches Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "BTCHDATE";
            /// <summary>
            /// Property for BatchDescription 
            /// </summary>
            public const string BatchDescription = "BTCHDESC";
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BTCHTYPE";
            /// <summary>
            /// Property for BatchStatus 
            /// </summary>
            public const string BatchStatus = "BTCHSTTS";
            /// <summary>
            /// Property for NumberofEntries 
            /// </summary>
            public const string NumberofEntries = "ENTRYCNT";
            /// <summary>
            /// Property for TotalofEntries 
            /// </summary>
            public const string TotalofEntries = "ENTRYTOT";
            /// <summary>
            /// Property for LastEntryNumber 
            /// </summary>
            public const string LastEntryNumber = "LASTENTRY";
            /// <summary>
            /// Property for PostingSequenceNo 
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNBR";
            /// <summary>
            /// Property for NumberofErrors 
            /// </summary>
            public const string NumberofErrors = "NBRERRORS";
            /// <summary>
            /// Property for DateCreated 
            /// </summary>
            public const string DateCreated = "DATECREATE";
            /// <summary>
            /// Property for DateLastEdited 
            /// </summary>
            public const string DateLastEdited = "DATELSTEDT";
            /// <summary>
            /// Property for BatchPrintedFlag 
            /// </summary>
            public const string BatchPrintedFlag = "SWPRINTED";
            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";
            /// <summary>
            /// Property for NumberofPrintedChecks 
            /// </summary>
            public const string NumberofPrintedChecks = "CNTCHKPRNT";

            #endregion
        }


        /// <summary>
        /// Contains list of RefundBatches Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;
            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 2;
            /// <summary>
            /// Property Indexer for BatchDescription 
            /// </summary>
            public const int BatchDescription = 3;
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 4;
            /// <summary>
            /// Property Indexer for BatchStatus 
            /// </summary>
            public const int BatchStatus = 5;
            /// <summary>
            /// Property Indexer for NumberofEntries 
            /// </summary>
            public const int NumberofEntries = 6;
            /// <summary>
            /// Property Indexer for TotalofEntries 
            /// </summary>
            public const int TotalofEntries = 7;
            /// <summary>
            /// Property Indexer for LastEntryNumber 
            /// </summary>
            public const int LastEntryNumber = 8;
            /// <summary>
            /// Property Indexer for PostingSequenceNo 
            /// </summary>
            public const int PostingSequenceNo = 9;
            /// <summary>
            /// Property Indexer for NumberofErrors 
            /// </summary>
            public const int NumberofErrors = 10;
            /// <summary>
            /// Property Indexer for DateCreated 
            /// </summary>
            public const int DateCreated = 11;
            /// <summary>
            /// Property Indexer for DateLastEdited 
            /// </summary>
            public const int DateLastEdited = 12;
            /// <summary>
            /// Property Indexer for BatchPrintedFlag 
            /// </summary>
            public const int BatchPrintedFlag = 13;
            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 14;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 15;
            /// <summary>
            /// Property Indexer for NumberofPrintedChecks 
            /// </summary>
            public const int NumberofPrintedChecks = 16;

            #endregion
        }


    }
}
