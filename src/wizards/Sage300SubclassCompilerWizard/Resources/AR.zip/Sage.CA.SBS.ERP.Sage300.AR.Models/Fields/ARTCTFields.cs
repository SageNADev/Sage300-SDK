﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Receipt Tax WithHolding
    /// </summary>
    public partial class ARTCT
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0085";

        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Batch Type 
            /// </summary>
            public const string BatchType = "BATCHTYPE";

            /// <summary>
            /// Property for Batch Number 
            /// </summary>
            public const string CntBtch = "CNTBTCH";

            /// <summary>
            /// Property for Entry Number 
            /// </summary>
            public const string CntEntr = "CNTENTR";

            /// <summary>
            /// Property for Tax Authority 
            /// </summary>
            public const string Authority = "AUTHORITY";

            /// <summary>
            /// Property for Vend Withheld Amount 
            /// </summary>
            public const string AmtWHDTC = "AMTWHDTC";

            /// <summary>
            /// Property for Func Withheld Amount 
            /// </summary>
            public const string AmtWHDHC = "AMTWHDHC";

            #endregion
        }

        public class Index
        {
            #region Properties

            /// <summary>
            /// Indexer for Batch Type 
            /// </summary>
            public const int BatchType = 1;

            /// <summary>
            /// Indexer for Batch Number 
            /// </summary>
            public const int CntBtch = 2;

            /// <summary>
            /// Indexer for Entry Number 
            /// </summary>
            public const int CntEntr = 3;

            /// <summary>
            /// Indexer for Tax Authority 
            /// </summary>
            public const int Authority = 4;

            /// <summary>
            /// Indexer for Vend Withheld Amount 
            /// </summary>
            public const int AmtWHDTC = 5;

            /// <summary>
            /// Indexer for Func Withheld Amount 
            /// </summary>
            public const int AmtWHDHC = 6;

            #endregion
        }
    }
}
