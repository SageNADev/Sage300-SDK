// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models // ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Company Options Constants 
    /// </summary>
    public partial class Options
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0001";

        /// <summary>
        /// Contains list of Company Options Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for Company Options Key 
            /// </summary>
            public const string CompanyOptionsKey = "IDR01";

            /// <summary>
            /// Property for Date Last Maintained 
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for Contact Name 
            /// </summary>
            public const string ContactName = "NAMECTAC";

            /// <summary>
            /// Property for Telephone Number 
            /// </summary>
            public const string TelephoneNumber = "TEXTPHON";

            /// <summary>
            /// Property for Fax Number 
            /// </summary>
            public const string FaxNumber = "TEXTFAX";

            /// <summary>
            /// Property for Multicurrency 
            /// </summary>
            public const string Multicurrency = "SWMULTCURN";

            /// <summary>
            /// Property for Process Recurring Charges 
            /// </summary>
            public const string ProcessRecurringCharges = "SWRCURCHG";

            /// <summary>
            /// Property for Edit Imported Batches 
            /// </summary>
            public const string EditImportedBatches = "SWEDITIMPT";

            /// <summary>
            /// Property for Force Listing of Batches 
            /// </summary>
            public const string ForceListingofBatches = "SWFRCLST";

            /// <summary>
            /// Property for Edit Customer Statistics 
            /// </summary>
            public const string EditCustStatistics = "SWEDITCUST";

            /// <summary>
            /// Property for Include Tax in Customer Statistics 
            /// </summary>
            public const string IncTaxinCustStatistics = "CODETAXCUS";

            /// <summary>
            /// Property for Customer Statistics Year Type 
            /// </summary>
            public const string CustStatisticsYearType = "CODECLDRCU";

            /// <summary>
            /// Property for Customer Statistics Period Type 
            /// </summary>
            public const string CustStatisticsPeriodType = "CODEPERDCU";

            /// <summary>
            /// Property for Keep Item Statistics 
            /// </summary>
            public const string KeepItemStatistics = "SWACCUITEM";

            /// <summary>
            /// Property for Edit Item Statistics 
            /// </summary>
            public const string EditItemStatistics = "SWEDITITEM";

            /// <summary>
            /// Property for Incluce Tax in Item Statistics 
            /// </summary>
            public const string IncTaxinItemStatistics = "CODETAXITM";

            /// <summary>
            /// Property for Item Statistics Year Type 
            /// </summary>
            public const string ItemStatisticsYearType = "CODECLDRIT";

            /// <summary>
            /// Property for Item Statistics Period Type 
            /// </summary>
            public const string ItemStatisticsPeriodType = "CODEPERDIT";

            /// <summary>
            /// Property for Keep Salesperson Statistics 
            /// </summary>
            public const string KeepSalespersonStatistics = "SWACCUSLSP";

            /// <summary>
            /// Property for Edit Salesperson Statistics 
            /// </summary>
            public const string EditSalespersonStatistics = "SWEDITSLSP";

            /// <summary>
            /// Property for Include Tax in Sales Statistics 
            /// </summary>
            public const string IncTaxinSalesStatistics = "CODETAXSAP";

            /// <summary>
            /// Property for Sales Statistics Year Type 
            /// </summary>
            public const string SalesStatisticsYearType = "CODECLDRSA";

            /// <summary>
            /// Property for Sales Statistics Period Type 
            /// </summary>
            public const string SalesStatisticsPeriodType = "CODEPERDSA";

            /// <summary>
            /// Property for Next Revaluation Posting Sequence 
            /// </summary>
            public const string NextRevaluationPostingSeq = "ATRRVALSEQ";

            /// <summary>
            /// Property for Keep History 
            /// </summary>
            public const string KeepHistory = "SWKEEPDTLS";

            /// <summary>
            /// Property for Keep Customer Statistics 
            /// </summary>
            public const string KeepCustomerStatistics = "SWACCUCUS";

            /// <summary>
            /// Property for Edit External Batches 
            /// </summary>
            public const string EditExternalBatches = "SWEDITSUB";

            #endregion
        }

        /// <summary>
        /// Contains list of Company Options Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for Company Options Key 
            /// </summary>
            public const int CompanyOptionsKey = 1;

            /// <summary>
            /// Property Indexer for Date Last Maintained 
            /// </summary>
            public const int DateLastMaintained = 2;

            /// <summary>
            /// Property Indexer for Contact Name 
            /// </summary>
            public const int ContactName = 3;

            /// <summary>
            /// Property Indexer for Telephone Number 
            /// </summary>
            public const int TelephoneNumber = 4;

            /// <summary>
            /// Property Indexer for Fax Number 
            /// </summary>
            public const int FaxNumber = 5;

            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 6;

            /// <summary>
            /// Property Indexer for Process Recurring Charges 
            /// </summary>
            public const int ProcessRecurringCharges = 7;

            /// <summary>
            /// Property Indexer for Edit Imported Batches 
            /// </summary>
            public const int EditImportedBatches = 8;

            /// <summary>
            /// Property Indexer for Force Listing of Batches 
            /// </summary>
            public const int ForceListingofBatches = 9;

            /// <summary>
            /// Property Indexer for Edit Customer Statistics 
            /// </summary>
            public const int EditCustStatistics = 11;

            /// <summary>
            /// Property Indexer for Include Tax in Customer Statistics 
            /// </summary>
            public const int IncTaxinCustStatistics = 12;

            /// <summary>
            /// Property Indexer for Customer Statistics Year Type 
            /// </summary>
            public const int CustStatisticsYearType = 13;

            /// <summary>
            /// Property Indexer for Customer Statistics Period Type 
            /// </summary>
            public const int CustStatisticsPeriodType = 14;

            /// <summary>
            /// Property Indexer for Keep Item Statistics 
            /// </summary>
            public const int KeepItemStatistics = 15;

            /// <summary>
            /// Property Indexer for Edit Item Statistics 
            /// </summary>
            public const int EditItemStatistics = 16;

            /// <summary>
            /// Property Indexer for Include Tax in Item Statistics 
            /// </summary>
            public const int IncTaxinItemStatistics = 17;

            /// <summary>
            /// Property Indexer for Item Statistics Year Type 
            /// </summary>
            public const int ItemStatisticsYearType = 18;

            /// <summary>
            /// Property Indexer for Item Statistics Period Type 
            /// </summary>
            public const int ItemStatisticsPeriodType = 19;

            /// <summary>
            /// Property Indexer for Keep Salesperson Statistics 
            /// </summary>
            public const int KeepSalespersonStatistics = 20;

            /// <summary>
            /// Property Indexer for Edit Salesperson Statistics 
            /// </summary>
            public const int EditSalespersonStatistics = 21;

            /// <summary>
            /// Property Indexer for Include Tax in Sales Statistics 
            /// </summary>
            public const int IncTaxinSalesStatistics = 22;

            /// <summary>
            /// Property Indexer for Sales Statistics Year Type 
            /// </summary>
            public const int SalesStatisticsYearType = 23;

            /// <summary>
            /// Property Indexer for Sales Statistics Period Type 
            /// </summary>
            public const int SalesStatisticsPeriodType = 24;

            /// <summary>
            /// Property Indexer for Next Revaluation Posting Sequence 
            /// </summary>
            public const int NextRevaluationPostingSeq = 25;

            /// <summary>
            /// Property Indexer for Keep History 
            /// </summary>
            public const int KeepHistory = 26;

            /// <summary>
            /// Property Indexer for Keep Customer Statistics 
            /// </summary>
            public const int KeepCustomerStatistics = 27;

            /// <summary>
            /// Property Indexer for Edit External Batches 
            /// </summary>
            public const int EditExternalBatches = 28;

            #endregion
        }
    }
}