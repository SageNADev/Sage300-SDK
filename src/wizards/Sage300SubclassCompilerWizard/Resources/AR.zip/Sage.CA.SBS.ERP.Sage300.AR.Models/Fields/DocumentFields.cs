/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of Documents Constants 
    /// </summary>
	public partial class Document
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string ViewName = "AR0036";

        /// <summary>
        /// Contains list of Documents Fields Constants
        /// </summary>
	    public class Fields
        {

        #region Properties
	            /// <summary>
        /// Property for CustomerNumber 
        /// </summary>
	    public const string CustomerNumber  = "IDCUST";
	            /// <summary>
        /// Property for DocumentNumber 
        /// </summary>
	    public const string DocumentNumber  = "IDINVC";
	            /// <summary>
        /// Property for CheckOrReceiptNo 
        /// </summary>
	    public const string CheckOrReceiptNo  = "IDRMIT";
	            /// <summary>
        /// Property for OrderNumber 
        /// </summary>
	    public const string OrderNumber  = "IDORDERNBR";
	            /// <summary>
        /// Property for PONumber 
        /// </summary>
	    public const string PONumber  = "IDCUSTPO";
	            /// <summary>
        /// Property for DueDate 
        /// </summary>
	    public const string DueDate  = "DATEDUE";
	            /// <summary>
        /// Property for NationalAccountNumber 
        /// </summary>
	    public const string NationalAccountNumber  = "IDNATACCT";
	            /// <summary>
        /// Property for ShipToLocation 
        /// </summary>
	    public const string ShipToLocation  = "IDCUSTSHPT";
	            /// <summary>
        /// Property for TransactionType 
        /// </summary>
	    public const string TransactionType  = "TRXTYPEID";
	            /// <summary>
        /// Property for DocumentType 
        /// </summary>
	    public const string DocumentType  = "TRXTYPETXT";
	            /// <summary>
        /// Property for BatchDate 
        /// </summary>
	    public const string BatchDate  = "DATEBTCH";
	            /// <summary>
        /// Property for BatchNumber 
        /// </summary>
	    public const string BatchNumber  = "CNTBTCH";
	            /// <summary>
        /// Property for EntryNumber 
        /// </summary>
	    public const string EntryNumber  = "CNTITEM";
	            /// <summary>
        /// Property for GroupCode 
        /// </summary>
	    public const string GroupCode  = "IDGRP";
	            /// <summary>
        /// Property for DocumentDescription 
        /// </summary>
	    public const string DocumentDescription  = "DESCINVC";
	            /// <summary>
        /// Property for DocumentDate 
        /// </summary>
	    public const string DocumentDate  = "DATEINVC";
	            /// <summary>
        /// Property for AsofDate 
        /// </summary>
	    public const string AsofDate  = "DATEASOF";
	            /// <summary>
        /// Property for Terms 
        /// </summary>
	    public const string Terms  = "CODETERM";
	            /// <summary>
        /// Property for DiscountDate 
        /// </summary>
	    public const string DiscountDate  = "DATEDISC";
	            /// <summary>
        /// Property for CurrencyCode 
        /// </summary>
	    public const string CurrencyCode  = "CODECURN";
	            /// <summary>
        /// Property for RateType 
        /// </summary>
	    public const string RateType  = "IDRATETYPE";
	            /// <summary>
        /// Property for RateOverridden 
        /// </summary>
	    public const string RateOverridden  = "SWRATEOVRD";
	            /// <summary>
        /// Property for ExchangeRate 
        /// </summary>
	    public const string ExchangeRate  = "EXCHRATEHC";
	            /// <summary>
        /// Property for FuncCurrencyInvoiceAmount 
        /// </summary>
	    public const string FuncCurrencyInvoiceAmount  = "AMTINVCHC";
	            /// <summary>
        /// Property for FuncCurrencyAmountDue 
        /// </summary>
	    public const string FuncCurrencyAmountDue  = "AMTDUEHC";
	            /// <summary>
        /// Property for FuncCurrencyTaxableAmount 
        /// </summary>
	    public const string FuncCurrencyTaxableAmount  = "AMTTXBLHC";
	            /// <summary>
        /// Property for FuncCurrencyNonTaxableAmt 
        /// </summary>
	    public const string FuncCurrencyNonTaxableAmt  = "AMTNONTXHC";
	            /// <summary>
        /// Property for FuncCurrencyTaxAmount 
        /// </summary>
	    public const string FuncCurrencyTaxAmount  = "AMTTAXHC";
	            /// <summary>
        /// Property for FuncCurrencyDiscountAmount 
        /// </summary>
	    public const string FuncCurrencyDiscountAmount  = "AMTDISCHC";
	            /// <summary>
        /// Property for CustCurrencyInvoiceAmount 
        /// </summary>
	    public const string CustCurrencyInvoiceAmount  = "AMTINVCTC";
	            /// <summary>
        /// Property for CustCurrencyAmountDue 
        /// </summary>
	    public const string CustCurrencyAmountDue  = "AMTDUETC";
	            /// <summary>
        /// Property for CustCurrencyTaxableAmount 
        /// </summary>
	    public const string CustCurrencyTaxableAmount  = "AMTTXBLTC";
	            /// <summary>
        /// Property for CustCurrencyNonTaxableAmt 
        /// </summary>
	    public const string CustCurrencyNonTaxableAmt  = "AMTNONTXTC";
	            /// <summary>
        /// Property for CustCurrencyTaxAmount 
        /// </summary>
	    public const string CustCurrencyTaxAmount  = "AMTTAXTC";
	            /// <summary>
        /// Property for CustCurrencyDiscountAmount 
        /// </summary>
	    public const string CustCurrencyDiscountAmount  = "AMTDISCTC";
	            /// <summary>
        /// Property for FullyPaid 
        /// </summary>
	    public const string FullyPaid  = "SWPAID";
	            /// <summary>
        /// Property for LastActivityDate 
        /// </summary>
	    public const string LastActivityDate  = "DATELSTACT";
	            /// <summary>
        /// Property for LastStatementDate 
        /// </summary>
	    public const string LastStatementDate  = "DATELSTSTM";
	            /// <summary>
        /// Property for NumberofScheduledPayments 
        /// </summary>
	    public const string NumberofScheduledPayments  = "CNTTOTPAYM";
	            /// <summary>
        /// Property for PaymentNumberonLastStatement 
        /// </summary>
	    public const string PaymentNumberonLastStatement  = "CNTLSTPYST";
	            /// <summary>
        /// Property for LastAppliedPaymentSeqNo 
        /// </summary>
	    public const string LastAppliedPaymentSeqNo  = "CNTLASTSEQ";
	            /// <summary>
        /// Property for DoNotCalcTax 
        /// </summary>
	    public const string DoNotCalcTax  = "SWTAXINPUT";
	            /// <summary>
        /// Property for TaxAuthority1 
        /// </summary>
	    public const string TaxAuthority1  = "CODETAX1";
	            /// <summary>
        /// Property for TaxAuthority2 
        /// </summary>
	    public const string TaxAuthority2  = "CODETAX2";
	            /// <summary>
        /// Property for TaxAuthority3 
        /// </summary>
	    public const string TaxAuthority3  = "CODETAX3";
	            /// <summary>
        /// Property for TaxAuthority4 
        /// </summary>
	    public const string TaxAuthority4  = "CODETAX4";
	            /// <summary>
        /// Property for TaxAuthority5 
        /// </summary>
	    public const string TaxAuthority5  = "CODETAX5";
	            /// <summary>
        /// Property for FuncBaseAmount1 
        /// </summary>
	    public const string FuncBaseAmount1  = "AMTBASE1HC";
	            /// <summary>
        /// Property for FuncBaseAmount2 
        /// </summary>
	    public const string FuncBaseAmount2  = "AMTBASE2HC";
	            /// <summary>
        /// Property for FuncBaseAmount3 
        /// </summary>
	    public const string FuncBaseAmount3  = "AMTBASE3HC";
	            /// <summary>
        /// Property for FuncBaseAmount4 
        /// </summary>
	    public const string FuncBaseAmount4  = "AMTBASE4HC";
	            /// <summary>
        /// Property for FuncBaseAmount5 
        /// </summary>
	    public const string FuncBaseAmount5  = "AMTBASE5HC";
	            /// <summary>
        /// Property for FuncTaxAmount1 
        /// </summary>
	    public const string FuncTaxAmount1  = "AMTTAX1HC";
	            /// <summary>
        /// Property for FuncTaxAmount2 
        /// </summary>
	    public const string FuncTaxAmount2  = "AMTTAX2HC";
	            /// <summary>
        /// Property for FuncTaxAmount3 
        /// </summary>
	    public const string FuncTaxAmount3  = "AMTTAX3HC";
	            /// <summary>
        /// Property for FuncTaxAmount4 
        /// </summary>
	    public const string FuncTaxAmount4  = "AMTTAX4HC";
	            /// <summary>
        /// Property for FuncTaxAmount5 
        /// </summary>
	    public const string FuncTaxAmount5  = "AMTTAX5HC";
	            /// <summary>
        /// Property for CustBaseAmount1 
        /// </summary>
	    public const string CustBaseAmount1  = "AMTBASE1TC";
	            /// <summary>
        /// Property for CustBaseAmount2 
        /// </summary>
	    public const string CustBaseAmount2  = "AMTBASE2TC";
	            /// <summary>
        /// Property for CustBaseAmount3 
        /// </summary>
	    public const string CustBaseAmount3  = "AMTBASE3TC";
	            /// <summary>
        /// Property for CustBaseAmount4 
        /// </summary>
	    public const string CustBaseAmount4  = "AMTBASE4TC";
	            /// <summary>
        /// Property for CustBaseAmount5 
        /// </summary>
	    public const string CustBaseAmount5  = "AMTBASE5TC";
	            /// <summary>
        /// Property for CustTaxAmount1 
        /// </summary>
	    public const string CustTaxAmount1  = "AMTTAX1TC";
	            /// <summary>
        /// Property for CustTaxAmount2 
        /// </summary>
	    public const string CustTaxAmount2  = "AMTTAX2TC";
	            /// <summary>
        /// Property for CustTaxAmount3 
        /// </summary>
	    public const string CustTaxAmount3  = "AMTTAX3TC";
	            /// <summary>
        /// Property for CustTaxAmount4 
        /// </summary>
	    public const string CustTaxAmount4  = "AMTTAX4TC";
	            /// <summary>
        /// Property for CustTaxAmount5 
        /// </summary>
	    public const string CustTaxAmount5  = "AMTTAX5TC";
	            /// <summary>
        /// Property for Salesperson1 
        /// </summary>
	    public const string Salesperson1  = "CODESLSP1";
	            /// <summary>
        /// Property for Salesperson2 
        /// </summary>
	    public const string Salesperson2  = "CODESLSP2";
	            /// <summary>
        /// Property for Salesperson3 
        /// </summary>
	    public const string Salesperson3  = "CODESLSP3";
	            /// <summary>
        /// Property for Salesperson4 
        /// </summary>
	    public const string Salesperson4  = "CODESLSP4";
	            /// <summary>
        /// Property for Salesperson5 
        /// </summary>
	    public const string Salesperson5  = "CODESLSP5";
	            /// <summary>
        /// Property for SalesSplitPercentage1 
        /// </summary>
	    public const string SalesSplitPercentage1  = "PCTSASPLT1";
	            /// <summary>
        /// Property for SalesSplitPercentage2 
        /// </summary>
	    public const string SalesSplitPercentage2  = "PCTSASPLT2";
	            /// <summary>
        /// Property for SalesSplitPercentage3 
        /// </summary>
	    public const string SalesSplitPercentage3  = "PCTSASPLT3";
	            /// <summary>
        /// Property for SalesSplitPercentage4 
        /// </summary>
	    public const string SalesSplitPercentage4  = "PCTSASPLT4";
	            /// <summary>
        /// Property for SalesSplitPercentage5 
        /// </summary>
	    public const string SalesSplitPercentage5  = "PCTSASPLT5";
	            /// <summary>
        /// Property for FiscalYear 
        /// </summary>
	    public const string FiscalYear  = "FISCYR";
	            /// <summary>
        /// Property for FiscalPeriod 
        /// </summary>
	    public const string FiscalPeriod  = "FISCPER";
	            /// <summary>
        /// Property for PrepayApplytoDocNo 
        /// </summary>
	    public const string PrepayApplytoDocNo  = "IDPREPAID";
	            /// <summary>
        /// Property for PostingDate 
        /// </summary>
	    public const string PostingDate  = "DATEBUS";
	            /// <summary>
        /// Property for RateDate 
        /// </summary>
	    public const string RateDate  = "RATEDATE";
	            /// <summary>
        /// Property for RateOperator 
        /// </summary>
	    public const string RateOperator  = "RATEOP";
	            /// <summary>
        /// Property for LastActivityYearOrPeriod 
        /// </summary>
	    public const string LastActivityYearOrPeriod  = "YPLASTACT";
	            /// <summary>
        /// Property for BankCode 
        /// </summary>
	    public const string BankCode  = "IDBANK";
	            /// <summary>
        /// Property for DepositNumber 
        /// </summary>
	    public const string DepositNumber  = "DEPSTNBR";
	            /// <summary>
        /// Property for PostingSequenceNo 
        /// </summary>
	    public const string PostingSequenceNo  = "POSTSEQNCE";
	            /// <summary>
        /// Property for JobRelated 
        /// </summary>
	    public const string JobRelated  = "SWJOB";
	            /// <summary>
        /// Property for HasRetainage 
        /// </summary>
	    public const string HasRetainage  = "SWRTG";
	            /// <summary>
        /// Property for RetainageOutstanding 
        /// </summary>
	    public const string RetainageOutstanding  = "SWRTGOUT";
	            /// <summary>
        /// Property for DateRetainageDue 
        /// </summary>
	    public const string DateRetainageDue  = "RTGDATEDUE";
	            /// <summary>
        /// Property for FuncCurrOrigRtngAmt 
        /// </summary>
	    public const string FuncCurrOrigRtngAmt  = "RTGOAMTHC";
	            /// <summary>
        /// Property for FuncCurrRetainageAmount 
        /// </summary>
	    public const string FuncCurrRetainageAmount  = "RTGAMTHC";
	            /// <summary>
        /// Property for CustCurrOrigRtngAmt 
        /// </summary>
	    public const string CustCurrOrigRtngAmt  = "RTGOAMTTC";
	            /// <summary>
        /// Property for CustCurrRetainageAmount 
        /// </summary>
	    public const string CustCurrRetainageAmount  = "RTGAMTTC";
	            /// <summary>
        /// Property for RetainageTermsCode 
        /// </summary>
	    public const string RetainageTermsCode  = "RTGTERMS";
	            /// <summary>
        /// Property for RetainageExchangeRate 
        /// </summary>
	    public const string RetainageExchangeRate  = "SWRTGRATE";
	            /// <summary>
        /// Property for OriginalDocNo 
        /// </summary>
	    public const string OriginalDocNo  = "RTGAPPLYTO";
	            /// <summary>
        /// Property for OptionalFields 
        /// </summary>
	    public const string OptionalFields  = "VALUES";
	            /// <summary>
        /// Property for SourceApplication 
        /// </summary>
	    public const string SourceApplication  = "SRCEAPPL";
	            /// <summary>
        /// Property for AOrRVersionCreatedIn 
        /// </summary>
	    public const string AOrRVersionCreatedIn  = "ARVERSION";
	            /// <summary>
        /// Property for InvoiceType 
        /// </summary>
	    public const string InvoiceType  = "INVCTYPE";
	            /// <summary>
        /// Property for DepositSerialNumber 
        /// </summary>
	    public const string DepositSerialNumber  = "DEPSEQ";
	            /// <summary>
        /// Property for DepositLineNumber 
        /// </summary>
	    public const string DepositLineNumber  = "DEPLINE";
	            /// <summary>
        /// Property for BatchType 
        /// </summary>
	    public const string BatchType  = "TYPEBTCH";
	            /// <summary>
        /// Property for NumberofOBLJDetails 
        /// </summary>
	    public const string NumberofOBLJDetails  = "CNTOBLJ";
	            /// <summary>
        /// Property for TaxReportingCurrencyCode 
        /// </summary>
	    public const string TaxReportingCurrencyCode  = "CODECURNRC";
	            /// <summary>
        /// Property for TaxReportingExchangeRate 
        /// </summary>
	    public const string TaxReportingExchangeRate  = "RATERC";
	            /// <summary>
        /// Property for TaxReportingRateType 
        /// </summary>
	    public const string TaxReportingRateType  = "RATETYPERC";
	            /// <summary>
        /// Property for TaxReportingRateDate 
        /// </summary>
	    public const string TaxReportingRateDate  = "RATEDATERC";
	            /// <summary>
        /// Property for TaxReportingRateOperator 
        /// </summary>
	    public const string TaxReportingRateOperator  = "RATEOPRC";
	            /// <summary>
        /// Property for TaxReportingRateOverride 
        /// </summary>
	    public const string TaxReportingRateOverride  = "SWRATERC";
	            /// <summary>
        /// Property for ReportRetainageTax 
        /// </summary>
	    public const string ReportRetainageTax  = "SWTXRTGRPT";
	            /// <summary>
        /// Property for TaxGroup 
        /// </summary>
	    public const string TaxGroup  = "CODETAXGRP";
	            /// <summary>
        /// Property for TaxStateVersion 
        /// </summary>
	    public const string TaxStateVersion  = "TAXVERSION";
	            /// <summary>
        /// Property for TaxReportingCalculateMethod 
        /// </summary>
	    public const string TaxReportingCalculateMethod  = "SWTXCTLRC";
	            /// <summary>
        /// Property for TaxClass1 
        /// </summary>
	    public const string TaxClass1  = "TAXCLASS1";
	            /// <summary>
        /// Property for TaxClass2 
        /// </summary>
	    public const string TaxClass2  = "TAXCLASS2";
	            /// <summary>
        /// Property for TaxClass3 
        /// </summary>
	    public const string TaxClass3  = "TAXCLASS3";
	            /// <summary>
        /// Property for TaxClass4 
        /// </summary>
	    public const string TaxClass4  = "TAXCLASS4";
	            /// <summary>
        /// Property for TaxClass5 
        /// </summary>
	    public const string TaxClass5  = "TAXCLASS5";
	            /// <summary>
        /// Property for TaxBase1 
        /// </summary>
	    public const string TaxBase1  = "TXBSERT1TC";
	            /// <summary>
        /// Property for TaxBase2 
        /// </summary>
	    public const string TaxBase2  = "TXBSERT2TC";
	            /// <summary>
        /// Property for TaxBase3 
        /// </summary>
	    public const string TaxBase3  = "TXBSERT3TC";
	            /// <summary>
        /// Property for TaxBase4 
        /// </summary>
	    public const string TaxBase4  = "TXBSERT4TC";
	            /// <summary>
        /// Property for TaxBase5 
        /// </summary>
	    public const string TaxBase5  = "TXBSERT5TC";
	            /// <summary>
        /// Property for TaxAmount1 
        /// </summary>
	    public const string TaxAmount1  = "TXAMTRT1TC";
	            /// <summary>
        /// Property for TaxAmount2 
        /// </summary>
	    public const string TaxAmount2  = "TXAMTRT2TC";
	            /// <summary>
        /// Property for TaxAmount3 
        /// </summary>
	    public const string TaxAmount3  = "TXAMTRT3TC";
	            /// <summary>
        /// Property for TaxAmount4 
        /// </summary>
	    public const string TaxAmount4  = "TXAMTRT4TC";
	            /// <summary>
        /// Property for TaxAmount5 
        /// </summary>
	    public const string TaxAmount5  = "TXAMTRT5TC";
	            /// <summary>
        /// Property for ShipmentNumber 
        /// </summary>
	    public const string ShipmentNumber  = "IDSHIPNBR";
	            /// <summary>
        /// Property for EarliestBackdatedActivityDate 
        /// </summary>
	    public const string EarliestBackdatedActivityDate  = "DATEFRSTBK";
	            /// <summary>
        /// Property for LastRevaluationDate 
        /// </summary>
	    public const string LastRevaluationDate  = "DATELSTRVL";
	            /// <summary>
        /// Property for OrigExchangeRate 
        /// </summary>
	    public const string OrigExchangeRate  = "ORATE";
	            /// <summary>
        /// Property for OrigRateType 
        /// </summary>
	    public const string OrigRateType  = "ORATETYPE";
	            /// <summary>
        /// Property for OrigRateDate 
        /// </summary>
	    public const string OrigRateDate  = "ORATEDATE";
	            /// <summary>
        /// Property for OrigRateOperator 
        /// </summary>
	    public const string OrigRateOperator  = "ORATEOP";
	            /// <summary>
        /// Property for OrigRateOverrideFlag 
        /// </summary>
	    public const string OrigRateOverrideFlag  = "OSWRATE";
	            /// <summary>
        /// Property for AccountSet 
        /// </summary>
	    public const string AccountSet  = "IDACCTSET";
	            /// <summary>
        /// Property for DatePaid 
        /// </summary>
	    public const string DatePaid  = "DATEPAID";
	            /// <summary>
        /// Property for MiscReceiptFlag 
        /// </summary>
	    public const string MiscReceiptFlag  = "SWNONRCVBL";
	            /// <summary>
        /// Property for TerritotyCode 
        /// </summary>
	    public const string TerritotyCode  = "CODETERR";

            #region UI
        /// <summary>
        /// Property for TerritotyCode 
        /// </summary>
        public const string TransactionTypeString = "TRXTYPEID";
        /// <summary>
        /// Property for TerritotyCode 
        /// </summary>
        public const string DocumentTypeString = "TRXTYPETXT";
        /// <summary>
        /// Property for TerritotyCode 
        /// </summary>
        public const string FullyPaidString = "SWPAID";
            #endregion

        #endregion
        }


		/// <summary>
        /// Contains list of Documents Index Constants
        /// </summary>
	    public class Index
        {

        #region Properties
	             /// <summary>
        /// Property Indexer for CustomerNumber 
        /// </summary>
	    public const int CustomerNumber  = 1;
	             /// <summary>
        /// Property Indexer for DocumentNumber 
        /// </summary>
	    public const int DocumentNumber  = 2;
	             /// <summary>
        /// Property Indexer for CheckOrReceiptNo 
        /// </summary>
	    public const int CheckOrReceiptNo  = 3;
	             /// <summary>
        /// Property Indexer for OrderNumber 
        /// </summary>
	    public const int OrderNumber  = 4;
	             /// <summary>
        /// Property Indexer for PONumber 
        /// </summary>
	    public const int PONumber  = 5;
	             /// <summary>
        /// Property Indexer for DueDate 
        /// </summary>
	    public const int DueDate  = 6;
	             /// <summary>
        /// Property Indexer for NationalAccountNumber 
        /// </summary>
	    public const int NationalAccountNumber  = 7;
	             /// <summary>
        /// Property Indexer for ShipToLocation 
        /// </summary>
	    public const int ShipToLocation  = 8;
	             /// <summary>
        /// Property Indexer for TransactionType 
        /// </summary>
	    public const int TransactionType  = 9;
	             /// <summary>
        /// Property Indexer for DocumentType 
        /// </summary>
	    public const int DocumentType  = 10;
	             /// <summary>
        /// Property Indexer for BatchDate 
        /// </summary>
	    public const int BatchDate  = 11;
	             /// <summary>
        /// Property Indexer for BatchNumber 
        /// </summary>
	    public const int BatchNumber  = 12;
	             /// <summary>
        /// Property Indexer for EntryNumber 
        /// </summary>
	    public const int EntryNumber  = 13;
	             /// <summary>
        /// Property Indexer for GroupCode 
        /// </summary>
	    public const int GroupCode  = 15;
	             /// <summary>
        /// Property Indexer for DocumentDescription 
        /// </summary>
	    public const int DocumentDescription  = 16;
	             /// <summary>
        /// Property Indexer for DocumentDate 
        /// </summary>
	    public const int DocumentDate  = 17;
	             /// <summary>
        /// Property Indexer for AsofDate 
        /// </summary>
	    public const int AsofDate  = 18;
	             /// <summary>
        /// Property Indexer for Terms 
        /// </summary>
	    public const int Terms  = 19;
	             /// <summary>
        /// Property Indexer for DiscountDate 
        /// </summary>
	    public const int DiscountDate  = 20;
	             /// <summary>
        /// Property Indexer for CurrencyCode 
        /// </summary>
	    public const int CurrencyCode  = 21;
	             /// <summary>
        /// Property Indexer for RateType 
        /// </summary>
	    public const int RateType  = 22;
	             /// <summary>
        /// Property Indexer for RateOverridden 
        /// </summary>
	    public const int RateOverridden  = 23;
	             /// <summary>
        /// Property Indexer for ExchangeRate 
        /// </summary>
	    public const int ExchangeRate  = 24;
	             /// <summary>
        /// Property Indexer for FuncCurrencyInvoiceAmount 
        /// </summary>
	    public const int FuncCurrencyInvoiceAmount  = 25;
	             /// <summary>
        /// Property Indexer for FuncCurrencyAmountDue 
        /// </summary>
	    public const int FuncCurrencyAmountDue  = 26;
	             /// <summary>
        /// Property Indexer for FuncCurrencyTaxableAmount 
        /// </summary>
	    public const int FuncCurrencyTaxableAmount  = 27;
	             /// <summary>
        /// Property Indexer for FuncCurrencyNonTaxableAmt 
        /// </summary>
	    public const int FuncCurrencyNonTaxableAmt  = 28;
	             /// <summary>
        /// Property Indexer for FuncCurrencyTaxAmount 
        /// </summary>
	    public const int FuncCurrencyTaxAmount  = 29;
	             /// <summary>
        /// Property Indexer for FuncCurrencyDiscountAmount 
        /// </summary>
	    public const int FuncCurrencyDiscountAmount  = 30;
	             /// <summary>
        /// Property Indexer for CustCurrencyInvoiceAmount 
        /// </summary>
	    public const int CustCurrencyInvoiceAmount  = 31;
	             /// <summary>
        /// Property Indexer for CustCurrencyAmountDue 
        /// </summary>
	    public const int CustCurrencyAmountDue  = 32;
	             /// <summary>
        /// Property Indexer for CustCurrencyTaxableAmount 
        /// </summary>
	    public const int CustCurrencyTaxableAmount  = 33;
	             /// <summary>
        /// Property Indexer for CustCurrencyNonTaxableAmt 
        /// </summary>
	    public const int CustCurrencyNonTaxableAmt  = 34;
	             /// <summary>
        /// Property Indexer for CustCurrencyTaxAmount 
        /// </summary>
	    public const int CustCurrencyTaxAmount  = 35;
	             /// <summary>
        /// Property Indexer for CustCurrencyDiscountAmount 
        /// </summary>
	    public const int CustCurrencyDiscountAmount  = 36;
	             /// <summary>
        /// Property Indexer for FullyPaid 
        /// </summary>
	    public const int FullyPaid  = 37;
	             /// <summary>
        /// Property Indexer for LastActivityDate 
        /// </summary>
	    public const int LastActivityDate  = 38;
	             /// <summary>
        /// Property Indexer for LastStatementDate 
        /// </summary>
	    public const int LastStatementDate  = 39;
	             /// <summary>
        /// Property Indexer for NumberofScheduledPayments 
        /// </summary>
	    public const int NumberofScheduledPayments  = 42;
	             /// <summary>
        /// Property Indexer for PaymentNumberonLastStatement 
        /// </summary>
	    public const int PaymentNumberonLastStatement  = 44;
	             /// <summary>
        /// Property Indexer for LastAppliedPaymentSeqNo 
        /// </summary>
	    public const int LastAppliedPaymentSeqNo  = 46;
	             /// <summary>
        /// Property Indexer for DoNotCalcTax 
        /// </summary>
	    public const int DoNotCalcTax  = 47;
	             /// <summary>
        /// Property Indexer for TaxAuthority1 
        /// </summary>
	    public const int TaxAuthority1  = 48;
	             /// <summary>
        /// Property Indexer for TaxAuthority2 
        /// </summary>
	    public const int TaxAuthority2  = 49;
	             /// <summary>
        /// Property Indexer for TaxAuthority3 
        /// </summary>
	    public const int TaxAuthority3  = 50;
	             /// <summary>
        /// Property Indexer for TaxAuthority4 
        /// </summary>
	    public const int TaxAuthority4  = 51;
	             /// <summary>
        /// Property Indexer for TaxAuthority5 
        /// </summary>
	    public const int TaxAuthority5  = 52;
	             /// <summary>
        /// Property Indexer for FuncBaseAmount1 
        /// </summary>
	    public const int FuncBaseAmount1  = 53;
	             /// <summary>
        /// Property Indexer for FuncBaseAmount2 
        /// </summary>
	    public const int FuncBaseAmount2  = 54;
	             /// <summary>
        /// Property Indexer for FuncBaseAmount3 
        /// </summary>
	    public const int FuncBaseAmount3  = 55;
	             /// <summary>
        /// Property Indexer for FuncBaseAmount4 
        /// </summary>
	    public const int FuncBaseAmount4  = 56;
	             /// <summary>
        /// Property Indexer for FuncBaseAmount5 
        /// </summary>
	    public const int FuncBaseAmount5  = 57;
	             /// <summary>
        /// Property Indexer for FuncTaxAmount1 
        /// </summary>
	    public const int FuncTaxAmount1  = 58;
	             /// <summary>
        /// Property Indexer for FuncTaxAmount2 
        /// </summary>
	    public const int FuncTaxAmount2  = 59;
	             /// <summary>
        /// Property Indexer for FuncTaxAmount3 
        /// </summary>
	    public const int FuncTaxAmount3  = 60;
	             /// <summary>
        /// Property Indexer for FuncTaxAmount4 
        /// </summary>
	    public const int FuncTaxAmount4  = 61;
	             /// <summary>
        /// Property Indexer for FuncTaxAmount5 
        /// </summary>
	    public const int FuncTaxAmount5  = 62;
	             /// <summary>
        /// Property Indexer for CustBaseAmount1 
        /// </summary>
	    public const int CustBaseAmount1  = 63;
	             /// <summary>
        /// Property Indexer for CustBaseAmount2 
        /// </summary>
	    public const int CustBaseAmount2  = 64;
	             /// <summary>
        /// Property Indexer for CustBaseAmount3 
        /// </summary>
	    public const int CustBaseAmount3  = 65;
	             /// <summary>
        /// Property Indexer for CustBaseAmount4 
        /// </summary>
	    public const int CustBaseAmount4  = 66;
	             /// <summary>
        /// Property Indexer for CustBaseAmount5 
        /// </summary>
	    public const int CustBaseAmount5  = 67;
	             /// <summary>
        /// Property Indexer for CustTaxAmount1 
        /// </summary>
	    public const int CustTaxAmount1  = 68;
	             /// <summary>
        /// Property Indexer for CustTaxAmount2 
        /// </summary>
	    public const int CustTaxAmount2  = 69;
	             /// <summary>
        /// Property Indexer for CustTaxAmount3 
        /// </summary>
	    public const int CustTaxAmount3  = 70;
	             /// <summary>
        /// Property Indexer for CustTaxAmount4 
        /// </summary>
	    public const int CustTaxAmount4  = 71;
	             /// <summary>
        /// Property Indexer for CustTaxAmount5 
        /// </summary>
	    public const int CustTaxAmount5  = 72;
	             /// <summary>
        /// Property Indexer for Salesperson1 
        /// </summary>
	    public const int Salesperson1  = 73;
	             /// <summary>
        /// Property Indexer for Salesperson2 
        /// </summary>
	    public const int Salesperson2  = 74;
	             /// <summary>
        /// Property Indexer for Salesperson3 
        /// </summary>
	    public const int Salesperson3  = 75;
	             /// <summary>
        /// Property Indexer for Salesperson4 
        /// </summary>
	    public const int Salesperson4  = 76;
	             /// <summary>
        /// Property Indexer for Salesperson5 
        /// </summary>
	    public const int Salesperson5  = 77;
	             /// <summary>
        /// Property Indexer for SalesSplitPercentage1 
        /// </summary>
	    public const int SalesSplitPercentage1  = 78;
	             /// <summary>
        /// Property Indexer for SalesSplitPercentage2 
        /// </summary>
	    public const int SalesSplitPercentage2  = 79;
	             /// <summary>
        /// Property Indexer for SalesSplitPercentage3 
        /// </summary>
	    public const int SalesSplitPercentage3  = 80;
	             /// <summary>
        /// Property Indexer for SalesSplitPercentage4 
        /// </summary>
	    public const int SalesSplitPercentage4  = 81;
	             /// <summary>
        /// Property Indexer for SalesSplitPercentage5 
        /// </summary>
	    public const int SalesSplitPercentage5  = 82;
	             /// <summary>
        /// Property Indexer for FiscalYear 
        /// </summary>
	    public const int FiscalYear  = 91;
	             /// <summary>
        /// Property Indexer for FiscalPeriod 
        /// </summary>
	    public const int FiscalPeriod  = 92;
	             /// <summary>
        /// Property Indexer for PrepayApplytoDocNo 
        /// </summary>
	    public const int PrepayApplytoDocNo  = 93;
	             /// <summary>
        /// Property Indexer for PostingDate 
        /// </summary>
	    public const int PostingDate  = 94;
	             /// <summary>
        /// Property Indexer for RateDate 
        /// </summary>
	    public const int RateDate  = 95;
	             /// <summary>
        /// Property Indexer for RateOperator 
        /// </summary>
	    public const int RateOperator  = 96;
	             /// <summary>
        /// Property Indexer for LastActivityYearOrPeriod 
        /// </summary>
	    public const int LastActivityYearOrPeriod  = 97;
	             /// <summary>
        /// Property Indexer for BankCode 
        /// </summary>
	    public const int BankCode  = 98;
	             /// <summary>
        /// Property Indexer for DepositNumber 
        /// </summary>
	    public const int DepositNumber  = 99;
	             /// <summary>
        /// Property Indexer for PostingSequenceNo 
        /// </summary>
	    public const int PostingSequenceNo  = 100;
	             /// <summary>
        /// Property Indexer for JobRelated 
        /// </summary>
	    public const int JobRelated  = 101;
	             /// <summary>
        /// Property Indexer for HasRetainage 
        /// </summary>
	    public const int HasRetainage  = 102;
	             /// <summary>
        /// Property Indexer for RetainageOutstanding 
        /// </summary>
	    public const int RetainageOutstanding  = 103;
	             /// <summary>
        /// Property Indexer for DateRetainageDue 
        /// </summary>
	    public const int DateRetainageDue  = 104;
	             /// <summary>
        /// Property Indexer for FuncCurrOrigRtngAmt 
        /// </summary>
	    public const int FuncCurrOrigRtngAmt  = 105;
	             /// <summary>
        /// Property Indexer for FuncCurrRetainageAmount 
        /// </summary>
	    public const int FuncCurrRetainageAmount  = 106;
	             /// <summary>
        /// Property Indexer for CustCurrOrigRtngAmt 
        /// </summary>
	    public const int CustCurrOrigRtngAmt  = 107;
	             /// <summary>
        /// Property Indexer for CustCurrRetainageAmount 
        /// </summary>
	    public const int CustCurrRetainageAmount  = 108;
	             /// <summary>
        /// Property Indexer for RetainageTermsCode 
        /// </summary>
	    public const int RetainageTermsCode  = 109;
	             /// <summary>
        /// Property Indexer for RetainageExchangeRate 
        /// </summary>
	    public const int RetainageExchangeRate  = 110;
	             /// <summary>
        /// Property Indexer for OriginalDocNo 
        /// </summary>
	    public const int OriginalDocNo  = 111;
	             /// <summary>
        /// Property Indexer for OptionalFields 
        /// </summary>
	    public const int OptionalFields  = 112;
	             /// <summary>
        /// Property Indexer for SourceApplication 
        /// </summary>
	    public const int SourceApplication  = 113;
	             /// <summary>
        /// Property Indexer for AOrRVersionCreatedIn 
        /// </summary>
	    public const int AOrRVersionCreatedIn  = 114;
	             /// <summary>
        /// Property Indexer for InvoiceType 
        /// </summary>
	    public const int InvoiceType  = 115;
	             /// <summary>
        /// Property Indexer for DepositSerialNumber 
        /// </summary>
	    public const int DepositSerialNumber  = 116;
	             /// <summary>
        /// Property Indexer for DepositLineNumber 
        /// </summary>
	    public const int DepositLineNumber  = 117;
	             /// <summary>
        /// Property Indexer for BatchType 
        /// </summary>
	    public const int BatchType  = 118;
	             /// <summary>
        /// Property Indexer for NumberofOBLJDetails 
        /// </summary>
	    public const int NumberofOBLJDetails  = 119;
	             /// <summary>
        /// Property Indexer for TaxReportingCurrencyCode 
        /// </summary>
	    public const int TaxReportingCurrencyCode  = 120;
	             /// <summary>
        /// Property Indexer for TaxReportingExchangeRate 
        /// </summary>
	    public const int TaxReportingExchangeRate  = 121;
	             /// <summary>
        /// Property Indexer for TaxReportingRateType 
        /// </summary>
	    public const int TaxReportingRateType  = 122;
	             /// <summary>
        /// Property Indexer for TaxReportingRateDate 
        /// </summary>
	    public const int TaxReportingRateDate  = 123;
	             /// <summary>
        /// Property Indexer for TaxReportingRateOperator 
        /// </summary>
	    public const int TaxReportingRateOperator  = 124;
	             /// <summary>
        /// Property Indexer for TaxReportingRateOverride 
        /// </summary>
	    public const int TaxReportingRateOverride  = 125;
	             /// <summary>
        /// Property Indexer for ReportRetainageTax 
        /// </summary>
	    public const int ReportRetainageTax  = 126;
	             /// <summary>
        /// Property Indexer for TaxGroup 
        /// </summary>
	    public const int TaxGroup  = 127;
	             /// <summary>
        /// Property Indexer for TaxStateVersion 
        /// </summary>
	    public const int TaxStateVersion  = 128;
	             /// <summary>
        /// Property Indexer for TaxReportingCalculateMethod 
        /// </summary>
	    public const int TaxReportingCalculateMethod  = 129;
	             /// <summary>
        /// Property Indexer for TaxClass1 
        /// </summary>
	    public const int TaxClass1  = 130;
	             /// <summary>
        /// Property Indexer for TaxClass2 
        /// </summary>
	    public const int TaxClass2  = 131;
	             /// <summary>
        /// Property Indexer for TaxClass3 
        /// </summary>
	    public const int TaxClass3  = 132;
	             /// <summary>
        /// Property Indexer for TaxClass4 
        /// </summary>
	    public const int TaxClass4  = 133;
	             /// <summary>
        /// Property Indexer for TaxClass5 
        /// </summary>
	    public const int TaxClass5  = 134;
	             /// <summary>
        /// Property Indexer for TaxBase1 
        /// </summary>
	    public const int TaxBase1  = 135;
	             /// <summary>
        /// Property Indexer for TaxBase2 
        /// </summary>
	    public const int TaxBase2  = 136;
	             /// <summary>
        /// Property Indexer for TaxBase3 
        /// </summary>
	    public const int TaxBase3  = 137;
	             /// <summary>
        /// Property Indexer for TaxBase4 
        /// </summary>
	    public const int TaxBase4  = 138;
	             /// <summary>
        /// Property Indexer for TaxBase5 
        /// </summary>
	    public const int TaxBase5  = 139;
	             /// <summary>
        /// Property Indexer for TaxAmount1 
        /// </summary>
	    public const int TaxAmount1  = 140;
	             /// <summary>
        /// Property Indexer for TaxAmount2 
        /// </summary>
	    public const int TaxAmount2  = 141;
	             /// <summary>
        /// Property Indexer for TaxAmount3 
        /// </summary>
	    public const int TaxAmount3  = 142;
	             /// <summary>
        /// Property Indexer for TaxAmount4 
        /// </summary>
	    public const int TaxAmount4  = 143;
	             /// <summary>
        /// Property Indexer for TaxAmount5 
        /// </summary>
	    public const int TaxAmount5  = 144;
	             /// <summary>
        /// Property Indexer for ShipmentNumber 
        /// </summary>
	    public const int ShipmentNumber  = 145;
	             /// <summary>
        /// Property Indexer for EarliestBackdatedActivityDate 
        /// </summary>
	    public const int EarliestBackdatedActivityDate  = 146;
	             /// <summary>
        /// Property Indexer for LastRevaluationDate 
        /// </summary>
	    public const int LastRevaluationDate  = 147;
	             /// <summary>
        /// Property Indexer for OrigExchangeRate 
        /// </summary>
	    public const int OrigExchangeRate  = 148;
	             /// <summary>
        /// Property Indexer for OrigRateType 
        /// </summary>
	    public const int OrigRateType  = 149;
	             /// <summary>
        /// Property Indexer for OrigRateDate 
        /// </summary>
	    public const int OrigRateDate  = 150;
	             /// <summary>
        /// Property Indexer for OrigRateOperator 
        /// </summary>
	    public const int OrigRateOperator  = 151;
	             /// <summary>
        /// Property Indexer for OrigRateOverrideFlag 
        /// </summary>
	    public const int OrigRateOverrideFlag  = 152;
	             /// <summary>
        /// Property Indexer for AccountSet 
        /// </summary>
	    public const int AccountSet  = 153;
	             /// <summary>
        /// Property Indexer for DatePaid 
        /// </summary>
	    public const int DatePaid  = 154;
	             /// <summary>
        /// Property Indexer for MiscReceiptFlag 
        /// </summary>
	    public const int MiscReceiptFlag  = 155;
	             /// <summary>
        /// Property Indexer for TerritotyCode 
        /// </summary>
	    public const int TerritotyCode  = 156;
	     
        #endregion
	    }

        #region Keys Properties
        /// <summary>
        /// Contains list of Document Keys Constants, used for order by
        /// This Keys class is added for Order By
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 1;
        }
        #endregion
	
	}
}
	