/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Invoices Constants 
    /// </summary>
    public partial class Invoice
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0032";

        /// <summary>
        /// Contains list of Invoices Fields Constants
        /// </summary>
        public class Fields : BaseFields
        {
            #region Fake Fields for numeric access to batch/entry

            /// <summary>
            /// Property for NBatchNumber
            /// </summary>
            public const string NBatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for NBatchNumber
            /// </summary>
            public const string NEntryNumber = "CNTITEM";

            #endregion
        }

        /// <summary>
        /// Contains list of Invoices Index Constants
        /// </summary>
        public class Index : BaseIndex
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;
            /// <summary>
            /// Property Indexer for InvoicePrinted 
            /// </summary>
            public const int InvoicePrinted = 15;

            /// <summary>
            /// Property Indexer for CustomerNumber 
            /// </summary>
            public const int CustomerNumber = 3;
            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 4;
            /// <summary>
            /// Property Indexer for ShipToLocationCode 
            /// </summary>
            public const int ShipToLocationCode = 5;
            /// <summary>
            /// Property Indexer for SpecialInstructions 
            /// </summary>
            public const int SpecialInstructions = 7;
            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 8;
            /// <summary>
            /// Property Indexer for TransactionType 
            /// </summary>
            public const int TransactionType = 9;
            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 11;
            /// <summary>
            /// Property Indexer for PONumber 
            /// </summary>
            public const int PONumber = 12;
            /// <summary>
            /// Property Indexer for InvoiceDescription 
            /// </summary>
            public const int InvoiceDescription = 14;
            /// <summary>
            /// Property Indexer for ApplytoDocument 
            /// </summary>
            public const int ApplytoDocument = 16;
            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 17;
            /// <summary>
            /// Property Indexer for DocumentDate 
            /// </summary>
            public const int DocumentDate = 18;
            /// <summary>
            /// Property Indexer for AsofDate 
            /// </summary>
            public const int AsofDate = 19;
            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 20;
            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 21;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 22;
            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 23;
            /// <summary>
            /// Property Indexer for RateOverridden 
            /// </summary>
            public const int RateOverridden = 24;
            /// <summary>
            /// Property Indexer for ExchangeRate 
            /// </summary>
            public const int ExchangeRate = 25;
            /// <summary>
            /// Property Indexer for ApplytoExchangeRate 
            /// </summary>
            public const int ApplytoExchangeRate = 26;
            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 27;
            /// <summary>
            /// Property Indexer for TermsCodeOverridden 
            /// </summary>
            public const int TermsCodeOverridden = 28;
            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 29;
            /// <summary>
            /// Property Indexer for DiscountDate 
            /// </summary>
            public const int DiscountDate = 30;
            /// <summary>
            /// Property Indexer for DiscountPercentage 
            /// </summary>
            public const int DiscountPercentage = 31;
            /// <summary>
            /// Property Indexer for DiscountAmountAvailable 
            /// </summary>
            public const int DiscountAmountAvailable = 32;
            /// <summary>
            /// Property Indexer for NumberofDetails 
            /// </summary>
            public const int NumberOfDetails = 33;
            /// <summary>
            /// Property Indexer for Salesperson1 
            /// </summary>
            public const int Salesperson1 = 34;
            /// <summary>
            /// Property Indexer for Salesperson2 
            /// </summary>
            public const int Salesperson2 = 35;
            /// <summary>
            /// Property Indexer for Salesperson3 
            /// </summary>
            public const int Salesperson3 = 36;
            /// <summary>
            /// Property Indexer for Salesperson4 
            /// </summary>
            public const int Salesperson4 = 37;
            /// <summary>
            /// Property Indexer for Salesperson5 
            /// </summary>
            public const int Salesperson5 = 38;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage1 
            /// </summary>
            public const int SalesSplitPercentage1 = 39;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage2 
            /// </summary>
            public const int SalesSplitPercentage2 = 40;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage3 
            /// </summary>
            public const int SalesSplitPercentage3 = 41;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage4 
            /// </summary>
            public const int SalesSplitPercentage4 = 42;
            /// <summary>
            /// Property Indexer for SalesSplitPercentage5 
            /// </summary>
            public const int SalesSplitPercentage5 = 43;
            /// <summary>
            /// Property Indexer for Taxable 
            /// </summary>
            public const int Taxable = 44;
            /// <summary>
            /// Property Indexer for DoNotCalcTax 
            /// </summary>
            public const int DoNotCalcTax = 45;
            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 46;
            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 47;
            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 48;
            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 49;
            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 50;
            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 51;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 52;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 53;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 54;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 55;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 56;
            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 57;
            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 58;
            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 59;
            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 60;
            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 61;
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 67;
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 68;
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 69;
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 70;
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 71;
            /// <summary>
            /// Property Indexer for TaxableAmount 
            /// </summary>
            public const int TaxableAmount = 80;
            /// <summary>
            /// Property Indexer for NonTaxableAmount 
            /// </summary>
            public const int NonTaxableAmount = 81;
            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 82;
            /// <summary>
            /// Property Indexer for DocumentTotalBeforeTax 
            /// </summary>
            public const int DocumentTotalBeforeTax = 83;
            /// <summary>
            /// Property Indexer for PrepaymentAmount 
            /// </summary>
            public const int PrepaymentAmount = 84;
            /// <summary>
            /// Property Indexer for NumberofScheduledPayments 
            /// </summary>
            public const int NumberofScheduledPayments = 85;
            /// <summary>
            /// Property Indexer for TotalPaymentAmountScheduled 
            /// </summary>
            public const int TotalPaymentAmountScheduled = 86;
            /// <summary>
            /// Property Indexer for DocumentTotalIncludingTax 
            /// </summary>
            public const int DocumentTotalIncludingTax = 87;
            /// <summary>
            /// Property Indexer for RecurringChargeCode 
            /// </summary>
            public const int RecurringChargeCode = 88;
            /// <summary>
            /// Property Indexer for DateGenerated 
            /// </summary>
            public const int DateGenerated = 89;
            /// <summary>
            /// Property Indexer for PrepaymentNumber 
            /// </summary>
            public const int PrepaymentNumber = 90;
            /// <summary>
            /// Property Indexer for RecurringBillingCycle 
            /// </summary>
            public const int RecurringBillingCycle = 91;
            /// <summary>
            /// Property Indexer for ShipToLocationName 
            /// </summary>
            public const int ShipToLocationName = 92;
            /// <summary>
            /// Property Indexer for ShipToAddressLine1 
            /// </summary>
            public const int ShipToAddressLine1 = 93;
            /// <summary>
            /// Property Indexer for ShipToAddressLine2 
            /// </summary>
            public const int ShipToAddressLine2 = 94;
            /// <summary>
            /// Property Indexer for ShipToAddressLine3 
            /// </summary>
            public const int ShipToAddressLine3 = 95;
            /// <summary>
            /// Property Indexer for ShipToAddressLine4 
            /// </summary>
            public const int ShipToAddressLine4 = 96;
            /// <summary>
            /// Property Indexer for ShipToCity 
            /// </summary>
            public const int ShipToCity = 97;
            /// <summary>
            /// Property Indexer for ShipToStateOrProv 
            /// </summary>
            public const int ShipToStateOrProv = 98;
            /// <summary>
            /// Property Indexer for ShipToZipOrPostalCode 
            /// </summary>
            public const int ShipToZipOrPostalCode = 99;
            /// <summary>
            /// Property Indexer for ShipToCountry 
            /// </summary>
            public const int ShipToCountry = 100;
            /// <summary>
            /// Property Indexer for ShipToContactName 
            /// </summary>
            public const int ShipToContactName = 101;
            /// <summary>
            /// Property Indexer for ShipToPhoneNumber 
            /// </summary>
            public const int ShipToPhoneNumber = 102;
            /// <summary>
            /// Property Indexer for ShipToFaxNumber 
            /// </summary>
            public const int ShipToFaxNumber = 103;
            /// <summary>
            /// Property Indexer for RateDate 
            /// </summary>
            public const int RateDate = 104;
            /// <summary>
            /// Property Indexer for CustOrNatlOverCreditFlag 
            /// </summary>
            public const int CustOrNatlOverCreditFlag = 105;
            /// <summary>
            /// Property Indexer for AmountDue 
            /// </summary>
            public const int AmountDue = 106;
            /// <summary>
            /// Property Indexer for RateOperator 
            /// </summary>
            public const int RateOperator = 108;
            /// <summary>
            /// Property Indexer for DrillDownApplicationSource 
            /// </summary>
            public const int DrillDownApplicationSource = 109;
            /// <summary>
            /// Property Indexer for DrillDownType 
            /// </summary>
            public const int DrillDownType = 110;
            /// <summary>
            /// Property Indexer for DrillDownLinkNumber 
            /// </summary>
            public const int DrillDownLinkNumber = 111;
            /// <summary>
            /// Property Indexer for ForceRereadofIBSTotals 
            /// </summary>
            public const int ForceRereadofIBSTotals = 113;
            /// <summary>
            /// Property Indexer for ProcessCommand 
            /// </summary>
            public const int ProcessCommand = 114;
            /// <summary>
            /// Property Indexer for ShipViaCode 
            /// </summary>
            public const int ShipViaCode = 115;
            /// <summary>
            /// Property Indexer for ShipViaDescription 
            /// </summary>
            public const int ShipViaDescription = 116;
            /// <summary>
            /// Property Indexer for PropertyCode 
            /// </summary>
            public const int PropertyCode = 117;
            /// <summary>
            /// Property Indexer for PropertyValue 
            /// </summary>
            public const int PropertyValue = 118;
            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 119;
            /// <summary>
            /// Property Indexer for ErrorBatch 
            /// </summary>
            public const int ErrorBatch = 120;
            /// <summary>
            /// Property Indexer for ErrorEntry 
            /// </summary>
            public const int ErrorEntry = 121;
            /// <summary>
            /// Property Indexer for ShipToEmail 
            /// </summary>
            public const int ShipToEmail = 122;
            /// <summary>
            /// Property Indexer for ShipToContactsPhone 
            /// </summary>
            public const int ShipToContactsPhone = 123;
            /// <summary>
            /// Property Indexer for ShipToContactsFax 
            /// </summary>
            public const int ShipToContactsFax = 124;
            /// <summary>
            /// Property Indexer for ShipToContactsEmail 
            /// </summary>
            public const int ShipToContactsEmail = 125;
            /// <summary>
            /// Property Indexer for DiscountBaseWithTax 
            /// </summary>
            public const int DiscountBaseWithTax = 126;
            /// <summary>
            /// Property Indexer for DiscountBaseWithoutTax 
            /// </summary>
            public const int DiscountBaseWithoutTax = 127;
            /// <summary>
            /// Property Indexer for DiscountBase 
            /// </summary>
            public const int DiscountBase = 128;
            /// <summary>
            /// Property Indexer for InvoiceType 
            /// </summary>
            public const int InvoiceType = 129;
            /// <summary>
            /// Property Indexer for RetainageInvoice 
            /// </summary>
            public const int RetainageInvoice = 130;
            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 131;
            /// <summary>
            /// Property Indexer for HasRetainage 
            /// </summary>
            public const int HasRetainage = 132;
            /// <summary>
            /// Property Indexer for RetainageAmount 
            /// </summary>
            public const int RetainageAmount = 133;
            /// <summary>
            /// Property Indexer for PercentRetained 
            /// </summary>
            public const int PercentRetained = 134;
            /// <summary>
            /// Property Indexer for DaysRetained 
            /// </summary>
            public const int DaysRetained = 135;
            /// <summary>
            /// Property Indexer for RetainageDueDate 
            /// </summary>
            public const int RetainageDueDate = 136;
            /// <summary>
            /// Property Indexer for RetainageTermsCode 
            /// </summary>
            public const int RetainageTermsCode = 137;
            /// <summary>
            /// Property Indexer for RetainageDueDateOverride 
            /// </summary>
            public const int RetainageDueDateOverride = 138;
            /// <summary>
            /// Property Indexer for RetainageAmountOverride 
            /// </summary>
            public const int RetainageAmountOverride = 139;
            /// <summary>
            /// Property Indexer for RetainageExchangeRate 
            /// </summary>
            public const int RetainageExchangeRate = 140;
            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 141;
            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 142;
            /// <summary>
            /// Property Indexer for AOrRVersionCreatedIn 
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int AOrRVersionCreatedIn = 143;
            /// <summary>
            /// Property Indexer for TaxStateVersion 
            /// </summary>
            public const int TaxStateVersion = 144;
            /// <summary>
            /// Property Indexer for ReportRetainageTax 
            /// </summary>
            public const int ReportRetainageTax = 145;
            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode 
            /// </summary>
            public const int TaxReportingCurrencyCode = 146;
            /// <summary>
            /// Property Indexer for TaxReportingCalculateMethod 
            /// </summary>
            public const int TaxReportingCalculateMethod = 147;
            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate 
            /// </summary>
            public const int TaxReportingExchangeRate = 148;
            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 149;
            /// <summary>
            /// Property Indexer for TaxReportingRateDate 
            /// </summary>
            public const int TaxReportingRateDate = 150;
            /// <summary>
            /// Property Indexer for TaxReportingRateOperator 
            /// </summary>
            public const int TaxReportingRateOperator = 151;
            /// <summary>
            /// Property Indexer for TaxReportingRateOverride 
            /// </summary>
            public const int TaxReportingRateOverride = 152;
            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 153;
            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 154;
            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 155;
            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 156;
            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 157;
            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 158;
            /// <summary>
            /// Property Indexer for RetainageTaxBase1 
            /// </summary>
            public const int RetainageTaxBase1 = 159;
            /// <summary>
            /// Property Indexer for RetainageTaxBase2 
            /// </summary>
            public const int RetainageTaxBase2 = 160;
            /// <summary>
            /// Property Indexer for RetainageTaxBase3 
            /// </summary>
            public const int RetainageTaxBase3 = 161;
            /// <summary>
            /// Property Indexer for RetainageTaxBase4 
            /// </summary>
            public const int RetainageTaxBase4 = 162;
            /// <summary>
            /// Property Indexer for RetainageTaxBase5 
            /// </summary>
            public const int RetainageTaxBase5 = 163;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount1 
            /// </summary>
            public const int RetainageTaxAmount1 = 164;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount2 
            /// </summary>
            public const int RetainageTaxAmount2 = 165;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount3 
            /// </summary>
            public const int RetainageTaxAmount3 = 166;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount4 
            /// </summary>
            public const int RetainageTaxAmount4 = 167;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount5 
            /// </summary>
            public const int RetainageTaxAmount5 = 168;
            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 169;
            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 170;
            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 171;
            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 172;
            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 173;
            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 174;
            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 175;
            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 176;
            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 177;
            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 178;
            /// <summary>
            /// Property Indexer for FuncDistributionwOrTaxTotal 
            /// </summary>
            public const int FuncDistributionwOrTaxTotal = 179;
            /// <summary>
            /// Property Indexer for FuncRetainageAmount 
            /// </summary>
            public const int FuncRetainageAmount = 180;
            /// <summary>
            /// Property Indexer for FuncDiscountAmount 
            /// </summary>
            public const int FuncDiscountAmount = 181;
            /// <summary>
            /// Property Indexer for FuncDistributionwOroTaxTotal 
            /// </summary>
            public const int FuncDistributionwOroTaxTotal = 182;
            /// <summary>
            /// Property Indexer for FuncPrepaymentAmount 
            /// </summary>
            public const int FuncPrepaymentAmount = 183;
            /// <summary>
            /// Property Indexer for FuncAmountDue 
            /// </summary>
            public const int FuncAmountDue = 184;
            /// <summary>
            /// Property Indexer for LabelPrinted 
            /// </summary>
            public const int LabelPrinted = 185;
            /// <summary>
            /// Property Indexer for RetainageTaxTotal 
            /// </summary>
            public const int RetainageTaxTotal = 186;
            /// <summary>
            /// Property Indexer for TaxAmount1Total 
            /// </summary>
            public const int TaxAmount1Total = 187;
            /// <summary>
            /// Property Indexer for TaxAmount2Total 
            /// </summary>
            public const int TaxAmount2Total = 188;
            /// <summary>
            /// Property Indexer for TaxAmount3Total 
            /// </summary>
            public const int TaxAmount3Total = 189;
            /// <summary>
            /// Property Indexer for TaxAmount4Total 
            /// </summary>
            public const int TaxAmount4Total = 190;
            /// <summary>
            /// Property Indexer for TaxAmount5Total 
            /// </summary>
            public const int TaxAmount5Total = 191;
            /// <summary>
            /// Property Indexer for RetainageAmountfromDetails 
            /// </summary>
            public const int RetainageAmountFromDetails = 192;
            /// <summary>
            /// Property Indexer for ShipmentNumber 
            /// </summary>
            public const int ShipmentNumber = 193;
            /// <summary>
            /// Property Indexer for DoOOrECostingandConsolidation 
            /// </summary>
            public const int DoOOrECostingandConsolidation = 194;
            /// <summary>
            /// Property Indexer for EnteredBy 
            /// </summary>
            public const int EnteredBy = 195;
            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 196;
            /// <summary>
            /// Property Indexer for Export Declaration Number
            /// </summary>
            public const int ExportDeclarationNumber = 197;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount1.
            /// </summary>
            public const int EstimatedTaxWithheld1 = 198;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount2.
            /// </summary>
            public const int EstimatedTaxWithheld2 = 199;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount3?
            /// </summary>
            public const int EstimatedTaxWithheld3 = 200;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount4.
            /// </summary>
            public const int EstimatedTaxWithheld4 = 201;
            /// <summary>
            /// Property Indexer for estimated tax withheld amount5.
            /// </summary>
            public const int EstimatedTaxWithheld5 = 202;
            /// <summary>
            /// Property Indexer for SF Payments Acceptance URL.
            /// </summary>
            public const int PaymentsURL = 203;
            /// <summary>
            /// Property Indexer for SF Payments Acceptance ID.
            /// </summary>
            public const int PaymentsID = 204;
            /// <summary>
            /// Property Indexer for Total Tax Withholding.
            /// </summary>
            public const int TotalTaxWithholding = 205;
            /// <summary>
            /// Property Indexer for Amount due with tax withholding.
            /// </summary>
            public const int AmountDueWithTaxWithholding = 206;
            /// <summary>
            /// Property Indexer for Amount due with tax withholding adjusted.
            /// </summary>
            public const int AmountDueWithTaxWithholdingAdjusted = 207;

            #region Fake Fields for Batch / Entry access
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int NBatchNumber = 1;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int NEntryNumber = 2;
            
            #endregion 
            #endregion
        }

        /// <summary>
        /// Class Keys.
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Property Indexer for CheckNumber 
            /// </summary>
            public const int BatchEntry = 0;
            public const int CustomerDocument = 1;
            public const int DocumentNumber = 2;
        }
        
    }
}

