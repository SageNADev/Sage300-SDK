// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
	/// <summary>
	/// Contains list of RefundDetailJob Constants
	/// </summary>
	public partial class RefundJobDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "AR0145";

		#region Properties

		/// <summary>
		/// Contains list of RefundDetailJob Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBTCH";

			/// <summary>
			/// Property for EntryNumber
			/// </summary>
			public const string EntryNumber = "CNTITEM";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "CNTLINE";

			/// <summary>
			/// Property for SeqNo
			/// </summary>
			public const string SeqNo = "CNTSEQ";

			/// <summary>
			/// Property for OriginalLineNumber
			/// </summary>
			public const string OriginalLineNumber = "OCNTLINE";

			/// <summary>
			/// Property for ContractCode
			/// </summary>
			public const string ContractCode = "CONTRACT";

			/// <summary>
			/// Property for ProjectCode
			/// </summary>
			public const string ProjectCode = "PROJECT";

			/// <summary>
			/// Property for CategoryCode
			/// </summary>
			public const string CategoryCode = "CATEGORY";

			/// <summary>
			/// Property for ProjectCategoryResource
			/// </summary>
			public const string ProjectCategoryResource = "RESOURCE";

			/// <summary>
			/// Property for TransactionNumber
			/// </summary>
			public const string TransactionNumber = "TRANSNBR";

			/// <summary>
			/// Property for CostClass
			/// </summary>
			public const string CostClass = "COSTCLASS";

			/// <summary>
			/// Property for RefundAmountInCustCurr
			/// </summary>
			public const string RefundAmountInCustCurr = "AMTTC";

			/// <summary>
			/// Property for AmountDueInCustCurr
			/// </summary>
			public const string AmountDueInCustCurr = "AMTDUETC";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of RefundDetailJob Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 1;

			/// <summary>
			/// Property Indexer for EntryNumber
			/// </summary>
			public const int EntryNumber = 2;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 3;

			/// <summary>
			/// Property Indexer for SeqNo
			/// </summary>
			public const int SeqNo = 4;

			/// <summary>
			/// Property Indexer for OriginalLineNumber
			/// </summary>
			public const int OriginalLineNumber = 5;

			/// <summary>
			/// Property Indexer for ContractCode
			/// </summary>
			public const int ContractCode = 6;

			/// <summary>
			/// Property Indexer for ProjectCode
			/// </summary>
			public const int ProjectCode = 7;

			/// <summary>
			/// Property Indexer for CategoryCode
			/// </summary>
			public const int CategoryCode = 8;

			/// <summary>
			/// Property Indexer for ProjectCategoryResource
			/// </summary>
			public const int ProjectCategoryResource = 9;

			/// <summary>
			/// Property Indexer for TransactionNumber
			/// </summary>
			public const int TransactionNumber = 10;

			/// <summary>
			/// Property Indexer for CostClass
			/// </summary>
			public const int CostClass = 11;

			/// <summary>
			/// Property Indexer for RefundAmountInCustCurr
			/// </summary>
			public const int RefundAmountInCustCurr = 12;

			/// <summary>
			/// Property Indexer for AmountDueInCustCurr
			/// </summary>
			public const int AmountDueInCustCurr = 13;

		}

		#endregion

	}
}
