// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of ItemPricing Constants 
    /// </summary>
	public partial class ItemPricing 
	{
	 
        /// <summary>
        /// View Name
        /// </summary>
	    public const string EntityName = "AR0009";

        /// <summary>
        /// Contains list of ItemPricing Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties

            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "IDITEM";

            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UNITMEAS";

            /// <summary>
            /// Property for ItemCost 
            /// </summary>
            public const string ItemCost = "AMTCOST";

            /// <summary>
            /// Property for ItemPrice 
            /// </summary>
            public const string ItemPrice = "AMTPRICE";

            /// <summary>
            /// Property for TaxBase 
            /// </summary>
            public const string TaxBase = "AMTBASETAX";

            #endregion
        }


        /// <summary>
        /// Contains list of ItemPricing Index Constants
        /// </summary>
        public class Index
        {

            #region Properties

            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 1;

            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 2;

            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 3;

            /// <summary>
            /// Property Indexer for ItemCost 
            /// </summary>
            public const int ItemCost = 5;

            /// <summary>
            /// Property Indexer for ItemPrice 
            /// </summary>
            public const int ItemPrice = 6;

            /// <summary>
            /// Property Indexer for TaxBase 
            /// </summary>
            public const int TaxBase = 7;

            #endregion
        }


	}
}
	