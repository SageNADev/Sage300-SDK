// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Contains list of RecurringChargeDetail Constants
	/// </summary>
	public partial class RecurringChargeDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "AR0047";

		#region Properties

		/// <summary>
		/// Contains list of RecurringChargeDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for RecurringChargeCode
			/// </summary>
			public const string RecurringChargeCode = "IDSTDINVC";

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "IDCUST";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "CNTLINE";

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "IDITEM";

			/// <summary>
			/// Property for DistributionCode
			/// </summary>
			public const string DistributionCode = "IDDIST";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "TEXTDESC";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "UNITMEAS";

			/// <summary>
			/// Property for Quantity
			/// </summary>
			public const string Quantity = "QTYINVC";

			/// <summary>
			/// Property for Cost
			/// </summary>
			public const string Cost = "AMTCOST";

			/// <summary>
			/// Property for Price
			/// </summary>
			public const string Price = "AMTPRIC";

			/// <summary>
			/// Property for ExtendedAmountWithTip
			/// </summary>
			public const string ExtendedAmountWithTip = "AMTEXTN";

			/// <summary>
			/// Property for COGSAmount
			/// </summary>
			public const string COGSAmount = "AMTCOGS";

			/// <summary>
			/// Property for ExtendedAmountWithoutTip
			/// </summary>
			public const string ExtendedAmountWithoutTip = "AMTTXBL";

			/// <summary>
			/// Property for TotalTaxAmount
			/// </summary>
			public const string TotalTaxAmount = "AMTTOTTX";

			/// <summary>
			/// Property for TaxBase1
			/// </summary>
			public const string TaxBase1 = "BASETAX1";

			/// <summary>
			/// Property for TaxBase2
			/// </summary>
			public const string TaxBase2 = "BASETAX2";

			/// <summary>
			/// Property for TaxBase3
			/// </summary>
			public const string TaxBase3 = "BASETAX3";

			/// <summary>
			/// Property for TaxBase4
			/// </summary>
			public const string TaxBase4 = "BASETAX4";

			/// <summary>
			/// Property for TaxBase5
			/// </summary>
			public const string TaxBase5 = "BASETAX5";

			/// <summary>
			/// Property for TaxClass1
			/// </summary>
			public const string TaxClass1 = "TAXSTTS1";

			/// <summary>
			/// Property for TaxClass2
			/// </summary>
			public const string TaxClass2 = "TAXSTTS2";

			/// <summary>
			/// Property for TaxClass3
			/// </summary>
			public const string TaxClass3 = "TAXSTTS3";

			/// <summary>
			/// Property for TaxClass4
			/// </summary>
			public const string TaxClass4 = "TAXSTTS4";

			/// <summary>
			/// Property for TaxClass5
			/// </summary>
			public const string TaxClass5 = "TAXSTTS5";

			/// <summary>
			/// Property for TaxIncluded1
			/// </summary>
			public const string TaxIncluded1 = "SWTXINCL1";

			/// <summary>
			/// Property for TaxIncluded2
			/// </summary>
			public const string TaxIncluded2 = "SWTXINCL2";

			/// <summary>
			/// Property for TaxIncluded3
			/// </summary>
			public const string TaxIncluded3 = "SWTXINCL3";

			/// <summary>
			/// Property for TaxIncluded4
			/// </summary>
			public const string TaxIncluded4 = "SWTXINCL4";

			/// <summary>
			/// Property for TaxIncluded5
			/// </summary>
			public const string TaxIncluded5 = "SWTXINCL5";

			/// <summary>
			/// Property for TaxRate1
			/// </summary>
			public const string TaxRate1 = "RATETAX1";

			/// <summary>
			/// Property for TaxRate2
			/// </summary>
			public const string TaxRate2 = "RATETAX2";

			/// <summary>
			/// Property for TaxRate3
			/// </summary>
			public const string TaxRate3 = "RATETAX3";

			/// <summary>
			/// Property for TaxRate4
			/// </summary>
			public const string TaxRate4 = "RATETAX4";

			/// <summary>
			/// Property for TaxRate5
			/// </summary>
			public const string TaxRate5 = "RATETAX5";

			/// <summary>
			/// Property for TaxAmount1
			/// </summary>
			public const string TaxAmount1 = "AMTTAX1";

			/// <summary>
			/// Property for TaxAmount2
			/// </summary>
			public const string TaxAmount2 = "AMTTAX2";

			/// <summary>
			/// Property for TaxAmount3
			/// </summary>
			public const string TaxAmount3 = "AMTTAX3";

			/// <summary>
			/// Property for TaxAmount4
			/// </summary>
			public const string TaxAmount4 = "AMTTAX4";

			/// <summary>
			/// Property for TaxAmount5
			/// </summary>
			public const string TaxAmount5 = "AMTTAX5";

			/// <summary>
			/// Property for EstimatedWithholdingAmount1
			/// </summary>
			public const string EstimatedWithholdingAmount1 = "AMTWHT1TC";

			/// <summary>
			/// Property for EstimatedWithholdingAmount2
			/// </summary>
			public const string EstimatedWithholdingAmount2 = "AMTWHT2TC";

			/// <summary>
			/// Property for EstimatedWithholdingAmount3
			/// </summary>
			public const string EstimatedWithholdingAmount3 = "AMTWHT3TC";

			/// <summary>
			/// Property for EstimatedWithholdingAmount4
			/// </summary>
			public const string EstimatedWithholdingAmount4 = "AMTWHT4TC";

			/// <summary>
			/// Property for EstimatedWithholdingAmount5
			/// </summary>
			public const string EstimatedWithholdingAmount5 = "AMTWHT5TC";

			/// <summary>
			/// Property for RevenueAccount
			/// </summary>
			public const string RevenueAccount = "IDACCTREV";

			/// <summary>
			/// Property for DistributedAmountBeforeTax
			/// </summary>
			public const string DistributedAmountBeforeTax = "AMTINVCTOT";

			/// <summary>
			/// Property for Discountable
			/// </summary>
			public const string Discountable = "SWDISCABL";

			/// <summary>
			/// Property for InventoryAccount
			/// </summary>
			public const string InventoryAccount = "IDACCTINV";

			/// <summary>
			/// Property for COGSAccount
			/// </summary>
			public const string COGSAccount = "IDACCTCOGS";

			/// <summary>
			/// Property for Comments
			/// </summary>
			public const string Comment = "COMMENT";

			/// <summary>
			/// Property for PrintComment
			/// </summary>
			public const string PrintComment = "SWPRTSTMT";

			/// <summary>
			/// Property for ItemCost
			/// </summary>
			public const string ItemCost = "ITEMCOST";

			/// <summary>
			/// Property for OptionalFields
			/// </summary>
			public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for ProcessCommandCode
			/// </summary>
			public const string ProcessCommandCode = "PROCESSCMD";

			/// <summary>
			/// Property for ContractCode
			/// </summary>
			public const string ContractCode = "CONTRACT";

			/// <summary>
			/// Property for ProjectCode
			/// </summary>
			public const string ProjectCode = "PROJECT";

			/// <summary>
			/// Property for CategoryCode
			/// </summary>
			public const string CategoryCode = "CATEGORY";

			/// <summary>
			/// Property for ProjectCategoryResource
			/// </summary>
			public const string ProjectCategoryResource = "RESOURCE";

			/// <summary>
			/// Property for CostClass
			/// </summary>
			public const string CostClass = "COSTCLASS";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of RecurringChargeDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for RecurringChargeCode
			/// </summary>
			public const int RecurringChargeCode = 1;

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 2;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 3;

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 4;

			/// <summary>
			/// Property Indexer for DistributionCode
			/// </summary>
			public const int DistributionCode = 5;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 6;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 7;

			/// <summary>
			/// Property Indexer for Quantity
			/// </summary>
			public const int Quantity = 8;

			/// <summary>
			/// Property Indexer for Cost
			/// </summary>
			public const int Cost = 9;

			/// <summary>
			/// Property Indexer for Price
			/// </summary>
			public const int Price = 10;

			/// <summary>
			/// Property Indexer for ExtendedAmountWithTip
			/// </summary>
			public const int ExtendedAmountWithTip = 11;

			/// <summary>
			/// Property Indexer for COGSAmount
			/// </summary>
			public const int COGSAmount = 12;

			/// <summary>
			/// Property Indexer for ExtendedAmountWithoutTip
			/// </summary>
			public const int ExtendedAmountWithoutTip = 13;

			/// <summary>
			/// Property Indexer for TotalTaxAmount
			/// </summary>
			public const int TotalTaxAmount = 14;

			/// <summary>
			/// Property Indexer for TaxBase1
			/// </summary>
			public const int TaxBase1 = 16;

			/// <summary>
			/// Property Indexer for TaxBase2
			/// </summary>
			public const int TaxBase2 = 17;

			/// <summary>
			/// Property Indexer for TaxBase3
			/// </summary>
			public const int TaxBase3 = 18;

			/// <summary>
			/// Property Indexer for TaxBase4
			/// </summary>
			public const int TaxBase4 = 19;

			/// <summary>
			/// Property Indexer for TaxBase5
			/// </summary>
			public const int TaxBase5 = 20;

			/// <summary>
			/// Property Indexer for TaxClass1
			/// </summary>
			public const int TaxClass1 = 21;

			/// <summary>
			/// Property Indexer for TaxClass2
			/// </summary>
			public const int TaxClass2 = 22;

			/// <summary>
			/// Property Indexer for TaxClass3
			/// </summary>
			public const int TaxClass3 = 23;

			/// <summary>
			/// Property Indexer for TaxClass4
			/// </summary>
			public const int TaxClass4 = 24;

			/// <summary>
			/// Property Indexer for TaxClass5
			/// </summary>
			public const int TaxClass5 = 25;

			/// <summary>
			/// Property Indexer for TaxIncluded1
			/// </summary>
			public const int TaxIncluded1 = 26;

			/// <summary>
			/// Property Indexer for TaxIncluded2
			/// </summary>
			public const int TaxIncluded2 = 27;

			/// <summary>
			/// Property Indexer for TaxIncluded3
			/// </summary>
			public const int TaxIncluded3 = 28;

			/// <summary>
			/// Property Indexer for TaxIncluded4
			/// </summary>
			public const int TaxIncluded4 = 29;

			/// <summary>
			/// Property Indexer for TaxIncluded5
			/// </summary>
			public const int TaxIncluded5 = 30;

			/// <summary>
			/// Property Indexer for TaxRate1
			/// </summary>
			public const int TaxRate1 = 31;

			/// <summary>
			/// Property Indexer for TaxRate2
			/// </summary>
			public const int TaxRate2 = 32;

			/// <summary>
			/// Property Indexer for TaxRate3
			/// </summary>
			public const int TaxRate3 = 33;

			/// <summary>
			/// Property Indexer for TaxRate4
			/// </summary>
			public const int TaxRate4 = 34;

			/// <summary>
			/// Property Indexer for TaxRate5
			/// </summary>
			public const int TaxRate5 = 35;

			/// <summary>
			/// Property Indexer for TaxAmount1
			/// </summary>
			public const int TaxAmount1 = 36;

			/// <summary>
			/// Property Indexer for TaxAmount2
			/// </summary>
			public const int TaxAmount2 = 37;

			/// <summary>
			/// Property Indexer for TaxAmount3
			/// </summary>
			public const int TaxAmount3 = 38;

			/// <summary>
			/// Property Indexer for TaxAmount4
			/// </summary>
			public const int TaxAmount4 = 39;

			/// <summary>
			/// Property Indexer for TaxAmount5
			/// </summary>
			public const int TaxAmount5 = 40;

			/// <summary>
			/// Property Indexer for EstimatedWithholdingAmount1
			/// </summary>
			public const int EstimatedWithholdingAmount1 = 57;

			/// <summary>
			/// Property Indexer for EstimatedWithholdingAmount2
			/// </summary>
			public const int EstimatedWithholdingAmount2 = 58;

			/// <summary>
			/// Property Indexer for EstimatedWithholdingAmount3
			/// </summary>
			public const int EstimatedWithholdingAmount3 = 59;

			/// <summary>
			/// Property Indexer for EstimatedWithholdingAmount4
			/// </summary>
			public const int EstimatedWithholdingAmount4 = 60;

			/// <summary>
			/// Property Indexer for EstimatedWithholdingAmount5
			/// </summary>
			public const int EstimatedWithholdingAmount5 = 61;

			/// <summary>
			/// Property Indexer for RevenueAccount
			/// </summary>
			public const int RevenueAccount = 41;

			/// <summary>
			/// Property Indexer for DistributedAmountBeforeTax
			/// </summary>
			public const int DistributedAmountBeforeTax = 43;

			/// <summary>
			/// Property Indexer for Discountable
			/// </summary>
			public const int Discountable = 44;

			/// <summary>
			/// Property Indexer for InventoryAccount
			/// </summary>
			public const int InventoryAccount = 45;

			/// <summary>
			/// Property Indexer for COGSAccount
			/// </summary>
			public const int COGSAccount = 46;

			/// <summary>
			/// Property Indexer for Comments
			/// </summary>
			public const int Comment = 47;

			/// <summary>
			/// Property Indexer for PrintComment
			/// </summary>
			public const int PrintComment = 48;

			/// <summary>
			/// Property Indexer for ItemCost
			/// </summary>
			public const int ItemCost = 49;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 50;

			/// <summary>
			/// Property Indexer for ProcessCommandCode
			/// </summary>
			public const int ProcessCommandCode = 51;

			/// <summary>
			/// Property Indexer for ContractCode
			/// </summary>
			public const int ContractCode = 52;

			/// <summary>
			/// Property Indexer for ProjectCode
			/// </summary>
			public const int ProjectCode = 53;

			/// <summary>
			/// Property Indexer for CategoryCode
			/// </summary>
			public const int CategoryCode = 54;

			/// <summary>
			/// Property Indexer for ProjectCategoryResource
			/// </summary>
			public const int ProjectCategoryResource = 55;

			/// <summary>
			/// Property Indexer for CostClass
			/// </summary>
			public const int CostClass = 56;

		}

		#endregion

	}
}
