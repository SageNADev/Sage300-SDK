// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of PostInvoices Constants 
    /// </summary>
    public partial class PostInvoice
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0048";

        /// <summary>
        /// Contains list of PostInvoices Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for PostAllBatches 
            /// </summary>
            public const string PostAllBatches = "SWALLBTCH";

            /// <summary>
            /// Property for FromBatch 
            /// </summary>
            public const string PostBatchFrom = "BATCHIDFR";

            /// <summary>
            /// Property for ToBatch 
            /// </summary>
            public const string PostBatchTo = "BATCHIDTO";

            #endregion
        }

        /// <summary>
        /// Contains list of PostInvoices Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for PostAllBatches 
            /// </summary>
            public const int PostAllBatches = 1;

            /// <summary>
            /// Property Indexer for FromBatch 
            /// </summary>
            public const int PostBatchFrom = 2;

            /// <summary>
            /// Property Indexer for ToBatch 
            /// </summary>
            public const int PostBatchTo = 3;

            #endregion
        }
    }
}