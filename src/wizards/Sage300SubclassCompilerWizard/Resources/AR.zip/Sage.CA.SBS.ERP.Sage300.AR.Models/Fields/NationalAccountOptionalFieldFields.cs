// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of National Account Optional Field Constants 
    /// </summary>
    public partial class NationalAccountOptionalField
    {
        #region Public Variables

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0411";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of National Account Optional Field Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for National Account 
            /// </summary>
            public const string NationalAccount = "IDNATACCT";

            /// <summary>
            /// Property for Optional Field 
            /// </summary>
            public const string OptionalField = "OPTFIELD";

            /// <summary>
            /// Property for Value 
            /// </summary>
            public const string Value = "VALUE";

            /// <summary>
            /// Property for Type 
            /// </summary>
            public const string Type = "TYPE";

            /// <summary>
            /// Property for Length 
            /// </summary>
            public const string Length = "LENGTH";

            /// <summary>
            /// Property for Decimals 
            /// </summary>
            public const string Decimals = "DECIMALS";

            /// <summary>
            /// Property for Allow Blank 
            /// </summary>
            public const string AllowBlank = "ALLOWNULL";

            /// <summary>
            /// Property for Validate 
            /// </summary>
            public const string Validate = "VALIDATE";

            /// <summary>
            /// Property for Value Set 
            /// </summary>
            public const string ValueSet = "SWSET";

            /// <summary>
            /// Property for Typed Value Field Index 
            /// </summary>
            public const string TypedValueFieldIndex = "VALINDEX";

            /// <summary>
            /// Property for Text Value 
            /// </summary>
            public const string TextValue = "VALIFTEXT";

            /// <summary>
            /// Property for Amount Value 
            /// </summary>
            public const string AmountValue = "VALIFMONEY";

            /// <summary>
            /// Property for Number Value 
            /// </summary>
            public const string NumberValue = "VALIFNUM";

            /// <summary>
            /// Property for Integer Value 
            /// </summary>
            public const string IntegerValue = "VALIFLONG";

            /// <summary>
            /// Property for Yes Or No Value 
            /// </summary>
            public const string YesOrNoValue = "VALIFBOOL";

            /// <summary>
            /// Property for Date Value 
            /// </summary>
            public const string DateValue = "VALIFDATE";

            /// <summary>
            /// Property for Time Value 
            /// </summary>
            public const string TimeValue = "VALIFTIME";

            /// <summary>
            /// Property for Optional Field Description 
            /// </summary>
            public const string OptionalFieldDescription = "FDESC";

            /// <summary>
            /// Property for Value Description 
            /// </summary>
            public const string ValueDescription = "VDESC";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of National Account Optional Field Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for National Account 
            /// </summary>
            public const int NationalAccount = 1;

            /// <summary>
            /// Property Indexer for Optional Field 
            /// </summary>
            public const int OptionalField = 2;

            /// <summary>
            /// Property Indexer for Value 
            /// </summary>
            public const int Value = 3;

            /// <summary>
            /// Property Indexer for Type 
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for Length 
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Property Indexer for Decimals 
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Property Indexer for Allow Blank 
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Property Indexer for Validate 
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Property Indexer for Value Set 
            /// </summary>
            public const int ValueSet = 9;

            /// <summary>
            /// Property Indexer for Typed Value Field Index 
            /// </summary>
            public const int TypedValueFieldIndex = 20;

            /// <summary>
            /// Property Indexer for Text Value 
            /// </summary>
            public const int TextValue = 21;

            /// <summary>
            /// Property Indexer for Amount Value 
            /// </summary>
            public const int AmountValue = 22;

            /// <summary>
            /// Property Indexer for Number Value 
            /// </summary>
            public const int NumberValue = 23;

            /// <summary>
            /// Property Indexer for Integer Value 
            /// </summary>
            public const int IntegerValue = 24;

            /// <summary>
            /// Property Indexer for Yes Or No Value 
            /// </summary>
            public const int YesOrNoValue = 25;

            /// <summary>
            /// Property Indexer for Date Value 
            /// </summary>
            public const int DateValue = 26;

            /// <summary>
            /// Property Indexer for Time Value 
            /// </summary>
            public const int TimeValue = 27;

            /// <summary>
            /// Property Indexer for Optional Field Description 
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Property Indexer for Value Description 
            /// </summary>
            public const int ValueDescription = 29;

            #endregion
        }

        #endregion
    }
}