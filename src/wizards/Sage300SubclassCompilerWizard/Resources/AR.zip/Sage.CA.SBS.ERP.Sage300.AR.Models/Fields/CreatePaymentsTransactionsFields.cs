// Copyright (c) 2020 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.AR.Models.Process
{
    /// <summary>
    /// Contains list of CreatePaymentsTransactions Constants
    /// </summary>
    public partial class CreatePaymentsTransactions
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AR0215";

        #region Properties

        /// <summary>
        /// Contains list of CreatePaymentsTransactions Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for BatchNumber
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for PassARIBH
            /// </summary>
            public const string PassARIBH = "PASSARIBH";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of CreatePaymentsTransactions Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 1;

            /// <summary>
            /// Property for BatchNumber
            /// </summary>
            public const int BatchNumber = 2;

            /// <summary>
            /// Property for PassARIBH
            /// </summary>
            public const int PassARIBH = 3;

        }

        #endregion

    }
}
