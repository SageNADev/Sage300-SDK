﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Field-name, field-index and entity constants for business entity Receipts/Adjustments (rotoview AR0042 - ARTCR).
    /// </summary>
    public partial class ReceiptAdjustmentHeader
    {
        #region Entity

        /// <summary>
        /// The Roto ID of the underlying view (AR0042).
        /// </summary>
        /// <remarks>
        /// The name of the underlying view is ARTCR.
        /// </remarks>
        public const string EntityName = "AR0042";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of ReceiptsAdjustments Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "CODEPYMTYP";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";

            /// <summary>
            /// Property for CheckOrReceiptNo 
            /// </summary>
            public const string CheckOrReceiptNo = "IDRMIT";

            /// <summary>
            /// Property for CustomerNumber 
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for ReceiptDateOrAdjustmentDate 
            /// </summary>
            public const string ReceiptDateOrAdjustmentDate = "DATERMIT";

            /// <summary>
            /// Property for EntryDescription 
            /// </summary>
            public const string EntryDescription = "TEXTRMIT";

            /// <summary>
            /// Property for EntryReference 
            /// </summary>
            public const string EntryReference = "TXTRMITREF";

            /// <summary>
            /// Property for BankReceiptAmount 
            /// </summary>
            public const string BankReceiptAmount = "AMTRMIT";

            /// <summary>
            /// Property for CustReceiptAmount 
            /// </summary>
            public const string CustReceiptAmount = "AMTRMITTC";

            /// <summary>
            /// Property for CustExchangeRate 
            /// </summary>
            public const string CustExchangeRate = "RATEEXCHTC";

            /// <summary>
            /// Property for CustRateOverridden 
            /// </summary>
            public const string CustRateOverridden = "SWRATETC";

            /// <summary>
            /// Property for NumberofDocumentsAppliedto 
            /// </summary>
            public const string NumberofDocumentsAppliedto = "CNTPAYMETR";

            /// <summary>
            /// Property for TotalCustAmountApplied 
            /// </summary>
            public const string TotalCustAmountApplied = "AMTPAYMTC";

            /// <summary>
            /// Property for TotalCustDiscountAmount 
            /// </summary>
            public const string TotalCustDiscountAmount = "AMTDISCTC";

            /// <summary>
            /// Property for PaymentCode 
            /// </summary>
            public const string PaymentCode = "CODEPAYM";

            /// <summary>
            /// Property for CustomerCurrencyCode 
            /// </summary>
            public const string CustomerCurrencyCode = "CODECURN";

            /// <summary>
            /// Property for BankRateType 
            /// </summary>
            public const string BankRateType = "RATETYPEHC";

            /// <summary>
            /// Property for BankExchangeRate 
            /// </summary>
            public const string BankExchangeRate = "RATEEXCHHC";

            /// <summary>
            /// Property for BankRateOverridden 
            /// </summary>
            public const string BankRateOverridden = "SWRATEHC";

            /// <summary>
            /// Property for ReceiptTransType 
            /// </summary>
            public const string ReceiptTransType = "RMITTYPE";

            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "DOCTYPE";

            /// <summary>
            /// Property for MatchingDocumentNumber 
            /// </summary>
            public const string MatchingDocumentNumber = "IDINVCMTCH";

            /// <summary>
            /// Property for LastLineNumber 
            /// </summary>
            public const string LastLineNumber = "CNTLSTLINE";

            /// <summary>
            /// Property for FiscalYear 
            /// </summary>
            public const string FiscalYear = "FISCYR";

            /// <summary>
            /// Property for FiscalPeriod 
            /// </summary>
            public const string FiscalPeriod = "FISCPER";

            /// <summary>
            /// Property for Payer 
            /// </summary>
            public const string Payer = "TEXTPAYOR";

            /// <summary>
            /// Property for CustRateDate 
            /// </summary>
            public const string CustRateDate = "DATERATETC";

            /// <summary>
            /// Property for CustRateType 
            /// </summary>
            public const string CustRateType = "RATETYPETC";

            /// <summary>
            /// Property for CustAdjustmentAmount 
            /// </summary>
            public const string CustAdjustmentAmount = "AMTADJENT";

            /// <summary>
            /// Property for BankRateDate 
            /// </summary>
            public const string BankRateDate = "DATERATEHC";

            /// <summary>
            /// Property for PaymentType 
            /// </summary>
            public const string PaymentType = "PAYMTYPE";

            /// <summary>
            /// Property for CustUnappliedAmount 
            /// </summary>
            public const string CustUnappliedAmount = "REMUNAPLTC";

            /// <summary>
            /// Property for BankUnappliedAmount 
            /// </summary>
            public const string BankUnappliedAmount = "REMUNAPL";

            /// <summary>
            /// Property for FuncReceiptAmount 
            /// </summary>
            public const string FuncReceiptAmount = "AMTRMITHC";

            /// <summary>
            /// Property for DocumentNumber 
            /// </summary>
            public const string DocumentNumber = "DOCNBR";

            /// <summary>
            /// Property for FuncAdjustmentAmount 
            /// </summary>
            public const string FuncAdjustmentAmount = "AMTADJHC";

            /// <summary>
            /// Property for BankRateOperator 
            /// </summary>
            public const string BankRateOperator = "OPERBANK";

            /// <summary>
            /// Property for CustomerRateOperator 
            /// </summary>
            public const string CustomerRateOperator = "OPERCUST";

            /// <summary>
            /// Property for TotalFuncDiscountAmount 
            /// </summary>
            public const string TotalFuncDiscountAmount = "AMTDISCHC";

            /// <summary>
            /// Property for TotalFuncDebitAmount 
            /// </summary>
            public const string TotalFuncDebitAmount = "AMTDBADJHC";

            /// <summary>
            /// Property for TotalFuncCreditAmount 
            /// </summary>
            public const string TotalFuncCreditAmount = "AMTCRADJHC";

            /// <summary>
            /// Property for TotalCustDebitAmount 
            /// </summary>
            public const string TotalCustDebitAmount = "AMTDBADJTC";

            /// <summary>
            /// Property for TotalCustCreditAmount 
            /// </summary>
            public const string TotalCustCreditAmount = "AMTCRADJTC";

            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for JobApplyMethod 
            /// </summary>
            public const string JobApplyMethod = "APPLYMETH";

            /// <summary>
            /// Property for ErrorBatch 
            /// </summary>
            public const string ErrorBatch = "ERRBATCH";

            /// <summary>
            /// Property for ErrorEntry 
            /// </summary>
            public const string ErrorEntry = "ERRENTRY";

            /// <summary>
            /// Property for OptionalFields 
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";

            /// <summary>
            /// Property for BankCurrencyCode 
            /// </summary>
            public const string BankCurrencyCode = "CODECURNBC";

            /// <summary>
            /// Property for DrillDownApplicationSource 
            /// </summary>
            public const string DrillDownApplicationSource = "DRILLAPP";

            /// <summary>
            /// Property for DrillDownType 
            /// </summary>
            public const string DrillDownType = "DRILLTYPE";

            /// <summary>
            /// Property for DrillDownLinkNumber 
            /// </summary>
            public const string DrillDownLinkNumber = "DRILLDWNLK";

            /// <summary>
            /// Property for ReceiptPrinted 
            /// </summary>
            public const string ReceiptPrinted = "SWPRINTED";

            /// <summary>
            /// Property for ReceiptPrintedString 
            /// </summary>
            public const string ReceiptPrintedString = "SWPRINTED";

            /// <summary>
            /// Property for CalculateTax 
            /// </summary>
            public const string CalculateTax = "SWTXAMTCTL";

            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";

            /// <summary>
            /// Property for TaxStateVersion 
            /// </summary>
            public const string TaxStateVersion = "TAXVERSION";

            /// <summary>
            /// Property for TaxAuthority1 
            /// </summary>
            public const string TaxAuthority1 = "CODETAX1";

            /// <summary>
            /// Property for TaxAuthority2 
            /// </summary>
            public const string TaxAuthority2 = "CODETAX2";

            /// <summary>
            /// Property for TaxAuthority3 
            /// </summary>
            public const string TaxAuthority3 = "CODETAX3";

            /// <summary>
            /// Property for TaxAuthority4 
            /// </summary>
            public const string TaxAuthority4 = "CODETAX4";

            /// <summary>
            /// Property for TaxAuthority5 
            /// </summary>
            public const string TaxAuthority5 = "CODETAX5";

            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "TXBSE1TC";

            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "TXBSE2TC";

            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "TXBSE3TC";

            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "TXBSE4TC";

            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "TXBSE5TC";

            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "TXAMT1TC";

            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "TXAMT2TC";

            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "TXAMT3TC";

            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "TXAMT4TC";

            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "TXAMT5TC";

            /// <summary>
            /// Property for TaxTotal 
            /// </summary>
            public const string TaxTotal = "TXTOTTC";

            /// <summary>
            /// Property for DistAmountNetofTaxes 
            /// </summary>
            public const string DistAmountNetofTaxes = "AMTNETTC";

            /// <summary>
            /// Property for DepositSerialNumber 
            /// </summary>
            public const string DepositSerialNumber = "DEPSEQ";

            /// <summary>
            /// Property for DepositLineNumber 
            /// </summary>
            public const string DepositLineNumber = "DEPLINE";

            /// <summary>
            /// Property for TaxReportingCurrencyCode 
            /// </summary>
            public const string TaxReportingCurrencyCode = "CODECURNRC";

            /// <summary>
            /// Property for TaxReportingCalculateMethod 
            /// </summary>
            public const string TaxReportingCalculateMethod = "SWTXCTLRC";

            /// <summary>
            /// Property for TaxReportingExchangeRate 
            /// </summary>
            public const string TaxReportingExchangeRate = "RATERC";

            /// <summary>
            /// Property for TaxReportingRateType 
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";

            /// <summary>
            /// Property for TaxReportingRateDate 
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";

            /// <summary>
            /// Property for TaxReportingRateOperator 
            /// </summary>
            public const string TaxReportingRateOperator = "RATEOPRC";

            /// <summary>
            /// Property for TaxReportingRateOverride 
            /// </summary>
            public const string TaxReportingRateOverride = "SWRATERC";

            /// <summary>
            /// Property for TaxReportingAmount1 
            /// </summary>
            public const string TaxReportingAmount1 = "TXAMT1RC";

            /// <summary>
            /// Property for TaxReportingAmount2 
            /// </summary>
            public const string TaxReportingAmount2 = "TXAMT2RC";

            /// <summary>
            /// Property for TaxReportingAmount3 
            /// </summary>
            public const string TaxReportingAmount3 = "TXAMT3RC";

            /// <summary>
            /// Property for TaxReportingAmount4 
            /// </summary>
            public const string TaxReportingAmount4 = "TXAMT4RC";

            /// <summary>
            /// Property for TaxReportingAmount5 
            /// </summary>
            public const string TaxReportingAmount5 = "TXAMT5RC";

            /// <summary>
            /// Property for TaxReportingTotal 
            /// </summary>
            public const string TaxReportingTotal = "TXTOTRC";

            /// <summary>
            /// Property for NumberofAdvanceCreditClaims 
            /// </summary>
            public const string NumberofAdvanceCreditClaims = "CNTACC";

            /// <summary>
            /// Property for TotalAdvanceCreditClaim 
            /// </summary>
            public const string TotalAdvanceCreditClaim = "AMTACCTC";

            /// <summary>
            /// Property for FuncTotalAdvanceCreditClaim 
            /// </summary>
            public const string FuncTotalAdvanceCreditClaim = "AMTACCHC";

            /// <summary>
            /// Property for FuncTotalCustAmountApplied 
            /// </summary>
            public const string FuncTotalCustAmountApplied = "AMTPAYMHC";

            /// <summary>
            /// Property for FuncCustUnappliedAmount 
            /// </summary>
            public const string FuncCustUnappliedAmount = "REMUNAPLHC";

            /// <summary>
            /// Property for FuncTaxBase1 
            /// </summary>
            public const string FuncTaxBase1 = "TXBSE1HC";

            /// <summary>
            /// Property for FuncTaxBase2 
            /// </summary>
            public const string FuncTaxBase2 = "TXBSE2HC";

            /// <summary>
            /// Property for FuncTaxBase3 
            /// </summary>
            public const string FuncTaxBase3 = "TXBSE3HC";

            /// <summary>
            /// Property for FuncTaxBase4 
            /// </summary>
            public const string FuncTaxBase4 = "TXBSE4HC";

            /// <summary>
            /// Property for FuncTaxBase5 
            /// </summary>
            public const string FuncTaxBase5 = "TXBSE5HC";

            /// <summary>
            /// Property for FuncTaxAmount1 
            /// </summary>
            public const string FuncTaxAmount1 = "TXAMT1HC";

            /// <summary>
            /// Property for FuncTaxAmount2 
            /// </summary>
            public const string FuncTaxAmount2 = "TXAMT2HC";

            /// <summary>
            /// Property for FuncTaxAmount3 
            /// </summary>
            public const string FuncTaxAmount3 = "TXAMT3HC";

            /// <summary>
            /// Property for FuncTaxAmount4 
            /// </summary>
            public const string FuncTaxAmount4 = "TXAMT4HC";

            /// <summary>
            /// Property for FuncTaxAmount5 
            /// </summary>
            public const string FuncTaxAmount5 = "TXAMT5HC";

            /// <summary>
            /// Property for FuncTaxTotal 
            /// </summary>
            public const string FuncTaxTotal = "TXTOTHC";

            /// <summary>
            /// Property for FuncDistAmountNetofTaxes 
            /// </summary>
            public const string FuncDistAmountNetofTaxes = "AMTNETHC";

            /// <summary>
            /// Property for A/RVersionCreatedIn 
            /// </summary>
            public const string AorRVersionCreatedIn = "ARVERSION";

            /// <summary>
            /// Property for EnteredBy 
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for PostingDate 
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for AccountSet 
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            /// <summary>
            /// Property for PreviousCCTransactionNumber 
            /// </summary>
            public const string PreviousCcTransactionNumber = "CCPREVID";

            /// <summary>
            /// Property for PreviousCCProcessStatus 
            /// </summary>
            public const string PreviousCcProcessStatus = "CCPREVSTTS";

            /// <summary>
            /// Property for CurrentCCTransactionNumber 
            /// </summary>
            public const string CurrentCcTransactionNumber = "CCTRANID";

            /// <summary>
            /// Property for CurrentCCProcessStatus 
            /// </summary>
            public const string CurrentCcProcessStatus = "CCTRANSTTS";

            /// <summary>
            /// Property for ProcessingCode 
            /// </summary>
            public const string ProcessingCode = "PROCESSCODE";

            /// <summary>
            /// Property for transaction ID 
            /// </summary>
            public const string TransID = "TRANSID";

            /// <summary>
            /// Property for XML String
            /// </summary>
            public const string XmlString = "XMLSTRING";

            /// <summary>
            /// Property for Response Indicator 
            /// </summary>
            public const string ResponseIndicator = "RESPIND";

            /// <summary>
            /// Property for Response Code
            /// </summary>
            public const string ResponseCode = "RESPCD";

            /// <summary>
            /// Property for Response Message 
            /// </summary>
            public const string ResponseMessage = "RESPMSG";

            /// <summary>
            /// Property for Authorization Code
            /// </summary>
            public const string AuthorizationCode = "AUTHCODE";

            /// <summary>
            /// Property for AVSResult 
            /// </summary>
            public const string AVSResult = "AVSRESULT";

            /// <summary>
            /// Property for CVVResult
            /// </summary>
            public const string CVVResult = "CVVRESULT";

            /// <summary>
            /// Property for Transaction Date
            /// </summary>
            public const string Transdate = "TRANSDATE";

            /// <summary>
            /// Property for VAN Reference 
            /// </summary>
            public const string Vanref = "VANREF";

            /// <summary>
            /// Property for Last 4
            /// </summary>
            public const string Last4 = "LAST4";

            /// <summary>
            /// Property for Payment Description
            /// </summary>
            public const string PmtDesc = "PMTDESC";

            /// <summary>
            /// Property for Payment Type ID 
            /// </summary>
            public const string PmtTypeID = "PMTTYPEID";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHT1TC = "AMTWHT1TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHT2TC = "AMTWHT2TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHT3TC = "AMTWHT3TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHT4TC = "AMTWHT4TC";

            /// <summary>
            /// Property for Estimated Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHT5TC = "AMTWHT5TC";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of ReceiptsAdjustments Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;

            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;

            /// <summary>
            /// Property Indexer for CheckOrReceiptNo 
            /// </summary>
            public const int CheckOrReceiptNo = 4;

            /// <summary>
            /// Property Indexer for CustomerNumber 
            /// </summary>
            public const int CustomerNumber = 5;

            /// <summary>
            /// Property Indexer for ReceiptDateOrAdjustmentDate 
            /// </summary>
            public const int ReceiptDateOrAdjustmentDate = 6;

            /// <summary>
            /// Property Indexer for EntryDescription 
            /// </summary>
            public const int EntryDescription = 7;

            /// <summary>
            /// Property Indexer for EntryReference 
            /// </summary>
            public const int EntryReference = 8;

            /// <summary>
            /// Property Indexer for BankReceiptAmount 
            /// </summary>
            public const int BankReceiptAmount = 9;

            /// <summary>
            /// Property Indexer for CustReceiptAmount 
            /// </summary>
            public const int CustReceiptAmount = 10;

            /// <summary>
            /// Property Indexer for CustExchangeRate 
            /// </summary>
            public const int CustExchangeRate = 11;

            /// <summary>
            /// Property Indexer for CustRateOverridden 
            /// </summary>
            public const int CustRateOverridden = 12;

            /// <summary>
            /// Property Indexer for NumberofDocumentsAppliedto 
            /// </summary>
            public const int NumberofDocumentsAppliedto = 13;

            /// <summary>
            /// Property Indexer for TotalCustAmountApplied 
            /// </summary>
            public const int TotalCustAmountApplied = 14;

            /// <summary>
            /// Property Indexer for TotalCustDiscountAmount 
            /// </summary>
            public const int TotalCustDiscountAmount = 15;

            /// <summary>
            /// Property Indexer for PaymentCode 
            /// </summary>
            public const int PaymentCode = 16;

            /// <summary>
            /// Property Indexer for CustomerCurrencyCode 
            /// </summary>
            public const int CustomerCurrencyCode = 17;

            /// <summary>
            /// Property Indexer for BankRateType 
            /// </summary>
            public const int BankRateType = 18;

            /// <summary>
            /// Property Indexer for BankExchangeRate 
            /// </summary>
            public const int BankExchangeRate = 19;

            /// <summary>
            /// Property Indexer for BankRateOverridden 
            /// </summary>
            public const int BankRateOverridden = 20;

            /// <summary>
            /// Property Indexer for ReceiptTransType 
            /// </summary>
            public const int ReceiptTransType = 21;

            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 22;

            /// <summary>
            /// Property Indexer for MatchingDocumentNumber 
            /// </summary>
            public const int MatchingDocumentNumber = 25;

            /// <summary>
            /// Property Indexer for LastLineNumber 
            /// </summary>
            public const int LastLineNumber = 30;

            /// <summary>
            /// Property Indexer for FiscalYear 
            /// </summary>
            public const int FiscalYear = 31;

            /// <summary>
            /// Property Indexer for FiscalPeriod 
            /// </summary>
            public const int FiscalPeriod = 32;

            /// <summary>
            /// Property Indexer for Payer 
            /// </summary>
            public const int Payer = 33;

            /// <summary>
            /// Property Indexer for CustRateDate 
            /// </summary>
            public const int CustRateDate = 34;

            /// <summary>
            /// Property Indexer for CustRateType 
            /// </summary>
            public const int CustRateType = 35;

            /// <summary>
            /// Property Indexer for CustAdjustmentAmount 
            /// </summary>
            public const int CustAdjustmentAmount = 36;

            /// <summary>
            /// Property Indexer for BankRateDate 
            /// </summary>
            public const int BankRateDate = 37;

            /// <summary>
            /// Property Indexer for PaymentType 
            /// </summary>
            public const int PaymentType = 38;

            /// <summary>
            /// Property Indexer for CustUnappliedAmount 
            /// </summary>
            public const int CustUnappliedAmount = 39;

            /// <summary>
            /// Property Indexer for BankUnappliedAmount 
            /// </summary>
            public const int BankUnappliedAmount = 40;

            /// <summary>
            /// Property Indexer for FuncReceiptAmount 
            /// </summary>
            public const int FuncReceiptAmount = 41;

            /// <summary>
            /// Property Indexer for DocumentNumber 
            /// </summary>
            public const int DocumentNumber = 42;

            /// <summary>
            /// Property Indexer for FuncAdjustmentAmount 
            /// </summary>
            public const int FuncAdjustmentAmount = 43;

            /// <summary>
            /// Property Indexer for BankRateOperator 
            /// </summary>
            public const int BankRateOperator = 44;

            /// <summary>
            /// Property Indexer for CustomerRateOperator 
            /// </summary>
            public const int CustomerRateOperator = 45;

            /// <summary>
            /// Property Indexer for TotalFuncDiscountAmount 
            /// </summary>
            public const int TotalFuncDiscountAmount = 46;

            /// <summary>
            /// Property Indexer for TotalFuncDebitAmount 
            /// </summary>
            public const int TotalFuncDebitAmount = 47;

            /// <summary>
            /// Property Indexer for TotalFuncCreditAmount 
            /// </summary>
            public const int TotalFuncCreditAmount = 48;

            /// <summary>
            /// Property Indexer for TotalCustDebitAmount 
            /// </summary>
            public const int TotalCustDebitAmount = 49;

            /// <summary>
            /// Property Indexer for TotalCustCreditAmount 
            /// </summary>
            public const int TotalCustCreditAmount = 50;

            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 51;

            /// <summary>
            /// Property Indexer for JobApplyMethod 
            /// </summary>
            public const int JobApplyMethod = 52;

            /// <summary>
            /// Property Indexer for ErrorBatch 
            /// </summary>
            public const int ErrorBatch = 53;

            /// <summary>
            /// Property Indexer for ErrorEntry 
            /// </summary>
            public const int ErrorEntry = 54;

            /// <summary>
            /// Property Indexer for OptionalFields 
            /// </summary>
            public const int OptionalFields = 55;

            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 56;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 57;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 58;

            /// <summary>
            /// Property Indexer for BankCurrencyCode 
            /// </summary>
            public const int BankCurrencyCode = 59;

            /// <summary>
            /// Property Indexer for DrillDownApplicationSource 
            /// </summary>
            public const int DrillDownApplicationSource = 65;

            /// <summary>
            /// Property Indexer for DrillDownType 
            /// </summary>
            public const int DrillDownType = 66;

            /// <summary>
            /// Property Indexer for DrillDownLinkNumber 
            /// </summary>
            public const int DrillDownLinkNumber = 67;

            /// <summary>
            /// Property Indexer for ReceiptPrinted 
            /// </summary>
            public const int ReceiptPrinted = 68;

            /// <summary>
            /// Property Indexer for CalculateTax 
            /// </summary>
            public const int CalculateTax = 69;

            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 70;

            /// <summary>
            /// Property Indexer for TaxStateVersion 
            /// </summary>
            public const int TaxStateVersion = 71;

            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 72;

            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 73;

            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 74;

            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 75;

            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 76;

            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 77;

            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 78;

            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 79;

            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 80;

            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 81;

            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 82;

            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 83;

            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 84;

            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 85;

            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 86;

            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 87;

            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 88;

            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 89;

            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 90;

            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 91;

            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 92;

            /// <summary>
            /// Property Indexer for DistAmountNetofTaxes 
            /// </summary>
            public const int DistAmountNetofTaxes = 93;

            /// <summary>
            /// Property Indexer for DepositSerialNumber 
            /// </summary>
            public const int DepositSerialNumber = 94;

            /// <summary>
            /// Property Indexer for DepositLineNumber 
            /// </summary>
            public const int DepositLineNumber = 95;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyCode 
            /// </summary>
            public const int TaxReportingCurrencyCode = 96;

            /// <summary>
            /// Property Indexer for TaxReportingCalculateMethod 
            /// </summary>
            public const int TaxReportingCalculateMethod = 97;

            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate 
            /// </summary>
            public const int TaxReportingExchangeRate = 98;

            /// <summary>
            /// Property Indexer for TaxReportingRateType 
            /// </summary>
            public const int TaxReportingRateType = 99;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate 
            /// </summary>
            public const int TaxReportingRateDate = 100;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperator 
            /// </summary>
            public const int TaxReportingRateOperator = 101;

            /// <summary>
            /// Property Indexer for TaxReportingRateOverride 
            /// </summary>
            public const int TaxReportingRateOverride = 102;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 103;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 104;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 105;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 106;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 107;

            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 108;

            /// <summary>
            /// Property Indexer for NumberofAdvanceCreditClaims 
            /// </summary>
            public const int NumberofAdvanceCreditClaims = 110;

            /// <summary>
            /// Property Indexer for TotalAdvanceCreditClaim 
            /// </summary>
            public const int TotalAdvanceCreditClaim = 111;

            /// <summary>
            /// Property Indexer for FuncTotalAdvanceCreditClaim 
            /// </summary>
            public const int FuncTotalAdvanceCreditClaim = 112;

            /// <summary>
            /// Property Indexer for FuncTotalCustAmountApplied 
            /// </summary>
            public const int FuncTotalCustAmountApplied = 113;

            /// <summary>
            /// Property Indexer for FuncCustUnappliedAmount 
            /// </summary>
            public const int FuncCustUnappliedAmount = 114;

            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 115;

            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 116;

            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 117;

            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 118;

            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 119;

            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 120;

            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 121;

            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 122;

            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 123;

            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 124;

            /// <summary>
            /// Property Indexer for FuncTaxTotal 
            /// </summary>
            public const int FuncTaxTotal = 125;

            /// <summary>
            /// Property Indexer for FuncDistAmountNetofTaxes 
            /// </summary>
            public const int FuncDistAmountNetofTaxes = 126;

            /// <summary>
            /// Property Indexer for A/RVersionCreatedIn 
            /// </summary>
            public const int AorRVersionCreatedIn = 127;

            /// <summary>
            /// Property Indexer for EnteredBy 
            /// </summary>
            public const int EnteredBy = 128;

            /// <summary>
            /// Property Indexer for PostingDate 
            /// </summary>
            public const int PostingDate = 129;

            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 130;

            /// <summary>
            /// Property Indexer for PreviousCCTransactionNumber 
            /// </summary>
            public const int PreviousCcTransactionNumber = 131;

            /// <summary>
            /// Property Indexer for PreviousCCProcessStatus 
            /// </summary>
            public const int PreviousCcProcessStatus = 132;

            /// <summary>
            /// Property Indexer for CurrentCCTransactionNumber 
            /// </summary>
            public const int CurrentCcTransactionNumber = 133;

            /// <summary>
            /// Property Indexer for CurrentCCProcessStatus 
            /// </summary>
            public const int CurrentCcProcessStatus = 134;

            /// <summary>
            /// Property Indexer for ProcessingCode 
            /// </summary>
            public const int ProcessingCode = 135;

            /// <summary>
            /// Property Indexer for the quick pre-auth/charge transaction ID
            /// </summary>
            public const int TransID = 136;

            /// <summary>
            /// Property Indexer for XML String for Quick Charge/Pre-Authorization
            /// </summary>
            public const int XmlString = 137;

            /// <summary>
            /// Property Indexer for Respond Indicator
            /// </summary>
            public const int ResponseIndicator = 138;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int ResponseCode = 139;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int ResponseMessage = 140;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int AuthorizationCode = 141;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int AVSResult = 142;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int CVVResult = 143;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int Transdate = 144;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int Vanref = 145;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int Last4 = 146;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int PmtDesc = 147;

            /// <summary>
            /// Property Indexer for 
            /// </summary>
            public const int PmtTypeID = 148;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHT1TC = 149;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHT2TC = 150;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHT3TC = 151;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHT4TC = 152;

            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHT5TC = 153;

           #endregion
        }

        #endregion
    }
}