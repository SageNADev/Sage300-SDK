/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of AccountSets Constants 
    /// </summary>
    public partial class AccountSet
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0013";

        /// <summary>
        /// Contains list of AccountSets Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for AccountSet 
            /// </summary>
            public const string AccountSetCode = "IDACCTSET";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "ACTVSW";
            /// <summary>
            /// Property for StatusString
            /// Added for Finder filter
            /// </summary>
            public const string StatusString = "ACTVSW";
            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEAINAC";
            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "LASTMNTN";
            /// <summary>
            /// Property for ReceivablesControlAccount 
            /// </summary>
            public const string ReceivablesControlAccount = "ARIDACCT";

            /// <summary>
            /// Property for PrepaymentLiabilityAccount 
            /// </summary>
            public const string PrepaymentLiabilityAccount = "CASHLIAB";
            /// <summary>
            /// Property for DiscountsAccount 
            /// </summary>
            public const string DiscountsAccount = "ACCTDISC";
            /// <summary>
            /// Property for WriteOffsAccount 
            /// </summary>
            public const string WriteOffsAccount = "ACCTWROF";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CURNCODE";
            /// <summary>
            /// Property for UnrealizedExchangeGainAccount 
            /// </summary>
            public const string UnrealizedExchangeGainAccount = "UNRLGAIN";
            /// <summary>
            /// Property for UnrealizedExchangeLossAccount 
            /// </summary>
            public const string UnrealizedExchangeLossAccount = "UNRLLOSS";
            /// <summary>
            /// Property for ExchangeGainAccount 
            /// </summary>
            public const string ExchangeGainAccount = "RLZDGAIN";
            /// <summary>
            /// Property for ExchangeLossAccount 
            /// </summary>
            public const string ExchangeLossAccount = "RLZDLOSS";

            /// <summary>
            /// Property for RetainageAccount 
            /// </summary>
            public const string RetainageAccount = "RTGACCT";
            /// <summary>
            /// Property for ExchangeRoundingAccount 
            /// </summary>
            public const string ExchangeRoundingAccount = "RNDACCT";

            #endregion
        }


        /// <summary>
        /// Contains list of AccountSets Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSetCode = 1;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 2;
            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 3;
            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 4;
            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 5;
            /// <summary>
            /// Property Indexer for ReceivablesControlAccount 
            /// </summary>
            public const int ReceivablesControlAccount = 6;

            /// <summary>
            /// Property Indexer for PrepaymentLiabilityAccount 
            /// </summary>
            public const int PrepaymentLiabilityAccount = 8;
            /// <summary>
            /// Property Indexer for DiscountsAccount 
            /// </summary>
            public const int DiscountsAccount = 9;
            /// <summary>
            /// Property Indexer for WriteOffsAccount 
            /// </summary>
            public const int WriteOffsAccount = 10;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 11;
            /// <summary>
            /// Property Indexer for UnrealizedExchangeGainAccount 
            /// </summary>
            public const int UnrealizedExchangeGainAccount = 12;
            /// <summary>
            /// Property Indexer for UnrealizedExchangeLossAccount 
            /// </summary>
            public const int UnrealizedExchangeLossAccount = 13;
            /// <summary>
            /// Property Indexer for ExchangeGainAccount 
            /// </summary>
            public const int ExchangeGainAccount = 14;
            /// <summary>
            /// Property Indexer for ExchangeLossAccount 
            /// </summary>
            public const int ExchangeLossAccount = 15;

            /// <summary>
            /// Property Indexer for RetainageAccount 
            /// </summary>
            public const int RetainageAccount = 17;
            /// <summary>
            /// Property Indexer for ExchangeRoundingAccount 
            /// </summary>
            public const int ExchangeRoundingAccount = 18;

            #endregion
        }


    }
}
