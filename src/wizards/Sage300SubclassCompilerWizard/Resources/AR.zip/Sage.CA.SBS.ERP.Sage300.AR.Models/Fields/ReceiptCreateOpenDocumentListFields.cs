/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CreateOpenDocumentList Constants 
    /// </summary>
    public partial class ReceiptCreateOpenDocumentDetail
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0061";

        /// <summary>
        /// Contains list of CreateOpenDocumentList Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "PAYMTYPE";
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";
            /// <summary>
            /// Property for Countkey 
            /// </summary>
            public const string Countkey = "CNTKEY";
            /// <summary>
            /// Property for Countpaymentsscheduled 
            /// </summary>
            public const string Countpaymentsscheduled = "PAYMSCHD";
            /// <summary>
            /// Property for ProcessType 
            /// </summary>
            public const string ProcessType = "PROTYPE";
            /// <summary>
            /// Property for ShowType 
            /// </summary>
            public const string ShowType = "SHOWTYPE";
            /// <summary>
            /// Property for OrderBy 
            /// </summary>
            public const string OrderBy = "ORDERBY";
            /// <summary>
            /// Property for IDCustomer 
            /// </summary>
            public const string IDCustomer = "IDCUST";
            /// <summary>
            /// Property for IDInvc 
            /// </summary>
            public const string IDInvc = "IDINVC";
            /// <summary>
            /// Property for ReceiptID 
            /// </summary>
            public const string ReceiptID = "IDRMIT";
            /// <summary>
            /// Property for PONumber 
            /// </summary>
            public const string PoNumber = "CUSTPO";
            /// <summary>   
            /// Property for OrderNumber 
            /// </summary>
            public const string OrderNumber = "ORDRNBR";
            /// <summary>
            /// Property for ShipmentNumber 
            /// </summary>
            public const string ShipmentNumber = "IDSHIPNBR";
            /// <summary>
            /// Property for Texttransactiontype 
            /// </summary>
            public const string Texttransactiontype = "TRXTYPE";
            /// <summary>
            /// Property for DueDate 
            /// </summary>
            public const string DueDate = "DATEDUE";
            /// <summary>
            /// Property for Discountdate 
            /// </summary>
            public const string Discountdate = "DATEDISC";
            /// <summary>
            /// Property for Invoicedate 
            /// </summary>
            public const string Invoicedate = "DATEINVC";
            /// <summary>
            /// Property for PaymentAmountDue 
            /// </summary>
            public const string PaymentAmountDue = "AMTDUE";
            /// <summary>
            /// Property for PaymentAmountNet 
            /// </summary>
            public const string PaymentAmountNet = "AMTNET";
            /// <summary>
            /// Property for PaymentAmountDiscount 
            /// </summary>
            public const string PaymentAmountDiscount = "AMTDISC";

            /// <summary>
            /// Property for PAYMAMT 
            /// </summary>
            public const string PayAmount = "PAYMAMT";
            /// <summary>
            /// Property for DiscountTakenAmount 
            /// </summary>
            public const string DiscountTakenAmount = "DISCAMT";
            /// <summary>
            /// Property for Apply 
            /// </summary>
            public const string Apply = "APPLY";
            /// <summary>
            /// Property for TextTransactionTypeId 
            /// </summary>
            public const string TextTransactionTypeId = "IDTRXTYPE";
            /// <summary>
            /// Property for AdjustmentAmount 
            /// </summary>
            public const string AdjustmentAmount = "ADJAMT";
            /// <summary>
            /// Property for StartingDocNumber 
            /// </summary>
            public const string StartingDocNumber = "STDOCSTR";
            /// <summary>
            /// Property for StartingDate 
            /// </summary>
            public const string StartingDate = "STDOCDTE";
            /// <summary>
            /// Property for StartingAmount 
            /// </summary>
            public const string StartingAmount = "STDOCAMT";

            /// <summary>
            /// Property for AMTRMIT 
            /// </summary>
            public const string AmountRemit = "AMTRMIT";
            /// <summary>
            /// Property for PaymentDiscountAvailable 
            /// </summary>
            public const string PaymentDiscountAvailable = "OBSDISC";
            /// <summary>
            /// Property for TCPlinecount 
            /// </summary>
            public const string TcpLineCount = "TCPLINE";
            /// <summary>
            /// Property for StartingCustomerNo 
            /// </summary>
            public const string StartingCustomerNo = "STRTCUST";
            /// <summary>
            /// Property for OriginalApply 
            /// </summary>
            public const string OriginalApply = "ORIGAPLY";
            /// <summary>
            /// Property for PendingReceiptAmount 
            /// </summary>
            public const string PendingReceiptAmount = "PNDPAYTOT";
            /// <summary>
            /// Property for PendingDiscountAmount 
            /// </summary>
            public const string PendingDiscountAmount = "PNDDSCTOT";
            /// <summary>
            /// Property for PendingAdjustmentAmount 
            /// </summary>
            public const string PendingAdjustmentAmount = "PNDADJTOT";
            /// <summary>
            /// Property for PendingBalance 
            /// </summary>
            public const string PendingBalance = "PENDNGBAL";
            /// <summary>
            /// Property for OriginalDocumentAmount 
            /// </summary>
            public const string OriginalDocumentAmount = "ORGDOCAMT";
            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";
            /// <summary>
            /// Property for OriginalDocNo 
            /// </summary>
            public const string OriginalDocNo = "RTGAPPLYTO";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";
            /// <summary>
            /// Property for Reference 
            /// </summary>
            public const string Reference = "TEXTREF";


            /// <summary>
            /// Property For Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHD1TC = "AMTWHD1TC";

            /// <summary>
            /// Property For Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHD2TC = "AMTWHD2TC";

            /// <summary>
            /// Property For Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHD3TC = "AMTWHD3TC";

            /// <summary>
            /// Property For Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHD4TC = "AMTWHD4TC";

            /// <summary>
            /// Property For Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHD5TC = "AMTWHD5TC";

            /// <summary>
            /// Property For Tax Withheld Amount Total
            /// </summary>
            public const string AmtWHDTot = "AMTWHDTOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 1
            /// </summary>
            public const string PndWHD1Tot = "PNDWHD1TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 2
            /// </summary>
            public const string PndWHD2Tot = "PNDWHD2TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 3
            /// </summary>
            public const string PndWHD3Tot = "PNDWHD3TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 4
            /// </summary>
            public const string PndWHD4Tot = "PNDWHD4TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Amount 5
            /// </summary>
            public const string PndWHD5Tot = "PNDWHD5TOT";

            /// <summary>
            /// Property For Pending Tax Withheld Total
            /// </summary>
            public const string PndWHDTot = "PNDWHDTOT";

            /// <summary>
            /// Property For Document Tax Authority 1
            /// </summary>
            public const string CodeTax1 = "CODETAX1";

            /// <summary>
            /// Property For Document Tax Authority 2
            /// </summary>
            public const string CodeTax2 = "CODETAX2";

            /// <summary>
            /// Property For Document Tax Authority 3
            /// </summary>
            public const string CodeTax3 = "CODETAX3";

            /// <summary>
            /// Property For Document Tax Authority 4
            /// </summary>
            public const string CodeTax4 = "CODETAX4";

            /// <summary>
            /// Property For Document Tax Authority 5
            /// </summary>
            public const string CodeTax5 = "CODETAX5";

            /// <summary>
            /// Property For Tax Auth 1 Description
            /// </summary>
            public const string TaxAuth1Description = "TXAU1DESC";

            /// <summary>
            /// Property For Tax Auth 2 Description
            /// </summary>
            public const string TaxAuth2Description = "TXAU2DESC";

            /// <summary>
            /// Property For Tax Auth 3 Description
            /// </summary>
            public const string TaxAuth3Description = "TXAU3DESC";

            /// <summary>
            /// Property For Tax Auth 4 Description
            /// </summary>
            public const string TaxAuth4Description = "TXAU4DESC";

            /// <summary>
            /// Property For Tax Auth 5 Description
            /// </summary>
            public const string TaxAuth5Description = "TXAU5DESC";

            #endregion
        }


        /// <summary>
        /// Contains list of CreateOpenDocumentList Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for BatchType 
            /// </summary>
            public const int BatchType = 1;
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 3;
            /// <summary>
            /// Property Indexer for Countkey 
            /// </summary>
            public const int Countkey = 4;
            /// <summary>
            /// Property Indexer for Countpaymentsscheduled 
            /// </summary>
            public const int Countpaymentsscheduled = 5;
            /// <summary>
            /// Property Indexer for ProcessType 
            /// </summary>
            public const int ProcessType = 6;
            /// <summary>
            /// Property Indexer for ShowType 
            /// </summary>
            public const int ShowType = 7;
            /// <summary>
            /// Property Indexer for OrderBy 
            /// </summary>
            public const int OrderBy = 8;
            /// <summary>
            /// Property Indexer for IDCustomer 
            /// </summary>
            public const int IDCustomer = 9;
            /// <summary>
            /// Property Indexer for IDInvc 
            /// </summary>
            public const int IDInvc = 10;
            /// <summary>
            /// Property Indexer for ReceiptID 
            /// </summary>
            public const int ReceiptID = 11;
            /// <summary>
            /// Property Indexer for PONumber 
            /// </summary>  
            public const int PoNumber = 12;
            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 13;
            /// <summary>
            /// Property Indexer for ShipmentNumber 
            /// </summary>
            public const int ShipmentNumber = 14;
            /// <summary>
            /// Property Indexer for Texttransactiontype 
            /// </summary>
            public const int Texttransactiontype = 15;
            /// <summary>
            /// Property Indexer for DueDate 
            /// </summary>
            public const int DueDate = 16;
            /// <summary>
            /// Property Indexer for Discountdate 
            /// </summary>
            public const int Discountdate = 17;
            /// <summary>
            /// Property Indexer for Invoicedate 
            /// </summary>
            public const int Invoicedate = 18;
            /// <summary>
            /// Property Indexer for PaymentAmountDue 
            /// </summary>
            public const int PaymentAmountDue = 19;
            /// <summary>
            /// Property Indexer for PaymentAmountNet 
            /// </summary>
            public const int PaymentAmountNet = 20;
            /// <summary>
            /// Property Indexer for PaymentAmountDiscount 
            /// </summary>
            public const int PaymentAmountDiscount = 21;

            /// <summary>
            /// Property Indexer for PAYMAMT 
            /// </summary>
            public const int PayAmount = 22;
            /// <summary>
            /// Property Indexer for DiscountTakenAmount 
            /// </summary>
            public const int DiscountTakenAmount = 23;
            /// <summary>
            /// Property Indexer for Apply 
            /// </summary>
            public const int Apply = 24;
            /// <summary>
            /// Property Indexer for TextTransactionTypeId 
            /// </summary>
            public const int TextTransactionTypeId = 26;
            /// <summary>
            /// Property Indexer for AdjustmentAmount 
            /// </summary>
            public const int AdjustmentAmount = 27;
            /// <summary>
            /// Property Indexer for StartingDocNumber 
            /// </summary>
            public const int StartingDocNumber = 28;
            /// <summary>
            /// Property Indexer for StartingDate 
            /// </summary>
            public const int StartingDate = 29;
            /// <summary>
            /// Property Indexer for StartingAmount 
            /// </summary>
            public const int StartingAmount = 30;

            /// <summary>
            /// Property Indexer for AMTRMIT 
            /// </summary>
            public const int AmountRemit = 31;
            /// <summary>
            /// Property Indexer for PaymentDiscountAvailable 
            /// </summary>
            public const int PaymentDiscountAvailable = 32;
            /// <summary>
            /// Property Indexer for TCPlinecount 
            /// </summary>
            public const int TcpLineCount = 33; 
            /// <summary>
            /// Property Indexer for StartingCustomerNo 
            /// </summary>
            public const int StartingCustomerNo = 34;
            /// <summary>
            /// Property Indexer for OriginalApply 
            /// </summary>
            public const int OriginalApply = 35;
            /// <summary>
            /// Property Indexer for PendingReceiptAmount 
            /// </summary>
            public const int PendingReceiptAmount = 36;
            /// <summary>
            /// Property Indexer for PendingDiscountAmount 
            /// </summary>
            public const int PendingDiscountAmount = 37;
            /// <summary>
            /// Property Indexer for PendingAdjustmentAmount 
            /// </summary>
            public const int PendingAdjustmentAmount = 38;
            /// <summary>
            /// Property Indexer for PendingBalance 
            /// </summary>
            public const int PendingBalance = 39;
            /// <summary>
            /// Property Indexer for OriginalDocumentAmount 
            /// </summary>
            public const int OriginalDocumentAmount = 40;
            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 41;
            /// <summary>
            /// Property Indexer for OriginalDocNo 
            /// </summary>
            public const int OriginalDocNo = 42;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 43;
            /// <summary>
            /// Property Indexer for Reference 
            /// </summary>
            public const int Reference = 44;

            /// <summary>
            /// Indexer For Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHD1TC = 45;

            /// <summary>
            /// Indexer For Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHD2TC = 46;

            /// <summary>
            /// Indexer For Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHD3TC = 47;

            /// <summary>
            /// Indexer For Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHD4TC = 48;

            /// <summary>
            /// Indexer For Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHD5TC = 49;

            /// <summary>
            /// Indexer For Tax Withheld Amount Total
            /// </summary>
            public const int AmtWHDTot = 50;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 1
            /// </summary>
            public const int PndWHD1Tot = 51;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 2
            /// </summary>
            public const int PndWHD2Tot = 52;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 3
            /// </summary>
            public const int PndWHD3Tot = 53;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 4
            /// </summary>
            public const int PndWHD4Tot = 54;

            /// <summary>
            /// Indexer For Pending Tax Withheld Amount 5
            /// </summary>
            public const int PndWHD5Tot = 55;

            /// <summary>
            /// Indexer For Pending Tax Withheld Total
            /// </summary>
            public const int PndWHDTot = 56;

            /// <summary>
            /// Indexer For Document Tax Authority 1
            /// </summary>
            public const int CodeTax1 = 57;

            /// <summary>
            /// Indexer For Document Tax Authority 2
            /// </summary>
            public const int CodeTax2 = 58;

            /// <summary>
            /// Indexer For Document Tax Authority 3
            /// </summary>
            public const int CodeTax3 = 59;

            /// <summary>
            /// Indexer For Document Tax Authority 4
            /// </summary>
            public const int CodeTax4 = 60;

            /// <summary>
            /// Indexer For Document Tax Authority 5
            /// </summary>
            public const int CodeTax5 = 61;

            /// <summary>
            /// Indexer For Tax Auth 1 Description
            /// </summary>
            public const int TaxAuth1Description = 150;

            /// <summary>
            /// Indexer For Tax Auth 2 Description
            /// </summary>
            public const int TaxAuth2Description = 151;

            /// <summary>
            /// Indexer For Tax Auth 3 Description
            /// </summary>
            public const int TaxAuth3Description = 152;

            /// <summary>
            /// Indexer For Tax Auth 4 Description
            /// </summary>
            public const int TaxAuth4Description = 153;

            /// <summary>
            /// Indexer For Tax Auth 5 Description
            /// </summary>
            public const int TaxAuth5Description = 154;

            #endregion
        }


    }
}
