// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
	/// <summary>
	/// Contains list of RefundEntrie Constants
	/// </summary>
	public partial class RefundEntry
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "AR0141";

		#region Properties

		/// <summary>
		/// Contains list of RefundEntrie Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBTCH";

			/// <summary>
			/// Property for EntryNumber
			/// </summary>
			public const string EntryNumber = "CNTITEM";

			/// <summary>
			/// Property for DocumentDescription
			/// </summary>
			public const string DocumentDescription = "DOCDESC";

			/// <summary>
			/// Property for DocumentDate
			/// </summary>
			public const string DocumentDate = "DOCDATE";

			/// <summary>
			/// Property for FiscalYear
			/// </summary>
			public const string FiscalYear = "FISCYR";

			/// <summary>
			/// Property for FiscalPeriod
			/// </summary>
			public const string FiscalPeriod = "FISCPER";

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "IDCUST";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "IDINVC";

			/// <summary>
			/// Property for RefundAmountCustomer
			/// </summary>
			public const string RefundAmountCustomer = "AMTTC";

			/// <summary>
			/// Property for RefundAmountFunctional
			/// </summary>
			public const string RefundAmountFunctional = "AMTHC";

			/// <summary>
			/// Property for CustomerCurrency
			/// </summary>
			public const string CustomerCurrency = "CODECURN";

			/// <summary>
			/// Property for RateType
			/// </summary>
			public const string RateType = "RATETYPE";

			/// <summary>
			/// Property for RateDate
			/// </summary>
			public const string RateDate = "RATEDATE";

			/// <summary>
			/// Property for ExchangeRate
			/// </summary>
			public const string ExchangeRate = "RATEEXCH";

			/// <summary>
			/// Property for RateOperator
			/// </summary>
			public const string RateOperator = "RATEOP";

			/// <summary>
			/// Property for RateOverrideFlag
			/// </summary>
			public const string RateOverrideFlag = "SWRATE";

			/// <summary>
			/// Property for DateCreated
			/// </summary>
			public const string DateCreated = "DATECREATE";

			/// <summary>
			/// Property for DateLastEdited
			/// </summary>
			public const string DateLastEdited = "DATELSTEDT";

			/// <summary>
			/// Property for NumberOfDetails
			/// </summary>
			public const string NumberOfDetails = "DETAILCNT";

			/// <summary>
			/// Property for JobApplyMethod
			/// </summary>
			public const string JobApplyMethod = "APPLYMETH";

			/// <summary>
			/// Property for NumberOfOptionalFields
			/// </summary>
			public const string NumberOfOptionalFields = "VALUES";

			/// <summary>
			/// Property for SourceApplication
			/// </summary>
			public const string SourceApplication = "SRCEAPPL";

			/// <summary>
			/// Property for ErrorBatch
			/// </summary>
			public const string ErrorBatch = "ERRBATCH";

			/// <summary>
			/// Property for ErrorEntry
			/// </summary>
			public const string ErrorEntry = "ERRENTRY";

			/// <summary>
			/// Property for CashBankAccount
			/// </summary>
			public const string CashBankAccount = "IDBANKCA";

			/// <summary>
			/// Property for CashGLAccount
			/// </summary>
			public const string CashGLAccount = "IDACCTCA";

			/// <summary>
			/// Property for CashPaymentCurrency
			/// </summary>
			public const string CashPaymentCurrency = "CODECURNCA";

			/// <summary>
			/// Property for CashRateType
			/// </summary>
			public const string CashRateType = "RATETYPECA";

			/// <summary>
			/// Property for CashRateDate
			/// </summary>
			public const string CashRateDate = "RATEDATECA";

			/// <summary>
			/// Property for CashExchangeRate
			/// </summary>
			public const string CashExchangeRate = "RATEEXCHCA";

			/// <summary>
			/// Property for CashRateOperator
			/// </summary>
			public const string CashRateOperator = "RATEOPCA";

			/// <summary>
			/// Property for CashRateOverrideFlag
			/// </summary>
			public const string CashRateOverrideFlag = "SWRATECA";

			/// <summary>
			/// Property for CashAmountPayment
			/// </summary>
			public const string CashAmountPayment = "AMTPCCA";

			/// <summary>
			/// Property for CashAmountCustomer
			/// </summary>
			public const string CashAmountCustomer = "AMTTCCA";

			/// <summary>
			/// Property for CashAmountFunctional
			/// </summary>
			public const string CashAmountFunctional = "AMTHCCA";

			/// <summary>
			/// Property for CheckBankAccount
			/// </summary>
			public const string CheckBankAccount = "IDBANKCK";

			/// <summary>
			/// Property for CheckPrintingRequired
			/// </summary>
			public const string CheckPrintingRequired = "SWPRINT";

			/// <summary>
			/// Property for CheckHasBeenPrinted
			/// </summary>
			public const string CheckHasBeenPrinted = "SWPRINTED";

			/// <summary>
			/// Property for CheckNumber
			/// </summary>
			public const string CheckNumber = "CHECKNUM";

			/// <summary>
			/// Property for CheckSerialNumber
			/// </summary>
			public const string CheckSerialNumber = "LONGSERIAL";

			/// <summary>
			/// Property for CheckPaymentCurrency
			/// </summary>
			public const string CheckPaymentCurrency = "CODECURNCK";

			/// <summary>
			/// Property for CheckRateType
			/// </summary>
			public const string CheckRateType = "RATETYPECK";

			/// <summary>
			/// Property for CheckRateDate
			/// </summary>
			public const string CheckRateDate = "RATEDATECK";

			/// <summary>
			/// Property for CheckExchangeRate
			/// </summary>
			public const string CheckExchangeRate = "RATEEXCHCK";

			/// <summary>
			/// Property for CheckRateOperator
			/// </summary>
			public const string CheckRateOperator = "RATEOPCK";

			/// <summary>
			/// Property for CheckRateOverrideFlag
			/// </summary>
			public const string CheckRateOverrideFlag = "SWRATECK";

			/// <summary>
			/// Property for CheckAmountPayment
			/// </summary>
			public const string CheckAmountPayment = "AMTPCCK";

			/// <summary>
			/// Property for CheckAmountCustomer
			/// </summary>
			public const string CheckAmountCustomer = "AMTTCCK";

			/// <summary>
			/// Property for CheckAmountFunctional
			/// </summary>
			public const string CheckAmountFunctional = "AMTHCCK";

			/// <summary>
			/// Property for RemitToName
			/// </summary>
			public const string RemitToName = "NAMERMIT";

			/// <summary>
			/// Property for AddressLine1
			/// </summary>
			public const string AddressLine1 = "TEXTSTRE1";

			/// <summary>
			/// Property for AddressLine2
			/// </summary>
			public const string AddressLine2 = "TEXTSTRE2";

			/// <summary>
			/// Property for AddressLine3
			/// </summary>
			public const string AddressLine3 = "TEXTSTRE3";

			/// <summary>
			/// Property for AddressLine4
			/// </summary>
			public const string AddressLine4 = "TEXTSTRE4";

			/// <summary>
			/// Property for City
			/// </summary>
			public const string City = "NAMECITY";

			/// <summary>
			/// Property for StateProv
			/// </summary>
			public const string StateProv = "CODESTTE";

			/// <summary>
			/// Property for ZipPostalCode
			/// </summary>
			public const string ZipPostalCode = "CODEPSTL";

			/// <summary>
			/// Property for Country
			/// </summary>
			public const string Country = "CODECTRY";

			/// <summary>
			/// Property for CheckLanguage
			/// </summary>
			public const string CheckLanguage = "CHECKLANG";

			/// <summary>
			/// Property for CCAmountCustomer
			/// </summary>
			public const string CcAmountCustomer = "AMTTCCC";

			/// <summary>
			/// Property for ProcessCommand
			/// </summary>
			public const string ProcessCommand = "PROCESSCMD";

			/// <summary>
			/// Property for EnteredBy
			/// </summary>
			public const string EnteredBy = "ENTEREDBY";

			/// <summary>
			/// Property for PostingDate
			/// </summary>
			public const string PostingDate = "DATEBUS";

			/// <summary>
            /// Property for NumberOfSpsccDetails
			/// </summary>
            public const string NumberOfSpsccDetails = "CCSPSCNT";

			/// <summary>
			/// Property for OriginalCCTransactionNumber
			/// </summary>
			public const string OriginalCcTransactionNumber = "CCORIGID";

			/// <summary>
			/// Property for PreviousCCTransactionNumber
			/// </summary>
			public const string PreviousCcTransactionNumber = "CCPREVID";

			/// <summary>
			/// Property for PreviousCCProcessStatus
			/// </summary>
			public const string PreviousCcProcessStatus = "CCPREVSTTS";

			/// <summary>
			/// Property for CurrentCCTransactionNumber
			/// </summary>
			public const string CurrentCcTransactionNumber = "CCTRANID";

			/// <summary>
			/// Property for CurrentCCProcessStatus
			/// </summary>
			public const string CurrentCcProcessStatus = "CCTRANSTTS";

			/// <summary>
			/// Property for ProcessingCode
			/// </summary>
			public const string ProcessingCode = "PROCESSCOD";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of RefundEntrie Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 1;

			/// <summary>
			/// Property Indexer for EntryNumber
			/// </summary>
			public const int EntryNumber = 2;

			/// <summary>
			/// Property Indexer for DocumentDescription
			/// </summary>
			public const int DocumentDescription = 3;

			/// <summary>
			/// Property Indexer for DocumentDate
			/// </summary>
			public const int DocumentDate = 4;

			/// <summary>
			/// Property Indexer for FiscalYear
			/// </summary>
			public const int FiscalYear = 5;

			/// <summary>
			/// Property Indexer for FiscalPeriod
			/// </summary>
			public const int FiscalPeriod = 6;

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 7;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 8;

			/// <summary>
			/// Property Indexer for RefundAmountCustomer
			/// </summary>
			public const int RefundAmountCustomer = 9;

			/// <summary>
			/// Property Indexer for RefundAmountFunctional
			/// </summary>
			public const int RefundAmountFunctional = 10;

			/// <summary>
			/// Property Indexer for CustomerCurrency
			/// </summary>
			public const int CustomerCurrency = 11;

			/// <summary>
			/// Property Indexer for RateType
			/// </summary>
			public const int RateType = 12;

			/// <summary>
			/// Property Indexer for RateDate
			/// </summary>
			public const int RateDate = 13;

			/// <summary>
			/// Property Indexer for ExchangeRate
			/// </summary>
			public const int ExchangeRate = 14;

			/// <summary>
			/// Property Indexer for RateOperator
			/// </summary>
			public const int RateOperator = 15;

			/// <summary>
			/// Property Indexer for RateOverrideFlag
			/// </summary>
			public const int RateOverrideFlag = 16;

			/// <summary>
			/// Property Indexer for DateCreated
			/// </summary>
			public const int DateCreated = 17;

			/// <summary>
			/// Property Indexer for DateLastEdited
			/// </summary>
			public const int DateLastEdited = 18;

			/// <summary>
			/// Property Indexer for NumberOfDetails
			/// </summary>
			public const int NumberOfDetails = 19;

			/// <summary>
			/// Property Indexer for JobApplyMethod
			/// </summary>
			public const int JobApplyMethod = 20;

			/// <summary>
			/// Property Indexer for NumberOfOptionalFields
			/// </summary>
			public const int NumberOfOptionalFields = 21;

			/// <summary>
			/// Property Indexer for SourceApplication
			/// </summary>
			public const int SourceApplication = 22;

			/// <summary>
			/// Property Indexer for ErrorBatch
			/// </summary>
			public const int ErrorBatch = 23;

			/// <summary>
			/// Property Indexer for ErrorEntry
			/// </summary>
			public const int ErrorEntry = 24;

			/// <summary>
			/// Property Indexer for CashBankAccount
			/// </summary>
			public const int CashBankAccount = 25;

			/// <summary>
			/// Property Indexer for CashGLAccount
			/// </summary>
			public const int CashGLAccount = 26;

			/// <summary>
			/// Property Indexer for CashPaymentCurrency
			/// </summary>
			public const int CashPaymentCurrency = 27;

			/// <summary>
			/// Property Indexer for CashRateType
			/// </summary>
			public const int CashRateType = 28;

			/// <summary>
			/// Property Indexer for CashRateDate
			/// </summary>
			public const int CashRateDate = 29;

			/// <summary>
			/// Property Indexer for CashExchangeRate
			/// </summary>
			public const int CashExchangeRate = 30;

			/// <summary>
			/// Property Indexer for CashRateOperator
			/// </summary>
			public const int CashRateOperator = 31;

			/// <summary>
			/// Property Indexer for CashRateOverrideFlag
			/// </summary>
			public const int CashRateOverrideFlag = 32;

			/// <summary>
			/// Property Indexer for CashAmountPayment
			/// </summary>
			public const int CashAmountPayment = 33;

			/// <summary>
			/// Property Indexer for CashAmountCustomer
			/// </summary>
			public const int CashAmountCustomer = 34;

			/// <summary>
			/// Property Indexer for CashAmountFunctional
			/// </summary>
			public const int CashAmountFunctional = 35;

			/// <summary>
			/// Property Indexer for CheckBankAccount
			/// </summary>
			public const int CheckBankAccount = 36;

			/// <summary>
			/// Property Indexer for CheckPrintingRequired
			/// </summary>
			public const int CheckPrintingRequired = 37;

			/// <summary>
			/// Property Indexer for CheckHasBeenPrinted
			/// </summary>
			public const int CheckHasBeenPrinted = 38;

			/// <summary>
			/// Property Indexer for CheckNumber
			/// </summary>
			public const int CheckNumber = 39;

			/// <summary>
			/// Property Indexer for CheckSerialNumber
			/// </summary>
			public const int CheckSerialNumber = 40;

			/// <summary>
			/// Property Indexer for CheckPaymentCurrency
			/// </summary>
			public const int CheckPaymentCurrency = 41;

			/// <summary>
			/// Property Indexer for CheckRateType
			/// </summary>
			public const int CheckRateType = 42;

			/// <summary>
			/// Property Indexer for CheckRateDate
			/// </summary>
			public const int CheckRateDate = 43;

			/// <summary>
			/// Property Indexer for CheckExchangeRate
			/// </summary>
			public const int CheckExchangeRate = 44;

			/// <summary>
			/// Property Indexer for CheckRateOperator
			/// </summary>
			public const int CheckRateOperator = 45;

			/// <summary>
			/// Property Indexer for CheckRateOverrideFlag
			/// </summary>
			public const int CheckRateOverrideFlag = 46;

			/// <summary>
			/// Property Indexer for CheckAmountPayment
			/// </summary>
			public const int CheckAmountPayment = 47;

			/// <summary>
			/// Property Indexer for CheckAmountCustomer
			/// </summary>
			public const int CheckAmountCustomer = 48;

			/// <summary>
			/// Property Indexer for CheckAmountFunctional
			/// </summary>
			public const int CheckAmountFunctional = 49;

			/// <summary>
			/// Property Indexer for RemitToName
			/// </summary>
			public const int RemitToName = 50;

			/// <summary>
			/// Property Indexer for AddressLine1
			/// </summary>
			public const int AddressLine1 = 51;

			/// <summary>
			/// Property Indexer for AddressLine2
			/// </summary>
			public const int AddressLine2 = 52;

			/// <summary>
			/// Property Indexer for AddressLine3
			/// </summary>
			public const int AddressLine3 = 53;

			/// <summary>
			/// Property Indexer for AddressLine4
			/// </summary>
			public const int AddressLine4 = 54;

			/// <summary>
			/// Property Indexer for City
			/// </summary>
			public const int City = 55;

			/// <summary>
			/// Property Indexer for StateProv
			/// </summary>
			public const int StateProv = 56;

			/// <summary>
			/// Property Indexer for ZipPostalCode
			/// </summary>
			public const int ZipPostalCode = 57;

			/// <summary>
			/// Property Indexer for Country
			/// </summary>
			public const int Country = 58;

			/// <summary>
			/// Property Indexer for CheckLanguage
			/// </summary>
			public const int CheckLanguage = 59;

			/// <summary>
			/// Property Indexer for CCAmountCustomer
			/// </summary>
			public const int CcAmountCustomer = 60;

			/// <summary>
			/// Property Indexer for ProcessCommand
			/// </summary>
			public const int ProcessCommand = 61;

			/// <summary>
			/// Property Indexer for EnteredBy
			/// </summary>
			public const int EnteredBy = 62;

			/// <summary>
			/// Property Indexer for PostingDate
			/// </summary>
			public const int PostingDate = 63;

			/// <summary>
            /// Property Indexer for NumberOfSpsccDetails
			/// </summary>
            public const int NumberOfSpsccDetails = 64;

			/// <summary>
			/// Property Indexer for OriginalCCTransactionNumber
			/// </summary>
			public const int OriginalCcTransactionNumber = 65;

			/// <summary>
			/// Property Indexer for PreviousCCTransactionNumber
			/// </summary>
			public const int PreviousCcTransactionNumber = 66;

			/// <summary>
			/// Property Indexer for PreviousCCProcessStatus
			/// </summary>
			public const int PreviousCcProcessStatus = 67;

			/// <summary>
			/// Property Indexer for CurrentCCTransactionNumber
			/// </summary>
			public const int CurrentCcTransactionNumber = 68;

			/// <summary>
			/// Property Indexer for CurrentCCProcessStatus
			/// </summary>
			public const int CurrentCcProcessStatus = 69;

			/// <summary>
			/// Property Indexer for ProcessingCode
			/// </summary>
			public const int ProcessingCode = 70;

		}

		#endregion

	}
}
