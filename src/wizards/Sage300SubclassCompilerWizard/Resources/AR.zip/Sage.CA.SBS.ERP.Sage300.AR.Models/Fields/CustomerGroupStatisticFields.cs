// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CustomerGroupStatistics Constants 
    /// </summary>
    public partial class CustomerGroupStatistic
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0026";

        /// <summary>
        /// Contains list of CustomerGroupStatistic Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for GroupCode 
            /// </summary>
            public const string GroupCode = "IDGRP";
            /// <summary>
            /// Property for Year 
            /// </summary>
            public const string Year = "CNTYR";
            /// <summary>
            /// Property for Period 
            /// </summary>
            public const string Period = "CNTPERD";
            /// <summary>
            /// Property for NumberOfInvoices 
            /// </summary>
            public const string NumberOfInvoices = "CNTINVC";
            /// <summary>
            /// Property for NumberOfCreditNotes 
            /// </summary>
            public const string NumberOfCreditNotes = "CNTCR";
            /// <summary>
            /// Property for NumberOfDebitNotes 
            /// </summary>
            public const string NumberOfDebitNotes = "CNTDR";
            /// <summary>
            /// Property for NumberOfReceipts 
            /// </summary>
            public const string NumberOfReceipts = "CNTPAYM";
            /// <summary>
            /// Property for NumberOfDiscounts 
            /// </summary>
            public const string NumberOfDiscounts = "CNTDISC";
            /// <summary>
            /// Property for NumberOfAdjustments 
            /// </summary>
            public const string NumberOfAdjustments = "CNTADJ";
            /// <summary>
            /// Property for NumberOfWriteOffs 
            /// </summary>
            public const string NumberOfWriteOffs = "CNTWROF";
            /// <summary>
            /// Property for NumberOfInterestCharges 
            /// </summary>
            public const string NumberOfInterestCharges = "CNTINTT";
            /// <summary>
            /// Property for NumberOfReturnedChecks 
            /// </summary>
            public const string NumberOfReturnedChecks = "CNTRIF";
            /// <summary>
            /// Property for NumberOfPaidInvoices 
            /// </summary>
            public const string NumberOfPaidInvoices = "CNTINVCPD";
            /// <summary>
            /// Property for NumberOfDaystoPay 
            /// </summary>
            public const string NumberOfDaystoPay = "CNTDTOPAY";
            /// <summary>
            /// Property for TotalInvoiceAmount 
            /// </summary>
            public const string TotalInvoiceAmount = "AMTINVCHC";
            /// <summary>
            /// Property for TotalCreditNoteAmount 
            /// </summary>
            public const string TotalCreditNoteAmount = "AMTCRHC";
            /// <summary>
            /// Property for TotalDebitNoteAmount 
            /// </summary>
            public const string TotalDebitNoteAmount = "AMTDRHC";
            /// <summary>
            /// Property for TotalReceiptAmount 
            /// </summary>
            public const string TotalReceiptAmount = "AMTPAYMHC";
            /// <summary>
            /// Property for TotalDiscountAmount 
            /// </summary>
            public const string TotalDiscountAmount = "AMTDISCHC";
            /// <summary>
            /// Property for TotalAdjustmentAmount 
            /// </summary>
            public const string TotalAdjustmentAmount = "AMTADJHC";
            /// <summary>
            /// Property for TotalWriteOffAmount 
            /// </summary>
            public const string TotalWriteOffAmount = "AMTWROFHC";
            /// <summary>
            /// Property for TotalInterestAmount 
            /// </summary>
            public const string TotalInterestAmount = "AMTINTTHC";
            /// <summary>
            /// Property for TotalAmountofReturnedChecks 
            /// </summary>
            public const string TotalAmountofReturnedChecks = "AMTRIFHC";
            /// <summary>
            /// Property for TotalAmountofPaidInvoices 
            /// </summary>
            public const string TotalAmountofPaidInvoices = "AMTINVPDHC";
            /// <summary>
            /// Property for AverageDaystoPay 
            /// </summary>
            public const string AverageDaystoPay = "AVGDAYSPAY";
            /// <summary>
            /// Property for NumberOfRefunds 
            /// </summary>
            public const string NumberOfRefunds = "CNTRF";
            /// <summary>
            /// Property for TotalRefundAmount 
            /// </summary>
            public const string TotalRefundAmount = "AMTRFHC";

            /// <summary>
            /// Property for YTDNumberOfInvoices 
            /// </summary>
           // ReSharper disable once InconsistentNaming
            public const string YTDNumberOfInvoices = "YTDCNTIN";

            /// <summary>
            /// Property for YTDNumberOfCredits 
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string YTDNumberOfCredits = "YTDCNTCR";
            /// <summary>
            /// Property for YTDNumberOfDebits 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfDebits = "YTDCNTDR";
            
            /// <summary>
            /// Property for YTDNumberOfReceipts 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfReceipts = "YTDCNTPY";

            /// <summary>
            /// Property for YTDNumberOfDiscounts 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfDiscounts = "YTDCNTED";

            /// <summary>
            /// Property for YTDNumberOfAdjustments 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfAdjustments = "YTDCNTAD";

            /// <summary>
            /// Property for YTDNumberOfWriteOffs 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfWriteOffs = "YTDCNTWO";

            /// <summary>
            /// Property for YTDNumberOfInterestCharges 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfInterestCharges = "YTDCNTIT";

            /// <summary>
            /// Property for YTDNumberOfReturnedChecks 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfReturnedChecks = "YTDCNTRIF";

            /// <summary>
            /// Property for YTDNumberOfInvoicesPaid 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfInvoicesPaid = "YTDCNTINPD";

            /// <summary>
            /// Property for YTDNumberOfRefunds 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfRefunds = "YTDCNTRF";

            /// <summary>
            /// Property for YTDNumberOfDaystoPay 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDNumberOfDaystoPay = "YTDCNTDTP";

            /// <summary>
            /// Property for YTDInvoicesInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDInvoicesInFuncCurr = "YTDHCIN";

            /// <summary>
            /// Property for YTDCreditsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDCreditsInFuncCurr = "YTDHCCR";

            /// <summary>
            /// Property for YTDDebitsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDDebitsInFuncCurr = "YTDHCDR";

            /// <summary>
            /// Property for YTDReceiptsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDReceiptsInFuncCurr = "YTDHCPY";

            /// <summary>
            /// Property for YTDDiscountsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDDiscountsInFuncCurr = "YTDHCED";

            /// <summary>
            /// Property for YTDAdjustmentsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDAdjustmentsInFuncCurr = "YTDHCAD";

            /// <summary>
            /// Property for YTDWriteOffsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDWriteOffsInFuncCurr = "YTDHCWO";
            
            /// <summary>
            /// Property for YTDInterestInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDInterestInFuncCurr = "YTDHCIT";

            /// <summary>
            /// Property for YTDRetdChecksInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDRetdChecksInFuncCurr = "YTDHCRIF";

            /// <summary>
            /// Property for YTDInvoicesPdInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDInvoicesPdInFuncCurr = "YTDHCINPD";

            /// <summary>
            /// Property for YTDRefundsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDRefundsInFuncCurr = "YTDHCRF";

            /// <summary>
            /// Property for YTDAverageDaystoPay 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string YTDAverageDaystoPay = "YTDCNTADTP";

            /// <summary>
            /// Property for EnableYTDCalculations 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const string EnableYTDCalculations = "YTDACTIVE";

            #endregion
        }


        /// <summary>
        /// Contains list of CustomerGroupStatistics Index Constants
        /// </summary>
        public class Index
        {

            #region Properties
            /// <summary>
            /// Property Indexer for GroupCode 
            /// </summary>
            public const int GroupCode = 1;
            /// <summary>
            /// Property Indexer for Year 
            /// </summary>
            public const int Year = 2;
            /// <summary>
            /// Property Indexer for Period 
            /// </summary>
            public const int Period = 3;
            /// <summary>
            /// Property Indexer for NumberOfInvoices 
            /// </summary>
            public const int NumberOfInvoices = 4;
            /// <summary>
            /// Property Indexer for NumberOfCreditNotes 
            /// </summary>
            public const int NumberOfCreditNotes = 5;
            /// <summary>
            /// Property Indexer for NumberOfDebitNotes 
            /// </summary>
            public const int NumberOfDebitNotes = 6;
            /// <summary>
            /// Property Indexer for NumberOfReceipts 
            /// </summary>
            public const int NumberOfReceipts = 7;
            /// <summary>
            /// Property Indexer for NumberOfDiscounts 
            /// </summary>
            public const int NumberOfDiscounts = 8;
            /// <summary>
            /// Property Indexer for NumberOfAdjustments 
            /// </summary>
            public const int NumberOfAdjustments = 9;
            /// <summary>
            /// Property Indexer for NumberOfWriteOffs 
            /// </summary>
            public const int NumberOfWriteOffs = 10;
            /// <summary>
            /// Property Indexer for NumberOfInterestCharges 
            /// </summary>
            public const int NumberOfInterestCharges = 11;
            /// <summary>
            /// Property Indexer for NumberOfReturnedChecks 
            /// </summary>
            public const int NumberOfReturnedChecks = 12;
            /// <summary>
            /// Property Indexer for NumberOfPaidInvoices 
            /// </summary>
            public const int NumberOfPaidInvoices = 13;
            /// <summary>
            /// Property Indexer for NumberOfDaystoPay 
            /// </summary>
            public const int NumberOfDaystoPay = 14;
            /// <summary>
            /// Property Indexer for TotalInvoiceAmount 
            /// </summary>
            public const int TotalInvoiceAmount = 15;
            /// <summary>
            /// Property Indexer for TotalCreditNoteAmount 
            /// </summary>
            public const int TotalCreditNoteAmount = 16;
            /// <summary>
            /// Property Indexer for TotalDebitNoteAmount 
            /// </summary>
            public const int TotalDebitNoteAmount = 17;
            /// <summary>
            /// Property Indexer for TotalReceiptAmount 
            /// </summary>
            public const int TotalReceiptAmount = 18;
            /// <summary>
            /// Property Indexer for TotalDiscountAmount 
            /// </summary>
            public const int TotalDiscountAmount = 19;
            /// <summary>
            /// Property Indexer for TotalAdjustmentAmount 
            /// </summary>
            public const int TotalAdjustmentAmount = 20;
            /// <summary>
            /// Property Indexer for TotalWriteOffAmount 
            /// </summary>
            public const int TotalWriteOffAmount = 21;
            /// <summary>
            /// Property Indexer for TotalInterestAmount 
            /// </summary>
            public const int TotalInterestAmount = 22;
            /// <summary>
            /// Property Indexer for TotalAmountofReturnedChecks 
            /// </summary>
            public const int TotalAmountofReturnedChecks = 23;
            /// <summary>
            /// Property Indexer for TotalAmountofPaidInvoices 
            /// </summary>
            public const int TotalAmountofPaidInvoices = 24;
            /// <summary>
            /// Property Indexer for AverageDaystoPay 
            /// </summary>
            public const int AverageDaystoPay = 25;
            /// <summary>
            /// Property Indexer for NumberOfRefunds 
            /// </summary>
            public const int NumberOfRefunds = 26;
            /// <summary>
            /// Property Indexer for TotalRefundAmount 
            /// </summary>
            public const int TotalRefundAmount = 27;
            /// <summary>
            /// Property Indexer for YTDNumberOfInvoices 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfInvoices = 28;

            /// <summary>
            /// Property Indexer for YTDNumberOfCredits 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfCredits = 29;

            /// <summary>
            /// Property Indexer for YTDNumberOfDebits 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfDebits = 30;

            /// <summary>
            /// Property Indexer for YTDNumberOfReceipts 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfReceipts = 31;

            /// <summary>
            /// Property Indexer for YTDNumberOfDiscounts 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfDiscounts = 32;

            /// <summary>
            /// Property Indexer for YTDNumberOfAdjustments 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfAdjustments = 33;

            /// <summary>
            /// Property Indexer for YTDNumberOfWriteOffs 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfWriteOffs = 34;

            /// <summary>
            /// Property Indexer for YTDNumberOfInterestCharges 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfInterestCharges = 35;

            /// <summary>
            /// Property Indexer for YTDNumberOfReturnedChecks 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfReturnedChecks = 36;

            /// <summary>
            /// Property Indexer for YTDNumberOfInvoicesPaid 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfInvoicesPaid = 37;

            /// <summary>
            /// Property Indexer for YTDNumberOfRefunds 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfRefunds = 38;
            
            /// <summary>
            /// Property Indexer for YTDNumberOfDaystoPay 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDNumberOfDaystoPay = 39;

            /// <summary>
            /// Property Indexer for YTDInvoicesInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDInvoicesInFuncCurr = 40;

            /// <summary>
            /// Property Indexer for YTDCreditsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDCreditsInFuncCurr = 41;

            /// <summary>
            /// Property Indexer for YTDDebitsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDDebitsInFuncCurr = 42;

            /// <summary>
            /// Property Indexer for YTDReceiptsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDReceiptsInFuncCurr = 43;

            /// <summary>
            /// Property Indexer for YTDDiscountsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDDiscountsInFuncCurr = 44;

            /// <summary>
            /// Property Indexer for YTDAdjustmentsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDAdjustmentsInFuncCurr = 45;

            /// <summary>
            /// Property Indexer for YTDWriteOffsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDWriteOffsInFuncCurr = 46;

            /// <summary>
            /// Property Indexer for YTDInterestInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDInterestInFuncCurr = 47;

            /// <summary>
            /// Property Indexer for YTDRetdChecksInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDRetdChecksInFuncCurr = 48;

            /// <summary>
            /// Property Indexer for YTDInvoicesPdInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDInvoicesPdInFuncCurr = 49;

            /// <summary>
            /// Property Indexer for YTDRefundsInFuncCurr 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDRefundsInFuncCurr = 50;
            /// <summary>
            /// Property Indexer for YTDAverageDaystoPay 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int YTDAverageDaystoPay = 51;

            /// <summary>
            /// Property Indexer for EnableYTDCalculations 
            /// </summary>
            /// ReSharper disable once InconsistentNaming
            public const int EnableYTDCalculations = 52;

            #endregion
        }


    }
}
