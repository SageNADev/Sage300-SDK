// Copyright (c) 1994-2022 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Customers Constants
    /// </summary>
    public partial class Customer
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0024";

        /// <summary>
        /// Contains list of Customers Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for ShortName
            /// </summary>
            public const string ShortName = "TEXTSNAM";

            /// <summary>
            /// Property for GroupCode
            /// </summary>
            public const string GroupCode = "IDGRP";

            /// <summary>
            /// Property for NationalAccount
            /// </summary>
            public const string NationalAccount = "IDNATACCT";

            /// <summary>
            /// Property for Status
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for InactiveDate
            /// </summary>
            public const string InactiveDate = "DATEINAC";

            /// <summary>
            /// Property for DateLastMaintained
            /// </summary>
            public const string DateLastMaintained = "DATELASTMN";

            /// <summary>
            /// Property for OnHold
            /// </summary>
            public const string OnHold = "SWHOLD";

            /// <summary>
            /// Property for StartDate
            /// </summary>
            public const string StartDate = "DATESTART";

            /// <summary>
            /// Property for CreditBureauNumber
            /// </summary>
            public const string CreditBureauNumber = "CODEDAB";

            /// <summary>
            /// Property for CreditBureauRating
            /// </summary>
            public const string CreditBureauRating = "CODEDABRTG";

            /// <summary>
            /// Property for CreditBureauDate
            /// </summary>
            public const string CreditBureauDate = "DATEDAB";

            /// <summary>
            /// Property for CustomerName
            /// </summary>
            public const string CustomerName = "NAMECUST";

            /// <summary>
            /// Property for AddressLine1
            /// </summary>
            public const string AddressLine1 = "TEXTSTRE1";

            /// <summary>
            /// Property for AddressLine2
            /// </summary>
            public const string AddressLine2 = "TEXTSTRE2";

            /// <summary>
            /// Property for AddressLine3
            /// </summary>
            public const string AddressLine3 = "TEXTSTRE3";

            /// <summary>
            /// Property for AddressLine4
            /// </summary>
            public const string AddressLine4 = "TEXTSTRE4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "NAMECITY";

            /// <summary>
            /// Property for StateOrProv
            /// </summary>
            public const string StateOrProv = "CODESTTE";

            /// <summary>
            /// Property for ZipOrPostalCode
            /// </summary>
            public const string ZipOrPostalCode = "CODEPSTL";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "CODECTRY";

            /// <summary>
            /// Property for ContactName
            /// </summary>
            public const string ContactName = "NAMECTAC";

            /// <summary>
            /// Property for PhoneNumber
            /// </summary>
            public const string PhoneNumber = "TEXTPHON1";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "TEXTPHON2";

            /// <summary>
            /// Property for TerritoryCode
            /// </summary>
            public const string TerritoryCode = "CODETERR";

            /// <summary>
            /// Property for AccountSet
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            /// <summary>
            /// Property for AutocashProfile
            /// </summary>
            public const string AutocashProfile = "IDAUTOCASH";

            /// <summary>
            /// Property for BillingCycle
            /// </summary>
            public const string BillingCycle = "IDBILLCYCL";

            /// <summary>
            /// Property for InterestProfile
            /// </summary>
            public const string InterestProfile = "IDSVCCHRG";

            /// <summary>
            /// Property for CurrencyCode
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for PrintStatements
            /// </summary>
            public const string PrintStatements = "SWPRTSTMT";

            /// <summary>
            /// Property for AccountType
            /// </summary>
            public const string AccountType = "SWBALFWD";

            /// <summary>
            /// Property for Terms
            /// </summary>
            public const string Terms = "CODETERM";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "IDRATETYPE";

            /// <summary>
            /// Property for TaxGroup
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";

            /// <summary>
            /// Property for TaxRegistrationNo1
            /// </summary>
            public const string TaxRegistrationNo1 = "IDTAXREGI1";

            /// <summary>
            /// Property for TaxRegistrationNo2
            /// </summary>
            public const string TaxRegistrationNo2 = "IDTAXREGI2";

            /// <summary>
            /// Property for TaxRegistrationNo3
            /// </summary>
            public const string TaxRegistrationNo3 = "IDTAXREGI3";

            /// <summary>
            /// Property for TaxRegistrationNo4
            /// </summary>
            public const string TaxRegistrationNo4 = "IDTAXREGI4";

            /// <summary>
            /// Property for TaxRegistrationNo5
            /// </summary>
            public const string TaxRegistrationNo5 = "IDTAXREGI5";

            /// <summary>
            /// Property for TaxClassCode1
            /// </summary>
            public const string TaxClassCode1 = "TAXSTTS1";

            /// <summary>
            /// Property for TaxClassCode2
            /// </summary>
            public const string TaxClassCode2 = "TAXSTTS2";

            /// <summary>
            /// Property for TaxClassCode3
            /// </summary>
            public const string TaxClassCode3 = "TAXSTTS3";

            /// <summary>
            /// Property for TaxClassCode4
            /// </summary>
            public const string TaxClassCode4 = "TAXSTTS4";

            /// <summary>
            /// Property for TaxClassCode5
            /// </summary>
            public const string TaxClassCode5 = "TAXSTTS5";

            /// <summary>
            /// Property for CreditLimitCustCurr
            /// </summary>
            public const string CreditLimitCustCurr = "AMTCRLIMT";

            /// <summary>
            /// Property for BalanceDueinCustCurr
            /// </summary>
            public const string BalanceDueinCustCurr = "AMTBALDUET";

            /// <summary>
            /// Property for BalanceDueinFuncCurr
            /// </summary>
            public const string BalanceDueinFuncCurr = "AMTBALDUEH";

            /// <summary>
            /// Property for DateofLastStatement
            /// </summary>
            public const string DateofLastStatement = "DATELASTST";

            /// <summary>
            /// Property for LastStatementTotalCustCurr
            /// </summary>
            public const string LastStatementTotalCustCurr = "AMTLASTSTT";

            /// <summary>
            /// Property for DateofLastBalFwdStatement
            /// </summary>
            public const string DateofLastBalFwdStatement = "DTBEGBALFW";

            /// <summary>
            /// Property for BeginningBalonLastStatement
            /// </summary>
            public const string BeginningBalonLastStatement = "AMTBALFWDT";

            /// <summary>
            /// Property for DateofLastRevaluation
            /// </summary>
            public const string DateofLastRevaluation = "DTLASTRVAL";

            /// <summary>
            /// Property for LastRevaluationBalance
            /// </summary>
            public const string LastRevaluationBalance = "AMTBALLARV";

            /// <summary>
            /// Property for NumberofOpenDocuments
            /// </summary>
            public const string NumberofOpenDocuments = "CNTOPENINV";

            /// <summary>
            /// Property for NumberofPaidInvoices
            /// </summary>
            public const string NumberofPaidInvoices = "CNTINVPAID";

            /// <summary>
            /// Property for NumberofDaystoPay
            /// </summary>
            public const string NumberofDaystoPay = "DAYSTOPAY";

            /// <summary>
            /// Property for DateofLargestInvoice
            /// </summary>
            public const string DateofLargestInvoice = "DATEINVCHI";

            /// <summary>
            /// Property for DateofHighestBalance
            /// </summary>
            public const string DateofHighestBalance = "DATEBALHI";

            /// <summary>
            /// Property for DateofLargestInvoiceLastYr
            /// </summary>
            public const string DateofLargestInvoiceLastYr = "DATEINVHIL";

            /// <summary>
            /// Property for DateofHighestBalanceLastYr
            /// </summary>
            public const string DateofHighestBalanceLastYr = "DATEBALHIL";

            /// <summary>
            /// Property for DateofLastActivity
            /// </summary>
            public const string DateofLastActivity = "DATELASTAC";

            /// <summary>
            /// Property for DateofLastInvoice
            /// </summary>
            public const string DateofLastInvoice = "DATELASTIV";

            /// <summary>
            /// Property for DateofLastCreditNote
            /// </summary>
            public const string DateofLastCreditNote = "DATELASTCR";

            /// <summary>
            /// Property for DateofLastDebitNote
            /// </summary>
            public const string DateofLastDebitNote = "DATELASTDR";

            /// <summary>
            /// Property for DateofLastReceipt
            /// </summary>
            public const string DateofLastReceipt = "DATELASTPA";

            /// <summary>
            /// Property for DateofLastDiscount
            /// </summary>
            public const string DateofLastDiscount = "DATELASTDI";

            /// <summary>
            /// Property for DateofLastAdjustment
            /// </summary>
            public const string DateofLastAdjustment = "DATELASTAD";

            /// <summary>
            /// Property for DateofLastWriteOff
            /// </summary>
            public const string DateofLastWriteOff = "DATELASTWR";

            /// <summary>
            /// Property for DateofLastReturnedCheck
            /// </summary>
            public const string DateofLastReturnedCheck = "DATELASTRI";

            /// <summary>
            /// Property for DateofLastInterestCharge
            /// </summary>
            public const string DateofLastInterestCharge = "DATELASTIN";

            /// <summary>
            /// Property for LargestInvoiceNumber
            /// </summary>
            public const string LargestInvoiceNumber = "IDINVCHI";

            /// <summary>
            /// Property for LargestInvoiceNumberLastYr
            /// </summary>
            public const string LargestInvoiceNumberLastYr = "IDINVCHILY";

            /// <summary>
            /// Property for LargestInvoiceCustCurr
            /// </summary>
            public const string LargestInvoiceCustCurr = "AMTINVHIT";

            /// <summary>
            /// Property for HighestBalanceCustCurr
            /// </summary>
            public const string HighestBalanceCustCurr = "AMTBALHIT";

            /// <summary>
            /// Property for LgstInvLastYrCustCurr
            /// </summary>
            public const string LgstInvLastYrCustCurr = "AMTINVHILT";

            /// <summary>
            /// Property for HighBalLastYrCustCurr
            /// </summary>
            public const string HighBalLastYrCustCurr = "AMTBALHILT";

            /// <summary>
            /// Property for LastInvoiceAmtCustCurr
            /// </summary>
            public const string LastInvoiceAmtCustCurr = "AMTLASTIVT";

            /// <summary>
            /// Property for LastCrNoteAmtCustCurr
            /// </summary>
            public const string LastCrNoteAmtCustCurr = "AMTLASTCRT";

            /// <summary>
            /// Property for LastDrNoteAmtCustCurr
            /// </summary>
            public const string LastDrNoteAmtCustCurr = "AMTLASTDRT";

            /// <summary>
            /// Property for LastReceiptCustCurr
            /// </summary>
            public const string LastReceiptCustCurr = "AMTLASTPYT";

            /// <summary>
            /// Property for LastDiscountAmtCustCurr
            /// </summary>
            public const string LastDiscountAmtCustCurr = "AMTLASTDIT";

            /// <summary>
            /// Property for LastAdjAmtCustCurr
            /// </summary>
            public const string LastAdjAmtCustCurr = "AMTLASTADT";

            /// <summary>
            /// Property for LastWriteOffAmtCustCurr
            /// </summary>
            public const string LastWriteOffAmtCustCurr = "AMTLASTWRT";

            /// <summary>
            /// Property for LastRetdChkAmtCustCurr
            /// </summary>
            public const string LastRetdChkAmtCustCurr = "AMTLASTRIT";

            /// <summary>
            /// Property for LastIntChargeCustCurr
            /// </summary>
            public const string LastIntChargeCustCurr = "AMTLASTINT";

            /// <summary>
            /// Property for LargestInvoiceFuncCurr
            /// </summary>
            public const string LargestInvoiceFuncCurr = "AMTINVHIH";

            /// <summary>
            /// Property for HighestBalanceFuncCurr
            /// </summary>
            public const string HighestBalanceFuncCurr = "AMTBALHIH";

            /// <summary>
            /// Property for LgstInvLastYrFuncCurr
            /// </summary>
            public const string LgstInvLastYrFuncCurr = "AMTINVHILH";

            /// <summary>
            /// Property for HighBalLastYrFuncCurr
            /// </summary>
            public const string HighBalLastYrFuncCurr = "AMTBALHILH";

            /// <summary>
            /// Property for LastInvoiceAmtFuncCurr
            /// </summary>
            public const string LastInvoiceAmtFuncCurr = "AMTLASTIVH";

            /// <summary>
            /// Property for LastCrNoteAmtFuncCurr
            /// </summary>
            public const string LastCrNoteAmtFuncCurr = "AMTLASTCRH";

            /// <summary>
            /// Property for LastDrNoteAmtFuncCurr
            /// </summary>
            public const string LastDrNoteAmtFuncCurr = "AMTLASTDRH";

            /// <summary>
            /// Property for LastReceiptFuncCurr
            /// </summary>
            public const string LastReceiptFuncCurr = "AMTLASTPYH";

            /// <summary>
            /// Property for LastDiscountAmtFuncCurr
            /// </summary>
            public const string LastDiscountAmtFuncCurr = "AMTLASTDIH";

            /// <summary>
            /// Property for LastAdjAmtFuncCurr
            /// </summary>
            public const string LastAdjAmtFuncCurr = "AMTLASTADH";

            /// <summary>
            /// Property for LastWriteOffAmtFuncCurr
            /// </summary>
            public const string LastWriteOffAmtFuncCurr = "AMTLASTWRH";

            /// <summary>
            /// Property for LastRetdChkAmtFuncCurr
            /// </summary>
            public const string LastRetdChkAmtFuncCurr = "AMTLASTRIH";

            /// <summary>
            /// Property for LastIntChargeFuncCurr
            /// </summary>
            public const string LastIntChargeFuncCurr = "AMTLASTINH";

            /// <summary>
            /// Property for Salesperson1
            /// </summary>
            public const string Salesperson1 = "CODESLSP1";

            /// <summary>
            /// Property for Salesperson2
            /// </summary>
            public const string Salesperson2 = "CODESLSP2";

            /// <summary>
            /// Property for Salesperson3
            /// </summary>
            public const string Salesperson3 = "CODESLSP3";

            /// <summary>
            /// Property for Salesperson4
            /// </summary>
            public const string Salesperson4 = "CODESLSP4";

            /// <summary>
            /// Property for Salesperson5
            /// </summary>
            public const string Salesperson5 = "CODESLSP5";

            /// <summary>
            /// Property for SalesSplitPercentage1
            /// </summary>
            public const string SalesSplitPercentage1 = "PCTSASPLT1";

            /// <summary>
            /// Property for SalesSplitPercentage2
            /// </summary>
            public const string SalesSplitPercentage2 = "PCTSASPLT2";

            /// <summary>
            /// Property for SalesSplitPercentage3
            /// </summary>
            public const string SalesSplitPercentage3 = "PCTSASPLT3";

            /// <summary>
            /// Property for SalesSplitPercentage4
            /// </summary>
            public const string SalesSplitPercentage4 = "PCTSASPLT4";

            /// <summary>
            /// Property for SalesSplitPercentage5
            /// </summary>
            public const string SalesSplitPercentage5 = "PCTSASPLT5";

            /// <summary>
            /// Property for AverageDaysToPay
            /// </summary>
            public const string AverageDaysToPay = "AVGDAYSPAY";

            /// <summary>
            /// Property for CustomerPriceList
            /// </summary>
            public const string CustomerPriceList = "PRICLIST";

            /// <summary>
            /// Property for CustomerDiscountType
            /// </summary>
            public const string CustomerDiscountType = "CUSTTYPE";

            /// <summary>
            /// Property for AmountPastDue
            /// </summary>
            public const string AmountPastDue = "AMTPDUE";

            /// <summary>
            /// Property for ContactsEmail
            /// </summary>
            public const string ContactsEmail = "EMAIL1";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "EMAIL2";

            /// <summary>
            /// Property for WebSite
            /// </summary>
            public const string WebSite = "WEBSITE";

            /// <summary>
            /// Property for BillingMethod
            /// </summary>
            public const string BillingMethod = "BILLMETHOD";

            /// <summary>
            /// Property for PaymentCode
            /// </summary>
            public const string PaymentCode = "PAYMCODE";

            /// <summary>
            /// Property for FreeOnBoard
            /// </summary>
            public const string FreeOnBoard = "FOB";

            /// <summary>
            /// Property for ShipViaCode
            /// </summary>
            public const string ShipViaCode = "SHPVIACODE";

            /// <summary>
            /// Property for ShipViaDescription
            /// </summary>
            public const string ShipViaDescription = "SHPVIADESC";

            /// <summary>
            /// Property for DeliveryMethod
            /// </summary>
            public const string DeliveryMethod = "DELMETHOD";

            /// <summary>
            /// Property for PrimaryShipToLocation
            /// </summary>
            public const string PrimaryShipToLocation = "PRIMSHIPTO";

            /// <summary>
            /// Property for ContactsPhone
            /// </summary>
            public const string ContactsPhone = "CTACPHONE";

            /// <summary>
            /// Property for ContactsFax
            /// </summary>
            public const string ContactsFax = "CTACFAX";

            /// <summary>
            /// Property for AllowPartialShipments
            /// </summary>
            public const string AllowPartialShipments = "SWPARTSHIP";

            /// <summary>
            /// Property for AllowWebStoreShopping
            /// </summary>
            public const string AllowWebStoreShopping = "SWWEBSHOP";

            /// <summary>
            /// Property for PercentRetained
            /// </summary>
            public const string PercentRetained = "RTGPERCENT";

            /// <summary>
            /// Property for DaysRetained
            /// </summary>
            public const string DaysRetained = "RTGDAYS";

            /// <summary>
            /// Property for RetainageTermsCode
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";

            /// <summary>
            /// Property for AmountRetainedCustCurr
            /// </summary>
            public const string AmountRetainedCustCurr = "RTGAMTTC";

            /// <summary>
            /// Property for AmountRetainedFuncCurr
            /// </summary>
            public const string AmountRetainedFuncCurr = "RTGAMTHC";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for ProcessCommandCode
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for NumberofOpenPrepayments
            /// </summary>
            public const string NumberofOpenPrepayments = "CNTPPDINVC";

            /// <summary>
            /// Property for AmountPrepaidCustCurr
            /// </summary>
            public const string AmountPrepaidCustCurr = "AMTPPDINVT";

            /// <summary>
            /// Property for AmountPrepaidFuncCurr
            /// </summary>
            public const string AmountPrepaidFuncCurr = "AMTPPDINVH";

            /// <summary>
            /// Property for DateofLastRefund
            /// </summary>
            public const string DateofLastRefund = "DATELASTRF";

            /// <summary>
            /// Property for LastRefundAmtCustCurr
            /// </summary>
            public const string LastRefundAmtCustCurr = "AMTLASTRFT";

            /// <summary>
            /// Property for LastRefundAmtFuncCurr
            /// </summary>
            public const string LastRefundAmtFuncCurr = "AMTLASTRFH";

            /// <summary>
            /// Property for CheckLanguage
            /// </summary>
            public const string CheckLanguage = "CODECHECK";

            /// <summary>
            /// Property for NextClientUniqueID
            /// </summary>
            public const string NextClientUniqueID = "NEXTCUID";

            /// <summary>
            /// Property for InventoryLocation
            /// </summary>
            public const string InventoryLocation = "LOCATION";

            /// <summary>
            /// Property for CheckCreditLimit
            /// </summary>
            public const string CheckCreditLimit = "SWCHKLIMIT";

            /// <summary>
            /// Property for CheckOverdueAmounts
            /// </summary>
            public const string CheckOverdueAmounts = "SWCHKOVER";

            /// <summary>
            /// Property for DaysOverdue
            /// </summary>
            public const string DaysOverdue = "OVERDAYS";

            /// <summary>
            /// Property for AmountOverdue
            /// </summary>
            public const string AmountOverdue = "OVERAMT";

            /// <summary>
            /// Property for AllowBackorderQuantities
            /// </summary>
            public const string AllowBackorderQuantities = "SWBACKORDR";

            /// <summary>
            /// Property for CheckforDuplicatePOs
            /// </summary>
            public const string CheckforDuplicatePOs = "SWCHKDUPPO";

            /// <summary>
            /// Property for SuppressIntegration
            /// </summary>
            public const string SuppressIntegration = "EWSUPPRESS";

            /// <summary>
            /// Property for AOrRVersion
            /// </summary>
            public const string AOrRVersion = "EWARVER";

            /// <summary>
            /// Property for Database
            /// </summary>
            public const string Database = "EWORGID";

            /// <summary>
            /// Property for Mode
            /// </summary>
            public const string Mode = "EWMODE";

            /// <summary>
            /// Property for SageBillingandPaymentCustomer
            /// </summary>
            public const string SageBillingandPaymentCustomer = "CATEGORY";

            /// <summary>
            /// Property for BusinessRegistrationNumber
            /// </summary>
            public const string BusinessRegistrationNumber = "BRN";

            /// <summary>
            /// Property for CRMUpdateMode
            /// </summary>
            public const string CRMUpdateMode = "EWCTACMODE";

            #endregion Properties
        }

        /// <summary>
        /// Contains list of Customers Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for ShortName
            /// </summary>
            public const int ShortName = 2;

            /// <summary>
            /// Property Indexer for GroupCode
            /// </summary>
            public const int GroupCode = 3;

            /// <summary>
            /// Property Indexer for NationalAccount
            /// </summary>
            public const int NationalAccount = 4;

            /// <summary>
            /// Property Indexer for Status
            /// </summary>
            public const int Status = 5;

            /// <summary>
            /// Property Indexer for InactiveDate
            /// </summary>
            public const int InactiveDate = 6;

            /// <summary>
            /// Property Indexer for DateLastMaintained
            /// </summary>
            public const int DateLastMaintained = 7;

            /// <summary>
            /// Property Indexer for OnHold
            /// </summary>
            public const int OnHold = 8;

            /// <summary>
            /// Property Indexer for StartDate
            /// </summary>
            public const int StartDate = 9;

            /// <summary>
            /// Property Indexer for CreditBureauNumber
            /// </summary>
            public const int CreditBureauNumber = 11;

            /// <summary>
            /// Property Indexer for CreditBureauRating
            /// </summary>
            public const int CreditBureauRating = 12;

            /// <summary>
            /// Property Indexer for CreditBureauDate
            /// </summary>
            public const int CreditBureauDate = 13;

            /// <summary>
            /// Property Indexer for CustomerName
            /// </summary>
            public const int CustomerName = 14;

            /// <summary>
            /// Property Indexer for AddressLine1
            /// </summary>
            public const int AddressLine1 = 15;

            /// <summary>
            /// Property Indexer for AddressLine2
            /// </summary>
            public const int AddressLine2 = 16;

            /// <summary>
            /// Property Indexer for AddressLine3
            /// </summary>
            public const int AddressLine3 = 17;

            /// <summary>
            /// Property Indexer for AddressLine4
            /// </summary>
            public const int AddressLine4 = 18;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 19;

            /// <summary>
            /// Property Indexer for StateOrProv
            /// </summary>
            public const int StateOrProv = 20;

            /// <summary>
            /// Property Indexer for ZipOrPostalCode
            /// </summary>
            public const int ZipOrPostalCode = 21;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 22;

            /// <summary>
            /// Property Indexer for ContactName
            /// </summary>
            public const int ContactName = 23;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 24;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 25;

            /// <summary>
            /// Property Indexer for TerritoryCode
            /// </summary>
            public const int TerritoryCode = 26;

            /// <summary>
            /// Property Indexer for AccountSet
            /// </summary>
            public const int AccountSet = 27;

            /// <summary>
            /// Property Indexer for AutocashProfile
            /// </summary>
            public const int AutocashProfile = 28;

            /// <summary>
            /// Property Indexer for BillingCycle
            /// </summary>
            public const int BillingCycle = 29;

            /// <summary>
            /// Property Indexer for InterestProfile
            /// </summary>
            public const int InterestProfile = 30;

            /// <summary>
            /// Property Indexer for CurrencyCode
            /// </summary>
            public const int CurrencyCode = 32;

            /// <summary>
            /// Property Indexer for PrintStatements
            /// </summary>
            public const int PrintStatements = 33;

            /// <summary>
            /// Property Indexer for AccountType
            /// </summary>
            public const int AccountType = 35;

            /// <summary>
            /// Property Indexer for Terms
            /// </summary>
            public const int Terms = 36;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 37;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 38;

            /// <summary>
            /// Property Indexer for TaxRegistrationNo1
            /// </summary>
            public const int TaxRegistrationNo1 = 39;

            /// <summary>
            /// Property Indexer for TaxRegistrationNo2
            /// </summary>
            public const int TaxRegistrationNo2 = 40;

            /// <summary>
            /// Property Indexer for TaxRegistrationNo3
            /// </summary>
            public const int TaxRegistrationNo3 = 41;

            /// <summary>
            /// Property Indexer for TaxRegistrationNo4
            /// </summary>
            public const int TaxRegistrationNo4 = 42;

            /// <summary>
            /// Property Indexer for TaxRegistrationNo5
            /// </summary>
            public const int TaxRegistrationNo5 = 43;

            /// <summary>
            /// Property Indexer for TaxClassCode1
            /// </summary>
            public const int TaxClassCode1 = 44;

            /// <summary>
            /// Property Indexer for TaxClassCode2
            /// </summary>
            public const int TaxClassCode2 = 45;

            /// <summary>
            /// Property Indexer for TaxClassCode3
            /// </summary>
            public const int TaxClassCode3 = 46;

            /// <summary>
            /// Property Indexer for TaxClassCode4
            /// </summary>
            public const int TaxClassCode4 = 47;

            /// <summary>
            /// Property Indexer for TaxClassCode5
            /// </summary>
            public const int TaxClassCode5 = 48;

            /// <summary>
            /// Property Indexer for CreditLimitCustCurr
            /// </summary>
            public const int CreditLimitCustCurr = 49;

            /// <summary>
            /// Property Indexer for BalanceDueinCustCurr
            /// </summary>
            public const int BalanceDueinCustCurr = 50;

            /// <summary>
            /// Property Indexer for BalanceDueinFuncCurr
            /// </summary>
            public const int BalanceDueinFuncCurr = 51;

            /// <summary>
            /// Property Indexer for DateofLastStatement
            /// </summary>
            public const int DateofLastStatement = 52;

            /// <summary>
            /// Property Indexer for LastStatementTotalCustCurr
            /// </summary>
            public const int LastStatementTotalCustCurr = 53;

            /// <summary>
            /// Property Indexer for DateofLastBalFwdStatement
            /// </summary>
            public const int DateofLastBalFwdStatement = 55;

            /// <summary>
            /// Property Indexer for BeginningBalonLastStatement
            /// </summary>
            public const int BeginningBalonLastStatement = 56;

            /// <summary>
            /// Property Indexer for DateofLastRevaluation
            /// </summary>
            public const int DateofLastRevaluation = 58;

            /// <summary>
            /// Property Indexer for LastRevaluationBalance
            /// </summary>
            public const int LastRevaluationBalance = 59;

            /// <summary>
            /// Property Indexer for NumberofOpenDocuments
            /// </summary>
            public const int NumberofOpenDocuments = 60;

            /// <summary>
            /// Property Indexer for NumberofPaidInvoices
            /// </summary>
            public const int NumberofPaidInvoices = 61;

            /// <summary>
            /// Property Indexer for NumberofDaystoPay
            /// </summary>
            public const int NumberofDaystoPay = 62;

            /// <summary>
            /// Property Indexer for DateofLargestInvoice
            /// </summary>
            public const int DateofLargestInvoice = 63;

            /// <summary>
            /// Property Indexer for DateofHighestBalance
            /// </summary>
            public const int DateofHighestBalance = 64;

            /// <summary>
            /// Property Indexer for DateofLargestInvoiceLastYr
            /// </summary>
            public const int DateofLargestInvoiceLastYr = 65;

            /// <summary>
            /// Property Indexer for DateofHighestBalanceLastYr
            /// </summary>
            public const int DateofHighestBalanceLastYr = 66;

            /// <summary>
            /// Property Indexer for DateofLastActivity
            /// </summary>
            public const int DateofLastActivity = 67;

            /// <summary>
            /// Property Indexer for DateofLastInvoice
            /// </summary>
            public const int DateofLastInvoice = 68;

            /// <summary>
            /// Property Indexer for DateofLastCreditNote
            /// </summary>
            public const int DateofLastCreditNote = 69;

            /// <summary>
            /// Property Indexer for DateofLastDebitNote
            /// </summary>
            public const int DateofLastDebitNote = 70;

            /// <summary>
            /// Property Indexer for DateofLastReceipt
            /// </summary>
            public const int DateofLastReceipt = 71;

            /// <summary>
            /// Property Indexer for DateofLastDiscount
            /// </summary>
            public const int DateofLastDiscount = 72;

            /// <summary>
            /// Property Indexer for DateofLastAdjustment
            /// </summary>
            public const int DateofLastAdjustment = 73;

            /// <summary>
            /// Property Indexer for DateofLastWriteOff
            /// </summary>
            public const int DateofLastWriteOff = 74;

            /// <summary>
            /// Property Indexer for DateofLastReturnedCheck
            /// </summary>
            public const int DateofLastReturnedCheck = 75;

            /// <summary>
            /// Property Indexer for DateofLastInterestCharge
            /// </summary>
            public const int DateofLastInterestCharge = 76;

            /// <summary>
            /// Property Indexer for LargestInvoiceNumber
            /// </summary>
            public const int LargestInvoiceNumber = 78;

            /// <summary>
            /// Property Indexer for LargestInvoiceNumberLastYr
            /// </summary>
            public const int LargestInvoiceNumberLastYr = 79;

            /// <summary>
            /// Property Indexer for LargestInvoiceCustCurr
            /// </summary>
            public const int LargestInvoiceCustCurr = 80;

            /// <summary>
            /// Property Indexer for HighestBalanceCustCurr
            /// </summary>
            public const int HighestBalanceCustCurr = 81;

            /// <summary>
            /// Property Indexer for LgstInvLastYrCustCurr
            /// </summary>
            public const int LgstInvLastYrCustCurr = 82;

            /// <summary>
            /// Property Indexer for HighBalLastYrCustCurr
            /// </summary>
            public const int HighBalLastYrCustCurr = 83;

            /// <summary>
            /// Property Indexer for LastInvoiceAmtCustCurr
            /// </summary>
            public const int LastInvoiceAmtCustCurr = 84;

            /// <summary>
            /// Property Indexer for LastCrNoteAmtCustCurr
            /// </summary>
            public const int LastCrNoteAmtCustCurr = 85;

            /// <summary>
            /// Property Indexer for LastDrNoteAmtCustCurr
            /// </summary>
            public const int LastDrNoteAmtCustCurr = 86;

            /// <summary>
            /// Property Indexer for LastReceiptCustCurr
            /// </summary>
            public const int LastReceiptCustCurr = 87;

            /// <summary>
            /// Property Indexer for LastDiscountAmtCustCurr
            /// </summary>
            public const int LastDiscountAmtCustCurr = 88;

            /// <summary>
            /// Property Indexer for LastAdjAmtCustCurr
            /// </summary>
            public const int LastAdjAmtCustCurr = 89;

            /// <summary>
            /// Property Indexer for LastWriteOffAmtCustCurr
            /// </summary>
            public const int LastWriteOffAmtCustCurr = 90;

            /// <summary>
            /// Property Indexer for LastRetdChkAmtCustCurr
            /// </summary>
            public const int LastRetdChkAmtCustCurr = 91;

            /// <summary>
            /// Property Indexer for LastIntChargeCustCurr
            /// </summary>
            public const int LastIntChargeCustCurr = 92;

            /// <summary>
            /// Property Indexer for LargestInvoiceFuncCurr
            /// </summary>
            public const int LargestInvoiceFuncCurr = 93;

            /// <summary>
            /// Property Indexer for HighestBalanceFuncCurr
            /// </summary>
            public const int HighestBalanceFuncCurr = 94;

            /// <summary>
            /// Property Indexer for LgstInvLastYrFuncCurr
            /// </summary>
            public const int LgstInvLastYrFuncCurr = 95;

            /// <summary>
            /// Property Indexer for HighBalLastYrFuncCurr
            /// </summary>
            public const int HighBalLastYrFuncCurr = 96;

            /// <summary>
            /// Property Indexer for LastInvoiceAmtFuncCurr
            /// </summary>
            public const int LastInvoiceAmtFuncCurr = 97;

            /// <summary>
            /// Property Indexer for LastCrNoteAmtFuncCurr
            /// </summary>
            public const int LastCrNoteAmtFuncCurr = 98;

            /// <summary>
            /// Property Indexer for LastDrNoteAmtFuncCurr
            /// </summary>
            public const int LastDrNoteAmtFuncCurr = 99;

            /// <summary>
            /// Property Indexer for LastReceiptFuncCurr
            /// </summary>
            public const int LastReceiptFuncCurr = 100;

            /// <summary>
            /// Property Indexer for LastDiscountAmtFuncCurr
            /// </summary>
            public const int LastDiscountAmtFuncCurr = 101;

            /// <summary>
            /// Property Indexer for LastAdjAmtFuncCurr
            /// </summary>
            public const int LastAdjAmtFuncCurr = 102;

            /// <summary>
            /// Property Indexer for LastWriteOffAmtFuncCurr
            /// </summary>
            public const int LastWriteOffAmtFuncCurr = 103;

            /// <summary>
            /// Property Indexer for LastRetdChkAmtFuncCurr
            /// </summary>
            public const int LastRetdChkAmtFuncCurr = 104;

            /// <summary>
            /// Property Indexer for LastIntChargeFuncCurr
            /// </summary>
            public const int LastIntChargeFuncCurr = 105;

            /// <summary>
            /// Property Indexer for Salesperson1
            /// </summary>
            public const int Salesperson1 = 106;

            /// <summary>
            /// Property Indexer for Salesperson2
            /// </summary>
            public const int Salesperson2 = 107;

            /// <summary>
            /// Property Indexer for Salesperson3
            /// </summary>
            public const int Salesperson3 = 108;

            /// <summary>
            /// Property Indexer for Salesperson4
            /// </summary>
            public const int Salesperson4 = 109;

            /// <summary>
            /// Property Indexer for Salesperson5
            /// </summary>
            public const int Salesperson5 = 110;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage1
            /// </summary>
            public const int SalesSplitPercentage1 = 111;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage2
            /// </summary>
            public const int SalesSplitPercentage2 = 112;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage3
            /// </summary>
            public const int SalesSplitPercentage3 = 113;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage4
            /// </summary>
            public const int SalesSplitPercentage4 = 114;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage5
            /// </summary>
            public const int SalesSplitPercentage5 = 115;

            /// <summary>
            /// Property Indexer for AverageDaysToPay
            /// </summary>
            public const int AverageDaysToPay = 124;

            /// <summary>
            /// Property Indexer for CustomerPriceList
            /// </summary>
            public const int CustomerPriceList = 125;

            /// <summary>
            /// Property Indexer for CustomerDiscountType
            /// </summary>
            public const int CustomerDiscountType = 126;

            /// <summary>
            /// Property Indexer for AmountPastDue
            /// </summary>
            public const int AmountPastDue = 127;

            /// <summary>
            /// Property Indexer for ContactsEmail
            /// </summary>
            public const int ContactsEmail = 128;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 129;

            /// <summary>
            /// Property Indexer for WebSite
            /// </summary>
            public const int WebSite = 130;

            /// <summary>
            /// Property Indexer for BillingMethod
            /// </summary>
            public const int BillingMethod = 131;

            /// <summary>
            /// Property Indexer for PaymentCode
            /// </summary>
            public const int PaymentCode = 135;

            /// <summary>
            /// Property Indexer for FreeOnBoard
            /// </summary>
            public const int FreeOnBoard = 136;

            /// <summary>
            /// Property Indexer for ShipViaCode
            /// </summary>
            public const int ShipViaCode = 137;

            /// <summary>
            /// Property Indexer for ShipViaDescription
            /// </summary>
            public const int ShipViaDescription = 138;

            /// <summary>
            /// Property Indexer for DeliveryMethod
            /// </summary>
            public const int DeliveryMethod = 139;

            /// <summary>
            /// Property Indexer for PrimaryShipToLocation
            /// </summary>
            public const int PrimaryShipToLocation = 140;

            /// <summary>
            /// Property Indexer for ContactsPhone
            /// </summary>
            public const int ContactsPhone = 141;

            /// <summary>
            /// Property Indexer for ContactsFax
            /// </summary>
            public const int ContactsFax = 142;

            /// <summary>
            /// Property Indexer for AllowPartialShipments
            /// </summary>
            public const int AllowPartialShipments = 143;

            /// <summary>
            /// Property Indexer for AllowWebStoreShopping
            /// </summary>
            public const int AllowWebStoreShopping = 144;

            /// <summary>
            /// Property Indexer for PercentRetained
            /// </summary>
            public const int PercentRetained = 145;

            /// <summary>
            /// Property Indexer for DaysRetained
            /// </summary>
            public const int DaysRetained = 146;

            /// <summary>
            /// Property Indexer for RetainageTermsCode
            /// </summary>
            public const int RetainageTermsCode = 147;

            /// <summary>
            /// Property Indexer for AmountRetainedCustCurr
            /// </summary>
            public const int AmountRetainedCustCurr = 148;

            /// <summary>
            /// Property Indexer for AmountRetainedFuncCurr
            /// </summary>
            public const int AmountRetainedFuncCurr = 149;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 150;

            /// <summary>
            /// Property Indexer for ProcessCommandCode
            /// </summary>
            public const int ProcessCommandCode = 151;

            /// <summary>
            /// Property Indexer for NumberofOpenPrepayments
            /// </summary>
            public const int NumberofOpenPrepayments = 152;

            /// <summary>
            /// Property Indexer for AmountPrepaidCustCurr
            /// </summary>
            public const int AmountPrepaidCustCurr = 153;

            /// <summary>
            /// Property Indexer for AmountPrepaidFuncCurr
            /// </summary>
            public const int AmountPrepaidFuncCurr = 154;

            /// <summary>
            /// Property Indexer for DateofLastRefund
            /// </summary>
            public const int DateofLastRefund = 155;

            /// <summary>
            /// Property Indexer for LastRefundAmtCustCurr
            /// </summary>
            public const int LastRefundAmtCustCurr = 156;

            /// <summary>
            /// Property Indexer for LastRefundAmtFuncCurr
            /// </summary>
            public const int LastRefundAmtFuncCurr = 157;

            /// <summary>
            /// Property Indexer for CheckLanguage
            /// </summary>
            public const int CheckLanguage = 158;

            /// <summary>
            /// Property Indexer for NextClientUniqueID
            /// </summary>
            public const int NextClientUniqueID = 159;

            /// <summary>
            /// Property Indexer for InventoryLocation
            /// </summary>
            public const int InventoryLocation = 160;

            /// <summary>
            /// Property Indexer for CheckCreditLimit
            /// </summary>
            public const int CheckCreditLimit = 161;

            /// <summary>
            /// Property Indexer for CheckOverdueAmounts
            /// </summary>
            public const int CheckOverdueAmounts = 162;

            /// <summary>
            /// Property Indexer for DaysOverdue
            /// </summary>
            public const int DaysOverdue = 163;

            /// <summary>
            /// Property Indexer for AmountOverdue
            /// </summary>
            public const int AmountOverdue = 164;

            /// <summary>
            /// Property Indexer for AllowBackorderQuantities
            /// </summary>
            public const int AllowBackorderQuantities = 167;

            /// <summary>
            /// Property Indexer for CheckforDuplicatePOs
            /// </summary>
            public const int CheckforDuplicatePOs = 168;

            /// <summary>
            /// Property Indexer for SuppressIntegration
            /// </summary>
            public const int SuppressIntegration = 169;

            /// <summary>
            /// Property Indexer for AOrRVersion
            /// </summary>
            public const int AOrRVersion = 170;

            /// <summary>
            /// Property Indexer for Database
            /// </summary>
            public const int Database = 171;

            /// <summary>
            /// Property Indexer for Mode
            /// </summary>
            public const int Mode = 172;

            /// <summary>
            /// Property Indexer for SageBillingandPaymentCustomer
            /// </summary>
            public const int SageBillingandPaymentCustomer = 173;

            /// <summary>
            /// Property Indexer for BusinessRegistrationNumber
            /// </summary>
            public const int BusinessRegistrationNumber = 174;

            /// <summary>
            /// Property Indexer for CRMUpdateMode
            /// </summary>
            public const int CRMUpdateMode = 175;

            #endregion Properties
        }
    }
}