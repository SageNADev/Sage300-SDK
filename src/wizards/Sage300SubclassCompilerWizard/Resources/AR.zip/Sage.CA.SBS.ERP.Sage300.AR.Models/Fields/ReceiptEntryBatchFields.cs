// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Field-name, field-index and entity constants for business entity Receipt and Adjustment Batches (rotoview AR0041 - ARBTA).
    /// </summary>
    public partial class ReceiptEntryBatch
    {
        #region Entity

        /// <summary>
        /// The Roto ID of the underlying view (AR0041).
        /// </summary>
        /// <remarks>
        /// The name of the underlying view is ARBTA.
        /// </remarks>
        public const string EntityName = "AR0041";

        #endregion

        #region Fields

        /// <summary>
        /// Contains list of ReceiptEntryBatch Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CodePaymentType 
            /// </summary>
            public const string PaymentType = "CODEPYMTYP";

            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";

            /// <summary>
            /// Property for BatchDate 
            /// </summary>
            public const string BatchDate = "DATEBTCH";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "BATCHDESC";

            /// <summary>
            /// Property for NumberofEntries 
            /// </summary>
            public const string NumberofEntries = "CNTENTER";

            /// <summary>
            /// Property for BatchTotal 
            /// </summary>
            public const string BatchTotal = "AMTENTER";

            /// <summary>
            /// Property for BatchType 
            /// </summary>
            public const string BatchType = "BATCHTYPE";

            /// <summary>
            /// Property for BatchStatus 
            /// </summary>
            public const string BatchStatus = "BATCHSTAT";

            /// <summary>
            /// Property for BatchStatus 
            /// </summary>
            public const string StatusString = "BATCHSTAT";

            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "IDBANK";

            /// <summary>
            /// Property for DepositSlipPrinted 
            /// </summary>
            public const string DepositSlipPrinted = "SWPRTDEP";

            /// <summary>
            /// Property for DefaultBankCurrency 
            /// </summary>
            public const string DefaultBankCurrency = "CODECURN";

            /// <summary>
            /// Property for BankRateDate 
            /// </summary>
            public const string BankRateDate = "DATERATE";

            /// <summary>
            /// Property for LastEntryNumber 
            /// </summary>
            public const string LastEntryNumber = "CNTLASTITM";

            /// <summary>
            /// Property for BankRateType 
            /// </summary>
            public const string BankRateType = "RATETYPE";

            /// <summary>
            /// Property for BankExchangeRate 
            /// </summary>
            public const string BankExchangeRate = "RATEEXCHHC";

            /// <summary>
            /// Property for DepositNumber 
            /// </summary>
            public const string DepositNumber = "DEPSTNBR";

            /// <summary>
            /// Property for DepositSerialNumber 
            /// </summary>
            public const string DepositSerialNumber = "DEPSEQ";

            /// <summary>
            /// Property for FuncAdjustmentAmount 
            /// </summary>
            public const string FuncAdjustmentAmount = "ADJUSTAMT";

            /// <summary>
            /// Property for FuncAppliedDocAmount 
            /// </summary>
            public const string FuncAppliedDocAmount = "REAPLYAMT";

            /// <summary>
            /// Property for FuncBatchTotal 
            /// </summary>
            public const string FuncBatchTotal = "FUNCAMOUNT";

            /// <summary>
            /// Property for PostingSequenceNo 
            /// </summary>
            public const string PostingSequenceNo = "POSTSEQNBR";

            /// <summary>
            /// Property for NumberofErrors 
            /// </summary>
            public const string NumberofErrors = "NBRERRORS";

            /// <summary>
            /// Property for DateLastEdited 
            /// </summary>
            public const string DateLastEdited = "DATELSTEDT";

            /// <summary>
            /// Property for BatchTypeClass 
            /// </summary>
            public const string BatchTypeClass = "TYPECLASS";

            /// <summary>
            /// Property for BatchPrintedFlag 
            /// </summary>
            public const string BatchPrintedFlag = "SWPRINTED";

            /// <summary>
            /// Property for BankRateOperator 
            /// </summary>
            public const string BankRateOperator = "RATEOP";

            /// <summary>
            /// Property for BankRateOverridden 
            /// </summary>
            public const string BankRateOverridden = "SWRATE";

            /// <summary>
            /// Property for SourceApplication 
            /// </summary>
            public const string SourceApplication = "SRCEAPPL";

            /// <summary>
            /// Property for ProcessCommand 
            /// </summary>
            public const string ProcessCommand = "PROCESSCMD";

            /// <summary>
            /// Property for DepositDate 
            /// </summary>
            public const string DepositDate = "DEPDATE";

            /// <summary>
            /// Property for DepositComment 
            /// </summary>
            public const string DepositComment = "DEPCOMMENT";

            /// <summary>
            /// Property for NumberofReapplies 
            /// </summary>
            public const string NumberofReapplies = "CNTREAPPLY";

            #endregion
        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of ReceiptEntryBatch Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CodePaymentType 
            /// </summary>
            public const int PaymentType = 1;

            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 2;

            /// <summary>
            /// Property Indexer for BatchDate 
            /// </summary>
            public const int BatchDate = 3;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 4;

            /// <summary>
            /// Property Indexer for NumberofEntries 
            /// </summary>
            public const int NumberofEntries = 5;

            /// <summary>
            /// Property Indexer for BatchTotal 
            /// </summary>
            public const int BatchTotal = 6;

            /// <summary>
            /// Property Indexer for BatchType
            /// </summary>
            public const int BatchType = 7;

            /// <summary>
            /// Property Indexer for BatchStatus 
            /// </summary>
            public const int BatchStatus = 8;

            /// <summary>
            /// Property Indexer for BatchStatus 
            /// </summary>
            public const int StatusString = 8;

            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 9;

            /// <summary>
            /// Property Indexer for DepositSlipPrinted 
            /// </summary>
            public const int DepositSlipPrinted = 10;

            /// <summary>
            /// Property Indexer for DefaultBankCurrency 
            /// </summary>
            public const int DefaultBankCurrency = 11;

            /// <summary>
            /// Property Indexer for BankRateDate 
            /// </summary>
            public const int BankRateDate = 12;

            /// <summary>
            /// Property Indexer for LastEntryNumber 
            /// </summary>
            public const int LastEntryNumber = 13;

            /// <summary>
            /// Property Indexer for BankRateType 
            /// </summary>
            public const int BankRateType = 14;

            /// <summary>
            /// Property Indexer for BankExchangeRate 
            /// </summary>
            public const int BankExchangeRate = 15;

            /// <summary>
            /// Property Indexer for DepositNumber 
            /// </summary>
            public const int DepositNumber = 16;

            /// <summary>
            /// Property Indexer for DepositSerialNumber 
            /// </summary>
            public const int DepositSerialNumber = 17;

            /// <summary>
            /// Property Indexer for FuncAdjustmentAmount 
            /// </summary>
            public const int FuncAdjustmentAmount = 18;

            /// <summary>
            /// Property Indexer for FuncAppliedDocAmount 
            /// </summary>
            public const int FuncAppliedDocAmount = 19;

            /// <summary>
            /// Property Indexer for FuncBatchTotal 
            /// </summary>
            public const int FuncBatchTotal = 20;

            /// <summary>
            /// Property Indexer for PostingSequenceNo 
            /// </summary>
            public const int PostingSequenceNo = 21;

            /// <summary>
            /// Property Indexer for NumberofErrors 
            /// </summary>
            public const int NumberofErrors = 22;

            /// <summary>
            /// Property Indexer for DateLastEdited 
            /// </summary>
            public const int DateLastEdited = 23;

            /// <summary>
            /// Property Indexer for BatchTypeClass 
            /// </summary>
            public const int BatchTypeClass = 24;

            /// <summary>
            /// Property Indexer for BatchPrintedFlag 
            /// </summary>
            public const int BatchPrintedFlag = 25;

            /// <summary>
            /// Property Indexer for BankRateOperator 
            /// </summary>
            public const int BankRateOperator = 26;

            /// <summary>
            /// Property Indexer for BankRateOverridden 
            /// </summary>
            public const int BankRateOverridden = 27;

            /// <summary>
            /// Property Indexer for SourceApplication 
            /// </summary>
            public const int SourceApplication = 28;

            /// <summary>
            /// Property Indexer for ProcessCommand 
            /// </summary>
            public const int ProcessCommand = 29;

            /// <summary>
            /// Property Indexer for DepositDate 
            /// </summary>
            public const int DepositDate = 30;

            /// <summary>
            /// Property Indexer for DepositComment 
            /// </summary>
            public const int DepositComment = 31;

            /// <summary>
            /// Property Indexer for NumberofReapplies 
            /// </summary>
            public const int NumberofReapplies = 32;

            #endregion
        }

        #endregion
    }
}