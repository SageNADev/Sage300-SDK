/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of Interest Rates by Currency Constants 
    /// </summary>
    public partial class InterestRatesByCurrency
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0019";

        /// <summary>
        /// Contains list of InterestRatesbyCurrency Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for InterestProfile 
            /// </summary>
            public const string InterestProfile = "CODESVCCHR";
            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CODECURN";
            /// <summary>
            /// Property for MinimumInterestCharge 
            /// </summary>
            public const string MinimumInterestCharge = "AMTMINCHG";
            /// <summary>
            /// Property for AnnualInterestRate 
            /// </summary>
            public const string AnnualInterestRate = "RTESVCCHRG";

            #endregion
        }

        /// <summary>
        /// Contains list of InterestRatesbyCurrency Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for InterestProfile 
            /// </summary>
            public const int InterestProfile = 1;
            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 2;
            /// <summary>
            /// Property Indexer for MinimumInterestCharge 
            /// </summary>
            public const int MinimumInterestCharge = 3;
            /// <summary>
            /// Property Indexer for AnnualInterestRate 
            /// </summary>
            public const int AnnualInterestRate = 4;

            #endregion
        }
    }
}
