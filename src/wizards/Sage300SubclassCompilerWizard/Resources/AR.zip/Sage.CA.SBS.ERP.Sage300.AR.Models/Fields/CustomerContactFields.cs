// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CustomerContacts Constants
    /// </summary>
    public partial class CustomerContact
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0220";

        /// <summary>
        /// Contains list of Customer Contact Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for ContactCode
            /// </summary>
            public const string ContactCode = "IDCONTACT";

            /// <summary>
            /// Property for ContactName
            /// </summary>
            public const string ContactName = "DISPLAYNAM";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "EMAIL";

            /// <summary>
            /// Property for ContactStatus
            /// </summary>
            public const string ContactStatus = "SWACTV";

            /// <summary>
            /// Property for ConsentsToEmail
            /// </summary>
            public const string ConsentsToEmail = "SWOKEMAIL";

            /// <summary>
            /// Property for EmailSeparator
            /// </summary>
            public const string EmailSeparator = "SEPARATOR";

            #endregion

        }

        /// <summary>
        /// Contains list of CustomerContacts Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for ContactID
            /// </summary>
            public const int ContactCode = 2;

            /// <summary>
            /// Property Indexer for DisplayName
            /// </summary>
            public const int ContactName = 3;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 4;

            /// <summary>
            /// Property Indexer for ContactStatus
            /// </summary>
            public const int ContactStatus = 5;

            /// <summary>
            /// Property Indexer for ConsentsToEmail
            /// </summary>
            public const int ConsentsToEmail = 6;

            /// <summary>
            /// Property Indexer for EmailSeparator
            /// </summary>
            public const int EmailSeparator = 7;

            #endregion Properties
        }
    }
}