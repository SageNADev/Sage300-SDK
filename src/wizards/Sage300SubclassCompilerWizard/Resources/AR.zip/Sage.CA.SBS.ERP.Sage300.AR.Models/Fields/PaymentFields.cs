// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Contains list of Payment Constants
	/// </summary>
	public partial class Payment
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "AR0139";

		/// <summary>
		/// Dynamic Attributes contain a reverse mapping of field and property
		/// </summary>
		[IgnoreExportImport]
		public static Dictionary<string, string> DynamicAttributes
		{
			get
			{
				return new Dictionary<string, string>
				{
				};
			}
		}

		#region Properties

		/// <summary>
		/// Contains list of Payment Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for CustomerNumber
			/// </summary>
			public const string CustomerNumber = "IDCUST";

			/// <summary>
			/// Property for DocumentNumber
			/// </summary>
			public const string DocumentNumber = "IDINVC";

			/// <summary>
			/// Property for SeqNo
			/// </summary>
			public const string SeqNo = "CNTSEQ";

			/// <summary>
			/// Property for PaymentCode
			/// </summary>
			public const string PaymentCode = "PAYMCODE";

			/// <summary>
			/// Property for PaymentType
			/// </summary>
			public const string PaymentType = "PAYMTYPE";

			/// <summary>
			/// Property for DocumentDate
			/// </summary>
			public const string DocumentDate = "DOCDATE";

			/// <summary>
			/// Property for FiscalYear
			/// </summary>
			public const string FiscalYear = "FISCYR";

			/// <summary>
			/// Property for FiscalPeriod
			/// </summary>
			public const string FiscalPeriod = "FISCPER";

			/// <summary>
			/// Property for BankCode
			/// </summary>
			public const string BankCode = "IDBANK";

			/// <summary>
			/// Property for CheckNumber
			/// </summary>
			public const string CheckNumber = "CHECKNUM";

			/// <summary>
			/// Property for CheckSerialNumber
			/// </summary>
			public const string CheckSerialNumber = "LONGSERIAL";

			/// <summary>
			/// Property for GLAccountTobeCredited
			/// </summary>
			public const string GLAccountTobeCredited = "IDACCT";

			/// <summary>
			/// Property for NameonCheck
			/// </summary>
			public const string NameonCheck = "NAMERMIT";

			/// <summary>
			/// Property for CheckLanguage
			/// </summary>
			public const string CheckLanguage = "CHECKLANG";

			/// <summary>
			/// Property for PaymentCurrency
			/// </summary>
			public const string PaymentCurrency = "CODECURN";

			/// <summary>
			/// Property for RateType
			/// </summary>
			public const string RateType = "RATETYPE";

			/// <summary>
			/// Property for RateDate
			/// </summary>
			public const string RateDate = "RATEDATE";

			/// <summary>
			/// Property for ExchangeRate
			/// </summary>
			public const string ExchangeRate = "RATEEXCH";

			/// <summary>
			/// Property for RateOperator
			/// </summary>
			public const string RateOperator = "RATEOP";

			/// <summary>
			/// Property for RateOverrideFlag
			/// </summary>
			public const string RateOverrideFlag = "SWRATE";

			/// <summary>
			/// Property for PaymentAmount
			/// </summary>
			public const string PaymentAmount = "AMTPC";

			/// <summary>
			/// Property for CustomerAmount
			/// </summary>
			public const string CustomerAmount = "AMTTC";

			/// <summary>
			/// Property for FunctionalAmount
			/// </summary>
			public const string FunctionalAmount = "AMTHC";

			/// <summary>
			/// Property for PostingSequenceNumber
			/// </summary>
			public const string PostingSequenceNumber = "POSTSEQNBR";

			/// <summary>
			/// Property for BatchNumber
			/// </summary>
			public const string BatchNumber = "CNTBTCH";

			/// <summary>
			/// Property for EntryNumber
			/// </summary>
			public const string EntryNumber = "CNTITEM";

			/// <summary>
			/// Property for PaymentStatus
			/// </summary>
			public const string PaymentStatus = "SWSTATUS";

			/// <summary>
			/// Property for DateCleared
			/// </summary>
			public const string DateCleared = "DATECLRD";

			/// <summary>
			/// Property for DateReversed
			/// </summary>
			public const string DateReversed = "DATERVRSD";

			/// <summary>
			/// Property for ReasonForReturn
			/// </summary>
			public const string ReasonForReturn = "TEXTRETRN";

			/// <summary>
			/// Property for DocumentType
			/// </summary>
			public const string DocumentType = "TRXTYPETXT";

			/// <summary>
			/// Property for ClientUniqueID
			/// </summary>
			public const string ClientUniqueID = "CUID";

			/// <summary>
			/// Property for PostingDate
			/// </summary>
			public const string PostingDate = "DATEBUS";

			/// <summary>
			/// Property for CreditCardTransactionNumber
			/// </summary>
			public const string CreditCardTransactionNumber = "CCTRANID";

			/// <summary>
			/// Property for ProcessingCode
			/// </summary>
			public const string ProcessingCode = "PROCESSCOD";

            /// <summary>
            /// Property for CustomerCurrency
            /// </summary>
            public const string CustomerCurrency = "CUSTCURN";
        }

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of Payment Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for CustomerNumber
			/// </summary>
			public const int CustomerNumber = 1;

			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 2;

			/// <summary>
			/// Property Indexer for SeqNo
			/// </summary>
			public const int SeqNo = 3;

			/// <summary>
			/// Property Indexer for PaymentCode
			/// </summary>
			public const int PaymentCode = 4;

			/// <summary>
			/// Property Indexer for PaymentType
			/// </summary>
			public const int PaymentType = 5;

			/// <summary>
			/// Property Indexer for DocumentDate
			/// </summary>
			public const int DocumentDate = 6;

			/// <summary>
			/// Property Indexer for FiscalYear
			/// </summary>
			public const int FiscalYear = 7;

			/// <summary>
			/// Property Indexer for FiscalPeriod
			/// </summary>
			public const int FiscalPeriod = 8;

			/// <summary>
			/// Property Indexer for BankCode
			/// </summary>
			public const int BankCode = 9;

			/// <summary>
			/// Property Indexer for CheckNumber
			/// </summary>
			public const int CheckNumber = 10;

			/// <summary>
			/// Property Indexer for CheckSerialNumber
			/// </summary>
			public const int CheckSerialNumber = 11;

			/// <summary>
			/// Property Indexer for GLAccountTobeCredited
			/// </summary>
			public const int GLAccountTobeCredited = 12;

			/// <summary>
			/// Property Indexer for NameonCheck
			/// </summary>
			public const int NameonCheck = 13;

			/// <summary>
			/// Property Indexer for CheckLanguage
			/// </summary>
			public const int CheckLanguage = 14;

			/// <summary>
			/// Property Indexer for PaymentCurrency
			/// </summary>
			public const int PaymentCurrency = 19;

			/// <summary>
			/// Property Indexer for RateType
			/// </summary>
			public const int RateType = 20;

			/// <summary>
			/// Property Indexer for RateDate
			/// </summary>
			public const int RateDate = 21;

			/// <summary>
			/// Property Indexer for ExchangeRate
			/// </summary>
			public const int ExchangeRate = 22;

			/// <summary>
			/// Property Indexer for RateOperator
			/// </summary>
			public const int RateOperator = 23;

			/// <summary>
			/// Property Indexer for RateOverrideFlag
			/// </summary>
			public const int RateOverrideFlag = 24;

			/// <summary>
			/// Property Indexer for PaymentAmount
			/// </summary>
			public const int PaymentAmount = 25;

			/// <summary>
			/// Property Indexer for CustomerAmount
			/// </summary>
			public const int CustomerAmount = 26;

			/// <summary>
			/// Property Indexer for FunctionalAmount
			/// </summary>
			public const int FunctionalAmount = 27;

			/// <summary>
			/// Property Indexer for PostingSequenceNumber
			/// </summary>
			public const int PostingSequenceNumber = 28;

			/// <summary>
			/// Property Indexer for BatchNumber
			/// </summary>
			public const int BatchNumber = 29;

			/// <summary>
			/// Property Indexer for EntryNumber
			/// </summary>
			public const int EntryNumber = 30;

			/// <summary>
			/// Property Indexer for PaymentStatus
			/// </summary>
			public const int PaymentStatus = 31;

			/// <summary>
			/// Property Indexer for DateCleared
			/// </summary>
			public const int DateCleared = 32;

			/// <summary>
			/// Property Indexer for DateReversed
			/// </summary>
			public const int DateReversed = 33;

			/// <summary>
			/// Property Indexer for ReasonForReturn
			/// </summary>
			public const int ReasonForReturn = 34;

			/// <summary>
			/// Property Indexer for DocumentType
			/// </summary>
			public const int DocumentType = 35;

			/// <summary>
			/// Property Indexer for ClientUniqueID
			/// </summary>
			public const int ClientUniqueID = 36;

			/// <summary>
			/// Property Indexer for PostingDate
			/// </summary>
			public const int PostingDate = 37;

			/// <summary>
			/// Property Indexer for CreditCardTransactionNumber
			/// </summary>
			public const int CreditCardTransactionNumber = 38;

			/// <summary>
			/// Property Indexer for ProcessingCode
			/// </summary>
			public const int ProcessingCode = 39;

            /// <summary>
            /// Property Indexer for CustomerCurrency
            /// </summary>
            public const int CustomerCurrency = 50;
        }

		#endregion


		public class Keys
		{
			/// <summary>
			/// Property Indexer for DocumentNumber
			/// </summary>
			public const int DocumentNumber = 0;

			/// <summary>
			/// Property Indexer for BankCode
			/// </summary>
			public const int BankCode = 1;

		}

	}
}
