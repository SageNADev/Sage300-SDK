// Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of RecurringCharges Constants 
    /// </summary>
    public partial class RecurringCharge
    {

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0046";

        /// <summary>
        /// Contains list of RecurringCharges Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for RecurringChargeCode 
            /// </summary>
            public const string RecurringChargeCode = "IDSTDINVC";

            /// <summary>
            /// Property for CustomerNumber 
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for Status 
            /// </summary>
            public const string Status = "SWACTV";

            /// <summary>
            /// Property for InactiveDate 
            /// </summary>
            public const string InactiveDate = "DATEINAC";

            /// <summary>
            /// Property for DateLastMaintained 
            /// </summary>
            public const string DateLastMaintained = "DATELSTMTN";

            /// <summary>
            /// Property for LastInvoiceDateGenerated 
            /// </summary>
            public const string LastInvoiceDateGenerated = "DATELSTPRC";

            /// <summary>
            /// Property for EffectiveDate 
            /// </summary>
            public const string EffectiveDate = "DATEEFF";

            /// <summary>
            /// Property for ExpirationDate 
            /// </summary>
            public const string ExpirationDate = "DATEEXPR";

            /// <summary>
            /// Property for MaximumTotalInvoiceAmount 
            /// </summary>
            public const string MaximumTotalInvoiceAmount = "AMTTOTCHRG";

            /// <summary>
            /// Property for YtdTotalInvoiceAmount 
            /// </summary>
            public const string YtdTotalInvoiceAmount = "AMTINVC";

            /// <summary>
            /// Property for ShipToLocation 
            /// </summary>
            public const string ShipToLocation = "IDCUSTSHPT";

            /// <summary>
            /// Property for SpecialInstructions 
            /// </summary>
            public const string SpecialInstructions = "TEXTINST";

            /// <summary>
            /// Property for OrderNumber 
            /// </summary>
            public const string OrderNumber = "IDORDENBR";

            /// <summary>
            /// Property for PONumber 
            /// </summary>
            public const string PoNumber = "IDCUSTPO";

            /// <summary>
            /// Property for InvoiceDescription 
            /// </summary>
            public const string InvoiceDescription = "INVCDESC";

            /// <summary>
            /// Property for CurrencyCode 
            /// </summary>
            public const string CurrencyCode = "CODECURN";

            /// <summary>
            /// Property for RateType 
            /// </summary>
            public const string RateType = "IDRATETYPE";

            /// <summary>
            /// Property for Terms 
            /// </summary>
            public const string Terms = "CODETERM";

            /// <summary>
            /// Property for LastLineNumber 
            /// </summary>
            public const string LastLineNumber = "CNTLSTLINE";

            /// <summary>
            /// Property for Salesperson1 
            /// </summary>
            public const string Salesperson1 = "CODESLSP1";

            /// <summary>
            /// Property for Salesperson2 
            /// </summary>
            public const string Salesperson2 = "CODESLSP2";

            /// <summary>
            /// Property for Salesperson3 
            /// </summary>
            public const string Salesperson3 = "CODESLSP3";

            /// <summary>
            /// Property for Salesperson4 
            /// </summary>
            public const string Salesperson4 = "CODESLSP4";

            /// <summary>
            /// Property for Salesperson5 
            /// </summary>
            public const string Salesperson5 = "CODESLSP5";

            /// <summary>
            /// Property for SalesSplitPercentage1 
            /// </summary>
            public const string SalesSplitPercentage1 = "PCTSASPLT1";

            /// <summary>
            /// Property for SalesSplitPercentage2 
            /// </summary>
            public const string SalesSplitPercentage2 = "PCTSASPLT2";

            /// <summary>
            /// Property for SalesSplitPercentage3 
            /// </summary>
            public const string SalesSplitPercentage3 = "PCTSASPLT3";

            /// <summary>
            /// Property for SalesSplitPercentage4 
            /// </summary>
            public const string SalesSplitPercentage4 = "PCTSASPLT4";

            /// <summary>
            /// Property for SalesSplitPercentage5 
            /// </summary>
            public const string SalesSplitPercentage5 = "PCTSASPLT5";

            /// <summary>
            /// Property for Taxable 
            /// </summary>
            public const string Taxable = "SWTXBL";

            /// <summary>
            /// Property for TaxOverride 
            /// </summary>
            public const string TaxOverride = "SWMANLTX";

            /// <summary>
            /// Property for TaxGroup 
            /// </summary>
            public const string TaxGroup = "CODETAXGRP";

            /// <summary>
            /// Property for TaxAuthority1 
            /// </summary>
            public const string TaxAuthority1 = "CODETAX1";

            /// <summary>
            /// Property for TaxAuthority2 
            /// </summary>
            public const string TaxAuthority2 = "CODETAX2";

            /// <summary>
            /// Property for TaxAuthority3 
            /// </summary>
            public const string TaxAuthority3 = "CODETAX3";

            /// <summary>
            /// Property for TaxAuthority4 
            /// </summary>
            public const string TaxAuthority4 = "CODETAX4";

            /// <summary>
            /// Property for TaxAuthority5 
            /// </summary>
            public const string TaxAuthority5 = "CODETAX5";

            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXSTTS1";

            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXSTTS2";

            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXSTTS3";

            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXSTTS4";

            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXSTTS5";

            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "BASETAX1";

            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "BASETAX2";

            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "BASETAX3";

            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "BASETAX4";

            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "BASETAX5";

            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "AMTTAX1";

            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "AMTTAX2";

            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "AMTTAX3";

            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "AMTTAX4";

            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "AMTTAX5";

            /// <summary>
            /// Property for EstimatedWithholdingAmount1
            /// </summary>
            public const string EstimatedWithholdingAmount1 = "AMTWHT1TC";

            /// <summary>
            /// Property for EstimatedWithholdingAmount2
            /// </summary>
            public const string EstimatedWithholdingAmount2 = "AMTWHT2TC";

            /// <summary>
            /// Property for EstimatedWithholdingAmount3
            /// </summary>
            public const string EstimatedWithholdingAmount3 = "AMTWHT3TC";

            /// <summary>
            /// Property for EstimatedWithholdingAmount4
            /// </summary>
            public const string EstimatedWithholdingAmount4 = "AMTWHT4TC";

            /// <summary>
            /// Property for EstimatedWithholdingAmount5
            /// </summary>
            public const string EstimatedWithholdingAmount5 = "AMTWHT5TC";

            /// <summary>
            /// Property for EstimatedWithholdingAmountTotal
            /// </summary>
            public const string EstimatedWithholdingAmountTotal = "AMTWHTTOT";

            /// <summary>
            /// Property for TaxableAmount 
            /// </summary>
            public const string TaxableAmount = "AMTTXBL";

            /// <summary>
            /// Property for NonTaxableAmount 
            /// </summary>
            public const string NonTaxableAmount = "AMTNOTTXBL";

            /// <summary>
            /// Property for TotalAmtTaxToL 
            /// </summary>
            public const string TotalAmtTaxToL = "AMTTAXTOTL";

            /// <summary>
            /// Property for LastInvoiceAmountPosted 
            /// </summary>
            public const string LastInvoiceAmountPosted = "AMTINVTOTL";

            /// <summary>
            /// Property for InvoiceSubtotal 
            /// </summary>
            public const string InvoiceSubtotal = "AMTPAYMSCD";

            /// <summary>
            /// Property for MaximumNumberofInvoices 
            /// </summary>
            public const string MaximumNumberofInvoices = "MAXCOUNT";

            /// <summary>
            /// Property for YtdNumberofInvoice 
            /// </summary>
            public const string YtdNumberofInvoice = "YTDCOUNT";

            /// <summary>
            /// Property for Schedule 
            /// </summary>
            public const string Schedule = "SCHEDKEY";

            /// <summary>
            /// Property for ScheduleLink 
            /// </summary>
            public const string ScheduleLink = "SCHEDLINK";

            /// <summary>
            /// Property for ExpirationType 
            /// </summary>
            public const string ExpirationType = "EXPIRETYPE";

            /// <summary>
            /// Property for ShipViaCode 
            /// </summary>
            public const string ShipViaCode = "SHPVIACODE";

            /// <summary>
            /// Property for ShipViaDescription 
            /// </summary>
            public const string ShipViaDescription = "SHPVIADESC";

            /// <summary>
            /// Property for InvoiceTotalBeforeTax 
            /// </summary>
            public const string InvoiceTotalBeforeTax = "AMTINVCTOT";

            /// <summary>
            /// Property for InvoiceTotalIncludingTax 
            /// </summary>
            public const string InvoiceTotalIncludingTax = "AMTNETTOT";

            /// <summary>
            /// Property for TotalTaxAmount 
            /// </summary>
            public const string TotalTaxAmount = "AMTTAXTOT";

            /// <summary>
            /// Property for InvoiceType 
            /// </summary>
            public const string InvoiceType = "INVCTYPE";

            /// <summary>
            /// Property for NumberofOptionalFields 
            /// </summary>
            public const string NumberofOptionalFields = "VALUES";

            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";

            /// <summary>
            /// Property for JobRelated 
            /// </summary>
            public const string JobRelated = "SWJOB";

            /// <summary>
            /// Property for NextScheduledDate 
            /// </summary>
            public const string NextScheduledDate = "DATENEXT";

            /// <summary>
            /// Property for UnpostedNumberofInvoices 
            /// </summary>
            public const string UnpostedNumberofInvoices = "OPENCOUNT";

            /// <summary>
            /// Property for UnpostedTotalInvoiceAmount 
            /// </summary>
            public const string UnpostedTotalInvoiceAmount = "OPENAMOUNT";

            /// <summary>
            /// Property for PostedNumberofInvoices 
            /// </summary>
            public const string PostedNumberofInvoices = "POSTCOUNT";

            /// <summary>
            /// Property for PostedTotalInvoiceAmount 
            /// </summary>
            public const string PostedTotalInvoiceAmount = "POSTAMOUNT";

            /// <summary>
            /// Property for LastInvoiceDatePosted 
            /// </summary>
            public const string LastInvoiceDatePosted = "LSTDATEINV";

            /// <summary>
            /// Property for LastInvoiceNumberPosted 
            /// </summary>
            public const string LastInvoiceNumberPosted = "LSTIDINVC";

            /// <summary>
            /// Property for LastBatchNumberPosted 
            /// </summary>
            public const string LastBatchNumberPosted = "LSTCNTBTCH";

            /// <summary>
            /// Property for LastEntryNumberPosted 
            /// </summary>
            public const string LastEntryNumberPosted = "LSTCNTITEM";

            /// <summary>
            /// Property for LastPostingSequenceNumber 
            /// </summary>
            public const string LastPostingSequenceNumber = "LSTPOSTSEQ";

            /// <summary>
            /// Property for AccountSet 
            /// </summary>
            public const string AccountSet = "IDACCTSET";

            #endregion
        }

        /// <summary>
        /// Contains list of RecurringCharges Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for RecurringChargeCode 
            /// </summary>
            public const int RecurringChargeCode = 1;

            /// <summary>
            /// Property Indexer for CustomerNumber 
            /// </summary>
            public const int CustomerNumber = 2;

            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 4;

            /// <summary>
            /// Property Indexer for Status 
            /// </summary>
            public const int Status = 5;

            /// <summary>
            /// Property Indexer for InactiveDate 
            /// </summary>
            public const int InactiveDate = 6;

            /// <summary>
            /// Property Indexer for DateLastMaintained 
            /// </summary>
            public const int DateLastMaintained = 7;

            /// <summary>
            /// Property Indexer for LastInvoiceDateGenerated 
            /// </summary>
            public const int LastInvoiceDateGenerated = 8;

            /// <summary>
            /// Property Indexer for EffectiveDate 
            /// </summary>
            public const int EffectiveDate = 9;

            /// <summary>
            /// Property Indexer for ExpirationDate 
            /// </summary>
            public const int ExpirationDate = 10;

            /// <summary>
            /// Property Indexer for MaximumTotalInvoiceAmount 
            /// </summary>
            public const int MaximumTotalInvoiceAmount = 11;

            /// <summary>
            /// Property Indexer for YtdTotalInvoiceAmount 
            /// </summary>
            public const int YtdTotalInvoiceAmount = 12;

            /// <summary>
            /// Property Indexer for ShipToLocation 
            /// </summary>
            public const int ShipToLocation = 15;

            /// <summary>
            /// Property Indexer for SpecialInstructions 
            /// </summary>
            public const int SpecialInstructions = 17;

            /// <summary>
            /// Property Indexer for OrderNumber 
            /// </summary>
            public const int OrderNumber = 18;

            /// <summary>
            /// Property Indexer for PoNumber 
            /// </summary>
            public const int PoNumber = 19;

            /// <summary>
            /// Property Indexer for InvoiceDescription 
            /// </summary>
            public const int InvoiceDescription = 21;

            /// <summary>
            /// Property Indexer for CurrencyCode 
            /// </summary>
            public const int CurrencyCode = 23;

            /// <summary>
            /// Property Indexer for RateType 
            /// </summary>
            public const int RateType = 24;

            /// <summary>
            /// Property Indexer for Terms 
            /// </summary>
            public const int Terms = 25;

            /// <summary>
            /// Property Indexer for LastLineNumber 
            /// </summary>
            public const int LastLineNumber = 26;

            /// <summary>
            /// Property Indexer for Salesperson1 
            /// </summary>
            public const int Salesperson1 = 27;

            /// <summary>
            /// Property Indexer for Salesperson2 
            /// </summary>
            public const int Salesperson2 = 28;

            /// <summary>
            /// Property Indexer for Salesperson3 
            /// </summary>
            public const int Salesperson3 = 29;

            /// <summary>
            /// Property Indexer for Salesperson4 
            /// </summary>
            public const int Salesperson4 = 30;

            /// <summary>
            /// Property Indexer for Salesperson5 
            /// </summary>
            public const int Salesperson5 = 31;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage1 
            /// </summary>
            public const int SalesSplitPercentage1 = 32;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage2 
            /// </summary>
            public const int SalesSplitPercentage2 = 33;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage3 
            /// </summary>
            public const int SalesSplitPercentage3 = 34;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage4 
            /// </summary>
            public const int SalesSplitPercentage4 = 35;

            /// <summary>
            /// Property Indexer for SalesSplitPercentage5 
            /// </summary>
            public const int SalesSplitPercentage5 = 36;

            /// <summary>
            /// Property Indexer for Taxable 
            /// </summary>
            public const int Taxable = 37;

            /// <summary>
            /// Property Indexer for TaxOverride 
            /// </summary>
            public const int TaxOverride = 38;

            /// <summary>
            /// Property Indexer for TaxGroup 
            /// </summary>
            public const int TaxGroup = 39;

            /// <summary>
            /// Property Indexer for TaxAuthority1 
            /// </summary>
            public const int TaxAuthority1 = 40;

            /// <summary>
            /// Property Indexer for TaxAuthority2 
            /// </summary>
            public const int TaxAuthority2 = 41;

            /// <summary>
            /// Property Indexer for TaxAuthority3 
            /// </summary>
            public const int TaxAuthority3 = 42;

            /// <summary>
            /// Property Indexer for TaxAuthority4 
            /// </summary>
            public const int TaxAuthority4 = 43;

            /// <summary>
            /// Property Indexer for TaxAuthority5 
            /// </summary>
            public const int TaxAuthority5 = 44;

            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 45;

            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 46;

            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 47;

            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 48;

            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 49;

            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 50;

            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 51;

            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 52;

            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 53;

            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 54;

            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 60;

            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 61;

            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 62;

            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 63;

            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 64;
         
            /// <summary>
            /// Property Indexer for EstimatedWithholdingAmount1 
            /// </summary>
            public const int EstimatedWithholdingAmount1 = 104;

            /// <summary>
            /// Property Indexer for EstimatedWithholdingAmount2 
            /// </summary>
            public const int EstimatedWithholdingAmount2 = 105;

            /// <summary>
            /// Property Indexer for EstimatedWithholdingAmount3 
            /// </summary>
            public const int EstimatedWithholdingAmount3 = 106 ;

            /// <summary>
            /// Property Indexer for EstimatedWithholdingAmount4 
            /// </summary>
            public const int EstimatedWithholdingAmount4 = 107;

            /// <summary>
            /// Property Indexer for EstimatedWithholdingAmount5 
            /// </summary>
            public const int EstimatedWithholdingAmount5 = 108;
         
            /// <summary>
            /// Property Indexer for EstimatedWithholdingTotal
            /// </summary>
            public const int EstimatedWithholdingAmountTotal = 109;
         
            /// <summary>
            /// Property Indexer for LastInvoiceAmountPosted 
            /// </summary>
            public const int LastInvoiceAmountPosted = 76;

            /// <summary>
            /// Property Indexer for InvoiceSubtotal 
            /// </summary>
            public const int InvoiceSubtotal = 78;

            /// <summary>
            /// Property Indexer for MaximumNumberofInvoices 
            /// </summary>
            public const int MaximumNumberofInvoices = 79;

            /// <summary>
            /// Property Indexer for YtdNumberofInvoice 
            /// </summary>
            public const int YtdNumberofInvoice = 80;

            /// <summary>
            /// Property Indexer for Schedule 
            /// </summary>
            public const int Schedule = 81;

            /// <summary>
            /// Property Indexer for ScheduleLink 
            /// </summary>
            public const int ScheduleLink = 82;

            /// <summary>
            /// Property Indexer for ExpirationType 
            /// </summary>
            public const int ExpirationType = 83;

            /// <summary>
            /// Property Indexer for ShipViaCode 
            /// </summary>
            public const int ShipViaCode = 84;

            /// <summary>
            /// Property Indexer for ShipViaDescription 
            /// </summary>
            public const int ShipViaDescription = 85;

            /// <summary>
            /// Property Indexer for InvoiceTotalBeforeTax 
            /// </summary>
            public const int InvoiceTotalBeforeTax = 86;

            /// <summary>
            /// Property Indexer for InvoiceTotalIncludingTax 
            /// </summary>
            public const int InvoiceTotalIncludingTax = 87;

            /// <summary>
            /// Property Indexer for TotalTaxAmount 
            /// </summary>
            public const int TotalTaxAmount = 88;

            /// <summary>
            /// Property Indexer for InvoiceType 
            /// </summary>
            public const int InvoiceType = 89;

            /// <summary>
            /// Property Indexer for NumberofOptionalFields 
            /// </summary>
            public const int NumberofOptionalFields = 90;

            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 91;

            /// <summary>
            /// Property Indexer for JobRelated 
            /// </summary>
            public const int JobRelated = 92;

            /// <summary>
            /// Property Indexer for NextScheduledDate 
            /// </summary>
            public const int NextScheduledDate = 93;

            /// <summary>
            /// Property Indexer for UnpostedNumberofInvoices 
            /// </summary>
            public const int UnpostedNumberofInvoices = 94;

            /// <summary>
            /// Property Indexer for UnpostedTotalInvoiceAmount 
            /// </summary>
            public const int UnpostedTotalInvoiceAmount = 95;

            /// <summary>
            /// Property Indexer for PostedNumberofInvoices 
            /// </summary>
            public const int PostedNumberofInvoices = 96;

            /// <summary>
            /// Property Indexer for PostedTotalInvoiceAmount 
            /// </summary>
            public const int PostedTotalInvoiceAmount = 97;

            /// <summary>
            /// Property Indexer for LastInvoiceDatePosted 
            /// </summary>
            public const int LastInvoiceDatePosted = 98;

            /// <summary>
            /// Property Indexer for LastInvoiceNumberPosted 
            /// </summary>
            public const int LastInvoiceNumberPosted = 99;

            /// <summary>
            /// Property Indexer for LastBatchNumberPosted 
            /// </summary>
            public const int LastBatchNumberPosted = 100;

            /// <summary>
            /// Property Indexer for LastEntryNumberPosted 
            /// </summary>
            public const int LastEntryNumberPosted = 101;

            /// <summary>
            /// Property Indexer for LastPostingSequenceNumber 
            /// </summary>
            public const int LastPostingSequenceNumber = 102;

            /// <summary>
            /// Property Indexer for AccountSet 
            /// </summary>
            public const int AccountSet = 103;

            #endregion
        }
    }
}
