/* Copyright (c) 1994-2021 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of Invoice Details Constants 
    /// </summary>
    public partial class InvoiceDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "AR0033";

        /// <summary>
        /// 
        /// </summary>
        public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for BatchNumber 
            /// </summary>
            public const string BatchNumber = "CNTBTCH";
            /// <summary>
            /// Property for EntryNumber 
            /// </summary>
            public const string EntryNumber = "CNTITEM";
            /// <summary>
            /// Property for LineNumber 
            /// </summary>
            public const string LineNumber = "CNTLINE";

            /// <summary>
            /// Property for IDINVC 
            /// </summary>
            public const string IDINVC = "IDINVC";
            /// <summary>
            /// Property for ItemNumber 
            /// </summary>
            public const string ItemNumber = "IDITEM";
            /// <summary>
            /// Property for DistributionCode 
            /// </summary>
            public const string DistributionCode = "IDDIST";
            /// <summary>
            /// Property for Description 
            /// </summary>
            public const string Description = "TEXTDESC";

            /// <summary>
            /// Property for SWMANLITEM 
            /// </summary>
            public const string SWMANLITEM = "SWMANLITEM";
            /// <summary>
            /// Property for UnitofMeasure 
            /// </summary>
            public const string UnitofMeasure = "UNITMEAS";
            /// <summary>
            /// Property for Quantity 
            /// </summary>
            public const string Quantity = "QTYINVC";
            /// <summary>
            /// Property for Cost 
            /// </summary>
            public const string Cost = "AMTCOST";
            /// <summary>
            /// Property for Price 
            /// </summary>
            public const string Price = "AMTPRIC";
            /// <summary>
            /// Property for ExtendedAmountwOrTIP 
            /// </summary>
            public const string ExtendedAmountwOrTIP = "AMTEXTN";
            /// <summary>
            /// Property for COGSAmount 
            /// </summary>
            public const string COGSAmount = "AMTCOGS";
            /// <summary>
            /// Property for ExtendedAmountwOroTIP 
            /// </summary>
            public const string ExtendedAmountwOroTIP = "AMTTXBL";
            /// <summary>
            /// Property for TaxTotal 
            /// </summary>
            public const string TaxTotal = "TOTTAX";

            /// <summary>
            /// Property for SWMANLTX 
            /// </summary>
            public const string SWMANLTX = "SWMANLTX";
            /// <summary>
            /// Property for TaxBase1 
            /// </summary>
            public const string TaxBase1 = "BASETAX1";
            /// <summary>
            /// Property for TaxBase2 
            /// </summary>
            public const string TaxBase2 = "BASETAX2";
            /// <summary>
            /// Property for TaxBase3 
            /// </summary>
            public const string TaxBase3 = "BASETAX3";
            /// <summary>
            /// Property for TaxBase4 
            /// </summary>
            public const string TaxBase4 = "BASETAX4";
            /// <summary>
            /// Property for TaxBase5 
            /// </summary>
            public const string TaxBase5 = "BASETAX5";
            /// <summary>
            /// Property for TaxClass1 
            /// </summary>
            public const string TaxClass1 = "TAXSTTS1";
            /// <summary>
            /// Property for TaxClass2 
            /// </summary>
            public const string TaxClass2 = "TAXSTTS2";
            /// <summary>
            /// Property for TaxClass3 
            /// </summary>
            public const string TaxClass3 = "TAXSTTS3";
            /// <summary>
            /// Property for TaxClass4 
            /// </summary>
            public const string TaxClass4 = "TAXSTTS4";
            /// <summary>
            /// Property for TaxClass5 
            /// </summary>
            public const string TaxClass5 = "TAXSTTS5";
            /// <summary>
            /// Property for TaxIncluded1 
            /// </summary>
            public const string TaxIncluded1 = "SWTAXINCL1";
            /// <summary>
            /// Property for TaxIncluded2 
            /// </summary>
            public const string TaxIncluded2 = "SWTAXINCL2";
            /// <summary>
            /// Property for TaxIncluded3 
            /// </summary>
            public const string TaxIncluded3 = "SWTAXINCL3";
            /// <summary>
            /// Property for TaxIncluded4 
            /// </summary>
            public const string TaxIncluded4 = "SWTAXINCL4";
            /// <summary>
            /// Property for TaxIncluded5 
            /// </summary>
            public const string TaxIncluded5 = "SWTAXINCL5";
            /// <summary>
            /// Property for TaxRate1 
            /// </summary>
            public const string TaxRate1 = "RATETAX1";
            /// <summary>
            /// Property for TaxRate2 
            /// </summary>
            public const string TaxRate2 = "RATETAX2";
            /// <summary>
            /// Property for TaxRate3 
            /// </summary>
            public const string TaxRate3 = "RATETAX3";
            /// <summary>
            /// Property for TaxRate4 
            /// </summary>
            public const string TaxRate4 = "RATETAX4";
            /// <summary>
            /// Property for TaxRate5 
            /// </summary>
            public const string TaxRate5 = "RATETAX5";
            /// <summary>
            /// Property for TaxAmount1 
            /// </summary>
            public const string TaxAmount1 = "AMTTAX1";
            /// <summary>
            /// Property for TaxAmount2 
            /// </summary>
            public const string TaxAmount2 = "AMTTAX2";
            /// <summary>
            /// Property for TaxAmount3 
            /// </summary>
            public const string TaxAmount3 = "AMTTAX3";
            /// <summary>
            /// Property for TaxAmount4 
            /// </summary>
            public const string TaxAmount4 = "AMTTAX4";
            /// <summary>
            /// Property for TaxAmount5 
            /// </summary>
            public const string TaxAmount5 = "AMTTAX5";
            /// <summary>
            /// Property for RevenueAccount 
            /// </summary>
            public const string RevenueAccount = "IDACCTREV";
            /// <summary>
            /// Property for InventoryAccount 
            /// </summary>
            public const string InventoryAccount = "IDACCTINV";
            /// <summary>
            /// Property for COGSAccount 
            /// </summary>
            public const string COGSAccount = "IDACCTCOGS";

            /// <summary>
            /// Property for IDJOBPROJ 
            /// </summary>
            public const string IDJOBPROJ = "IDJOBPROJ";
            /// <summary>
            /// Property for Comments 
            /// </summary>
            public const string Comments = "COMMENT";
            /// <summary>
            /// Property for PrintComment 
            /// </summary>
            public const string PrintComment = "SWPRTSTMT";
            /// <summary>
            /// Property for ItemCost 
            /// </summary>
            public const string ItemCost = "ITEMCOST";
            /// <summary>
            /// Property for ContractCode 
            /// </summary>
            public const string ContractCode = "CONTRACT";
            /// <summary>
            /// Property for ProjectCode 
            /// </summary>
            public const string ProjectCode = "PROJECT";
            /// <summary>
            /// Property for CategoryCode 
            /// </summary>
            public const string CategoryCode = "CATEGORY";
            /// <summary>
            /// Property for ProjectOrCategoryResource 
            /// </summary>
            public const string ProjectOrCategoryResource = "RESOURCE";
            /// <summary>
            /// Property for TransactionNumber 
            /// </summary>
            public const string TransactionNumber = "TRANSNBR";
            /// <summary>
            /// Property for CostClass 
            /// </summary>
            public const string CostClass = "COSTCLASS";
            /// <summary>
            /// Property for BillingDate 
            /// </summary>
            public const string BillingDate = "BILLDATE";
            /// <summary>
            /// Property for CommentAttached 
            /// </summary>
            public const string CommentAttached = "SWIBT";
            /// <summary>
            /// Property for Discountable 
            /// </summary>
            public const string Discountable = "SWDISCABL";
            /// <summary>
            /// Property for OriginalLineIdentifier 
            /// </summary>
            public const string OriginalLineIdentifier = "OCNTLINE";
            /// <summary>
            /// Property for RetainageAmount 
            /// </summary>
            public const string RetainageAmount = "RTGAMT";
            /// <summary>
            /// Property for PercentRetained 
            /// </summary>
            public const string PercentRetained = "RTGPERCENT";
            /// <summary>
            /// Property for DaysRetained 
            /// </summary>
            public const string DaysRetained = "RTGDAYS";
            /// <summary>
            /// Property for RetainageDueDate 
            /// </summary>
            public const string RetainageDueDate = "RTGDATEDUE";
            /// <summary>
            /// Property for RetainageDueDateOverride 
            /// </summary>
            public const string RetainageDueDateOverride = "SWRTGDDTOV";
            /// <summary>
            /// Property for RetainageAmountOverride 
            /// </summary>
            public const string RetainageAmountOverride = "SWRTGAMTOV";
            /// <summary>
            /// Property for Values 
            /// </summary>
            public const string Values = "VALUES";
            /// <summary>
            /// Property for ProcessCommandCode 
            /// </summary>
            public const string ProcessCommandCode = "PROCESSCMD";
            /// <summary>
            /// Property for RetainageDistributionAmount 
            /// </summary>
            public const string RetainageDistributionAmount = "RTGDISTTC";
            /// <summary>
            /// Property for RetainageCOGSAmount 
            /// </summary>
            public const string RetainageCOGSAmount = "RTGCOGSTC";
            /// <summary>
            /// Property for RetainageAlternateBaseAmount 
            /// </summary>
            public const string RetainageAlternateBaseAmount = "RTGALTBTC";
            /// <summary>
            /// Property for InvoicedRetainageDistribution 
            /// </summary>
            public const string InvoicedRetainageDistribution = "RTGINVDIST";
            /// <summary>
            /// Property for InvoicedRetainageCOGS 
            /// </summary>
            public const string InvoicedRetainageCOGS = "RTGINVCOGS";
            /// <summary>
            /// Property for InvoicedRetainageAlternateBas 
            /// </summary>
            public const string InvoicedRetainageAlternateBas = "RTGINVALTB";
            /// <summary>
            /// Property for TaxReportingAmount1 
            /// </summary>
            public const string TaxReportingAmount1 = "TXAMT1RC";
            /// <summary>
            /// Property for TaxReportingAmount2 
            /// </summary>
            public const string TaxReportingAmount2 = "TXAMT2RC";
            /// <summary>
            /// Property for TaxReportingAmount3 
            /// </summary>
            public const string TaxReportingAmount3 = "TXAMT3RC";
            /// <summary>
            /// Property for TaxReportingAmount4 
            /// </summary>
            public const string TaxReportingAmount4 = "TXAMT4RC";
            /// <summary>
            /// Property for TaxReportingAmount5 
            /// </summary>
            public const string TaxReportingAmount5 = "TXAMT5RC";
            /// <summary>
            /// Property for TaxReportingTotal 
            /// </summary>
            public const string TaxReportingTotal = "TXTOTRC";
            /// <summary>
            /// Property for RetainageTaxBase1 
            /// </summary>
            public const string RetainageTaxBase1 = "TXBSERT1TC";
            /// <summary>
            /// Property for RetainageTaxBase2 
            /// </summary>
            public const string RetainageTaxBase2 = "TXBSERT2TC";
            /// <summary>
            /// Property for RetainageTaxBase3 
            /// </summary>
            public const string RetainageTaxBase3 = "TXBSERT3TC";
            /// <summary>
            /// Property for RetainageTaxBase4 
            /// </summary>
            public const string RetainageTaxBase4 = "TXBSERT4TC";
            /// <summary>
            /// Property for RetainageTaxBase5 
            /// </summary>
            public const string RetainageTaxBase5 = "TXBSERT5TC";
            /// <summary>
            /// Property for RetainageTaxAmount1 
            /// </summary>
            public const string RetainageTaxAmount1 = "TXAMTRT1TC";
            /// <summary>
            /// Property for RetainageTaxAmount2 
            /// </summary>
            public const string RetainageTaxAmount2 = "TXAMTRT2TC";
            /// <summary>
            /// Property for RetainageTaxAmount3 
            /// </summary>
            public const string RetainageTaxAmount3 = "TXAMTRT3TC";
            /// <summary>
            /// Property for RetainageTaxAmount4 
            /// </summary>
            public const string RetainageTaxAmount4 = "TXAMTRT4TC";
            /// <summary>
            /// Property for RetainageTaxAmount5 
            /// </summary>
            public const string RetainageTaxAmount5 = "TXAMTRT5TC";
            /// <summary>
            /// Property for FuncTaxBase1 
            /// </summary>
            public const string FuncTaxBase1 = "TXBSE1HC";
            /// <summary>
            /// Property for FuncTaxBase2 
            /// </summary>
            public const string FuncTaxBase2 = "TXBSE2HC";
            /// <summary>
            /// Property for FuncTaxBase3 
            /// </summary>
            public const string FuncTaxBase3 = "TXBSE3HC";
            /// <summary>
            /// Property for FuncTaxBase4 
            /// </summary>
            public const string FuncTaxBase4 = "TXBSE4HC";
            /// <summary>
            /// Property for FuncTaxBase5 
            /// </summary>
            public const string FuncTaxBase5 = "TXBSE5HC";
            /// <summary>
            /// Property for FuncTaxAmount1 
            /// </summary>
            public const string FuncTaxAmount1 = "TXAMT1HC";
            /// <summary>
            /// Property for FuncTaxAmount2 
            /// </summary>
            public const string FuncTaxAmount2 = "TXAMT2HC";
            /// <summary>
            /// Property for FuncTaxAmount3 
            /// </summary>
            public const string FuncTaxAmount3 = "TXAMT3HC";
            /// <summary>
            /// Property for FuncTaxAmount4 
            /// </summary>
            public const string FuncTaxAmount4 = "TXAMT4HC";
            /// <summary>
            /// Property for FuncTaxAmount5 
            /// </summary>
            public const string FuncTaxAmount5 = "TXAMT5HC";
            /// <summary>
            /// Property for FuncRetainageTaxAmount1 
            /// </summary>
            public const string FuncRetainageTaxAmount1 = "TXAMTRT1HC";
            /// <summary>
            /// Property for FuncRetainageTaxAmount2 
            /// </summary>
            public const string FuncRetainageTaxAmount2 = "TXAMTRT2HC";
            /// <summary>
            /// Property for FuncRetainageTaxAmount3 
            /// </summary>
            public const string FuncRetainageTaxAmount3 = "TXAMTRT3HC";
            /// <summary>
            /// Property for FuncRetainageTaxAmount4 
            /// </summary>
            public const string FuncRetainageTaxAmount4 = "TXAMTRT4HC";
            /// <summary>
            /// Property for FuncRetainageTaxAmount5 
            /// </summary>
            public const string FuncRetainageTaxAmount5 = "TXAMTRT5HC";
            /// <summary>
            /// Property for FuncDistributionNetofTaxes 
            /// </summary>
            public const string FuncDistributionNetofTaxes = "DISTNETHC";
            /// <summary>
            /// Property for FuncRetainageAmount 
            /// </summary>
            public const string FuncRetainageAmount = "RTGAMTHC";
            /// <summary>
            /// Property for FuncCOGSAmount 
            /// </summary>
            public const string FuncCOGSAmount = "AMTCOGSHC";
            /// <summary>
            /// Property for FuncCost 
            /// </summary>
            public const string FuncCost = "AMTCOSTHC";
            /// <summary>
            /// Property for FuncPrice 
            /// </summary>
            public const string FuncPrice = "AMTPRICHC";
            /// <summary>
            /// Property for FuncExtendedAmountwOrTIP 
            /// </summary>
            public const string FuncExtendedAmountwOrTIP = "AMTEXTNHC";
            /// <summary>
            /// Property for RetainageTaxTotal 
            /// </summary>
            public const string RetainageTaxTotal = "TXTOTRTTC";
            /// <summary>
            /// Property for TaxAmount1Total 
            /// </summary>
            public const string TaxAmount1Total = "TXTOTAMT1";
            /// <summary>
            /// Property for TaxAmount2Total 
            /// </summary>
            public const string TaxAmount2Total = "TXTOTAMT2";
            /// <summary>
            /// Property for TaxAmount3Total 
            /// </summary>
            public const string TaxAmount3Total = "TXTOTAMT3";
            /// <summary>
            /// Property for TaxAmount4Total 
            /// </summary>
            public const string TaxAmount4Total = "TXTOTAMT4";
            /// <summary>
            /// Property for TaxAmount5Total 
            /// </summary>
            public const string TaxAmount5Total = "TXTOTAMT5";
            /// <summary>
            /// Property for CurrRetainageAmount 
            /// </summary>
            public const string CurrRetainageAmount = "RTGAMTOTC";
            /// <summary>
            /// Property for CurrRetainageDistAmount 
            /// </summary>
            public const string CurrRetainageDistAmount = "RTGDISTOTC";
            /// <summary>
            /// Property for CurrCOGSAmount 
            /// </summary>
            public const string CurrCOGSAmount = "RTGCOGSOTC";
            /// <summary>
            /// Property for CurrAlternateBaseAmount 
            /// </summary>
            public const string CurrAlternateBaseAmount = "RTGALTBOTC";
            /// <summary>
            /// Property for Export Declaration Number
            /// </summary>
            public const string EDN = "EDN";
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 1
            /// </summary>
            public const string AmtWHT1TC = "AMTWHT1TC";
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 2
            /// </summary>
            public const string AmtWHT2TC = "AMTWHT2TC";
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 3
            /// </summary>
            public const string AmtWHT3TC = "AMTWHT3TC";
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 4
            /// </summary>
            public const string AmtWHT4TC = "AMTWHT4TC";
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 5
            /// </summary>
            public const string AmtWHT5TC = "AMTWHT5TC";

            #endregion
        }

        /// <summary>
        /// Contains list of InvoiceDetails Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for BatchNumber 
            /// </summary>
            public const int BatchNumber = 1;
            /// <summary>
            /// Property Indexer for EntryNumber 
            /// </summary>
            public const int EntryNumber = 2;
            /// <summary>
            /// Property Indexer for LineNumber 
            /// </summary>
            public const int LineNumber = 3;

            /// <summary>
            /// Property Indexer for IDINVC 
            /// </summary>
            public const int IDINVC = 4;
            /// <summary>
            /// Property Indexer for ItemNumber 
            /// </summary>
            public const int ItemNumber = 5;
            /// <summary>
            /// Property Indexer for DistributionCode 
            /// </summary>
            public const int DistributionCode = 6;
            /// <summary>
            /// Property Indexer for Description 
            /// </summary>
            public const int Description = 7;

            /// <summary>
            /// Property Indexer for SWMANLITEM 
            /// </summary>
            public const int SWMANLITEM = 8;
            /// <summary>
            /// Property Indexer for UnitofMeasure 
            /// </summary>
            public const int UnitofMeasure = 9;
            /// <summary>
            /// Property Indexer for Quantity 
            /// </summary>
            public const int Quantity = 10;
            /// <summary>
            /// Property Indexer for Cost 
            /// </summary>
            public const int Cost = 11;
            /// <summary>
            /// Property Indexer for Price 
            /// </summary>
            public const int Price = 12;
            /// <summary>
            /// Property Indexer for ExtendedAmountwOrTIP 
            /// </summary>
            public const int ExtendedAmountwOrTIP = 13;
            /// <summary>
            /// Property Indexer for COGSAmount 
            /// </summary>
            public const int COGSAmount = 14;
            /// <summary>
            /// Property Indexer for ExtendedAmountwOroTIP 
            /// </summary>
            public const int ExtendedAmountwOroTIP = 15;
            /// <summary>
            /// Property Indexer for TaxTotal 
            /// </summary>
            public const int TaxTotal = 16;

            /// <summary>
            /// Property Indexer for SWMANLTX 
            /// </summary>
            public const int SWMANLTX = 17;
            /// <summary>
            /// Property Indexer for TaxBase1 
            /// </summary>
            public const int TaxBase1 = 18;
            /// <summary>
            /// Property Indexer for TaxBase2 
            /// </summary>
            public const int TaxBase2 = 19;
            /// <summary>
            /// Property Indexer for TaxBase3 
            /// </summary>
            public const int TaxBase3 = 20;
            /// <summary>
            /// Property Indexer for TaxBase4 
            /// </summary>
            public const int TaxBase4 = 21;
            /// <summary>
            /// Property Indexer for TaxBase5 
            /// </summary>
            public const int TaxBase5 = 22;
            /// <summary>
            /// Property Indexer for TaxClass1 
            /// </summary>
            public const int TaxClass1 = 23;
            /// <summary>
            /// Property Indexer for TaxClass2 
            /// </summary>
            public const int TaxClass2 = 24;
            /// <summary>
            /// Property Indexer for TaxClass3 
            /// </summary>
            public const int TaxClass3 = 25;
            /// <summary>
            /// Property Indexer for TaxClass4 
            /// </summary>
            public const int TaxClass4 = 26;
            /// <summary>
            /// Property Indexer for TaxClass5 
            /// </summary>
            public const int TaxClass5 = 27;
            /// <summary>
            /// Property Indexer for TaxIncluded1 
            /// </summary>
            public const int TaxIncluded1 = 28;
            /// <summary>
            /// Property Indexer for TaxIncluded2 
            /// </summary>
            public const int TaxIncluded2 = 29;
            /// <summary>
            /// Property Indexer for TaxIncluded3 
            /// </summary>
            public const int TaxIncluded3 = 30;
            /// <summary>
            /// Property Indexer for TaxIncluded4 
            /// </summary>
            public const int TaxIncluded4 = 31;
            /// <summary>
            /// Property Indexer for TaxIncluded5 
            /// </summary>
            public const int TaxIncluded5 = 32;
            /// <summary>
            /// Property Indexer for TaxRate1 
            /// </summary>
            public const int TaxRate1 = 33;
            /// <summary>
            /// Property Indexer for TaxRate2 
            /// </summary>
            public const int TaxRate2 = 34;
            /// <summary>
            /// Property Indexer for TaxRate3 
            /// </summary>
            public const int TaxRate3 = 35;
            /// <summary>
            /// Property Indexer for TaxRate4 
            /// </summary>
            public const int TaxRate4 = 36;
            /// <summary>
            /// Property Indexer for TaxRate5 
            /// </summary>
            public const int TaxRate5 = 37;
            /// <summary>
            /// Property Indexer for TaxAmount1 
            /// </summary>
            public const int TaxAmount1 = 38;
            /// <summary>
            /// Property Indexer for TaxAmount2 
            /// </summary>
            public const int TaxAmount2 = 39;
            /// <summary>
            /// Property Indexer for TaxAmount3 
            /// </summary>
            public const int TaxAmount3 = 40;
            /// <summary>
            /// Property Indexer for TaxAmount4 
            /// </summary>
            public const int TaxAmount4 = 41;
            /// <summary>
            /// Property Indexer for TaxAmount5 
            /// </summary>
            public const int TaxAmount5 = 42;
            /// <summary>
            /// Property Indexer for RevenueAccount 
            /// </summary>
            public const int RevenueAccount = 43;
            /// <summary>
            /// Property Indexer for InventoryAccount 
            /// </summary>
            public const int InventoryAccount = 44;
            /// <summary>
            /// Property Indexer for COGSAccount 
            /// </summary>
            public const int COGSAccount = 45;

            /// <summary>
            /// Property Indexer for IDJOBPROJ 
            /// </summary>
            public const int IDJOBPROJ = 46;
            /// <summary>
            /// Property Indexer for Comments 
            /// </summary>
            public const int Comments = 47;
            /// <summary>
            /// Property Indexer for PrintComment 
            /// </summary>
            public const int PrintComment = 48;
            /// <summary>
            /// Property Indexer for ItemCost 
            /// </summary>
            public const int ItemCost = 49;
            /// <summary>
            /// Property Indexer for ContractCode 
            /// </summary>
            public const int ContractCode = 50;
            /// <summary>
            /// Property Indexer for ProjectCode 
            /// </summary>
            public const int ProjectCode = 51;
            /// <summary>
            /// Property Indexer for CategoryCode 
            /// </summary>
            public const int CategoryCode = 52;
            /// <summary>
            /// Property Indexer for ProjectOrCategoryResource 
            /// </summary>
            public const int ProjectOrCategoryResource = 53;
            /// <summary>
            /// Property Indexer for TransactionNumber 
            /// </summary>
            public const int TransactionNumber = 54;
            /// <summary>
            /// Property Indexer for CostClass 
            /// </summary>
            public const int CostClass = 55;
            /// <summary>
            /// Property Indexer for BillingDate 
            /// </summary>
            public const int BillingDate = 56;
            /// <summary>
            /// Property Indexer for CommentAttached 
            /// </summary>
            public const int CommentAttached = 57;
            /// <summary>
            /// Property Indexer for Discountable 
            /// </summary>
            public const int Discountable = 58;
            /// <summary>
            /// Property Indexer for OriginalLineIdentifier 
            /// </summary>
            public const int OriginalLineIdentifier = 59;
            /// <summary>
            /// Property Indexer for RetainageAmount 
            /// </summary>
            public const int RetainageAmount = 60;
            /// <summary>
            /// Property Indexer for PercentRetained 
            /// </summary>
            public const int PercentRetained = 61;
            /// <summary>
            /// Property Indexer for DaysRetained 
            /// </summary>
            public const int DaysRetained = 62;
            /// <summary>
            /// Property Indexer for RetainageDueDate 
            /// </summary>
            public const int RetainageDueDate = 63;
            /// <summary>
            /// Property Indexer for RetainageDueDateOverride 
            /// </summary>
            public const int RetainageDueDateOverride = 64;
            /// <summary>
            /// Property Indexer for RetainageAmountOverride 
            /// </summary>
            public const int RetainageAmountOverride = 65;
            /// <summary>
            /// Property Indexer for Values 
            /// </summary>
            public const int Values = 66;
            /// <summary>
            /// Property Indexer for ProcessCommandCode 
            /// </summary>
            public const int ProcessCommandCode = 67;
            /// <summary>
            /// Property Indexer for RetainageDistributionAmount 
            /// </summary>
            public const int RetainageDistributionAmount = 68;
            /// <summary>
            /// Property Indexer for RetainageCOGSAmount 
            /// </summary>
            public const int RetainageCOGSAmount = 69;
            /// <summary>
            /// Property Indexer for RetainageAlternateBaseAmount 
            /// </summary>
            public const int RetainageAlternateBaseAmount = 70;
            /// <summary>
            /// Property Indexer for InvoicedRetainageDistribution 
            /// </summary>
            public const int InvoicedRetainageDistribution = 71;
            /// <summary>
            /// Property Indexer for InvoicedRetainageCOGS 
            /// </summary>
            public const int InvoicedRetainageCOGS = 72;
            /// <summary>
            /// Property Indexer for InvoicedRetainageAlternateBas 
            /// </summary>
            public const int InvoicedRetainageAlternateBas = 73;
            /// <summary>
            /// Property Indexer for TaxReportingAmount1 
            /// </summary>
            public const int TaxReportingAmount1 = 74;
            /// <summary>
            /// Property Indexer for TaxReportingAmount2 
            /// </summary>
            public const int TaxReportingAmount2 = 75;
            /// <summary>
            /// Property Indexer for TaxReportingAmount3 
            /// </summary>
            public const int TaxReportingAmount3 = 76;
            /// <summary>
            /// Property Indexer for TaxReportingAmount4 
            /// </summary>
            public const int TaxReportingAmount4 = 77;
            /// <summary>
            /// Property Indexer for TaxReportingAmount5 
            /// </summary>
            public const int TaxReportingAmount5 = 78;
            /// <summary>
            /// Property Indexer for TaxReportingTotal 
            /// </summary>
            public const int TaxReportingTotal = 79;
            /// <summary>
            /// Property Indexer for RetainageTaxBase1 
            /// </summary>
            public const int RetainageTaxBase1 = 80;
            /// <summary>
            /// Property Indexer for RetainageTaxBase2 
            /// </summary>
            public const int RetainageTaxBase2 = 81;
            /// <summary>
            /// Property Indexer for RetainageTaxBase3 
            /// </summary>
            public const int RetainageTaxBase3 = 82;
            /// <summary>
            /// Property Indexer for RetainageTaxBase4 
            /// </summary>
            public const int RetainageTaxBase4 = 83;
            /// <summary>
            /// Property Indexer for RetainageTaxBase5 
            /// </summary>
            public const int RetainageTaxBase5 = 84;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount1 
            /// </summary>
            public const int RetainageTaxAmount1 = 85;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount2 
            /// </summary>
            public const int RetainageTaxAmount2 = 86;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount3 
            /// </summary>
            public const int RetainageTaxAmount3 = 87;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount4 
            /// </summary>
            public const int RetainageTaxAmount4 = 88;
            /// <summary>
            /// Property Indexer for RetainageTaxAmount5 
            /// </summary>
            public const int RetainageTaxAmount5 = 89;
            /// <summary>
            /// Property Indexer for FuncTaxBase1 
            /// </summary>
            public const int FuncTaxBase1 = 90;
            /// <summary>
            /// Property Indexer for FuncTaxBase2 
            /// </summary>
            public const int FuncTaxBase2 = 91;
            /// <summary>
            /// Property Indexer for FuncTaxBase3 
            /// </summary>
            public const int FuncTaxBase3 = 92;
            /// <summary>
            /// Property Indexer for FuncTaxBase4 
            /// </summary>
            public const int FuncTaxBase4 = 93;
            /// <summary>
            /// Property Indexer for FuncTaxBase5 
            /// </summary>
            public const int FuncTaxBase5 = 94;
            /// <summary>
            /// Property Indexer for FuncTaxAmount1 
            /// </summary>
            public const int FuncTaxAmount1 = 95;
            /// <summary>
            /// Property Indexer for FuncTaxAmount2 
            /// </summary>
            public const int FuncTaxAmount2 = 96;
            /// <summary>
            /// Property Indexer for FuncTaxAmount3 
            /// </summary>
            public const int FuncTaxAmount3 = 97;
            /// <summary>
            /// Property Indexer for FuncTaxAmount4 
            /// </summary>
            public const int FuncTaxAmount4 = 98;
            /// <summary>
            /// Property Indexer for FuncTaxAmount5 
            /// </summary>
            public const int FuncTaxAmount5 = 99;
            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount1 
            /// </summary>
            public const int FuncRetainageTaxAmount1 = 100;
            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount2 
            /// </summary>
            public const int FuncRetainageTaxAmount2 = 101;
            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount3 
            /// </summary>
            public const int FuncRetainageTaxAmount3 = 102;
            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount4 
            /// </summary>
            public const int FuncRetainageTaxAmount4 = 103;
            /// <summary>
            /// Property Indexer for FuncRetainageTaxAmount5 
            /// </summary>
            public const int FuncRetainageTaxAmount5 = 104;
            /// <summary>
            /// Property Indexer for FuncDistributionNetofTaxes 
            /// </summary>
            public const int FuncDistributionNetofTaxes = 105;
            /// <summary>
            /// Property Indexer for FuncRetainageAmount 
            /// </summary>
            public const int FuncRetainageAmount = 106;
            /// <summary>
            /// Property Indexer for FuncCOGSAmount 
            /// </summary>
            public const int FuncCOGSAmount = 107;
            /// <summary>
            /// Property Indexer for FuncCost 
            /// </summary>
            public const int FuncCost = 108;
            /// <summary>
            /// Property Indexer for FuncPrice 
            /// </summary>
            public const int FuncPrice = 109;
            /// <summary>
            /// Property Indexer for FuncExtendedAmountwOrTIP 
            /// </summary>
            public const int FuncExtendedAmountwOrTIP = 110;
            /// <summary>
            /// Property Indexer for RetainageTaxTotal 
            /// </summary>
            public const int RetainageTaxTotal = 111;
            /// <summary>
            /// Property Indexer for TaxAmount1Total 
            /// </summary>
            public const int TaxAmount1Total = 112;
            /// <summary>
            /// Property Indexer for TaxAmount2Total 
            /// </summary>
            public const int TaxAmount2Total = 113;
            /// <summary>
            /// Property Indexer for TaxAmount3Total 
            /// </summary>
            public const int TaxAmount3Total = 114;
            /// <summary>
            /// Property Indexer for TaxAmount4Total 
            /// </summary>
            public const int TaxAmount4Total = 115;
            /// <summary>
            /// Property Indexer for TaxAmount5Total 
            /// </summary>
            public const int TaxAmount5Total = 116;
            /// <summary>
            /// Property Indexer for CurrRetainageAmount 
            /// </summary>
            public const int CurrRetainageAmount = 117;
            /// <summary>
            /// Property Indexer for CurrRetainageDistAmount 
            /// </summary>
            public const int CurrRetainageDistAmount = 118;
            /// <summary>
            /// Property Indexer for CurrCOGSAmount 
            /// </summary>
            public const int CurrCOGSAmount = 119;
            /// <summary>
            /// Property Indexer for CurrAlternateBaseAmount 
            /// </summary>
            public const int CurrAlternateBaseAmount = 120;
            /// <summary>
            /// Property Indexer for Export Declaration Number
            /// </summary>
            public const int EDN = 121;
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 1
            /// </summary>
            public const int AmtWHT1TC = 122;
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 2
            /// </summary>
            public const int AmtWHT2TC = 123;
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 3
            /// </summary>
            public const int AmtWHT3TC = 124;
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 4
            /// </summary>
            public const int AmtWHT4TC = 125;
            /// <summary>
            /// Indexer for Estimated Tax Withheld Amount 5
            /// </summary>
            public const int AmtWHT5TC = 126;

            #endregion
        }
    }
}
