// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of CustomerStatistics Constants
    /// </summary>
    public partial class CustomerStatistics
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "AR0022";

        /// <summary>
        /// Contains list of CustomerStatistics Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Property for CustomerNumber
            /// </summary>
            public const string CustomerNumber = "IDCUST";

            /// <summary>
            /// Property for Year
            /// </summary>
            public const string Year = "CNTYR";

            /// <summary>
            /// Property for Period
            /// </summary>
            public const string Period = "CNTPERD";

            /// <summary>
            /// Property for NumberofInvoices
            /// </summary>
            public const string NumberOfInvoices = "CNTINVC";

            /// <summary>
            /// Property for NumberofCredits
            /// </summary>
            public const string NumberOfCredits = "CNTCR";

            /// <summary>
            /// Property for NumberofDebits
            /// </summary>
            public const string NumberOfDebits = "CNTDR";

            /// <summary>
            /// Property for NumberofReceipts
            /// </summary>
            public const string NumberOfReceipts = "CNTPAYM";

            /// <summary>
            /// Property for NumberofDiscounts
            /// </summary>
            public const string NumberOfDiscounts = "CNTDISC";

            /// <summary>
            /// Property for NumberofAdjustments
            /// </summary>
            public const string NumberOfAdjustments = "CNTADJ";

            /// <summary>
            /// Property for NumberofWriteOffs
            /// </summary>
            public const string NumberOfWriteOffs = "CNTWROF";

            /// <summary>
            /// Property for NumberofInterestCharges
            /// </summary>
            public const string NumberOfInterestCharges = "CNTINTT";

            /// <summary>
            /// Property for NumberofReturnedChecks
            /// </summary>
            public const string NumberOfReturnedChecks = "CNTRIF";

            /// <summary>
            /// Property for NumberofInvoicesPaid
            /// </summary>
            public const string NumberOfInvoicesPaid = "CNTINVCPD";

            /// <summary>
            /// Property for NumberofDaystoPay
            /// </summary>
            public const string NumberOfDaystoPay = "CNTDTOPAY";

            /// <summary>
            /// Property for TotalInvoicesinFuncCurr
            /// </summary>
            public const string TotalInvoicesInFuncCurr = "AMTINVCHC";

            /// <summary>
            /// Property for TotalCreditsinFuncCurr
            /// </summary>
            public const string TotalCreditsInFuncCurr = "AMTCRHC";

            /// <summary>
            /// Property for TotalDebitsinFuncCurr
            /// </summary>
            public const string TotalDebitsInFuncCurr = "AMTDRHC";

            /// <summary>
            /// Property for TotalReceiptsinFuncCurr
            /// </summary>
            public const string TotalReceiptsInFuncCurr = "AMTPAYMHC";

            /// <summary>
            /// Property for TotalDiscountsinFuncCurr
            /// </summary>
            public const string TotalDiscountsInFuncCurr = "AMTDISCHC";

            /// <summary>
            /// Property for TotalAdjustmentsinFuncCurr
            /// </summary>
            public const string TotalAdjustmentsInFuncCurr = "AMTADJHC";

            /// <summary>
            /// Property for TotalWriteOffsinFuncCurr
            /// </summary>
            public const string TotalWriteOffsInFuncCurr = "AMTWROFHC";

            /// <summary>
            /// Property for TotalInterestinFuncCurr
            /// </summary>
            public const string TotalInterestInFuncCurr = "AMTINTTHC";

            /// <summary>
            /// Property for TotalRetdChecksinFuncCurr
            /// </summary>
            public const string TotalRetdChecksInFuncCurr = "AMTRIFHC";

            /// <summary>
            /// Property for TotalInvoicesPdinFuncCurr
            /// </summary>
            public const string TotalInvoicesPdInFuncCurr = "AMTINVPDHC";

            /// <summary>
            /// Property for TotalInvoicesinCustCurr
            /// </summary>
            public const string TotalInvoicesInCustCurr = "AMTINVCTC";

            /// <summary>
            /// Property for TotalCreditsinCustCurr
            /// </summary>
            public const string TotalCreditsInCustCurr = "AMTCRTC";

            /// <summary>
            /// Property for TotalDebitsinCustCurr
            /// </summary>
            public const string TotalDebitsInCustCurr = "AMTDRTC";

            /// <summary>
            /// Property for TotalReceiptsinCustCurr
            /// </summary>
            public const string TotalReceiptsInCustCurr = "AMTPAYMTC";

            /// <summary>
            /// Property for TotalDiscountsinCustCurr
            /// </summary>
            public const string TotalDiscountsInCustCurr = "AMTDISCTC";

            /// <summary>
            /// Property for TotalAdjustmentsinCustCurr
            /// </summary>
            public const string TotalAdjustmentsInCustCurr = "AMTADJTC";

            /// <summary>
            /// Property for TotalWriteOffsinCustCurr
            /// </summary>
            public const string TotalWriteOffsInCustCurr = "AMTWROFTC";

            /// <summary>
            /// Property for TotalInterestinCustCurr
            /// </summary>
            public const string TotalInterestInCustCurr = "AMTINTTTC";

            /// <summary>
            /// Property for TotalRetdChecksinCustCurr
            /// </summary>
            public const string TotalRetdChecksInCustCurr = "AMTRIFTC";

            /// <summary>
            /// Property for TotalInvoicesPdinCustCurr
            /// </summary>
            public const string TotalInvoicesPdInCustCurr = "AMTINVPDTC";

            /// <summary>
            /// Property for RevaluationBalinFuncCurr
            /// </summary>
            public const string RevaluationBalInFuncCurr = "AMTBARVALT";

            /// <summary>
            /// Property for AverageDaystoPay
            /// </summary>
            public const string AverageDaysToPay = "AVGDAYSPAY";

            /// <summary>
            /// Property for NumberofRefunds
            /// </summary>
            public const string NumberOfRefunds = "CNTRF";

            /// <summary>
            /// Property for TotalRefundsinFuncCurr
            /// </summary>
            public const string TotalRefundsInFuncCurr = "AMTRFHC";

            /// <summary>
            /// Property for TotalRefundsinCustCurr
            /// </summary>
            public const string TotalRefundsInCustCurr = "AMTRFTC";

            /// <summary>
            /// Property for YTDNumberofInvoices
            /// </summary>
            public const string YTDNumberOfInvoices = "YTDCNTIN";

            /// <summary>
            /// Property for YTDNumberofCredits
            /// </summary>
            public const string YTDNumberOfCredits = "YTDCNTCR";

            /// <summary>
            /// Property for YTDNumberofDebits
            /// </summary>
            public const string YTDNumberOfDebits = "YTDCNTDR";

            /// <summary>
            /// Property for YTDNumberofReceipts
            /// </summary>
            public const string YTDNumberOfReceipts = "YTDCNTPY";

            /// <summary>
            /// Property for YTDNumberofDiscounts
            /// </summary>
            public const string YTDNumberOfDiscounts = "YTDCNTED";

            /// <summary>
            /// Property for YTDNumberofAdjustments
            /// </summary>
            public const string YTDNumberOfAdjustments = "YTDCNTAD";

            /// <summary>
            /// Property for YTDNumberofWriteOffs
            /// </summary>
            public const string YTDNumberOfWriteOffs = "YTDCNTWO";

            /// <summary>
            /// Property for YTDNumberofInterestCharges
            /// </summary>
            public const string YTDNumberOfInterestCharges = "YTDCNTIT";

            /// <summary>
            /// Property for YTDNumberofReturnedChecks
            /// </summary>
            public const string YTDNumberOfReturnedChecks = "YTDCNTRIF";

            /// <summary>
            /// Property for YTDNumberofInvoicesPaid
            /// </summary>
            public const string YTDNumberOfInvoicesPaid = "YTDCNTINPD";

            /// <summary>
            /// Property for YTDNumberofRefunds
            /// </summary>
            public const string YTDNumberOfRefunds = "YTDCNTRF";

            /// <summary>
            /// Property for YTDNumberOfDaysToPay
            /// </summary>
            public const string YTDNumberOfDaysToPay = "YTDCNTDTP";

            /// <summary>
            /// Property for YTDInvoicesinFuncCurr
            /// </summary>
            public const string YTDInvoicesInFuncCurr = "YTDHCIN";

            /// <summary>
            /// Property for YTDCreditsinFuncCurr
            /// </summary>
            public const string YTDCreditsInFuncCurr = "YTDHCCR";

            /// <summary>
            /// Property for YTDDebitsinFuncCurr
            /// </summary>
            public const string YTDDebitsInFuncCurr = "YTDHCDR";

            /// <summary>
            /// Property for YTDReceiptsinFuncCurr
            /// </summary>
            public const string YTDReceiptsInFuncCurr = "YTDHCPY";

            /// <summary>
            /// Property for YTDDiscountsinFuncCurr
            /// </summary>
            public const string YTDDiscountsInFuncCurr = "YTDHCED";

            /// <summary>
            /// Property for YTDAdjustmentsinFuncCurr
            /// </summary>
            public const string YTDAdjustmentsInFuncCurr = "YTDHCAD";

            /// <summary>
            /// Property for YTDWriteOffsinFuncCurr
            /// </summary>
            public const string YTDWriteOffsInFuncCurr = "YTDHCWO";

            /// <summary>
            /// Property for YTDInterestinFuncCurr
            /// </summary>
            public const string YTDInterestInFuncCurr = "YTDHCIT";

            /// <summary>
            /// Property for YTDRetdChecksinFuncCurr
            /// </summary>
            public const string YTDRetdChecksInFuncCurr = "YTDHCRIF";

            /// <summary>
            /// Property for YTDInvoicesPdinFuncCurr
            /// </summary>
            public const string YTDInvoicesPdInFuncCurr = "YTDHCINPD";

            /// <summary>
            /// Property for YTDRefundsinFuncCurr
            /// </summary>
            public const string YTDRefundsInFuncCurr = "YTDHCRF";

            /// <summary>
            /// Property for YTDInvoicesinCustCurr
            /// </summary>
            public const string YTDInvoicesInCustCurr = "YTDTCIN";

            /// <summary>
            /// Property for YTDCreditsinCustCurr
            /// </summary>
            public const string YTDCreditsInCustCurr = "YTDTCCR";

            /// <summary>
            /// Property for YTDDebitsinCustCurr
            /// </summary>
            public const string YTDDebitsInCustCurr = "YTDTCDR";

            /// <summary>
            /// Property for YTDReceiptsinCustCurr
            /// </summary>
            public const string YTDReceiptsInCustCurr = "YTDTCPY";

            /// <summary>
            /// Property for YTDDiscountsinCustCurr
            /// </summary>
            public const string YTDDiscountsInCustCurr = "YTDTCED";

            /// <summary>
            /// Property for YTDAdjustmentsinCustCurr
            /// </summary>
            public const string YTDAdjustmentsInCustCurr = "YTDTCAD";

            /// <summary>
            /// Property for YTDWriteOffsinCustCurr
            /// </summary>
            public const string YTDWriteOffsInCustCurr = "YTDTCWO";

            /// <summary>
            /// Property for YTDInterestinCustCurr
            /// </summary>
            public const string YTDInterestInCustCurr = "YTDTCIT";

            /// <summary>
            /// Property for YTDRetdChecksinCustCurr
            /// </summary>
            public const string YTDRetdChecksInCustCurr = "YTDTCRIF";

            /// <summary>
            /// Property for YTDInvoicesPdinCustCurr
            /// </summary>
            public const string YTDInvoicesPdInCustCurr = "YTDTCINPD";

            /// <summary>
            /// Property for YTDRefundsinCustCurr
            /// </summary>
            public const string YTDRefundsInCustCurr = "YTDTCRF";

            /// <summary>
            /// Property for YTDAverageDaystoPay
            /// </summary>
            public const string YTDAverageDaysToPay = "YTDCNTADTP";

            /// <summary>
            /// Property for EnableYTDCalculations
            /// </summary>
            public const string EnableYTDCalculations = "YTDACTIVE";

            #endregion Properties
        }

        /// <summary>
        /// Contains list of CustomerStatistics Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for CustomerNumber
            /// </summary>
            public const int CustomerNumber = 1;

            /// <summary>
            /// Property Indexer for Year
            /// </summary>
            public const int Year = 2;

            /// <summary>
            /// Property Indexer for Period
            /// </summary>
            public const int Period = 3;

            /// <summary>
            /// Property Indexer for NumberofInvoices
            /// </summary>
            public const int NumberOfInvoices = 4;

            /// <summary>
            /// Property Indexer for NumberofCredits
            /// </summary>
            public const int NumberOfCredits = 5;

            /// <summary>
            /// Property Indexer for NumberofDebits
            /// </summary>
            public const int NumberOfDebits = 6;

            /// <summary>
            /// Property Indexer for NumberofReceipts
            /// </summary>
            public const int NumberOfReceipts = 7;

            /// <summary>
            /// Property Indexer for NumberofDiscounts
            /// </summary>
            public const int NumberOfDiscounts = 8;

            /// <summary>
            /// Property Indexer for NumberofAdjustments
            /// </summary>
            public const int NumberOfAdjustments = 9;

            /// <summary>
            /// Property Indexer for NumberofWriteOffs
            /// </summary>
            public const int NumberOfWriteOffs = 10;

            /// <summary>
            /// Property Indexer for NumberofInterestCharges
            /// </summary>
            public const int NumberOfInterestCharges = 11;

            /// <summary>
            /// Property Indexer for NumberofReturnedChecks
            /// </summary>
            public const int NumberOfReturnedChecks = 12;

            /// <summary>
            /// Property Indexer for NumberofInvoicesPaid
            /// </summary>
            public const int NumberOfInvoicesPaid = 13;

            /// <summary>
            /// Property Indexer for NumberofDaystoPay
            /// </summary>
            public const int NumberOfDaystoPay = 14;

            /// <summary>
            /// Property Indexer for TotalInvoicesinFuncCurr
            /// </summary>
            public const int TotalInvoicesInFuncCurr = 15;

            /// <summary>
            /// Property Indexer for TotalCreditsinFuncCurr
            /// </summary>
            public const int TotalCreditsInFuncCurr = 16;

            /// <summary>
            /// Property Indexer for TotalDebitsinFuncCurr
            /// </summary>
            public const int TotalDebitsInFuncCurr = 17;

            /// <summary>
            /// Property Indexer for TotalReceiptsinFuncCurr
            /// </summary>
            public const int TotalReceiptsInFuncCurr = 18;

            /// <summary>
            /// Property Indexer for TotalDiscountsinFuncCurr
            /// </summary>
            public const int TotalDiscountsInFuncCurr = 19;

            /// <summary>
            /// Property Indexer for TotalAdjustmentsinFuncCurr
            /// </summary>
            public const int TotalAdjustmentsInFuncCurr = 20;

            /// <summary>
            /// Property Indexer for TotalWriteOffsinFuncCurr
            /// </summary>
            public const int TotalWriteOffsInFuncCurr = 21;

            /// <summary>
            /// Property Indexer for TotalInterestinFuncCurr
            /// </summary>
            public const int TotalInterestInFuncCurr = 22;

            /// <summary>
            /// Property Indexer for TotalRetdChecksinFuncCurr
            /// </summary>
            public const int TotalRetdChecksInFuncCurr = 23;

            /// <summary>
            /// Property Indexer for TotalInvoicesPdinFuncCurr
            /// </summary>
            public const int TotalInvoicesPdInFuncCurr = 24;

            /// <summary>
            /// Property Indexer for TotalInvoicesinCustCurr
            /// </summary>
            public const int TotalInvoicesInCustCurr = 25;

            /// <summary>
            /// Property Indexer for TotalCreditsinCustCurr
            /// </summary>
            public const int TotalCreditsInCustCurr = 26;

            /// <summary>
            /// Property Indexer for TotalDebitsinCustCurr
            /// </summary>
            public const int TotalDebitsInCustCurr = 27;

            /// <summary>
            /// Property Indexer for TotalReceiptsinCustCurr
            /// </summary>
            public const int TotalReceiptsInCustCurr = 28;

            /// <summary>
            /// Property Indexer for TotalDiscountsinCustCurr
            /// </summary>
            public const int TotalDiscountsInCustCurr = 29;

            /// <summary>
            /// Property Indexer for TotalAdjustmentsinCustCurr
            /// </summary>
            public const int TotalAdjustmentsInCustCurr = 30;

            /// <summary>
            /// Property Indexer for TotalWriteOffsinCustCurr
            /// </summary>
            public const int TotalWriteOffsInCustCurr = 31;

            /// <summary>
            /// Property Indexer for TotalInterestinCustCurr
            /// </summary>
            public const int TotalInterestInCustCurr = 32;

            /// <summary>
            /// Property Indexer for TotalRetdChecksinCustCurr
            /// </summary>
            public const int TotalRetdChecksInCustCurr = 33;

            /// <summary>
            /// Property Indexer for TotalInvoicesPdinCustCurr
            /// </summary>
            public const int TotalInvoicesPdInCustCurr = 34;

            /// <summary>
            /// Property Indexer for RevaluationBalInFuncCurr
            /// </summary>
            public const int RevaluationBalInFuncCurr = 35;

            /// <summary>
            /// Property Indexer for AverageDaystoPay
            /// </summary>
            public const int AverageDaysToPay = 36;

            /// <summary>
            /// Property Indexer for NumberofRefunds
            /// </summary>
            public const int NumberofRefunds = 37;

            /// <summary>
            /// Property Indexer for TotalRefundsinFuncCurr
            /// </summary>
            public const int TotalRefundsInFuncCurr = 38;

            /// <summary>
            /// Property Indexer for TotalRefundsinCustCurr
            /// </summary>
            public const int TotalRefundsInCustCurr = 39;

            /// <summary>
            /// Property Indexer for YTDNumberofInvoices
            /// </summary>
            public const int YTDNumberOfInvoices = 50;

            /// <summary>
            /// Property Indexer for YTDNumberofCredits
            /// </summary>
            public const int YTDNumberOfCredits = 51;

            /// <summary>
            /// Property Indexer for YTDNumberofDebits
            /// </summary>
            public const int YTDNumberOfDebits = 52;

            /// <summary>
            /// Property Indexer for YTDNumberofReceipts
            /// </summary>
            public const int YTDNumberOfReceipts = 53;

            /// <summary>
            /// Property Indexer for YTDNumberofDiscounts
            /// </summary>
            public const int YTDNumberOfDiscounts = 54;

            /// <summary>
            /// Property Indexer for YTDNumberofAdjustments
            /// </summary>
            public const int YTDNumberOfAdjustments = 55;

            /// <summary>
            /// Property Indexer for YTDNumberofWriteOffs
            /// </summary>
            public const int YTDNumberOfWriteOffs = 56;

            /// <summary>
            /// Property Indexer for YTDNumberofInterestCharges
            /// </summary>
            public const int YTDNumberOfInterestCharges = 57;

            /// <summary>
            /// Property Indexer for YTDNumberofReturnedChecks
            /// </summary>
            public const int YTDNumberOfReturnedChecks = 58;

            /// <summary>
            /// Property Indexer for YTDNumberofInvoicesPaid
            /// </summary>
            public const int YTDNumberOfInvoicesPaid = 59;

            /// <summary>
            /// Property Indexer for YTDNumberofRefunds
            /// </summary>
            public const int YTDNumberOfRefunds = 60;

            /// <summary>
            /// Property Indexer for YTDNumberofDaystoPay
            /// </summary>
            public const int YTDNumberOfDaysToPay = 61;

            /// <summary>
            /// Property Indexer for YTDInvoicesinFuncCurr
            /// </summary>
            public const int YTDInvoicesInFuncCurr = 62;

            /// <summary>
            /// Property Indexer for YTDCreditsinFuncCurr
            /// </summary>
            public const int YTDCreditsInFuncCurr = 63;

            /// <summary>
            /// Property Indexer for YTDDebitsinFuncCurr
            /// </summary>
            public const int YTDDebitsInFuncCurr = 64;

            /// <summary>
            /// Property Indexer for YTDReceiptsinFuncCurr
            /// </summary>
            public const int YTDReceiptsInFuncCurr = 65;

            /// <summary>
            /// Property Indexer for YTDDiscountsinFuncCurr
            /// </summary>
            public const int YTDDiscountsInFuncCurr = 66;

            /// <summary>
            /// Property Indexer for YTDAdjustmentsinFuncCurr
            /// </summary>
            public const int YTDAdjustmentsInFuncCurr = 67;

            /// <summary>
            /// Property Indexer for YTDWriteOffsinFuncCurr
            /// </summary>
            public const int YTDWriteOffsInFuncCurr = 68;

            /// <summary>
            /// Property Indexer for YTDInterestinFuncCurr
            /// </summary>
            public const int YTDInterestInFuncCurr = 69;

            /// <summary>
            /// Property Indexer for YTDRetdChecksinFuncCurr
            /// </summary>
            public const int YTDRetdChecksInFuncCurr = 70;

            /// <summary>
            /// Property Indexer for YTDInvoicesPdinFuncCurr
            /// </summary>
            public const int YTDInvoicesPdInFuncCurr = 71;

            /// <summary>
            /// Property Indexer for YTDRefundsinFuncCurr
            /// </summary>
            public const int YTDRefundsInFuncCurr = 72;

            /// <summary>
            /// Property Indexer for YTDInvoicesinCustCurr
            /// </summary>
            public const int YTDInvoicesInCustCurr = 73;

            /// <summary>
            /// Property Indexer for YTDCreditsinCustCurr
            /// </summary>
            public const int YTDCreditsInCustCurr = 74;

            /// <summary>
            /// Property Indexer for YTDDebitsinCustCurr
            /// </summary>
            public const int YTDDebitsInCustCurr = 75;

            /// <summary>
            /// Property Indexer for YTDReceiptsinCustCurr
            /// </summary>
            public const int YTDReceiptsInCustCurr = 76;

            /// <summary>
            /// Property Indexer for YTDDiscountsinCustCurr
            /// </summary>
            public const int YTDDiscountsInCustCurr = 77;

            /// <summary>
            /// Property Indexer for YTDAdjustmentsinCustCurr
            /// </summary>
            public const int YTDAdjustmentsInCustCurr = 78;

            /// <summary>
            /// Property Indexer for YTDWriteOffsinCustCurr
            /// </summary>
            public const int YTDWriteOffsInCustCurr = 79;

            /// <summary>
            /// Property Indexer for YTDInterestinCustCurr
            /// </summary>
            public const int YTDInterestInCustCurr = 80;

            /// <summary>
            /// Property Indexer for YTDRetdChecksinCustCurr
            /// </summary>
            public const int YTDRetdChecksInCustCurr = 81;

            /// <summary>
            /// Property Indexer for YTDInvoicesPdinCustCurr
            /// </summary>
            public const int YTDInvoicesPdInCustCurr = 82;

            /// <summary>
            /// Property Indexer for YTDRefundsinCustCurr
            /// </summary>
            public const int YTDRefundsInCustCurr = 83;

            /// <summary>
            /// Property Indexer for YTDAverageDaystoPay
            /// </summary>
            public const int YTDAverageDaysToPay = 84;

            /// <summary>
            /// Property Indexer for EnableYTDCalculations
            /// </summary>
            public const int EnableYTDCalculations = 85;

            #endregion Properties
        }
    }
}