/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Model for Miscellaneous Receipt Details
    /// </summary>
    public partial class ReceiptMiscellaneousDetail : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ReceiptMiscellaneousDetail"/> class.
        /// </summary>
        public ReceiptMiscellaneousDetail()
        {
            CostClass = CostClass.None;
            TaxIncluded1 = AllowBlank.No;
            TaxIncluded2 = AllowBlank.No;
            TaxIncluded3 = AllowBlank.No;
            TaxIncluded4 = AllowBlank.No;
            TaxIncluded5 = AllowBlank.No;
        }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets AccountNumber 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AccountNumber, Id = Index.AccountNumber, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets G/LReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.GorLReference, Id = Index.GorLReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string GorLReference { get; set; }

        /// <summary>
        /// Gets or sets G/LDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.GorLDescription, Id = Index.GorLDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GorLDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1 
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2 
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3 
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4 
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5 
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1 
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2 
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3 
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4 
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5 
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlank TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2 
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3 
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4 
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5 
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1 
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2 
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3 
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4 
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5 
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>

        [Display(Name = "TaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DistAmount 
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DistAmount, Id = Index.DistAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmount { get; set; }

        /// <summary>
        /// Gets or sets DistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "DistAmountNetofTaxes", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DistAmountNetofTaxes, Id = Index.DistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmount 
        /// </summary>
        [Display(Name = "FuncDistAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncDistAmount, Id = Index.FuncDistAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncDistAmountNetofTaxes 
        /// </summary>
        [Display(Name = "FuncDistAmountNetofTaxes", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncDistAmountNetofTaxes, Id = Index.FuncDistAmountNetofTaxes, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDistAmountNetofTaxes { get; set; }

        /// <summary>
        /// Gets or sets COGSAmount 
        /// </summary>
        [Display(Name = "COGSAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CogsAmount, Id = Index.CogsAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CogsAmount { get; set; }

        /// <summary>
        /// Gets or sets AlternateTaxBaseAmount 
        /// </summary>
        [Display(Name = "AlternateTaxBaseAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.AlternateTaxBaseAmount, Id = Index.AlternateTaxBaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AlternateTaxBaseAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotal 
        /// </summary>
        [Display(Name = "TaxReportingTotal", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxReportingTotal, Id = Index.TaxReportingTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotal { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase1 
        /// </summary>
        [Display(Name = "FuncTaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase1, Id = Index.FuncTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase2 
        /// </summary>
        [Display(Name = "FuncTaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase2, Id = Index.FuncTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase3 
        /// </summary>
        [Display(Name = "FuncTaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase3, Id = Index.FuncTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase4 
        /// </summary>
        [Display(Name = "FuncTaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase4, Id = Index.FuncTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxBase5 
        /// </summary>
        [Display(Name = "FuncTaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxBase5, Id = Index.FuncTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount1 
        /// </summary>
        [Display(Name = "FuncTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount1, Id = Index.FuncTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount2 
        /// </summary>
        [Display(Name = "FuncTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount2, Id = Index.FuncTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount3 
        /// </summary>
        [Display(Name = "FuncTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount3, Id = Index.FuncTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount4 
        /// </summary>
        [Display(Name = "FuncTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount4, Id = Index.FuncTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAmount5 
        /// </summary>
        [Display(Name = "FuncTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxAmount5, Id = Index.FuncTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxTotal 
        /// </summary>
        [Display(Name = "FuncTaxTotal", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.FuncTaxTotal, Id = Index.FuncTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets ContractCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ContractCode, Id = Index.ContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ContractCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCode", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ProjectCode, Id = Index.ProjectCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string ProjectCode { get; set; }

        /// <summary>
        /// Gets or sets CategoryCode 
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CategoryCode, Id = Index.CategoryCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string CategoryCode { get; set; }

        /// <summary>
        /// Gets or sets ProjectOrCategoryResource 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ProjectCategoryResource", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ProjectOrCategoryResource, Id = Index.ProjectOrCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectOrCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets CostClass 
        /// </summary>
        [Display(Name = "CostClass", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets BillingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingDate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillingDate, Id = Index.BillingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BillingDate { get; set; }

         /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 1
        /// </summary>
        [ViewField(Name = Fields.AmtWHT1TC, Id = Index.AmtWHT1TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT1TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 2
        /// </summary>
        [ViewField(Name = Fields.AmtWHT2TC, Id = Index.AmtWHT2TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT2TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 3
        /// </summary>
        [ViewField(Name = Fields.AmtWHT3TC, Id = Index.AmtWHT3TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT3TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 4
        /// </summary>
        [ViewField(Name = Fields.AmtWHT4TC, Id = Index.AmtWHT4TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT4TC { get; set; } = 0;

        /// <summary>
        /// Gets or sets Estimated Tax Withheld Amount 5
        /// </summary>
        [ViewField(Name = Fields.AmtWHT5TC, Id = Index.AmtWHT5TC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmtWHT5TC { get; set; } = 0;

       #region UI

        /// <summary>
        /// Gets or sets AccountDescription 
        /// </summary>
        [Display(Name = "AccountDesc", ResourceType = typeof(ReceiptEntryResx))]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString
        {
            get { return EnumUtility.GetStringValue(CostClass); }
        }

        /// <summary>
        /// Gets or sets unformatted contract code
        /// </summary>
        [IgnoreExportImport]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets time and material project
        /// </summary>
        [IgnoreExportImport]
        public bool TimeAndMaterialProject { get; set; } = false;

        /// <summary>
        /// Gets or sets whether the dynamic attribute fields are disabled
        /// </summary>
        [IgnoreExportImport]
        public Dictionary<string, bool> FieldDisabledAttributes { get; set; }

        #endregion
    }
}
