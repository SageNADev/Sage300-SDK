// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// PostInvoice Model
    /// </summary>
    public partial class PostInvoice : ModelBase
    {

        /// <summary>
        /// Gets or sets ProcessAllBatches 
        /// </summary>
        [ViewField(Name = Fields.PostAllBatches, Id = Index.PostAllBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public PostAllBatches PostAllBatches { get; set; }

        /// <summary>
        /// Gets or sets FromBatch 
        /// </summary>
        [ViewField(Name = Fields.PostBatchFrom, Id = Index.PostBatchFrom, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchFrom { get; set; }

        /// <summary>
        /// Gets or sets ToBatch 
        /// </summary>
        [ViewField(Name = Fields.PostBatchTo, Id = Index.PostBatchTo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostBatchTo { get; set; }
    }
}
