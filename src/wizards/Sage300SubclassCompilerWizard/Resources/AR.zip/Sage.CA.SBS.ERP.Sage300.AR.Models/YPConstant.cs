﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// YPConstants
    /// </summary>
    public static class YPConstant
    {
        // Common Popup parameters 

        /// <summary>
        /// The customer identifier
        /// </summary>
        public const string CustomerId = "CUSTOMER";

        /// <summary>
        /// The transaction type
        /// </summary>
        public const string TransactionType = "TRANSACTIONTYPE";

        /// <summary>
        /// The transaction amount
        /// </summary>
        public const string TransactionAmount = "TRANSACTIONAMOUNT";

        /// <summary>
        /// The transaction identifier
        /// </summary>
        public const string TransactionId = "TRANSACTIONID";

        /// <summary>
        /// The previous transaction identifier
        /// </summary>
        public const string PrevTransactionId = "PREVIOUSTRANSACTIONID";

        /// <summary>
        /// The application identifier
        /// </summary>
        public const string AppId = "APPID";

        /// <summary>
        /// The reference
        /// </summary>
        public const string Reference = "REFERENCE1";

        /// <summary>
        /// The document number
        /// </summary>
        public const string DocumentNumber = "DOCUMENTNUMBER";

        /// <summary>
        /// The identifier card
        /// </summary>
        public const string IdCard = "IDCARD";

        /// <summary>
        /// The processing code
        /// </summary>
        public const string ProcessingCode = "PROCESSINGCODE";

        /// <summary>
        /// The status
        /// </summary>
        public const string Status = "STATUS";
    }
}
