// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Partial class for DocumentDetailPayment
	/// </summary>
	public partial class DocumentDetailPayment : ModelBase
	{
		/// <summary>
		/// Gets or sets CustomerNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CustomerNumber", ResourceType = typeof (ARCommonResx))]
		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string CustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets DocumentNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string DocumentNumber { get; set; }

		/// <summary>
		/// Gets or sets LineNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
		public decimal LineNumber { get; set; }

		/// <summary>
		/// Gets or sets SequenceNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNumber", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long SequenceNumber { get; set; }

		/// <summary>
		/// Gets or sets TransactionNumber
		/// </summary>
        [Display(Name = "TransactionNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long TransactionNumber { get; set; }

		/// <summary>
		/// Gets or sets PostingDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime PostingDate { get; set; }

		/// <summary>
		/// Gets or sets DocumentType
		/// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentPaymentType DocumentType { get; set; }

		/// <summary>
		/// Gets or sets TransactionType
		/// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentPaymentTransactionType TransactionType { get; set; }

		/// <summary>
		/// Gets or sets BatchType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string BatchType { get; set; }

		/// <summary>
		/// Gets or sets BatchNumber
		/// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
		public decimal BatchNumber { get; set; }

		/// <summary>
		/// Gets or sets EntryNumber
		/// </summary>
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
		public decimal EntryNumber { get; set; }

		/// <summary>
		/// Gets or sets BatchDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime BatchDate { get; set; }

		/// <summary>
		/// Gets or sets FuncReceiptAmount
		/// </summary>
        [Display(Name = "FunctionalReceiptAmount", ResourceType = typeof(DocumentInquiryResx))]
        [ViewField(Name = Fields.FunctionalReceiptAmount, Id = Index.FunctionalReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalReceiptAmount { get; set; }

		/// <summary>
		/// Gets or sets CustReceiptAmount
		/// </summary>
        [Display(Name = "CustomerReceiptAmount", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.CustomerReceiptAmount, Id = Index.CustomerReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal CustomerReceiptAmount { get; set; }

		/// <summary>
		/// Gets or sets FuncRetainageTaxInvoiced
		/// </summary>
        [Display(Name = "FunctionalRetainageTaxInvoiced", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.FunctionalRetainageTaxInvoiced, Id = Index.FunctionalRetainageTaxInvoiced, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal FunctionalRetainageTaxInvoiced { get; set; }

		/// <summary>
		/// Gets or sets CustRetainageTaxInvoiced
		/// </summary>
        [Display(Name = "CustomerRetainageTaxInvoiced", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.CustomerRetainageTaxInvoiced, Id = Index.CustomerRetainageTaxInvoiced, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal CustomerRetainageTaxInvoiced { get; set; }

		/// <summary>
		/// Gets or sets CurrencyCode
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string CurrencyCode { get; set; }

		/// <summary>
		/// Gets or sets RateType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
		public string RateType { get; set; }

		/// <summary>
		/// Gets or sets ExchangeRate
		/// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal ExchangeRate { get; set; }

		/// <summary>
		/// Gets or sets RateDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime RateDate { get; set; }

		/// <summary>
		/// Gets or sets RateOperator
		/// </summary>
        [Display(Name = "RateOperator", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
		public int RateOperator { get; set; }

		/// <summary>
		/// Gets or sets BankCode
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
		public string BankCode { get; set; }

		/// <summary>
		/// Gets or sets RemittingCustomerNumber
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemittingCustomerNumber", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.RemittingCustomerNumber, Id = Index.RemittingCustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string RemittingCustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets CheckReceiptNo
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckReceiptNo", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string CheckReceiptNo { get; set; }

		/// <summary>
		/// Gets or sets DepositSerialNumber
		/// </summary>
        [Display(Name = "DepositSerialNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.DepositSerialNumber, Id = Index.DepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
		public long DepositSerialNumber { get; set; }

		/// <summary>
		/// Gets or sets DepositLineNumber
		/// </summary>
        [Display(Name = "DepositLineNumber", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.DepositLineNumber, Id = Index.DepositLineNumber, FieldType = EntityFieldType.Long, Size = 4)]
		public long DepositLineNumber { get; set; }

		/// <summary>
		/// Gets or sets ReceiptDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDate", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ReceiptDate { get; set; }

		/// <summary>
		/// Gets or sets PaymentCUID
		/// </summary>
        [Display(Name = "PaymentCustomerId", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.PaymentCustomerId, Id = Index.PaymentCustomerId, FieldType = EntityFieldType.Long, Size = 4)]
		public long PaymentCustomerId { get; set; }

		/// <summary>
		/// Gets or sets ReferenceDocumentNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReferenceDocumentNumber", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.ReferenceDocumentNumber, Id = Index.ReferenceDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
		public string ReferenceDocumentNumber { get; set; }

		/// <summary>
		/// Gets or sets FiscalYear
		/// </summary>
		[StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
		public string FiscalYear { get; set; }

		/// <summary>
		/// Gets or sets FiscalPeriod
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
		public string FiscalPeriod { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets DocumentType string value
		/// </summary>
		public string DocumentTypeString
		{
			get { return EnumUtility.GetStringValue(DocumentType); }
		}

		/// <summary>
		/// Gets TransactionType string value
		/// </summary>
		public string TransactionTypeString
		{
			get { return EnumUtility.GetStringValue(TransactionType); }
		}

		#endregion
	}
}
