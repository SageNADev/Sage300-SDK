/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Status = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Status;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Customer Group Model
    /// </summary>
    public partial class CustomerGroup : ModelBase
    {
        /// <summary>
        /// Customer Group Constructor
        /// </summary>
        public CustomerGroup()
        {
            SalesPersonList = new EnumerableResponse<CustGrpSalesPerson>();
            CreditCurrencyList = new EnumerableResponse<CustGrpCurrency>();
            Statistic = new CustomerGroupStatistic();
            CustGrpOptFldValue = new EnumerableResponse<CustGrpOptFldValue>();
            CustTaxAuthorityList = new EnumerableResponse<CustTaxAuthority>();
        }
        /// <summary>
        /// Gets or sets GroupCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "GroupCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.GroupCode, Id = Index.GroupCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string GroupCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GroupDesc", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "InactiveAsOfDate", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets Status from Status Property
        /// </summary>
        [IgnoreExportImport]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status);  }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSet", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AccountSet, Id = Index.AccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSet { get; set; }

        /// <summary>
        /// Gets or sets AutocashProfile 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AutocashProfile", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AutocashProfile, Id = Index.AutocashProfile, FieldType = EntityFieldType.Char, Size = 6)]
        public string AutocashProfile { get; set; }

        /// <summary>
        /// Gets or sets BillingCycle 
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCycle", ResourceType = typeof(ARCommonResx))] 
        [ViewField(Name = Fields.BillingCycle, Id = Index.BillingCycle, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillingCycle { get; set; }

        /// <summary>
        /// Gets or sets InterestProfile 
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InterestProfile", ResourceType = typeof(ARCommonResx))] 
        [ViewField(Name = Fields.InterestProfile, Id = Index.InterestProfile, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string InterestProfile { get; set; }

        /// <summary>
        /// Gets or sets AccountType 
        /// </summary>
        [Display(Name = "AccountType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AccountType, Id = Index.AccountType, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerGroupAccountType AccountType { get; set; }

        /// <summary>
        /// Gets or sets Terms 
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Terms", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Terms, Id = Index.Terms, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Terms { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets AllowEditofCreditLimit 
        /// </summary>
        [Display(Name = "AllowEditOfCreditCheck", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.AllowEditofCreditLimit, Id = Index.AllowEditofCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowEditofCreditLimit AllowEditofCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit1Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditLimit1Currency", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit1Currency, Id = Index.CreditLimit1Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CreditLimit1Currency { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit1Amount 
        /// </summary>
        [Display(Name = "CreditLimit1Amount", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit1Amount, Id = Index.CreditLimit1Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit1Amount { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit2Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditLimit2Currency", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit2Currency, Id = Index.CreditLimit2Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CreditLimit2Currency { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit2Amount 
        /// </summary>
        [Display(Name = "CreditLimit2Amount", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit2Amount, Id = Index.CreditLimit2Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit2Amount { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit3Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditLimit3Currency", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit3Currency, Id = Index.CreditLimit3Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CreditLimit3Currency { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit3Amount 
        /// </summary>
        [Display(Name = "CreditLimit3Amount", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit3Amount, Id = Index.CreditLimit3Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit3Amount { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit4Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditLimit4Currency", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit4Currency, Id = Index.CreditLimit4Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CreditLimit4Currency { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit4Amount 
        /// </summary>
        [Display(Name = "CreditLimit4Amount", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit4Amount, Id = Index.CreditLimit4Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit4Amount { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit5Currency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditLimit5Currency", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit5Currency, Id = Index.CreditLimit5Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CreditLimit5Currency { get; set; }

        /// <summary>
        /// Gets or sets CreditLimit5Amount 
        /// </summary>
        [Display(Name = "CreditLimit5Amount", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CreditLimit5Amount, Id = Index.CreditLimit5Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditLimit5Amount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields 
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public CustGrpProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode1 
        /// </summary>
        [Display(Name = "TaxClassCode1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode1, Id = Index.TaxClassCode1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode2 
        /// </summary>
        [Display(Name = "TaxClassCode2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode2, Id = Index.TaxClassCode2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode3 
        /// </summary>
        [Display(Name = "TaxClassCode3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode3, Id = Index.TaxClassCode3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode4 
        /// </summary>
        [Display(Name = "TaxClassCode4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode4, Id = Index.TaxClassCode4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClassCode5 
        /// </summary>
        [Display(Name = "TaxClassCode5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxClassCode5, Id = Index.TaxClassCode5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClassCode5 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson1 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson1, Id = Index.Salesperson1, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson1 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson2 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson2, Id = Index.Salesperson2, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson2 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson3 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson3, Id = Index.Salesperson3, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson3 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson4 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson4, Id = Index.Salesperson4, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson4 { get; set; }

        /// <summary>
        /// Gets or sets Salesperson5 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Salesperson5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Salesperson5, Id = Index.Salesperson5, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string Salesperson5 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage1 
        /// </summary>
        [Display(Name = "SalesSplitPercentage1", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage1, Id = Index.SalesSplitPercentage1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage1 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage2 
        /// </summary>
        [Display(Name = "SalesSplitPercentage2", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage2, Id = Index.SalesSplitPercentage2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage2 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage3 
        /// </summary>
        [Display(Name = "SalesSplitPercentage3", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage3, Id = Index.SalesSplitPercentage3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage3 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage4 
        /// </summary>
        [Display(Name = "SalesSplitPercentage4", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage4, Id = Index.SalesSplitPercentage4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage4 { get; set; }

        /// <summary>
        /// Gets or sets SalesSplitPercentage5 
        /// </summary>
        [Display(Name = "SalesSplitPercentage5", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SalesSplitPercentage5, Id = Index.SalesSplitPercentage5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal SalesSplitPercentage5 { get; set; }

        /// <summary>
        /// Gets or sets PrintStatements 
        /// </summary>
        [Display(Name = "PrintStatements", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PrintStatements, Id = Index.PrintStatements, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowEditofCreditLimit PrintStatements { get; set; }

        /// <summary>
        /// Gets or sets CheckCreditLimit 
        /// </summary>
        [Display(Name = "TotalOutExceedsLimit", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CheckCreditLimit, Id = Index.CheckCreditLimit, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowEditofCreditLimit CheckCreditLimit { get; set; }

        /// <summary>
        /// Gets or sets CheckOverdueAmounts 
        /// </summary>
        [Display(Name = "ARTransactionsAreOverdueByDays", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.CheckOverdueAmounts, Id = Index.CheckOverdueAmounts, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowEditofCreditLimit CheckOverdueAmounts { get; set; }

        /// <summary>
        /// Gets or sets DaysOverdue 
        /// </summary>
        [Display(Name = "DaysOverdue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DaysOverdue, Id = Index.DaysOverdue, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysOverdue { get; set; }

        /// <summary>
        /// Gets or sets AmountOverdue1 
        /// </summary>
        [Display(Name = "AmountOverdue1", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.AmountOverdue1, Id = Index.AmountOverdue1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOverdue1 { get; set; }

        /// <summary>
        /// Gets or sets AmountOverdue2 
        /// </summary>
        [Display(Name = "AmountOverdue2", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.AmountOverdue2, Id = Index.AmountOverdue2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOverdue2 { get; set; }

        /// <summary>
        /// Gets or sets AmountOverdue3 
        /// </summary>
        [Display(Name = "AmountOverdue3", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.AmountOverdue3, Id = Index.AmountOverdue3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOverdue3 { get; set; }

        /// <summary>
        /// Gets or sets AmountOverdue4 
        /// </summary>
        [Display(Name = "AmountOverdue4", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.AmountOverdue4, Id = Index.AmountOverdue4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOverdue4 { get; set; }

        /// <summary>
        /// Gets or sets AmountOverdue5 
        /// </summary>
        [Display(Name = "AmountOverdue5", ResourceType = typeof(CustomerGroupsResx))]
        [ViewField(Name = Fields.AmountOverdue5, Id = Index.AmountOverdue5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountOverdue5 { get; set; }


        /// <summary>
        /// Gets or Sets Statistic
        /// </summary>
        [IgnoreExportImport]
        public CustomerGroupStatistic Statistic { get; set; }

        /// <summary>
        /// Gets or Sets CustGrpOptFldValue
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CustGrpOptFldValue> CustGrpOptFldValue { get; set; }

        /// <summary>
        /// Gets or Sets SalesPersonList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CustGrpSalesPerson> SalesPersonList { get; set; }

        /// <summary>
        /// Gets or Sets CreditCurrencyList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CustGrpCurrency> CreditCurrencyList { get; set; }

        /// <summary>
        /// Gets or Sets CustTaxAuthorityList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CustTaxAuthority> CustTaxAuthorityList { get; set; }

        /// <summary>
        /// Gets and sets FunctionalCurrency(Added to get the Functional Currency Set in CS Company Profile)
        /// </summary>
        [IgnoreExportImport]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets the account type string.
        /// </summary>
       [IgnoreExportImport]
        public string AccountTypeString
        {
            get { return EnumUtility.GetStringValue(AccountType); }
        }

        /// <summary>
        /// Gets the print statements string.
        /// </summary>
        [IgnoreExportImport]
        public string PrintStatementsString
        {
            get { return EnumUtility.GetStringValue(PrintStatements); }
        }

        /// <summary>
        /// Gets the CheckCreditLimit string.
        /// </summary>
        [IgnoreExportImport]
        public string CheckCreditLimitString
        {
            get { return EnumUtility.GetStringValue(CheckCreditLimit); }
        }

        /// <summary>
        /// Gets the CheckOverdueAmounts string.
        /// </summary>
        [IgnoreExportImport]
        public string CheckOverdueAmountsString
        {
            get { return EnumUtility.GetStringValue(CheckOverdueAmounts); }
        }

        
        
        
        /// <summary>
        /// Gets the AllowEditOfCreditCheck string.
        /// </summary>
       [IgnoreExportImport]
        public string AllowEditOfCreditCheckString
        {
            get { return EnumUtility.GetStringValue(AllowEditofCreditLimit); }
        }
        
        /// <summary>
        /// Gets the ProcessCommandCode string.
        /// </summary>
       [IgnoreExportImport]
        public string ProcessCommandCodeString
        {
           get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
       /// Gets and Sets the SessionDate 
        /// </summary>
       [IgnoreExportImport]
       public DateTime SessionDate { get; set; }

       /// <summary>
       /// Fiscal Period Start  year
       /// </summary>
       [IgnoreExportImport]
        public string StartYear { get; set; }

       /// <summary>
       /// Fiscal Period End year
       /// </summary>
       [IgnoreExportImport]
        public string EndYear { get; set; }

        /// <summary>
       /// Check Optional Tab Selected while saving.
        /// </summary>
         [IgnoreExportImport]
        public bool SaveOptionalFields { get; set; }

        /// <summary>
         /// Check Statistics Tab Selected while saving.
        /// </summary>
         [IgnoreExportImport]
        public bool SaveStatistics { get; set; }

         [IgnoreExportImport]
        public string Reserved { get; set; }

        /// <summary>
        /// Checks Is Multi Currency
        /// </summary>
        [IgnoreExportImport] 
        public bool IsMultiCurrency { get; set; }
    }

    /// <summary>
    /// CustomerGroup Sales Person Class 
    /// </summary>
    public class CustGrpSalesPerson : ModelBase
    {
        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        public long LineNumber { get; set; }

        /// <summary>
        /// Gets and Sets SalesPersonCode
        /// </summary>
        [Display(Name = "SalespersonCode", ResourceType = typeof(ARCommonResx))]
        public string SalesPersonCode { get; set; }

        /// <summary>
        ///  Gets and Sets SalesPersonName
        /// </summary>
        [Display(Name = "SalespersonName", ResourceType = typeof(ARCommonResx))]
        public string SalesPersonName { get; set; }

        /// <summary>
        /// Gets and Sets SalesPercentage
        /// </summary>
        [Display(Name = "Percentage", ResourceType = typeof(ARCommonResx))]
        public string SalesPercentage { get; set; }

    }

    /// <summary>
    /// CustomerGroup Sales Person Class 
    /// </summary>
    public class CustGrpCurrency : ModelBase
    {

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        public long LineNumber { get; set; }

        /// <summary>
        /// Gets and Sets Currency
        /// </summary>
        [Display(Name = "Currency", ResourceType = typeof(ARCommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Currency { get; set; }

        /// <summary>
        ///  Gets and Sets CreditAmount
        /// </summary>
        [Display(Name = "CreditAmount", ResourceType = typeof(ARCommonResx))]
        public string CreditAmount { get; set; }

        /// <summary>
        /// Gets and Sets OverdueAmount
        /// </summary>
        [Display(Name = "OverdueLimit", ResourceType = typeof(CustomerGroupsResx))]
        public string OverdueAmount { get; set; }

        /// <summary>
        /// Gets and Sets Currency Decimal
        /// </summary>
        public int CurrencyDecimal { get; set; }
    }

    /// <summary>
    /// Customer Tax Authority (Class For Grid)
    /// </summary>
    public class CustTaxAuthority : ModelBase
    {
        /// <summary>
        /// Gets and Sets TaxAuthority
        /// </summary>
        [Display(Name = "TaxAuthority", ResourceType = typeof(ARCommonResx))]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets and Sets TaxAuthorityDescription
        /// </summary>
        [Display(Name = "TaxGroupDesc", ResourceType = typeof(CustomerGroupsResx))]
        public string TaxAuthorityDescription { get; set; }

        /// <summary>
        /// Gets and Sets TaxClass for the TaxAuthority
        /// </summary>
        [Display(Name = "TaxClass", ResourceType = typeof(ARCommonResx))]
        public int TaxClass { get; set; }
    }

}
