﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.GLIntegration;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class for G/L Reference Integration
    /// </summary>
    public partial class GLReferenceIntegration : BaseGLReferenceIntegration
    {
        /// <summary>
        /// Gets or sets Source Transaction Type 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "TransactionType", ResourceType = typeof(GLIntegrationResx))]
        public SourceTransactionType SourceTransactionType { get; set; }

        //The following properties don't have display attribute as it is not mapped to UI controls directly//
        
        /// <summary>
        /// Gets or sets Included Segment 1 
        /// </summary>
        public IncludedSegment1 IncludedSegment1 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 2 
        /// </summary>
        public IncludedSegment1 IncludedSegment2 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 3 
        /// </summary>
        public IncludedSegment1 IncludedSegment3 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 4 
        /// </summary>
        public IncludedSegment1 IncludedSegment4 { get; set; }

        /// <summary>
        /// Gets or sets Included Segment 5 
        /// </summary>
        public IncludedSegment1 IncludedSegment5 { get; set; }

        #region override UI properties

        //The following properties don't have display attribute as it is not mapped to UI controls directly

        /// <summary>
        /// Gets or sets Source Transaction Type Value 
        /// </summary>
        public override int SourceTransactionTypeValue
        {
            get { return Convert.ToInt32(SourceTransactionType); }
            set { SourceTransactionType = (SourceTransactionType)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 1 Value 
        /// </summary>
        public override int IncludedSegment1Value
        {
            get { return Convert.ToInt32(IncludedSegment1); }
            set { IncludedSegment1 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 2 Value 
        /// </summary>
        public override int IncludedSegment2Value
        {
            get { return Convert.ToInt32(IncludedSegment2); }
            set { IncludedSegment2 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 3 Value 
        /// </summary>
        public override int IncludedSegment3Value
        {
            get { return Convert.ToInt32(IncludedSegment3); }
            set { IncludedSegment3 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 4 Value 
        /// </summary>
        public override int IncludedSegment4Value
        {
            get { return Convert.ToInt32(IncludedSegment4); }
            set { IncludedSegment4 = (IncludedSegment1)value; }
        }

        /// <summary>
        /// Gets or sets Included Segment 5 Value 
        /// </summary>
        public override int IncludedSegment5Value
        {
            get { return Convert.ToInt32(IncludedSegment5); }
            set { IncludedSegment5 = (IncludedSegment1)value; }
        }

        #endregion

    }
}
