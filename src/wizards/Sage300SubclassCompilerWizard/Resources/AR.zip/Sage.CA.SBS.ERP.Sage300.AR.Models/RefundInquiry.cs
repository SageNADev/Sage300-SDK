﻿/* Copyright (c) 2020 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// A class to use in the Search criteria of RefundInquiry screen
    /// </summary>
    public class RefundInquiry : ModelBase
    {
        private const char Z = 'Z';

        private const int BankCodeLength = 8;
        private const int CustomerNumberLength = 12;
        private const int DocumentNumberLength = 22;
        private const int CheckNumberLength = 15;

        /// <summary>
        /// Gets or sets the property of IsMulticurrency
        /// </summary>
        public bool IsMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets the property of FunctionalCurrency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets the property of BankFrom
        /// </summary>
        [Display(Name = "FromBank", ResourceType = typeof(RefundInquiryResx))]
        [StringLength(BankCodeLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string BankFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of BankTo
        /// </summary>
        [Display(Name = "ToBank", ResourceType = typeof(ARCommonResx))]
        [StringLength(BankCodeLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string BankTo { get; set; }

        /// <summary>
        /// Gets or sets the property of CustomerFrom
        /// </summary>
        [Display(Name = "FromCustomerNumber", ResourceType = typeof(RefundInquiryResx))]
        [StringLength(CustomerNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CustomerFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of CustomerTo
        /// </summary>
        [Display(Name = "ToCustomerNumber", ResourceType = typeof(ARCommonResx))]
        [StringLength(CustomerNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CustomerTo { get; set; }

        /// <summary>
        /// Gets or sets the property of RefundFrom
        /// </summary>
        [Display(Name = "FromRefundDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? RefundFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of RefundTo
        /// </summary>
        [Display(Name = "ToRefundDate", ResourceType = typeof(ARCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? RefundTo { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalYearFrom
        /// </summary>
        [Display(Name = "FromYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(decimal), "1000", "9999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalYearFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalYearTo
        /// </summary>
        [Display(Name = "FromYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(decimal), "1000", "9999", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalYearTo { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalPeriodFrom
        /// </summary>
        [Display(Name = "FromYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(decimal), "1", "99", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalPeriodFrom { get; set; }

        /// <summary>
        /// Gets or sets the property of FiscalPeriodTo
        /// </summary>
        [Display(Name = "ToYearPeriod", ResourceType = typeof(ARCommonResx))]
        [Range(typeof(decimal), "1", "99", ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public int FiscalPeriodTo { get; set; }

        /// <summary>
        /// Gets or sets the DocumentNumberFrom
        /// </summary>
        [Display(Name = "FromDocumentNumber", ResourceType = typeof(RefundInquiryResx))]
        [StringLength(DocumentNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DocumentNumberFrom { get; set; }

        /// <summary>
        /// Gets or sets the DocumentNumberTo
        /// </summary>
        [Display(Name = "ToDocumentNumber", ResourceType = typeof(RefundInquiryResx))]
        [StringLength(DocumentNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DocumentNumberTo { get; set; }

        /// <summary>
        /// Gets or sets the CheckNumberFrom
        /// </summary>
        [Display(Name = "FromCheckNumber", ResourceType = typeof(RefundInquiryResx))]
        [StringLength(CheckNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CheckNumberFrom { get; set; }

        /// <summary>
        /// Gets or sets the CheckNumberTo
        /// </summary>
        [Display(Name = "ToCheckNumber", ResourceType = typeof(RefundInquiryResx))]
        [StringLength(CheckNumberLength, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CheckNumberTo { get; set; }

        #region Constructor

        /// <summary>
        /// Default Parameterless Constructor
        /// </summary>
        public RefundInquiry()
        {
            BankTo = CommonUtil.Repeat(Z, BankCodeLength);
            CustomerTo = CommonUtil.Repeat(Z, CustomerNumberLength);
            RefundTo = DateUtil.GetMaxDate();
            DocumentNumberTo = CommonUtil.Repeat(Z, DocumentNumberLength);
            CheckNumberTo = CommonUtil.Repeat('9', CheckNumberLength);
        }

        /// <summary>
        /// Gets or sets the property of PaymentType
        /// </summary>
        [Display(Name = "PaymentType", ResourceType = typeof(ARCommonResx))]
        public ARPaymentType PaymentType { get; set; }

        /// <summary>
        /// Gets or sets the property of Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        public PaymentStatus Status { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultToYear { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultToPeriod { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultFromYear { get; set; }

        /// <summary>
        ///  Gets or Sets DefaultToYear 
        /// </summary>
        public string DefaultFromPeriod { get; set; }

        #endregion
    }
}