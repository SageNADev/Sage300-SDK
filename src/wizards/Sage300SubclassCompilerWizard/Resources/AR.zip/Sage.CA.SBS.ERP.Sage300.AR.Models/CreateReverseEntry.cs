/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */
/* Portions co-modified with Claude Code */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Class CreateReverseEntry. Maps to ARRIB view (AR0530) used to create a
    /// reverse invoice entry or reverse invoice batch from a posted batch.
    /// </summary>
    public partial class CreateReverseEntry : ModelBase
    {
        /// <summary>
        /// Gets or sets OptionSwitch
        /// </summary>
        [ViewField(Name = Fields.OptionSwitch, Id = Index.OptionSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionSwitch OptionSwitch { get; set; }

        /// <summary>
        /// Gets or sets SelectedBatchId
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SelectedBatchId, Id = Index.SelectedBatchId, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string SelectedBatchId { get; set; }

        /// <summary>
        /// Gets or sets SelectedEntry
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SelectedEntry, Id = Index.SelectedEntry, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string SelectedEntry { get; set; }

        /// <summary>
        /// Gets or sets ReverseBatchId
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReverseBatchId, Id = Index.ReverseBatchId, FieldType = EntityFieldType.Char, Size = 5, Mask = "%05D")]
        public string ReverseBatchId { get; set; }

        /// <summary>
        /// Gets or sets ReverseBatchDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.ReverseBatchDescription, Id = Index.ReverseBatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReverseBatchDescription { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumberOption
        /// </summary>
        [ViewField(Name = Fields.DocumentNumberOption, Id = Index.DocumentNumberOption, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentNumberOption DocumentNumberOption { get; set; }

        /// <summary>
        /// Gets or sets ReverseDocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ReverseDocumentNumber, Id = Index.ReverseDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string ReverseDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets HeaderDescriptionOption
        /// </summary>
        [ViewField(Name = Fields.HeaderDescriptionOption, Id = Index.HeaderDescriptionOption, FieldType = EntityFieldType.Int, Size = 2)]
        public HeaderDescriptionOption HeaderDescriptionOption { get; set; }

        /// <summary>
        /// Gets or sets HeaderDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryDescription", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.HeaderDescription, Id = Index.HeaderDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string HeaderDescription { get; set; }

        /// <summary>
        /// Gets or sets CreatedReverseEntryNo
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedReverseEntryNo", ResourceType = typeof(InvoiceEntryResx))]
        [ViewField(Name = Fields.CreatedReverseEntryNo, Id = Index.CreatedReverseEntryNo, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string CreatedReverseEntryNo { get; set; }

        /// <summary>
        /// Gets or sets Reverse Mode
        /// </summary>
        public ReverseMode ReverseMode { get; set; }

        /// <summary>
        /// Gets or sets Original With Prefix description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalWithPrefix", ResourceType = typeof(InvoiceEntryResx))]
        public string OriginalWithPrefix { get; set; }

        /// <summary>
        /// Gets or sets New Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NewDescription", ResourceType = typeof(InvoiceEntryResx))]
        public string NewDescription { get; set; }

        /// <summary>
        /// Gets or sets IsProcessDone
        /// </summary>
        public bool IsProcessDone { get; set; }

        /// <summary>
        /// Gets or sets the message
        /// </summary>
        public string Message { get; set; }
    }
}
