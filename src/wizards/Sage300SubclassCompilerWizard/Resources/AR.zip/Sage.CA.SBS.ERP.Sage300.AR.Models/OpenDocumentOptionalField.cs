// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	/// <summary>
	/// Partial class for OpenDocumentOptionalField
	/// </summary>
	public partial class OpenDocumentOptionalField : ModelBase
	{
		/// <summary>
		/// Gets or sets CustomerNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string CustomerNumber { get; set; }

		/// <summary>
		/// Gets or sets DocumentNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string DocumentNumber { get; set; }

		/// <summary>
		/// Gets or sets OptionalField
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
		[ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
		public string OptionalField { get; set; }

		/// <summary>
		/// Gets or sets Value
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Value", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
		public string Value { get; set; }

		/// <summary>
		/// Gets or sets Type
		/// </summary>
        [Display(Name = "Type", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
		public Enums.Type Type { get; set; }

		/// <summary>
		/// Gets or sets Length
		/// </summary>
        [Display(Name = "Length", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
		public int Length { get; set; }

		/// <summary>
		/// Gets or sets Decimals
		/// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(InvoiceResx))]
		[ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
		public int Decimals { get; set; }

		/// <summary>
		/// Gets or sets AllowBlank
		/// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(InvoiceResx))]
		[ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
		public AllowBlank AllowBlank { get; set; }

		/// <summary>
		/// Gets or sets Validate
		/// </summary>
        [Display(Name = "Validate", ResourceType = typeof(InvoiceResx))]
		[ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
		public Validate Validate { get; set; }

		/// <summary>
		/// Gets or sets TypedValueFieldIndex
		/// </summary>
        [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(InvoiceResx))]
		[ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
		public long TypedValueFieldIndex { get; set; }

		/// <summary>
		/// Gets or sets TextValue
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TextValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
		public string TextValue { get; set; }

		/// <summary>
		/// Gets or sets AmountValue
		/// </summary>
        [Display(Name = "AmountValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal AmountValue { get; set; }

		/// <summary>
		/// Gets or sets NumberValue
		/// </summary>
        [Display(Name = "NumberValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal NumberValue { get; set; }

		/// <summary>
		/// Gets or sets IntegerValue
		/// </summary>
        [Display(Name = "Generated", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
		public long IntegerValue { get; set; }

		/// <summary>
		/// Gets or sets YesNoValue
		/// </summary>
        [Display(Name = "YesNoValue", ResourceType = typeof(DocumentInquiryResx))]
		[ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
		public YesNoValue YesNoValue { get; set; }

		/// <summary>
		/// Gets or sets DateValue
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateValue { get; set; }

		/// <summary>
		/// Gets or sets TimeValue
		/// </summary>
        [Display(Name = "TimeValue", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
		public TimeSpan TimeValue { get; set; }

		/// <summary>
		/// Gets or sets OptionalFieldDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(InvoiceResx))]
		[ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string OptionalFieldDescription { get; set; }

		/// <summary>
		/// Gets or sets ValueDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ValueDescription", ResourceType = typeof(ARCommonResx))]
		[ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string ValueDescription { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets Type string value
		/// </summary>
		public string TypeString
		{
			get { return EnumUtility.GetStringValue(Type); }
		}

		/// <summary>
		/// Gets AllowBlank string value
		/// </summary>
		public string AllowBlankString
		{
			get { return EnumUtility.GetStringValue(AllowBlank); }
		}

		/// <summary>
		/// Gets Validate string value
		/// </summary>
		public string ValidateString
		{
			get { return EnumUtility.GetStringValue(Validate); }
		}

		/// <summary>
		/// Gets YesNoValue string value
		/// </summary>
		public string YesNoValueString
		{
			get { return EnumUtility.GetStringValue(YesNoValue); }
		}

		#endregion
	}
}
