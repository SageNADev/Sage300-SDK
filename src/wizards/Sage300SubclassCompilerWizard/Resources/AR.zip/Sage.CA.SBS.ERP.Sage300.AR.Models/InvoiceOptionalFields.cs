/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Invoice Optional Fields
    /// </summary>
    public partial class InvoiceOptionalFields : BaseInvoiceOptionalField
    {       
    }
}
