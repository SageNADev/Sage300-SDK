// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for FunctionParametersHeader
    /// </summary>
    public partial class FunctionParametersHeader : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the Function Parameters Header/> class.
        /// </summary>
        public FunctionParametersHeader()
        {
            FunctionParametersDetails = new EnumerableResponse<FunctionParametersDetail>();
        }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public Function Function { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets OptFields
        /// </summary>
        /// <value>Function Parameters Details</value>
        public EnumerableResponse<FunctionParametersDetail> FunctionParametersDetails { get; set; }

    }
}
