// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Refund Batch Model
    /// </summary>
    public partial class RefundBatch : ModelBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RefundBatch"/> class.
        /// </summary>
        public RefundBatch()
        {
            RefundEntry = new RefundEntry();
            BatchType = BatchType.Entered;
            BatchStatus = RefundBatchStatus.Open;
            PostRefund = new PostRefund();
        }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BatchDate { get; set; }

        /// <summary>
        /// Gets or sets BatchDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchDescription", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchDescription, Id = Index.BatchDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BatchDescription { get; set; }

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Display(Name = "BatchType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public BatchType BatchType { get; set; }

        /// <summary>
        /// Gets or sets BatchStatus 
        /// </summary>
        [Display(Name = "BatchStatus", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchStatus, Id = Index.BatchStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public RefundBatchStatus BatchStatus { get; set; }

        /// <summary>
        /// Gets or sets NumberofEntries 
        /// </summary>
        [Display(Name = "NumberofEntries", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofEntries, Id = Index.NumberofEntries, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofEntries { get; set; }

        /// <summary>
        /// Gets or sets TotalofEntries 
        /// </summary>
        [Display(Name = "TotalAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TotalofEntries, Id = Index.TotalofEntries, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalofEntries { get; set; }

        /// <summary>
        /// Gets or sets LastEntryNumber 
        /// </summary>
        [Display(Name = "LastEntryNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.LastEntryNumber, Id = Index.LastEntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal LastEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [Display(Name = "PostingSequenceNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets NumberofErrors 
        /// </summary>
        [Display(Name = "NumberofErrors", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NumberofErrors, Id = Index.NumberofErrors, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NumberofErrors { get; set; }

        /// <summary>
        /// Gets or sets DateCreated 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCreated", ResourceType = typeof(RefundEntryResx))]
        [ViewField(Name = Fields.DateCreated, Id = Index.DateCreated, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCreated { get; set; }

        /// <summary>
        /// Gets or sets DateLastEdited 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateLastEdited", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DateLastEdited, Id = Index.DateLastEdited, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastEdited { get; set; }

        /// <summary>
        /// Gets or sets BatchPrintedFlag 
        /// </summary>
        [Display(Name = "BatchPrintedFlag", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchPrintedFlag, Id = Index.BatchPrintedFlag, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed BatchPrintedFlag { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode 
        /// </summary>
        [Display(Name = "ProcessCommandCode", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ProcessCommandCode, Id = Index.ProcessCommandCode, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets NumberofPrintedChecks 
        /// </summary>
        [ViewField(Name = Fields.NumberofPrintedChecks, Id = Index.NumberofPrintedChecks, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal NumberofPrintedChecks { get; set; }

        /// <summary>
        /// Refund Entry (Header) related to the Refund Batch
        /// </summary>
        public RefundEntry RefundEntry { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }


        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        public short SessionWarnDays { get; set; }
        
        /// <summary>
        /// Gets or sets the Post Refund model. 
        /// </summary>
        public PostRefund PostRefund { get; set; }
        #region UI

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string.</value>
        [IgnoreExportImport]
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(BatchType); }
        }

        /// <summary>
        /// To get the string of Status property
        /// </summary>
        /// <value>The status string.</value>
        [IgnoreExportImport]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(BatchStatus); }
        }

        /// <summary>
        /// To get the string of BatchPrintedFlag property
        /// </summary>
        /// <value>The type string.</value>
        public string PrintedFlag
        {
            get { return EnumUtility.GetStringValue(BatchPrintedFlag); }
        }

        /// <summary>
        /// To get the string of ProcessCommandCode property
        /// </summary>
        /// <value>The type string.</value>
        [IgnoreExportImport]
        public string CommandCode
        {
            get { return EnumUtility.GetStringValue(ProcessCommandCode); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is oe active.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is oe active; otherwise, <c>false</c>.
        /// </value>
        [IgnoreExportImport]
        public bool IsYpActive { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is oe active.
        /// </summary>
        /// <value>
        /// <c>true</c> if this instance is oe active; otherwise, <c>false</c>.
        /// </value>
        [IgnoreExportImport]
        public bool IsGlActive { get; set; }


        /// <summary>
        /// Gets or sets a value indicating whether [have opt field license].
        /// </summary>
        /// <value>
        /// <c>true</c> if [have opt field license]; otherwise, <c>false</c>.
        /// </value>
        [IgnoreExportImport]
        public bool HaveOptFldLicense { get; set; }

        #endregion
    }
}
