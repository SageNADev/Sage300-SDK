// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 
#region
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
#endregion

// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
	public partial class ItemStatistic : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets ItemNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ItemNo", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
 		public string ItemNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets UnitofMeasure 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.UnitofMeasure, Id = Index.UnitofMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
 		public string UnitofMeasure {get; set;}
		 
  		/// <summary>
        /// Gets or sets Year 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Year", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.Year, Id = Index.Year, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
 		public string Year {get; set;}
		 
  		/// <summary>
        /// Gets or sets Period 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "Period", ResourceType = typeof(ARCommonResx))]
 		[ViewField(Name = Fields.Period, Id = Index.Period, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
 		public string Period {get; set;}
		
		/// <summary>
        /// Gets or sets DateofLastSale 
        /// </summary>
        // [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]	
        [Display(Name = "DateofLastSale", ResourceType = typeof(ItemsResx))]	
		 [ViewField(Name = Fields.DateofLastSale, Id = Index.DateofLastSale, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime? DateofLastSale {get; set;}
	 
  		/// <summary>
        /// Gets or sets NumberofSales 
        /// </summary>
        [Display(Name = "NumberofSales", ResourceType = typeof(ItemsResx))]	
 		[ViewField(Name = Fields.NumberofSales, Id = Index.NumberofSales, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofSales {get; set;}
		 
  		/// <summary>
        /// Gets or sets NumberofReturns 
        /// </summary>
        [Display(Name = "NumberofReturns", ResourceType = typeof(ItemsResx))]	
 		[ViewField(Name = Fields.NumberofReturns, Id = Index.NumberofReturns, FieldType = EntityFieldType.Decimal, Size = 4)]
 		public decimal NumberofReturns {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalAmountSold 
        /// </summary>
        [Display(Name = "TotalAmountSold", ResourceType = typeof(ItemsResx))]	
        [ViewField(Name = Fields.TotalAmountSold, Id = Index.TotalAmountSold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalAmountSold {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalAmountReturned 
        /// </summary>
        [Display(Name = "TotalAmountReturned", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.TotalAmountReturned, Id = Index.TotalAmountReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalAmountReturned {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalCostofGoodsSold 
        /// </summary>
        [Display(Name = "TotalCostofGoodsSold", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.TotalCostofGoodsSold, Id = Index.TotalCostofGoodsSold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalCostofGoodsSold {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalGrossMargin 
        /// </summary>
        [Display(Name = "TotalGrossMargin", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.TotalGrossMargin, Id = Index.TotalGrossMargin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalGrossMargin {get; set;}
		 
  		/// <summary>
        /// Gets or sets QuantitySold 
        /// </summary>
        [Display(Name = "QuantitySold", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.QuantitySold, Id = Index.QuantitySold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
 		public decimal QuantitySold {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofSales 
        /// </summary>
        [Display(Name = "YTDNumberofSales", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.YtdNumberofSales, Id = Index.YtdNumberofSales, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofSales {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDNumberofReturns 
        /// </summary>
        [Display(Name = "YTDNumberofReturns", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.YtdNumberofReturns, Id = Index.YtdNumberofReturns, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal YtdNumberofReturns {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalAmountSold 
        /// </summary>
        [Display(Name = "YTDTotalAmountSold", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.YtdTotalAmountSold, Id = Index.YtdTotalAmountSold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalAmountSold {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalAmountReturned 
        /// </summary>
        [Display(Name = "YTDTotalAmountReturned", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.YtdTotalAmountReturned, Id = Index.YtdTotalAmountReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalAmountReturned {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalCostofGoodsSold 
        /// </summary>
        [Display(Name = "YTDTotalCostofGoodsSold", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.YtdTotalCostofGoodsSold, Id = Index.YtdTotalCostofGoodsSold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalCostofGoodsSold {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDTotalGrossMargin 
        /// </summary>
        [Display(Name = "YTDTotalGrossMargin", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.YtdTotalGrossMargin, Id = Index.YtdTotalGrossMargin, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal YtdTotalGrossMargin {get; set;}
		 
  		/// <summary>
        /// Gets or sets YTDQuantitySold 
        /// </summary>
        [Display(Name = "YTDQuantitySold", ResourceType = typeof(ItemsResx))]
 		[ViewField(Name = Fields.YtdQuantitySold, Id = Index.YtdQuantitySold, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
 		public decimal YtdQuantitySold {get; set;}
		
		/// <summary>
        /// Gets or sets YTDDateofLastSale 
        /// </summary>
		// [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]	
        [Display(Name = "YTDDateofLastSale", ResourceType = typeof(ItemsResx))]
		 [ViewField(Name = Fields.YtdDateofLastSale, Id = Index.YtdDateofLastSale, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime? YtdDateofLastSale {get; set;}
	 
  		/// <summary>
        /// Gets or sets EnableYTDCalculations 
        /// </summary>
        [Display(Name = "EnableYTDCalculations", ResourceType = typeof(ItemsResx))]
         [ViewField(Name = Fields.EnableYtdCalculations, Id = Index.EnableYtdCalculations, FieldType = EntityFieldType.Int, Size = 2)]
         public EnableYtdCalculations EnableYtdCalculations { get; set; }
		    }
}
