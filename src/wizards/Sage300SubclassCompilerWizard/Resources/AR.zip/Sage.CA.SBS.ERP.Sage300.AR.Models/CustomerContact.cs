// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Status = Sage.CA.SBS.ERP.Sage300.AR.Models.Enums.Status;

#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for Customer
    /// </summary>
    public partial class CustomerContact : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12)]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets ContactCode
        /// </summary>
        [Display(Name = "ContactCode", ResourceType = typeof(ARCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn(IsDrillDown = true)]
        [Key]
        [ViewField(Name = Fields.ContactCode, Id = Index.ContactCode, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ContactCode { get; set; }

        /// <summary>
        /// Gets or sets ContactName
        /// </summary>
        [Display(Name = "ContactName", ResourceType = typeof(ARCommonResx))]
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridColumn]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 255)]
        public string ContactName { get; set; }


        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [Display(Name = "Email", ResourceType = typeof(CustomersResx))]
        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 255)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets ContactStatus
        /// </summary>
        [Display(Name = "ContactStatus", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.ContactStatus, Id = Index.ContactStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public AR.Models.Enums.Status ContactStatus { get; set; }

        /// <summary>
        /// Gets or sets ConsentsToEmail
        /// </summary>
        [Display(Name = "ConsentsToEmail", ResourceType = typeof(ARCommonResx))]
        [GridColumn]
        [ViewField(Name = Fields.ConsentsToEmail, Id = Index.ConsentsToEmail, FieldType = EntityFieldType.Int, Size = 2)]
        public int ConsentsToEmail { get; set; }

        /// <summary>
        /// Gets or sets EmailSeparator
        /// </summary>
        [Display(Name = "EmailSeparator", ResourceType = typeof(CustomersResx))]
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EmailSeparator, Id = Index.EmailSeparator, FieldType = EntityFieldType.Char, Size = 1)]
        public string EmailSeparator { get; set; }


        #region Properties for finder
        #endregion Properties for finder
    }

}
