/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    public partial class InvoicePaymentSchedules : ModelBase
    {
        /// <summary>
        /// Gets or sets the value of LineNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(InvoiceResx))]
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BatchNumber", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "EntryNumber", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets DueDate 
        /// </summary>
        //[ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DueDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DueDate, Id = Index.DueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DueDate { get; set; }

        /// <summary>
        /// Gets or sets AmountDue 
        /// </summary>
        [Display(Name = "AmountDue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.AmountDue, Id = Index.AmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AmountDue { get; set; }

        /// <summary>
        /// Gets or sets DiscountDate 
        /// </summary>
        //[ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DiscountDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountDate, Id = Index.DiscountDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DiscountDate { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount 
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncAmountDue 
        /// </summary>
        [Display(Name = "AmountDue", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncAmountDue, Id = Index.FuncAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAmountDue { get; set; }

        /// <summary>
        /// Gets or sets FuncDiscountAmount 
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FuncDiscountAmount, Id = Index.FuncDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDiscountAmount { get; set; }
    }
}
