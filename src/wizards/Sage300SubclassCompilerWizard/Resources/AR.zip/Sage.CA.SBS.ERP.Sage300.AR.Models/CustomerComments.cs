// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Contains list of properties for CustomerComments
    /// </summary>
    public partial class CustomerComments : ModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CustomerNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DateEntered 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateEntered", ResourceType = typeof(ARCommonResx))]
        [Key]
        [ViewField(Name = Fields.DateEntered, Id = Index.DateEntered, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateEntered { get; set; }

        /// <summary>
        /// Gets or sets CommentNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "CommentNumber", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.CommentNumber, Id = Index.CommentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal CommentNumber { get; set; }

        /// <summary>
        /// Gets or sets ExpirationDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpirationDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets FollowupDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FollowUpDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.FollowupDate, Id = Index.FollowupDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FollowupDate { get; set; }

        /// <summary>
        /// Gets or sets Comments 
        /// </summary>
        [StringLength(2500, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comments", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 2500)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets ReverseCount 
        /// </summary>
        [Display(Name = "ReverseCount", ResourceType = typeof(CustomersResx))]
        [ViewField(Name = Fields.ReverseCount, Id = Index.ReverseCount, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal ReverseCount { get; set; }

        /// <summary>
        /// Gets or sets Comments1of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments1Of10, Id = Index.Comments1Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments1Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments2of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments2Of10, Id = Index.Comments2Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments2Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments3of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments3Of10, Id = Index.Comments3Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments3Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments4of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments4Of10, Id = Index.Comments4Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments4Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments5of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments5Of10, Id = Index.Comments5Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments5Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments6of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments6Of10, Id = Index.Comments6Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments6Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments7of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments7Of10, Id = Index.Comments7Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments7Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments8of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments8Of10, Id = Index.Comments8Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments8Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments9of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments9Of10, Id = Index.Comments9Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments9Of10 { get; set; }

        /// <summary>
        /// Gets or sets Comments10of10 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Comments10Of10, Id = Index.Comments10Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments10Of10 { get; set; }

        /// <summary>
        /// Gets or sets CommentType 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CommentType, Id = Index.CommentType, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string CommentType { get; set; }

        /// <summary>
        /// Gets or sets UserID 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or Sets LineNumber Number
        /// </summary>
        [Display(Name = "LineNumber", ResourceType = typeof(ARCommonResx))]
        public long LineNumber { get; set; }
    }
}
