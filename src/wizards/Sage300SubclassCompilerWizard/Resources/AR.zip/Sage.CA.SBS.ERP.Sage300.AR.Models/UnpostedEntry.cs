// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for UnpostedEntry
    /// </summary>
    public partial class UnpostedEntry : ModelBase
    {
        /// <summary>
        /// Gets or sets SequenceNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SequenceNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SequenceNo, Id = Index.SequenceNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets TransType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransType, Id = Index.TransType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransType TransType { get; set; }

        /// <summary>
        /// Gets or sets BatchNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BatchNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchNo, Id = Index.BatchNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNo { get; set; }

        /// <summary>
        /// Gets or sets EntryNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntryNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EntryNo, Id = Index.EntryNo, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNo { get; set; }

        /// <summary>
        /// Gets or sets BatchStatus
        /// </summary>
        [Display(Name = "BatchStatus", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.BatchStatus, Id = Index.BatchStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CustomerInquiryBatchStatus BatchStatus { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2A")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets CustomerNo
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CustomerNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CustomerNo, Id = Index.CustomerNo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNo { get; set; }

        /// <summary>
        /// Gets or sets NationalAccount
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NationalAccount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.NationalAccount, Id = Index.NationalAccount, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string NationalAccount { get; set; }

        /// <summary>
        /// Gets or sets DocumentNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.DocumentNo, Id = Index.DocumentNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNo { get; set; }

        /// <summary>
        /// Gets or sets ApplyBy
        /// </summary>
        [Display(Name = "ApplyBy", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ApplyBy, Id = Index.ApplyBy, FieldType = EntityFieldType.Int, Size = 2)]
        public ApplyBy ApplyBy { get; set; }

        /// <summary>
        /// Gets or sets ApplyTo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApplyTo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ApplyTo, Id = Index.ApplyTo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ApplyTo { get; set; }

        /// <summary>
        /// Gets or sets OriginalDocNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalDocumentNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OriginalDocNo, Id = Index.OriginalDocNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OriginalDocNo { get; set; }

        /// <summary>
        /// Gets or sets OrderNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.OrderNo, Id = Index.OrderNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNo { get; set; }

        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PONumber, Id = Index.PONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PONumber { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumber", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ShipmentNo, Id = Index.ShipmentNo, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ShipmentNo { get; set; }

        /// <summary>
        /// Gets or sets CheckReceiptNo
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckReceiptNo", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CheckReceiptNo { get; set; }

        /// <summary>
        /// Gets or sets Payer
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayerPayee", ResourceType = typeof(CustomerInquiryResx))]
        [ViewField(Name = Fields.Payer, Id = Index.Payer, FieldType = EntityFieldType.Char, Size = 60)]
        public string Payer { get; set; }

        /// <summary>
        /// Gets or sets TransDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransDate, Id = Index.TransDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransDate { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Int, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets HasItem
        /// </summary>
        
        [ViewField(Name = Fields.HasItem, Id = Index.HasItem, FieldType = EntityFieldType.Int, Size = 2)]
        public HasItem HasItem { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Int, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets TransCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCurrency", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransCurrency, Id = Index.TransCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TransCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TransAmt
        /// </summary>
        [Display(Name = "TransactionAmt", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TransAmt, Id = Index.TransAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransAmt { get; set; }

        /// <summary>
        /// Gets or sets TransAmtHome
        /// </summary>
        
        [ViewField(Name = Fields.TransAmtHome, Id = Index.TransAmtHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransAmtHome { get; set; }

        /// <summary>
        /// Gets or sets TaxAmt
        /// </summary>
        [Display(Name = "TaxAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.TaxAmt, Id = Index.TaxAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmt { get; set; }

        /// <summary>
        /// Gets or sets TaxAmtHome
        /// </summary>
        
        [ViewField(Name = Fields.TaxAmtHome, Id = Index.TaxAmtHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmtHome { get; set; }

        /// <summary>
        /// Gets or sets PrepayAdvanceAmt
        /// </summary>
        [Display(Name = "AdvancePrepayAmount", ResourceType = typeof(CustomerInquiryResx))]
        [ViewField(Name = Fields.PrepayAdvanceAmt, Id = Index.PrepayAdvanceAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepayAdvanceAmt { get; set; }

        /// <summary>
        /// Gets or sets PrepayAdvanceAmtHome
        /// </summary>
        
        [ViewField(Name = Fields.PrepayAdvanceAmtHome, Id = Index.PrepayAdvanceAmtHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrepayAdvanceAmtHome { get; set; }

        /// <summary>
        /// Gets or sets RtgAmt
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.RtgAmt, Id = Index.RtgAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgAmt { get; set; }

        /// <summary>
        /// Gets or sets RtgAmtHome
        /// </summary>
        
        [ViewField(Name = Fields.RtgAmtHome, Id = Index.RtgAmtHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgAmtHome { get; set; }

        /// <summary>
        /// Gets or sets UnappliedAmt
        /// </summary>
        [Display(Name = "UnappliedAmount", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.UnappliedAmt, Id = Index.UnappliedAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnappliedAmt { get; set; }

        /// <summary>
        /// Gets or sets UnappliedAmtHome
        /// </summary>
        
        [ViewField(Name = Fields.UnappliedAmtHome, Id = Index.UnappliedAmtHome, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnappliedAmtHome { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommand
        /// </summary>
        
        [ViewField(Name = Fields.ProcessCommand, Id = Index.ProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public int ProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets GeneratedSequenceNo
        /// </summary>
        
        [ViewField(Name = Fields.GeneratedSequenceNo, Id = Index.GeneratedSequenceNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long GeneratedSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets ForCustomer
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        
        [ViewField(Name = Fields.ForCustomer, Id = Index.ForCustomer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ForCustomer { get; set; }

        /// <summary>
        /// Gets or sets CheckNationalAccounts
        /// </summary>
        
        [ViewField(Name = Fields.CheckNationalAccounts, Id = Index.CheckNationalAccounts, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckNationalAccounts CheckNationalAccounts { get; set; }

        /// <summary>
        /// Gets or sets Checkinvoices
        /// </summary>
        
        [ViewField(Name = Fields.Checkinvoices, Id = Index.Checkinvoices, FieldType = EntityFieldType.Int, Size = 2)]
        public Checkinvoices Checkinvoices { get; set; }

        /// <summary>
        /// Gets or sets CheckDebitNotes
        /// </summary>
        
        [ViewField(Name = Fields.CheckDebitNotes, Id = Index.CheckDebitNotes, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckDebitNotes CheckDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets CheckCreditNotes
        /// </summary>
        
        [ViewField(Name = Fields.CheckCreditNotes, Id = Index.CheckCreditNotes, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckCreditNotes CheckCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets CheckInterest
        /// </summary>
        
        [ViewField(Name = Fields.CheckInterest, Id = Index.CheckInterest, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckInterest CheckInterest { get; set; }

        /// <summary>
        /// Gets or sets CheckReceipts
        /// </summary>
        
        [ViewField(Name = Fields.CheckReceipts, Id = Index.CheckReceipts, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckReceipts CheckReceipts { get; set; }

        /// <summary>
        /// Gets or sets CheckPrepayments
        /// </summary>
        
        [ViewField(Name = Fields.CheckPrepayments, Id = Index.CheckPrepayments, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckPrepayments CheckPrepayments { get; set; }

        /// <summary>
        /// Gets or sets CheckUnappliedCash
        /// </summary>
        
        [ViewField(Name = Fields.CheckUnappliedCash, Id = Index.CheckUnappliedCash, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckUnappliedCash CheckUnappliedCash { get; set; }

        /// <summary>
        /// Gets or sets CheckApply
        /// </summary>
        
        [ViewField(Name = Fields.CheckApply, Id = Index.CheckApply, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckApply CheckApply { get; set; }

        /// <summary>
        /// Gets or sets CheckMiscReceipts
        /// </summary>
        
        [ViewField(Name = Fields.CheckMiscReceipts, Id = Index.CheckMiscReceipts, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckMiscReceipts CheckMiscReceipts { get; set; }

        /// <summary>
        /// Gets or sets CheckRefunds
        /// </summary>
        
        [ViewField(Name = Fields.CheckRefunds, Id = Index.CheckRefunds, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckRefunds CheckRefunds { get; set; }

        /// <summary>
        /// Gets or sets CheckAdjustments
        /// </summary>
        
        [ViewField(Name = Fields.CheckAdjustments, Id = Index.CheckAdjustments, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckAdjustments CheckAdjustments { get; set; }

        /// <summary>
        /// Gets or sets CheckWriteOffs
        /// </summary>
        
        [ViewField(Name = Fields.CheckWriteOffs, Id = Index.CheckWriteOffs, FieldType = EntityFieldType.Int, Size = 2)]
        public CheckWriteOffs CheckWriteOffs { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets Batch and Entry No Combination
        /// </summary>
        [Display(Name = "BatchEntryNo", ResourceType = typeof(ARCommonResx))]
        public string BatchEntryNo
        {
            get { return BatchNo + " - " + EntryNo; }
        }

        /// <summary>
        /// Gets TransType string value
        /// </summary>
        public string TransTypeString
        {
            get { return EnumUtility.GetStringValue(TransType); }
        }

        /// <summary>
        /// Gets BatchStatus string value
        /// </summary>
        public string BatchStatusString
        {
            get { return EnumUtility.GetStringValue(BatchStatus); }
        }

        /// <summary>
        /// Gets ApplyBy string value
        /// </summary>
        public string ApplyByString
        {
            get { return EnumUtility.GetStringValue(ApplyBy); }
        }

        /// <summary>
        /// Gets JobRelated string value
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets HasItem string value
        /// </summary>
        public string HasItemString
        {
            get { return EnumUtility.GetStringValue(HasItem); }
        }

        /// <summary>
        /// Gets HasRetainage string value
        /// </summary>
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets CheckNationalAccounts string value
        /// </summary>
        public bool CheckNationalAccountsBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets Checkinvoices Bool value
        /// </summary>
        public bool CheckinvoicesBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckDebitNotes Bool value
        /// </summary>
        public bool CheckDebitNotesBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckCreditNotes Bool value
        /// </summary>
        public bool CheckCreditNotesBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckInterest Bool value
        /// </summary>
        public bool CheckInterestBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckReceipts Bool value
        /// </summary>
        public bool CheckReceiptsBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckPrepayments Bool value
        /// </summary>
        public bool CheckPrepaymentsBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckUnappliedCash Bool value
        /// </summary>
        public bool CheckUnappliedCashBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckApply Bool value
        /// </summary>
        public bool CheckApplyBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckMiscReceipts Bool value
        /// </summary>
        public bool CheckMiscReceiptsBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckRefunds Bool value
        /// </summary>
        public bool CheckRefundsBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckAdjustments Bool value
        /// </summary>
        public bool CheckAdjustmentsBool
        {
            get;
            set;
        }

        /// <summary>
        /// Gets CheckWriteOffs Bool value
        /// </summary>
        public bool CheckWriteOffsBool
        {
            get;
            set;
        }


        /// <summary>
        /// Gets or Sets Order Number Exist
        /// </summary>
        public bool HasOrderNoExist { get; set; }

        /// <summary>
        /// Gets or Sets Shipment Number Exist
        /// </summary>
        public bool HasShipmentNoExist { get; set; }

        /// <summary>
        /// Gets or Sets Bank Currency Decimal
        /// </summary>
        public int BankCurrencyDecimal { get; set; }

        #endregion
    }
}
