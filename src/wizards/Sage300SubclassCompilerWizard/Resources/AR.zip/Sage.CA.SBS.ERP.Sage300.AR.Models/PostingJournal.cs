/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Posting Journal Model 
    /// </summary>
    public partial class PostingJournal : ModelBase
    {

        /// <summary>
        /// Gets or sets BatchType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.BatchType, Id = Index.BatchType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string BatchType { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNo 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.PostingSequenceNo, Id = Index.PostingSequenceNo, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNo { get; set; }

        /// <summary>
        /// Gets or sets SystemDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SystemDate, Id = Index.SystemDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SystemDate { get; set; }

        /// <summary>
        /// Gets or sets DatePostedinAOrR 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DatePostedinAOrR, Id = Index.DatePostedinAOrR, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePostedinAOrR { get; set; }

        /// <summary>
        /// Gets or sets Printed? 
        /// </summary>

        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed Printed { get; set; }

        /// <summary>
        /// Gets or sets PostedtoGOrL? 
        /// </summary>

        [ViewField(Name = Fields.PostedtoGOrL, Id = Index.PostedtoGOrL, FieldType = EntityFieldType.Int, Size = 2)]
        public Printed PostedtoGOrL { get; set; }

        /// <summary>
        /// Gets or sets DatePostedtoGOrL 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DatePostedtoGOrL, Id = Index.DatePostedtoGOrL, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DatePostedtoGOrL { get; set; }

        /// <summary>
        /// Gets or sets ConsolidatedforGOrL? 
        /// </summary>

        [ViewField(Name = Fields.ConsolidatedforGOrL, Id = Index.ConsolidatedforGOrL, FieldType = EntityFieldType.Int, Size = 2)]
        public int ConsolidatedforGOrL { get; set; }

        /// <summary>
        /// Gets or sets ProgramVersion 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ProgramVersion, Id = Index.ProgramVersion, FieldType = EntityFieldType.Char, Size = 3)]
        public string ProgramVersion { get; set; }



        /// <summary>
        /// To get the string of Printed property
        /// </summary>
        public string PrintedString
        {
            get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// To get the string of PostedtoGOrL property
        /// </summary>
        public string PostedtoGOrLString
        {
            get { return EnumUtility.GetStringValue(PostedtoGOrL); }
        }
    }
}
