// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for OpenDocumentDetail
    /// </summary>
    public partial class OpenDocumentDetail : SqlModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 1)]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 2)]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 3)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Item)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Summary)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Item_JobRelated)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Item_Retainage)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Summary_JobRelated)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Summary_Retainage)]
        [GridInfo(1, typeof(ARCommonResx), "LineNumber", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage)]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 4)]
        [GridInfo(2, typeof(ARCommonResx), "Contract", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(2, typeof(ARCommonResx), "Contract", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(2, typeof(ARCommonResx), "Contract", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150")]
        [GridInfo(2, typeof(ARCommonResx), "Contract", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 5)]
        [GridInfo(3, typeof(CustomerInquiryResx), "Project", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(3, typeof(CustomerInquiryResx), "Project", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(3, typeof(CustomerInquiryResx), "Project", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150")]
        [GridInfo(3, typeof(CustomerInquiryResx), "Project", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 6)]
        [GridInfo(4, typeof(ARCommonResx), "Category", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(4, typeof(ARCommonResx), "Category", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(4, typeof(ARCommonResx), "Category", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150")]
        [GridInfo(4, typeof(ARCommonResx), "Category", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets ProjectCategoryResource
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 7)]
        [GridInfo(6, typeof(ARCommonResx), "Resource", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(6, typeof(ARCommonResx), "Resource", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(6, typeof(ARCommonResx), "Resource", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150")]
        [GridInfo(6, typeof(ARCommonResx), "Resource", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        [ViewField(Name = Fields.ProjectCategoryResource, Id = Index.ProjectCategoryResource, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-16N")]
        public string ProjectCategoryResource { get; set; }

        /// <summary>
        /// Gets or sets TransactionNumber
        /// </summary>
        [InquiryField(Id = 8)]
        [ViewField(Name = Fields.TransactionNumber, Id = Index.TransactionNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [InquiryField(Id = 9)]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 10)]
        [GridInfo(6, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Item)]
        [GridInfo(2, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Summary)]
        [GridInfo(12, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Item_JobRelated)]
        [GridInfo(6, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Item_Retainage)]
        [GridInfo(12, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage)]
        [GridInfo(8, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Summary_JobRelated)]
        [GridInfo(2, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Summary_Retainage)]
        [GridInfo(8, typeof(ARCommonResx), "DistributionCode", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage)]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GLAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 11)]
        [GridInfo(16, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Item, Style = "w150")]
        [GridInfo(11, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Summary, Style = "w150")]
        [GridInfo(22, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(21, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150")]
        [GridInfo(27, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(17, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150")]
        [GridInfo(16, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150")]
        [GridInfo(22, typeof(ARCommonResx), "GLAccount", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }
        
        /// <summary>
        /// Gets or sets CustCurrencyInvoiceAmount
        /// </summary>
        [InquiryField(Id = 12)]
        [GridInfo(9, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(4, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary, Style = "w150 numeric")]
        [GridInfo(15, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(9, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(15, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(10, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150 numeric")]
        [GridInfo(4, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(10, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.CustomerCurrencyInvoiceAmount, Id = Index.CustomerCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrencyAmountDue
        /// </summary>
        [InquiryField(Id = 13)]
        [GridInfo(13, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(8, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary, Style = "w150 numeric")]
        [GridInfo(19, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(13, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(19, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(14, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150 numeric")]
        [GridInfo(8, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(14, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.CustomerCurrencyAmountDue, Id = Index.CustomerCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyInvoiceAmount
        /// </summary>
        [InquiryField(Id = 14)]
        [GridInfo(10, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(5, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary, Style = "w150 numeric")]
        [GridInfo(16, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(10, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(16, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(11, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150 numeric")]
        [GridInfo(5, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(11, typeof(ARCommonResx), "DetailAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.FunctionalCurrencyInvoiceAmount, Id = Index.FunctionalCurrencyInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrencyAmountDue
        /// </summary>
        [InquiryField(Id = 15)]
        [GridInfo(14, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(9, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary, Style = "w150 numeric")]
        [GridInfo(20, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(14, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(20, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(15, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150 numeric")]
        [GridInfo(9, typeof(ARCommonResx), "TotalAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(15, typeof(ARCommonResx), "CurrentBalance", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.FunctionalCurrencyAmountDue, Id = Index.FunctionalCurrencyAmountDue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyAmountDue { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 16)]
        [GridInfo(2, typeof(ARCommonResx), "ItemNo", identity: (int)InquiryInvoiceType.Item)]
        [GridInfo(8, typeof(ARCommonResx), "ItemNo", identity: (int)InquiryInvoiceType.Item_JobRelated)]
        [GridInfo(2, typeof(ARCommonResx), "ItemNo", identity: (int)InquiryInvoiceType.Item_Retainage)]
        [GridInfo(8, typeof(ARCommonResx), "ItemNo", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage)]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 17)]
        [GridInfo(4, typeof(ARCommonResx), "UOM", identity: (int)InquiryInvoiceType.Item)]
        [GridInfo(10, typeof(ARCommonResx), "UOM", identity: (int)InquiryInvoiceType.Item_JobRelated)]
        [GridInfo(4, typeof(ARCommonResx), "UOM", identity: (int)InquiryInvoiceType.Item_Retainage)]
        [GridInfo(10, typeof(ARCommonResx), "UOM", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage)]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [InquiryField(Id = 18)]
        [GridInfo(5, typeof(ARCommonResx), "Quantity", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryQuantityDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(11, typeof(ARCommonResx), "Quantity", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryQuantityDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(5, typeof(ARCommonResx), "Quantity", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryQuantityDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(11, typeof(ARCommonResx), "Quantity", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryQuantityDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 5)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets Cost
        /// </summary>
        [InquiryField(Id = 19)]
        [GridInfo(8, typeof(ARCommonResx), "UnitPrice", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(14, typeof(ARCommonResx), "UnitPrice", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(8, typeof(ARCommonResx), "UnitPrice", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(14, typeof(ARCommonResx), "UnitPrice", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.Cost, Id = Index.Cost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal Cost { get; set; }

        /// <summary>
        /// Gets or sets BillingDate
        /// </summary>
        [InquiryField(Id = 20)]
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(7, typeof(ARCommonResx), "Date", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(7, typeof(ARCommonResx), "Date", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(7, typeof(ARCommonResx), "Date", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150")]
        [GridInfo(7, typeof(ARCommonResx), "Date", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        [ViewField(Name = Fields.BillingDate, Id = Index.BillingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BillingDate { get; set; }

        /// <summary>
        /// Gets or sets Discountable
        /// </summary>
        [InquiryField(Id = 21)]
        [ViewField(Name = Fields.Discountable, Id = Index.Discountable, FieldType = EntityFieldType.Int, Size = 2)]
        public Discountable Discountable { get; set; }

        /// <summary>
        /// Gets or sets DateRetainageDue
        /// </summary>
        [InquiryField(Id = 22)]
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [GridInfo(19, typeof(ARCommonResx), "RetainageDueDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150")]
        [GridInfo(25, typeof(ARCommonResx), "RetainageDueDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(14, typeof(ARCommonResx), "RetainageDueDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150")]
        [GridInfo(20, typeof(ARCommonResx), "RetainageDueDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        [ViewField(Name = Fields.DateRetainageDue, Id = Index.DateRetainageDue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateRetainageDue { get; set; }

       
        /// <summary>
        /// Gets or sets FuncCurrOrigRtngAmt
        /// </summary>
        [InquiryField(Id = 23)]
        [GridInfo(16, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(22, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(11, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(17, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.FunctionalCurrencyOrigRtngAmt, Id = Index.FunctionalCurrencyOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets FuncCurrRetainageAmount
        /// </summary>
        [InquiryField(Id = 24)]
        [GridInfo(18, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(24, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(13, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(19, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.FunctionalCurrencyRetainageAmount, Id = Index.FunctionalCurrencyRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalCurrencyRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets CustCurrOrigRtngAmt
        /// </summary>
        [InquiryField(Id = 25)]
        [GridInfo(15, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(21, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(10, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(16, typeof(ARCommonResx), "OriginalRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.CustomerCurrencyOrigRtngAmt, Id = Index.CustomerCurrencyOrigRtngAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCurrencyOrigRtngAmt { get; set; }

        /// <summary>
        /// Gets or sets CustCurrRetainageAmount
        /// </summary>
        [InquiryField(Id = 26)]
        [GridInfo(17, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(23, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(12, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(18, typeof(ARCommonResx), "OutstandingRetainage", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        [ViewField(Name = Fields.CustomerCurrencyRetainageAmount, Id = Index.CustomerCurrencyRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerCurrencyRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
       [Display(Name = "OptionalFields", ResourceType = typeof(CommonResx))]
       [InquiryField(Id = 27)]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets RetainageDistributionAmount
        /// </summary>
        [InquiryField(Id = 28)]
        [ViewField(Name = Fields.RetainageDistributionAmount, Id = Index.RetainageDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageCOGSAmount
        /// </summary>
        [InquiryField(Id = 29)]
        [ViewField(Name = Fields.RetainageCOGSAmount, Id = Index.RetainageCOGSAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageCOGSAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageAlternateBaseAmount
        /// </summary>
        [InquiryField(Id = 30)]
        [ViewField(Name = Fields.RetainageAlternateBaseAmount, Id = Index.RetainageAlternateBaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAlternateBaseAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [InquiryField(Id = 31)]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [InquiryField(Id = 32)]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [InquiryField(Id = 33)]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [InquiryField(Id = 34)]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [InquiryField(Id = 35)]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [InquiryField(Id = 36)]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2
        /// </summary>
        [InquiryField(Id = 37)]
        [ViewField(Name = Fields.TaxIncluded2, Id = Index.TaxIncluded2, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3
        /// </summary>
        [InquiryField(Id = 38)]
        [ViewField(Name = Fields.TaxIncluded3, Id = Index.TaxIncluded3, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4
        /// </summary>
        [InquiryField(Id = 39)]
        [ViewField(Name = Fields.TaxIncluded4, Id = Index.TaxIncluded4, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5
        /// </summary>
        [InquiryField(Id = 40)]
        [ViewField(Name = Fields.TaxIncluded5, Id = Index.TaxIncluded5, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden TaxIncluded5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1
        /// </summary>
        [InquiryField(Id = 41)]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2
        /// </summary>
        [InquiryField(Id = 42)]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3
        /// </summary>
        [InquiryField(Id = 43)]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4
        /// </summary>
        [InquiryField(Id = 44)]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5
        /// </summary>
        [InquiryField(Id = 45)]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

       /// <summary>
        /// Gets or sets CustRetainageTaxBase1
        /// </summary>
        [InquiryField(Id = 46)]
        [ViewField(Name = Fields.CustomerRetainageTaxBase1, Id = Index.CustomerRetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxBase2
        /// </summary>
        [InquiryField(Id = 47)]
        [ViewField(Name = Fields.CustomerRetainageTaxBase2, Id = Index.CustomerRetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxBase3
        /// </summary>
        [InquiryField(Id = 48)]
        [ViewField(Name = Fields.CustomerRetainageTaxBase3, Id = Index.CustomerRetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxBase4
        /// </summary>
        [InquiryField(Id = 49)]
        [ViewField(Name = Fields.CustomerRetainageTaxBase4, Id = Index.CustomerRetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxBase5
        /// </summary>
        [InquiryField(Id = 50)]
        [ViewField(Name = Fields.CustomerRetainageTaxBase5, Id = Index.CustomerRetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxAmount1
        /// </summary>
        [InquiryField(Id = 51)]
        [ViewField(Name = Fields.CustomerRetainageTaxAmount1, Id = Index.CustomerRetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxAmount2
        /// </summary>
        [InquiryField(Id = 52)] 
        [ViewField(Name = Fields.CustomerRetainageTaxAmount2, Id = Index.CustomerRetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxAmount3
        /// </summary>
        [InquiryField(Id = 53)] 
        [ViewField(Name = Fields.CustomerRetainageTaxAmount3, Id = Index.CustomerRetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxAmount4
        /// </summary>
        [InquiryField(Id = 54)] 
        [ViewField(Name = Fields.CustomerRetainageTaxAmount4, Id = Index.CustomerRetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustRetainageTaxAmount5
        /// </summary>
        [InquiryField(Id = 55)] 
        [ViewField(Name = Fields.CustomerRetainageTaxAmount5, Id = Index.CustomerRetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerRetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageTaxAmount1
        /// </summary>
        [InquiryField(Id = 56)] 
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount1, Id = Index.FunctionalRetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageTaxAmount2
        /// </summary>
        [InquiryField(Id = 57)] 
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount2, Id = Index.FunctionalRetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageTaxAmount3
        /// </summary>
        [InquiryField(Id = 58)] 
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount3, Id = Index.FunctionalRetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageTaxAmount4
        /// </summary>
        [InquiryField(Id = 59)] 
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount4, Id = Index.FunctionalRetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncRetainageTaxAmount5
        /// </summary>
        [InquiryField(Id = 60)] 
        [ViewField(Name = Fields.FunctionalRetainageTaxAmount5, Id = Index.FunctionalRetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets LastAppliedPaymentSeqNo
        /// </summary>
        [InquiryField(Id = 61)] 
        [ViewField(Name = Fields.LastAppliedPaymentSeqNo, Id = Index.LastAppliedPaymentSeqNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long LastAppliedPaymentSeqNo { get; set; }

        /// <summary>
        /// Gets or sets the item description.
        /// </summary>
        /// <value>
        /// The item description.
        /// </value>
        [InquiryField(Id = 62)]
        [GridInfo(3, typeof(ARCommonResx), "ItemDescription", identity: (int)InquiryInvoiceType.Item, Style = "w150")]
        [GridInfo(9, typeof(ARCommonResx), "ItemDescription", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(3, typeof(ARCommonResx), "ItemDescription", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150")]
        [GridInfo(9, typeof(ARCommonResx), "ItemDescription", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets the account description.
        /// </summary>
        /// <value>
        /// The account description.
        /// </value>
        [InquiryField(Id = 63)]
        [GridInfo(17, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Item, Style = "w150")]
        [GridInfo(12, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Summary, Style = "w150")]
        [GridInfo(23, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150")]
        [GridInfo(22, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150")]
        [GridInfo(28, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150")]
        [GridInfo(18, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150")]
        [GridInfo(17, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150")]
        [GridInfo(23, typeof(CustomerInquiryResx), "AccountDescription", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150")]
        public string AccountDescription { get; set; }

        /// <summary>
        /// Gets or sets the functional currency applied amount. - DIFFHC
        /// </summary>
        /// <value>
        /// The functional currency applied amount.
        /// </value>
        [GridInfo(12, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(7, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary, Style = "w150 numeric")]
        [GridInfo(18, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(12, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(18, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(13, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150 numeric")]
        [GridInfo(7, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(13, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        public decimal FunctionalCurrencyAppliedAmount
        {
            get { return FunctionalCurrencyAmountDue - FunctionalCurrencyInvoiceAmount; }
        }

        /// <summary>
        /// Gets or sets the customer currency applied amount. - DIFFTC
        /// </summary>
        /// <value>
        /// The customer currency applied amount.
        /// </value>
        [GridInfo(11, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item, Style = "w150 numeric")]
        [GridInfo(6, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary, Style = "w150 numeric")]
        [GridInfo(17, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated, Style = "w150 numeric")]
        [GridInfo(11, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_Retainage, Style = "w150 numeric")]
        [GridInfo(17, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage, Style = "w150 numeric")]
        [GridInfo(12, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated, Style = "w150 numeric")]
        [GridInfo(6, typeof(ARCommonResx), "AdjustmentAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_Retainage, Style = "w150 numeric")]
        [GridInfo(12, typeof(ARCommonResx), "AppliedAmount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage, Style = "w150 numeric")]
        public decimal CustomerCurrencyAppliedAmount
        {
            get { return CustomerCurrencyAmountDue - CustomerCurrencyInvoiceAmount; }
        }

        /// <summary>
        /// Gets the discountable string.
        /// </summary>
        /// <value>
        /// The discountable string.
        /// </value>
        [GridInfo(7, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Item)]
        [GridInfo(3, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Summary)]
        [GridInfo(13, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Item_JobRelated)]
        [GridInfo(7, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Item_Retainage)]
        [GridInfo(13, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage)]
        [GridInfo(9, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Summary_JobRelated)]
        [GridInfo(3, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Summary_Retainage)]
        [GridInfo(9, typeof(ARCommonResx), "Discountable", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage)]
        public string DiscountableString
        {
            get { return EnumUtility.GetStringValue(Discountable); }
        }

        /// <summary>
        /// To get the string of Cost Class property for finder purpose
        /// </summary>
        /// <value>The Cost Class string</value>
        [IgnoreExportImport]
        [GridInfo(5, typeof(ARCommonResx), "CostClass", identity: (int)InquiryInvoiceType.Item_JobRelated)]
        [GridInfo(5, typeof(ARCommonResx), "CostClass", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage)]
        [GridInfo(5, typeof(ARCommonResx), "CostClass", identity: (int)InquiryInvoiceType.Summary_JobRelated)]
        [GridInfo(5, typeof(ARCommonResx), "CostClass", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage)]
        public string CostClassString
        {
            get
            {
                return CostClass == CostClass.None ? string.Empty : EnumUtility.GetStringValue(CostClass);
            }
        }

        /// <summary>
        /// Gets OptionalFields string value
        /// </summary>
        [IgnoreExportImport]
        [GridInfo(15, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Item)]
        [GridInfo(10, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Summary)]
        [GridInfo(21, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Item_JobRelated)]
        [GridInfo(20, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Item_Retainage)]
        [GridInfo(26, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Item_JobRelated_Retainage)]
        [GridInfo(16, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Summary_JobRelated)]
        [GridInfo(15, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Summary_Retainage)]
        [GridInfo(21, typeof(CommonResx), "OptionalFields", identity: (int)InquiryInvoiceType.Summary_JobRelated_Retainage)]
        public string OptionalFieldsString
        {
            get { return OptionalFields > 0 ? CommonResx.Yes : CommonResx.No; }
        }
    }
}
