// Copyright (c) 2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Partial class for DocumentPayment
    /// </summary>
    public partial class DocumentPayment : SqlModelBase
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 1)]
        [GridInfo(1, typeof(ARCommonResx), "CustomerNumber", identity: (int)InquiryType.Adjustments, Style = "w150")]
        [ViewField(Name = Fields.CustomerNumber, Id = Index.CustomerNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string CustomerNumber { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNo", ResourceType = typeof(CustomerInquiryResx))]
        [InquiryField(Id = 2)]
        [GridInfo(4, typeof(ARCommonResx), "DocumentNumber", identity: (int)InquiryType.Adjustments, Style = "w150")]
        [GridInfo(5, typeof(ARCommonResx), "DocumentNo", identity: (int)InquiryType.Refunds, Style = "w150")]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets PaymentNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 3)]
        [GridInfo(5, typeof(ARCommonResx), "PaymentNumber", identity: (int)InquiryType.Receipts)]
        [GridInfo(6, typeof(ARCommonResx), "PaymentNumber", identity: (int)InquiryType.Refunds)]
        [GridInfo(5, typeof(ARCommonResx), "PaymentNumber", identity: (int)InquiryType.Adjustments)]
        [ViewField(Name = Fields.PaymentNumber, Id = Index.PaymentNumber, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal PaymentNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckReceiptNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 4)]
        [GridInfo(10, typeof(ARCommonResx), "CheckReceiptNo", identity: (int)InquiryType.Documents, Style = "w150 align-right")]
        [ViewField(Name = Fields.CheckReceiptNo, Id = Index.CheckReceiptNo, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string CheckReceiptNo { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 5)]
        [GridInfo(1, typeof(ARCommonResx), "PostingDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryType.Documents)]
        [GridInfo(1, typeof(ARCommonResx), "PostingDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryType.Receipts)]
        [GridInfo(1, typeof(ARCommonResx), "PostingDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryType.Refunds)]
        [GridInfo(9, typeof(ARCommonResx), "PostingDate", templateSource: GridInfoTemplateLib.FormattedDate, identity: (int)InquiryType.Adjustments)]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? PostingDate { get; set; }

        /// <summary>
        /// Gets or sets DocumentType
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 6)]
        [ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentPaymentType DocumentType { get; set; }

        /// <summary>
        /// Document Type String
        /// </summary>
        public string DocumentTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(DocumentType);
            }
        }

        /// <summary>
        /// Gets or sets SequenceNo
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 7)]
        [ViewField(Name = Fields.SequenceNo, Id = Index.SequenceNo, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal SequenceNo { get; set; }

        /// <summary>
        /// Gets or sets DepositNumber
        /// </summary>
        [GridInfo(11, typeof(ARCommonResx), "DepositNumber", identity: (int)InquiryType.Documents, Style = "w120 align-right")]
        [InquiryField(Id = 8)]
        [ViewField(Name = Fields.DepositNumber, Id = Index.DepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal DepositNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber
        /// </summary>
        [InquiryField(Id = 9)]
        [GridInfo(12, typeof(ARCommonResx), "BatchNumber", identity: (int)InquiryType.Adjustments)]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets BatchDate
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 10)]
        [ViewField(Name = Fields.BatchDate, Id = Index.BatchDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BatchDate { get; set; }

        /// <summary>
        /// Gets or sets FuncReceiptAmount
        /// </summary>
        [Display(Name = "TransactionAmt", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 11)]
        [GridInfo(8, typeof(ARCommonResx), "TransactionAmt", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Documents, Style = "w150 numeric")]
        [GridInfo(9, typeof(ARCommonResx), "TransactionAmt", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Receipts, Style = "w150 numeric")]
        [GridInfo(9, typeof(ARCommonResx), "TransactionAmt", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Refunds, Style = "w150 numeric")]
        [GridInfo(8, typeof(ARCommonResx), "Amount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Adjustments, Style = "w150 numeric")]
        [ViewField(Name = Fields.FuncReceiptAmount, Id = Index.FuncReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets CustReceiptAmount
        /// </summary>
        [Display(Name = "TransactionAmt", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 12)]
        [GridInfo(6, typeof(ARCommonResx), "TransactionAmt", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Documents, Style = "w150 numeric")]
        [GridInfo(7, typeof(ARCommonResx), "TransactionAmt", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Receipts, Style = "w150 numeric")]
        [GridInfo(7, typeof(ARCommonResx), "TransactionAmt", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Refunds, Style = "w150 numeric")]
        [GridInfo(6, typeof(ARCommonResx), "Amount", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryCurrencyDecimal", identity: (int)InquiryType.Adjustments, Style = "w150 numeric")]
        [ViewField(Name = Fields.CustReceiptAmount, Id = Index.CustReceiptAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustReceiptAmount { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 13)]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 14)]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 15)]
        [GridInfo(7, typeof(ARCommonResx), "ExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryType.Documents, Style = "w150 numeric")]
        [GridInfo(8, typeof(ARCommonResx), "ExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryType.Receipts, Style = "w150 numeric")]
        [GridInfo(8, typeof(ARCommonResx), "ExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryType.Refunds, Style = "w150 numeric")]
        [GridInfo(7, typeof(ARCommonResx), "ExchangeRate", templateSource: GridInfoTemplateLib.FormattedDecimal, numericDecimalField: "InquiryRateDecimal", identity: (int)InquiryType.Adjustments, Style = "w150 numeric")]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden
        /// </summary>
        [InquiryField(Id = 16)]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets BankCode
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 17)]
        [GridInfo(9, typeof(ARCommonResx), "BankCode", identity: (int)InquiryType.Documents)]
        [GridInfo(10, typeof(ARCommonResx), "BankCode", identity: (int)InquiryType.Refunds)]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }
        
        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 18)]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentPaymentTransactionType TransactionType { get; set; }

        /// <summary>
        /// TransactionType Type String
        /// </summary>
        [GridInfo(4, typeof(ARCommonResx), "TransactionType", identity: (int)InquiryType.Documents, Style = "w150")]
        [GridInfo(4, typeof(ARCommonResx), "TransactionType", identity: (int)InquiryType.Receipts, Style = "w150")]
        [GridInfo(4, typeof(ARCommonResx), "TransactionType", identity: (int)InquiryType.Refunds, Style = "w150")]
        [GridInfo(2, typeof(ARCommonResx), "AdjustmentType", identity: (int)InquiryType.Adjustments, Style = "w150")]
        public string TransactionTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(TransactionType);
            }
        }

        /// <summary>
        /// Gets or sets ReferenceDocumentNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RefDocumentNumber", ResourceType = typeof(ARCommonResx))]
        [InquiryField(Id = 19)]
        [GridInfo(5, typeof(ARCommonResx), "RefDocumentNumber", identity: (int)InquiryType.Documents, Style = "w150")]
        [GridInfo(6, typeof(ARCommonResx), "RefDocumentNumber", identity: (int)InquiryType.Receipts, Style = "w150")]
        [GridInfo(3, typeof(ARCommonResx), "AdjustmentNumber", templateSource: GridInfoTemplateLib.PencilIconDrillDown, identity: (int)InquiryType.Adjustments, Style = "w150")]
        [ViewField(Name = Fields.ReferenceDocumentNo, Id = Index.ReferenceDocumentNo, FieldType = EntityFieldType.Char, Size = 22)]
        public string ReferenceDocumentNo { get; set; }

        /// <summary>
        /// Gets or sets DeleteInvoiceSwitch
        /// </summary>
        [InquiryField(Id = 20)]
        [ViewField(Name = Fields.DeleteInvoiceSwitch, Id = Index.DeleteInvoiceSwitch, FieldType = EntityFieldType.Int, Size = 2)]
        public int DeleteInvoiceSwitch { get; set; }

        /// <summary>
        /// Gets or sets LastStatementDate
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 21)]
        [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastStatementDate { get; set; }

        /// <summary>
        /// Gets or sets PrepayApplytoDocNo
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 22)]
        [ViewField(Name = Fields.PrepayApplytoDocNo, Id = Index.PrepayApplytoDocNo, FieldType = EntityFieldType.Char, Size = 22)]
        public string PrepayApplytoDocNo { get; set; }

        /// <summary>
        /// Gets or sets RemittingCustomerNo
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 23)]
        [ViewField(Name = Fields.RemittingCustomerNo, Id = Index.RemittingCustomerNo, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string RemittingCustomerNo { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDate
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 24)]
        [ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber
        /// </summary>
        [InquiryField(Id = 25)]
        [GridInfo(13, typeof(ARCommonResx), "EntryNumber", identity: (int)InquiryType.Adjustments)]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(ARCommonResx))]
        [GridInfo(2, typeof(ARCommonResx), "Year", identity: (int)InquiryType.Documents)]
        [GridInfo(2, typeof(ARCommonResx), "Year", identity: (int)InquiryType.Receipts)]
        [GridInfo(2, typeof(ARCommonResx), "Year", identity: (int)InquiryType.Refunds)]
        [GridInfo(10, typeof(ARCommonResx), "Year", identity: (int)InquiryType.Adjustments)]
        [InquiryField(Id = 26)]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(ARCommonResx))]
        [GridInfo(3, typeof(ARCommonResx), "Period", identity: (int)InquiryType.Documents)]
        [GridInfo(3, typeof(ARCommonResx), "Period", identity: (int)InquiryType.Receipts)]
        [GridInfo(3, typeof(ARCommonResx), "Period", identity: (int)InquiryType.Refunds)]
        [GridInfo(11, typeof(ARCommonResx), "Period", identity: (int)InquiryType.Adjustments)]
        [InquiryField(Id = 27)]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Char, Size = 2, Mask = "%02D")]
        public string FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [InquiryField(Id = 28)]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperator
        /// </summary>
        [InquiryField(Id = 29)]
        [ViewField(Name = Fields.RateOperator, Id = Index.RateOperator, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateOperator { get; set; }

        /// <summary>
        /// Gets or sets StatementRunNo
        /// </summary>
        [InquiryField(Id = 30)]
        [ViewField(Name = Fields.StatementRunNo, Id = Index.StatementRunNo, FieldType = EntityFieldType.Long, Size = 4)]
        public long StatementRunNo { get; set; }

        /// <summary>
        /// Gets or sets PaymentCUID
        /// </summary>
        [InquiryField(Id = 31)]
        [ViewField(Name = Fields.PaymentCUID, Id = Index.PaymentCUID, FieldType = EntityFieldType.Long, Size = 4)]
        public long PaymentCUID { get; set; }

        /// <summary>
        /// Gets or sets DepositSerialNumber
        /// </summary>
        [InquiryField(Id = 32)]
        [ViewField(Name = Fields.DepositSerialNumber, Id = Index.DepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long DepositSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DepositLineNumber
        /// </summary>
        [InquiryField(Id = 33)]
        [ViewField(Name = Fields.DepositLineNumber, Id = Index.DepositLineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DepositLineNumber { get; set; }

        #region UI

        /// <summary>
        /// Payer Customer Number
        /// </summary>
        public string PayerCustomerNumber { get; set; }

        /// <summary>
        /// Payer Customer Name
        /// </summary>
        public string PayerCustomerName { get; set; }
        
        /// <summary>
        /// Batch Or Entry Number
        /// </summary>
        public string BatchOrEntryNumber 
        {
            get { return   Convert.ToString(BatchNumber) + " - "  +  Convert.ToString(EntryNumber);}
        }

        #endregion
    }
}
