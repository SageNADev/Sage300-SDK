/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using Sage.CA.SBS.ERP.Sage300.AR.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.AR.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
namespace Sage.CA.SBS.ERP.Sage300.AR.Models
{
    /// <summary>
    /// Account Set Class
    /// </summary>
    public partial class AccountSet : ModelBase
    {
        /// <summary>
        /// Constructor for Account Set
        /// </summary>
        public AccountSet()
        {
            Status = Status.Active;
        }

        /// <summary>
        /// Gets or sets AccountSet 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "AcctSetcode", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.AccountSetCode, Id = Index.AccountSetCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AccountSetCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AccountSetDesc", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(ARCommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets DateLastMaintained 
        /// </summary>
       [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets ReceivablesControlAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReControls", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.ReceivablesControlAccount, Id = Index.ReceivablesControlAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ReceivablesControlAccount { get; set; }

        /// <summary>
        /// Gets or sets PrepaymentLiabilityAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PreLiability", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.PrepaymentLiabilityAccount, Id = Index.PrepaymentLiabilityAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string PrepaymentLiabilityAccount { get; set; }

        /// <summary>
        /// Gets or sets DiscountsAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReDiscounts", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.DiscountsAccount, Id = Index.DiscountsAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DiscountsAccount { get; set; }

        /// <summary>
        /// Gets or sets WriteOffsAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WriteOffs", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.WriteOffsAccount, Id = Index.WriteOffsAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string WriteOffsAccount { get; set; }

        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.CurrencyCode, Id = Index.CurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeGainAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnrlzExchGain", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.UnrealizedExchangeGainAccount, Id = Index.UnrealizedExchangeGainAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedExchangeGainAccount { get; set; }

        /// <summary>
        /// Gets or sets UnrealizedExchangeLossAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnrlzExchLoss", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.UnrealizedExchangeLossAccount, Id = Index.UnrealizedExchangeLossAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string UnrealizedExchangeLossAccount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGainAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RlzExchGain", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.ExchangeGainAccount, Id = Index.ExchangeGainAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExchangeGainAccount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLossAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RlzEXchLoss", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.ExchangeLossAccount, Id = Index.ExchangeLossAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExchangeLossAccount { get; set; }

        /// <summary>
        /// Gets or sets RetainageAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Retainage", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.RetainageAccount, Id = Index.RetainageAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string RetainageAccount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRoundingAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExchRounding", ResourceType = typeof(AccountSetsResx))]
        [ViewField(Name = Fields.ExchangeRoundingAccount, Id = Index.ExchangeRoundingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExchangeRoundingAccount { get; set; }

        #region UI Property
        /// <summary>
        /// To get the string of Status property
        /// </summary>
        public string StatusString
        {
            get
            {
                return EnumUtility.GetStringValue(Status);
            }
        }
        #endregion
    }
}
