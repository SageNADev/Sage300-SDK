﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.AR.Models
    {
    /// <summary>
    /// Model which contains Customer Inquiry Header
    /// </summary>
    public class CustomerInquiryHeader
        {
        /// <summary>
        /// Get or Sets AR Options
        /// </summary>
        public Options AROptions { get; set; }

        /// <summary>
        /// Get/Set IsMultiCurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Get/Set IsNationalAccount
        /// </summary>
        public bool IsNationalAccount { get; set; }

        /// <summary>
        ///  Get/Set Functional Currency 
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets the functional currency decimal
        /// </summary>
        public string FunctionalCurrencyDecimal { get; set; }

        /// <summary>
        /// Get/Set UseRetainage
        /// </summary>
        public bool UseRetainage { get; set; }

        /// <summary>
        /// Get/Set IsFormatPhoneNo
        /// </summary>
        public bool IsFormatPhoneNo { get; set; }

        /// <summary>
        /// Gets or Sets FractionalDecimal
        /// </summary>
        public string FractionalDecimal { get; set; }

        /// <summary>
        /// Gets or Sets IsCalendarYear
        /// </summary>
        public bool IsCalendarYear { get; set; }

        /// <summary>
        /// Gets or sets the IsKeepStatistics 
        /// </summary>
        public bool IsKeepStatistics { get; set; }

        /// <summary>
        /// Gets or Sets IsFractionalQuantities.
        /// </summary>
        public bool IsFractionalQuantities { get; set; } 
        
        }
    }
