// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Class for E-mailMessage
	/// </summary>
	public partial class EmailMessage : ModelBase
	{
		   /// <summary>
        /// Constructor
        /// </summary>
        public EmailMessage()
        {
            Status = StatusEmailMessage.Active;
        }
        
        /// <summary>
		/// Gets or sets MessageType
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MessageType", ResourceType = typeof(EmailMessagesResx))]
		[ViewField(Name = Fields.MessageType, Id = Index.MessageType, FieldType = EntityFieldType.Int, Size = 2)]
		public MessageType MessageType {get; set;}

		/// <summary>
		/// Gets or sets MessageID
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "MessageID", ResourceType = typeof(EmailMessagesResx))]
		[ViewField(Name = Fields.MessageID, Id = Index.MessageID, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
		public string MessageID {get; set;}

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string Description {get; set;}

		/// <summary>
		/// Gets or sets Status
		/// </summary>
        [Display(Name = "Status", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public StatusEmailMessage Status { get; set; }

		/// <summary>
		/// Gets or sets DateInactive
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateInactive", ResourceType = typeof(EmailMessagesResx))]
		[ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateInactive {get; set;}

		/// <summary>
		/// Gets or sets DateLastMaintained
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
		[ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateLastMaintained {get; set;}

		/// <summary>
		/// Gets or sets EmailSubject
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmailSubject", ResourceType = typeof(EmailMessagesResx))]
		[ViewField(Name = Fields.EmailSubject, Id = Index.EmailSubject, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailSubject {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText1Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText1Of10, Id = Index.EmailBodyText1Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText1Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText2Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText2Of10, Id = Index.EmailBodyText2Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText2Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText3Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText3Of10, Id = Index.EmailBodyText3Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText3Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText4Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText4Of10, Id = Index.EmailBodyText4Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText4Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText5Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText5Of10, Id = Index.EmailBodyText5Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText5Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText6Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText6Of10, Id = Index.EmailBodyText6Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText6Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText7Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText7Of10, Id = Index.EmailBodyText7Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText7Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText8Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText8Of10, Id = Index.EmailBodyText8Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText8Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText9Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
		[ViewField(Name = Fields.EmailBodyText9Of10, Id = Index.EmailBodyText9Of10, FieldType = EntityFieldType.Char, Size = 250)]
		public string EmailBodyText9Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBodyText10Of10
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.EmailBodyText10Of10, Id = Index.EmailBodyText10Of10, FieldType = EntityFieldType.Char, Size = 250)]
        public string EmailBodyText10Of10 {get; set;}

		/// <summary>
		/// Gets or sets EmailBody
		/// </summary>
		[StringLength(2500, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmailBody", ResourceType = typeof(EmailMessagesResx))]
		[ViewField(Name = Fields.EmailBody, Id = Index.EmailBody, FieldType = EntityFieldType.Char, Size = 2500)]
		public string EmailBody {get; set;}

		#region UI Strings

		/// <summary>
		/// Gets MessageType string value
		/// </summary>
		public string MessageTypeString
		{
			get { return EnumUtility.GetStringValue(MessageType); }
		}

        /// <summary>
        /// Gets Status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

		#endregion
	}
}
