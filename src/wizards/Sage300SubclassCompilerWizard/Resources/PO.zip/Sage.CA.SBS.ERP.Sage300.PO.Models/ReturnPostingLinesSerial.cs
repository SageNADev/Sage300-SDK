// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Partial class for Return Posting Lines Serial
	/// </summary>
	public partial class ReturnPostingLinesSerial : ModelBase
	{
		/// <summary>
		/// Gets or sets Header Sequence
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal HeaderSequence { get; set; }

		/// <summary>
		/// Gets or sets Credit Debit Note SequenceKey
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal CreditDebitNoteSequenceKey { get; set; }

		/// <summary>
		/// Gets or sets Credit Debit Note Line Sequence
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CreditDebitNoteLineSequence, Id = Index.CreditDebitNoteLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal CreditDebitNoteLineSequence { get; set; }

		/// <summary>
		/// Gets or sets Serial Number
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string SerialNumber { get; set; }

		/// <summary>
		/// Gets or sets Operation To Post
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OperationToPost, Id = Index.OperationToPost, FieldType = EntityFieldType.Int, Size = 2)]
		public int OperationToPost { get; set; }

		/// <summary>
		/// Gets or sets Serial Count
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.SerialCount, Id = Index.SerialCount, FieldType = EntityFieldType.Long, Size = 4)]
		public long SerialCount { get; set; }
		
	}
}
