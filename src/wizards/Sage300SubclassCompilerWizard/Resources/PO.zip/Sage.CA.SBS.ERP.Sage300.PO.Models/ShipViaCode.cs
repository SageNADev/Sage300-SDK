// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Ship-Via Code
     /// </summary>
     public partial class ShipViaCode : ModelBase
     {
          /// <summary>
          /// Gets or sets Ship-Via
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ShipViaCode", ResourceType = typeof(ShipViaCodesResx))]
          [ViewField(Name = Fields.ShipVia, Id = Index.ShipVia, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string ShipVia {get; set;}

          /// <summary>
          /// Gets or sets Ship-Via Name
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ShipViaName", ResourceType = typeof(ShipViaCodesResx))]
          [ViewField(Name = Fields.ShipViaName, Id = Index.ShipViaName, FieldType = EntityFieldType.Char, Size = 60)]
          public string ShipViaName {get; set;}

          /// <summary>
          /// Gets or sets Address 1
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "AddressLine1", ResourceType = typeof(ShipViaCodesResx))]
          [ViewField(Name = Fields.Address1, Id = Index.Address1, FieldType = EntityFieldType.Char, Size = 60)]
          public string Address1 {get; set;}

          /// <summary>
          /// Gets or sets Address 2
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "AddressLine2", ResourceType = typeof(ShipViaCodesResx))]
          [ViewField(Name = Fields.Address2, Id = Index.Address2, FieldType = EntityFieldType.Char, Size = 60)]
          public string Address2 {get; set;}

          /// <summary>
          /// Gets or sets Address 3
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "AddressLine3", ResourceType = typeof(ShipViaCodesResx))]
          [ViewField(Name = Fields.Address3, Id = Index.Address3, FieldType = EntityFieldType.Char, Size = 60)]
          public string Address3 { get; set; }

          /// <summary>
          /// Gets or sets Address 4
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "AddressLine4", ResourceType = typeof(ShipViaCodesResx))]
          [ViewField(Name = Fields.Address4, Id = Index.Address4, FieldType = EntityFieldType.Char, Size = 60)]
          public string Address4 { get; set; }

          /// <summary>
          /// Gets or sets City
          /// </summary>
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "City", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
          public string City {get; set;}

          /// <summary>
          /// Gets or sets State Province
          /// </summary>
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "StateProvince", ResourceType = typeof(CommonResx))]
          [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30)]
          public string StateProvince { get; set; }

          /// <summary>
          /// Gets or sets Zip/Postal Code
          /// </summary>
          [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ZipPostalCode", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
          public string ZipPostalCode { get; set; }

          /// <summary>
          /// Gets or sets Country
          /// </summary>
          [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Country", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
          public string Country { get; set; }

          /// <summary>
          /// Gets or sets Phone Number
          /// </summary>
          [StringLength(34, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
          [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string PhoneNumber { get; set; }

          /// <summary>
          /// Gets or sets Fax Number
          /// </summary>
          [StringLength(34, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
          [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string FaxNumber { get; set; }

          /// <summary>
          /// Gets or sets Contact
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Contact", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
          public string Contact { get; set; }

          /// <summary>
          /// Gets or sets Comment
          /// </summary>
          [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 80)]
          public string Comment { get; set; }

          /// <summary>
          /// Gets or sets Email
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Email", ResourceType = typeof(CommonResx))]
          [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
          public string Email { get; set; }

          /// <summary>
          /// Gets or sets Contact Phone
          /// </summary>
          [StringLength(34, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ContactPhone", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string ContactPhone { get; set; }

          /// <summary>
          /// Gets or sets Contact Fax
          /// </summary>
          [StringLength(34, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ContactFax", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
          public string ContactFax { get; set; }

          /// <summary>
          /// Gets or sets Contact Email
          /// </summary>
          [StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ContactEmail", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
          public string ContactEmail { get; set; }

     }
}
