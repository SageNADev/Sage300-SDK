// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for CrdrNotePostingAddCost
    /// </summary>
    public partial class CrdrNotePostingAddCost : ModelBase
    {
        /// <summary>
        /// Gets or sets HeaderSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal HeaderSequence { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteCostSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CreditDebitNoteCostSequence, Id = Index.CreditDebitNoteCostSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteCostSequence { get; set; }

        /// <summary>
        /// Gets or sets OperationToPost
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.OperationToPost, Id = Index.OperationToPost, FieldType = EntityFieldType.Int, Size = 2)]
        public int OperationToPost { get; set; }

        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCostSequence
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ReceiptCostSequence, Id = Index.ReceiptCostSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptCostSequence { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSequenceKey
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.InvoiceSequenceKey, Id = Index.InvoiceSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets InvoiceCostSequence
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.InvoiceCostSequence, Id = Index.InvoiceCostSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceCostSequence { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCost
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.AdditionalCost, Id = Index.AdditionalCost, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AdditionalCost { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets ExpenseAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ExpenseAccount, Id = Index.ExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets ReturnAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ReturnAccount, Id = Index.ReturnAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ReturnAccount { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets ProrationMethod
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ProrationMethod, Id = Index.ProrationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public ProrationMethod ProrationMethod { get; set; }

        /// <summary>
        /// Gets or sets ReprorationMethod
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ReprorationMethod, Id = Index.ReprorationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReprorationMethod { get; set; }

        /// <summary>
        /// Gets or sets CostTaxClass1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CostTaxClass1, Id = Index.CostTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int CostTaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets CostTaxClass2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CostTaxClass2, Id = Index.CostTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int CostTaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets CostTaxClass3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CostTaxClass3, Id = Index.CostTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int CostTaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets CostTaxClass4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CostTaxClass4, Id = Index.CostTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int CostTaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets CostTaxClass5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CostTaxClass5, Id = Index.CostTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int CostTaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxIncludable1, Id = Index.TaxIncludable1, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxIncludable1 TaxIncludable1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxIncludable2, Id = Index.TaxIncludable2, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxIncludable2 TaxIncludable2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxIncludable3, Id = Index.TaxIncludable3, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxIncludable3 TaxIncludable3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxIncludable4, Id = Index.TaxIncludable4, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxIncludable4 TaxIncludable4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxIncludable5, Id = Index.TaxIncludable5, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxIncludable5 TaxIncludable5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets NetOfTax
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.NetOfTax, Id = Index.NetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTax { get; set; }

        /// <summary>
        /// Gets or sets FuncNetOfTax
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncNetOfTax, Id = Index.FuncNetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncNetOfTax { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount1, Id = Index.FuncTaxIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount2, Id = Index.FuncTaxIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount3, Id = Index.FuncTaxIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount4, Id = Index.FuncTaxIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount5, Id = Index.FuncTaxIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount1, Id = Index.FuncTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount2, Id = Index.FuncTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount3, Id = Index.FuncTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount4, Id = Index.FuncTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount5, Id = Index.FuncTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount1, Id = Index.FuncTaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount2, Id = Index.FuncTaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount3, Id = Index.FuncTaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount4, Id = Index.FuncTaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount5, Id = Index.FuncTaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount1, Id = Index.FuncTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount2, Id = Index.FuncTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount3, Id = Index.FuncTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount4, Id = Index.FuncTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount5, Id = Index.FuncTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ReceiptApplyToReceiptSeqKey
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ReceiptApplyToReceiptSeqKey, Id = Index.ReceiptApplyToReceiptSeqKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptApplyToReceiptSeqKey { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets RetainagePercentage
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainagePercentage, Id = Index.RetainagePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RetainagePercentage { get; set; }

        /// <summary>
        /// Gets or sets RetentionPeriod
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetentionPeriod, Id = Index.RetentionPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int RetentionPeriod { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmountOverridden
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageAmountOverridden, Id = Index.RetainageAmountOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RetainageAmountOverridden { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDateOverridden
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageDueDateOverridden, Id = Index.RetainageDueDateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RetainageDueDateOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount1, Id = Index.TaxReportingIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount2, Id = Index.TaxReportingIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount3, Id = Index.TaxReportingIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount4, Id = Index.TaxReportingIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount5, Id = Index.TaxReportingIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount1, Id = Index.TaxReportingExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount2, Id = Index.TaxReportingExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount3, Id = Index.TaxReportingExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount4, Id = Index.TaxReportingExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount5, Id = Index.TaxReportingExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt1, Id = Index.RetainageTaxRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt2, Id = Index.RetainageTaxRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt3, Id = Index.RetainageTaxRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt4, Id = Index.RetainageTaxRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt5, Id = Index.RetainageTaxRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount1, Id = Index.RetainageTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount2, Id = Index.RetainageTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount3, Id = Index.RetainageTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount4, Id = Index.RetainageTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount5, Id = Index.RetainageTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount1
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount1, Id = Index.RetainageTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount2
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount2, Id = Index.RetainageTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount3
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount3, Id = Index.RetainageTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount4
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount4, Id = Index.RetainageTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount5
        /// </summary>
        // TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
        // TODO: OR remove 'Display' attribute if not required on property
        // TODO: Delete TODO statements when complete
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount5, Id = Index.RetainageTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount5 { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets ProrationMethod string value
        /// </summary>
        public string ProrationMethodString
        {
            get { return EnumUtility.GetStringValue(ProrationMethod); }
        }

        /// <summary>
        /// Gets TaxIncludable1 string value
        /// </summary>
        public string TaxIncludable1String
        {
            get { return EnumUtility.GetStringValue(TaxIncludable1); }
        }

        /// <summary>
        /// Gets TaxIncludable2 string value
        /// </summary>
        public string TaxIncludable2String
        {
            get { return EnumUtility.GetStringValue(TaxIncludable2); }
        }

        /// <summary>
        /// Gets TaxIncludable3 string value
        /// </summary>
        public string TaxIncludable3String
        {
            get { return EnumUtility.GetStringValue(TaxIncludable3); }
        }

        /// <summary>
        /// Gets TaxIncludable4 string value
        /// </summary>
        public string TaxIncludable4String
        {
            get { return EnumUtility.GetStringValue(TaxIncludable4); }
        }

        /// <summary>
        /// Gets TaxIncludable5 string value
        /// </summary>
        public string TaxIncludable5String
        {
            get { return EnumUtility.GetStringValue(TaxIncludable5); }
        }

        #endregion
    }
}
