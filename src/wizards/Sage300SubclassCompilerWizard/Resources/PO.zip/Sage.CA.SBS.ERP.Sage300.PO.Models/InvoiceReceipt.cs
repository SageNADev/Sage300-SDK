// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.POOEInvoiceEntry;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Model class for InvoiceReceipt
    /// </summary>
    public partial class InvoiceReceipt : POOEBaseInvoiceReciepts
    {
    }
}
