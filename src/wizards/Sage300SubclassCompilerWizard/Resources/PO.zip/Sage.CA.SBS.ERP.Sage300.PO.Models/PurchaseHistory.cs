// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for PurchaseHistory model
    /// </summary>
    public partial class PurchaseHistory : ModelBase
    {
        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets ITEMNO
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        // It is required to display the Decimal values
        /// <summary>
        /// Gets or Sets the Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string CurrencyDecimal { get; set; }

        // It is required to assign Home Currency of OE Options
        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        [IgnoreExportImport]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FunctionalCurrency { get; set; }

        // It is required to display the Decimal values for Functional Currency
        /// <summary>
        /// Gets or Sets the Functional Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string FunctionalCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets NoOfReceipts
        /// </summary>
        [Display(Name = "NumberOfReceipts", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NoOfReceipts, Id = Index.NoOfReceipts, FieldType = EntityFieldType.Long, Size = 4)]
        public long NoOfReceipts { get; set; }

        /// <summary>
        /// Gets or sets QuantityReceived
        /// </summary>
        [Display(Name = "QuantityReceived", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityReceived, Id = Index.QuantityReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReceived { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalReceived
        /// </summary>
        [Display(Name = "FuncTotalReceived", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncTotalReceived, Id = Index.FuncTotalReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalReceived { get; set; }

        /// <summary>
        /// Gets or sets SrceTotalReceived
        /// </summary>
        [Display(Name = "SrceTotalReceived", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceTotalReceived, Id = Index.SrceTotalReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTotalReceived { get; set; }

        /// <summary>
        /// Gets or sets NoOfInvoices
        /// </summary>
        [Display(Name = "NumberOfInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.NoOfInvoices, Id = Index.NoOfInvoices, FieldType = EntityFieldType.Long, Size = 4)]
        public long NoOfInvoices { get; set; }

        /// <summary>
        /// Gets or sets QuantityAdjustedonInvoices
        /// </summary>
        [Display(Name = "QuantityAdjustedonInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.QuantityAdjustedonInvoices, Id = Index.QuantityAdjustedonInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityAdjustedonInvoices { get; set; }

        /// <summary>
        /// Gets or sets FuncAdjustedonInvoices
        /// </summary>
        [Display(Name = "FuncAdjustedonInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncAdjustedonInvoices, Id = Index.FuncAdjustedonInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAdjustedonInvoices { get; set; }

        /// <summary>
        /// Gets or sets SrceAdjustedonInvoices
        /// </summary>
        [Display(Name = "SrceAdjustedonInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceAdjustedonInvoices, Id = Index.SrceAdjustedonInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceAdjustedonInvoices { get; set; }

        /// <summary>
        /// Gets or sets NoOfReturns
        /// </summary>
        [Display(Name = "NumberOfReturns", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.NoOfReturns, Id = Index.NoOfReturns, FieldType = EntityFieldType.Long, Size = 4)]
        public long NoOfReturns { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QuantityReturned", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets FuncReturnAmount
        /// </summary>
        [Display(Name = "FuncReturnAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncReturnAmount, Id = Index.FuncReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceReturnAmount
        /// </summary>
        [Display(Name = "SrceReturnAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceReturnAmount, Id = Index.SrceReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets NoOfCreditNotes
        /// </summary>
        [Display(Name = "NumberOfCreditNotes", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.NoOfCreditNotes, Id = Index.NoOfCreditNotes, FieldType = EntityFieldType.Long, Size = 4)]
        public long NoOfCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets QuantityCredited
        /// </summary>
        [Display(Name = "QuantityCredited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.QuantityCredited, Id = Index.QuantityCredited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityCredited { get; set; }

        /// <summary>
        /// Gets or sets FuncCreditNoteAmount
        /// </summary>
        [Display(Name = "FuncCreditNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncCreditNoteAmount, Id = Index.FuncCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceCreditNoteAmount
        /// </summary>
        [Display(Name = "SrceCreditNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceCreditNoteAmount, Id = Index.SrceCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets NoOfDebitNotes
        /// </summary>
        [Display(Name = "NumberOfDebitNotes", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.NoOfDebitNotes, Id = Index.NoOfDebitNotes, FieldType = EntityFieldType.Long, Size = 4)]
        public long NoOfDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets QuantityDebited
        /// </summary>
        [Display(Name = "QuantityDebited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.QuantityDebited, Id = Index.QuantityDebited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityDebited { get; set; }

        /// <summary>
        /// Gets or sets FuncDebitNoteAmount
        /// </summary>
        [Display(Name = "FuncDebitNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncDebitNoteAmount, Id = Index.FuncDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceDebitNoteAmount
        /// </summary>
        [Display(Name = "SrceDebitNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceDebitNoteAmount, Id = Index.SrceDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets QuantityInvoiced
        /// </summary>
        [Display(Name = "QuantityInvoiced", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityInvoiced, Id = Index.QuantityInvoiced, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityInvoiced { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalInvoiced
        /// </summary>
        [Display(Name = "FuncTotalInvoiced", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncTotalInvoiced, Id = Index.FuncTotalInvoiced, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalInvoiced { get; set; }

        /// <summary>
        /// Gets or sets SrceTotalInvoiced
        /// </summary>
        [Display(Name = "SrceTotalInvoiced", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceTotalInvoiced, Id = Index.SrceTotalInvoiced, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTotalInvoiced { get; set; }

        /// <summary>
        /// Gets or sets TotalCreditedQuantity
        /// </summary>
        [Display(Name = "TotalCreditedQuantity", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TotalCreditedQuantity, Id = Index.TotalCreditedQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalCreditedQuantity { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalCredited
        /// </summary>
        [Display(Name = "FuncTotalCredited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncTotalCredited, Id = Index.FuncTotalCredited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalCredited { get; set; }

        /// <summary>
        /// Gets or sets SrceTotalCredited
        /// </summary>
        [Display(Name = "SrceTotalCredited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceTotalCredited, Id = Index.SrceTotalCredited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTotalCredited { get; set; }

        /// <summary>
        /// Gets or sets TotalDebitedQuantity
        /// </summary>
        [Display(Name = "TotalDebitedQuantity", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TotalDebitedQuantity, Id = Index.TotalDebitedQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalDebitedQuantity { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalDebited
        /// </summary>
        [Display(Name = "FuncTotalDebited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncTotalDebited, Id = Index.FuncTotalDebited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalDebited { get; set; }

        /// <summary>
        /// Gets or sets SrceTotalDebited
        /// </summary>
        [Display(Name = "SrceTotalDebited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceTotalDebited, Id = Index.SrceTotalDebited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTotalDebited { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets VendorName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets FMTITEMNO
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FormattedItemNumber { get; set; }

        /// <summary>
        /// List of PurchaseHistory Detail 
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<PurchaseHistoryDetail> PurchaseHistoryDetail { get; set; }

        #region UI Strings

        // Added extra parameters, required for the Purchase History Details

        /// <summary>
        /// Gets or sets From Year
        /// </summary>
        [IgnoreExportImport]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromYear { get; set; }

        /// <summary>
        /// Gets or sets To Year
        /// </summary>
        [IgnoreExportImport]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToYear { get; set; }

        /// <summary>
        /// Gets or sets From Period
        /// </summary>
        [IgnoreExportImport]
        public int FromPeriod { get; set; }

        /// <summary>
        /// Gets or sets To Period
        /// </summary>
        [IgnoreExportImport]
        public int ToPeriod { get; set; }

        /// <summary>
        /// Gets or sets Select By
        /// </summary>
        /// <value>Type</value>
        [IgnoreExportImport]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SelectBy", ResourceType = typeof(PurchaseHistoryResx))]
        public SelectedBy SelectBy { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        /// <value>Type</value>
        [IgnoreExportImport]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        public CurrencyType CurrencyType { get; set; }

        #endregion
    }
}
