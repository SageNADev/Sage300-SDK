// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.POOEInvoiceEntry;
using System;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Invoice
    /// </summary>
    public partial class Invoice : POOEBaseInvoice
    {
        #region Extra Property

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        public short SessionWarnDays { get; set; }

        #endregion

        #region Security Parameters

        /// <summary>
        /// Gets or sets IsAPVendor
        /// </summary>
        public bool IsAPVendor { get; set; }

        /// <summary>
        /// Gets or sets IsPurchaseHistory
        /// </summary>
        public bool IsPurchaseHistory { get; set; }

        /// <summary>
        /// Gets or sets IsOFTransRights
        /// </summary>
        public bool IsOfTransRights { get; set; }

        /// <summary>
        /// Get- OE module Active
        /// </summary>
        /// <value>Boolean</value>
        public bool IsOEActive { get; set; }

        /// <summary>
        /// Get- PM module Active
        /// </summary>
        /// <value>Boolean</value>
        public bool IsPMActive { get; set; }

        /// <summary>
        /// Get- Is Order Inquiry 
        /// </summary>
        /// <value>Boolean</value>
        public bool IsOrderInquiry { get; set; }

        /// <summary>
        /// Get- IsEditInvoiceQuantity
        /// </summary>
        /// <value>Boolean</value>
        public bool IsEditInvoiceQuantity { get; set; }

        /// <summary>
        /// Get- IsEditInvoiceCost
        /// </summary>
        /// <value>Boolean</value>
        public bool IsEditInvoiceCost { get; set; }

        #endregion
    }
}
