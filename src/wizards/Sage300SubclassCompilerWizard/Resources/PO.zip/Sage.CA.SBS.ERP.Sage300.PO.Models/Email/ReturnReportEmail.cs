﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Email
{
    /// <summary>
    /// Class for Return Report Email
    /// </summary>
    public class ReturnReportEmail : EmailOption
    {      
        /// <summary>
        /// Gets or Sets Reports
        /// </summary>
        public List<ReturnReport> Reports { get; set; }
    }
}
