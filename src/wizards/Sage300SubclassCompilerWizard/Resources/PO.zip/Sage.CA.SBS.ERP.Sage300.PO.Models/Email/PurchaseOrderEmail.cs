﻿/* Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved. */

#region 

using Sage.CA.SBS.ERP.Sage300.Common.Models.Email;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Email
{
    /// <summary>
    /// A simple symbol for the <see cref="EmailOption"/> for a list of <see cref="PurchaseOrderReport"/>
    /// </summary>
    public class PurchaseOrderEmail : ReportsEmailOption<PurchaseOrderReport>
    {      
    }
}
