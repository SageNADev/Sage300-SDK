// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for CreditDebitNoteComment
     /// </summary>
     public partial class CreditDebitNoteComment : ModelBase
     {
          /// <summary>
          /// Gets or sets CreditDebitNoteSequenceKey
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "CreditDebitNoteSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CreditDebitNoteSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets CommentIdentifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "CommentIdentifier", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.CommentIdentifier, Id = Index.CommentIdentifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CommentIdentifier {get; set;}

          /// <summary>
          /// Gets or sets CRDRNoteCommentSequence
          /// </summary>
          [Display(Name = "CrdrNoteCommentSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.CRDRNoteCommentSequence, Id = Index.CRDRNoteCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CRDRNoteCommentSequence {get; set;}

          /// <summary>
          /// Gets or sets StoredInDatabaseTable
          /// </summary>
          [IgnoreExportImport]
          [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool StoredInDatabaseTable {get; set;}

          /// <summary>
          /// Gets or sets LineType
          /// </summary>
          [Display(Name = "LineType", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
          public LineType LineType {get; set;}

          /// <summary>
          /// Gets or sets Comment
          /// </summary>
          [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 80)]
          public string Comment {get; set;}

     }
}
