// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for PurchaseHistoryDetail model
    /// </summary>
    public partial class PurchaseHistoryDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets ITEMNO
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        public string CustCurrency { get; set; }

        // It is required to display the Decimal values
        /// <summary>
        /// Gets or Sets the Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string CurrencyDecimal { get; set; }

        // It is required to assign Home Currency of OE Options
        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        [IgnoreExportImport]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        public string FunctionalCurrency { get; set; }

        // It is required to display the Decimal values for Functional Currency
        /// <summary>
        /// Gets or Sets the Functional Currency Decimal
        /// </summary>
        [IgnoreExportImport]
        public string FunctionalCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DayEndNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DayEndNumber, Id = Index.DayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionSequence", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TransactionSequence, Id = Index.TransactionSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionSequence { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets HeaderSequence
        /// </summary>
        [Display(Name = "HeaderSequence", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal HeaderSequence { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DocumentNumber, Id = Index.DocumentNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string DocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets QuantityRqPosted
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.QuantityRqPosted, Id = Index.QuantityRqPosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityRqPosted { get; set; }

        /// <summary>
        /// Gets or sets StockingQuantitySqPosted
        /// </summary>
        [Display(Name = "StockingQuantity", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.StockingQuantitySqPosted, Id = Index.StockingQuantitySqPosted, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal StockingQuantitySqPosted { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactor
        /// </summary>
        [Display(Name = "ConversionFactor", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.ConversionFactor, Id = Index.ConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets SrceCost
        /// </summary>
        [Display(Name = "SrceCost", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceCost, Id = Index.SrceCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceCost { get; set; }

        /// <summary>
        /// Gets or sets FuncCost
        /// </summary>
        [Display(Name = "FuncCost", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncCost, Id = Index.FuncCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCost { get; set; }

        /// <summary>
        /// Gets or sets DaysToReceive
        /// </summary>
        [Display(Name = "DaysToReceive", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.DaysToReceive, Id = Index.DaysToReceive, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysToReceive { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantity
        /// </summary>
        [Display(Name = "TotalQuantity", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TotalQuantity, Id = Index.TotalQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalQuantity { get; set; }

        /// <summary>
        /// Gets or sets StockingTotalQuantity
        /// </summary>
        [Display(Name = "StockingTotalQuantity", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.StockingTotalQuantity, Id = Index.StockingTotalQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal StockingTotalQuantity { get; set; }

        /// <summary>
        /// Gets or sets SrceTotalCost
        /// </summary>
        [Display(Name = "SrceTotalCost", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceTotalCost, Id = Index.SrceTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTotalCost { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalCost
        /// </summary>
        [Display(Name = "FuncTotalCost", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncTotalCost, Id = Index.FuncTotalCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalCost { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncDiscountAmount
        /// </summary>
        [Display(Name = "FuncDiscountAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncDiscountAmount, Id = Index.FuncDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalDiscount
        /// </summary>
        [Display(Name = "TotalDiscount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TotalDiscount, Id = Index.TotalDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDiscount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTotalDiscount
        /// </summary>
        [Display(Name = "FunctionalTotalDiscount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FunctionalTotalDiscount, Id = Index.FunctionalTotalDiscount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTotalDiscount { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets VendorName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets EntryQuantityReceived
        /// </summary>
        [Display(Name = "EntryQuantityReceived", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryQuantityReceived, Id = Index.EntryQuantityReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryQuantityReceived { get; set; }

        /// <summary>
        /// Gets or sets QuantityReceived
        /// </summary>
        [Display(Name = "QuantityReceived", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityReceived, Id = Index.QuantityReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReceived { get; set; }

        /// <summary>
        /// Gets or sets FuncReceivedAmount
        /// </summary>
        [Display(Name = "FuncReceivedAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncReceivedAmount, Id = Index.FuncReceivedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReceivedAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceReceivedAmount
        /// </summary>
        [Display(Name = "SrceReceivedAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceReceivedAmount, Id = Index.SrceReceivedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceReceivedAmount { get; set; }

        /// <summary>
        /// Gets or sets EntryQuantityAdjonInvoices
        /// </summary>
        [Display(Name = "EntryQuantityAdjonInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryQuantityAdjonInvoices, Id = Index.EntryQuantityAdjonInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryQuantityAdjonInvoices { get; set; }

        /// <summary>
        /// Gets or sets QuantityAdjustedonInvoices
        /// </summary>
        [Display(Name = "QuantityAdjustedonInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.QuantityAdjustedonInvoices, Id = Index.QuantityAdjustedonInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityAdjustedonInvoices { get; set; }

        /// <summary>
        /// Gets or sets FuncAdjustedonInvoices
        /// </summary>
        [Display(Name = "FuncAdjustedonInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncAdjustedonInvoices, Id = Index.FuncAdjustedonInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAdjustedonInvoices { get; set; }

        /// <summary>
        /// Gets or sets SrceAdjustedonInvoices
        /// </summary>
        [Display(Name = "SrceAdjustedonInvoices", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceAdjustedonInvoices, Id = Index.SrceAdjustedonInvoices, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceAdjustedonInvoices { get; set; }

        /// <summary>
        /// Gets or sets EntryQuantityReturned
        /// </summary>
        [Display(Name = "EntryQuantityReturned", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryQuantityReturned, Id = Index.EntryQuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryQuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QuantityReturned", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets FuncReturnAmount
        /// </summary>
        [Display(Name = "FuncReturnAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncReturnAmount, Id = Index.FuncReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceReturnAmount
        /// </summary>
        [Display(Name = "SrceReturnAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceReturnAmount, Id = Index.SrceReturnAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceReturnAmount { get; set; }

        /// <summary>
        /// Gets or sets EntryQuantityCredited
        /// </summary>
        [Display(Name = "EntryQuantityCredited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryQuantityCredited, Id = Index.EntryQuantityCredited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryQuantityCredited { get; set; }

        /// <summary>
        /// Gets or sets QuantityCredited
        /// </summary>
        [Display(Name = "QuantityCredited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.QuantityCredited, Id = Index.QuantityCredited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityCredited { get; set; }

        /// <summary>
        /// Gets or sets FuncCreditNoteAmount
        /// </summary>
        [Display(Name = "FuncCreditNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncCreditNoteAmount, Id = Index.FuncCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceCreditNoteAmount
        /// </summary>
        [Display(Name = "SrceCreditNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceCreditNoteAmount, Id = Index.SrceCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets EntryQuantityDebited
        /// </summary>
        [Display(Name = "EntryQuantityDebited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryQuantityDebited, Id = Index.EntryQuantityDebited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryQuantityDebited { get; set; }

        /// <summary>
        /// Gets or sets QuantityDebited
        /// </summary>
        [Display(Name = "QuantityDebited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.QuantityDebited, Id = Index.QuantityDebited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityDebited { get; set; }

        /// <summary>
        /// Gets or sets FuncDebitNoteAmount
        /// </summary>
        [Display(Name = "FuncDebitNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncDebitNoteAmount, Id = Index.FuncDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceDebitNoteAmount
        /// </summary>
        [Display(Name = "SrceDebitNoteAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceDebitNoteAmount, Id = Index.SrceDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets EntryTotalQuantityInvoiced
        /// </summary>
        [Display(Name = "EntryTotalQuantityInvoiced", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryTotalQuantityInvoiced, Id = Index.EntryTotalQuantityInvoiced, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryTotalQuantityInvoiced { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantityInvoiced
        /// </summary>
        [Display(Name = "TotalQuantityInvoiced", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TotalQuantityInvoiced, Id = Index.TotalQuantityInvoiced, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalQuantityInvoiced { get; set; }

        /// <summary>
        /// Gets or sets FuncInvoiceTotal
        /// </summary>
        [Display(Name = "FuncInvoiceTotal", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncInvoiceTotal, Id = Index.FuncInvoiceTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncInvoiceTotal { get; set; }

        /// <summary>
        /// Gets or sets SrceInvoiceTotal
        /// </summary>
        [Display(Name = "SrceInvoiceTotal", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceInvoiceTotal, Id = Index.SrceInvoiceTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceInvoiceTotal { get; set; }

        /// <summary>
        /// Gets or sets EntryTotalQuantityCredited
        /// </summary>
        [Display(Name = "EntryTotalQuantityCredited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryTotalQuantityCredited, Id = Index.EntryTotalQuantityCredited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryTotalQuantityCredited { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantityCredited
        /// </summary>
        [Display(Name = "TotalQuantityCredited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TotalQuantityCredited, Id = Index.TotalQuantityCredited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalQuantityCredited { get; set; }

        /// <summary>
        /// Gets or sets FuncCreditNoteTotal
        /// </summary>
        [Display(Name = "FuncCreditNoteTotal", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncCreditNoteTotal, Id = Index.FuncCreditNoteTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCreditNoteTotal { get; set; }

        /// <summary>
        /// Gets or sets SrceCreditNoteTotal
        /// </summary>
        [Display(Name = "SrceCreditNoteTotal", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceCreditNoteTotal, Id = Index.SrceCreditNoteTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceCreditNoteTotal { get; set; }

        /// <summary>
        /// Gets or sets EntryTotalQuantityDebited
        /// </summary>
        [Display(Name = "EntryTotalQuantityDebited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.EntryTotalQuantityDebited, Id = Index.EntryTotalQuantityDebited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal EntryTotalQuantityDebited { get; set; }

        /// <summary>
        /// Gets or sets TotalQuantityDebited
        /// </summary>
        [Display(Name = "TotalQuantityDebited", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.TotalQuantityDebited, Id = Index.TotalQuantityDebited, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal TotalQuantityDebited { get; set; }

        /// <summary>
        /// Gets or sets FuncDebitNoteTotal
        /// </summary>
        [Display(Name = "FuncDebitNoteTotal", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncDebitNoteTotal, Id = Index.FuncDebitNoteTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDebitNoteTotal { get; set; }

        /// <summary>
        /// Gets or sets SrceDebitNoteTotal
        /// </summary>
        [Display(Name = "SrceDebitNoteTotal", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceDebitNoteTotal, Id = Index.SrceDebitNoteTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceDebitNoteTotal { get; set; }

        /// <summary>
        /// Gets or sets QuantityRqDisplay
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.QuantityRqDisplay, Id = Index.QuantityRqDisplay, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityRqDisplay { get; set; }

        /// <summary>
        /// Gets or sets StockingQuantitySqDisplay
        /// </summary>
        [Display(Name = "StockingQuantity", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.StockingQuantitySqDisplay, Id = Index.StockingQuantitySqDisplay, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal StockingQuantitySqDisplay { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAmount
        /// </summary>
        [Display(Name = "FunctionalAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FunctionalAmount, Id = Index.FunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets SourceAmount
        /// </summary>
        [Display(Name = "SourceAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SourceAmount, Id = Index.SourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceAmount { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets FMTITEMNO
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string FormattedItemNumber { get; set; }

        /// <summary>
        /// Gets or sets SrceNetExtendedAmount
        /// </summary>
        [Display(Name = "SrceNetExtendedAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceNetExtendedAmount, Id = Index.SrceNetExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceNetExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncNetExtendedAmount
        /// </summary>
        [Display(Name = "FuncNetExtendedAmount", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncNetExtendedAmount, Id = Index.FuncNetExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncNetExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceTotalNetCost
        /// </summary>
        [Display(Name = "SrceTotalNetCost", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.SrceTotalNetCost, Id = Index.SrceTotalNetCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceTotalNetCost { get; set; }

        /// <summary>
        /// Gets or sets FuncTotalNetCost
        /// </summary>
        [Display(Name = "FuncTotalNetCost", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.FuncTotalNetCost, Id = Index.FuncTotalNetCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTotalNetCost { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(PurchaseHistoryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TransactionType", ResourceType = typeof(PurchaseHistoryResx))]
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        #endregion
    }
}
