// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for RequisitionComment
     /// </summary>
     public partial class RequisitionComment : ModelBase
     {
          /// <summary>
          /// Gets or sets RequisitionSequenceKey
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "RequisitionSequenceKey", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.RequisitionSequenceKey, Id = Index.RequisitionSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal RequisitionSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets CommentIdentifier
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "CommentIdentifier", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.CommentIdentifier, Id = Index.CommentIdentifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CommentIdentifier {get; set;}

          /// <summary>
          /// Gets or sets RequisitionCommentSequence
          /// </summary>
           [Display(Name = "RequisitionCommentSequence", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.RequisitionCommentSequence, Id = Index.RequisitionCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal RequisitionCommentSequence {get; set;}

          /// <summary>
          /// Gets or sets StoredInDatabaseTable
          /// </summary>
           [IgnoreExportImport]
          [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
          public StoredInDatabaseTable StoredInDatabaseTable {get; set;}

          /// <summary>
          /// Gets or sets LineType
          /// </summary>
          [Display(Name = "LineType", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
          public LineType LineType {get; set;}

          /// <summary>
          /// Gets or sets CommentsInstructions
          /// </summary>
          [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "CommentsInstructions", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.CommentsInstructions, Id = Index.CommentsInstructions, FieldType = EntityFieldType.Char, Size = 80)]
          public string CommentsInstructions {get; set;}

          /// <summary>
          /// Get or Set  Attributes
          /// </summary>
          [IgnoreExportImport]
          public IDictionary<string, object> Attributes { get; set; }
     }
}
