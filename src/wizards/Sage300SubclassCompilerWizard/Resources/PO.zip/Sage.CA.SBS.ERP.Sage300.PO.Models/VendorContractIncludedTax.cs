// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Vendor Contract Included Tax
     /// </summary>
     public partial class VendorContractIncludedTax : ModelBase
     {
          /// <summary>
          /// Gets or sets Item Number
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ItemNumber { get; set; }

          /// <summary>
          /// Gets or sets Vendor
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
          public string Vendor { get; set; }

          /// <summary>
          /// Gets or sets Tax Authority
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "TaxAuthority", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string TaxAuthority { get; set; }

          /// <summary>
          /// Gets or sets Tax Class
          /// </summary>
          [Display(Name = "TaxClass", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.TaxClass, Id = Index.TaxClass, FieldType = EntityFieldType.Int, Size = 2)]
          public int TaxClass { get; set; }

          /// <summary>
          /// Gets or sets Tax Authority Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "TaxAuthorityDescription", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.TaxAuthorityDescription, Id = Index.TaxAuthorityDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxAuthorityDescription { get; set; }

          /// <summary>
          /// Gets or sets Tax Class Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "TaxClassDesc", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.TaxClassDescription, Id = Index.TaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string TaxClassDescription { get; set; }

          /// <summary>
          /// Gets or sets Serial Number
          /// </summary>
          [IgnoreExportImport]
          public long SerialNumber { get; set; }

     }
}
