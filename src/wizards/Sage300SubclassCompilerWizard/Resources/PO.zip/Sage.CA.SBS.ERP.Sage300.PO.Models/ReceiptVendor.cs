// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of properties for ReceiptVendor
    /// </summary>
    public partial class ReceiptVendor : ModelBase
    {
        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets Costs
        /// </summary>
        [Display(Name = "Costs", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Costs, Id = Index.Costs, FieldType = EntityFieldType.Long, Size = 4)]
        public long Costs { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCostsProrated
        /// </summary>
        [Display(Name = "NumberOfCostsProrated", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfCostsProrated, Id = Index.NumberOfCostsProrated, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfCostsProrated { get; set; }

        /// <summary>
        /// Gets or sets CostsComplete
        /// </summary>
        [Display(Name = "CostsComplete", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.CostsComplete, Id = Index.CostsComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostsComplete { get; set; }

        /// <summary>
        /// Gets or sets StoredInDatabaseTable
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
        public StoredInDatabaseTable StoredInDatabaseTable { get; set; }

        /// <summary>
        /// Gets or sets AutoTaxCalculationOnSave
        /// </summary>
        [Display(Name = "Autotaxcalculationonsave", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.AutoTaxCalculationOnSave, Id = Index.AutoTaxCalculationOnSave, FieldType = EntityFieldType.Bool, Size = 2)]
        public AutoTaxCalculationOnSave AutoTaxCalculationOnSave { get; set; }

        /// <summary>
        /// Gets or sets Invoiced
        /// </summary>
        [Display(Name = "Invoiced", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Invoiced, Id = Index.Invoiced, FieldType = EntityFieldType.Bool, Size = 2)]
        public Invoiced Invoiced { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorExists
        /// </summary>
        [Display(Name = "VendorExists", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Address1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address1", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address1, Id = Index.Address1, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address1 { get; set; }

        /// <summary>
        /// Gets or sets Address2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address2", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address2, Id = Index.Address2, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets Address3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address3", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address3, Id = Index.Address3, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address3 { get; set; }

        /// <summary>
        /// Gets or sets Address4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address4", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address4, Id = Index.Address4, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets TermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsCode", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateMatchType
        /// </summary>
        [Display(Name = "RateMatchType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RateMatchType, Id = Index.RateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateMatchType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden
        /// </summary>
        [Display(Name = "RateOverridden", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlaces
        /// </summary>
        [Display(Name = "DecimalPlaces", ResourceType = typeof(CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DecimalPlaces, Id = Index.DecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets Total
        /// </summary>
        [Display(Name = "Total", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Total, Id = Index.Total, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Total { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1
        /// </summary>
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2
        /// </summary>
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3
        /// </summary>
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4
        /// </summary>
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5
        /// </summary>
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets NetOfTax
        /// </summary>
        [Display(Name = "NetofTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NetOfTax, Id = Index.NetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTax { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded
        /// </summary>
        [Display(Name = "TaxIncluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxIncluded, Id = Index.TaxIncluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded
        /// </summary>
        [Display(Name = "TaxExcluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxExcluded, Id = Index.TaxExcluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded { get; set; }

        /// <summary>
        /// Gets or sets TotalTax
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TotalTax, Id = Index.TotalTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTax { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxRecoverable
        /// </summary>
        [Display(Name = "TotalTaxRecoverable", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalTaxRecoverable, Id = Index.TotalTaxRecoverable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxRecoverable { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxExpensed
        /// </summary>
        [Display(Name = "TotalTaxExpensed", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalTaxExpensed, Id = Index.TotalTaxExpensed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxExpensed { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAllocated
        /// </summary>
        [Display(Name = "TotalTaxAllocated", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TotalTaxAllocated, Id = Index.TotalTaxAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAllocated { get; set; }

        /// <summary>
        /// Gets or sets ConversionSourceAmount
        /// </summary>
        [Display(Name = "ConversionSourceAmount", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ConversionSourceAmount, Id = Index.ConversionSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets ConversionFunctionalAmount
        /// </summary>
        [Display(Name = "ConversionFunctionalAmount", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ConversionFunctionalAmount, Id = Index.ConversionFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets ManualToProrate
        /// </summary>
        [Display(Name = "ManualToProrate", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ManualToProrate, Id = Index.ManualToProrate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ManualToProrate { get; set; }

        /// <summary>
        /// Gets or sets TaxLines
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxLines, Id = Index.TaxLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxLines { get; set; }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        [Display(Name = "Completed", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

        /// <summary>
        /// Gets or sets DateCompleted
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets ContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactPhone", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactFax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactFax { get; set; }

        /// <summary>
        /// Gets or sets ContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactEmail", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactEmail { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedCosts
        /// </summary>
        [Display(Name = "JobRelatedCosts", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.JobRelatedCosts, Id = Index.JobRelatedCosts, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedCosts { get; set; }

        /// <summary>
        /// Gets or sets CostBillingRatesProrated
        /// </summary>
        [Display(Name = "CostBillingRatesProrated", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.CostBillingRatesProrated, Id = Index.CostBillingRatesProrated, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostBillingRatesProrated { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTermsCode", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxReportingCurrency, Id = Index.TaxReportingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrency { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateSpread
        /// </summary>
        [Display(Name = "TaxReportingRateSpread", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateSpread, Id = Index.TaxReportingRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingRateSpread { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateMatchType  
        /// </summary>
        [Display(Name = "TaxReportingRateMatchType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateMatchType, Id = Index.TaxReportingRateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateMatchType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation
        /// </summary>
        [Display(Name = "TaxReportingRateOperation", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingRateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOverridden
        /// </summary>
        [Display(Name = "TaxReportingRateOverridden", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingRateOverridden, Id = Index.TaxReportingRateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingRateOverridden TaxReportingRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingDecimalPlaces
        /// </summary>
        [Display(Name = "TaxReportingDecimalPlaces", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingDecimalPlaces, Id = Index.TaxReportingDecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingDecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount1, Id = Index.TaxReportingIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount2, Id = Index.TaxReportingIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount3, Id = Index.TaxReportingIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount4, Id = Index.TaxReportingIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount5, Id = Index.TaxReportingIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount1, Id = Index.TaxReportingExcludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount2, Id = Index.TaxReportingExcludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount3, Id = Index.TaxReportingExcludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount4, Id = Index.TaxReportingExcludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount5, Id = Index.TaxReportingExcludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyDescription", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsCodeDesc", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TermsCodeDescription, Id = Index.TermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets RateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateTypeDescription", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RateTypeDescription, Id = Index.RateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroupDesc", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass1Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass2Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass3Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass4Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass5Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5Description", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets NetOfTaxSum
        /// </summary>
        [Display(Name = "NetOfTaxSum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.NetOfTaxSum, Id = Index.NetOfTaxSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTaxSum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1Sum
        /// </summary>
        [Display(Name = "TaxIncluded1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded1Sum, Id = Index.TaxIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2Sum
        /// </summary>
        [Display(Name = "TaxIncluded2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded2Sum, Id = Index.TaxIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3Sum
        /// </summary>
        [Display(Name = "TaxIncluded3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded3Sum, Id = Index.TaxIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4Sum
        /// </summary>
        [Display(Name = "TaxIncluded4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded4Sum, Id = Index.TaxIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5Sum
        /// </summary>
        [Display(Name = "TaxIncluded5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded5Sum, Id = Index.TaxIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount1Sum, Id = Index.TaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount2Sum, Id = Index.TaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount3Sum, Id = Index.TaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount4Sum, Id = Index.TaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount5Sum, Id = Index.TaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount1Sum, Id = Index.TaxRecoverableAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount2Sum, Id = Index.TaxRecoverableAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount3Sum, Id = Index.TaxRecoverableAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount4Sum, Id = Index.TaxRecoverableAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount5Sum, Id = Index.TaxRecoverableAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount1Sum, Id = Index.TaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount2Sum, Id = Index.TaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount3Sum, Id = Index.TaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount4Sum, Id = Index.TaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount5Sum, Id = Index.TaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAllocated1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TotalTaxAllocated1, Id = Index.TotalTaxAllocated1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAllocated1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded1, Id = Index.TaxExcluded1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded1 { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedTax
        /// </summary>
        [Display(Name = "TotalUnbalancedAllocatedTax", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TotalUnbalancedTax, Id = Index.TotalUnbalancedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedTax { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedAllocatedTax
        /// </summary>
        [Display(Name = "TotalUnbalancedAllocatedTax", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TotalUnbalancedAllocatedTax, Id = Index.TotalUnbalancedAllocatedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedAllocatedTax { get; set; }

        /// <summary>
        /// Gets or sets PrimaryNetOfTax
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryNetOfTax, Id = Index.PrimaryNetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryNetOfTax { get; set; }

        /// <summary>
        /// Gets or sets PrimaryIncludedTaxAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryIncludedTaxAmount1, Id = Index.PrimaryIncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryIncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryIncludedTaxAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryIncludedTaxAmount2, Id = Index.PrimaryIncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryIncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryIncludedTaxAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryIncludedTaxAmount3, Id = Index.PrimaryIncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryIncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryIncludedTaxAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryIncludedTaxAmount4, Id = Index.PrimaryIncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryIncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryIncludedTaxAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryIncludedTaxAmount5, Id = Index.PrimaryIncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryIncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAllocatedAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAllocatedAmount1, Id = Index.PrimaryTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAllocatedAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAllocatedAmount2, Id = Index.PrimaryTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAllocatedAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAllocatedAmount3, Id = Index.PrimaryTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAllocatedAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAllocatedAmount4, Id = Index.PrimaryTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAllocatedAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAllocatedAmount5, Id = Index.PrimaryTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxRecoverableAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxRecoverableAmount1, Id = Index.PrimaryTaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxRecoverableAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxRecoverableAmount2, Id = Index.PrimaryTaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxRecoverableAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxRecoverableAmount3, Id = Index.PrimaryTaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxRecoverableAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxRecoverableAmount4, Id = Index.PrimaryTaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxRecoverableAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxRecoverableAmount5, Id = Index.PrimaryTaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxExpenseAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxExpenseAmount1, Id = Index.PrimaryTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxExpenseAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxExpenseAmount2, Id = Index.PrimaryTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxExpenseAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxExpenseAmount3, Id = Index.PrimaryTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxExpenseAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxExpenseAmount4, Id = Index.PrimaryTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxExpenseAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxExpenseAmount5, Id = Index.PrimaryTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Amount1
        /// </summary>        
        [IgnoreExportImport]
        [ViewField(Name = Fields.Amount1, Id = Index.Amount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount1 { get; set; }

        /// <summary>
        /// Gets or sets Subtotal
        /// </summary>
        [Display(Name = "Subtotal", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Subtotal, Id = Index.Subtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Subtotal { get; set; }

        /// <summary>
        /// Gets or sets Vendors
        /// </summary>
        [Display(Name = "Vendors", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Vendors, Id = Index.Vendors, FieldType = EntityFieldType.Long, Size = 4)]
        public long Vendors { get; set; }

        /// <summary>
        /// Gets or sets VendorsCompleted
        /// </summary>
        [Display(Name = "VendorsCompleted", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorsCompleted, Id = Index.VendorsCompleted, FieldType = EntityFieldType.Long, Size = 4)]
        public long VendorsCompleted { get; set; }

        /// <summary>
        /// Gets or sets VendorsInvoiced
        /// </summary>
        [Display(Name = "VendorsInvoiced", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorsInvoiced, Id = Index.VendorsInvoiced, FieldType = EntityFieldType.Long, Size = 4)]
        public long VendorsInvoiced { get; set; }

        /// <summary>
        /// Gets or sets TaxcalculationIspending
        /// </summary>
        [Display(Name = "TaxcalculationIspending", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxcalculationIspending, Id = Index.TaxcalculationIspending, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxcalculationIspending TaxcalculationIspending { get; set; }

        /// <summary>
        /// Gets or sets DocumentLocked
        /// </summary>
        [Display(Name = "DocumentLocked", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DocumentLocked, Id = Index.DocumentLocked, FieldType = EntityFieldType.Bool, Size = 2)]
        public DocumentLocked DocumentLocked { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateExists
        /// </summary>
        [Display(Name = "ExchangeRateExists", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExchangeRateExists, Id = Index.ExchangeRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public ExchangeRateExists ExchangeRateExists { get; set; }

        /// <summary>
        /// Gets or sets IsThisVendorPrimary
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.IsThisVendorPrimary, Id = Index.IsThisVendorPrimary, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsThisVendorPrimary IsThisVendorPrimary { get; set; }

        /// <summary>
        /// Gets or sets HasDetails
        /// </summary>
        [Display(Name = "HasDetails", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.HasDetails, Id = Index.HasDetails, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasDetails HasDetails { get; set; }

        /// <summary>
        /// Gets or sets TaxLines1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxLines1, Id = Index.TaxLines1, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxLines1 { get; set; }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [Display(Name = "Command", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTermsCodeDescription", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTermsCodeDescription, Id = Index.RetainageTermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RetainageTermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageAmount
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageAmount, Id = Index.PrimaryRetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets UnretainedTotal
        /// </summary>
        [Display(Name = "UnretainedTotal", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.UnretainedTotal, Id = Index.UnretainedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnretainedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount1
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount1, Id = Index.TaxReportingExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount2
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount2, Id = Index.TaxReportingExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount3
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount3, Id = Index.TaxReportingExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount4
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount4, Id = Index.TaxReportingExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount5
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount5, Id = Index.TaxReportingExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchRateExists
        /// </summary>
        [Display(Name = "TaxReportingExchRateExists", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExchRateExists, Id = Index.TaxReportingExchRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingExchRateExists TaxReportingExchRateExists { get; set; }

        /// <summary>
        /// Gets or sets DerivedTaxReportingExchRate
        /// </summary>
        [Display(Name = "DerivedTaxReportingExchRate", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DerivedTaxReportingExchRate, Id = Index.DerivedTaxReportingExchRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal DerivedTaxReportingExchRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyDesc", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingCurrencyDesc, Id = Index.TaxReportingCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateTypeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateTypeDesc", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingRateTypeDesc, Id = Index.TaxReportingRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotalAmount
        /// </summary>
        [Display(Name = "TaxReportingTotalAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingTotalAmount, Id = Index.TaxReportingTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount, Id = Index.TaxReportingIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount, Id = Index.TaxReportingExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmount
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmount, Id = Index.TaxReportingRecoverableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount, Id = Index.TaxReportingExpensedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount, Id = Index.TaxReportingAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1Sum
        /// </summary>
        [Display(Name = "TaxBase1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase1Sum, Id = Index.TaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2Sum
        /// </summary>
        [Display(Name = "TaxBase2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase2Sum, Id = Index.TaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3Sum
        /// </summary>
        [Display(Name = "TaxBase3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase3Sum, Id = Index.TaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4Sum
        /// </summary>
        [Display(Name = "TaxBase4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase4Sum, Id = Index.TaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5Sum
        /// </summary>
        [Display(Name = "TaxBase5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase5Sum, Id = Index.TaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1Sum
        /// </summary>
        [Display(Name = "TaxAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount1Sum, Id = Index.TaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2Sum
        /// </summary>
        [Display(Name = "TaxAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount2Sum, Id = Index.TaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3Sum
        /// </summary>
        [Display(Name = "TaxAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount3Sum, Id = Index.TaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4Sum
        /// </summary>
        [Display(Name = "TaxAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount4Sum, Id = Index.TaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5Sum
        /// </summary>
        [Display(Name = "TaxAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount5Sum, Id = Index.TaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded1Sum
        /// </summary>
        [Display(Name = "TaxExcluded1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded1Sum, Id = Index.TaxExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded2Sum
        /// </summary>
        [Display(Name = "TaxExcluded2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded2Sum, Id = Index.TaxExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded3Sum
        /// </summary>
        [Display(Name = "TaxExcluded3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded3Sum, Id = Index.TaxExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded4Sum
        /// </summary>
        [Display(Name = "TaxExcluded4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded4Sum, Id = Index.TaxExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded5Sum
        /// </summary>
        [Display(Name = "TaxExcluded5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded5Sum, Id = Index.TaxExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1Sum
        /// </summary>
        [Display(Name = "TaxReportingAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount1Sum, Id = Index.TaxReportingAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2Sum
        /// </summary>
        [Display(Name = "TaxReportingAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount2Sum, Id = Index.TaxReportingAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3Sum
        /// </summary>
        [Display(Name = "TaxReportingAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount3Sum, Id = Index.TaxReportingAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4Sum
        /// </summary>
        [Display(Name = "TaxReportingAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount4Sum, Id = Index.TaxReportingAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5Sum
        /// </summary>
        [Display(Name = "TaxReportingAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount5Sum, Id = Index.TaxReportingAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded1Sum
        /// </summary>
        [Display(Name = "TaxReportingIncluded1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded1Sum, Id = Index.TaxReportingIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded2Sum
        /// </summary>
        [Display(Name = "TaxReportingIncluded2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded2Sum, Id = Index.TaxReportingIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded3Sum
        /// </summary>
        [Display(Name = "TaxReportingIncluded3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded3Sum, Id = Index.TaxReportingIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded4Sum
        /// </summary>
        [Display(Name = "TaxReportingIncluded4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded4Sum, Id = Index.TaxReportingIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded5Sum
        /// </summary>
        [Display(Name = "TaxReportingIncluded5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded5Sum, Id = Index.TaxReportingIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded1Sum
        /// </summary>
        [Display(Name = "TaxReportingExcluded1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded1Sum, Id = Index.TaxReportingExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded2Sum
        /// </summary>
        [Display(Name = "TaxReportingExcluded2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded2Sum, Id = Index.TaxReportingExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded3Sum
        /// </summary>
        [Display(Name = "TaxReportingExcluded3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded3Sum, Id = Index.TaxReportingExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded4Sum
        /// </summary>
        [Display(Name = "TaxReportingExcluded4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded4Sum, Id = Index.TaxReportingExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded5Sum
        /// </summary>
        [Display(Name = "TaxReportingExcluded5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded5Sum, Id = Index.TaxReportingExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount1Sum
        /// </summary>
        [Display(Name = "TaxRepAllocatedAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount1Sum, Id = Index.TaxRepAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount2Sum
        /// </summary>
        [Display(Name = "TaxRepAllocatedAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount2Sum, Id = Index.TaxRepAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount3Sum
        /// </summary>
        [Display(Name = "TaxRepAllocatedAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount3Sum, Id = Index.TaxRepAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount4Sum
        /// </summary>
        [Display(Name = "TaxRepAllocatedAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount4Sum, Id = Index.TaxRepAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount5Sum
        /// </summary>
        [Display(Name = "TaxRepAllocatedAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount5Sum, Id = Index.TaxRepAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt1Sum
        /// </summary>
        [Display(Name = "TaxRepRecoverableAmt1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt1Sum, Id = Index.TaxRepRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt2Sum
        /// </summary>
        [Display(Name = "TaxRepRecoverableAmt2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt2Sum, Id = Index.TaxRepRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt3Sum
        /// </summary>
        [Display(Name = "TaxRepRecoverableAmt3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt3Sum, Id = Index.TaxRepRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt4Sum
        /// </summary>
        [Display(Name = "TaxRepRecoverableAmt4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt4Sum, Id = Index.TaxRepRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt5Sum
        /// </summary>
        [Display(Name = "TaxRepRecoverableAmt5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt5Sum, Id = Index.TaxRepRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount1Sum
        /// </summary>
        [Display(Name = "TaxRepExpenseAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount1Sum, Id = Index.TaxRepExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount2Sum
        /// </summary>
        [Display(Name = "TaxRepExpenseAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount2Sum, Id = Index.TaxRepExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount3Sum
        /// </summary>
        [Display(Name = "TaxRepExpenseAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount3Sum, Id = Index.TaxRepExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount4Sum
        /// </summary>
        [Display(Name = "TaxRepExpenseAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount4Sum, Id = Index.TaxRepExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount5Sum
        /// </summary>
        [Display(Name = "TaxRepExpenseAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount5Sum, Id = Index.TaxRepExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxBase1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxBase1, Id = Index.PrimaryTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxBase2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxBase2, Id = Index.PrimaryTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxBase3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxBase3, Id = Index.PrimaryTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxBase4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxBase4, Id = Index.PrimaryTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxBase5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxBase5, Id = Index.PrimaryTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAmount1, Id = Index.PrimaryTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAmount2, Id = Index.PrimaryTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAmount3, Id = Index.PrimaryTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAmount4, Id = Index.PrimaryTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryTaxAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryTaxAmount5, Id = Index.PrimaryTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryExcludedTaxAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryExcludedTaxAmount1, Id = Index.PrimaryExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryExcludedTaxAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryExcludedTaxAmount2, Id = Index.PrimaryExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryExcludedTaxAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryExcludedTaxAmount3, Id = Index.PrimaryExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryExcludedTaxAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryExcludedTaxAmount4, Id = Index.PrimaryExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryExcludedTaxAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryExcludedTaxAmount5, Id = Index.PrimaryExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAmount1, Id = Index.PrmTaxRepAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAmount2, Id = Index.PrmTaxRepAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAmount3, Id = Index.PrmTaxRepAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAmount4, Id = Index.PrmTaxRepAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAmount5, Id = Index.PrmTaxRepAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepIncludedAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepIncludedAmount1, Id = Index.PrmTaxRepIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepIncludedAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepIncludedAmount2, Id = Index.PrmTaxRepIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepIncludedAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepIncludedAmount3, Id = Index.PrmTaxRepIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepIncludedAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepIncludedAmount4, Id = Index.PrmTaxRepIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepIncludedAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepIncludedAmount5, Id = Index.PrmTaxRepIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExcludedAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExcludedAmount1, Id = Index.PrmTaxRepExcludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExcludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExcludedAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExcludedAmount2, Id = Index.PrmTaxRepExcludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExcludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExcludedAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExcludedAmount3, Id = Index.PrmTaxRepExcludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExcludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExcludedAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExcludedAmount4, Id = Index.PrmTaxRepExcludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExcludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExcludedAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExcludedAmount5, Id = Index.PrmTaxRepExcludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExcludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAllocatedAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAllocatedAmount1, Id = Index.PrmTaxRepAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAllocatedAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAllocatedAmount2, Id = Index.PrmTaxRepAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAllocatedAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAllocatedAmount3, Id = Index.PrmTaxRepAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAllocatedAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAllocatedAmount4, Id = Index.PrmTaxRepAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepAllocatedAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepAllocatedAmount5, Id = Index.PrmTaxRepAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepRecoverableAmt1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepRecoverableAmt1, Id = Index.PrmTaxRepRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepRecoverableAmt2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepRecoverableAmt2, Id = Index.PrmTaxRepRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepRecoverableAmt3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepRecoverableAmt3, Id = Index.PrmTaxRepRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepRecoverableAmt4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepRecoverableAmt4, Id = Index.PrmTaxRepRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepRecoverableAmt5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepRecoverableAmt5, Id = Index.PrmTaxRepRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExpenseAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExpenseAmount1, Id = Index.PrmTaxRepExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExpenseAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExpenseAmount2, Id = Index.PrmTaxRepExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExpenseAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExpenseAmount3, Id = Index.PrmTaxRepExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExpenseAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExpenseAmount4, Id = Index.PrmTaxRepExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrmTaxRepExpenseAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmTaxRepExpenseAmount5, Id = Index.PrmTaxRepExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmTaxRepExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt1
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt1, Id = Index.RetainageTaxRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt2
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt2, Id = Index.RetainageTaxRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt3
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt3, Id = Index.RetainageTaxRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt4
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt4, Id = Index.RetainageTaxRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt5
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt5, Id = Index.RetainageTaxRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount1
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount1, Id = Index.RetainageTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount2
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount2, Id = Index.RetainageTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount3
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount3, Id = Index.RetainageTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount4
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount4, Id = Index.RetainageTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount5
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount5, Id = Index.RetainageTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount1, Id = Index.RetainageTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount2, Id = Index.RetainageTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount3, Id = Index.RetainageTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount4, Id = Index.RetainageTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount5, Id = Index.RetainageTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets WarnOnRetainageTaxShift
        /// </summary>
        [Display(Name = "WarnOnRetainageTaxShift", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.WarnOnRetainageTaxShift, Id = Index.WarnOnRetainageTaxShift, FieldType = EntityFieldType.Bool, Size = 2)]
        public WarnOnRetainageTaxShift WarnOnRetainageTaxShift { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxTotalAmount
        /// </summary>
        [Display(Name = "RetainageTaxTotalAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxTotalAmount, Id = Index.RetainageTaxTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt1
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt1, Id = Index.TaxAmountPlusRtgTaxAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt2
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt2, Id = Index.TaxAmountPlusRtgTaxAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt3
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt3, Id = Index.TaxAmountPlusRtgTaxAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt4
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt4, Id = Index.TaxAmountPlusRtgTaxAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt5
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt5, Id = Index.TaxAmountPlusRtgTaxAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1Sum
        /// </summary>
        [Display(Name = "RetainageTaxBase1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase1Sum, Id = Index.RetainageTaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2Sum
        /// </summary>
        [Display(Name = "RetainageTaxBase2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase2Sum, Id = Index.RetainageTaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3Sum
        /// </summary>
        [Display(Name = "RetainageTaxBase3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase3Sum, Id = Index.RetainageTaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4Sum
        /// </summary>
        [Display(Name = "RetainageTaxBase4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase4Sum, Id = Index.RetainageTaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5Sum
        /// </summary>
        [Display(Name = "RetainageTaxBase5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase5Sum, Id = Index.RetainageTaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1Sum
        /// </summary>
        [Display(Name = "RetainageTaxAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount1Sum, Id = Index.RetainageTaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2Sum
        /// </summary>
        [Display(Name = "RetainageTaxAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount2Sum, Id = Index.RetainageTaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3Sum
        /// </summary>
        [Display(Name = "RetainageTaxAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount3Sum, Id = Index.RetainageTaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4Sum
        /// </summary>
        [Display(Name = "RetainageTaxAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount4Sum, Id = Index.RetainageTaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5Sum
        /// </summary>
        [Display(Name = "RetainageTaxAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount5Sum, Id = Index.RetainageTaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt1Sum
        /// </summary>
        [Display(Name = "RtgTaxRecoverableAmt1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt1Sum, Id = Index.RtgTaxRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt2Sum
        /// </summary>
        [Display(Name = "RtgTaxRecoverableAmt2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt2Sum, Id = Index.RtgTaxRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt3Sum
        /// </summary>
        [Display(Name = "RtgTaxRecoverableAmt3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt3Sum, Id = Index.RtgTaxRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt4Sum
        /// </summary>
        [Display(Name = "RtgTaxRecoverableAmt4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt4Sum, Id = Index.RtgTaxRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt5Sum
        /// </summary>
        [Display(Name = "RtgTaxRecoverableAmt5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt5Sum, Id = Index.RtgTaxRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount1Sum
        /// </summary>
        [Display(Name = "RtgTaxExpenseAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount1Sum, Id = Index.RtgTaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount2Sum
        /// </summary>
        [Display(Name = "RtgTaxExpenseAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount2Sum, Id = Index.RtgTaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount3Sum
        /// </summary>
        [Display(Name = "RtgTaxExpenseAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount3Sum, Id = Index.RtgTaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount4Sum
        /// </summary>
        [Display(Name = "RtgTaxExpenseAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount4Sum, Id = Index.RtgTaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount5Sum
        /// </summary>
        [Display(Name = "RtgTaxExpenseAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount5Sum, Id = Index.RtgTaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount1Sum
        /// </summary>
        [Display(Name = "RtgTaxAllocatedAmount1Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount1Sum, Id = Index.RtgTaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount2Sum
        /// </summary>
        [Display(Name = "RtgTaxAllocatedAmount2Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount2Sum, Id = Index.RtgTaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount3Sum
        /// </summary>
        [Display(Name = "RtgTaxAllocatedAmount3Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount3Sum, Id = Index.RtgTaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount4Sum
        /// </summary>
        [Display(Name = "RtgTaxAllocatedAmount4Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount4Sum, Id = Index.RtgTaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount5Sum
        /// </summary>
        [Display(Name = "RtgTaxAllocatedAmount5Sum", ResourceType = typeof(ReceiptEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount5Sum, Id = Index.RtgTaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxBase1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxBase1, Id = Index.PrimaryRetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxBase2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxBase2, Id = Index.PrimaryRetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxBase3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxBase3, Id = Index.PrimaryRetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxBase4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxBase4, Id = Index.PrimaryRetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxBase5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxBase5, Id = Index.PrimaryRetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxAmount1, Id = Index.PrimaryRetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxAmount2, Id = Index.PrimaryRetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxAmount3, Id = Index.PrimaryRetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxAmount4, Id = Index.PrimaryRetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrimaryRetainageTaxAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrimaryRetainageTaxAmount5, Id = Index.PrimaryRetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrimaryRetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxRecoverableAmt1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxRecoverableAmt1, Id = Index.PrmRtgTaxRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxRecoverableAmt2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxRecoverableAmt2, Id = Index.PrmRtgTaxRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxRecoverableAmt3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxRecoverableAmt3, Id = Index.PrmRtgTaxRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxRecoverableAmt4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxRecoverableAmt4, Id = Index.PrmRtgTaxRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxRecoverableAmt5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxRecoverableAmt5, Id = Index.PrmRtgTaxRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxExpenseAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxExpenseAmount1, Id = Index.PrmRtgTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxExpenseAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxExpenseAmount2, Id = Index.PrmRtgTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxExpenseAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxExpenseAmount3, Id = Index.PrmRtgTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxExpenseAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxExpenseAmount4, Id = Index.PrmRtgTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxExpenseAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxExpenseAmount5, Id = Index.PrmRtgTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxAllocatedAmount1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxAllocatedAmount1, Id = Index.PrmRtgTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxAllocatedAmount2
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxAllocatedAmount2, Id = Index.PrmRtgTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxAllocatedAmount3
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxAllocatedAmount3, Id = Index.PrmRtgTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxAllocatedAmount4
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxAllocatedAmount4, Id = Index.PrmRtgTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets PrmRtgTaxAllocatedAmount5
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PrmRtgTaxAllocatedAmount5, Id = Index.PrmRtgTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PrmRtgTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorAccountSet1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.VendorAccountSet, Id = Index.VendorAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string VendorAccountSet { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSetDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorForImportExport", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.VendorAccountSetDescription, Id = Index.VendorAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets VendorImportExport
        /// </summary>
       [Display(Name = "VendorForImportExport", ResourceType = typeof(ReceiptEntryResx))]
        public string VendorImportExport { get; set; }

        #region Properties for UI

        /// <summary>
        /// Gets the AutoTaxCalculationOnSave string
        /// </summary>
        [IgnoreExportImport]
        public string AutoTaxCalculationOnSaveString
        {
            get { return EnumUtility.GetStringValue(AutoTaxCalculationOnSave); }
        }

        /// <summary>
        /// Gets the Invoiced string
        /// </summary>
        [IgnoreExportImport]
        public string InvoicedString
        {
            get { return EnumUtility.GetStringValue(Invoiced); }
        }

        /// <summary>
        /// Gets the Completed string
        /// </summary>
        [IgnoreExportImport]
        public string CompletedString
        {
            get { return EnumUtility.GetStringValue(Completed); }
        }

        /// <summary>
        /// Gets the VendorExists string
        /// </summary>
        [IgnoreExportImport]
        public string VendorExistsString
        {
            get { return EnumUtility.GetStringValue(VendorExists); }
        }

        /// <summary>
        /// Gets the RateOperation string
        /// </summary>
        [IgnoreExportImport]
        public string RateOperationString
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets the RateOverridden string
        /// </summary>
        [IgnoreExportImport]
        public string RateOverriddenString
        {
            get { return EnumUtility.GetStringValue(RateOverridden); }
        }

        /// <summary>
        /// Gets the HasRetainage string
        /// </summary>
        [IgnoreExportImport]
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets the RetainageExchangeRate string
        /// </summary>
        [IgnoreExportImport]
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Gets the TaxcalculationIspending string
        /// </summary>
        [IgnoreExportImport]
        public string TaxcalculationIspendingString
        {
            get { return EnumUtility.GetStringValue(TaxcalculationIspending); }
        }

        /// <summary>
        /// Gets the DocumentLocked string
        /// </summary>
        [IgnoreExportImport]
        public string DocumentLockedString
        {
            get { return EnumUtility.GetStringValue(DocumentLocked); }
        }

        /// <summary>
        /// Gets the IsThisVendorPrimary string
        /// </summary>
        [IgnoreExportImport]
        public string IsThisVendorPrimaryString
        {
            get { return EnumUtility.GetStringValue(IsThisVendorPrimary); }
        }

        /// <summary>
        /// Gets the ExchangeRateExists string
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeRateExistsString
        {
            get { return EnumUtility.GetStringValue(ExchangeRateExists); }
        }

        /// <summary>
        /// Gets the HasDetails string
        /// </summary>
        [IgnoreExportImport]
        public string HasDetailsString
        {
            get { return EnumUtility.GetStringValue(HasDetails); }
        }

        /// <summary>
        /// Gets the Command string
        /// </summary>
        [IgnoreExportImport]
        public string CommandString
        {
            get { return EnumUtility.GetStringValue(Command); }
        }

        /// <summary>
        /// Gets the TaxReportingRateOperatioDaten string
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOperationString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOperation); }
        }

        /// <summary>
        /// Gets the TaxReportingRateOverridden string
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOverriddenString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOverridden); }
        }

        /// <summary>
        /// Gets the StoredInDatabaseTable string
        /// </summary>
        [IgnoreExportImport]
        public string StoredInDatabaseTableString
        {
            get { return EnumUtility.GetStringValue(StoredInDatabaseTable); }
        }

        /// <summary>
        /// Gets the WarnOnRetainageTaxShift string
        /// </summary>
        [IgnoreExportImport]
        public string WarnOnRetainageTaxShiftString
        {
            get { return EnumUtility.GetStringValue(WarnOnRetainageTaxShift); }
        }

        /// <summary>
        /// Gets the TaxReportingExchRateExists string
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingExchRateExistsString
        {
            get { return EnumUtility.GetStringValue(TaxReportingExchRateExists); }
        }

        /// <summary>
        /// Gets a value indicating whether receipt vendor is stored in database.
        /// </summary>
        [IgnoreExportImport]
        public bool IsStoredInDatabaseTable
        {
            get { return StoredInDatabaseTable.Equals(StoredInDatabaseTable.Yes); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is locked invoiced.
        /// </summary>
        [IgnoreExportImport]
        public bool IsLockedInvoiced
        {
            get { return DocumentLocked.Equals(DocumentLocked.Yes) || Invoiced.Equals(Invoiced.Yes); }
        }

        /// <summary>
        /// Gets or sets the attributes
        /// </summary>
        [IgnoreExportImport]
        public IDictionary<string, object> Attributes { get; set; }

        #endregion

    }
}
