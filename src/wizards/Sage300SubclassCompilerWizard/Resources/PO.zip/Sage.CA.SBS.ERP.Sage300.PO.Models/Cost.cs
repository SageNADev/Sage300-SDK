// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Cost
     /// </summary>
     public partial class Cost : ModelBase
     {
          /// <summary>
          /// Gets or sets Sequence
          /// </summary>
          [ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Int, Size = 2)]
          public int Sequence {get; set;}

          /// <summary>
          /// Gets or sets ItemNumber
          /// </summary>
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ItemNumber {get; set;}

          /// <summary>
          /// Gets or sets Location
          /// </summary>
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string Location {get; set;}

          /// <summary>
          /// Gets or sets TaxGroup
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12)]
          public string TaxGroup {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority1
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12)]
          public string TaxAuthority1 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority2
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12)]
          public string TaxAuthority2 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority3
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12)]
          public string TaxAuthority3 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority4
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12)]
          public string TaxAuthority4 {get; set;}

          /// <summary>
          /// Gets or sets TaxAuthority5
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12)]
          public string TaxAuthority5 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClass1
          /// </summary>
          [ViewField(Name = Fields.VendorTaxClass1, Id = Index.VendorTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
          public int VendorTaxClass1 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClass2
          /// </summary>
          [ViewField(Name = Fields.VendorTaxClass2, Id = Index.VendorTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
          public int VendorTaxClass2 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClass3
          /// </summary>
          [ViewField(Name = Fields.VendorTaxClass3, Id = Index.VendorTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
          public int VendorTaxClass3 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClass4
          /// </summary>
          [ViewField(Name = Fields.VendorTaxClass4, Id = Index.VendorTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
          public int VendorTaxClass4 {get; set;}

          /// <summary>
          /// Gets or sets VendorTaxClass5
          /// </summary>
          [ViewField(Name = Fields.VendorTaxClass5, Id = Index.VendorTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
          public int VendorTaxClass5 {get; set;}

          /// <summary>
          /// Gets or sets CostTaxClass1
          /// </summary>
          [ViewField(Name = Fields.CostTaxClass1, Id = Index.CostTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
          public int CostTaxClass1 {get; set;}

          /// <summary>
          /// Gets or sets CostTaxClass2
          /// </summary>
          [ViewField(Name = Fields.CostTaxClass2, Id = Index.CostTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
          public int CostTaxClass2 {get; set;}

          /// <summary>
          /// Gets or sets CostTaxClass3
          /// </summary>
          [ViewField(Name = Fields.CostTaxClass3, Id = Index.CostTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
          public int CostTaxClass3 {get; set;}

          /// <summary>
          /// Gets or sets CostTaxClass4
          /// </summary>
          [ViewField(Name = Fields.CostTaxClass4, Id = Index.CostTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
          public int CostTaxClass4 {get; set;}

          /// <summary>
          /// Gets or sets CostTaxClass5
          /// </summary>
          [ViewField(Name = Fields.CostTaxClass5, Id = Index.CostTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
          public int CostTaxClass5 {get; set;}

          /// <summary>
          /// Gets or sets TaxIncludable1
          /// </summary>
          [ViewField(Name = Fields.TaxIncludable1, Id = Index.TaxIncludable1, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TaxIncludable1 {get; set;}

          /// <summary>
          /// Gets or sets TaxIncludable2
          /// </summary>
          [ViewField(Name = Fields.TaxIncludable2, Id = Index.TaxIncludable2, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TaxIncludable2 {get; set;}

          /// <summary>
          /// Gets or sets TaxIncludable3
          /// </summary>
          [ViewField(Name = Fields.TaxIncludable3, Id = Index.TaxIncludable3, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TaxIncludable3 {get; set;}

          /// <summary>
          /// Gets or sets TaxIncludable4
          /// </summary>
          [ViewField(Name = Fields.TaxIncludable4, Id = Index.TaxIncludable4, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TaxIncludable4 {get; set;}

          /// <summary>
          /// Gets or sets TaxIncludable5
          /// </summary>
          [ViewField(Name = Fields.TaxIncludable5, Id = Index.TaxIncludable5, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TaxIncludable5 {get; set;}

          /// <summary>
          /// Gets or sets ContractDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ContractDate, Id = Index.ContractDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime ContractDate {get; set;}

          /// <summary>
          /// Gets or sets UnitCost
          /// </summary>
          [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal UnitCost {get; set;}

          /// <summary>
          /// Gets or sets CostingunitOfmeasure
          /// </summary>
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.CostingunitOfmeasure, Id = Index.CostingunitOfmeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string CostingunitOfmeasure {get; set;}

          /// <summary>
          /// Gets or sets Currency
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
          public string Currency {get; set;}

          /// <summary>
          /// Gets or sets ExchangeRate
          /// </summary>
          [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal ExchangeRate {get; set;}

          /// <summary>
          /// Gets or sets RateOperation
          /// </summary>
          [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
          public RateOperation RateOperation {get; set;}

          /// <summary>
          /// Gets or sets Vendor
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
          public string Vendor {get; set;}

          /// <summary>
          /// Gets or sets QuantityFrom
          /// </summary>
          [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.QuantityFrom, Id = Index.QuantityFrom, FieldType = EntityFieldType.Char, Size = 20)]
          public string QuantityFrom {get; set;}

          /// <summary>
          /// Gets or sets QuantityTo
          /// </summary>
          [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.QuantityTo, Id = Index.QuantityTo, FieldType = EntityFieldType.Char, Size = 20)]
          public string QuantityTo {get; set;}

          /// <summary>
          /// Gets or sets CostType
          /// </summary>
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.CostType, Id = Index.CostType, FieldType = EntityFieldType.Char, Size = 40)]
          public string CostType {get; set;}

          #region Properties for finder

          /// <summary>
          /// Gets the RateOperation string
          /// </summary>
          public string RateOperationString
          {
              get { return EnumUtility.GetStringValue(RateOperation); }
          }

          /// <summary>
          /// Gets TaxIncludable1 String
          /// </summary>
          public string TaxIncludable1String
          {
              get
              {
                  if (TaxIncludable1 == false)
                  {
                      return EnumUtility.GetStringValue(BooleanType.False);
                  }
                  return EnumUtility.GetStringValue(BooleanType.True);
              }
          }

          /// <summary>
          /// Gets TaxIncludable2 String
          /// </summary>
          public string TaxIncludable2String
          {
              get
              {
                  if (TaxIncludable2 == false)
                  {
                      return EnumUtility.GetStringValue(BooleanType.False);
                  }
                  return EnumUtility.GetStringValue(BooleanType.True);
              }
          }

          /// <summary>
          /// Gets TaxIncludable3 String
          /// </summary>
          public string TaxIncludable3String
          {
              get
              {
                  if (TaxIncludable3 == false)
                  {
                      return EnumUtility.GetStringValue(BooleanType.False);
                  }
                  return EnumUtility.GetStringValue(BooleanType.True);
              }
          }

          /// <summary>
          /// Gets TaxIncludable4 String
          /// </summary>
          public string TaxIncludable4String
          {
              get
              {
                  if (TaxIncludable4 == false)
                  {
                      return EnumUtility.GetStringValue(BooleanType.False);
                  }
                  return EnumUtility.GetStringValue(BooleanType.True);
              }
          }

          /// <summary>
          /// Gets TaxIncludable5 String
          /// </summary>
          public string TaxIncludable5String
          {
              get
              {
                  if (TaxIncludable5 == false)
                  {
                      return EnumUtility.GetStringValue(BooleanType.False);
                  }
                  return EnumUtility.GetStringValue(BooleanType.True);
              }
          }

          #endregion

         
     }
}
