﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    public interface IVendorInformation
    {        
        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        string Vendor { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        string Name { get; set; }

        /// <summary>
        /// Gets or sets Address1
        /// </summary>
        string Address1 { get; set; }

        /// <summary>
        /// Gets or sets Address2
        /// </summary>
        string Address2 { get; set; }

        /// <summary>
        /// Gets or sets Address3
        /// </summary>
        string Address3 { get; set; }

        /// <summary>
        /// Gets or sets Address4
        /// </summary>
        string Address4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        string Country { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        string Email { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        string Contact { get; set; }

        /// <summary>
        /// Gets or sets ContactPhone
        /// </summary>
        string ContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactFax
        /// </summary>
        string ContactFax { get; set; }

        /// <summary>
        /// Gets or sets ContactEmail
        /// </summary>
        string ContactEmail { get; set; }
    }
}
