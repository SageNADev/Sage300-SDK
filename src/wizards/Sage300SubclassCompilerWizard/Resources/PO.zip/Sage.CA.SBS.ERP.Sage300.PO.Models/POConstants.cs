﻿/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    ///  Static Class for PO Module constants 
    /// </summary>
    public static class POConstants
    {
      
        #region Shipping Back Order Report

        /// <summary>
        /// The ship back order report name
        /// </summary>
        public const string ShipBackOrderReportName = "POSHPBO1";

        /// <summary>
        /// The ship back order program identifier
        /// </summary>
        public const string ShipBackOrderProgramId = "PO3250";

        /// <summary>
        /// The menu identifier
        /// </summary>
        public const string MenuId = "<MENU ID>";

        /// <summary>
        /// Constant for Application Id
        /// </summary>
        public const string POApplicationId = "PO";

        /// <summary>
        /// Constant for Yes Value
        /// </summary>
        public const string Yes = "Y";

        /// <summary>
        /// Constant for No Value
        /// </summary>
        public const string No = "N";

        /// <summary>
        /// Constant for Zero Value
        /// </summary>
        public const int Inactive = 0;

        /// <summary>
        /// Constant for One Value
        /// </summary>
        public const int Active = 1;

        /// <summary>
        /// Constant for Empty Date Value
        /// </summary>
        public const string EmptyDate = "00000000";

        /// <summary>
        /// The z
        /// </summary>
        public const char Z = 'Z';

        #endregion Shipping Back Order Report

        /// <summary>
        /// Constant for Field Value Zero
        /// </summary>
        public const string FieldValueZero = "0";

        /// <summary>
        /// Constant for Field Value One
        /// </summary>
        public const string FieldValueOne = "1";

        /// <summary>
        /// Constant for Field Length Two
        /// </summary>
        public const string FieldLengthTwo = "2";

        /// <summary>
        /// Constant for Field Length Three
        /// </summary>
        public const string FieldLengthThree = "3";

        /// <summary>
        /// Constant for Field Length Four
        /// </summary>
        public const string FieldLengthFour = "4";

        /// <summary>
        /// The gl application identifier
        /// </summary>
        public const string GlApplicationId = "GL";

        /// <summary>
        /// The oe application identifier
        /// </summary>
        public const string OeApplicationId = "OE";

        /// <summary>
        /// The pm application identifier
        /// </summary>
        public const string PmApplicationId = "PM";

        /// <summary>
        /// The optional field
        /// </summary>
        public const string OptionalField = "OB";

        /// <summary>
        /// The ic application identifier
        /// </summary>
        public const string IcApplicationId = "IC";

        /// <summary>
        /// The ic application identifier
        /// </summary>
        public const string EmptyValue = " ";

        /// <summary>
        /// The Default Currency Code Value
        /// </summary>
        public const string DefaultCurrencyValue = "ZZZ";

        /// <summary>
        /// Constant for Field Value T
        /// </summary>
        public const string FieldValueT = "T";

        /// <summary>
        /// Constant for Field Value F
        /// </summary>
        public const string FieldValueF = "F";

        /// <summary>
        /// Constant for Field Value S
        /// </summary>
        public const string FieldValueS = "S";

        /// <summary>
        /// Constant for Currency Decimal
        /// </summary>
        public const string CurrencyDecimal = "3";

		
		#region Additional Cost
        /// <summary>
        /// Expense Account
        /// </summary>
        public const string AddtionalCostLocationCode = ",LOCATION=0";
        
        /// <summary>
        /// Expense Account
        /// </summary>
        public const string ExpenseAccount = "Expense";

        /// <summary>
        /// Return Account
        /// </summary>
        public const string ReturnAccount = "Return";
        #endregion

        /// <summary>
        /// Constant for Functional Currency
        /// </summary>
        public const string FunctionalCurrency = "F";

         /// <summary>
        /// Constant for Vendor Currency
        /// </summary>
        public const string VendorCurrency = "S";

        /// <summary>
        /// Constant True
        /// </summary>
        public const string True = "true";

        /// <summary>
        /// Constant Empty Const
        /// </summary>
        public const string Empty = " ";


        /// <summary>
        /// Constant PoNumber
        /// </summary>
        public const string PoNumber = "PONUMBER";


        /// <summary>
        /// Constant VdCode
        /// </summary>
        public const string VdCode = "VDCODE";

        /// <summary>
        /// Constant Currency
        /// </summary>
        public const string Currency = "CURRENCY";

        /// <summary>
        /// Constant IsTrue
        /// </summary>
        public const bool IsTrue = true;

        #region Taxes

        /// <summary>
        /// Constant TaxGroup
        /// </summary>
        public const string TaxGroup = "TaxGroup";

        /// <summary>
        /// Constant TaxClass1
        /// </summary>
        public const string TaxClass1 = "TaxClass1";

        /// <summary>
        /// Constant TaxClass2
        /// </summary>
        public const string TaxClass2 = "TaxClass2";

        /// <summary>
        /// Constant TaxClass3
        /// </summary>
        public const string TaxClass3 = "TaxClass3";

        /// <summary>
        /// Constant TaxClass4
        /// </summary>
        public const string TaxClass4 = "TaxClass4";

        /// <summary>
        /// Constant TaxClass5
        /// </summary>
        public const string TaxClass5 = "TaxClass5";

        /// <summary>
        /// Constant TaxAmount1
        /// </summary>
        public const string TaxAmount1 = "TaxAmount1";

        /// <summary>
        /// Constant TaxAmount2
        /// </summary>
        public const string TaxAmount2 = "TaxAmount2";

        /// <summary>
        /// Constant TaxAmount3
        /// </summary>
        public const string TaxAmount3 = "TaxAmount3";

        /// <summary>
        /// Constant TaxAmount4
        /// </summary>
        public const string TaxAmount4 = "TaxAmount4";

        /// <summary>
        /// Constant TaxAmount5
        /// </summary>
        public const string TaxAmount5 = "TaxAmount5";

        /// <summary>
        /// Constant TaxReportingAmount1
        /// </summary>
        public const string TaxReportingAmount1 = "TaxReportingAmount1";

        /// <summary>
        /// Constant TaxReportingAmount2
        /// </summary>
        public const string TaxReportingAmount2 = "TaxReportingAmount2";

        /// <summary>
        /// Constant TaxReportingAmount3
        /// </summary>
        public const string TaxReportingAmount3 = "TaxReportingAmount3";

        /// <summary>
        /// Constant TaxReportingAmount4
        /// </summary>
        public const string TaxReportingAmount4 = "TaxReportingAmount4";

        /// <summary>
        /// Constant TaxReportingAmount5
        /// </summary>
        public const string TaxReportingAmount5 = "TaxReportingAmount5";

        /// <summary>
        /// Constant TaxIncluded1
        /// </summary>
        public const string TaxIncluded1 = "TaxIncluded1";

        /// <summary>
        /// Constant TaxIncluded2
        /// </summary>
        public const string TaxIncluded2 = "TaxIncluded2";

        /// <summary>
        /// Constant TaxIncluded3
        /// </summary>
        public const string TaxIncluded3 = "TaxIncluded3";

        /// <summary>
        /// Constant TaxIncluded4
        /// </summary>
        public const string TaxIncluded4 = "TaxIncluded4";

        /// <summary>
        /// Constant TaxIncluded5
        /// </summary>
        public const string TaxIncluded5 = "TaxIncluded5";

        /// <summary>
        /// Constant ReverseCharges1
        /// </summary>
        public const string ReverseCharges1 = "ReverseCharges1";
        /// <summary>
        /// Constant ReverseCharges2
        /// </summary>
        public const string ReverseCharges2 = "ReverseCharges2";
        /// <summary>
        /// Constant ReverseCharges3
        /// </summary>
        public const string ReverseCharges3 = "ReverseCharges3";
        /// <summary>
        /// Constant ReverseCharges4
        /// </summary>
        public const string ReverseCharges4 = "ReverseCharges4";
        /// <summary>
        /// Constant ReverseCharges5
        /// </summary>
        public const string ReverseCharges5 = "ReverseCharges5";

        #endregion Taxes
    }
}
