// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Vendor Contract Cost Sale Unit
     /// </summary>
     public partial class VendorContractCostSaleUnit : ModelBase
     {
          /// <summary>
          /// Gets or sets Item Number
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ItemNumber { get; set; }

          /// <summary>
          /// Gets or sets Vendor
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
          public string Vendor { get; set; }

          /// <summary>
          /// Gets or sets Unit Of Measure
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "UnitOfMeasure", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string UnitOfMeasure { get; set; }

          /// <summary>
          /// Gets or sets Conversion Factor To Stocking
          /// </summary>
          [Display(Name = "ConversionFactorToStocking", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.ConversionFactorToStocking, Id = Index.ConversionFactorToStocking, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal ConversionFactorToStocking { get; set; }

          /// <summary>
          /// Gets or sets Sale Cost Calculated Using
          /// </summary>
          [Display(Name = "SaleCostCalculatedUsing", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleCostCalculatedUsing, Id = Index.SaleCostCalculatedUsing, FieldType = EntityFieldType.Int, Size = 2)]
          public SaleCostCalculatedUsing SaleCostCalculatedUsing { get; set; }

          /// <summary>
          /// Gets or sets Discount Percent
          /// </summary>
          [Display(Name = "DiscountPercent", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountPercent, Id = Index.DiscountPercent, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal DiscountPercent { get; set; }

          /// <summary>
          /// Gets or sets Discount Amount
          /// </summary>
          [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountAmount { get; set; }

          /// <summary>
          /// Gets or sets Fixed Amount
          /// </summary>
          [Display(Name = "FixedAmount", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.FixedAmount, Id = Index.FixedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal FixedAmount { get; set; }

          /// <summary>
          /// Gets or sets Sale Start Date
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "SaleStartDate", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleStartDate, Id = Index.SaleStartDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime? SaleStartDate {get; set;}

          /// <summary>
          /// Gets or sets Sale End Date
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "SaleEndDate", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleEndDate, Id = Index.SaleEndDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime? SaleEndDate {get; set;}

          /// <summary>
          /// Gets or sets Sale Cost
          /// </summary>
          [Display(Name = "SaleCost", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleCost, Id = Index.SaleCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal SaleCost { get; set; }

          /// <summary>
          /// Gets or sets Default Unit Of Measure
          /// </summary>
          [Display(Name = "DefaultUnitOfMeasure", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DefaultUnitOfMeasure, Id = Index.DefaultUnitOfMeasure, FieldType = EntityFieldType.Bool, Size = 2)]
          public DefaultUnitOfMeasure DefaultUnitOfMeasure { get; set; }

          /// <summary>
          /// Gets or sets SerialNumber - Unique key for grid rows
          /// </summary>
          [IgnoreExportImport]
          public long SerialNumber { get; set; }

          /// <summary>
          /// Get the string value of Default Unit Of Measure
          /// </summary>
          [IgnoreExportImport]
          public string DefaultUnitOfMeasureString
          {
              get { return EnumUtility.GetStringValue(DefaultUnitOfMeasure); }
          }

          /// <summary>
          /// Get the string value of Sale Cost Calculated Using
          /// </summary>
          [IgnoreExportImport]
          public string SaleCostCalculatedUsingString
          {
              get { return EnumUtility.GetStringValue(SaleCostCalculatedUsing); }
          }

          /// <summary>
          /// Gets or sets Discount Percent Value which is used for Grid UI
          /// </summary>
          [Display(Name = "DiscountPercent", ResourceType = typeof(VendorContractCostsResx))]
          public decimal DiscountPercentValue { get; set; }

          /// <summary>
          /// Gets or sets Discount Amount Value which is used for Grid UI
          /// </summary>
          [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
          public decimal DiscountAmountValue { get; set; }

     }
}
