// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for RequisitionFunction
     /// </summary>
     public partial class RequisitionFunction : ModelBase
     {
          /// <summary>
          /// Gets or sets RequisitionSequenceKey
          /// </summary>
          [ViewField(Name = Fields.RequisitionSequenceKey, Id = Index.RequisitionSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal RequisitionSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets SequenceToRetrieve
          /// </summary>
          [ViewField(Name = Fields.SequenceToRetrieve, Id = Index.SequenceToRetrieve, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal SequenceToRetrieve {get; set;}

          /// <summary>
          /// Gets or sets Function
          /// </summary>
          [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
          public int Function {get; set;}
     }
}
