﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Tax Group Authority Class
    /// </summary>
    public class ReturnTaxGroupAuthority : ModelBase
    {
        /// <summary>
        /// Gets and Sets Line Number
        /// </summary>
        public int LineNumber { get; set; }

        /// <summary>
        /// Gets and Sets TaxAuthority
        /// </summary>
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets and Sets Tax Authority Description
        /// </summary>
        public string TaxAuthorityDescription { get; set; }

        /// <summary>
        /// Gets and Sets ItemTaxClass
        /// </summary>
        public int ItemTaxClass { get; set; }

        /// <summary>
        /// Gets and Sets Item Tax Class Decription
        /// </summary>
        public string ItemTaxClassDecription { get; set; }

        /// <summary>
        /// Gets and Sets Tax Included
        /// </summary>
        public decimal TaxIncluded { get; set; }

        /// <summary>
        /// Gets and Sets Tax Base
        /// </summary>
        public decimal TaxBase { get; set; }

        /// <summary>
        /// Gets and Sets Tax Amount
        /// </summary>
        public decimal TaxAmount { get; set; }

        /// <summary>
        /// Gets and Sets Tax Reporting Amount
        /// </summary>
        public decimal TaxReportingAmount { get; set; }

        /// <summary>
        /// Gets and Sets Retainage Tax Base
        /// </summary>
        public decimal RetainageTaxBase { get; set; }

        /// <summary>
        /// Gets and Sets Retainage Tax Amount
        /// </summary>
        public decimal RetainageTaxAmount { get; set; }

        /// <summary>
        /// Gets and Sets Tax Amount Plus Retainage Tax Amount
        /// </summary>
        public decimal TaxAmountPlusRtgTaxAmt { get; set; }

        /// <summary>
        /// Gets and Sets Tax Class
        /// </summary>
        public int TaxClass { get; set; }

        /// <summary>
        /// Tax Class Description
        /// </summary>
        public string TaxClassDescription { get; set; }

        /// <summary>
        /// Gets and Sets Total Tax Amount
        /// </summary>
        public decimal TotalTaxAmount { get; set; }

        /// <summary>
        /// Gets and Sets Tax Excluded 
        /// </summary>
        public decimal TaxExcluded { get; set; }
    }
}