// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Model class for PendingReceiptsInquiry
    /// </summary>
    public partial class PendingReceiptsInquiry : ModelBase
    {
        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderLineSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderLineSequence, Id = Index.PurchaseOrderLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderLineSequence { get; set; }

        /// <summary>
        /// Gets or sets ExpectedArrivalDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedArrivalDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExpectedArrivalDate, Id = Index.ExpectedArrivalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedArrivalDate { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderType
        /// </summary>
        [Display(Name = "POType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PurchaseOrderType, Id = Index.PurchaseOrderType, FieldType = EntityFieldType.Int, Size = 2)]
        public PurchaseOrderType PurchaseOrderType { get; set; }

        /// <summary>
        /// Gets or sets VendorName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PODate", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.PurchaseOrderDate, Id = Index.PurchaseOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PurchaseOrderDate { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [Display(Name = "QuantityOrdered", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets DateReceived
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateReceived", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.DateReceived, Id = Index.DateReceived, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateReceived { get; set; }

        /// <summary>
        /// Gets or sets IsComplete
        /// </summary>
        [Display(Name = "IncludeCompletedDetailLines", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.IsComplete, Id = Index.IsComplete, FieldType = EntityFieldType.Int, Size = 2)]
        public IsComplete IsComplete { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelated { get; set; }

        /// <summary>
        /// Gets or sets ReceiptsExist
        /// </summary>
        [ViewField(Name = Fields.ReceiptsExist, Id = Index.ReceiptsExist, FieldType = EntityFieldType.Int, Size = 2)]
        public ReceiptsExist ReceiptsExist { get; set; }

        /// <summary>
        /// Gets or sets DaysLate
        /// </summary>
        [Display(Name = "DaysLate", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.DaysLate, Id = Index.DaysLate, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysLate { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets PurchaseOrderType string value
        /// </summary>
        public string PurchaseOrderTypeString
        {
            get { return EnumUtility.GetStringValue(PurchaseOrderType); }
        }

        /// <summary>
        /// Gets IsComplete string value
        /// </summary>
        [Display(Name = "Completed", ResourceType = typeof(POCommonResx))]
        public string IsCompleteString
        {
            get { return EnumUtility.GetStringValue(IsComplete); }
        }

        /// <summary>
        /// Gets ReceiptsExist string value
        /// </summary>
        public string ReceiptsExistString
        {
            get { return EnumUtility.GetStringValue(ReceiptsExist); }
        }

        #endregion

        #region Custom Defined
        /// <summary>
        /// Show Late POs Only
        /// </summary>
        [Display(Name = "ShowLatePOsOnly", ResourceType = typeof(PendingReceiptsInquiryResx))]
        public bool ShowLatePOsOnly { get; set; }

        /// <summary>
        /// PO From Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PODate", ResourceType = typeof(PendingReceiptsInquiryResx))]
        public DateTime? PODateFrom { get; set; }

        /// <summary>
        /// PO To Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PODate", ResourceType = typeof(PendingReceiptsInquiryResx))]
        public DateTime PODateTo { get; set; }

        /// <summary>
        /// Expected Arrival From Date
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedArrivalDate", ResourceType = typeof(POCommonResx))]
        public DateTime? ExpectedArrivalDateFrom { get; set; }

        /// <summary>
        /// Expected Arrival To Date
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedArrivalDate", ResourceType = typeof(POCommonResx))]
        public DateTime ExpectedArrivalDateTo { get; set; }

        /// <summary>
        /// From Location
        /// </summary>
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        public string LocationFrom { get; set; }

        /// <summary>
        /// To Location
        /// </summary>
        public string LocationTo { get; set; }

        /// <summary>
        /// Gets or sets Select By Vendor/Item Number
        /// </summary>
        [Display(Name = "SelectBy", ResourceType = typeof(CommonResx))]
        public SelectedBy SelectBy { get; set; }

        #endregion
    }
}
