// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for CRDRNoteCostDistribution
    /// </summary>
    public partial class CrdrNoteCostDistribution : ModelBase
    {
        /// <summary>
        /// Gets or sets CreditDebitNoteSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets LineSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LineSequence, Id = Index.LineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineSequence { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets StoredInDatabaseTable
        /// </summary>
        [Display(Name = "StoredInDatabaseTable", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool StoredInDatabaseTable { get; set; }

        /// <summary>
        /// Gets or sets ManualCostDistribution
        /// </summary>
        [Display(Name = "ManualCostDistribution", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ManualCostDistribution, Id = Index.ManualCostDistribution, FieldType = EntityFieldType.Long, Size = 4)]
        public long ManualCostDistribution { get; set; }

        /// <summary>
        /// Gets or sets ExtraneousCostDistribution
        /// </summary>
        [Display(Name = "ExtraneousCostDistribution", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtraneousCostDistribution, Id = Index.ExtraneousCostDistribution, FieldType = EntityFieldType.Long, Size = 4)]
        public long ExtraneousCostDistribution { get; set; }

        /// <summary>
        /// Gets or sets CostDistribution
        /// </summary>
        [Display(Name = "CostDistribution", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CostDistribution, Id = Index.CostDistribution, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostDistribution { get; set; }

    }
}
