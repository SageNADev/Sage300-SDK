// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Return Line Lot
    /// </summary>
    public partial class ReturnLineLot : ModelBase
    {
        /// <summary>
        /// Gets or sets ReturnSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets ReturnLineSequence
        /// </summary>
        [ViewField(Name = Fields.ReturnLineSequence, Id = Index.ReturnLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnLineSequence { get; set; }

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotStockQuantity
        /// </summary>
        [ViewField(Name = Fields.LotStockQuantity, Id = Index.LotStockQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotStockQuantity { get; set; }

        /// <summary>
        /// Gets or sets Returned
        /// </summary>
        [ViewField(Name = Fields.Returned, Id = Index.Returned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal Returned { get; set; }

        /// <summary>
        /// Gets or sets ReturnedStock
        /// </summary>
        [ViewField(Name = Fields.ReturnedStock, Id = Index.ReturnedStock, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ReturnedStock { get; set; }
    }
}
