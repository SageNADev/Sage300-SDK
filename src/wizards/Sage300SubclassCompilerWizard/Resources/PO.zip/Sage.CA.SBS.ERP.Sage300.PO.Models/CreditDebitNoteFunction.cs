// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for CreditDebitNoteFunction
     /// </summary>
     public partial class CreditDebitNoteFunction : ModelBase
     {
          /// <summary>
          /// Gets or sets CreditDebitNoteSequenceKey
          /// </summary>
          [Display(Name = "CreditDebitNoteSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CreditDebitNoteSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets SequenceToRetrieve
          /// </summary>
          [Display(Name = "SequenceToRetrieve", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.SequenceToRetrieve, Id = Index.SequenceToRetrieve, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal SequenceToRetrieve {get; set;}

          /// <summary>
          /// Gets or sets Vendor
          /// </summary>
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
          public string Vendor {get; set;}

          /// <summary>
          /// Gets or sets ReturnNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ReturnNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ReturnNumber, Id = Index.ReturnNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
          public string ReturnNumber {get; set;}

          /// <summary>
          /// Gets or sets InvoiceNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "InvoiceNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
          public string InvoiceNumber {get; set;}

          /// <summary>
          /// Gets or sets PredecessorTimestamp
          /// </summary>
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "PredecessorTimestamp", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.PredecessorTimestamp, Id = Index.PredecessorTimestamp, FieldType = EntityFieldType.Char, Size = 24)]
          public string PredecessorTimestamp {get; set;}

          /// <summary>
          /// Gets or sets Function
          /// </summary>
          [Display(Name = "Function", ResourceType = typeof(CreditDebitNoteEntryResx))]
          [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
          public int Function {get; set;}

     }
}
