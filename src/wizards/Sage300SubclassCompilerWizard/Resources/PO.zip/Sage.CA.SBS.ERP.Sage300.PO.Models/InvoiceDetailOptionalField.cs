// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.InvoiceEntry;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for InvoiceDetailOptionalField
    /// </summary>
    public partial class InvoiceDetailOptionalField : BaseInvoiceOptionalField
    {
    }
}
