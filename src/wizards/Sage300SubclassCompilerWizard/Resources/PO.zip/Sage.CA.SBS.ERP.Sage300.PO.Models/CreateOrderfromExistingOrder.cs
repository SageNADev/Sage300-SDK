// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Type = Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Type;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for CreateOrderfromExistingOrder
    /// </summary>
    public partial class CreateOrderfromExistingOrder : ModelBase
    {
        /// <summary>
        /// Gets or sets FromVendorNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FromVendorNumber, Id = Index.FromVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string FromVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets ToVendorNumber
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ToVendorNumber, Id = Index.ToVendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ToVendorNumber { get; set; }

        /// <summary>
        /// Gets or sets FromPONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FromPONumber, Id = Index.FromPONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string FromPONumber { get; set; }

        /// <summary>
        /// Gets or sets ToPONumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ToPONumber, Id = Index.ToPONumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToPONumber { get; set; }

        /// <summary>
        /// Gets or sets ActionPerformed
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ActionPerformed, Id = Index.ActionPerformed, FieldType = EntityFieldType.Int, Size = 2)]
        public int ActionPerformed { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.TaxGroupCurrency, Id = Index.TaxGroupCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string TaxGroupCurrency { get; set; }

        /// <summary>
        /// Gets or sets FromVendorCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FromVendorCurrency, Id = Index.FromVendorCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FromVendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets ToVendorCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ToVendorCurrency, Id = Index.ToVendorCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string ToVendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets FromVendorName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FromVendorName, Id = Index.FromVendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string FromVendorName { get; set; }

        /// <summary>
        /// Gets or sets ToVendorName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.ToVendorName, Id = Index.ToVendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ToVendorName { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets UsePOCost
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.UsePOCost, Id = Index.UsePOCost, FieldType = EntityFieldType.Bool, Size = 2)]
        public UsePOCost UsePOCost { get; set; }

        /// <summary>
        /// Gets or sets POType
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.POType, Id = Index.POType, FieldType = EntityFieldType.Int, Size = 2)]
        public POType POType { get; set; }       
    }
}
