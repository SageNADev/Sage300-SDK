// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Additional Cost Details
    /// </summary>
    public partial class AdditionalCostDetails : ModelBase
    {
        /// <summary>
        /// Gets or sets Additional Cost
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdditionalCost", ResourceType = typeof(AdditionalCostsResx))]
        [ViewField(Name = Fields.AdditionalCost, Id = Index.AdditionalCost, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AdditionalCost { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets Tax Class
        /// </summary>
        [Display(Name = "TaxClass", ResourceType = typeof(AdditionalCostsResx))]
        [ViewField(Name = Fields.TaxClass, Id = Index.TaxClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass { get; set; }

        /// <summary>
        /// Gets or sets Tax Authority Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthorityDescription, Id = Index.TaxAuthorityDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription { get; set; }

        /// <summary>
        /// Gets or sets Tax Class Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClassDescription, Id = Index.TaxClassDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClassDescription { get; set; }

        /// <summary>
        /// Gets or sets Line
        /// </summary>
         [IgnoreExportImport]
        [ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
        public long Line { get; set; }

        /// <summary>
        /// Gets or sets Unique key for grid rows
        /// </summary>
         [IgnoreExportImport]
        public long SerialNumber { get; set; }

         /// <summary>
         /// Is Deleted
         /// </summary>
         /// <value><c>true</c> if this instance is editable; otherwise, <c>false</c>.</value>
         [IsMvcSpecific]
         [IgnoreExportImport]
         public bool IsEditable { get; set; }
    }
}
