// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Return Function
     /// </summary>
     public partial class ReturnFunction : ModelBase
     {
          /// <summary>
          /// Gets or sets ReturnSequenceKey
          /// </summary>
          [ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal ReturnSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets SequenceToRetrieve
          /// </summary>
          [ViewField(Name = Fields.SequenceToRetrieve, Id = Index.SequenceToRetrieve, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal SequenceToRetrieve {get; set;}

          /// <summary>
          /// Gets or sets ReceiptNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
          public string ReceiptNumber {get; set;}

          /// <summary>
          /// Gets or sets TemplateCode
          /// </summary>
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
          public string TemplateCode {get; set;}

          /// <summary>
          /// Gets or sets PredecessorTimestamp
          /// </summary>
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.PredecessorTimestamp, Id = Index.PredecessorTimestamp, FieldType = EntityFieldType.Char, Size = 24)]
          public string PredecessorTimestamp {get; set;}

          /// <summary>
          /// Gets or sets Function
          /// </summary>
          [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
          public int Function {get; set;}
     }
}
