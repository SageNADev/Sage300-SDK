// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespaces
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums; // For common enumerations
using Sage.CA.SBS.ERP.Sage300.PO.Resources; // For common resources
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for ICOptions
    /// </summary>
    public partial class ICOptions : ModelBase
    {
        /// <summary>
        /// Gets or sets DummyField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DummyField", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DummyField, Id = Index.DummyField, FieldType = EntityFieldType.Int, Size = 2)]
        public short DummyField { get; set; }

        /// <summary>
        /// Gets or sets ContactName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PhoneNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FaxNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets FractionalQuantities
        /// </summary>
        [Display(Name = "FractionalQuantities", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.FractionalQuantities, Id = Index.FractionalQuantities, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FractionalQuantities { get; set; }

        /// <summary>
        /// Gets or sets AllowNegativeQuantities
        /// </summary>
        [Display(Name = "AllowNegativeQuantities", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowNegativeQuantities, Id = Index.AllowNegativeQuantities, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowNegativeQuantities { get; set; }

        /// <summary>
        /// Gets or sets KeepTransactionHistory
        /// </summary>
        [Display(Name = "KeepTransactionHistory", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.KeepTransactionHistory, Id = Index.KeepTransactionHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool KeepTransactionHistory { get; set; }

        /// <summary>
        /// Gets or sets InterfaceWithJobCost
        /// </summary>
        [Display(Name = "InterfaceWithJobCost", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.InterfaceWithJobCost, Id = Index.InterfaceWithJobCost, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool InterfaceWithJobCost { get; set; }

        /// <summary>
        /// Gets or sets GLReferenceField
        /// </summary>
        [Display(Name = "GLReferenceField", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.GLReferenceField, Id = Index.GLReferenceField, FieldType = EntityFieldType.Int, Size = 2)]
        public GLReferenceField GLReferenceField { get; set; }

        /// <summary>
        /// Gets or sets GLDescriptionField
        /// </summary>
        [Display(Name = "GLDescriptionField", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.GLDescriptionField, Id = Index.GLDescriptionField, FieldType = EntityFieldType.Int, Size = 2)]
        public GLDescriptionField GLDescriptionField { get; set; }

        /// <summary>
        /// Gets or sets DefaultWeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultWeightUnitOfMeasure", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultWeightUnitOfMeasure, Id = Index.DefaultWeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string DefaultWeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets Cost1Name
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Cost1Name", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.Cost1Name, Id = Index.Cost1Name, FieldType = EntityFieldType.Char, Size = 10)]
        public string Cost1Name { get; set; }

        /// <summary>
        /// Gets or sets Cost2Name
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Cost2Name", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.Cost2Name, Id = Index.Cost2Name, FieldType = EntityFieldType.Char, Size = 10)]
        public string Cost2Name { get; set; }

        /// <summary>
        /// Gets or sets DayEndTransactionsOutstanding
        /// </summary>
        [Display(Name = "DayEndTransactionsOutstanding", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DayEndTransactionsOutstanding, Id = Index.DayEndTransactionsOutstanding, FieldType = EntityFieldType.Int, Size = 2)]
        public short DayEndTransactionsOutstanding { get; set; }

        /// <summary>
        /// Gets or sets NextTransactionNumber
        /// </summary>
        [Display(Name = "NextTransactionNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextTransactionNumber, Id = Index.NextTransactionNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextTransactionNumber { get; set; }

        /// <summary>
        /// Gets or sets NextAlternateItemSetNumber
        /// </summary>
        [Display(Name = "NextAlternateItemSetNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextAlternateItemSetNumber, Id = Index.NextAlternateItemSetNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextAlternateItemSetNumber { get; set; }

        /// <summary>
        /// Gets or sets GLTransCreatedThruDayEnd
        /// </summary>
        [Display(Name = "GLTransCreatedThruDayEnd", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.GLTransCreatedThruDayEnd, Id = Index.GLTransCreatedThruDayEnd, FieldType = EntityFieldType.Long, Size = 4)]
        public int GLTransCreatedThruDayEnd { get; set; }

        /// <summary>
        /// Gets or sets NextAdjustmentEntrySequence
        /// </summary>
        [Display(Name = "NextAdjustmentEntrySequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextAdjustmentEntrySequence, Id = Index.NextAdjustmentEntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextAdjustmentEntrySequence { get; set; }

        /// <summary>
        /// Gets or sets NextAssemblyEntrySequence
        /// </summary>
        [Display(Name = "NextAssemblyEntrySequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextAssemblyEntrySequence, Id = Index.NextAssemblyEntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextAssemblyEntrySequence { get; set; }

        /// <summary>
        /// Gets or sets NextReceiptEntrySequence
        /// </summary>
        [Display(Name = "NextReceiptEntrySequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextReceiptEntrySequence, Id = Index.NextReceiptEntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextReceiptEntrySequence { get; set; }

        /// <summary>
        /// Gets or sets NextShipmentEntrySequence
        /// </summary>
        [Display(Name = "NextShipmentEntrySequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextShipmentEntrySequence, Id = Index.NextShipmentEntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextShipmentEntrySequence { get; set; }

        /// <summary>
        /// Gets or sets NextTransferEntrySequence
        /// </summary>
        [Display(Name = "NextTransferEntrySequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextTransferEntrySequence, Id = Index.NextTransferEntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextTransferEntrySequence { get; set; }

        /// <summary>
        /// Gets or sets NextHistoryEntrySequence
        /// </summary>
        [Display(Name = "NextHistoryEntrySequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextHistoryEntrySequence, Id = Index.NextHistoryEntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextHistoryEntrySequence { get; set; }

        /// <summary>
        /// Gets or sets NextDayEndPostingSequence
        /// </summary>
        [Display(Name = "NextDayEndPostingSequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextDayEndPostingSequence, Id = Index.NextDayEndPostingSequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextDayEndPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets DeferredGLPosting
        /// </summary>
        [Display(Name = "DeferredGLPosting", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DeferredGLPosting, Id = Index.DeferredGLPosting, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DeferredGLPosting { get; set; }

        /// <summary>
        /// Gets or sets AppendToGLBatch
        /// </summary>
        [Display(Name = "AppendToGLBatch", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AppendToGLBatch, Id = Index.AppendToGLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public AppendToGLBatch AppendToGLBatch { get; set; }

        /// <summary>
        /// Gets or sets ConsolidateGLBatch
        /// </summary>
        [Display(Name = "ConsolidateGLBatch", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ConsolidateGLBatch, Id = Index.ConsolidateGLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidateGLBatch ConsolidateGLBatch { get; set; }

        /// <summary>
        /// Gets or sets StatisticsCalendar
        /// </summary>
        [Display(Name = "StatisticsCalendar", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.StatisticsCalendar, Id = Index.StatisticsCalendar, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsCalendar StatisticsCalendar { get; set; }

        /// <summary>
        /// Gets or sets StatisticsPeriod
        /// </summary>
        [Display(Name = "StatisticsPeriod", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.StatisticsPeriod, Id = Index.StatisticsPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriod StatisticsPeriod { get; set; }

        /// <summary>
        /// Gets or sets EditStatistics
        /// </summary>
        [Display(Name = "EditStatistics", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.EditStatistics, Id = Index.EditStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EditStatistics { get; set; }

        /// <summary>
        /// Gets or sets AllowItemsAtAllLocations
        /// </summary>
        [Display(Name = "AllowItemsAtAllLocations", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowItemsAtAllLocations, Id = Index.AllowItemsAtAllLocations, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowItemsAtAllLocations { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostOnReceiptReturns
        /// </summary>
        [Display(Name = "AdditionalCostOnReceiptReturns", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AdditionalCostOnReceiptReturns, Id = Index.AdditionalCostOnReceiptReturns, FieldType = EntityFieldType.Int, Size = 2)]
        public AdditionalCostOnReceiptReturns AdditionalCostOnReceiptReturns { get; set; }

        /// <summary>
        /// Gets or sets DefaultRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultRateType", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultRateType, Id = Index.DefaultRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string DefaultRateType { get; set; }

        /// <summary>
        /// Gets or sets DefaultItemStructure
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultItemStructure", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultItemStructure, Id = Index.DefaultItemStructure, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string DefaultItemStructure { get; set; }

        /// <summary>
        /// Gets or sets AccumulateItemStatistics
        /// </summary>
        [Display(Name = "AccumulateItemStatistics", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AccumulateItemStatistics, Id = Index.AccumulateItemStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AccumulateItemStatistics { get; set; }

        /// <summary>
        /// Gets or sets PostToClosedFiscalPeriods
        /// </summary>
        [Display(Name = "PostToClosedFiscalPeriods", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.PostToClosedFiscalPeriods, Id = Index.PostToClosedFiscalPeriods, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostToClosedFiscalPeriods { get; set; }

        /// <summary>
        /// Gets or sets PeriodType
        /// </summary>
        [Display(Name = "PeriodType", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.PeriodType, Id = Index.PeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public PeriodType PeriodType { get; set; }

        /// <summary>
        /// Gets or sets PeriodLength
        /// </summary>
        [Display(Name = "PeriodLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.PeriodLength, Id = Index.PeriodLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short PeriodLength { get; set; }

        /// <summary>
        /// Gets or sets FractionalQuantityDecimals
        /// </summary>
        [Display(Name = "FractionalQuantityDecimals", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.FractionalQuantityDecimals, Id = Index.FractionalQuantityDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public short FractionalQuantityDecimals { get; set; }

        /// <summary>
        /// Gets or sets ConversionFactorDecimals
        /// </summary>
        [Display(Name = "ConversionFactorDecimals", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ConversionFactorDecimals, Id = Index.ConversionFactorDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public short ConversionFactorDecimals { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriods
        /// </summary>
        [Display(Name = "StatisticalPeriods", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.StatisticalPeriods, Id = Index.StatisticalPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public short StatisticalPeriods { get; set; }

        /// <summary>
        /// Gets or sets UseHyhenAsItemSeparator
        /// </summary>
        [Display(Name = "UseHyhenAsItemSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseHyhenAsItemSeparator, Id = Index.UseHyhenAsItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseHyhenAsItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UseForwardSlashAsItemSepara
        /// </summary>
        [Display(Name = "UseForwardSlashAsItemSepara", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseForwardSlashAsItemSepara, Id = Index.UseForwardSlashAsItemSepara, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseForwardSlashAsItemSepara { get; set; }

        /// <summary>
        /// Gets or sets UseBackSlashAsItemSeparator
        /// </summary>
        [Display(Name = "UseBackSlashAsItemSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseBackSlashAsItemSeparator, Id = Index.UseBackSlashAsItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseBackSlashAsItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UseAsteriskAsItemSeparator
        /// </summary>
        [Display(Name = "UseAsteriskAsItemSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseAsteriskAsItemSeparator, Id = Index.UseAsteriskAsItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseAsteriskAsItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UsePeriodAsItemSeparator
        /// </summary>
        [Display(Name = "UsePeriodAsItemSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UsePeriodAsItemSeparator, Id = Index.UsePeriodAsItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UsePeriodAsItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets UseLeftParenthesisAsItemSep
        /// </summary>
        [Display(Name = "UseLeftParenthesisAsItemSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseLeftParenthesisAsItemSep, Id = Index.UseLeftParenthesisAsItemSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseLeftParenthesisAsItemSep { get; set; }

        /// <summary>
        /// Gets or sets UseRightParenthesisAsItemSe
        /// </summary>
        [Display(Name = "UseRightParenthesisAsItemSe", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseRightParenthesisAsItemSe, Id = Index.UseRightParenthesisAsItemSe, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseRightParenthesisAsItemSe { get; set; }

        /// <summary>
        /// Gets or sets UsePoundSignAsItemSeparator
        /// </summary>
        [Display(Name = "UsePoundSignAsItemSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UsePoundSignAsItemSeparator, Id = Index.UsePoundSignAsItemSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UsePoundSignAsItemSeparator { get; set; }

        /// <summary>
        /// Gets or sets AllowReceiptOfNonStockItems
        /// </summary>
        [Display(Name = "AllowReceiptOfNonStockItems", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowReceiptOfNonStockItems, Id = Index.AllowReceiptOfNonStockItems, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowReceiptOfNonStockItems { get; set; }

        /// <summary>
        /// Gets or sets PromptToDeleteDuringPosting
        /// </summary>
        [Display(Name = "PromptToDeleteDuringPosting", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.PromptToDeleteDuringPosting, Id = Index.PromptToDeleteDuringPosting, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PromptToDeleteDuringPosting { get; set; }

        /// <summary>
        /// Gets or sets CostDuring
        /// </summary>
        [Display(Name = "CostDuring", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.CostDuring, Id = Index.CostDuring, FieldType = EntityFieldType.Int, Size = 2)]
        public CostDuring CostDuring { get; set; }

        /// <summary>
        /// Gets or sets AssemblyNumberLength
        /// </summary>
        [Display(Name = "AssemblyNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AssemblyNumberLength, Id = Index.AssemblyNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short AssemblyNumberLength { get; set; }

        /// <summary>
        /// Gets or sets AssemblyNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AssemblyNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AssemblyNumberPrefix, Id = Index.AssemblyNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string AssemblyNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextAssemblyNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextAssemblyNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextAssemblyNumberDescription, Id = Index.NextAssemblyNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextAssemblyNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets DisassemblyNumberLength
        /// </summary>
        [Display(Name = "DisassemblyNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DisassemblyNumberLength, Id = Index.DisassemblyNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short DisassemblyNumberLength { get; set; }

        /// <summary>
        /// Gets or sets DisassemblyNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DisassemblyNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DisassemblyNumberPrefix, Id = Index.DisassemblyNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string DisassemblyNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextDisassemblyNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextDisassemblyNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextDisassemblyNumberDescription, Id = Index.NextDisassemblyNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextDisassemblyNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets TransferNumberLength
        /// </summary>
        [Display(Name = "TransferNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.TransferNumberLength, Id = Index.TransferNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short TransferNumberLength { get; set; }

        /// <summary>
        /// Gets or sets TransferNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransferNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.TransferNumberPrefix, Id = Index.TransferNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string TransferNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextTransferNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextTransferNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextTransferNumberDescription, Id = Index.NextTransferNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextTransferNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumberLength
        /// </summary>
        [Display(Name = "AdjustmentNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AdjustmentNumberLength, Id = Index.AdjustmentNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short AdjustmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets AdjustmentNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdjustmentNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AdjustmentNumberPrefix, Id = Index.AdjustmentNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string AdjustmentNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextAdjustmentNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextAdjustmentNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextAdjustmentNumberDescription, Id = Index.NextAdjustmentNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextAdjustmentNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumberLength
        /// </summary>
        [Display(Name = "ShipmentNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ShipmentNumberLength, Id = Index.ShipmentNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short ShipmentNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ShipmentNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ShipmentNumberPrefix, Id = Index.ShipmentNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipmentNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextShipmentNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextShipmentNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextShipmentNumberDescription, Id = Index.NextShipmentNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextShipmentNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipmentReturnNumberLength
        /// </summary>
        [Display(Name = "ShipmentReturnNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ShipmentReturnNumberLength, Id = Index.ShipmentReturnNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short ShipmentReturnNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ShipmentReturnNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipmentReturnNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ShipmentReturnNumberPrefix, Id = Index.ShipmentReturnNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ShipmentReturnNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextShipmentReturnNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextShipmentReturnNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextShipmentReturnNumberDescription, Id = Index.NextShipmentReturnNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextShipmentReturnNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumberLength
        /// </summary>
        [Display(Name = "ReceiptNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ReceiptNumberLength, Id = Index.ReceiptNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short ReceiptNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ReceiptNumberPrefix, Id = Index.ReceiptNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReceiptNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextReceiptNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextReceiptNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextReceiptNumberDescription, Id = Index.NextReceiptNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextReceiptNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets TransitReceiptNumberLength
        /// </summary>
        [Display(Name = "TransitReceiptNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.TransitReceiptNumberLength, Id = Index.TransitReceiptNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short TransitReceiptNumberLength { get; set; }

        /// <summary>
        /// Gets or sets TransitReceiptNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransitReceiptNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.TransitReceiptNumberPrefix, Id = Index.TransitReceiptNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string TransitReceiptNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextTransitReceiptNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextTransitReceiptNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextTransitReceiptNumberDescription, Id = Index.NextTransitReceiptNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextTransitReceiptNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets NextNonCostedReceiptDayEnd
        /// </summary>
        [Display(Name = "NextNonCostedReceiptDayEnd", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextNonCostedReceiptDayEnd, Id = Index.NextNonCostedReceiptDayEnd, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextNonCostedReceiptDayEnd { get; set; }

        /// <summary>
        /// Gets or sets SeparatorHyhen
        /// </summary>
        [Display(Name = "SeparatorHyhen", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorHyhen, Id = Index.SeparatorHyhen, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorHyhen SeparatorHyhen { get; set; }

        /// <summary>
        /// Gets or sets SeparatorForwardSlash
        /// </summary>
        [Display(Name = "SeparatorForwardSlash", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorForwardSlash, Id = Index.SeparatorForwardSlash, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorForwardSlash SeparatorForwardSlash { get; set; }

        /// <summary>
        /// Gets or sets SeparatorBackSlash
        /// </summary>
        [Display(Name = "SeparatorBackSlash", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorBackSlash, Id = Index.SeparatorBackSlash, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorBackSlash SeparatorBackSlash { get; set; }

        /// <summary>
        /// Gets or sets SeparatorAsterisk
        /// </summary>
        [Display(Name = "SeparatorAsterisk", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorAsterisk, Id = Index.SeparatorAsterisk, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorAsterisk SeparatorAsterisk { get; set; }

        /// <summary>
        /// Gets or sets SeparatorPeriod
        /// </summary>
        [Display(Name = "SeparatorPeriod", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorPeriod, Id = Index.SeparatorPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorPeriod SeparatorPeriod { get; set; }

        /// <summary>
        /// Gets or sets SeparatorLeftParenthesis
        /// </summary>
        [Display(Name = "SeparatorLeftParenthesis", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorLeftParenthesis, Id = Index.SeparatorLeftParenthesis, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorLeftParenthesis SeparatorLeftParenthesis { get; set; }

        /// <summary>
        /// Gets or sets SeparatorRightParenthesis
        /// </summary>
        [Display(Name = "SeparatorRightParenthesis", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorRightParenthesis, Id = Index.SeparatorRightParenthesis, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorRightParenthesis SeparatorRightParenthesis { get; set; }

        /// <summary>
        /// Gets or sets SeparatorNumberSign
        /// </summary>
        [Display(Name = "SeparatorNumberSign", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorNumberSign, Id = Index.SeparatorNumberSign, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorNumberSign SeparatorNumberSign { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "HomeCurrency", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.HomeCurrency, Id = Index.HomeCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets DefaultAssemblyNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultAssemblyNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultAssemblyNumber, Id = Index.DefaultAssemblyNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultAssemblyNumber { get; set; }

        /// <summary>
        /// Gets or sets NextAssemblyNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextAssemblyNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextAssemblyNumber, Id = Index.NextAssemblyNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextAssemblyNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultDisassemblyNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultDisassemblyNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultDisassemblyNumber, Id = Index.DefaultDisassemblyNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultDisassemblyNumber { get; set; }

        /// <summary>
        /// Gets or sets NextDisassemblyNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextDisassemblyNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextDisassemblyNumber, Id = Index.NextDisassemblyNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextDisassemblyNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultTransferNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTransferNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultTransferNumber, Id = Index.DefaultTransferNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets NextTransferNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextTransferNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextTransferNumber, Id = Index.NextTransferNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultAdjustmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultAdjustmentNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultAdjustmentNumber, Id = Index.DefaultAdjustmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultAdjustmentNumber { get; set; }

        /// <summary>
        /// Gets or sets NextAdjustmentValue
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextAdjustmentValue", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextAdjustmentValue, Id = Index.NextAdjustmentNumber)]
        public string NextAdjustmentValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultShipmentNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultShipmentNumber, Id = Index.DefaultShipmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets NextShipmentNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextShipmentNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextShipmentNumber, Id = Index.NextShipmentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextShipmentNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultShipmentReturnNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultShipmentReturnNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultShipmentReturnNumber, Id = Index.DefaultShipmentReturnNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultShipmentReturnNumber { get; set; }

        /// <summary>
        /// Gets or sets NextShipmentReturnNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextShipmentReturnNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextShipmentReturnNumber, Id = Index.NextShipmentReturnNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextShipmentReturnNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultReceiptNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultReceiptNumber, Id = Index.DefaultReceiptNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets NextReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextReceiptNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextReceiptNumber, Id = Index.NextReceiptNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultTransitReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTransitReceiptNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultTransitReceiptNumber, Id = Index.DefaultTransitReceiptNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultTransitReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets NextTransitReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextTransitReceiptNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextTransitReceiptNumber, Id = Index.NextTransitReceiptNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextTransitReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultGoodsInTransitLocatio
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultGoodsInTransitLocatio", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultGoodsInTransitLocatio, Id = Index.DefaultGoodsInTransitLocatio, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultGoodsInTransitLocatio { get; set; }

        /// <summary>
        /// Gets or sets TransitLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransitLocationDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.TransitLocationDescription, Id = Index.TransitLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransitLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets OnlyUseDefinedUOM
        /// </summary>
        [Display(Name = "OnlyUseDefinedUOM", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.OnlyUseDefinedUOM, Id = Index.OnlyUseDefinedUOM, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OnlyUseDefinedUOM { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod1
        /// </summary>
        [Display(Name = "AgingPeriod1", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod2
        /// </summary>
        [Display(Name = "AgingPeriod2", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod3
        /// </summary>
        [Display(Name = "AgingPeriod3", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal AgingPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets CreateSubledgerAuditDuring
        /// </summary>
        [Display(Name = "CreateSubledgerAuditDuring", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.CreateSubledgerAuditDuring, Id = Index.CreateSubledgerAuditDuring, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateSubledgerAuditDuring CreateSubledgerAuditDuring { get; set; }

        /// <summary>
        /// Gets or sets NextInternalUsageEntrySequence
        /// </summary>
        [Display(Name = "NextInternalUsageEntrySequence", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextInternalUsageEntrySequence, Id = Index.NextInternalUsageEntrySequence, FieldType = EntityFieldType.Long, Size = 4)]
        public int NextInternalUsageEntrySequence { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageNumberLength
        /// </summary>
        [Display(Name = "InternalUsageNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.InternalUsageNumberLength, Id = Index.InternalUsageNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short InternalUsageNumberLength { get; set; }

        /// <summary>
        /// Gets or sets InternalUsageNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InternalUsageNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.InternalUsageNumberPrefix, Id = Index.InternalUsageNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string InternalUsageNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextInternalUsageNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextInternalUsageNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextInternalUsageNumberDescription, Id = Index.NextInternalUsageNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%22D")]
        public string NextInternalUsageNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultInternalUsageNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultInternalUsageNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultInternalUsageNumber, Id = Index.DefaultInternalUsageNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultInternalUsageNumber { get; set; }

        /// <summary>
        /// Gets or sets NextInternalUsageNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextInternalUsageNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextInternalUsageNumber, Id = Index.NextInternalUsageNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextInternalUsageNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionPostDepCost
        /// </summary>
        [Display(Name = "TransactionPostDepCost", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.TransactionPostDepCost, Id = Index.TransactionPostDepCost, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionPostDepCost TransactionPostDepCost { get; set; }

        /// <summary>
        /// Gets or sets ICReceipts
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICReceipts", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICReceipts, Id = Index.ICReceipts, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICReceipts { get; set; }

        /// <summary>
        /// Gets or sets ICReceiptReturns
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICReceiptReturns", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICReceiptReturns, Id = Index.ICReceiptReturns, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICReceiptReturns { get; set; }

        /// <summary>
        /// Gets or sets ICReceiptAdjustments
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICReceiptAdjustments", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICReceiptAdjustments, Id = Index.ICReceiptAdjustments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICReceiptAdjustments { get; set; }

        /// <summary>
        /// Gets or sets ICShipments
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICShipments", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICShipments, Id = Index.ICShipments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICShipments { get; set; }

        /// <summary>
        /// Gets or sets ICShipmentReturns
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICShipmentReturns", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICShipmentReturns, Id = Index.ICShipmentReturns, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICShipmentReturns { get; set; }

        /// <summary>
        /// Gets or sets ICTransfers
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICTransfers", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICTransfers, Id = Index.ICTransfers, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICTransfers { get; set; }

        /// <summary>
        /// Gets or sets ICAssemblies
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICAssemblies", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICAssemblies, Id = Index.ICAssemblies, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICAssemblies { get; set; }

        /// <summary>
        /// Gets or sets ICAdjustments
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICAdjustments", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICAdjustments, Id = Index.ICAdjustments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICAdjustments { get; set; }

        /// <summary>
        /// Gets or sets ICConsolidatedEntry
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICConsolidatedEntry", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICConsolidatedEntry, Id = Index.ICConsolidatedEntry, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICConsolidatedEntry { get; set; }

        /// <summary>
        /// Gets or sets ICDisassemblies
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICDisassemblies", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICDisassemblies, Id = Index.ICDisassemblies, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICDisassemblies { get; set; }

        /// <summary>
        /// Gets or sets ICInternalUsage
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ICInternalUsage", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ICInternalUsage, Id = Index.ICInternalUsage, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ICInternalUsage { get; set; }

        /// <summary>
        /// Gets or sets DefaultPostingDate
        /// </summary>
        [Display(Name = "DefaultPostingDate", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; }

        /// <summary>
        /// Gets or sets SerialNumberMask
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialNumberMask", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialNumberMask, Id = Index.SerialNumberMask, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string SerialNumberMask { get; set; }

        /// <summary>
        /// Gets or sets UseSerialsDaysToExpire
        /// </summary>
        [Display(Name = "UseSerialsDaysToExpire", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseSerialsDaysToExpire, Id = Index.UseSerialsDaysToExpire, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseSerialsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets SerialsDaysToExpire
        /// </summary>
        [Display(Name = "SerialsDaysToExpire", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsDaysToExpire, Id = Index.SerialsDaysToExpire, FieldType = EntityFieldType.Int, Size = 2)]
        public short SerialsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets AllowDifferentSerialQty
        /// </summary>
        [Display(Name = "AllowDifferentSerialQty", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowDifferentSerialQty, Id = Index.AllowDifferentSerialQty, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowDifferentSerialQty { get; set; }

        /// <summary>
        /// Gets or sets AllowSerialAllocOnQtyOrdered
        /// </summary>
        [Display(Name = "AllowSerialAllocOnQtyOrdered", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowSerialAllocOnQtyOrdered, Id = Index.AllowSerialAllocOnQtyOrdered, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowSerialAllocOnQtyOrdered { get; set; }

        /// <summary>
        /// Gets or sets SortSerialsBy
        /// </summary>
        [Display(Name = "SortSerialsBy", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SortSerialsBy, Id = Index.SortSerialsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SortSerialsBy SortSerialsBy { get; set; }

        /// <summary>
        /// Gets or sets SortSerialsFirstBy
        /// </summary>
        [Display(Name = "SortSerialsFirstBy", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SortSerialsFirstBy, Id = Index.SortSerialsFirstBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SortSerialsFirstBy SortSerialsFirstBy { get; set; }

        /// <summary>
        /// Gets or sets StopAllocationOfExpiredSeria
        /// </summary>
        [Display(Name = "StopAllocationOfExpiredSeria", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.StopAllocationOfExpiredSeria, Id = Index.StopAllocationOfExpiredSeria, FieldType = EntityFieldType.Int, Size = 2)]
        public StopAllocationOfExpiredSeria StopAllocationOfExpiredSeria { get; set; }

        /// <summary>
        /// Gets or sets SerialsHyphenAsSeparator
        /// </summary>
        [Display(Name = "SerialsHyphenAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsHyphenAsSeparator, Id = Index.SerialsHyphenAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsHyphenAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsFwdSlashAsSeparator
        /// </summary>
        [Display(Name = "SerialsFwdSlashAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsFwdSlashAsSeparator, Id = Index.SerialsFwdSlashAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsFwdSlashAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsBackSlashAsSeparator
        /// </summary>
        [Display(Name = "SerialsBackSlashAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsBackSlashAsSeparator, Id = Index.SerialsBackSlashAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsBackSlashAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsAsteriskAsSeparator
        /// </summary>
        [Display(Name = "SerialsAsteriskAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsAsteriskAsSeparator, Id = Index.SerialsAsteriskAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsAsteriskAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsPeriodAsSeparator
        /// </summary>
        [Display(Name = "SerialsPeriodAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsPeriodAsSeparator, Id = Index.SerialsPeriodAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsPeriodAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsLeftParenthesisAsSep
        /// </summary>
        [Display(Name = "SerialsLeftParenthesisAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsLeftParenthesisAsSep, Id = Index.SerialsLeftParenthesisAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsLeftParenthesisAsSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsRightParenthesisAsSep
        /// </summary>
        [Display(Name = "SerialsRightParenthesisAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsRightParenthesisAsSep, Id = Index.SerialsRightParenthesisAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsRightParenthesisAsSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsPoundSignAsSeparator
        /// </summary>
        [Display(Name = "SerialsPoundSignAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsPoundSignAsSeparator, Id = Index.SerialsPoundSignAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsPoundSignAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets SerialsLeftBracketAsSep
        /// </summary>
        [Display(Name = "SerialsLeftBracketAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsLeftBracketAsSep, Id = Index.SerialsLeftBracketAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsLeftBracketAsSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsRightBracketAsSep
        /// </summary>
        [Display(Name = "SerialsRightBracketAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsRightBracketAsSep, Id = Index.SerialsRightBracketAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsRightBracketAsSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsLeftBraceAsSep
        /// </summary>
        [Display(Name = "SerialsLeftBraceAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsLeftBraceAsSep, Id = Index.SerialsLeftBraceAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsLeftBraceAsSep { get; set; }

        /// <summary>
        /// Gets or sets SerialsRightBraceAsSep
        /// </summary>
        [Display(Name = "SerialsRightBraceAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SerialsRightBraceAsSep, Id = Index.SerialsRightBraceAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool SerialsRightBraceAsSep { get; set; }

        /// <summary>
        /// Gets or sets LotNumberMask
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LotNumberMask", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotNumberMask, Id = Index.LotNumberMask, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string LotNumberMask { get; set; }

        /// <summary>
        /// Gets or sets UseLotsDaysToExpire
        /// </summary>
        [Display(Name = "UseLotsDaysToExpire", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseLotsDaysToExpire, Id = Index.UseLotsDaysToExpire, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseLotsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets LotsDaysToExpire
        /// </summary>
        [Display(Name = "LotsDaysToExpire", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsDaysToExpire, Id = Index.LotsDaysToExpire, FieldType = EntityFieldType.Int, Size = 2)]
        public short LotsDaysToExpire { get; set; }

        /// <summary>
        /// Gets or sets UseLotsDaysOnQuarantine
        /// </summary>
        [Display(Name = "UseLotsDaysOnQuarantine", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UseLotsDaysOnQuarantine, Id = Index.UseLotsDaysOnQuarantine, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool UseLotsDaysOnQuarantine { get; set; }

        /// <summary>
        /// Gets or sets LotsDaysOnQuarantine
        /// </summary>
        [Display(Name = "LotsDaysOnQuarantine", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsDaysOnQuarantine, Id = Index.LotsDaysOnQuarantine, FieldType = EntityFieldType.Int, Size = 2)]
        public short LotsDaysOnQuarantine { get; set; }

        /// <summary>
        /// Gets or sets AllowDifferentLotQty
        /// </summary>
        [Display(Name = "AllowDifferentLotQty", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowDifferentLotQty, Id = Index.AllowDifferentLotQty, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowDifferentLotQty { get; set; }

        /// <summary>
        /// Gets or sets AllowLotAllocOnQtyOrdered
        /// </summary>
        [Display(Name = "AllowLotAllocOnQtyOrdered", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowLotAllocOnQtyOrdered, Id = Index.AllowLotAllocOnQtyOrdered, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowLotAllocOnQtyOrdered { get; set; }

        /// <summary>
        /// Gets or sets SortLotsBy
        /// </summary>
        [Display(Name = "SortLotsBy", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SortLotsBy, Id = Index.SortLotsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SortLotsBy SortLotsBy { get; set; }

        /// <summary>
        /// Gets or sets SortLotsFirstBy
        /// </summary>
        [Display(Name = "SortLotsFirstBy", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SortLotsFirstBy, Id = Index.SortLotsFirstBy, FieldType = EntityFieldType.Int, Size = 2)]
        public SortLotsFirstBy SortLotsFirstBy { get; set; }

        /// <summary>
        /// Gets or sets StopAllocationOfExpiredLots
        /// </summary>
        [Display(Name = "StopAllocationOfExpiredLots", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.StopAllocationOfExpiredLots, Id = Index.StopAllocationOfExpiredLots, FieldType = EntityFieldType.Int, Size = 2)]
        public StopAllocationOfExpiredLots StopAllocationOfExpiredLots { get; set; }

        /// <summary>
        /// Gets or sets LotsHyphenAsSeparator
        /// </summary>
        [Display(Name = "LotsHyphenAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsHyphenAsSeparator, Id = Index.LotsHyphenAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsHyphenAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsFwdSlashAsSeparator
        /// </summary>
        [Display(Name = "LotsFwdSlashAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsFwdSlashAsSeparator, Id = Index.LotsFwdSlashAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsFwdSlashAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsBackSlashAsSeparator
        /// </summary>
        [Display(Name = "LotsBackSlashAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsBackSlashAsSeparator, Id = Index.LotsBackSlashAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsBackSlashAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsAsteriskAsSeparator
        /// </summary>
        [Display(Name = "LotsAsteriskAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsAsteriskAsSeparator, Id = Index.LotsAsteriskAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsAsteriskAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsPeriodAsSeparator
        /// </summary>
        [Display(Name = "LotsPeriodAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsPeriodAsSeparator, Id = Index.LotsPeriodAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsPeriodAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsLeftParenthesisAsSep
        /// </summary>
        [Display(Name = "LotsLeftParenthesisAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsLeftParenthesisAsSep, Id = Index.LotsLeftParenthesisAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsLeftParenthesisAsSep { get; set; }

        /// <summary>
        /// Gets or sets LotsRightParenthesisAsSep
        /// </summary>
        [Display(Name = "LotsRightParenthesisAsSep", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsRightParenthesisAsSep, Id = Index.LotsRightParenthesisAsSep, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsRightParenthesisAsSep { get; set; }

        /// <summary>
        /// Gets or sets LotsPoundSignAsSeparator
        /// </summary>
        [Display(Name = "LotsPoundSignAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsPoundSignAsSeparator, Id = Index.LotsPoundSignAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsPoundSignAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsLeftBracketAsSeparator
        /// </summary>
        [Display(Name = "LotsLeftBracketAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsLeftBracketAsSeparator, Id = Index.LotsLeftBracketAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsLeftBracketAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsRightBracketAsSeparator
        /// </summary>
        [Display(Name = "LotsRightBracketAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsRightBracketAsSeparator, Id = Index.LotsRightBracketAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsRightBracketAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsLeftBraceAsSeparator
        /// </summary>
        [Display(Name = "LotsLeftBraceAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsLeftBraceAsSeparator, Id = Index.LotsLeftBraceAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsLeftBraceAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets LotsRightBraceAsSeparator
        /// </summary>
        [Display(Name = "LotsRightBraceAsSeparator", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LotsRightBraceAsSeparator, Id = Index.LotsRightBraceAsSeparator, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool LotsRightBraceAsSeparator { get; set; }

        /// <summary>
        /// Gets or sets RecallReleaseSequenceNumber
        /// </summary>
        [Display(Name = "RecallReleaseSequenceNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.RecallReleaseSequenceNumber, Id = Index.RecallReleaseSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RecallReleaseSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets RecallNumberLength
        /// </summary>
        [Display(Name = "RecallNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.RecallNumberLength, Id = Index.RecallNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short RecallNumberLength { get; set; }

        /// <summary>
        /// Gets or sets RecallNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RecallNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.RecallNumberPrefix, Id = Index.RecallNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RecallNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextRecallNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextRecallNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextRecallNumberDescription, Id = Index.NextRecallNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextRecallNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultRecallNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultRecallNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultRecallNumber, Id = Index.DefaultRecallNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultRecallNumber { get; set; }

        /// <summary>
        /// Gets or sets NextRecallNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextRecallNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextRecallNumber, Id = Index.NextRecallNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextRecallNumber { get; set; }

        /// <summary>
        /// Gets or sets ReleaseNumberLength
        /// </summary>
        [Display(Name = "ReleaseNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ReleaseNumberLength, Id = Index.ReleaseNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short ReleaseNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ReleaseNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReleaseNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ReleaseNumberPrefix, Id = Index.ReleaseNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReleaseNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextReleaseNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextReleaseNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextReleaseNumberDescription, Id = Index.NextReleaseNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextReleaseNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultReleaseNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultReleaseNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultReleaseNumber, Id = Index.DefaultReleaseNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReleaseNumber { get; set; }

        /// <summary>
        /// Gets or sets NextReleaseNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextReleaseNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextReleaseNumber, Id = Index.NextReleaseNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextReleaseNumber { get; set; }

        /// <summary>
        /// Gets or sets CombineSplitSequenceNumber
        /// </summary>
        [Display(Name = "CombineSplitSequenceNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.CombineSplitSequenceNumber, Id = Index.CombineSplitSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CombineSplitSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets CombineNumberLength
        /// </summary>
        [Display(Name = "CombineNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.CombineNumberLength, Id = Index.CombineNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short CombineNumberLength { get; set; }

        /// <summary>
        /// Gets or sets CombineNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CombineNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.CombineNumberPrefix, Id = Index.CombineNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CombineNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextCombineNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextCombineNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextCombineNumberDescription, Id = Index.NextCombineNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextCombineNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultCombineNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultCombineNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultCombineNumber, Id = Index.DefaultCombineNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultCombineNumber { get; set; }

        /// <summary>
        /// Gets or sets NextCombineNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextCombineNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextCombineNumber, Id = Index.NextCombineNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextCombineNumber { get; set; }

        /// <summary>
        /// Gets or sets SplitNumberLength
        /// </summary>
        [Display(Name = "SplitNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SplitNumberLength, Id = Index.SplitNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short SplitNumberLength { get; set; }

        /// <summary>
        /// Gets or sets SplitNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SplitNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SplitNumberPrefix, Id = Index.SplitNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string SplitNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextSplitNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextSplitNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextSplitNumberDescription, Id = Index.NextSplitNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextSplitNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultSplitNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultSplitNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultSplitNumber, Id = Index.DefaultSplitNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultSplitNumber { get; set; }

        /// <summary>
        /// Gets or sets NextSplitNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextSplitNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextSplitNumber, Id = Index.NextSplitNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextSplitNumber { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationSequenceNumber
        /// </summary>
        [Display(Name = "ReconciliationSequenceNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ReconciliationSequenceNumber, Id = Index.ReconciliationSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReconciliationSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationNumberLength
        /// </summary>
        [Display(Name = "ReconciliationNumberLength", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ReconciliationNumberLength, Id = Index.ReconciliationNumberLength, FieldType = EntityFieldType.Int, Size = 2)]
        public short ReconciliationNumberLength { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationNumberPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReconciliationNumberPrefix", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.ReconciliationNumberPrefix, Id = Index.ReconciliationNumberPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReconciliationNumberPrefix { get; set; }

        /// <summary>
        /// Gets or sets NextReconciliationNumberDescription
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextReconciliationNumberDescription", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextReconciliationNumberDescription, Id = Index.NextReconciliationNumberDescription, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string NextReconciliationNumberDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultReconciliationNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultReconciliationNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultReconciliationNumber, Id = Index.DefaultReconciliationNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReconciliationNumber { get; set; }

        /// <summary>
        /// Gets or sets NextReconciliationNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextReconciliationNumber", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.NextReconciliationNumber, Id = Index.NextReconciliationNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextReconciliationNumber { get; set; }

        /// <summary>
        /// Gets or sets SeparatorLeftBracket
        /// </summary>
        [Display(Name = "SeparatorLeftBracket", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorLeftBracket, Id = Index.SeparatorLeftBracket, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorLeftBracket SeparatorLeftBracket { get; set; }

        /// <summary>
        /// Gets or sets SeparatorRightBracket
        /// </summary>
        [Display(Name = "SeparatorRightBracket", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorRightBracket, Id = Index.SeparatorRightBracket, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorRightBracket SeparatorRightBracket { get; set; }

        /// <summary>
        /// Gets or sets SeparatorLeftBrace
        /// </summary>
        [Display(Name = "SeparatorLeftBrace", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorLeftBrace, Id = Index.SeparatorLeftBrace, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorLeftBrace SeparatorLeftBrace { get; set; }

        /// <summary>
        /// Gets or sets SeparatorRightBrace
        /// </summary>
        [Display(Name = "SeparatorRightBrace", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SeparatorRightBrace, Id = Index.SeparatorRightBrace, FieldType = EntityFieldType.Int, Size = 2)]
        public SeparatorRightBrace SeparatorRightBrace { get; set; }

        /// <summary>
        /// Gets or sets AllowDuplicateSerials
        /// </summary>
        [Display(Name = "AllowDuplicateSerials", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowDuplicateSerials, Id = Index.AllowDuplicateSerials, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowDuplicateSerials { get; set; }

        /// <summary>
        /// Gets or sets SalesStatsPeriodsToUse
        /// </summary>
        [Display(Name = "SalesStatsPeriodsToUse", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.SalesStatsPeriodsToUse, Id = Index.SalesStatsPeriodsToUse, FieldType = EntityFieldType.Int, Size = 2)]
        public short SalesStatsPeriodsToUse { get; set; }

        /// <summary>
        /// Gets or sets UpdateLocationDetailsMinQty
        /// </summary>
        [Display(Name = "UpdateLocationDetailsMinQty", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UpdateLocationDetailsMinQty, Id = Index.UpdateLocationDetailsMinQty, FieldType = EntityFieldType.Bool, Size = 2)]
        public UpdateLocationDetailsMinQty UpdateLocationDetailsMinQty { get; set; }

        /// <summary>
        /// Gets or sets MinimumQuantityMarginFactor
        /// </summary>
        [Display(Name = "MinimumQuantityMarginFactor", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.MinimumQuantityMarginFactor, Id = Index.MinimumQuantityMarginFactor, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal MinimumQuantityMarginFactor { get; set; }

        /// <summary>
        /// Gets or sets MaximumQuantityMarginFactor
        /// </summary>
        [Display(Name = "MaximumQuantityMarginFactor", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.MaximumQuantityMarginFactor, Id = Index.MaximumQuantityMarginFactor, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal MaximumQuantityMarginFactor { get; set; }

        /// <summary>
        /// Gets or sets HighlightSalesVarianceAbove
        /// </summary>
        [Display(Name = "HighlightSalesVarianceAbove", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.HighlightSalesVarianceAbove, Id = Index.HighlightSalesVarianceAbove, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal HighlightSalesVarianceAbove { get; set; }

        /// <summary>
        /// Gets or sets HighlightTrendVarianceAbove
        /// </summary>
        [Display(Name = "HighlightTrendVarianceAbove", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.HighlightTrendVarianceAbove, Id = Index.HighlightTrendVarianceAbove, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal HighlightTrendVarianceAbove { get; set; }

        /// <summary>
        /// Gets or sets HighlightMinMaxVarianceAbove
        /// </summary>
        [Display(Name = "HighlightMinMaxVarianceAbove", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.HighlightMinMaxVarianceAbove, Id = Index.HighlightMinMaxVarianceAbove, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 2)]
        public decimal HighlightMinMaxVarianceAbove { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberDaysForExpiry
        /// </summary>
        [Display(Name = "DefaultNumberDaysForExpiry", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultNumberDaysForExpiry, Id = Index.DefaultNumberDaysForExpiry, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal DefaultNumberDaysForExpiry { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberDaysForFollowUp
        /// </summary>
        [Display(Name = "DefaultNumberDaysForFollowUp", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultNumberDaysForFollowUp, Id = Index.DefaultNumberDaysForFollowUp, FieldType = EntityFieldType.Decimal, Size = 3)]
        public decimal DefaultNumberDaysForFollowUp { get; set; }

        /// <summary>
        /// Gets or sets DefaultCommentType
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultCommentType", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.DefaultCommentType, Id = Index.DefaultCommentType, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DefaultCommentType { get; set; }

        /// <summary>
        /// Gets or sets AllowBlankCommentType
        /// </summary>
        [Display(Name = "AllowBlankCommentType", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.AllowBlankCommentType, Id = Index.AllowBlankCommentType, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowBlankCommentType AllowBlankCommentType { get; set; }

        /// <summary>
        /// Gets or sets UTCDateLastDayEnd
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UTCDateLastDayEnd", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UTCDateLastDayEnd, Id = Index.UTCDateLastDayEnd, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime UTCDateLastDayEnd { get; set; }

        /// <summary>
        /// Gets or sets UTCTimeLastDayEnd
        /// </summary>
        [Display(Name = "UTCTimeLastDayEnd", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.UTCTimeLastDayEnd, Id = Index.UTCTimeLastDayEnd, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan UTCTimeLastDayEnd { get; set; }

        /// <summary>
        /// Gets or sets LocalDateLastDayEnd
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocalDateLastDayEnd", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LocalDateLastDayEnd, Id = Index.LocalDateLastDayEnd, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LocalDateLastDayEnd { get; set; }

        /// <summary>
        /// Gets or sets LocalTimeLastDayEnd
        /// </summary>
        [Display(Name = "LocalTimeLastDayEnd", ResourceType = typeof (ICOptionResx))]
        [ViewField(Name = Fields.LocalTimeLastDayEnd, Id = Index.LocalTimeLastDayEnd, FieldType = EntityFieldType.Time, Size = 5)]
        public TimeSpan LocalTimeLastDayEnd { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets GLReferenceField string value
        /// </summary>
        public string GLReferenceFieldString => EnumUtility.GetStringValue(GLReferenceField);

        /// <summary>
        /// Gets GLDescriptionField string value
        /// </summary>
        public string GLDescriptionFieldString => EnumUtility.GetStringValue(GLDescriptionField);

        /// <summary>
        /// Gets AppendToGLBatch string value
        /// </summary>
        public string AppendToGLBatchString => EnumUtility.GetStringValue(AppendToGLBatch);

        /// <summary>
        /// Gets ConsolidateGLBatch string value
        /// </summary>
        public string ConsolidateGLBatchString => EnumUtility.GetStringValue(ConsolidateGLBatch);

        /// <summary>
        /// Gets StatisticsCalendar string value
        /// </summary>
        public string StatisticsCalendarString => EnumUtility.GetStringValue(StatisticsCalendar);

        /// <summary>
        /// Gets StatisticsPeriod string value
        /// </summary>
        public string StatisticsPeriodString => EnumUtility.GetStringValue(StatisticsPeriod);

        /// <summary>
        /// Gets AdditionalCostOnReceiptReturns string value
        /// </summary>
        public string AdditionalCostOnReceiptReturnsString => EnumUtility.GetStringValue(AdditionalCostOnReceiptReturns);

        /// <summary>
        /// Gets PeriodType string value
        /// </summary>
        public string PeriodTypeString => EnumUtility.GetStringValue(PeriodType);

        /// <summary>
        /// Gets CostDuring string value
        /// </summary>
        public string CostDuringString => EnumUtility.GetStringValue(CostDuring);

        /// <summary>
        /// Gets SeparatorHyhen string value
        /// </summary>
        public string SeparatorHyhenString => EnumUtility.GetStringValue(SeparatorHyhen);

        /// <summary>
        /// Gets SeparatorForwardSlash string value
        /// </summary>
        public string SeparatorForwardSlashString => EnumUtility.GetStringValue(SeparatorForwardSlash);

        /// <summary>
        /// Gets SeparatorBackSlash string value
        /// </summary>
        public string SeparatorBackSlashString => EnumUtility.GetStringValue(SeparatorBackSlash);

        /// <summary>
        /// Gets SeparatorAsterisk string value
        /// </summary>
        public string SeparatorAsteriskString => EnumUtility.GetStringValue(SeparatorAsterisk);

        /// <summary>
        /// Gets SeparatorPeriod string value
        /// </summary>
        public string SeparatorPeriodString => EnumUtility.GetStringValue(SeparatorPeriod);

        /// <summary>
        /// Gets SeparatorLeftParenthesis string value
        /// </summary>
        public string SeparatorLeftParenthesisString => EnumUtility.GetStringValue(SeparatorLeftParenthesis);

        /// <summary>
        /// Gets SeparatorRightParenthesis string value
        /// </summary>
        public string SeparatorRightParenthesisString => EnumUtility.GetStringValue(SeparatorRightParenthesis);

        /// <summary>
        /// Gets SeparatorNumberSign string value
        /// </summary>
        public string SeparatorNumberSignString => EnumUtility.GetStringValue(SeparatorNumberSign);

        /// <summary>
        /// Gets CreateSubledgerAuditDuring string value
        /// </summary>
        public string CreateSubledgerAuditDuringString => EnumUtility.GetStringValue(CreateSubledgerAuditDuring);

        /// <summary>
        /// Gets TransactionPostDepCost string value
        /// </summary>
        public string TransactionPostDepCostString => EnumUtility.GetStringValue(TransactionPostDepCost);

        /// <summary>
        /// Gets DefaultPostingDate string value
        /// </summary>
        public string DefaultPostingDateString => EnumUtility.GetStringValue(DefaultPostingDate);

        /// <summary>
        /// Gets SortSerialsBy string value
        /// </summary>
        public string SortSerialsByString => EnumUtility.GetStringValue(SortSerialsBy);

        /// <summary>
        /// Gets SortSerialsFirstBy string value
        /// </summary>
        public string SortSerialsFirstByString => EnumUtility.GetStringValue(SortSerialsFirstBy);

        /// <summary>
        /// Gets StopAllocationOfExpiredSeria string value
        /// </summary>
        public string StopAllocationOfExpiredSeriaString => EnumUtility.GetStringValue(StopAllocationOfExpiredSeria);

        /// <summary>
        /// Gets SortLotsBy string value
        /// </summary>
        public string SortLotsByString => EnumUtility.GetStringValue(SortLotsBy);

        /// <summary>
        /// Gets SortLotsFirstBy string value
        /// </summary>
        public string SortLotsFirstByString => EnumUtility.GetStringValue(SortLotsFirstBy);

        /// <summary>
        /// Gets StopAllocationOfExpiredLots string value
        /// </summary>
        public string StopAllocationOfExpiredLotsString => EnumUtility.GetStringValue(StopAllocationOfExpiredLots);

        /// <summary>
        /// Gets SeparatorLeftBracket string value
        /// </summary>
        public string SeparatorLeftBracketString => EnumUtility.GetStringValue(SeparatorLeftBracket);

        /// <summary>
        /// Gets SeparatorRightBracket string value
        /// </summary>
        public string SeparatorRightBracketString => EnumUtility.GetStringValue(SeparatorRightBracket);

        /// <summary>
        /// Gets SeparatorLeftBrace string value
        /// </summary>
        public string SeparatorLeftBraceString => EnumUtility.GetStringValue(SeparatorLeftBrace);

        /// <summary>
        /// Gets SeparatorRightBrace string value
        /// </summary>
        public string SeparatorRightBraceString => EnumUtility.GetStringValue(SeparatorRightBrace);

        /// <summary>
        /// Gets UpdateLocationDetailsMinQty string value
        /// </summary>
        public string UpdateLocationDetailsMinQtyString => EnumUtility.GetStringValue(UpdateLocationDetailsMinQty);

        /// <summary>
        /// Gets AllowBlankCommentType string value
        /// </summary>
        public string AllowBlankCommentTypeString => EnumUtility.GetStringValue(AllowBlankCommentType);

        #endregion
    }
}
