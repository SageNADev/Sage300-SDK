// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.POOEInvoiceEntry;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// InvoiceLine model class
    /// </summary>
    public partial class InvoiceLine : POOEBaseInvoiceLine
    {
    }
}
