// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Requisition
    /// </summary>
    public partial class Requisition : ModelBase
    {
        public Requisition()
        {
            RequisitionHeaderOptionalField = new EnumerableResponse<RequisitionHeaderOptionalField>();
            RequisitionLine = new EnumerableResponse<RequisitionLine>();
        }

        /// <summary>
        /// Gets or sets RequisitionSequenceKey
        /// </summary>
        [Key]
        [Display(Name = "RequisitionSequenceKey", ResourceType = typeof(RequisitionEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RequisitionSequenceKey, Id = Index.RequisitionSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets NextLineSequence
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NextLineSequence", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.NextLineSequence, Id = Index.NextLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextLineSequence { get; set; }

        /// <summary>
        /// Gets or sets Lines
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Lines", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets LinesComplete
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "LinesComplete", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.LinesComplete, Id = Index.LinesComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesComplete { get; set; }

        /// <summary>
        /// Gets or sets LinesOrdered
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "LinesOrdered", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.LinesOrdered, Id = Index.LinesOrdered, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesOrdered { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Printed", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Printed Printed { get; set; }

        /// <summary>
        /// Get or Set Receipt printed
        /// </summary>
        public string PrintedString
        {
            get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Completed", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

        /// <summary>
        /// Get or Set Completed 
        /// </summary>
        public string CompletedString
        {
            get { return EnumUtility.GetStringValue(Completed); }
        }

        /// <summary>
        /// Gets or sets DateCompleted
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "DateCompleted", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

        /// <summary>
        /// Gets or sets LastPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "LastPostingDate", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPostingDate { get; set; }

        /// <summary>
        /// Gets or sets RequisitionDate
        /// </summary>
        [Display(Name = "RqnDate", ResourceType = typeof(RequisitionEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RequisitionDate, Id = Index.RequisitionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RequisitionDate { get; set; }

        /// <summary>
        /// Gets or sets RequisitionNumber
        /// </summary>
        [Display(Name = "RequisitionNumber", ResourceType = typeof(POCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RequisitionNumber, Id = Index.RequisitionNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string RequisitionNumber { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>       
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets VendorExists
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "VendorExists", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

        /// <summary>
        /// Get or Set VendorExists 
        /// </summary>
        public string VendorExistsString
        {
            get { return EnumUtility.GetStringValue(VendorExists); }
        }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets OnHold
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public OnHold OnHold { get; set; }

        /// <summary>
        /// Get or Set OnHold 
        /// </summary>
        public string OnHoldString
        {
            get { return EnumUtility.GetStringValue(OnHold); }
        }

        /// <summary>
        /// Gets or sets OrderDate
        /// </summary>
        [Display(Name = "OrderDate", ResourceType = typeof(RequisitionEntryResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? OrderDate { get; set; }

        /// <summary>
        /// Gets or sets DateRequired
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateRequired", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DateRequired, Id = Index.DateRequired, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? DateRequired { get; set; }

        /// <summary>
        /// Gets or sets ExpirationDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpirationDate", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpirationDate { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RequisitionDescription", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "QuantityOrdered", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets Requestedby
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RequestedBy", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.Requestedby, Id = Index.Requestedby, FieldType = EntityFieldType.Char, Size = 60)]
        public string Requestedby { get; set; }

        /// <summary>
        /// Gets or sets DocumentSource
        /// </summary>
        [Display(Name = "DocumentSource", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DocumentSource, Id = Index.DocumentSource, FieldType = EntityFieldType.Int, Size = 2)]
        public DocumentSource DocumentSource { get; set; }

        /// <summary>
        /// Get or Set DocumentSource 
        /// </summary>
        public string DocumentSourceString
        {
            get { return EnumUtility.GetStringValue(DocumentSource); }
        }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OptionalFields", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedLines
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "JobRelatedLines", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.JobRelatedLines, Id = Index.JobRelatedLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedLines { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets LocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LocationDescription", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string LocationDescription { get; set; }

        /// <summary>
        /// Gets or sets ApprovalStatus
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ApprovalStatus", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.ApprovalStatus, Id = Index.ApprovalStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public ApprovalStatus ApprovalStatus { get; set; }

        /// <summary>
        /// Get or Set ApprovalStatus 
        /// </summary>
        public string ApprovalStatusString
        {
            get { return EnumUtility.GetStringValue(ApprovalStatus); }
        }

        /// <summary>
        /// Gets or sets ApproverID
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ApproverID", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.ApproverID, Id = Index.ApproverID, FieldType = EntityFieldType.Char, Size = 8)]
        public string ApproverID { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TotalWeight", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets FuncExtendedAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "FuncExtendedAmount", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.FuncExtendedAmount, Id = Index.FuncExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets VendorOnHold
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "VendorOnHold", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.VendorOnHold, Id = Index.VendorOnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorOnHold VendorOnHold { get; set; }

        /// <summary>
        /// Get or Set VendorOnHold 
        /// </summary>
        public string VendorOnHoldString
        {
            get { return EnumUtility.GetStringValue(VendorOnHold); }
        }

        /// <summary>
        /// Gets or sets DocumentLocked
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DocumentLocked", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DocumentLocked, Id = Index.DocumentLocked, FieldType = EntityFieldType.Bool, Size = 2)]
        public DocumentLocked DocumentLocked { get; set; }

        /// <summary>
        /// Get or Set DocumentLocked 
        /// </summary>
        public string DocumentLockedString
        {
            get { return EnumUtility.GetStringValue(DocumentLocked); }
        }

        /// <summary>
        /// Gets or sets RequisitionHasExpired
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RequisitionHasExpired", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.RequisitionHasExpired, Id = Index.RequisitionHasExpired, FieldType = EntityFieldType.Bool, Size = 2)]
        public RequisitionHasExpired RequisitionHasExpired { get; set; }

        /// <summary>
        /// Get or Set RequisitionHasExpired 
        /// </summary>
        public string RequisitionHasExpiredString
        {
            get { return EnumUtility.GetStringValue(RequisitionHasExpired); }
        }

        /// <summary>
        /// Gets or sets IsDocumentDeletable
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IsDocumentDeletable", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.IsDocumentDeletable, Id = Index.IsDocumentDeletable, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsDocumentDeletable IsDocumentDeletable { get; set; }

        /// <summary>
        /// Get or Set IsDocumentDeletable 
        /// </summary>
        public string IsDocumentDeletableString
        {
            get { return EnumUtility.GetStringValue(IsDocumentDeletable); }
        }

        /// <summary>
        /// Gets or sets IsRecordActive
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IsRecordActive", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.IsRecordActive, Id = Index.IsRecordActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsRecordActive IsRecordActive { get; set; }

        /// <summary>
        /// Get or Set IsRecordActive 
        /// </summary>
        public string IsRecordActiveString
        {
            get { return EnumUtility.GetStringValue(IsRecordActive); }
        }

        /// <summary>
        /// Gets or sets HasDetails
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "HasDetails", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.HasDetails, Id = Index.HasDetails, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasDetails HasDetails { get; set; }

        /// <summary>
        /// Get or Set HasDetails 
        /// </summary>
        public string HasDetailsString
        {
            get { return EnumUtility.GetStringValue(HasDetails); }
        }

        /// <summary>
        /// Gets or sets IsCanadianPayrollActive
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IsCanadianPayrollActive", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.IsCanadianPayrollActive, Id = Index.IsCanadianPayrollActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsCanadianPayrollActive IsCanadianPayrollActive { get; set; }

        /// <summary>
        /// Get or Set IsCanadianPayrollActive 
        /// </summary>
        public string IsCanadianPayrollActiveString
        {
            get { return EnumUtility.GetStringValue(IsCanadianPayrollActive); }
        }

        /// <summary>
        /// Gets or sets IsUSPayrollActive
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IsUSPayrollActive", ResourceType = typeof(RequisitionEntryResx))]            
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.IsUSPayrollActive, Id = Index.IsUSPayrollActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsUSPayrollActive IsUSPayrollActive { get; set; }

        /// <summary>
        /// Get or Set IsUSPayrollActive 
        /// </summary>
        // ReSharper disable once InconsistentNaming
        public string IsUSPayrollActiveString
        {
            get { return EnumUtility.GetStringValue(IsUSPayrollActive); }
        }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Command", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Get or Set Command 
        /// </summary>
        public string CommandString
        {
            get { return EnumUtility.GetStringValue(Command); }
        }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Get or Set JobRelated for finder
        /// </summary>
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets or sets ApproverName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "ApproverName", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.ApproverName, Id = Index.ApproverName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ApproverName { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        #region UI Properties
        /// <summary>
        ///  Gets or sets Header Optional Field
        /// </summary>       
        public EnumerableResponse<RequisitionHeaderOptionalField> RequisitionHeaderOptionalField { get; set; }

        /// <summary>
        ///  Gets or sets Requisition Line
        /// </summary>
        public EnumerableResponse<RequisitionLine> RequisitionLine { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        [IgnoreExportImport]
        public short SessionWarnDays { get; set; }


        /// <summary>
        /// Gets or sets Print Report
        /// </summary>
        /// <value>The Print Report .</value>
        [IgnoreExportImport]
        public bool PrintReport { get; set; }

        /// <summary>
        /// Get or Set  Attributes
        /// </summary>
        [IgnoreExportImport]
        public IDictionary<string, object> Attributes { get; set; }
        #endregion
    }
}
