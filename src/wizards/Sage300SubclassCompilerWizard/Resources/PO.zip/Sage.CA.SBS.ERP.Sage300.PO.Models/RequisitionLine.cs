// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.AP.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.PODropShipment;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for RequisitionLine
    /// </summary>
    public partial class RequisitionLine : ModelBase
    {
        public RequisitionLine()
        {
            RequisitionDetailOptionalField = new EnumerableResponse<RequisitionDetailOptionalField>();
            RequisitionComment=new EnumerableResponse<RequisitionComment>();
        }

        /// <summary>
        /// Gets or sets RequisitionSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RequisitionSequenceKey", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.RequisitionSequenceKey, Id = Index.RequisitionSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets RequisitionLineSequence
        /// </summary>
        [Display(Name = "RequisitionLineSequence", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.RequisitionLineSequence, Id = Index.RequisitionLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionLineSequence { get; set; }

        /// <summary>
        /// Gets or sets LineOrdered
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LineOrdered, Id = Index.LineOrdered, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineOrdered { get; set; }

        /// <summary>
        /// Gets or sets RequisitionCommentSequence
        /// </summary>
        [Display(Name = "RequisitionCommentSequence", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.RequisitionCommentSequence, Id = Index.RequisitionCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionCommentSequence { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets VendorExists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

        /// <summary>
        /// Gets or sets VDCODE
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]        
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.VDCODE, Id = Index.VDCODE, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string VDCODE { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets StoredInDatabaseTable
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
        public StoredInDatabaseTable StoredInDatabaseTable { get; set; }

        /// <summary>
        /// Gets or sets CompletionStatus
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.CompletionStatus, Id = Index.CompletionStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CompletionStatus CompletionStatus { get; set; }

        /// <summary>
        /// Gets or sets DateCompleted
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCompleted", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

        /// <summary>
        /// Gets or sets ItemExists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ItemExists, Id = Index.ItemExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public ItemExists ItemExists { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [Display(Name = "ItemDescription", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets ExpectedArrivalDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedArrivalDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExpectedArrivalDate, Id = Index.ExpectedArrivalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ExpectedArrivalDate { get; set; }

        /// <summary>
        /// Gets or sets VendorItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorItemNo", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.VendorItemNumber, Id = Index.VendorItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string VendorItemNumber { get; set; }

        /// <summary>
        /// Gets or sets CommentsInstructions
        /// </summary>
        [Display(Name = "CommentsInstructions", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.CommentsInstructions, Id = Index.CommentsInstructions, FieldType = EntityFieldType.Bool, Size = 2)]
        public CommentsInstructions CommentsInstructions { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [Key]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitConversion
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrderUnitConversion, Id = Index.OrderUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal OrderUnitConversion { get; set; }

        /// <summary>
        /// Gets or sets OrderUnitDecimals
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.OrderUnitDecimals, Id = Index.OrderUnitDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int OrderUnitDecimals { get; set; }

        /// <summary>
        /// Gets or sets StockUnitDecimals
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.StockUnitDecimals, Id = Index.StockUnitDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int StockUnitDecimals { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [Display(Name = "QuantityOrdered", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

        ///<summary>
        /// Gets or sets DropShipType
        /// </summary>
        [Display(Name = "DropShipType", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipType, Id = Index.DropShipType, FieldType = EntityFieldType.Int, Size = 2)]
        public DropShipType DropShipType { get; set; }

        /// <summary>
        /// Gets or sets DropShipCustomer
        /// </summary>
        [Display(Name = "DropShipCustomer", ResourceType = typeof(RequisitionEntryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DropShipCustomer, Id = Index.DropShipCustomer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string DropShipCustomer { get; set; }

        /// <summary>
        /// Gets or sets CustomerShipToAddress
        /// </summary>
        [Display(Name = "CustomerShipToAddress", ResourceType = typeof(RequisitionEntryResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CustomerShipToAddress, Id = Index.CustomerShipToAddress, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string CustomerShipToAddress { get; set; }

        /// <summary>
        /// Gets or sets DropShipLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipLocation", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipLocation, Id = Index.DropShipLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DropShipLocation { get; set; }

        /// <summary>
        /// Gets or sets DropShipDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipDescription", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipDescription, Id = Index.DropShipDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DropShipDescription { get; set; }

        /// <summary>
        /// Gets or sets DropShipAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipAddress1", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipAddress1, Id = Index.DropShipAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string DropShipAddress1 { get; set; }

        /// <summary>
        /// Gets or sets DropShipAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipAddress2", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipAddress2, Id = Index.DropShipAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string DropShipAddress2 { get; set; }

        /// <summary>
        /// Gets or sets DropShipAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipAddress3", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipAddress3, Id = Index.DropShipAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string DropShipAddress3 { get; set; }

        /// <summary>
        /// Gets or sets DropShipAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipAddress4", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipAddress4, Id = Index.DropShipAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string DropShipAddress4 { get; set; }

        /// <summary>
        /// Gets or sets DropShipCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipCity", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipCity, Id = Index.DropShipCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string DropShipCity { get; set; }

        /// <summary>
        /// Gets or sets DropShipStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipStateProvince", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipStateProvince, Id = Index.DropShipStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string DropShipStateProvince { get; set; }

        /// <summary>
        /// Gets or sets DropShipZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipZipPostalCode", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipZipPostalCode, Id = Index.DropShipZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string DropShipZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets DropShipCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipCountry", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipCountry, Id = Index.DropShipCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string DropShipCountry { get; set; }

        /// <summary>
        /// Gets or sets DropShipPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipPhoneNumber", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipPhoneNumber, Id = Index.DropShipPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string DropShipPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets DropShipFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipFaxNumber", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipFaxNumber, Id = Index.DropShipFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string DropShipFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets DropShipContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipContact", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipContact, Id = Index.DropShipContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string DropShipContact { get; set; }

        /// <summary>
        /// Gets or sets DropShipEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipEmail", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipEmail, Id = Index.DropShipEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string DropShipEmail { get; set; }

        /// <summary>
        /// Gets or sets DropShipContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipContactPhone", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipContactPhone, Id = Index.DropShipContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string DropShipContactPhone { get; set; }

        /// <summary>
        /// Gets or sets DropShipContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipContactFax", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipContactFax, Id = Index.DropShipContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string DropShipContactFax { get; set; }

        /// <summary>
        /// Gets or sets DropShipContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DropShipContactEmail", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DropShipContactEmail, Id = Index.DropShipContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string DropShipContactEmail { get; set; }

        /// <summary>
        /// Gets or sets DropShip
        /// </summary>
        [Display(Name = "DropShip", ResourceType = typeof(POCommonResx))]  
        [ViewField(Name = Fields.DropShip, Id = Index.DropShip, FieldType = EntityFieldType.Bool, Size = 2)]
        public DropShip DropShip { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem StockItem { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OptFields", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }


        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CostClass", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets CostClass string value
        /// </summary>
        public string CostClassString
        {
            get { return EnumUtility.GetStringValue(CostClass); }
        }


        /// <summary>
        /// Gets or sets StockingQuantityOrdered
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.StockingQuantityOrdered, Id = Index.StockingQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal StockingQuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets VendorOnHold
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorOnHold, Id = Index.VendorOnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorOnHold VendorOnHold { get; set; }

        /// <summary>
        /// Gets or sets UseICVendor
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UseICVendor, Id = Index.UseICVendor, FieldType = EntityFieldType.Int, Size = 2)]
        public UseICVendor UseICVendor { get; set; }

        /// <summary>
        /// Gets or sets ICVDCODE
        /// </summary>
        [IgnoreExportImport]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]        
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.ICVDCODE, Id = Index.ICVDCODE, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ICVDCODE { get; set; }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Completed", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

        /// <summary>
        /// Gets or sets LinesComplete
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "LinesComplete", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.LinesComplete, Id = Index.LinesComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesComplete { get; set; }

        /// <summary>
        /// Gets or sets IsRecordActive
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IsRecordActive", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.IsRecordActive, Id = Index.IsRecordActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsRecordActive IsRecordActive { get; set; }

        /// <summary>
        /// Gets or sets Line
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
        public long Line { get; set; }

        /// <summary>
        /// Gets or sets MapManufacturersItemNumber
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.MapManufacturersItemNumber, Id = Index.MapManufacturersItemNumber, FieldType = EntityFieldType.Bool, Size = 2)]
        public MapManufacturersItemNumber MapManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [IgnoreExportImport]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Key]
        [Display(Name = "UnitCost", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets UnitCostIsManual
        /// </summary>
        [Display(Name = "UnitCostIsManual", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.UnitCostIsManual, Id = Index.UnitCostIsManual, FieldType = EntityFieldType.Bool, Size = 2)]
        public UnitCostIsManual UnitCostIsManual { get; set; }

        /// <summary>
        /// Gets or sets CopyCostToPurchaseOrder
        /// </summary>
        [Display(Name = "CopyCostToPO", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.CopyCostToPurchaseOrder, Id = Index.CopyCostToPurchaseOrder, FieldType = EntityFieldType.Bool, Size = 2)]
        public CopyCostToPurchaseOrder CopyCostToPurchaseOrder { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExtended
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.FunctionalExtended, Id = Index.FunctionalExtended, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExtended { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercentage
        /// </summary>
        [Display(Name = "DiscountPercentage", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight
        /// </summary>
        [Display(Name = "UnitWeight", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WeightUOM", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightConversion
        /// </summary>
        [Display(Name = "WeightConversion", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.WeightConversion, Id = Index.WeightConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal WeightConversion { get; set; }

        /// <summary>
        /// Gets or sets DefaultUnitWeight
        /// </summary>
        [Display(Name = "DefaultUnitWeight", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DefaultUnitWeight, Id = Index.DefaultUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefaultUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets DefaultExtendedWeight
        /// </summary>
        [Display(Name = "DefaultExtendedWeight", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DefaultExtendedWeight, Id = Index.DefaultExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefaultExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets NetExtendedCost
        /// </summary>
        [Display(Name = "NetExtendedCost", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.NetExtendedCost, Id = Index.NetExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets Lines
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Lines", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [IgnoreExportImport]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3)]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets VendorCurrency
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        public string VendorCurrency { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyDescription", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExchangeRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateExists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExchangeRateExists, Id = Index.ExchangeRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public ExchangeRateExists ExchangeRateExists { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [IgnoreExportImport]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2)]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateTypeDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateTypeDescription", ResourceType = typeof(VendorResx))]
        [ViewField(Name = Fields.RateTypeDescription, Id = Index.RateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets CostDateForContract
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CostDateForContract, Id = Index.CostDateForContract, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CostDateForContract { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        ///  Gets or sets DropShipAddress
        /// </summary>
         [IgnoreExportImport]
        public DropShipAddress DropShipAddress { get; set; }

        /// <summary>
        /// 
        /// </summary>
         [IgnoreExportImport]
         public string OptionalFieldsString 
         { 
             get
             {
                 if (OptionalFields>0)
                 {
                     return CommonResx.Yes;
                 }
                return CommonResx.No;            
             }
         }

        #region UI Properties
        /// <summary>
        ///  Gets or sets Requisition Comment
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RequisitionComment> RequisitionComment { get; set; }

        /// <summary>
        ///  Gets or sets Requisition Detail Optional Field 
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<RequisitionDetailOptionalField> RequisitionDetailOptionalField { get; set; }

        /// <summary>
        /// Get or Set  Attributes
        /// </summary>
        [IgnoreExportImport]
        public IDictionary<string, object> Attributes { get; set; }
        #endregion
    }
}
