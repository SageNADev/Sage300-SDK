﻿using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    public class CrdrNoteEntrySecurity
    {
        #region Properties Added for Security
        /// <summary>
        /// Gets or sets HasApvenUpdateSec
        /// </summary>
        [IgnoreExportImport]
        public bool HasApvenUpdateSec { get; set; }

        /// <summary>
        /// Gets or sets HasPohshtInquireSec
        /// </summary>
        [IgnoreExportImport]
        public bool HasPohshtInquireSec { get; set; }

        /// <summary>
        /// Gets or sets CanPrintTransList
        /// </summary>
        [IgnoreExportImport]
        public bool CanPrintTransList { get; set; }

        /// <summary>
        /// Gets or sets HasOfTransRights
        /// </summary>
        [IgnoreExportImport]
        public bool HasOfTransRights { get; set; }

        /// <summary>
        /// Gets or Sets Optional Field Access Status
        /// </summary>
        public bool HasOptFieldsAccess { get; set; }

        #endregion
    }
}
