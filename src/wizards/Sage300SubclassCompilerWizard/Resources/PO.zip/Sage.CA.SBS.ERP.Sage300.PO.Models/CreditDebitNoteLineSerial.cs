// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for CreditDebitNoteLineSerial
     /// </summary>
     public partial class CreditDebitNoteLineSerial : ModelBase
     {
          /// <summary>
          /// Gets or sets CreditDebitNoteSequenceKey
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CreditDebitNoteSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal LineNumber {get; set;}

          /// <summary>
          /// Gets or sets SerialNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string SerialNumber {get; set;}

          /// <summary>
          /// Gets or sets CreditDebitNoteLineSequence
          /// </summary>
          [ViewField(Name = Fields.CreditDebitNoteLineSequence, Id = Index.CreditDebitNoteLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CreditDebitNoteLineSequence {get; set;}

          /// <summary>
          /// Gets or sets SerialCount
          /// </summary>
          [ViewField(Name = Fields.SerialCount, Id = Index.SerialCount, FieldType = EntityFieldType.Long, Size = 4)]
          public long SerialCount {get; set;}

     }
}
