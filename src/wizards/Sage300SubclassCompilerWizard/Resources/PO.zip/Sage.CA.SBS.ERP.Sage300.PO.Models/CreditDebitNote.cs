// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for CreditDebitNote
    /// </summary>
    public partial class CreditDebitNote : ModelBase,IVendorInformation
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public CreditDebitNote()
        {
            CreditDebitNoteLines = new EnumerableResponse<CreditDebitNoteLine>();
            CreditDebitNoteComments = new EnumerableResponse<CreditDebitNoteComment>();
            CreditDebitNoteFunctions = new EnumerableResponse<CreditDebitNoteFunction>();
            CreditDebitNoteOptFields = new EnumerableResponse<CreditDebitNoteOptField>();
            CrdrNoteAdditionalCosts = new EnumerableResponse<CrdrNoteAdditionalCost>();
            CrdrNoteCostDistributions = new EnumerableResponse<CrdrNoteCostDistribution>();
            CrdrAddCostsSuperViewList = new EnumerableResponse<CrdrAddCostsSuperview>();
            CrdrNoteEntrySecurity=new CrdrNoteEntrySecurity();
        }

        /// <summary>
        /// Gets or sets CreditDebitNoteSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets NextLineSequence
        /// </summary>
        [Display(Name = "NextLineSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.NextLineSequence, Id = Index.NextLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextLineSequence { get; set; }

        /// <summary>
        /// Gets or sets Lines
        /// </summary>
        [Display(Name = "NumberofLines", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets LinesComplete
        /// </summary>
        [Display(Name = "LinesComplete", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LinesComplete, Id = Index.LinesComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesComplete { get; set; }

        /// <summary>
        /// Gets or sets Costs
        /// </summary>
        [Display(Name = "NumberofCosts", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Costs, Id = Index.Costs, FieldType = EntityFieldType.Long, Size = 4)]
        public long Costs { get; set; }

        /// <summary>
        /// Gets or sets CostsComplete
        /// </summary>
        [Display(Name = "CostsComplete", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.CostsComplete, Id = Index.CostsComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostsComplete { get; set; }

        /// <summary>
        /// Gets or sets LinesTaxCalculationSees
        /// </summary>
        [Display(Name = "LinesTaxCalculationSees", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LinesTaxCalculationSees, Id = Index.LinesTaxCalculationSees, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesTaxCalculationSees { get; set; }

        /// <summary>
        /// Gets or sets ExtraneousLineCount
        /// </summary>
        [Display(Name = "ExtraneousLineCount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtraneousLineCount, Id = Index.ExtraneousLineCount, FieldType = EntityFieldType.Long, Size = 4)]
        public long ExtraneousLineCount { get; set; }

        /// <summary>
        /// Gets or sets Autotaxcalculationonsave
        /// </summary>
        [Display(Name = "AutoTaxCalculationOnSave", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Autotaxcalculationonsave, Id = Index.Autotaxcalculationonsave, FieldType = EntityFieldType.Bool, Size = 2)]
        public AutoTaxCalculationOnSave Autotaxcalculationonsave { get; set; }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        [Display(Name = "Completed", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

        /// <summary>
        /// Gets or sets DateCompleted
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "DateCompleted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

        /// <summary>
        /// Gets or sets LastPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "LastPostingDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPostingDate { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [Display(Name = "PurchaseOrderSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PONumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; } 

        /// <summary>
        /// Gets or sets CreditDebitNoteDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteDate, Id = Index.CreditDebitNoteDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CreditDebitNoteDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FromYearPeriod", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteNumber
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DocumentNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.CreditDebitNoteNumber, Id = Index.CreditDebitNoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string CreditDebitNoteNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "DocumentType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public CreditDebitNoteTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets FromDocument
        /// </summary>
        [Display(Name = "FromDocument", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.FromDocument, Id = Index.FromDocument, FieldType = EntityFieldType.Int, Size = 2)]
        public CreditDebitNoteFromDocument FromDocument { get; set; }

        /// <summary>
        /// Gets or sets VendorExists
        /// </summary>
        [Display(Name = "VendorExists", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets ReturnSequenceKey
        /// </summary>
        [Display(Name = "ReturnSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets ReturnNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "ReturnNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReturnNumber, Id = Index.ReturnNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ReturnNumber { get; set; }

        /// <summary>
        /// Gets or sets ReturnDate
        /// </summary>
        //[ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReturnDate", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ReturnDate, Id = Index.ReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ReturnDate { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSequenceKey
        /// </summary>
        [Display(Name = "InvoiceSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.InvoiceSequenceKey, Id = Index.InvoiceSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceDate
        /// </summary>
        //[ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "InvoiceDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.InvoiceDate, Id = Index.InvoiceDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? InvoiceDate { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary> 
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateMatchType
        /// </summary>
        [Display(Name = "RateMatchType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RateMatchType, Id = Index.RateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateMatchType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden
        /// </summary>
        [Display(Name = "RateOverridden", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlaces
        /// </summary>
        [Display(Name = "DecimalPlaces", ResourceType = typeof(CommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DecimalPlaces, Id = Index.DecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [Display(Name = "TotalWeight", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets Total
        /// </summary>
        [Display(Name = "Total", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Total, Id = Index.Total, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Total { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [Display(Name = "QuantityReturned", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(POCommonResx))]
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1
        /// </summary>
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2
        /// </summary>
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3
        /// </summary>
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4
        /// </summary>
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5
        /// </summary>
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets NetOfTax
        /// </summary>
        [Display(Name = "NetOfTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NetOfTax, Id = Index.NetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTax { get; set; }

        /// <summary>
        /// Gets or sets Txincluded
        /// </summary>
        [Display(Name = "TaxIncluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Txincluded, Id = Index.Txincluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Txincluded { get; set; }

        /// <summary>
        /// Gets or sets Txexcluded
        /// </summary>
        [Display(Name = "PlusExcludedTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Txexcluded, Id = Index.Txexcluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Txexcluded { get; set; } 

        /// <summary>
        /// Gets or sets TotalTax
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(POCommonResx))] 
        [ViewField(Name = Fields.TotalTax, Id = Index.TotalTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTax { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxRecoverable
        /// </summary>
        [Display(Name = "TotalTaxRecoverable", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalTaxRecoverable, Id = Index.TotalTaxRecoverable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxRecoverable { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxExpensed
        /// </summary>
        [Display(Name = "TotalTaxExpensed", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalTaxExpensed, Id = Index.TotalTaxExpensed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxExpensed { get; set; }

        /// <summary>
        /// Gets or sets Txalloamt
        /// </summary>
        [Display(Name = "TotalTaxAllocated", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Txalloamt, Id = Index.Txalloamt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Txalloamt { get; set; }

        /// <summary>
        /// Gets or sets Num1099CprsClass
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "_1099CPRSCode", ResourceType = typeof(POCommonResx))] 
        [ViewField(Name = Fields.Num1099CprsClass, Id = Index.Num1099CprsClass, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Num1099CprsClass { get; set; }

        /// <summary>
        /// Gets or sets The1099CprsAmount
        /// </summary>
        [Display(Name = "The1099CPRSAmount", ResourceType = typeof(CreditDebitNoteEntryResx))] 
        [ViewField(Name = Fields.The1099CprsAmount, Id = Index.The1099CprsAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal The1099CprsAmount { get; set; }

        /// <summary>
        /// Gets or sets ManualProrationTotal
        /// </summary>
        [Display(Name = "ManualProrationTotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ManualProrationTotal, Id = Index.ManualProrationTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ManualProrationTotal { get; set; }

        /// <summary>
        /// Gets or sets ManualToProrate
        /// </summary>
        [Display(Name = "ManualToProrate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ManualToProrate, Id = Index.ManualToProrate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ManualToProrate { get; set; }

        /// <summary>
        /// Gets or sets ConversionSourceAmount
        /// </summary>
        [Display(Name = "ConversionSourceAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ConversionSourceAmount, Id = Index.ConversionSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets ConversionFunctionalAmount
        /// </summary>
        [Display(Name = "ConversionFunctionalAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ConversionFunctionalAmount, Id = Index.ConversionFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets BillToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToLocation", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.BillToLocation, Id = Index.BillToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillToLocation { get; set; } 

        /// <summary>
        /// Gets or sets BillToLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToLocationDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToLocationDescription, Id = Index.BillToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress1, Id = Index.BillToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress2, Id = Index.BillToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress3, Id = Index.BillToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToAddress4, Id = Index.BillToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets BillToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToCity, Id = Index.BillToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCity { get; set; }

        /// <summary>
        /// Gets or sets BillToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToStateProvince", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToStateProvince, Id = Index.BillToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets BillToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToZipPostalCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToZipPostalCode, Id = Index.BillToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string BillToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets BillToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCountry", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToCountry, Id = Index.BillToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCountry { get; set; }

        /// <summary>
        /// Gets or sets BillToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToPhoneNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToPhoneNumber, Id = Index.BillToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToFaxNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToFaxNumber, Id = Index.BillToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContact", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToContact, Id = Index.BillToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToContact { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocationDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToLocationDescription, Id = Index.ShipToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToAddress1, Id = Index.ShipToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToAddress2, Id = Index.ShipToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToAddress3, Id = Index.ShipToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToAddress4, Id = Index.ShipToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets ShipToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToCity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToCity, Id = Index.ShipToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCity { get; set; }

        /// <summary>
        /// Gets or sets ShipToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToStateProvince", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToStateProvince, Id = Index.ShipToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets ShipToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToZipPostalCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToZipPostalCode, Id = Index.ShipToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ShipToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToCountry", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToCountry, Id = Index.ShipToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// Gets or sets ShipToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToPhoneNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToPhoneNumber, Id = Index.ShipToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToFaxNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToFaxNumber, Id = Index.ShipToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContact", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToContact, Id = Index.ShipToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToContact { get; set; }

        /// <summary>
        /// Gets or sets RemitToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToLocation", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RemitToLocation, Id = Index.RemitToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RemitToLocation { get; set; }

        /// <summary>
        /// Gets or sets RemitToLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToLocationDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToLocationDescription, Id = Index.RemitToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToAddress1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToAddress1, Id = Index.RemitToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToAddress2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToAddress2, Id = Index.RemitToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToAddress3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToAddress3, Id = Index.RemitToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets RemitToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToAddress4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToAddress4, Id = Index.RemitToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets RemitToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToCity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToCity, Id = Index.RemitToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToCity { get; set; }

        /// <summary>
        /// Gets or sets RemitToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToStateProvince", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToStateProvince, Id = Index.RemitToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets RemitToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToZipPostalCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToZipPostalCode, Id = Index.RemitToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string RemitToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets RemitToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToCountry", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToCountry, Id = Index.RemitToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string RemitToCountry { get; set; }

        /// <summary>
        /// Gets or sets RemitToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToPhoneNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToPhoneNumber, Id = Index.RemitToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string RemitToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets RemitToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToFaxNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToFaxNumber, Id = Index.RemitToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string RemitToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets RemitToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToContact", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToContact, Id = Index.RemitToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemitToContact { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsExchangeRate
        /// </summary>
        [Display(Name = "PredecessorsExchangeRate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsExchangeRate, Id = Index.PredecessorsExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PredecessorsExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "PredecessorsRateType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredecessorsRateType, Id = Index.PredecessorsRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PredecessorsRateType { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "PredecessorsRateDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredecessorsRateDate, Id = Index.PredecessorsRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PredecessorsRateDate { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateOperation
        /// </summary>
        [Display(Name = "PredecessorsRateOperation", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsRateOperation, Id = Index.PredecessorsRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public PredecessorsRateOperation PredecessorsRateOperation { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateOverridden
        /// </summary>
        [Display(Name = "PredecessorsRateOverridden", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsRateOverridden, Id = Index.PredecessorsRateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public PredecessorsRateOverridden PredecessorsRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxClass1Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxClass2Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxClass3Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxClass4Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxClass5Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority1Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority2Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority3Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority4Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority5Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "CurrencyDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets RateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "RateTypeDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RateTypeDescription, Id = Index.RateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateTypeDescript
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "PredecessorsRateTypeDescript", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredecessorsRateTypeDescript, Id = Index.PredecessorsRateTypeDescript, FieldType = EntityFieldType.Char, Size = 60)]
        public string PredecessorsRateTypeDescript { get; set; }

        /// <summary>
        /// Gets or sets NetOfTaxSum
        /// </summary>
        [Display(Name = "NetOfTaxSum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.NetOfTaxSum, Id = Index.NetOfTaxSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTaxSum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1Sum
        /// </summary>
        [Display(Name = "TaxIncluded1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded1Sum, Id = Index.TaxIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2Sum
        /// </summary>
        [Display(Name = "TaxIncluded2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded2Sum, Id = Index.TaxIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3Sum
        /// </summary>
        [Display(Name = "TaxIncluded3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded3Sum, Id = Index.TaxIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4Sum
        /// </summary>
        [Display(Name = "TaxIncluded4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded4Sum, Id = Index.TaxIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5Sum
        /// </summary>
        [Display(Name = "TaxIncluded5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded5Sum, Id = Index.TaxIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount1Sum, Id = Index.TaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount2Sum, Id = Index.TaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount3Sum, Id = Index.TaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount4Sum, Id = Index.TaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5Sum
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount5Sum, Id = Index.TaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount1Sum, Id = Index.TaxRecoverableAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount2Sum, Id = Index.TaxRecoverableAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount3Sum, Id = Index.TaxRecoverableAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount4Sum, Id = Index.TaxRecoverableAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5Sum
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount5Sum, Id = Index.TaxRecoverableAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount1Sum, Id = Index.TaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount2Sum, Id = Index.TaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount3Sum, Id = Index.TaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount4Sum, Id = Index.TaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5Sum
        /// </summary>
        [Display(Name = "TaxExpenseAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount5Sum, Id = Index.TaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5Sum { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TCALLOAMT
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Tcalloamt, Id = Index.Tcalloamt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Tcalloamt { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TCINCLUDED
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Tcincluded, Id = Index.Tcincluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Tcincluded { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets TCEXCLUDED
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Tcexcluded, Id = Index.Tcexcluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Tcexcluded { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedTax
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TotalUnbalancedTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalUnbalancedTax, Id = Index.TotalUnbalancedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedTax { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedAllocatedTax
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TotalUnbalancedAllocatedTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TotalUnbalancedAllocatedTax, Id = Index.TotalUnbalancedAllocatedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedAllocatedTax { get; set; }

        /// <summary>
        /// Gets or sets UnbalancedManualProrationAmou
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "UnbalancedManualProrationAmou", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnbalancedManualProrationAmou, Id = Index.UnbalancedManualProrationAmou, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnbalancedManualProrationAmou { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteTotal
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteTotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteTotal, Id = Index.CreditDebitNoteTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditDebitNoteTotal { get; set; }

        /// <summary>
        /// Gets or sets Subtotal
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Subtotal", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Subtotal, Id = Index.Subtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Subtotal { get; set; }

        /// <summary>
        /// Gets or sets TaxcalculationIspending
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxcalculationIspending", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxcalculationIspending, Id = Index.TaxcalculationIspending, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxcalculationIspending TaxcalculationIspending { get; set; }

        /// <summary>
        /// Gets or sets SubjectTo1099CPRSReporting
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "SubjectTo1099CPRSReporting", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public SubjectTo1099CPRSReporting SubjectTo1099CprsReporting { get; set; }

        /// <summary>
        /// Gets or sets DocumentLocked
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DocumentLocked", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DocumentLocked, Id = Index.DocumentLocked, FieldType = EntityFieldType.Bool, Size = 2)]
        public DocumentLocked DocumentLocked { get; set; }

        /// <summary>
        /// Gets or sets IsDocumentDeletable
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IsDocumentDeletable", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IsDocumentDeletable, Id = Index.IsDocumentDeletable, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsDocumentDeletable IsDocumentDeletable { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateExists
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExchangeRateExists", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExchangeRateExists, Id = Index.ExchangeRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public ExchangeRateExists ExchangeRateExists { get; set; }

        /// <summary>
        /// Gets or sets HasDetails
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "HasDetails", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.HasDetails, Id = Index.HasDetails, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasDetails HasDetails { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCostGroups
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NumberofCosts", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NumberOfCostGroups, Id = Index.NumberOfCostGroups, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfCostGroups { get; set; }

        /// <summary>
        /// Gets or sets BillToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToEmail, Id = Index.BillToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToEmail { get; set; }

        /// <summary>
        /// Gets or sets BillToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactPhone", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToContactPhone, Id = Index.BillToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactFax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToContactFax, Id = Index.BillToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillToContactEmail, Id = Index.BillToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToEmail, Id = Index.ShipToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactPhone", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToContactPhone, Id = Index.ShipToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactFax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToContactFax, Id = Index.ShipToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ShipToContactEmail, Id = Index.ShipToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets RemitToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToEmail, Id = Index.RemitToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string RemitToEmail { get; set; }

        /// <summary>
        /// Gets or sets RemitToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToContactPhone", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToContactPhone, Id = Index.RemitToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string RemitToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets RemitToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToContactFax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToContactFax, Id = Index.RemitToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string RemitToContactFax { get; set; }

        /// <summary>
        /// Gets or sets RemitToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemitToContactEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RemitToContactEmail, Id = Index.RemitToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string RemitToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercentage
        /// </summary>
        [Display(Name = "DiscountPercentage", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmountSum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DiscountAmountSum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DiscountAmountSum, Id = Index.DiscountAmountSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmountSum { get; set; }

        /// <summary>
        /// Gets or sets NetExtendedCost
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NetAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NetExtendedCost, Id = Index.NetExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OptionalFields", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Command", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets OnHold
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OnHold { get; set; }
        
        /// <summary>
        /// Gets or sets ProrationVersion
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ProrationVersion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProrationVersion, Id = Index.ProrationVersion, FieldType = EntityFieldType.Int, Size = 2)]
        public ProrationVersion ProrationVersion { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RetainageBase
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageBase", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageBase, Id = Index.RetainageBase, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageBase RetainageBase { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedLines
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "JobRelatedLines", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.JobRelatedLines, Id = Index.JobRelatedLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedLines { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedCosts
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "JobRelatedCosts", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.JobRelatedCosts, Id = Index.JobRelatedCosts, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedCosts { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets UnretainedTotal
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "UnretainedTotal", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnretainedTotal, Id = Index.UnretainedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnretainedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxReportingCurrency, Id = Index.TaxReportingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrency { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateSpread
        /// </summary>
        [Display(Name = "TaxReportingRateSpread", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateSpread, Id = Index.TaxReportingRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingRateSpread { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateMatchType
        /// </summary>
        [Display(Name = "TaxReportingRateMatchType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateMatchType, Id = Index.TaxReportingRateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateMatchType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation
        /// </summary>
        [Display(Name = "TaxReportingRateOperation", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingRateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOverridden
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingRateOverridden", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOverridden, Id = Index.TaxReportingRateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingRateOverridden TaxReportingRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingDecimalPlaces
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingDecimalPlaces", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingDecimalPlaces, Id = Index.TaxReportingDecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingDecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount1, Id = Index.TaxReportingIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount2, Id = Index.TaxReportingIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount3, Id = Index.TaxReportingIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount4, Id = Index.TaxReportingIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount5, Id = Index.TaxReportingIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount1, Id = Index.TaxReportingExcludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount2, Id = Index.TaxReportingExcludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount3, Id = Index.TaxReportingExcludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount4, Id = Index.TaxReportingExcludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount5, Id = Index.TaxReportingExcludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount1
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount1, Id = Index.TaxReportingExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount2
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount2, Id = Index.TaxReportingExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount3
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount3, Id = Index.TaxReportingExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount4
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount4, Id = Index.TaxReportingExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount5
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount5, Id = Index.TaxReportingExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingExchRate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingExchRate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingExchRate, Id = Index.PredTaxReportingExchRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PredTaxReportingExchRate { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateType
        /// </summary>
        [IgnoreExportImport]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PredTaxReportingRateType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingRateType, Id = Index.PredTaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PredTaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateDate
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PredTaxReportingRateDate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingRateDate, Id = Index.PredTaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PredTaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateOper
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingRateOper", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingRateOper, Id = Index.PredTaxReportingRateOper, FieldType = EntityFieldType.Int, Size = 2)]
        public PredTaxReportingRateOper PredTaxReportingRateOper { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateOverrd
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingRateOverrd", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingRateOverrd, Id = Index.PredTaxReportingRateOverrd, FieldType = EntityFieldType.Bool, Size = 2)]
        public PredTaxReportingRateOverrd PredTaxReportingRateOverrd { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchRateExists
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExchRateExists", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExchRateExists, Id = Index.TaxReportingExchRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingExchRateExists TaxReportingExchRateExists { get; set; }

        /// <summary>
        /// Gets or sets DerivedTaxReportingExchRate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DerivedTaxReportingExchRate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DerivedTaxReportingExchRate, Id = Index.DerivedTaxReportingExchRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal DerivedTaxReportingExchRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyDesc
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyDesc, Id = Index.TaxReportingCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateTypeDesc
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateTypeDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateTypeDesc, Id = Index.TaxReportingRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets PredTaxRepRateTypeDesc
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PredTaxRepRateTypeDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PredTaxRepRateTypeDesc, Id = Index.PredTaxRepRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PredTaxRepRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotalAmount
        /// </summary>
        [Display(Name = "TaxReportingTotalAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingTotalAmount, Id = Index.TaxReportingTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount, Id = Index.TaxReportingIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount, Id = Index.TaxReportingExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmount
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmount, Id = Index.TaxReportingRecoverableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount, Id = Index.TaxReportingExpensedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount, Id = Index.TaxReportingAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase1Sum, Id = Index.TaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase2Sum, Id = Index.TaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase3Sum, Id = Index.TaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase4Sum, Id = Index.TaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase5Sum, Id = Index.TaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount1Sum, Id = Index.TaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount2Sum, Id = Index.TaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount3Sum, Id = Index.TaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount4Sum, Id = Index.TaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount5Sum, Id = Index.TaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExcluded1Sum, Id = Index.TaxExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExcluded2Sum, Id = Index.TaxExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExcluded3Sum, Id = Index.TaxExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExcluded4Sum, Id = Index.TaxExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExcluded5Sum, Id = Index.TaxExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1Sum, Id = Index.TaxReportingAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2Sum, Id = Index.TaxReportingAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3Sum, Id = Index.TaxReportingAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4Sum, Id = Index.TaxReportingAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5Sum, Id = Index.TaxReportingAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded1Sum, Id = Index.TaxReportingIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded2Sum, Id = Index.TaxReportingIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded3Sum, Id = Index.TaxReportingIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded4Sum, Id = Index.TaxReportingIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded5Sum, Id = Index.TaxReportingIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded1Sum, Id = Index.TaxReportingExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded2Sum, Id = Index.TaxReportingExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded3Sum, Id = Index.TaxReportingExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded4Sum, Id = Index.TaxReportingExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded5Sum, Id = Index.TaxReportingExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount1Sum, Id = Index.TaxRepAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount2Sum, Id = Index.TaxRepAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount3Sum, Id = Index.TaxRepAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount4Sum, Id = Index.TaxRepAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount5Sum, Id = Index.TaxRepAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt1Sum, Id = Index.TaxRepRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt2Sum, Id = Index.TaxRepRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt3Sum, Id = Index.TaxRepRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt4Sum, Id = Index.TaxRepRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt5Sum, Id = Index.TaxRepRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount1Sum, Id = Index.TaxRepExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount2Sum, Id = Index.TaxRepExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount3Sum, Id = Index.TaxRepExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount4Sum, Id = Index.TaxRepExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount5Sum, Id = Index.TaxRepExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets ReportRetainageTax
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReportRetainageTax", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReportRetainageTax, Id = Index.ReportRetainageTax, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportRetainageTax ReportRetainageTax { get; set; }

        /// <summary>
        /// Gets or sets TaxStateVersion
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxStateVersion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxStateVersion, Id = Index.TaxStateVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxStateVersion { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt1
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt1, Id = Index.RetainageTaxRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt2
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt2, Id = Index.RetainageTaxRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt3
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt3, Id = Index.RetainageTaxRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt4
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt4, Id = Index.RetainageTaxRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt5
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt5, Id = Index.RetainageTaxRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount1
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount1, Id = Index.RetainageTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount2
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount2, Id = Index.RetainageTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount3
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount3, Id = Index.RetainageTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount4
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount4, Id = Index.RetainageTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount5
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount5, Id = Index.RetainageTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount1, Id = Index.RetainageTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount2, Id = Index.RetainageTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount3, Id = Index.RetainageTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount4, Id = Index.RetainageTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount5, Id = Index.RetainageTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets WarnOnRetainageTaxShift
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "WarnOnRetainageTaxShift", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.WarnOnRetainageTaxShift, Id = Index.WarnOnRetainageTaxShift, FieldType = EntityFieldType.Bool, Size = 2)]
        public WarnOnRetainageTaxShift WarnOnRetainageTaxShift { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxTotalAmount
        /// </summary>
        [Display(Name = "RetainageTaxTotalAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxTotalAmount, Id = Index.RetainageTaxTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt1
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt1, Id = Index.TaxAmountPlusRtgTaxAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt2
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt2, Id = Index.TaxAmountPlusRtgTaxAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt3
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt3, Id = Index.TaxAmountPlusRtgTaxAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt4
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt4, Id = Index.TaxAmountPlusRtgTaxAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt5
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt5, Id = Index.TaxAmountPlusRtgTaxAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase1Sum, Id = Index.RetainageTaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase2Sum, Id = Index.RetainageTaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase3Sum, Id = Index.RetainageTaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase4Sum, Id = Index.RetainageTaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase5Sum, Id = Index.RetainageTaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1Sum, Id = Index.RetainageTaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2Sum, Id = Index.RetainageTaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3Sum, Id = Index.RetainageTaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4Sum, Id = Index.RetainageTaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5Sum, Id = Index.RetainageTaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt1Sum, Id = Index.RtgTaxRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt2Sum, Id = Index.RtgTaxRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt3Sum, Id = Index.RtgTaxRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt4Sum, Id = Index.RtgTaxRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt5Sum, Id = Index.RtgTaxRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount1Sum, Id = Index.RtgTaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount2Sum, Id = Index.RtgTaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount3Sum, Id = Index.RtgTaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount4Sum, Id = Index.RtgTaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount5Sum, Id = Index.RtgTaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount1Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount1Sum, Id = Index.RtgTaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount2Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount2Sum, Id = Index.RtgTaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount3Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount3Sum, Id = Index.RtgTaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount4Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount4Sum, Id = Index.RtgTaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount5Sum", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount5Sum, Id = Index.RtgTaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorAcctSet", ResourceType = typeof(POCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorAccountSet, Id = Index.VendorAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string VendorAccountSet { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSetDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorAccountSetDescription", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.VendorAccountSetDescription, Id = Index.VendorAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteLines
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitNoteLine> CreditDebitNoteLines { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteComments
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitNoteComment> CreditDebitNoteComments { get; set; }

        /// <summary>
        /// Gets or sets CrdrNoteAdditionalCosts
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CrdrNoteAdditionalCost> CrdrNoteAdditionalCosts { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteFunctions
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitNoteFunction> CreditDebitNoteFunctions { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteOptFields
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CreditDebitNoteOptField> CreditDebitNoteOptFields { get; set; }

        /// <summary>
        /// Gets or sets CrdrNoteCostDistributions
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CrdrNoteCostDistribution> CrdrNoteCostDistributions { get; set; }

        /// <summary>
        /// Gets or sets CrdrAddCostsSuperView List
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<CrdrAddCostsSuperview> CrdrAddCostsSuperViewList { get; set; }

        [IgnoreExportImport]
        public IEnumerable<SelectList> FromDocumentList { get; set; }

        [IgnoreExportImport]
        [IsMvcSpecific]
        public IDictionary<string, object> Attributes { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Address1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address1", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address1, Id = Index.Address1, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address1 { get; set; }

        /// <summary>
        /// Gets or sets Address2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address2", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address2, Id = Index.Address2, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets Address3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address3", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address3, Id = Index.Address3, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address3 { get; set; }

        /// <summary>
        /// Gets or sets Address4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address4", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address4, Id = Index.Address4, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets ContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactPhone", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactFax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactFax { get; set; }

        /// <summary>
        /// Gets or sets ContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactEmail", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactEmail { get; set; }

        #region Newly added properties for Finder
        /// <summary>
        /// To get the string of Autotaxcalculationonsave property
        /// </summary>
        [IgnoreExportImport]
        public string AutotaxcalculationonsaveString
        {
            get
            {
                return EnumUtility.GetStringValue(Autotaxcalculationonsave);
            }
        }

        /// <summary>
        /// To get the string of Completed property
        /// </summary>
        [IgnoreExportImport]
        public string CompletedString
        {
            get
            {
                return EnumUtility.GetStringValue(Completed);
            }
        }

        /// <summary>
        /// To get the string of FiscalPeriod property
        /// </summary>
        [IgnoreExportImport]
        public string FiscalPeriodString
        {
            get
            {
                return EnumUtility.GetStringValue(FiscalPeriod);
            }
        }

        /// <summary>
        /// To get the string of TransactionType property
        /// </summary>
        [IgnoreExportImport]
        public string TransactionTypeString
        {
            get
            {
                return EnumUtility.GetStringValue(TransactionType);
            }
        }

        /// <summary>
        /// To get the string of FromDocument property
        /// </summary>
        [IgnoreExportImport]
        public string FromDocumentString
        {
            get
            {
                return EnumUtility.GetStringValue(FromDocument);
            }
        }

        /// <summary>
        /// To get the string of VendorExists property
        /// </summary>
        [IgnoreExportImport]
        public string VendorExistsString
        {
            get
            {
                return EnumUtility.GetStringValue(VendorExists);
            }
        }

        /// <summary>
        /// To get the string of RateOperation property
        /// </summary>
        [IgnoreExportImport]
        public string RateOperationString
        {
            get
            {
                return EnumUtility.GetStringValue(RateOperation);
            }
        }

        /// <summary>
        /// To get the string of RateOverridden property
        /// </summary>
        [IgnoreExportImport]
        public string RateOverriddenString
        {
            get
            {
                return EnumUtility.GetStringValue(RateOverridden);
            }
        }

        /// <summary>
        /// To get the string of PredecessorsRateOperation property
        /// </summary>
        [IgnoreExportImport]
        public string PredecessorsRateOperationString
        {
            get
            {
                return EnumUtility.GetStringValue(PredecessorsRateOperation);
            }
        }

        /// <summary>
        /// To get the string of PredecessorsRateOverridden property
        /// </summary>
        [IgnoreExportImport]
        public string PredecessorsRateOverriddenString
        {
            get
            {
                return EnumUtility.GetStringValue(PredecessorsRateOverridden);
            }
        }

        /// <summary>
        /// To get the string of TaxcalculationIspending property
        /// </summary>
        [IgnoreExportImport]
        public string TaxcalculationIspendingString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxcalculationIspending);
            }
        }

        /// <summary>
        /// To get the string of SubjectTo1099CPRSReporting property
        /// </summary>
        [IgnoreExportImport]
        public string SubjectTo1099CPRSReportingString
        {
            get
            {
                return EnumUtility.GetStringValue(SubjectTo1099CprsReporting);
            }
        }

        /// <summary>
        /// To get the string of DocumentLocked property
        /// </summary>
        [IgnoreExportImport]
        public string DocumentLockedString
        {
            get
            {
                return EnumUtility.GetStringValue(DocumentLocked);
            }
        }

        /// <summary>
        /// To get the string of IsDocumentDeletable property
        /// </summary>
        [IgnoreExportImport]
        public string IsDocumentDeletableString
        {
            get
            {
                return EnumUtility.GetStringValue(IsDocumentDeletable);
            }
        }

        /// <summary>
        /// To get the string of ExchangeRateExists property
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeRateExistsString
        {
            get
            {
                return EnumUtility.GetStringValue(ExchangeRateExists);
            }
        }

        /// <summary>
        /// To get the string of HasDetails property
        /// </summary>
        [IgnoreExportImport]
        public string HasDetailsString
        {
            get
            {
                return EnumUtility.GetStringValue(HasDetails);
            }
        }

        /// <summary>
        /// To get the string of Command property
        /// </summary>
        [IgnoreExportImport]
        public string CommandString
        {
            get
            {
                return EnumUtility.GetStringValue(Command);
            }
        }

        /// <summary>
        /// To get the string of ProrationVersion property
        /// </summary>
        [IgnoreExportImport]
        public string ProrationVersionString
        {
            get
            {
                return EnumUtility.GetStringValue(ProrationVersion);
            }
        }

        /// <summary>
        /// To get the string of HasRetainage property
        /// </summary>
        [IgnoreExportImport]
        public string HasRetainageString
        {
            get
            {
                return EnumUtility.GetStringValue(HasRetainage);
            }
        }

        /// <summary>
        /// To get the string of RetainageExchangeRate property
        /// </summary>
        [IgnoreExportImport]
        public string RetainageExchangeRateString
        {
            get
            {
                return EnumUtility.GetStringValue(RetainageExchangeRate);
            }
        }

        /// <summary>
        /// To get the string of RetainageBase property
        /// </summary>
        [IgnoreExportImport]
        public string RetainageBaseString
        {
            get
            {
                return EnumUtility.GetStringValue(RetainageBase);
            }
        }

        /// <summary>
        /// To get the string of JobRelated property
        /// </summary>
        [IgnoreExportImport]
        public string JobRelatedString
        {
            get
            {
                return EnumUtility.GetStringValue(JobRelated);
            }
        }

        /// <summary>
        /// To get the string of TaxReportingRateOperation property
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOperationString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxReportingRateOperation);
            }
        }

        /// <summary>
        /// To get the string of TaxReportingRateOperation property
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOverriddenString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxReportingRateOverridden);
            }
        }

        /// <summary>
        /// To get the string of PredTaxReportingRateOper property
        /// </summary>
        [IgnoreExportImport]
        public string PredTaxReportingRateOperString
        {
            get
            {
                return EnumUtility.GetStringValue(PredTaxReportingRateOper);
            }
        }

        /// <summary>
        /// To get the string of PredTaxReportingRateOverrd property
        /// </summary>
        [IgnoreExportImport]
        public string PredTaxReportingRateOverrdString
        {
            get
            {
                return EnumUtility.GetStringValue(PredTaxReportingRateOverrd);
            }
        }

        /// <summary>
        /// To get the string of TaxReportingExchRateExists property
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingExchRateExistsString
        {
            get
            {
                return EnumUtility.GetStringValue(TaxReportingExchRateExists);
            }
        }

        /// <summary>
        /// To get the string of ReportRetainageTax property
        /// </summary>
        [IgnoreExportImport]
        public string ReportRetainageTaxString
        {
            get
            {
                return EnumUtility.GetStringValue(ReportRetainageTax);
            }
        }

        /// <summary>
        /// To get the string of WarnOnRetainageTaxShift property
        /// </summary>
        [IgnoreExportImport]
        public string WarnOnRetainageTaxShiftString
        {
            get
            {
                return EnumUtility.GetStringValue(WarnOnRetainageTaxShift);
            }
        }
        #endregion

        #region Properties Added for Security

        /// <summary>
        /// Gets or Sets CrdrNoteEntrySecurity
        /// </summary>
        [IgnoreExportImport]
        public CrdrNoteEntrySecurity CrdrNoteEntrySecurity { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether [fiscal period lock warning].
        /// </summary>
        /// <value>
        /// <c>true</c> if [fiscal period lock warning]; otherwise, <c>false</c>.
        /// </value>
        [IgnoreExportImport]
        public bool FiscalPeriodLockWarning { get; set; }

        #endregion
    }
}
