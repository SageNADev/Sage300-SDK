/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Usings

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for PurchaseOrder Template
    /// </summary>
    public partial class Template : ModelBase
    {
        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [Key]
        [Display(Name = "Template", ResourceType = typeof(POCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets TemplateDescription
        /// </summary>
        [Display(Name = "TemplateDesc", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateDescription, Id = Index.TemplateDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TemplateDescription { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderType
        /// </summary>
        [Display(Name = "POType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PurchaseOrderType, Id = Index.PurchaseOrderType, FieldType = EntityFieldType.Int, Size = 2)]
        public PurchaseOrderType PurchaseOrderType { get; set; }


        /// <summary>
        /// Get the string of PurchaseOrderType property, UI Property
        /// </summary>
        [IgnoreExportImport]
        public string PurchaseOrderTypeString
        {
            get { return EnumUtility.GetStringValue(PurchaseOrderType); }
        }
        /// <summary>
        /// Gets or sets FOBPoint
        /// </summary>
        [Display(Name = "FOBPoint", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FOBPoint, Id = Index.FOBPoint, FieldType = EntityFieldType.Char, Size = 60)]
        public string FOBPoint { get; set; }

        /// <summary>
        /// Gets or sets OnHold
        /// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool OnHold { get; set; }

        /// <summary>
        /// Get the string of OnHold property,UI Property
        /// </summary>
        [IgnoreExportImport]
        public string OnHoldString
        {
            get
            {
                var result = OnHold ? Enums.OnHold.Yes : Enums.OnHold.No;
                return EnumUtility.GetStringValue(result);
            }
        }

        /// <summary>
        /// Gets or sets ShipToLocation
        /// </summary>
        [Display(Name = "ShipToLocation", ResourceType = typeof(POCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets BillToLocation
        /// </summary>
        [Display(Name = "BillToLocation", ResourceType = typeof(POCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToLocation, Id = Index.BillToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillToLocation { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [Display(Name = "Description", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [Display(Name = "Reference", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ShipVia
        /// </summary>
        [Display(Name = "Shipvia", ResourceType = typeof(POCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipVia, Id = Index.ShipVia, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipVia { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [Key]
        [Display(Name = "TaxGroup", ResourceType = typeof(POCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TermsCode
        /// </summary>
        [Display(Name = "Terms", ResourceType = typeof(POCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets ShipViaName
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ShipviaDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaName, Id = Index.ShipViaName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaName { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDescription
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TermsDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TermsCodeDescription, Id = Index.TermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocationDescription
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ShipToLocationDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToLocationDescription, Id = Index.ShipToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets BillToLocationDescription
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "BillToLocationDescription", ResourceType = typeof(TemplatesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToLocationDescription, Id = Index.BillToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxGroupCurrency, Id = Index.TaxGroupCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxGroupCurrency { get; set; }

    }
}
