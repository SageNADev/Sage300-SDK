// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Vendor Contract Cost Base Unit
     /// </summary>
     public partial class VendorContractCostBaseUnit : ModelBase
     {
          /// <summary>
          /// Gets or sets Item Number
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ItemNumber { get; set; }

          /// <summary>
          /// Gets or sets Vendor
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
          public string Vendor { get; set; }

          /// <summary>
          /// Gets or sets Unit Of Measure
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "UnitOfMeasure", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string UnitOfMeasure { get; set; }

          /// <summary>
          /// Gets or sets Conversion Factor To Stocking
          /// </summary>
          [Display(Name = "ConversionFactorToStocking", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.ConversionFactorToStocking, Id = Index.ConversionFactorToStocking, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal ConversionFactorToStocking { get; set; }

          /// <summary>
          /// Gets or sets Base Amount
          /// </summary>
          [Display(Name = "BaseAmount", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.BaseAmount, Id = Index.BaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal BaseAmount { get; set; }

          /// <summary>
          /// Gets or sets Default Unit Of Measure
          /// </summary>
          [Display(Name = "DefaultUnitOfMeasure", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DefaultUnitOfMeasure, Id = Index.DefaultUnitOfMeasure, FieldType = EntityFieldType.Bool, Size = 2)]
          public DefaultUnitOfMeasure DefaultUnitOfMeasure { get; set; }

          /// <summary>
          /// Gets or sets SerialNumber - Unique key for grid rows
          /// </summary>
          [IgnoreExportImport]
          public long SerialNumber { get; set; }

          /// <summary>
          /// Get the string value of Default Unit Of Measure
          /// </summary>
          [IgnoreExportImport]
          public string DefaultUnitOfMeasureString
          {
              get { return EnumUtility.GetStringValue(DefaultUnitOfMeasure); }
          }

     }
}
