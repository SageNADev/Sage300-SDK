// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Additional Cost Optional Field
     /// </summary>
     public partial class AdditionalCostOptionalField : ModelBase
     {
          /// <summary>
          /// Gets or sets Additional Cost
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "AdditionalCost", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.AdditionalCost, Id = Index.AdditionalCost, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
         public string AdditionalCost {get; set;}

          /// <summary>
          /// Gets or sets Optional Field
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))] 
          [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string OptionalField {get; set;}

          /// <summary>
          /// Gets or sets Value
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Value", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
         public string Value {get; set;}

          /// <summary>
          /// Gets or sets Type
          /// </summary>
         [Display(Name = "Type", ResourceType = typeof(POCommonResx))]  
         [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
         public Enums.Type Type {get; set;}

          /// <summary>
          /// Gets or sets Length
          /// </summary>
         [Display(Name = "Length", ResourceType = typeof(OptionalFieldResx))] 
         [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
         public int Length {get; set;}

          /// <summary>
          /// Gets or sets Decimals
          /// </summary>
         [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldResx))] 
         [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
         public int Decimals {get; set;}

          /// <summary>
          /// Gets or sets Allow Blank
          /// </summary>
         [Display(Name = "AllowBlank", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
         public AllowBlank AllowBlank {get; set;}

          /// <summary>
          /// Gets or sets Validate
          /// </summary>
         [Display(Name = "Validate", ResourceType = typeof(OptionalFieldResx))]
         [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
         public Validate Validate { get; set; }

          /// <summary>
          /// Gets or sets Value Set
          /// </summary>
         [Display(Name = "ValueSet", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
         public ValueSet ValueSet {get; set;}

          /// <summary>
          /// Gets or sets Typed Value Field Index
          /// </summary>
         [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
         public long TypedValueFieldIndex {get; set;}

          /// <summary>
          /// Gets or sets Text Value
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "TextValue", ResourceType = typeof(AdditionalCostsResx))]
         [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
         public string TextValue {get; set;}

          /// <summary>
          /// Gets or sets Amount Value
          /// </summary>
         [Display(Name = "AmountValue", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
         public decimal AmountValue {get; set;}

          /// <summary>
          /// Gets or sets Number Value
          /// </summary>
         [Display(Name = "NumberValue", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
         public decimal NumberValue {get; set;}

          /// <summary>
          /// Gets or sets Integer Value
          /// </summary>
         [Display(Name = "IntegerValue", ResourceType = typeof(AdditionalCostsResx))]
         [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
         public long IntegerValue {get; set;}

          /// <summary>
          /// Gets or sets Yes Or No Value
          /// </summary>
         [Display(Name = "YesNoValue", ResourceType = typeof(AdditionalCostsResx))]
         [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
         public YesNoValue YesNoValue {get; set;}

          /// <summary>
          /// Gets or sets Date Value
          /// </summary>
         [Display(Name = "DateValue", ResourceType = typeof(AdditionalCostsResx))]
         [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
         public DateTime? DateValue {get; set;}

          /// <summary>
          /// Gets or sets Time Value
          /// </summary>
         [Display(Name = "TimeValue", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
         public DateTime? TimeValue { get; set; }

          /// <summary>
          /// Gets or sets Optional Field Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalFieldDescription", ResourceType = typeof(AdditionalCostsResx))] 
         [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
         public string OptionalFieldDescription {get; set;}

          /// <summary>
          /// Gets or sets Value Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DefaultValueDescription", ResourceType = typeof(AdditionalCostsResx))]
         [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
         public string ValueDescription { get; set; }

          /// <summary>
          /// Gets or sets Line Number
          /// </summary>
          /// <value>The Line Number.</value>
          [IgnoreExportImport]
          public long SerialNumber { get; set; }

          /// <summary>
          /// Gets  ValueSet String
          /// </summary>
          /// <value>The Value Set String</value>
         [IgnoreExportImport]
         public string ValueSetString
         {
             get { return EnumUtility.GetStringValue(ValueSet); }
         }

     }
}
