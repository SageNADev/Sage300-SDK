// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for PurchaseOrderFunction
    /// </summary>
    public partial class PurchaseOrderFunction : ModelBase
    {
        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets SequenceToRetrieve
        /// </summary>
        [ViewField(Name = Fields.SequenceToRetrieve, Id = Index.SequenceToRetrieve, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal SequenceToRetrieve { get; set; }

        /// <summary>
        /// Gets or sets RequisitionNumber
        /// </summary>
        [Display(Name = "RequisitionNumber", ResourceType = typeof(POCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RequisitionNumber, Id = Index.RequisitionNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string RequisitionNumber { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [Display(Name = "PONumber", ResourceType = typeof(POCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [Display(Name = "Template", ResourceType = typeof(POCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public int Function { get; set; }

        /// <summary>
        /// Gets or sets UseBlankVendors
        /// </summary>
        [ViewField(Name = Fields.UseBlankVendors, Id = Index.UseBlankVendors, FieldType = EntityFieldType.Bool, Size = 2)]
        public UseBlankVendors UseBlankVendors { get; set; }

        /// <summary>
        /// Gets or sets UseICVendor
        /// </summary>
        [ViewField(Name = Fields.UseICVendor, Id = Index.UseICVendor, FieldType = EntityFieldType.Int, Size = 2)]
        public UseICVendor UseICVendor { get; set; }

        /// <summary>
        /// Gets or sets HeaderSequence
        /// </summary>
        [ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal HeaderSequence { get; set; }

        /// <summary>
        /// Gets or sets LineSequence
        /// </summary>
        [ViewField(Name = Fields.LineSequence, Id = Index.LineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineSequence { get; set; }

    }
}
