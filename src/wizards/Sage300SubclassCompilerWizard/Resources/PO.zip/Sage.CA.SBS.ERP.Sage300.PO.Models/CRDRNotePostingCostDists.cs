// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for CRDRNotePostingCostDists
    /// </summary>
    public partial class CrdrNotePostingCostDists : ModelBase
    {
        /// <summary>
        /// Gets or sets HeaderSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal HeaderSequence { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteCostSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CreditDebitNoteCostSequence, Id = Index.CreditDebitNoteCostSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteCostSequence { get; set; }

        /// <summary>
        /// Gets or sets LineSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LineSequence, Id = Index.LineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineSequence { get; set; }

        /// <summary>
        /// Gets or sets OperationToPost
        /// </summary>
        [ViewField(Name = Fields.OperationToPost, Id = Index.OperationToPost, FieldType = EntityFieldType.Int, Size = 2)]
        public int OperationToPost { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

    }
}
