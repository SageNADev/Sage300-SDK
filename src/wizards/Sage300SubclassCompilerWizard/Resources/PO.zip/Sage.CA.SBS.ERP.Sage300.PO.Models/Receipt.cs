// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of properties for Receipt
    /// </summary>
    public partial class Receipt : ModelBase
    {
        #region Constructor

        /// <summary>
        /// Constructor for Receipt
        /// </summary>
        public Receipt()
        {
            ReceiptOptionalFields = new EnumerableResponse<ReceiptOptionalField>();
            ReceiptLines=new EnumerableResponse<ReceiptLine>();
            ReceiptPurchaseOrders= new EnumerableResponse<ReceiptPurchaseOrder>();
            DetailOptionalFieldData = new EnumerableResponse<ReceiptDetailOptionalField>();
            DetailAdditionalCostOptionalFieldData = new  EnumerableResponse<ReceiptDetailOptionalField>();

        }

        #endregion
        /// <summary>
        /// Gets or sets the purchase order HDR opt fields.
        /// </summary>
        /// <value>
        /// The purchase order HDR opt fields.
        /// </value>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptDetailOptionalField> DetailOptionalFieldData { get; set; }
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptDetailOptionalField> DetailAdditionalCostOptionalFieldData { get; set; }

        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets NextLineSequence
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NextLineSequence, Id = Index.NextLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextLineSequence { get; set; }

        /// <summary>
        /// Gets or sets Lines
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLinesProrated
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfLinesProrated, Id = Index.NumberOfLinesProrated, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfLinesProrated { get; set; }

        /// <summary>
        /// Gets or sets LinesComplete
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LinesComplete, Id = Index.LinesComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesComplete { get; set; }

        /// <summary>
        /// Gets or sets Costs
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Costs, Id = Index.Costs, FieldType = EntityFieldType.Long, Size = 4)]
        public long Costs { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCostsProrated
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfCostsProrated, Id = Index.NumberOfCostsProrated, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfCostsProrated { get; set; }

        /// <summary>
        /// Gets or sets CostsComplete
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.CostsComplete, Id = Index.CostsComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostsComplete { get; set; }

        /// <summary>
        /// Gets or sets Vendors
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Vendors, Id = Index.Vendors, FieldType = EntityFieldType.Long, Size = 4)]
        public long Vendors { get; set; }

        /// <summary>
        /// Gets or sets VendorsCompleted
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorsCompleted, Id = Index.VendorsCompleted, FieldType = EntityFieldType.Long, Size = 4)]
        public long VendorsCompleted { get; set; }

        /// <summary>
        /// Gets or sets VendorsInvoiced
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorsInvoiced, Id = Index.VendorsInvoiced, FieldType = EntityFieldType.Long, Size = 4)]
        public long VendorsInvoiced { get; set; }

        /// <summary>
        /// Gets or sets LinesTaxCalculationSees
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.LinesTaxCalculationSees, Id = Index.LinesTaxCalculationSees, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesTaxCalculationSees { get; set; }

        /// <summary>
        /// Gets or sets ExtraneousLineCount
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtraneousLineCount, Id = Index.ExtraneousLineCount, FieldType = EntityFieldType.Long, Size = 4)]
        public long ExtraneousLineCount { get; set; }

        /// <summary>
        /// Gets or sets AutoTaxCalculationOnSave
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Autotaxcalculationonsave", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.AutoTaxCalculationOnSave, Id = Index.AutoTaxCalculationOnSave, FieldType = EntityFieldType.Bool, Size = 2)]
        public AutoTaxCalculationOnSave AutoTaxCalculationOnSave { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Printed", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Printed Printed { get; set; }

        /// <summary>
        /// Gets or sets Invoiced
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Invoiced, Id = Index.Invoiced, FieldType = EntityFieldType.Bool, Size = 2)]
        public Invoiced Invoiced { get; set; }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

        /// <summary>
        /// Gets or sets DateCompleted
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

        /// <summary>
        /// Gets or sets LastPostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPostingDate { get; set; }

        /// <summary>
        /// Gets or sets DATE
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TemplateCode", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets FOBPoint
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FOBPoint", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FobPoint, Id = Index.FobPoint, FieldType = EntityFieldType.Char, Size = 60)]
        public string FobPoint { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets VendorExists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Address1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address1", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address1, Id = Index.Address1, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address1 { get; set; }

        /// <summary>
        /// Gets or sets Address2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address2", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address2, Id = Index.Address2, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets Address3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address3", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address3, Id = Index.Address3, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address3 { get; set; }

        /// <summary>
        /// Gets or sets Address4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Address4", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Address4, Id = Index.Address4, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ZipPostalCode", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets TermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TermsCode", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TermsCode, Id = Index.TermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TermsCode { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PurchaseOrderNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets InvoiceNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "InvoiceNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.InvoiceNumber, Id = Index.InvoiceNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string InvoiceNumber { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptDescription", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ShipVia
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Shipvia", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ShipVia, Id = Index.ShipVia, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipVia { get; set; }
        
        /// <summary>
        /// Gets or sets ShipViaName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipViaName", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipViaName, Id = Index.ShipViaName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaName { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateMatchType
        /// </summary>
        [Display(Name = "RateMatchType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RateMatchType, Id = Index.RateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateMatchType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlaces
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DecimalPlaces, Id = Index.DecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets Total
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Total", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Total, Id = Index.Total, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Total { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCosts
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.AdditionalCosts, Id = Index.AdditionalCosts, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdditionalCosts { get; set; }

        /// <summary>
        /// Gets or sets QuantityReceived
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.QuantityReceived, Id = Index.QuantityReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReceived { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1
        /// </summary>
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2
        /// </summary>
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3
        /// </summary>
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4
        /// </summary>
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5
        /// </summary>
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets NetOfTax
        /// </summary>
        [Display(Name = "NetofTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NetOfTax, Id = Index.NetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTax { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded
        /// </summary>
        [Display(Name = "TaxIncluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxIncluded, Id = Index.TaxIncluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded
        /// </summary>
        [Display(Name = "TaxExcluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxExcluded, Id = Index.TaxExcluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded { get; set; }

        /// <summary>
        /// Gets or sets TotalTax
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TotalTax, Id = Index.TotalTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTax { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxRecoverable
        /// </summary>
        [Display(Name = "TotalTaxRecoverable", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalTaxRecoverable, Id = Index.TotalTaxRecoverable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxRecoverable { get; set; }

        /// <summary>
        /// Gets or sets Total Tax Expensed
        /// </summary>
        [Display(Name = "TotalTaxExpensed", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TotalTaxExpensed, Id = Index.TotalTaxExpensed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxExpensed { get; set; }

        /// <summary>
        /// Gets or sets Total Tax Allocated
        /// </summary>
        [Display(Name = "TotalTaxAllocated", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TotalTaxAllocated, Id = Index.TotalTaxAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAllocated { get; set; }

        /// <summary>
        /// Gets or sets ManualProrationTotal
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ManualProrationTotal, Id = Index.ManualProrationTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ManualProrationTotal { get; set; }

        /// <summary>
        /// Gets or sets ManualToProrate
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ManualToProrate, Id = Index.ManualToProrate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ManualToProrate { get; set; }

        /// <summary>
        /// Gets or sets ConversionSourceAmount
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ConversionSourceAmount, Id = Index.ConversionSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets ConversionFunctionalAmount
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ConversionFunctionalAmount, Id = Index.ConversionFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets MultiplePurchaseOrders
        /// </summary>
        [Display(Name = "MultiplePurchaseOrders", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.MultiplePurchaseOrders, Id = Index.MultiplePurchaseOrders, FieldType = EntityFieldType.Bool, Size = 2)]
        public MultiplePurchaseOrders MultiplePurchaseOrders { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrders
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PurchaseOrders, Id = Index.PurchaseOrders, FieldType = EntityFieldType.Long, Size = 4)]
        public long PurchaseOrders { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Email", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets ContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactPhone", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactFax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactFax { get; set; }

        /// <summary>
        /// Gets or sets ContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactEmail", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactEmail { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercentage
        /// </summary>
        [Display(Name = "DiscountPercentage", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ProrationVersion
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ProrationVersion, Id = Index.ProrationVersion, FieldType = EntityFieldType.Int, Size = 2)]
        public ProrationVersion ProrationVersion { get; set; }
        
        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets BillToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToLocation", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.BillToLocation, Id = Index.BillToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillToLocation { get; set; }

        /// <summary>
        /// Gets or sets BillToLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToLocationDescription", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToLocationDescription, Id = Index.BillToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToAddress1, Id = Index.BillToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToAddress2, Id = Index.BillToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToAddress3, Id = Index.BillToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToAddress4, Id = Index.BillToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets BillToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCity", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToCity, Id = Index.BillToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCity { get; set; }

        /// <summary>
        /// Gets or sets BillToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToStateProvince", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToStateProvince, Id = Index.BillToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets BillToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToZipPostalCode", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToZipPostalCode, Id = Index.BillToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string BillToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets BillToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCountry", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToCountry, Id = Index.BillToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCountry { get; set; }

        /// <summary>
        /// Gets or sets BillToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToPhoneNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToPhoneNumber, Id = Index.BillToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToFaxNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToFaxNumber, Id = Index.BillToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContact", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToContact, Id = Index.BillToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToContact { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocationDescription", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToLocationDescription, Id = Index.ShipToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToAddress1, Id = Index.ShipToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToAddress2, Id = Index.ShipToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToAddress3, Id = Index.ShipToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToAddress4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToAddress4, Id = Index.ShipToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets ShipToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToCity", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToCity, Id = Index.ShipToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCity { get; set; }

        /// <summary>
        /// Gets or sets ShipToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToStateProvince", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToStateProvince, Id = Index.ShipToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets ShipToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToZipPostalCode", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToZipPostalCode, Id = Index.ShipToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ShipToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToCountry", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToCountry, Id = Index.ShipToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// Gets or sets ShipToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToPhone", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToPhoneNumber, Id = Index.ShipToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToFax", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToFaxNumber, Id = Index.ShipToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContact", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToContact, Id = Index.ShipToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToContact { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsExchangeRate
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsExchangeRate, Id = Index.PredecessorsExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PredecessorsExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsRateType, Id = Index.PredecessorsRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PredecessorsRateType { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsRateDate, Id = Index.PredecessorsRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PredecessorsRateDate { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateOperation
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsRateOperation, Id = Index.PredecessorsRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public PredecessorsRateOperation PredecessorsRateOperation { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateOverridden
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsRateOverridden, Id = Index.PredecessorsRateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public PredecessorsRateOverridden PredecessorsRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets BillToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToEmail", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToEmail, Id = Index.BillToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToEmail { get; set; }

        /// <summary>
        /// Gets or sets BillToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactPhone", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToContactPhone, Id = Index.BillToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactFax", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToContactFax, Id = Index.BillToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactEmail", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.BillToContactEmail, Id = Index.BillToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToEmail", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToEmail, Id = Index.ShipToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactPhone", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToContactPhone, Id = Index.ShipToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactFax", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToContactFax, Id = Index.ShipToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToContactEmail", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ShipToContactEmail, Id = Index.ShipToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets RateTypeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RateTypeDescription, Id = Index.RateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets LastReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LastReceiptNumber, Id = Index.LastReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string LastReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets RcpDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RcpDate, Id = Index.RcpDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RcpDate { get; set; }

        /// <summary>
        /// Gets or sets NumberOfPostedReceipts
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NumberOfPostedReceipts, Id = Index.NumberOfPostedReceipts, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfPostedReceipts { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TermsCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "TermsCodeDescription", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.TermsCodeDescription, Id = Index.TermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TermsCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateTypeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredecessorsRateTypeDesc, Id = Index.PredecessorsRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PredecessorsRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets NetOfTaxSum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NetOfTaxSum, Id = Index.NetOfTaxSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTaxSum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded1Sum, Id = Index.TaxIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded2Sum, Id = Index.TaxIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded3Sum, Id = Index.TaxIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded4Sum, Id = Index.TaxIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded5Sum, Id = Index.TaxIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount1Sum, Id = Index.TaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount2Sum, Id = Index.TaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount3Sum, Id = Index.TaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount4Sum, Id = Index.TaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAllocatedAmount5Sum, Id = Index.TaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount1Sum, Id = Index.TaxRecoverableAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount2Sum, Id = Index.TaxRecoverableAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount3Sum, Id = Index.TaxRecoverableAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount4Sum, Id = Index.TaxRecoverableAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRecoverableAmount5Sum, Id = Index.TaxRecoverableAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount1Sum, Id = Index.TaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount2Sum, Id = Index.TaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount3Sum, Id = Index.TaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount4Sum, Id = Index.TaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExpenseAmount5Sum, Id = Index.TaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAllocated1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TotalTaxAllocated1, Id = Index.TotalTaxAllocated1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAllocated1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxIncluded1, Id = Index.TaxIncluded1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded1
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded1, Id = Index.TaxExcluded1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded1 { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedTax
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TotalUnbalancedTax, Id = Index.TotalUnbalancedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedTax { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedAllocatedTax
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TotalUnbalancedAllocatedTax, Id = Index.TotalUnbalancedAllocatedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedAllocatedTax { get; set; }

        /// <summary>
        /// Gets or sets UnbalancedManualProrationAmt
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UnbalancedManualProrationAmt, Id = Index.UnbalancedManualProrationAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnbalancedManualProrationAmt { get; set; }

        /// <summary>
        /// Gets or sets Subtotal 
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReceiptSubtotal", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.Subtotal, Id = Index.Subtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Subtotal { get; set; }

        /// <summary>
        /// Gets or sets TaxcalculationIspending
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxcalculationIspending, Id = Index.TaxcalculationIspending, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxcalculationIspending TaxcalculationIspending { get; set; }

        /// <summary>
        /// Gets or sets DocumentLocked
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DocumentLocked, Id = Index.DocumentLocked, FieldType = EntityFieldType.Bool, Size = 2)]
        public DocumentLocked DocumentLocked { get; set; }

        /// <summary>
        /// Gets or sets IsDocumentDeletable
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.IsDocumentDeletable, Id = Index.IsDocumentDeletable, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsDocumentDeletable IsDocumentDeletable { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateExists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExchangeRateExists, Id = Index.ExchangeRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public ExchangeRateExists ExchangeRateExists { get; set; }

        /// <summary>
        /// Gets or sets HasDetails
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "HasDetails", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.HasDetails, Id = Index.HasDetails, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasDetails HasDetails { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmountSum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DiscountAmountSum, Id = Index.DiscountAmountSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmountSum { get; set; }

        /// <summary>
        /// Gets or sets NetExtendedCost
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.NetExtendedCost, Id = Index.NetExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DayEndNumber, Id = Index.DayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageTermsCode", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTermsCode, Id = Index.RetainageTermsCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string RetainageTermsCode { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedLines
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.JobRelatedLines, Id = Index.JobRelatedLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedLines { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedCosts
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.JobRelatedCosts, Id = Index.JobRelatedCosts, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedCosts { get; set; }

        /// <summary>
        /// Gets or sets BillableLines
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.BillableLines, Id = Index.BillableLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long BillableLines { get; set; }

        /// <summary>
        /// Gets or sets CostBillingRatesProrated
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.CostBillingRatesProrated, Id = Index.CostBillingRatesProrated, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostBillingRatesProrated { get; set; }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets RetainageTermsCodeDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTermsCodeDescription, Id = Index.RetainageTermsCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RetainageTermsCodeDescription { get; set; }
        
        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets RetainageBase
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageBase, Id = Index.RetainageBase, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageBase RetainageBase { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets UnretainedTotal
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.UnretainedTotal, Id = Index.UnretainedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnretainedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxReportingCurrency, Id = Index.TaxReportingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrency { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateSpread
        /// </summary>
        [Display(Name = "TaxReportingRateSpread", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateSpread, Id = Index.TaxReportingRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingRateSpread { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateMatchType
        /// </summary>
        [Display(Name = "TaxReportingRateMatchType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateMatchType, Id = Index.TaxReportingRateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateMatchType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation
        /// </summary>
        [Display(Name = "TaxReportingRateOperation", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingRateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOverridden
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingRateOverridden, Id = Index.TaxReportingRateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingRateOverridden TaxReportingRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingDecimalPlaces
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingDecimalPlaces, Id = Index.TaxReportingDecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingDecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount1, Id = Index.TaxReportingIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount2, Id = Index.TaxReportingIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount3, Id = Index.TaxReportingIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount4, Id = Index.TaxReportingIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount5, Id = Index.TaxReportingIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount1, Id = Index.TaxReportingExcludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount2, Id = Index.TaxReportingExcludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount3, Id = Index.TaxReportingExcludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount4, Id = Index.TaxReportingExcludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount5, Id = Index.TaxReportingExcludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount1
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount1, Id = Index.TaxReportingExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount2
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount2, Id = Index.TaxReportingExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount3
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount3, Id = Index.TaxReportingExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount4
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount4, Id = Index.TaxReportingExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount5
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount5, Id = Index.TaxReportingExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingExchRate
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredTaxReportingExchRate, Id = Index.PredTaxReportingExchRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PredTaxReportingExchRate { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredTaxReportingRateType, Id = Index.PredTaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PredTaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredTaxReportingRateDate, Id = Index.PredTaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PredTaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateOper
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredTaxReportingRateOper, Id = Index.PredTaxReportingRateOper, FieldType = EntityFieldType.Int, Size = 2)]
        public PredTaxReportingRateOper PredTaxReportingRateOper { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateOverrd
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredTaxReportingRateOverrd, Id = Index.PredTaxReportingRateOverrd, FieldType = EntityFieldType.Bool, Size = 2)]
        public PredTaxReportingRateOverrd PredTaxReportingRateOverrd { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchRateExists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExchRateExists, Id = Index.TaxReportingExchRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingExchRateExists TaxReportingExchRateExists { get; set; }

        /// <summary>
        /// Gets or sets DerivedTaxReportingExchRate
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DerivedTaxReportingExchRate, Id = Index.DerivedTaxReportingExchRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal DerivedTaxReportingExchRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingCurrencyDesc, Id = Index.TaxReportingCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateTypeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingRateTypeDesc, Id = Index.TaxReportingRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets PredTaxRepRateTypeDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.PredTaxRepRateTypeDesc, Id = Index.PredTaxRepRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PredTaxRepRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotalAmount
        /// </summary>
        [Display(Name = "TaxReportingTotalAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingTotalAmount, Id = Index.TaxReportingTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount, Id = Index.TaxReportingIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount, Id = Index.TaxReportingExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmount
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmount, Id = Index.TaxReportingRecoverableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmount { get; set; }

        /// <summary>
        /// Gets or sets Tax Reporting Expensed Amount
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount", ResourceType = typeof(ReceiptEntryResx))]
        public decimal TaxReportingExpensedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount, Id = Index.TaxReportingAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase1Sum, Id = Index.TaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase2Sum, Id = Index.TaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase3Sum, Id = Index.TaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase4Sum, Id = Index.TaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxBase5Sum, Id = Index.TaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount1Sum, Id = Index.TaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount2Sum, Id = Index.TaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount3Sum, Id = Index.TaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount4Sum, Id = Index.TaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxAmount5Sum, Id = Index.TaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded1Sum, Id = Index.TaxExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded2Sum, Id = Index.TaxExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded3Sum, Id = Index.TaxExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded4Sum, Id = Index.TaxExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxExcluded5Sum, Id = Index.TaxExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount1Sum, Id = Index.TaxReportingAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount2Sum, Id = Index.TaxReportingAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount3Sum, Id = Index.TaxReportingAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount4Sum, Id = Index.TaxReportingAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingAmount5Sum, Id = Index.TaxReportingAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded1Sum, Id = Index.TaxReportingIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded2Sum, Id = Index.TaxReportingIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded3Sum, Id = Index.TaxReportingIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded4Sum, Id = Index.TaxReportingIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingIncluded5Sum, Id = Index.TaxReportingIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded1Sum, Id = Index.TaxReportingExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded2Sum, Id = Index.TaxReportingExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded3Sum, Id = Index.TaxReportingExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded4Sum, Id = Index.TaxReportingExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxReportingExcluded5Sum, Id = Index.TaxReportingExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount1Sum, Id = Index.TaxRepAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount2Sum, Id = Index.TaxRepAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount3Sum, Id = Index.TaxRepAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount4Sum, Id = Index.TaxRepAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepAllocatedAmount5Sum, Id = Index.TaxRepAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt1Sum, Id = Index.TaxRepRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt2Sum, Id = Index.TaxRepRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt3Sum, Id = Index.TaxRepRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt4Sum, Id = Index.TaxRepRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepRecoverableAmt5Sum, Id = Index.TaxRepRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount1Sum, Id = Index.TaxRepExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount2Sum, Id = Index.TaxRepExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount3Sum, Id = Index.TaxRepExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount4Sum, Id = Index.TaxRepExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.TaxRepExpenseAmount5Sum, Id = Index.TaxRepExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets ReportRetainageTax
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ReportRetainageTax, Id = Index.ReportRetainageTax, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportRetainageTax ReportRetainageTax { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt1
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt1, Id = Index.RetainageTaxRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt2
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt2, Id = Index.RetainageTaxRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt3
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt3, Id = Index.RetainageTaxRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt4
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt4, Id = Index.RetainageTaxRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt5
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt5, Id = Index.RetainageTaxRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount1
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount1, Id = Index.RetainageTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount2
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount2, Id = Index.RetainageTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount3
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount3, Id = Index.RetainageTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount4
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount4, Id = Index.RetainageTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount5
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount5, Id = Index.RetainageTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount1, Id = Index.RetainageTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount2, Id = Index.RetainageTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount3, Id = Index.RetainageTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount4, Id = Index.RetainageTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount5, Id = Index.RetainageTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets WarnOnRetainageTaxShift
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.WarnOnRetainageTaxShift, Id = Index.WarnOnRetainageTaxShift, FieldType = EntityFieldType.Bool, Size = 2)]
        public WarnOnRetainageTaxShift WarnOnRetainageTaxShift { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxTotalAmount
        /// </summary>
        [Display(Name = "RetainageTaxTotalAmount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.RetainageTaxTotalAmount, Id = Index.RetainageTaxTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt1
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt1, Id = Index.TaxAmountPlusRtgTaxAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt2
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt2", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt2, Id = Index.TaxAmountPlusRtgTaxAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt3
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt3", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt3, Id = Index.TaxAmountPlusRtgTaxAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt4
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt4", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt4, Id = Index.TaxAmountPlusRtgTaxAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt5
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt5", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt5, Id = Index.TaxAmountPlusRtgTaxAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt5 { get; set; }

        [Display(Name = "CustomerTaxBase1", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase1, Id = Index.CustomerTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase1 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase2
        /// </summary>
        [Display(Name = "CustomerTaxBase2", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase2, Id = Index.CustomerTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase2 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase3
        /// </summary>
        [Display(Name = "CustomerTaxBase3", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase3, Id = Index.CustomerTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase3 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase4
        /// </summary>
        [Display(Name = "CustomerTaxBase4", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase4, Id = Index.CustomerTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase4 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTaxBase5
        /// /// </summary>
        [Display(Name = "CustomerTaxBase5", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxBase5, Id = Index.CustomerTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount1
        /// </summary>
        [Display(Name = "CustomerTaxAmount1", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount1, Id = Index.CustomerTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount1 { get; set; }
        /// <summary>
        /// Gets or sets CustomerTax Amount2
        /// </summary>
        [Display(Name = "CustomerTaxAmount2", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount2, Id = Index.CustomerTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount3
        /// </summary>
        [Display(Name = "CustomerTaxAmount3", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount3, Id = Index.CustomerTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount4
        /// </summary>
        [Display(Name = "CustomerTaxAmount4", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount4, Id = Index.CustomerTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTax Amount5
        /// </summary>
        [Display(Name = "CustomerTaxAmount5", ResourceType = typeof(InvoiceResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount5, Id = Index.CustomerTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAmount
        /// </summary>
        [Display(Name = "CustomerTaxAmount", ResourceType = typeof(POCommonResx))]
        //[ViewField(Name = Fields.CustomerTaxAmount, Id = Index.CustomerTaxAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CustomerTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets CustomerTaxAmount
        /// </summary>
        [Display(Name = "ExcludedTaxLessReverseCharge", ResourceType = typeof(POCommonResx))]
        //[ViewField(Name = Fields.ExcludedTaxLessReverseCharge, Id = Index.ExcludedTaxLessReverseCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxLessReverseCharge { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase1Sum, Id = Index.RetainageTaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase2Sum, Id = Index.RetainageTaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase3Sum, Id = Index.RetainageTaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase4Sum, Id = Index.RetainageTaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxBase5Sum, Id = Index.RetainageTaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount1Sum, Id = Index.RetainageTaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount2Sum, Id = Index.RetainageTaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount3Sum, Id = Index.RetainageTaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount4Sum, Id = Index.RetainageTaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RetainageTaxAmount5Sum, Id = Index.RetainageTaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt1Sum, Id = Index.RtgTaxRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt2Sum, Id = Index.RtgTaxRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt3Sum, Id = Index.RtgTaxRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt4Sum, Id = Index.RtgTaxRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt5Sum, Id = Index.RtgTaxRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount1Sum, Id = Index.RtgTaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount2Sum, Id = Index.RtgTaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount3Sum, Id = Index.RtgTaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount4Sum, Id = Index.RtgTaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxExpenseAmount5Sum, Id = Index.RtgTaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount1Sum, Id = Index.RtgTaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount2Sum, Id = Index.RtgTaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount3Sum, Id = Index.RtgTaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount4Sum, Id = Index.RtgTaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount5Sum, Id = Index.RtgTaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSet
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorAccountSet1", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.VendorAccountSet, Id = Index.VendorAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string VendorAccountSet { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSetDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [Display(Name = "VendorAccountDesc", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.VendorAccountSetDescription, Id = Index.VendorAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PostingDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// Gets or sets the receipt lines.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptLine> ReceiptLines { get; set; }

        /// <summary>
        /// Gets or sets the receipt comments.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptComment> ReceiptComments { get; set; }

        /// <summary>
        /// Gets or sets the receipt vendors.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptVendor> ReceiptVendors { get; set; }

        /// <summary>
        /// Gets or sets the receipt function.
        /// </summary>
        [IgnoreExportImport]
        public ReceiptFunction ReceiptFunction { get; set; }

        /// <summary>
        /// Gets or sets the receipt purchase orders.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptPurchaseOrder> ReceiptPurchaseOrders { get; set; }
        
        /// <summary>
        /// Gets or sets the receipt optional fields.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptOptionalField> ReceiptOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets the receipt cost distributions.
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReceiptCostDistribution> ReceiptCostDistributions { get; set; }

        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        [IgnoreExportImport]
        public short SessionWarnDays { get; set; }

        #region Properties for UI

        /// <summary>
        /// Gets the AutoTaxCalculationOnSave string
        /// </summary>
        [IgnoreExportImport]
        public string AutoTaxCalculationOnSaveString
        {
            get { return EnumUtility.GetStringValue(AutoTaxCalculationOnSave); }
        }

        /// <summary>
        /// Gets the Printed string
        /// </summary>
        [IgnoreExportImport]
        public string PrintedString
        {
            get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// Gets the Invoiced string
        /// </summary>
        [IgnoreExportImport]
        public string InvoicedString
        {
            get { return EnumUtility.GetStringValue(Invoiced); }
        }

        /// <summary>
        /// Gets the Completed string
        /// </summary>
        [IgnoreExportImport]
        public string CompletedString
        {
            get { return EnumUtility.GetStringValue(Completed); }
        }

        /// <summary>
        /// Gets the FiscalPeriod string
        /// </summary>
        [IgnoreExportImport]
        public string FiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(FiscalPeriod); }
        }

        /// <summary>
        /// Gets the VendorExists string
        /// </summary>
        [IgnoreExportImport]
        public string VendorExistsString
        {
            get { return EnumUtility.GetStringValue(VendorExists); }
        }

        /// <summary>
        /// Gets the RateOperation string
        /// </summary>
        [IgnoreExportImport]
        public string RateOperationString
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets the RateOverridden string
        /// </summary>
        [IgnoreExportImport]
        public string ReportRetainageTaxString
        {
            get { return EnumUtility.GetStringValue(ReportRetainageTax); }
        }

        /// <summary>
        /// Gets the RateOverridden string
        /// </summary>
        [IgnoreExportImport]
        public string RateOverriddenString
        {
            get { return EnumUtility.GetStringValue(RateOverridden); }
        }

        /// <summary>
        /// Gets the MultiplePurchaseOrders string
        /// </summary>
        [IgnoreExportImport]
        public string MultiplePurchaseOrdersString
        {
            get { return EnumUtility.GetStringValue(MultiplePurchaseOrders); }
        }

        /// <summary>
        /// Gets the ProrationVersion string
        /// </summary>
        [IgnoreExportImport]
        public string ProrationVersionString
        {
            get { return EnumUtility.GetStringValue(ProrationVersion); }
        }

        /// <summary>
        /// Gets the HasRetainage string
        /// </summary>
        [IgnoreExportImport]
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets the RetainageExchangeRate string
        /// </summary>
        [IgnoreExportImport]
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Gets the PredecessorsRateOperation string
        /// </summary>
        public string PredecessorsRateOperationString
        {
            get { return EnumUtility.GetStringValue(PredecessorsRateOperation); }
        }

        /// <summary>
        /// Gets the PredecessorsRateOverridden string
        /// </summary>
        [IgnoreExportImport]
        public string PredecessorsRateOverriddenString
        {
            get { return EnumUtility.GetStringValue(PredecessorsRateOverridden); }
        }

        /// <summary>
        /// Gets the TaxcalculationIspending string
        /// </summary>
        [IgnoreExportImport]
        public string TaxcalculationIspendingString
        {
            get { return EnumUtility.GetStringValue(TaxcalculationIspending); }
        }

        /// <summary>
        /// Gets the DocumentLocked string
        /// </summary>
        [IgnoreExportImport]
        public string DocumentLockedString
        {
            get { return EnumUtility.GetStringValue(DocumentLocked); }
        }

        /// <summary>
        /// Gets the IsDocumentDeletable string
        /// </summary>
        [IgnoreExportImport]
        public string IsDocumentDeletableString
        {
            get { return EnumUtility.GetStringValue(IsDocumentDeletable); }
        }

        /// <summary>
        /// Gets the ExchangeRateExists string
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeRateExistsString
        {
            get { return EnumUtility.GetStringValue(ExchangeRateExists); }
        }

        /// <summary>
        /// Gets the HasDetails string
        /// </summary>
        [IgnoreExportImport]
        public string HasDetailsString
        {
            get { return EnumUtility.GetStringValue(HasDetails); }
        }

        /// <summary>
        /// Gets the Command string
        /// </summary>
        [IgnoreExportImport]
        public string CommandString
        {
            get { return EnumUtility.GetStringValue(Command); }
        }

        /// <summary>
        /// Gets the JobRelated string
        /// </summary>
        [IgnoreExportImport]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets the RetainageBase string
        /// </summary>
        [IgnoreExportImport]
        public string RetainageBaseString
        {
            get { return EnumUtility.GetStringValue(RetainageBase); }
        }

        /// <summary>
        /// Gets the TaxReportingRateOperatioDaten string
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOperationString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOperation); }
        }

        /// <summary>
        /// Gets the TaxReportingRateOverridden string
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOverriddenString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOverridden); }
        }

        /// <summary>
        /// Gets the PredTaxReportingRateOper string
        /// </summary>
        [IgnoreExportImport]
        public string PredTaxReportingRateOperString
        {
            get { return EnumUtility.GetStringValue(PredTaxReportingRateOper); }
        }

        /// <summary>
        /// Gets the PredTaxReportingRateOverrd string
        /// </summary>
        [IgnoreExportImport]
        public string PredTaxReportingRateOverrdString
        {
            get { return EnumUtility.GetStringValue(PredTaxReportingRateOverrd); }
        }

        /// <summary>
        /// Gets the TaxReportingExchRateExists string
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingExchRateExistsString
        {
            get { return EnumUtility.GetStringValue(TaxReportingExchRateExists); }
        }

        /// <summary>
        /// Gets the WarnOnRetainageTaxShift string
        /// </summary>
        [IgnoreExportImport]
        public string WarnOnRetainageTaxShiftString
        {
            get { return EnumUtility.GetStringValue(WarnOnRetainageTaxShift); }
        }

        /// <summary>
        /// Gets a value indicating whether this instance is locked invoiced.
        /// </summary>
        [IgnoreExportImport]
        public bool IsLockedInvoiced
        {
            get { return DocumentLocked.Equals(DocumentLocked.Yes) || Invoiced.Equals(Invoiced.Yes); }
        }

        /// <summary>
        /// To check if vendor is null/empty
        /// </summary>
        [IgnoreExportImport]
        public bool IsVendorSet
        {
            get
            {
                if (String.IsNullOrEmpty(Vendor))
                {
                    return false;
                }
                return true;
            }
        }

        #endregion

    }

    /// <summary>
    ///  Receipt Active application to check
    /// </summary>
    public class ReceiptActiveApplication : ModelBase
    {
        /// <summary>
        /// Checks YP Is Installed
        /// </summary>
        [IgnoreExportImport]
        public bool IsGlActive { get; set; }

        /// <summary>
        /// Checks IC Is Installed
        /// </summary>
        [IgnoreExportImport]
        public bool IsOeActive { get; set; }

        /// <summary>
        /// Checks OE Is Installed
        /// </summary>
        [IgnoreExportImport]
        public bool IsIcActive { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [have opt field license].
        /// </summary>
        [IgnoreExportImport]
        public bool HaveOptFldLicense { get; set; }

        /// <summary>
        /// Checks PM Is Installed
        /// </summary>
        [IgnoreExportImport]
        public bool IsPmActive { get; set; }

    }
}
