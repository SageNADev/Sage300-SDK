// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Partial class for Return Posting Line sLot
	/// </summary>
	public partial class ReturnPostingLinesLot : ModelBase
	{
		/// <summary>
		/// Gets or sets HeaderSequence
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal HeaderSequence { get; set; }

		/// <summary>
		/// Gets or sets CreditDebitNoteSequenceKey
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal CreditDebitNoteSequenceKey { get; set; }

		/// <summary>
		/// Gets or sets CreditDebitNoteLineSequence
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CreditDebitNoteLineSequence, Id = Index.CreditDebitNoteLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal CreditDebitNoteLineSequence { get; set; }

		/// <summary>
		/// Gets or sets LotNumber
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
		public string LotNumber { get; set; }

		/// <summary>
		/// Gets or sets OldQuantity
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OldQuantity, Id = Index.OldQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OldQuantity { get; set; }

		/// <summary>
		/// Gets or sets CurrentQuantity
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CurrentQuantity, Id = Index.CurrentQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal CurrentQuantity { get; set; }

		/// <summary>
		/// Gets or sets OldStockQuantity
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OldStockQuantity, Id = Index.OldStockQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal OldStockQuantity { get; set; }

		/// <summary>
		/// Gets or sets CurrentStockQuantity
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CurrentStockQuantity, Id = Index.CurrentStockQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal CurrentStockQuantity { get; set; }

		/// <summary>
		/// Gets or sets OperationToPost
		/// </summary>
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OperationToPost, Id = Index.OperationToPost, FieldType = EntityFieldType.Int, Size = 2)]
		public int OperationToPost { get; set; }
		
	}
}
