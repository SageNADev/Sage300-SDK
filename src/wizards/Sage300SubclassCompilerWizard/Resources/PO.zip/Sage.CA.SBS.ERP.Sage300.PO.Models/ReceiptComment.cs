// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of properties for ReceiptComment
    /// </summary>
    public partial class ReceiptComment : ModelBase
    {
        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets CommentIdentifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentIdentifier", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.CommentIdentifier, Id = Index.CommentIdentifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CommentIdentifier { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCommentSequence
        /// </summary>
        [Display(Name = "ReceiptCommentSequence", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptCommentSequence, Id = Index.ReceiptCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptCommentSequence { get; set; }

        /// <summary>
        /// Gets or sets StoredInDatabaseTable
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
        public StoredInDatabaseTable StoredInDatabaseTable { get; set; }

        /// <summary>
        /// Gets or sets LineType
        /// </summary>
        [Display(Name = "LineType", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comment { get; set; }
    }
}
