// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.AP.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for RequisitionDetailOpt.Field
     /// </summary>
     public partial class RequisitionDetailOptionalField : ModelBase
     {
          /// <summary>
          /// Gets or sets RequisitionSequenceKey
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "RequisitionSequenceKey", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.RequisitionSequenceKey, Id = Index.RequisitionSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal RequisitionSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal LineNumber {get; set;}

          /// <summary>
          /// Gets or sets OptionalField
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalField", ResourceType = typeof(CommonResx))]
          [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
          public string OptionalField {get; set;}

          /// <summary>
          /// Gets or sets Value
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "Value", ResourceType = typeof(APCommonResx))]
          [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
          public string Value {get; set;}

          /// <summary>
          /// Gets or sets Type
          /// </summary>
          [Display(Name = "Type", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
          public Enums.Type Type {get; set;}

          /// <summary>
          /// Gets or sets Length
          /// </summary>
          [Display(Name = "Length", ResourceType = typeof(APCommonResx))]
          [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
          public int Length {get; set;}

          /// <summary>
          /// Gets or sets Decimals
          /// </summary>    
          [Display(Name = "Decimals", ResourceType = typeof(APCommonResx))]     
          [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
          public int Decimals {get; set;}

          /// <summary>
          /// Gets or sets AllowBlank
          /// </summary>
          [Display(Name = "AllowBlank", ResourceType = typeof(RequisitionEntryResx))] 
          [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
          public AllowBlank AllowBlank {get; set;}

          /// <summary>
          /// Gets or sets Validate
          /// </summary>
          [Display(Name = "Validate", ResourceType = typeof(APCommonResx))] 
          [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
          public Validate Validate {get; set;}

          /// <summary>
          /// Gets or sets ValueSet
          /// </summary>
          [Display(Name = "ValueSet", ResourceType = typeof(RequisitionEntryResx))] 
          [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
          public ValueSet ValueSet {get; set;}

          /// <summary>
          /// Gets or sets TypedValueFieldIndex
          /// </summary>
          [Display(Name = "TypedValueFieldIndex", ResourceType = typeof(RequisitionEntryResx))] 
          [ViewField(Name = Fields.TypedValueFieldIndex, Id = Index.TypedValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
          public long TypedValueFieldIndex {get; set;}

          /// <summary>
          /// Gets or sets TextValue
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "TextValue", ResourceType = typeof(RequisitionEntryResx))] 
          [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60)]
          public string TextValue {get; set;}

          /// <summary>
          /// Gets or sets AmountValue
          /// </summary>
          [Display(Name = "AmountValue", ResourceType = typeof(RequisitionEntryResx))] 
          [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal AmountValue {get; set;}

          /// <summary>
          /// Gets or sets NumberValue
          /// </summary>
           [Display(Name = "NumberValue", ResourceType = typeof(RequisitionEntryResx))] 
          [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal NumberValue {get; set;}

          /// <summary>
          /// Gets or sets IntegerValue
          /// </summary>
           [Display(Name = "IntegerValue", ResourceType = typeof(RequisitionEntryResx))] 
          [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
          public long IntegerValue {get; set;}

          /// <summary>
          /// Gets or sets YesNoValue
          /// </summary>
          [Display(Name = "YesNoValue", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.YesNoValue, Id = Index.YesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
          public YesNoValue YesNoValue {get; set;}

          /// <summary>
          /// Gets or sets DateValue
          /// </summary>          
         // ReSharper disable once LocalizableElement
         [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DateValue", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime DateValue {get; set;}

          /// <summary>
          /// Gets or sets TimeValue
          /// </summary>
           [Display(Name = "TimeValue", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
          public DateTime TimeValue { get; set; }

          /// <summary>
          /// Gets or sets OptionalFieldDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "OptionalFieldDescription", ResourceType = typeof(RequisitionEntryResx))]
         [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
         public string OptionalFieldDescription {get; set;}

          /// <summary>
          /// Gets or sets DefaultValueDescription
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DefaultValueDescription", ResourceType = typeof(RequisitionEntryResx))]
          [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string DefaultValueDescription {get; set;}
     }
}
