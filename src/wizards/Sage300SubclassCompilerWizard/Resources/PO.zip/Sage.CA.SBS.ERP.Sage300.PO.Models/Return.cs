// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Return
    /// </summary>
    public partial class Return : ModelBase
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public Return()
        {
            ReturnLines = new EnumerableResponse<ReturnLine>();
            ReturnComments = new EnumerableResponse<ReturnComment>();
            ReturnLineLots = new EnumerableResponse<ReturnLineLot>();
            ReturnLineSerials = new EnumerableResponse<ReturnLineSerial>();
            ReturnFunctions = new EnumerableResponse<ReturnFunction>();
            OptionalFieldList = new EnumerableResponse<ReturnOptionalField>();
            DetailOptionalFieldList = new EnumerableResponse<ReturnOptionalField>();
        }

        /// <summary>
        /// Gets or sets ReturnSequenceKey
        /// </summary>
        [Key]
        [Display(Name = "ReturnSequenceKey", ResourceType = typeof(ReturnEntryResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets NextLineSequence
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NextLineSequence", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.NextLineSequence, Id = Index.NextLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextLineSequence { get; set; }

        /// <summary>
        /// Gets or sets Lines
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Lines", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets LinesComplete
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "LinesComplete", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.LinesComplete, Id = Index.LinesComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesComplete { get; set; }

        /// <summary>
        /// Gets or sets LinesTaxCalculationSees
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "LinesTaxCalculationSees", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.LinesTaxCalculationSees, Id = Index.LinesTaxCalculationSees, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesTaxCalculationSees { get; set; }

        /// <summary>
        /// Gets or sets ExtraneousLineCount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExtraneousLineCount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ExtraneousLineCount, Id = Index.ExtraneousLineCount, FieldType = EntityFieldType.Long, Size = 4)]
        public long ExtraneousLineCount { get; set; }

        /// <summary>
        /// Gets or sets Autotaxcalculationonsave
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "AutoTaxCalculationOnSave", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.AutoTaxCalculationOnSave, Id = Index.AutoTaxCalculationOnSave, FieldType = EntityFieldType.Bool, Size = 2)]
        public AutoTaxCalculationOnSave AutoTaxCalculationOnSave { get; set; }

        /// <summary>
        /// Gets or sets Printed
        /// </summary>
        [Display(Name = "Printed", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Printed Printed { get; set; }

        /// <summary>
        /// Gets or sets IsCredited
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.IsCredited, Id = Index.IsCredited, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsCredited IsCredited { get; set; }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

        /// <summary>
        /// Gets or sets DateCompleted
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DateCompleted", ResourceType = typeof(ReturnEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

        /// <summary>
        /// Gets or sets LastPostingDate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "LastPostingDate", ResourceType = typeof(ReturnEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastPostingDate { get; set; }

        /// <summary>
        /// Gets or sets LabelsPrinted
        /// </summary>
        [Display(Name = "LabelsPrinted", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.LabelsPrinted, Id = Index.LabelsPrinted, FieldType = EntityFieldType.Bool, Size = 2)]
        public LabelsPrinted LabelsPrinted { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLabels
        /// </summary>
        [Display(Name = "NumberofLabels", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NumberOfLabels, Id = Index.NumberOfLabels, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfLabels { get; set; }

        /// <summary>
        /// Gets or sets ReturnDate
        /// </summary>
        [Display(Name = "ReturnDate", ResourceType = typeof(POCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReturnDate, Id = Index.ReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReturnDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Display(Name = "FiscalYear", ResourceType = typeof(CommonResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReturnNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReturnNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReturnNumber, Id = Index.ReturnNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ReturnNumber { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TemplateCode", ResourceType = typeof(POCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorNumber", ResourceType = typeof(POCommonResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets VendorExists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Address1
        /// </summary>
        [Display(Name = "Address1", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Address1, Id = Index.Address1, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address1 { get; set; }

        /// <summary>
        /// Gets or sets Address2
        /// </summary>
        [Display(Name = "Address2", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Address2, Id = Index.Address2, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address2 { get; set; }

        /// <summary>
        /// Gets or sets Address3
        /// </summary>
        [Display(Name = "Address3", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Address3, Id = Index.Address3, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address3 { get; set; }

        /// <summary>
        /// Gets or sets Address4
        /// </summary>
        [Display(Name = "Address4", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Address4, Id = Index.Address4, FieldType = EntityFieldType.Char, Size = 60)]
        public string Address4 { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        [Display(Name = "StateProvince", ResourceType = typeof(POCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StateProvince, Id = Index.StateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets ZipPostalCode
        /// </summary>
        [Display(Name = "ZipPostalCode", ResourceType = typeof(POCommonResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ZipPostalCode, Id = Index.ZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Country
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        [Display(Name = "PhoneNumber", ResourceType = typeof(PurchaseOrderEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [Display(Name = "FaxNumber", ResourceType = typeof(PurchaseOrderEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumber
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(POCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptDate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReceiptDate", ResourceType = typeof(POCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptDate, Id = Index.ReceiptDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ReceiptDate { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PurchaseOrderSequenceKey", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PurchaseOrderNumber", ResourceType = typeof(POCommonResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderDate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PurchaseOrderDate", ResourceType = typeof(ReturnEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderDate, Id = Index.PurchaseOrderDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PurchaseOrderDate { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReturnDescription", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comment { get; set; }

        /// <summary>
        /// Gets or sets ShipVia
        /// </summary>
        [Display(Name = "Shipvia", ResourceType = typeof(POCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipVia, Id = Index.ShipVia, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipVia { get; set; }

        /// <summary>
        /// Gets or sets ShipViaName
        /// </summary>
        [Display(Name = "ShipViaName", ResourceType = typeof(POCommonResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipViaName, Id = Index.ShipViaName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipViaName { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateType
        /// </summary>
        [Display(Name = "RateType", ResourceType = typeof(POCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets RateMatchType
        /// </summary>
        [Display(Name = "RateMatchType", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RateMatchType, Id = Index.RateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int RateMatchType { get; set; }

        /// <summary>
        /// Gets or sets RateDate
        /// </summary>
        [Display(Name = "RateDate", ResourceType = typeof(POCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RateDate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets RateOverridden
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RateOverridden", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RateOverridden, Id = Index.RateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public RateOverridden RateOverridden { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlaces
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DecimalPlaces", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.DecimalPlaces, Id = Index.DecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int DecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExtendedWeight", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets ReturnCost
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReturnCost", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ReturnCost, Id = Index.ReturnCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReturnCost { get; set; }

        /// <summary>
        /// Gets or sets Total
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Total, Id = Index.Total, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Total { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets QuantityReturned
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "QuantityReturned", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityReturned, Id = Index.QuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup
        /// </summary>
        [Display(Name = "TaxGroup", ResourceType = typeof(POCommonResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1
        /// </summary>
        [Display(Name = "TaxAuthority1", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2
        /// </summary>
        [Display(Name = "TaxAuthority2", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3
        /// </summary>
        [Display(Name = "TaxAuthority3", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4
        /// </summary>
        [Display(Name = "TaxAuthority4", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5
        /// </summary>
        [Display(Name = "TaxAuthority5", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1
        /// </summary>
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2
        /// </summary>
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3
        /// </summary>
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4
        /// </summary>
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5
        /// </summary>
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets NetOfTax
        /// </summary>
        [Display(Name = "NetofTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NetOfTax, Id = Index.NetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTax { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded
        /// </summary>
        [Display(Name = "TaxIncluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxIncluded, Id = Index.TaxIncluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded
        /// </summary>
        [Display(Name = "TaxExcluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxExcluded, Id = Index.TaxExcluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded { get; set; }

        /// <summary>
        /// Gets or sets TotalTax
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TotalTax, Id = Index.TotalTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTax { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxRecoverable
        /// </summary>
        [Display(Name = "TotalTaxRecoverable", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TotalTaxRecoverable, Id = Index.TotalTaxRecoverable, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxRecoverable { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxExpensed
        /// </summary>
        [Display(Name = "TotalTaxExpensed", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TotalTaxExpensed, Id = Index.TotalTaxExpensed, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxExpensed { get; set; }

        /// <summary>
        /// Gets or sets TXALLOAMT
        /// </summary>
        [Display(Name = "TotalTaxAllocated", ResourceType = typeof(POCommonResx))]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.TXALLOAMT, Id = Index.TXALLOAMT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXALLOAMT { get; set; }

        /// <summary>
        /// Gets or sets ConversionSourceAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ConversionSourceAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ConversionSourceAmount, Id = Index.ConversionSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets ConversionFunctionalAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ConversionFunctionalAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ConversionFunctionalAmount, Id = Index.ConversionFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ConversionFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipToLocation { get; set; }

        /// <summary>
        /// Gets or sets ShipToLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocationDescription", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ShipToLocationDescription, Id = Index.ShipToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress1
        /// </summary>
        [Display(Name = "ShipToAddress1", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress1, Id = Index.ShipToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress2
        /// </summary>
        [Display(Name = "ShipToAddress2", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress2, Id = Index.ShipToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress3
        /// </summary>
        [Display(Name = "ShipToAddress3", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress3, Id = Index.ShipToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets ShipToAddress4
        /// </summary>
        [Display(Name = "ShipToAddress4", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToAddress4, Id = Index.ShipToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets ShipToCity
        /// </summary>
        [Display(Name = "ShipToCity", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCity, Id = Index.ShipToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCity { get; set; }

        /// <summary>
        /// Gets or sets ShipToStateProvince
        /// </summary>
        [Display(Name = "ShipToStateProvince", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToStateProvince, Id = Index.ShipToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets ShipToZipPostalCode
        /// </summary>
        [Display(Name = "ShipToZipPostalCode", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToZipPostalCode, Id = Index.ShipToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ShipToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets ShipToCountry
        /// </summary>
        [Display(Name = "ShipToCountry", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToCountry, Id = Index.ShipToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string ShipToCountry { get; set; }

        /// <summary>
        /// Gets or sets ShipToPhoneNumber
        /// </summary>
        [Display(Name = "ShipToPhoneNumber", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToPhoneNumber, Id = Index.ShipToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToFaxNumber
        /// </summary>
        [Display(Name = "ShipToFaxNumber", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToFaxNumber, Id = Index.ShipToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets ShipToContact
        /// </summary>
        [Display(Name = "ShipToContact", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContact, Id = Index.ShipToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string ShipToContact { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsExchangeRate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredecessorsExchangeRate", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.PredecessorsExchangeRate, Id = Index.PredecessorsExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PredecessorsExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateType
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredecessorsRateType", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredecessorsRateType, Id = Index.PredecessorsRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PredecessorsRateType { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateDate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RateDate", ResourceType = typeof(POCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredecessorsRateDate, Id = Index.PredecessorsRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PredecessorsRateDate { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateOperation
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredecessorsRateOperation", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.PredecessorsRateOperation, Id = Index.PredecessorsRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public PredecessorsRateOperation PredecessorsRateOperation { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateOverridden
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredecessorsRateOverridden", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.PredecessorsRateOverridden, Id = Index.PredecessorsRateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public PredecessorsRateOverridden PredecessorsRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxClass1Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxClass2Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxClass3Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxClass4Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxClass5Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority1Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority1Description, Id = Index.TaxAuthority1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority2Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority2Description, Id = Index.TaxAuthority2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority3Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority3Description, Id = Index.TaxAuthority3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority4Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority4Description, Id = Index.TaxAuthority4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5Description
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAuthority5Description", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxAuthority5Description, Id = Index.TaxAuthority5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthority5Description { get; set; }

        /// <summary>
        /// Gets or sets CurrencyDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets RateTypeDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RateTypeDescription, Id = Index.RateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string RateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets PredecessorsRateTypeDescript
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredecessorsRateTypeDescript, Id = Index.PredecessorsRateTypeDescript, FieldType = EntityFieldType.Char, Size = 60)]
        public string PredecessorsRateTypeDescript { get; set; }

        /// <summary>
        /// Gets or sets NetOfTaxSum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NetOfTaxSum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.NetOfTaxSum, Id = Index.NetOfTaxSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTaxSum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxIncluded1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxIncluded1Sum, Id = Index.TaxIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxIncluded2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxIncluded2Sum, Id = Index.TaxIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxIncluded3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxIncluded3Sum, Id = Index.TaxIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxIncluded4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxIncluded4Sum, Id = Index.TaxIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxIncluded5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxIncluded5Sum, Id = Index.TaxIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1Sum, Id = Index.TaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2Sum, Id = Index.TaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3Sum, Id = Index.TaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4Sum, Id = Index.TaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5Sum, Id = Index.TaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1Sum, Id = Index.TaxRecoverableAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2Sum, Id = Index.TaxRecoverableAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3Sum, Id = Index.TaxRecoverableAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4Sum, Id = Index.TaxRecoverableAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5Sum, Id = Index.TaxRecoverableAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1Sum, Id = Index.TaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2Sum, Id = Index.TaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3Sum, Id = Index.TaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4Sum, Id = Index.TaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5Sum, Id = Index.TaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TCALLOAMT
        /// </summary>
        [IgnoreExportImport]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.TCALLOAMT, Id = Index.TCALLOAMT, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TCALLOAMT { get; set; }

        /// <summary>
        /// Gets or sets TCINCLUDED
        /// </summary>
        [IgnoreExportImport]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.TCINCLUDED, Id = Index.TCINCLUDED, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TCINCLUDED { get; set; }

        /// <summary>
        /// Gets or sets TCEXCLUDED
        /// </summary>
        [IgnoreExportImport]
        // ReSharper disable once InconsistentNaming
        [ViewField(Name = Fields.TCEXCLUDED, Id = Index.TCEXCLUDED, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TCEXCLUDED { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedTax
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TotalUnbalancedTax", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TotalUnbalancedTax, Id = Index.TotalUnbalancedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedTax { get; set; }

        /// <summary>
        /// Gets or sets TotalUnbalancedAllocatedTax
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TotalUnbalancedAllocatedTax", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TotalUnbalancedAllocatedTax, Id = Index.TotalUnbalancedAllocatedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalUnbalancedAllocatedTax { get; set; }

        /// <summary>
        /// Gets or sets UnbalancedManualProrationAmou
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "UnbalancedManualProrationAmou", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.UnbalancedManualProrationAmou, Id = Index.UnbalancedManualProrationAmou, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnbalancedManualProrationAmou { get; set; }

        /// <summary>
        /// Gets or sets Subtotal
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Subtotal, Id = Index.Subtotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Subtotal { get; set; }

        /// <summary>
        /// Gets or sets TaxcalculationIspending
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxcalculationIspending", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxcalculationIspending, Id = Index.TaxcalculationIspending, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxcalculationIspending TaxcalculationIspending { get; set; }

        /// <summary>
        /// Gets or sets DocumentLocked
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DocumentLocked", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.DocumentLocked, Id = Index.DocumentLocked, FieldType = EntityFieldType.Bool, Size = 2)]
        public DocumentLocked DocumentLocked { get; set; }

        /// <summary>
        /// Gets or sets IsDocumentDeletable
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IsDocumentDeletable", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.IsDocumentDeletable, Id = Index.IsDocumentDeletable, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsDocumentDeletable IsDocumentDeletable { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateExists
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExchangeRateExists", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ExchangeRateExists, Id = Index.ExchangeRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public ExchangeRateExists ExchangeRateExists { get; set; }

        /// <summary>
        /// Gets or sets HasDetails
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "HasDetails", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.HasDetails, Id = Index.HasDetails, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasDetails HasDetails { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.Email, Id = Index.Email, FieldType = EntityFieldType.Char, Size = 50)]
        public string Email { get; set; }

        /// <summary>
        /// Gets or sets ContactPhone
        /// </summary>
        [Display(Name = "ContactPhone", ResourceType = typeof(POCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactPhone, Id = Index.ContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ContactFax
        /// </summary>
        [Display(Name = "ContactFax", ResourceType = typeof(POCommonResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactFax, Id = Index.ContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ContactFax { get; set; }

        /// <summary>
        /// Gets or sets ContactEmail
        /// </summary>
        [Display(Name = "ContactEmail", ResourceType = typeof(POCommonResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ContactEmail, Id = Index.ContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ContactEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToEmail
        /// </summary>
        [Display(Name = "ShipToEmail", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToEmail, Id = Index.ShipToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToEmail { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactPhone
        /// </summary>
        [Display(Name = "ShipToContactPhone", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactPhone, Id = Index.ShipToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactFax
        /// </summary>
        [Display(Name = "ShipToContactFax", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactFax, Id = Index.ShipToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string ShipToContactFax { get; set; }

        /// <summary>
        /// Gets or sets ShipToContactEmail
        /// </summary>
        [Display(Name = "ShipToContactEmail", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ShipToContactEmail, Id = Index.ShipToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ShipToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercentage
        /// </summary>
        [Display(Name = "DiscountPercentage", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmountSum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DiscountAmountSum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.DiscountAmountSum, Id = Index.DiscountAmountSum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmountSum { get; set; }

        /// <summary>
        /// Gets or sets NetReturnCost
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NetReturnCost", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.NetReturnCost, Id = Index.NetReturnCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetReturnCost { get; set; }

        /// <summary>
        /// Gets or sets DayEndNumber
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DayEndNumber", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.DayEndNumber, Id = Index.DayEndNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long DayEndNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OptionalFields", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets ProrationVersion
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ProrationVersion", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ProrationVersion, Id = Index.ProrationVersion, FieldType = EntityFieldType.Int, Size = 2)]
        public ProrationVersion ProrationVersion { get; set; }

        /// <summary>
        /// Gets or sets HasRetainage
        /// </summary>
        [Display(Name = "HasRetainage", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
        public HasRetainage HasRetainage { get; set; }

        /// <summary>
        /// Gets or sets RetainageExchangeRate
        /// </summary>
        [Display(Name = "RetainageExchangeRate", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageExchangeRate RetainageExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RetainageBase
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageBase", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageBase, Id = Index.RetainageBase, FieldType = EntityFieldType.Int, Size = 2)]
        public RetainageBase RetainageBase { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets JobRelatedLines
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "JobRelatedLines", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.JobRelatedLines, Id = Index.JobRelatedLines, FieldType = EntityFieldType.Long, Size = 4)]
        public long JobRelatedLines { get; set; }

        /// <summary>
        /// Gets or sets JobRelated
        /// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
        public JobRelated JobRelated { get; set; }

        /// <summary>
        /// Gets or sets UnretainedTotal
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "UnretainedTotal", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.UnretainedTotal, Id = Index.UnretainedTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal UnretainedTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrency
        /// </summary>
        [Display(Name = "TaxReportingCurrency", ResourceType = typeof(POCommonResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingCurrency, Id = Index.TaxReportingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrency { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchangeRate
        /// </summary>
        [Display(Name = "TaxReportingExchangeRate", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExchangeRate, Id = Index.TaxReportingExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateSpread
        /// </summary>
        [Display(Name = "TaxReportingRateSpread", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateSpread, Id = Index.TaxReportingRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingRateSpread { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType
        /// </summary>
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateMatchType
        /// </summary>
        [Display(Name = "TaxReportingRateMatchType", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateMatchType, Id = Index.TaxReportingRateMatchType, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingRateMatchType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate
        /// </summary>
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(ReturnEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation
        /// </summary>
        [Display(Name = "TaxReportingRateOperation", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingRateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOverridden
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingRateOverridden", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRateOverridden, Id = Index.TaxReportingRateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingRateOverridden TaxReportingRateOverridden { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingDecimalPlaces
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingDecimalPlaces", ResourceType = typeof(ReturnEntryResx))]

        [ViewField(Name = Fields.TaxReportingDecimalPlaces, Id = Index.TaxReportingDecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxReportingDecimalPlaces { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount1, Id = Index.TaxReportingIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount2, Id = Index.TaxReportingIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount3, Id = Index.TaxReportingIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount4, Id = Index.TaxReportingIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount5, Id = Index.TaxReportingIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount1, Id = Index.TaxReportingExcludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount2, Id = Index.TaxReportingExcludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount3, Id = Index.TaxReportingExcludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount4, Id = Index.TaxReportingExcludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount5, Id = Index.TaxReportingExcludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount1
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount1, Id = Index.TaxReportingExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount2
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount2, Id = Index.TaxReportingExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount3
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount3, Id = Index.TaxReportingExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount4
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount4, Id = Index.TaxReportingExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount5
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount5, Id = Index.TaxReportingExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingExchRate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingExchRate", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingExchRate, Id = Index.PredTaxReportingExchRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal PredTaxReportingExchRate { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateType
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingRateType", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredTaxReportingRateType, Id = Index.PredTaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PredTaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateDate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingRateDate", ResourceType = typeof(ReturnEntryResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredTaxReportingRateDate, Id = Index.PredTaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PredTaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateOper
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingRateOper", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingRateOper, Id = Index.PredTaxReportingRateOper, FieldType = EntityFieldType.Int, Size = 2)]
        public PredTaxReportingRateOper PredTaxReportingRateOper { get; set; }

        /// <summary>
        /// Gets or sets PredTaxReportingRateOverrd
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxReportingRateOverrd", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.PredTaxReportingRateOverrd, Id = Index.PredTaxReportingRateOverrd, FieldType = EntityFieldType.Bool, Size = 2)]
        public PredTaxReportingRateOverrd PredTaxReportingRateOverrd { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExchRateExists
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExchRateExists", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExchRateExists, Id = Index.TaxReportingExchRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public TaxReportingExchRateExists TaxReportingExchRateExists { get; set; }

        /// <summary>
        /// Gets or sets DerivedTaxReportingExchRate
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DerivedTaxReportingExchRate", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.DerivedTaxReportingExchRate, Id = Index.DerivedTaxReportingExchRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal DerivedTaxReportingExchRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyDesc
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingCurrencyDesc", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyDesc, Id = Index.TaxReportingCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateTypeDesc
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingRateTypeDesc", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxReportingRateTypeDesc, Id = Index.TaxReportingRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets PredTaxRepRateTypeDesc
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PredTaxRepRateTypeDesc", ResourceType = typeof(ReturnEntryResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredTaxRepRateTypeDesc, Id = Index.PredTaxRepRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string PredTaxRepRateTypeDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotalAmount
        /// </summary>
        [Display(Name = "TaxReportingTotalAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingTotalAmount, Id = Index.TaxReportingTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount, Id = Index.TaxReportingIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount, Id = Index.TaxReportingExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmount
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmount, Id = Index.TaxReportingRecoverableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount, Id = Index.TaxReportingExpensedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount, Id = Index.TaxReportingAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase1Sum, Id = Index.TaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase2Sum, Id = Index.TaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase3Sum, Id = Index.TaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase4Sum, Id = Index.TaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxBase5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxBase5Sum, Id = Index.TaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount1Sum, Id = Index.TaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount2Sum, Id = Index.TaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount3Sum, Id = Index.TaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount4Sum, Id = Index.TaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmount5Sum, Id = Index.TaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExcluded1Sum, Id = Index.TaxExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExcluded2Sum, Id = Index.TaxExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExcluded3Sum, Id = Index.TaxExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExcluded4Sum, Id = Index.TaxExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExcluded5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxExcluded5Sum, Id = Index.TaxExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1Sum, Id = Index.TaxReportingAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2Sum, Id = Index.TaxReportingAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3Sum, Id = Index.TaxReportingAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4Sum, Id = Index.TaxReportingAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5Sum, Id = Index.TaxReportingAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded1Sum, Id = Index.TaxReportingIncluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded2Sum, Id = Index.TaxReportingIncluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded3Sum, Id = Index.TaxReportingIncluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded4Sum, Id = Index.TaxReportingIncluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingIncluded5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncluded5Sum, Id = Index.TaxReportingIncluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded1Sum, Id = Index.TaxReportingExcluded1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded2Sum, Id = Index.TaxReportingExcluded2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded3Sum, Id = Index.TaxReportingExcluded3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded4Sum, Id = Index.TaxReportingExcluded4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcluded5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxReportingExcluded5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcluded5Sum, Id = Index.TaxReportingExcluded5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcluded5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount1Sum, Id = Index.TaxRepAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount2Sum, Id = Index.TaxRepAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount3Sum, Id = Index.TaxRepAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount4Sum, Id = Index.TaxRepAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepAllocatedAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepAllocatedAmount5Sum, Id = Index.TaxRepAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt1Sum, Id = Index.TaxRepRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt2Sum, Id = Index.TaxRepRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt3Sum, Id = Index.TaxRepRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt4Sum, Id = Index.TaxRepRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepRecoverableAmt5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepRecoverableAmt5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepRecoverableAmt5Sum, Id = Index.TaxRepRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount1Sum, Id = Index.TaxRepExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount2Sum, Id = Index.TaxRepExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount3Sum, Id = Index.TaxRepExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount4Sum, Id = Index.TaxRepExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets TaxRepExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRepExpenseAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxRepExpenseAmount5Sum, Id = Index.TaxRepExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRepExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets ReportRetainageTax
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReportRetainageTax", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ReportRetainageTax, Id = Index.ReportRetainageTax, FieldType = EntityFieldType.Int, Size = 2)]
        public ReportRetainageTax ReportRetainageTax { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt1
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt1, Id = Index.RetainageTaxRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt2
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt2, Id = Index.RetainageTaxRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt3
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt3, Id = Index.RetainageTaxRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt4
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt4, Id = Index.RetainageTaxRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt5
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt5, Id = Index.RetainageTaxRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount1
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount1, Id = Index.RetainageTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount2
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount2, Id = Index.RetainageTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount3
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount3, Id = Index.RetainageTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount4
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount4, Id = Index.RetainageTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount5
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount5, Id = Index.RetainageTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount1, Id = Index.RetainageTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount2, Id = Index.RetainageTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount3, Id = Index.RetainageTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount4, Id = Index.RetainageTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount5, Id = Index.RetainageTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets WarnOnRetainageTaxShift
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "WarnOnRetainageTaxShift", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.WarnOnRetainageTaxShift, Id = Index.WarnOnRetainageTaxShift, FieldType = EntityFieldType.Bool, Size = 2)]
        public WarnOnRetainageTaxShift WarnOnRetainageTaxShift { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxTotalAmount
        /// </summary>
        [Display(Name = "RetainageTaxTotalAmount", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxTotalAmount, Id = Index.RetainageTaxTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt1
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt1, Id = Index.TaxAmountPlusRtgTaxAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt2
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt2, Id = Index.TaxAmountPlusRtgTaxAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt3
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt3, Id = Index.TaxAmountPlusRtgTaxAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt4
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt4, Id = Index.TaxAmountPlusRtgTaxAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt5
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt5", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt5, Id = Index.TaxAmountPlusRtgTaxAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase1Sum, Id = Index.RetainageTaxBase1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase2Sum, Id = Index.RetainageTaxBase2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase3Sum, Id = Index.RetainageTaxBase3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase4Sum, Id = Index.RetainageTaxBase4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxBase5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase5Sum, Id = Index.RetainageTaxBase5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1Sum, Id = Index.RetainageTaxAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2Sum, Id = Index.RetainageTaxAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3Sum, Id = Index.RetainageTaxAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4Sum, Id = Index.RetainageTaxAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageTaxAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5Sum, Id = Index.RetainageTaxAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt1Sum, Id = Index.RtgTaxRecoverableAmt1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt2Sum, Id = Index.RtgTaxRecoverableAmt2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt3Sum, Id = Index.RtgTaxRecoverableAmt3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt4Sum, Id = Index.RtgTaxRecoverableAmt4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxRecoverableAmt5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxRecoverableAmt5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxRecoverableAmt5Sum, Id = Index.RtgTaxRecoverableAmt5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxRecoverableAmt5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount1Sum, Id = Index.RtgTaxExpenseAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount2Sum, Id = Index.RtgTaxExpenseAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount3Sum, Id = Index.RtgTaxExpenseAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount4Sum, Id = Index.RtgTaxExpenseAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxExpenseAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxExpenseAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxExpenseAmount5Sum, Id = Index.RtgTaxExpenseAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxExpenseAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount1Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount1Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount1Sum, Id = Index.RtgTaxAllocatedAmount1Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount1Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount2Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount2Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount2Sum, Id = Index.RtgTaxAllocatedAmount2Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount2Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount3Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount3Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount3Sum, Id = Index.RtgTaxAllocatedAmount3Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount3Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount4Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount4Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount4Sum, Id = Index.RtgTaxAllocatedAmount4Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount4Sum { get; set; }

        /// <summary>
        /// Gets or sets RtgTaxAllocatedAmount5Sum
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RtgTaxAllocatedAmount5Sum", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.RtgTaxAllocatedAmount5Sum, Id = Index.RtgTaxAllocatedAmount5Sum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RtgTaxAllocatedAmount5Sum { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSet
        /// </summary>
        [Display(Name = "VendorAcctSet", ResourceType = typeof(POCommonResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorAccountSet, Id = Index.VendorAccountSet, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string VendorAccountSet { get; set; }

        /// <summary>
        /// Gets or sets VendorAccountSetDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.VendorAccountSetDescription, Id = Index.VendorAccountSetDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorAccountSetDescription { get; set; }

        /// <summary>
        /// Gets or sets PostingDate
        /// </summary>
        [Display(Name = "PostingDate", ResourceType = typeof(POCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime PostingDate { get; set; }

        /// <summary>
        /// Gets or sets EnteredBy
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string EnteredBy { get; set; }

        /// <summary>
        /// Gets or sets BillToLocation
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToLocation", ResourceType = typeof(POCommonResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BillToLocation, Id = Index.BillToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string BillToLocation { get; set; }

        /// <summary>
        /// Gets or sets BillToLocationDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToLocationDescription", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToLocationDescription, Id = Index.BillToLocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToLocationDescription { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress1", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToAddress1, Id = Index.BillToAddress1, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress1 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress2", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToAddress2, Id = Index.BillToAddress2, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress2 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress3
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress3", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToAddress3, Id = Index.BillToAddress3, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress3 { get; set; }

        /// <summary>
        /// Gets or sets BillToAddress4
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToAddress4", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToAddress4, Id = Index.BillToAddress4, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToAddress4 { get; set; }

        /// <summary>
        /// Gets or sets BillToCity
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCity", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToCity, Id = Index.BillToCity, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCity { get; set; }

        /// <summary>
        /// Gets or sets BillToStateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToStateProvince", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToStateProvince, Id = Index.BillToStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToStateProvince { get; set; }

        /// <summary>
        /// Gets or sets BillToZipPostalCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToZipPostalCode", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToZipPostalCode, Id = Index.BillToZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string BillToZipPostalCode { get; set; }

        /// <summary>
        /// Gets or sets BillToCountry
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToCountry", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToCountry, Id = Index.BillToCountry, FieldType = EntityFieldType.Char, Size = 30)]
        public string BillToCountry { get; set; }

        /// <summary>
        /// Gets or sets BillToPhoneNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToPhoneNumber", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToPhoneNumber, Id = Index.BillToPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToPhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToFaxNumber
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToFaxNumber", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToFaxNumber, Id = Index.BillToFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToFaxNumber { get; set; }

        /// <summary>
        /// Gets or sets BillToContact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContact", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToContact, Id = Index.BillToContact, FieldType = EntityFieldType.Char, Size = 60)]
        public string BillToContact { get; set; }

        /// <summary>
        /// Gets or sets BillToEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToEmail", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToEmail, Id = Index.BillToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToEmail { get; set; }

        /// <summary>
        /// Gets or sets BillToContactPhone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactPhone", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToContactPhone, Id = Index.BillToContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactPhone { get; set; }

        /// <summary>
        /// Gets or sets BillToContactFax
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactFax", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToContactFax, Id = Index.BillToContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string BillToContactFax { get; set; }

        /// <summary>
        /// Gets or sets BillToContactEmail
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillToContactEmail", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.BillToContactEmail, Id = Index.BillToContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BillToContactEmail { get; set; }

        /// <summary>
        /// Gets or sets NextDetailNumber
        /// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int NextDetailNumber { get; set; }

        /// <summary>
        /// ReturnLines
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReturnLine> ReturnLines { get; set; }

        /// <summary>
        /// ReturnComments
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReturnComment> ReturnComments { get; set; }

        /// <summary>
        /// ReturnLineLots
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReturnLineLot> ReturnLineLots { get; set; }

        /// <summary>
        /// ReturnLineSerials
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReturnLineSerial> ReturnLineSerials { get; set; }

        /// <summary>
        /// ReturnFunctions
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReturnFunction> ReturnFunctions { get; set; }

        /// <summary>
        /// Optional Field - Tab
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ReturnOptionalField> OptionalFieldList { get; set; }

        /// <summary>
        /// Optional Field - Pop-Up
        /// </summary>
        [IgnoreExportImport]

        public EnumerableResponse<ReturnOptionalField> DetailOptionalFieldList { get; set; }

        #region UI Properties

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        [IgnoreExportImport]
        public string AutoTaxCalculationOnSaveString
        {
            get { return EnumUtility.GetStringValue(AutoTaxCalculationOnSave); }
        }

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        [IgnoreExportImport]
        public string PrintedString
        {
            get { return EnumUtility.GetStringValue(Printed); }
        }

        /// <summary>
        /// Gets IsCredited string value
        /// </summary>
        [IgnoreExportImport]
        public string IsCreditedString
        {
            get { return EnumUtility.GetStringValue(IsCredited); }
        }

        /// <summary>
        /// Gets Completed string value
        /// </summary>
        [IgnoreExportImport]
        public string CompletedString
        {
            get { return EnumUtility.GetStringValue(Completed); }
        }

        /// <summary>
        /// Gets LabelsPrinted string value
        /// </summary>
        [IgnoreExportImport]
        public string LabelsPrintedString
        {
            get { return EnumUtility.GetStringValue(LabelsPrinted); }
        }

        /// <summary>
        /// Gets FiscalPeriod string value
        /// </summary>
        [IgnoreExportImport]
        public string FiscalPeriodString
        {
            get { return EnumUtility.GetStringValue(FiscalPeriod); }
        }

        /// <summary>
        /// Gets VendorExists string value
        /// </summary>
        [IgnoreExportImport]
        public string VendorExistsString
        {
            get { return EnumUtility.GetStringValue(VendorExists); }
        }

        /// <summary>
        /// Gets RateOperation string value
        /// </summary>
        [IgnoreExportImport]
        public string RateOperationString
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets RateOverridden string value
        /// </summary>
        [IgnoreExportImport]
        public string RateOverriddenString
        {
            get { return EnumUtility.GetStringValue(RateOverridden); }
        }

        /// <summary>
        /// Gets PredecessorsRateOperation string value
        /// </summary>
        [IgnoreExportImport]
        public string PredecessorsRateOperationString
        {
            get { return EnumUtility.GetStringValue(PredecessorsRateOperation); }
        }

        /// <summary>
        /// Gets PredecessorsRateOverridden string value
        /// </summary>
        [IgnoreExportImport]
        public string PredecessorsRateOverriddenString
        {
            get { return EnumUtility.GetStringValue(PredecessorsRateOverridden); }
        }

        /// <summary>
        /// Gets TaxcalculationIspending string value
        /// </summary>
        [IgnoreExportImport]
        public string TaxcalculationIspendingString
        {
            get { return EnumUtility.GetStringValue(TaxcalculationIspending); }
        }

        /// <summary>
        /// Gets DocumentLocked string value
        /// </summary>
        [IgnoreExportImport]
        public string DocumentLockedString
        {
            get { return EnumUtility.GetStringValue(DocumentLocked); }
        }

        /// <summary>
        /// Gets IsDocumentDeletable string value
        /// </summary>
        [IgnoreExportImport]
        public string IsDocumentDeletableString
        {
            get { return EnumUtility.GetStringValue(IsDocumentDeletable); }
        }

        /// <summary>
        /// Gets ExchangeRateExists string value
        /// </summary>
        [IgnoreExportImport]
        public string ExchangeRateExistsString
        {
            get { return EnumUtility.GetStringValue(ExchangeRateExists); }
        }

        /// <summary>
        /// Gets HasDetails string value
        /// </summary>
        [IgnoreExportImport]
        public string HasDetailsString
        {
            get { return EnumUtility.GetStringValue(HasDetails); }
        }

        /// <summary>
        /// Gets Command string value
        /// </summary>
        [IgnoreExportImport]
        public string CommandString
        {
            get { return EnumUtility.GetStringValue(Command); }
        }

        /// <summary>
        /// Gets ProrationVersion string value
        /// </summary>
        [IgnoreExportImport]
        public string ProrationVersionString
        {
            get { return EnumUtility.GetStringValue(ProrationVersion); }
        }

        /// <summary>
        /// Gets HasRetainage string value
        /// </summary>
        [IgnoreExportImport]
        public string HasRetainageString
        {
            get { return EnumUtility.GetStringValue(HasRetainage); }
        }

        /// <summary>
        /// Gets RetainageExchangeRate string value
        /// </summary>
        [IgnoreExportImport]
        public string RetainageExchangeRateString
        {
            get { return EnumUtility.GetStringValue(RetainageExchangeRate); }
        }

        /// <summary>
        /// Gets RetainageBase string value
        /// </summary>
        [IgnoreExportImport]
        public string RetainageBaseString
        {
            get { return EnumUtility.GetStringValue(RetainageBase); }
        }

        /// <summary>
        /// Gets JobRelated string value
        /// </summary>
        [IgnoreExportImport]
        public string JobRelatedString
        {
            get { return EnumUtility.GetStringValue(JobRelated); }
        }

        /// <summary>
        /// Gets TaxReportingRateOperation string value
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOperationString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOperation); }
        }

        /// <summary>
        /// Gets TaxReportingRateOverridden string value
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingRateOverriddenString
        {
            get { return EnumUtility.GetStringValue(TaxReportingRateOverridden); }
        }

        /// <summary>
        /// Gets PredTaxReportingRateOper string value
        /// </summary>
        public string PredTaxReportingRateOperString
        {
            get { return EnumUtility.GetStringValue(PredTaxReportingRateOper); }
        }

        /// <summary>
        /// Gets PredTaxReportingRateOverrd string value
        /// </summary>
        [IgnoreExportImport]
        public string PredTaxReportingRateOverrdString
        {
            get { return EnumUtility.GetStringValue(PredTaxReportingRateOverrd); }
        }

        /// <summary>
        /// Gets TaxReportingExchRateExists string value
        /// </summary>
        [IgnoreExportImport]
        public string TaxReportingExchRateExistsString
        {
            get { return EnumUtility.GetStringValue(TaxReportingExchRateExists); }
        }

        /// <summary>
        /// Gets ReportRetainageTax string value
        /// </summary>
        [IgnoreExportImport]
        public string ReportRetainageTaxString
        {
            get { return EnumUtility.GetStringValue(ReportRetainageTax); }
        }

        /// <summary>
        /// Gets WarnOnRetainageTaxShift string value
        /// </summary>
        [IgnoreExportImport]
        public string WarnOnRetainageTaxShiftString
        {
            get { return EnumUtility.GetStringValue(WarnOnRetainageTaxShift); }
        }

        /// <summary>
        /// IsVendorSet
        /// </summary>
        [IgnoreExportImport]
        public bool IsVendorSet
        {
            get
            {
                if (String.IsNullOrEmpty(Vendor))
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        /// IsTaxGroupSet
        /// </summary>
        [IgnoreExportImport]
        public bool IsTaxGroupSet
        {
            get
            {
                if (String.IsNullOrEmpty(TaxGroup))
                {
                    return false;
                }
                return true;
            }
        }

        /// <summary>
        /// Gets or Sets Session date
        /// </summary>
        /// <value>The session date.</value>
        [IgnoreExportImport]
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or Sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        [IgnoreExportImport]
        public short SessionWarnDays { get; set; }

        #endregion

    }

    /// <summary>
    /// Return Access Class : 
    /// Holds User Access Values for the modules dependent on Return Entry
    /// </summary>
    public class ReturnAccess
    {
        /// <summary>
        /// Gets or Sets OE Active Status
        /// </summary>
        public bool IsOEActive { get; set; }

        /// <summary>
        /// Gets or Sets GL Active Status
        /// </summary>
        public bool IsGLActive { get; set; }

        /// <summary>
        /// Gets or Sets IC Active Status
        /// </summary>
        public bool IsICActive { get; set; }

        /// <summary>
        /// Gets or Sets PM Active Status
        /// </summary>
        public bool IsPMActive { get; set; }

        /// <summary>
        /// Gets or Sets Vendor Access Status
        /// </summary>
        public bool HasVendorAccess { get; set; }

        /// <summary>
        /// Gets or Sets History Access Status
        /// </summary>
        public bool HasHistoryAccess { get; set; }

        /// <summary>
        /// Gets or Sets Optional Field Access Status
        /// </summary>
        public bool HasOptFieldsAccess { get; set; }

        /// <summary>
        /// Gets or Sets Print Permission
        /// </summary>
        public bool HasPrintPermission { get; set; }

        /// <summary>
        /// Gets or Sets Transaction Optional Fields Rights
        /// </summary>
        public bool HasOptFieldsRights { get; set; }
    }
}
