//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Vendor Contract Cost
     /// </summary>
     public partial class VendorContractCost : ModelBase
     {
         public VendorContractCost()
         {
             VendorContractCostBaseUnits = new EnumerableResponse<VendorContractCostBaseUnit>();
             VendorContractCostSaleUnits = new EnumerableResponse<VendorContractCostSaleUnit>();
             VendorContractIncludedTaxes = new EnumerableResponse<VendorContractIncludedTax>();
         }

          /// <summary>
          /// Gets or sets Item Number
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string ItemNumber {get; set;}

          /// <summary>
          /// Gets or sets Vendor Number
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "VendorNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.VendorNumber, Id = Index.VendorNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
          public string VendorNumber {get; set;}

          /// <summary>
          /// Gets or sets Contract Cost Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ContractCostDescription", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.ContractCostDescription, Id = Index.ContractCostDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string ContractCostDescription {get; set;}

          /// <summary>
          /// Gets or sets Base Cost Type
          /// </summary>
          [Display(Name = "ColBCOSTTYPE", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.BaseCostType, Id = Index.BaseCostType, FieldType = EntityFieldType.Int, Size = 2)]
          public BaseCostType BaseCostType {get; set;}

          /// <summary>
          /// Gets or sets Base Cost Amount
          /// </summary>
          [Display(Name = "ColBAMOUNT", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.BaseCostAmount, Id = Index.BaseCostAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal BaseCostAmount {get; set;}

          /// <summary>
          /// Gets or sets Base Unit
          /// </summary>
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "BaseUnit", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.BaseUnit, Id = Index.BaseUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string BaseUnit {get; set;}

          /// <summary>
          /// Gets or sets Base Unit Conversion
          /// </summary>
          [Display(Name = "BaseUnitConversion", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.BaseUnitConversion, Id = Index.BaseUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal BaseUnitConversion {get; set;}

          /// <summary>
          /// Gets or sets Sale Cost Type
          /// </summary>
          [Display(Name = "ColSCOSTTYPE", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleCostType, Id = Index.SaleCostType, FieldType = EntityFieldType.Int, Size = 2)]
          public SaleCostType SaleCostType {get; set;}

          /// <summary>
          /// Gets or sets Sale Cost Based On
          /// </summary>
          [Display(Name = "ColSDEFUSING", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleCostBasedOn, Id = Index.SaleCostBasedOn, FieldType = EntityFieldType.Int, Size = 2)]
          public SaleCostBasedOn SaleCostBasedOn {get; set;}

          /// <summary>
          /// Gets or sets Percentage Of Base
          /// </summary>
          [Display(Name = "Percentage", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageOfBase, Id = Index.PercentageOfBase, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageOfBase {get; set;}

          /// <summary>
          /// Gets or sets Discount Amount
          /// </summary>
          [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountAmount {get; set;}

          /// <summary>
          /// Gets or sets Fixed Amount
          /// </summary>
          [Display(Name = "FixedAmount", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.FixedAmount, Id = Index.FixedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal FixedAmount {get; set;}

          /// <summary>
          /// Gets or sets Sale Unit
          /// </summary>
          [StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "SaleUnit", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleUnit, Id = Index.SaleUnit, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string SaleUnit {get; set;}

          /// <summary>
          /// Gets or sets Sale Unit Conversion
          /// </summary>
          [Display(Name = "SaleUnitConversion", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleUnitConversion, Id = Index.SaleUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal SaleUnitConversion {get; set;}

          /// <summary>
          /// Gets or sets Sale Starts
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ColSALESTART", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleStarts, Id = Index.SaleStarts, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime? SaleStarts {get; set;}

          /// <summary>
          /// Gets or sets Sale Ends
          /// </summary>
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ColSALEEND", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.SaleEnds, Id = Index.SaleEnds, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime? SaleEnds {get; set;}

          /// <summary>
          /// Gets or sets Discount Based On
          /// </summary>
          [Display(Name = "ColCOSTFMT", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountBasedOn, Id = Index.DiscountBasedOn, FieldType = EntityFieldType.Int, Size = 2)]
          public DiscountBasedOn DiscountBasedOn {get; set;}

          /// <summary>
          /// Gets or sets Rounding Method
          /// </summary>
          [Display(Name = "ColROUNDMETHD", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.RoundingMethod, Id = Index.RoundingMethod, FieldType = EntityFieldType.Int, Size = 2)]
          public RoundingMethod RoundingMethod { get; set; }

          /// <summary>
          /// Gets or sets Round To a Multiple Of
          /// </summary>
          [Display(Name = "ColROUNDAMT", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.RoundToMultipleOf, Id = Index.RoundToMultipleOf, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal RoundToMultipleOf { get; set; }

          /// <summary>
          /// Gets or sets Item Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "ItemDescription", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
          public string ItemDescription { get; set; }

          /// <summary>
          /// Gets or sets Formatted Item Number
          /// </summary>
          [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "FormattedItemNumber", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.FormattedItemNumber, Id = Index.FormattedItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
          public string FormattedItemNumber { get; set; }

          /// <summary>
          /// Gets or sets Unit Of Measure
          /// </summary>
          [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "UnitofMeasure", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
          public string UnitOfMeasure { get; set; }

          /// <summary>
          /// Gets or sets Calculated Sale Cost
          /// </summary>
          [Display(Name = "ColSAMOUNT", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.CalculatedSaleCost, Id = Index.CalculatedSaleCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal CalculatedSaleCost { get; set; }

          /// <summary>
          /// Gets or sets Vendor Currency
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "VendorCurrency", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.VendorCurrency, Id = Index.VendorCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
          public string VendorCurrency { get; set; }

          /// <summary>
          /// Gets or sets Vendor Name
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "VendorName", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
          public string Name { get; set; }
         
          /// <summary>
          /// Gets or sets Quantity Level 0
          /// </summary>
          [Display(Name = "QuantityLevel0", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel0, Id = Index.QuantityLevel0, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel0 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 1
          /// </summary>
          [Display(Name = "QuantityLevel1", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel1, Id = Index.QuantityLevel1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel1 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 2
          /// </summary>
          [Display(Name = "QuantityLevel2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel2, Id = Index.QuantityLevel2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel2 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 3
          /// </summary>
          [Display(Name = "QuantityLevel3", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel3, Id = Index.QuantityLevel3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel3 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 4
          /// </summary>
          [Display(Name = "QuantityLevel4", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel4, Id = Index.QuantityLevel4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel4 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 5
          /// </summary>
          [Display(Name = "QuantityLevel5", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel5, Id = Index.QuantityLevel5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel5 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 6
          /// </summary>
          [Display(Name = "QuantityLevel6", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel6, Id = Index.QuantityLevel6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel6 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 7
          /// </summary>
          [Display(Name = "QuantityLevel7", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel7, Id = Index.QuantityLevel7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel7 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 8
          /// </summary>
          [Display(Name = "QuantityLevel8", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel8, Id = Index.QuantityLevel8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel8 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Level 9
          /// </summary>
          [Display(Name = "QuantityLevel9", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityLevel9, Id = Index.QuantityLevel9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityLevel9 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 0
          /// </summary>
          [Display(Name = "PercentageLevel0", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel0, Id = Index.PercentageLevel0, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel0 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 1
          /// </summary>
          [Display(Name = "PercentageLevel1", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel1, Id = Index.PercentageLevel1, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel1 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 2
          /// </summary>
          [Display(Name = "PercentageLevel2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel2, Id = Index.PercentageLevel2, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel2 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 3
          /// </summary>
          [Display(Name = "PercentageLevel3", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel3, Id = Index.PercentageLevel3, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel3 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 4
          /// </summary>
          [Display(Name = "PercentageLevel4", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel4, Id = Index.PercentageLevel4, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel4 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 5
          /// </summary>
          [Display(Name = "PercentageLevel5", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel5, Id = Index.PercentageLevel5, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel5 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 6
          /// </summary>
          [Display(Name = "PercentageLevel6", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel6, Id = Index.PercentageLevel6, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel6 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 7
          /// </summary>
          [Display(Name = "PercentageLevel7", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel7, Id = Index.PercentageLevel7, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel7 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 8
          /// </summary>
          [Display(Name = "PercentageLevel8", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel8, Id = Index.PercentageLevel8, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel8 {get; set;}

          /// <summary>
          /// Gets or sets Percentage Level 9
          /// </summary>
          [Display(Name = "PercentageLevel9", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.PercentageLevel9, Id = Index.PercentageLevel9, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
          public decimal PercentageLevel9 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 0
          /// </summary>
          [Display(Name = "AmountLevel0", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel0, Id = Index.AmountLevel0, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel0 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 1
          /// </summary>
          [Display(Name = "AmountLevel1", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel1, Id = Index.AmountLevel1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel1 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 2
          /// </summary>
          [Display(Name = "AmountLevel2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel2, Id = Index.AmountLevel2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel2 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 3
          /// </summary>
          [Display(Name = "AmountLevel2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel3, Id = Index.AmountLevel3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel3 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 4
          /// </summary>
          [Display(Name = "AmountLevel4", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel4, Id = Index.AmountLevel4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel4 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 5
          /// </summary>
          [Display(Name = "AmountLevel5", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel5, Id = Index.AmountLevel5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel5 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 6
          /// </summary>
          [Display(Name = "AmountLevel6", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel6, Id = Index.AmountLevel6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel6 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 7
          /// </summary>
          [Display(Name = "AmountLevel7", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel7, Id = Index.AmountLevel7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel7 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 8
          /// </summary>
          [Display(Name = "AmountLevel8", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel8, Id = Index.AmountLevel8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel8 {get; set;}

          /// <summary>
          /// Gets or sets Amount Level 9
          /// </summary>
          [Display(Name = "AmountLevel9", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.AmountLevel9, Id = Index.AmountLevel9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal AmountLevel9 {get; set;}
          
          /// <summary>
          /// Gets or sets Quantity To 0
          /// </summary>
          [Display(Name = "QuantityTo0", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo0, Id = Index.QuantityTo0, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo0 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 1
          /// </summary>
          [Display(Name = "QuantityTo1", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo1, Id = Index.QuantityTo1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo1 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 2
          /// </summary>
          [Display(Name = "QuantityTo2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo2, Id = Index.QuantityTo2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo2 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 3
          /// </summary>
          [Display(Name = "QuantityTo3", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo3, Id = Index.QuantityTo3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo3 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 4
          /// </summary>
          [Display(Name = "QuantityTo4", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo4, Id = Index.QuantityTo4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo4 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 5
          /// </summary>
          [Display(Name = "QuantityTo5", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo5, Id = Index.QuantityTo5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo5 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 6
          /// </summary>
          [Display(Name = "QuantityTo6", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo6, Id = Index.QuantityTo6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo6 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 7
          /// </summary>
          [Display(Name = "QuantityTo7", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo7, Id = Index.QuantityTo7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo7 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 8
          /// </summary>
          [Display(Name = "QuantityTo8", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo8, Id = Index.QuantityTo8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo8 {get; set;}

          /// <summary>
          /// Gets or sets Quantity To 9
          /// </summary>
          [Display(Name = "QuantityTo9", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityTo9, Id = Index.QuantityTo9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityTo9 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 0
          /// </summary>
          [Display(Name = "QuantityNext0", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext0, Id = Index.QuantityNext0, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext0 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 1
          /// </summary>
          [Display(Name = "QuantityNext1", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext1, Id = Index.QuantityNext1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext1 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 2
          /// </summary>
          [Display(Name = "QuantityNext2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext2, Id = Index.QuantityNext2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext2 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 3
          /// </summary>
          [Display(Name = "QuantityNext3", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext3, Id = Index.QuantityNext3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext3 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 4
          /// </summary>
          [Display(Name = "QuantityNext4", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext4, Id = Index.QuantityNext4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext4 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 5
          /// </summary>
          [Display(Name = "QuantityNext5", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext5, Id = Index.QuantityNext5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext5 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 6
          /// </summary>
          [Display(Name = "QuantityNext6", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext6, Id = Index.QuantityNext6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext6 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 7
          /// </summary>
          [Display(Name = "QuantityNext7", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext7, Id = Index.QuantityNext7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext7 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 8
          /// </summary>
          [Display(Name = "QuantityNext8", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext8, Id = Index.QuantityNext8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext8 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Next 9
          /// </summary>
          [Display(Name = "QuantityNext9", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityNext9, Id = Index.QuantityNext9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityNext9 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 0
          /// </summary>
          [Display(Name = "DiscountedAmount0", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount0, Id = Index.DiscountedAmount0, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount0 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 1
          /// </summary>
          [Display(Name = "DiscountedAmount1", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount1, Id = Index.DiscountedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount1 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 2
          /// </summary>
          [Display(Name = "DiscountedAmount2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount2, Id = Index.DiscountedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount2 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 3
          /// </summary>
          [Display(Name = "DiscountedAmount3", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount3, Id = Index.DiscountedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount3 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 4
          /// </summary>
          [Display(Name = "DiscountedAmount4", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount4, Id = Index.DiscountedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount4 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 5
          /// </summary>
          [Display(Name = "DiscountedAmount5", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount5, Id = Index.DiscountedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount5 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 6
          /// </summary>
          [Display(Name = "DiscountedAmount6", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount6, Id = Index.DiscountedAmount6, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount6 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 7
          /// </summary>
          [Display(Name = "DiscountedAmount7", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount7, Id = Index.DiscountedAmount7, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount7 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 8
          /// </summary>
          [Display(Name = "DiscountedAmount8", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount8, Id = Index.DiscountedAmount8, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount8 {get; set;}

          /// <summary>
          /// Gets or sets Discounted Amount 9
          /// </summary>
          [Display(Name = "DiscountedAmount9", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.DiscountedAmount9, Id = Index.DiscountedAmount9, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
          public decimal DiscountedAmount9 {get; set;}
          
          /// <summary>
          /// Gets or sets Level Used 0
          /// </summary>
          [Display(Name = "LevelUsed0", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed0, Id = Index.LevelUsed0, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed0 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 1
          /// </summary>
          [Display(Name = "LevelUsed1", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed1, Id = Index.LevelUsed1, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed1 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 2
          /// </summary>
          [Display(Name = "LevelUsed2", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed2, Id = Index.LevelUsed2, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed2 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 3
          /// </summary>
          [Display(Name = "LevelUsed3", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed3, Id = Index.LevelUsed3, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed3 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 4
          /// </summary>
          [Display(Name = "LevelUsed4", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed4, Id = Index.LevelUsed4, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed4 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 5
          /// </summary>
          [Display(Name = "LevelUsed5", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed5, Id = Index.LevelUsed5, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed5 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 6
          /// </summary>
          [Display(Name = "LevelUsed6", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed6, Id = Index.LevelUsed6, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed6 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 7
          /// </summary>
          [Display(Name = "LevelUsed7", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed7, Id = Index.LevelUsed7, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed7 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 8
          /// </summary>
          [Display(Name = "LevelUsed8", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed8, Id = Index.LevelUsed8, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed8 {get; set;}

          /// <summary>
          /// Gets or sets Level Used 9
          /// </summary>
          [Display(Name = "LevelUsed9", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.LevelUsed9, Id = Index.LevelUsed9, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsed9 {get; set;}

          /// <summary>
          /// Gets or sets Quantity Maximum
          /// </summary>
          [Display(Name = "QuantityMaximum", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityMaximum, Id = Index.QuantityMaximum, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityMaximum {get; set;}

          /// <summary>
          /// Gets or sets Quantity Increment
          /// </summary>
          [Display(Name = "QuantityIncrement", ResourceType = typeof(VendorContractCostsResx))]
          [ViewField(Name = Fields.QuantityIncrement, Id = Index.QuantityIncrement, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal QuantityIncrement {get; set;}


          /// <summary>
          /// Gets or sets COST QTY TO X
          /// </summary>
          [IgnoreExportImport]
          [ViewField(Name = Fields.CostQtyToX, Id = Index.CostQtyToX, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal CostQtyToX { get; set; }

          /// <summary>
          /// Gets or sets LEVEL USED X
          /// </summary>
          [IgnoreExportImport]
          [ViewField(Name = Fields.LevelUsedX, Id = Index.LevelUsedX, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsedX { get; set; }

          /// <summary>
          /// Gets or sets LEVEL USED Z
          /// </summary>
          [IgnoreExportImport]
          [ViewField(Name = Fields.LevelUsedZ, Id = Index.LevelUsedZ, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool LevelUsedZ { get; set; }

          /// <summary>
          /// Gets or sets Vendor Contract Cost Base Units
          /// </summary>
          [IgnoreExportImport]
          public EnumerableResponse<VendorContractCostBaseUnit> VendorContractCostBaseUnits { get; set; }

          /// <summary>
          /// Gets or sets Vendor Contract Cost Sale Units
          /// </summary>
          [IgnoreExportImport]
          public EnumerableResponse<VendorContractCostSaleUnit> VendorContractCostSaleUnits { get; set; }

          /// <summary>
          /// Gets or sets Vendor Contract Included Taxes
          /// </summary>
          [IgnoreExportImport]
          public EnumerableResponse<VendorContractIncludedTax> VendorContractIncludedTaxes { get; set; }
         
          /// <summary>
          /// Gets or sets Serial Number - Unique key for grid rows
          /// </summary>
          [IgnoreExportImport]
          public long SerialNumber { get; set; }

          /// <summary>
          /// Gets or sets the status of Sale Cost type changed Multi to Single.
          /// </summary>
          [IgnoreExportImport]
          public bool IsSaleChangedFromMultiToSingle { get; set; }

          /// <summary>
          /// Gets or sets the status of Base Cost type changed Multi to Single.
          /// </summary>
          [IgnoreExportImport]
          public bool IsBaseChangedFromMultiToSingle { get; set; }

          #region Finder Fields
          /// <summary>
          /// Gets the Base Cost Type String
          /// </summary>
          public string BaseCostTypeString
          {
              get { return EnumUtility.GetStringValue(BaseCostType); }
          }

          /// <summary>
          /// Gets the Sale Cost Type String
          /// </summary>
          public string SaleCostTypeString
          {
              get { return EnumUtility.GetStringValue(SaleCostType); }
          }
          /// <summary>
          /// Gets the Sale Cost Based On String
          /// </summary>
          public string SaleCostBasedOnString
          {
              get { return EnumUtility.GetStringValue(SaleCostBasedOn); }
          }

          /// <summary>
          /// Gets the Discount Based On String
          /// </summary>
          public string DiscountBasedOnString
          {
              get { return EnumUtility.GetStringValue(DiscountBasedOn); }
          }
         
          /// <summary>
          /// Gets the Rounding Method String
          /// </summary>
          public string RoundingMethodString
          {
              get { return EnumUtility.GetStringValue(RoundingMethod); }
          }
          
          /// <summary>
          /// Gets the Level Used 0 
          /// </summary>
          public string LevelUsed0String
          {
              get
              {
                  if (LevelUsed0)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets the Level Used 1 
          /// </summary>
          public string LevelUsed1String
          {
              get
              {
                  if (LevelUsed1)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 2
          /// </summary>
          public string LevelUsed2String
          {
              get
              {
                  if (LevelUsed2)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 3 
          /// </summary>
          public string LevelUsed3String
          {
              get
              {
                  if (LevelUsed3)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 4
          /// </summary>
          public string LevelUsed4String
          {
              get
              {
                  if (LevelUsed4)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 5 
          /// </summary>
          public string LevelUsed5String
          {
              get
              {
                  if (LevelUsed5)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 6
          /// </summary>
          public string LevelUsed6String
          {
              get
              {
                  if (LevelUsed6)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 7
          /// </summary>
          public string LevelUsed7String
          {
              get
              {
                  if (LevelUsed7)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 8
          /// </summary>
          public string LevelUsed8String
          {
              get
              {
                  if (LevelUsed8)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }
          /// <summary>
          /// Gets Level Used 9
          /// </summary>
          public string LevelUsed9String
          {
              get
              {
                  if (LevelUsed9)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }

          /// <summary>
          /// Gets Level Used Z- UI Helper
          /// </summary>
          public string LevelUsedZString
          {
              get
              {
                  if (LevelUsedZ)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }

          /// <summary>
          /// Gets Level Used X- UI Helper
          /// </summary>
          public string LevelUsedXString
          {
              get
              {
                  if (LevelUsedX)
                  {
                      return EnumUtility.GetStringValue(BooleanType.True);
                  }
                  return EnumUtility.GetStringValue(BooleanType.False);

              }
          }

          #endregion
     }
}
