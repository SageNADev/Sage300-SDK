// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Type = Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Type;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for PurchaseOrderDetOptFieldFields
    /// </summary>
    public partial class PurchaseOrderDetOptField : ModelBase
    {
        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        public Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        public Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedValueFieldIndex
        /// </summary>
        public long TypedValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets TextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets AmountValue
        /// </summary>
        public decimal AmountValue { get; set; }

        /// <summary>
        /// Gets or sets NumberValue
        /// </summary>
        public decimal NumberValue { get; set; }

        /// <summary>
        /// Gets or sets IntegerValue
        /// </summary>
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets YesNoValue
        /// </summary>
        public YesNoValue YesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DateValue
        /// </summary>
        [ValidateDateFormat(ErrorMessage = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime DateValue { get; set; }

        /// <summary>
        /// Gets or sets TimeValue
        /// </summary>
        public TimeSpan TimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DefaultValueDescription { get; set; }

    }
}
