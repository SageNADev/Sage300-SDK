// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for CostClass
     /// </summary>
     public enum CostClass
     {
          /// <summary>
          /// Gets or sets 
          /// </summary>
           None  = 0,
          /// <summary>
          /// Gets or sets Labor
          /// </summary>
          [EnumValue("CostClass_Labor", typeof(POCommonResx))]
          Labor = 1,
          /// <summary>
          /// Gets or sets Material
          /// </summary>
          [EnumValue("CostClass_Material", typeof(POCommonResx))]
          Material = 2,
          /// <summary>
          /// Gets or sets Equipment
          /// </summary>
          [EnumValue("CostClass_Equipment", typeof(POCommonResx))]
          Equipment = 3,
          /// <summary>
          /// Gets or sets Subcontractor
          /// </summary>
          [EnumValue("CostClass_Subcontractor", typeof(POCommonResx))]
          Subcontractor = 4,
          /// <summary>
          /// Gets or sets Overhead
          /// </summary>
          [EnumValue("CostClass_Overhead", typeof(POCommonResx))]
          Overhead = 5,
          /// <summary>
          /// Gets or sets Miscellaneous
          /// </summary>
          [EnumValue("CostClass_Miscellaneous", typeof(POCommonResx))]
          Miscellaneous = 6,
     }
}
