// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for SeparatorAsterisk
    /// </summary>
    public enum SeparatorAsterisk
    {
        /// <summary>
        /// Gets or sets Asterisk
        /// </summary>
        [EnumValue("Asterisk", typeof(ICOptionResx))]
        Asterisk = 1
    }
}