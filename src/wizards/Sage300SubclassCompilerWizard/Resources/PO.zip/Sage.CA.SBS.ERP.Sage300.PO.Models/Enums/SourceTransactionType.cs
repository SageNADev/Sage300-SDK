﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for Source Transaction Type
    /// </summary>
    public enum SourceTransactionType
    {
        /// <summary>
        /// Gets or sets Receipt
        /// </summary>
        [EnumValue("Receipt", typeof(POCommonResx), 1)]
        Receipt = 0,
        /// <summary>
        /// Gets or sets Receipt Detail
        /// </summary>
        [EnumValue("ReceiptDetail", typeof(GLIntegrationResx), 2)]
        ReceiptDetail = 1,
        /// <summary>
        /// Gets or sets Receipt Expensed Additional CostDetail
        /// </summary>
        [EnumValue("ReceiptExpensedAdditionalCostDetail", typeof(GLIntegrationResx), 3)]
        ReceiptExpensedAdditionalCostDetail = 2,
        /// <summary>
        /// Gets or sets Invoice
        /// </summary>
        [EnumValue("Invoice", typeof(POCommonResx), 4)]
        Invoice = 3,
        /// <summary>
        /// Gets or sets Invoice Detail
        /// </summary>
        [EnumValue("InvoiceDetail", typeof(GLIntegrationResx), 5)]
        InvoiceDetail = 4,
        /// <summary>
        /// Gets or sets Invoice Expensed Additional CostDetail
        /// </summary>
        [EnumValue("InvoiceExpensedAdditionalCostDetail", typeof(GLIntegrationResx), 6)]
        InvoiceExpensedAdditionalCostDetail = 5,
        /// <summary>
        /// Gets or sets Return
        /// </summary>
        [EnumValue("Return", typeof(GLIntegrationResx), 7)]
        Return = 6,
        /// <summary>
        /// Gets or sets Return Detail
        /// </summary>
        [EnumValue("ReturnDetail", typeof(GLIntegrationResx), 8)]
        ReturnDetail = 7,
        /// <summary>
        /// Gets or sets Credit Note
        /// </summary>
        [EnumValue("CreditNote", typeof(POCommonResx), 9)]
        CreditNote = 8,
        /// <summary>
        /// Gets or sets Credit Note Detail
        /// </summary>
        [EnumValue("CreditNoteDetail", typeof(GLIntegrationResx), 10)]
        CreditNoteDetail = 9,
        /// <summary>
        /// Gets or sets Credit Note Expensed Additional Cost Detail
        /// </summary>
        [EnumValue("CreditNoteExpensedAdditionalCostDetail", typeof(GLIntegrationResx), 11)]
        CreditNoteExpensedAdditionalCostDetail = 10,
        /// <summary>
        /// Gets or sets Debit Note
        /// </summary>
        [EnumValue("DebitNote", typeof(POCommonResx), 12)]
        DebitNote = 11,
        /// <summary>
        /// Gets or sets Debit Note Detail
        /// </summary>
        [EnumValue("DebitNoteDetail", typeof(GLIntegrationResx), 13)]
        DebitNoteDetail = 12,
        /// <summary>
        /// Gets or sets Debit Note Expensed Additional Cost Detail
        /// </summary>
        [EnumValue("DebitNoteExpensedAdditionalCostDetail", typeof(GLIntegrationResx), 14)]
        DebitNoteExpensedAdditionalCostDetail = 13,
    }
}
