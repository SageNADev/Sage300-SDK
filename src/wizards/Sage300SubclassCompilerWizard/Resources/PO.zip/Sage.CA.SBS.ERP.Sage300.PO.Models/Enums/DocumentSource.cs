// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for DocumentSource
     /// </summary>
     public enum DocumentSource
     {
          /// <summary>
          /// Gets or sets Entered
          /// </summary>
          [EnumValue("Entered", typeof(POCommonResx), 0)]
          Entered = 0,
          /// <summary>
          /// Gets or sets Internet
          /// </summary>
          [EnumValue("Internet", typeof(POCommonResx), 1)]
          Internet = 1,
     }
}
