// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for GL Consolidation
     /// </summary>
     public enum GLConsolidation
     {
          /// <summary>
          /// Gets or sets Do Not Consolidate
          /// </summary>
          [EnumValue("DoNotConsolidate", typeof(GLIntegrationResx), 1)]
          DoNotConsolidate = 1,
          /// <summary>
          /// Gets or sets Consolidate Transaction Details by Account
          /// </summary>
          [EnumValue("ConsolidateTransactionDetailsbyAccount", typeof(GLIntegrationResx), 2)]
          ConsolidateTransactionDetailsbyAccount = 9,
          /// <summary>
          /// Gets or sets Consolidate by Account And Fiscal Period
          /// </summary>
          [EnumValue("ConsolidateByAccountPeriod", typeof(GLIntegrationResx), 3)]
          ConsolidatebyAccountAndFiscalPeriod = 2,
          /// <summary>
          /// Gets or sets Consolidate by Account Fiscal Period And Source
          /// </summary>
          [EnumValue("ConsolidateByAccountPeriodSource", typeof(GLIntegrationResx), 4)]
          ConsolidatebyAccountFiscalPeriodAndSource = 3,
     }
}
