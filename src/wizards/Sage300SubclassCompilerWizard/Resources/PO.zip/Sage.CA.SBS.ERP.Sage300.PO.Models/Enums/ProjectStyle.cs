// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for ProjectStyle
     /// </summary>
     public enum ProjectStyle
     {
          /// <summary>
          /// Gets or sets 
          /// </summary>
          None = 0,
          /// <summary>
          /// Gets or sets Standard
          /// </summary>
          Standard = 1,
          /// <summary>
          /// Gets or sets Basic
          /// </summary>
          Basic = 2,
     }
}
