// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for DefaultCost
    /// </summary>
    public enum DefaultCost
    {
        /// <summary>
        /// Gets or sets MostRecentCost
        /// </summary>
        [EnumValue("CostMostRecent", typeof(OptionsResx), 1)]
        MostRecentCost = 28,
        /// <summary>
        /// Gets or sets StandardCost
        /// </summary>
        [EnumValue("CostStandard", typeof(OptionsResx), 2)]
        StandardCost = 20,
        /// <summary>
        /// Gets or sets AverageCost
        /// </summary>
        [EnumValue("CostAverage", typeof(OptionsResx), 3)]
        AverageCost = 65,
        /// <summary>
        /// Gets or sets LastUnitCost
        /// </summary>
        [EnumValue("CostLastUnit", typeof(OptionsResx), 4)]
        LastUnitCost = 31,
        /// <summary>
        /// Gets or sets VendorCost
        /// </summary>
        [EnumValue("CostVendor", typeof(OptionsResx), 5)]
        VendorCost = 8,
    }
}
