// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for PrimaryVendor
    /// </summary>
    public enum PrimaryVendor
    {
        /// <summary>
        /// Gets or sets PrimaryVendor
        /// </summary>
        [EnumValue("PrimaryVendor", typeof(InvoiceResx))]
        PrimaryVendor = 1,
        /// <summary>
        /// Gets or sets SecondaryVendor
        /// </summary>
        [EnumValue("SecondaryVendor", typeof(InvoiceResx))]
        SecondaryVendor = 2,

        /// <summary>
        /// Gets or sets NewVendor
        /// </summary>
        [EnumValue("NewVendor", typeof(InvoiceResx))]
        NewVendor = 3,
    }
}
