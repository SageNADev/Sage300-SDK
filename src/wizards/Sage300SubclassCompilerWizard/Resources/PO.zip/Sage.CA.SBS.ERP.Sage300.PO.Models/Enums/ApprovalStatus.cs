// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for ApprovalStatus
     /// </summary>
     public enum ApprovalStatus
     {
          /// <summary>
          /// Gets or sets Entered
          /// </summary>
          [EnumValue("Entered", typeof(POCommonResx), 11)]
          Entered = 11,
          /// <summary>
          /// Gets or sets Approved
          /// </summary>
          [EnumValue("Approved", typeof(POCommonResx), 12)]
          Approved = 12,
     }
}
