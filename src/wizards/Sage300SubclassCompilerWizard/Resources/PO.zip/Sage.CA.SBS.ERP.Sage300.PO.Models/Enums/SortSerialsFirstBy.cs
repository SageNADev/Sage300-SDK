// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for SortSerialsFirstBy
    /// </summary>
    public enum SortSerialsFirstBy
    {
        /// <summary>
        /// Gets or sets Earliest
        /// </summary>
        [EnumValue("Earliest", typeof(ICOptionResx))]
        Earliest = 1,
        /// <summary>
        /// Gets or sets Latest
        /// </summary>
        [EnumValue("Latest", typeof(ICOptionResx))]
        Latest = 2
    }
}