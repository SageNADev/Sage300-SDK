// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Sale Cost Type
     /// </summary>
     public enum SaleCostType
     {
          /// <summary>
          /// Gets or sets Sale Unit Cost For Single Unit Of Measure
          /// </summary>
          [EnumValue("SaleUnitCostForSingleUnitOfMeasure", typeof(VendorContractCostsResx), 1)] 
          SaleUnitCostForSingleUnitOfMeasure = 1,
          /// <summary>
          /// Gets or sets Sale Unit Cost For Multiple Units Of Measure
          /// </summary>
          [EnumValue("SaleUnitCostForMultipleUnitsOfMeasure", typeof(VendorContractCostsResx), 2)] 
          SaleUnitCostForMultipleUnitsOfMeasure = 2,
     }
}
