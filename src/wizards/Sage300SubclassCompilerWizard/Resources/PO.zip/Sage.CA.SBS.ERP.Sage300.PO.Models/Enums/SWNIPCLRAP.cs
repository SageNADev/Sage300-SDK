// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for SWNIPCLRAP
     /// </summary>
     public enum SWNIPCLRAP
     {
          /// <summary>
          /// Gets or sets NotApplicable
          /// </summary>
          NotApplicable = 99,
     }
}
