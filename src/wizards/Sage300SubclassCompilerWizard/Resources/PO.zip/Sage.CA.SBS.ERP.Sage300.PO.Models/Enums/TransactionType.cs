// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
	/// <summary>
	/// Enum for TransactionType
	/// </summary>
	public enum TransactionType
	{
		/// <summary>
		/// Gets or sets Requisition
		/// </summary>
        [EnumValue("Requisition", typeof(POCommonResx))]
		Requisition = 1,

		/// <summary>
		/// Gets or sets PurchaseOrder
		/// </summary>
        [EnumValue("PurchaseOrders", typeof(POCommonResx))]
		PurchaseOrder = 2,

		/// <summary>
		/// Gets or sets Receipt
		/// </summary>
        [EnumValue("Receipt", typeof(POCommonResx))]
		Receipt = 3,

		/// <summary>
		/// Gets or sets Return
		/// </summary>
        [EnumValue("Return", typeof(POCommonResx))]
		Return = 4,

		/// <summary>
		/// Gets or sets Invoice
		/// </summary>
        [EnumValue("Invoice", typeof(POCommonResx))]
		Invoice = 5,

		/// <summary>
		/// Gets or sets CreditNote
		/// </summary>
        [EnumValue("CreditNote", typeof(POCommonResx))]
		CreditNote = 6,

		/// <summary>
		/// Gets or sets DebitNote
		/// </summary>
        [EnumValue("DebitNote", typeof(POCommonResx))]
		DebitNote = 7
	}
}
