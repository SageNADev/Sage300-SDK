// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for RateOperation
     /// </summary>
     public enum RateOperation
     {
         /// <summary>
         /// Gets or sets Multiply 
         /// </summary>	
         [EnumValue("Divide", typeof(POCommonResx))]
         Divide = 0,
         /// <summary>
         /// Gets or sets Divide 
         /// </summary>	
         [EnumValue("Multiply", typeof(POCommonResx))]
         Multiply = 1,
     }
}
