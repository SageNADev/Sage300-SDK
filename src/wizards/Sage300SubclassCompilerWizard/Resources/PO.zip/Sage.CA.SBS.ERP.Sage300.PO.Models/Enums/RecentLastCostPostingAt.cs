// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for RecentLastCostPostingAt
    /// </summary>
    public enum RecentLastCostPostingAt
    {
        /// <summary>
        /// Gets or sets ReceiptCosting
        /// </summary>
        [EnumValue("ReceiptCosting", typeof(OptionsResx), 1)]
        ReceiptCosting = 1,
        /// <summary>
        /// Gets or sets InvoiceCosting
        /// </summary>
        [EnumValue("InvoiceCosting", typeof(OptionsResx), 2)]
        InvoiceCosting = 2,
    }
}
