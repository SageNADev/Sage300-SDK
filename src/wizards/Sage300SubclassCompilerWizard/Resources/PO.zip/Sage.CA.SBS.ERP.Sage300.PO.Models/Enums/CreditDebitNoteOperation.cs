﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for CreditDebitNote Operation
    /// </summary>
    public enum CreditDebitNoteOperation
    {
        Initialize_CRN_From_Return = 1,
        initialize_CRN_From_RetNumber = 2,
        Calculate_Tax = 3,
        Calculate_Tax_If_Pending = 6,
        Initialize_CRN_From_Invoice = 10,
        initialize_DEB_From_invoice = 11,
        Contract_Cost_On_Date = 61,
        Posted_Contract_Cost_On_Date = 62
    }
}
