// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for SaleCostCalculatedUsing
     /// </summary>
     public enum SaleCostCalculatedUsing
     {
          /// <summary>
          /// Gets or sets BaseUnitCostMinusaPercentage
          /// </summary>
         [EnumValue("BaseUnitCostMinusaPercentage", typeof(VendorContractCostsResx), 1)]  
         BaseUnitCostMinusaPercentage = 1,
          /// <summary>
          /// Gets or sets BaseUnitCostMinusanAmount
          /// </summary>
         [EnumValue("BaseUnitCostMinusanAmount", typeof(VendorContractCostsResx), 2)]  
         BaseUnitCostMinusanAmount = 2,
          /// <summary>
          /// Gets or sets FixedAmount
          /// </summary>
         [EnumValue("FixedAmount", typeof(VendorContractCostsResx), 3)]  
         FixedAmount = 3,
     }
}
