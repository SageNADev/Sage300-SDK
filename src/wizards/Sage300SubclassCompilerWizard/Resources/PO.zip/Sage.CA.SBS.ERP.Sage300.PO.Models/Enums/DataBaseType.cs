// Copyright (c) 1994-2024 The Sage Group plc or its licensors.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for Database types that require special handling
    /// </summary>
    public enum DataBaseType
    {
        /// <summary>
        /// Database Type Oracle
        /// </summary>
        Oracle = 4,
    }
}
