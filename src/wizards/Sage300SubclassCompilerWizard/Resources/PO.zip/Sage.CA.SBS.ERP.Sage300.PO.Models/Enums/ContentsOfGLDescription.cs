// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for ContentsOfGLDescription
     /// </summary>
     public enum ContentsOfGLDescription
     {
          /// <summary>
          /// Gets or sets DocumentNumber
          /// </summary>
          DocumentNumber = 1,
          /// <summary>
          /// Gets or sets SourceCodeDayEndNumberEntryNumber
          /// </summary>
          SourceCodeDayEndNumberEntryNumber = 2,
          /// <summary>
          /// Gets or sets Description
          /// </summary>
          Description = 3,
          /// <summary>
          /// Gets or sets Reference
          /// </summary>
          Reference = 4,
          /// <summary>
          /// Gets or sets VendorNumber
          /// </summary>
          VendorNumber = 5,
          /// <summary>
          /// Gets or sets VendorName
          /// </summary>
          VendorName = 6,
          /// <summary>
          /// Gets or sets PONumber
          /// </summary>
          PONumber = 7,
     }
}
