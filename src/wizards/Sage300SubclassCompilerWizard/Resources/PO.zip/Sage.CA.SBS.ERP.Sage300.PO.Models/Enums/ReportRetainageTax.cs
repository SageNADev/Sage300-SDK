// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for ReportRetainageTax
     /// </summary>
     public enum ReportRetainageTax
     {
          /// <summary>
          /// Gets or sets AtTimeOfOriginalDocument
          /// </summary>
         [EnumValue("AtTimeOfOriginalDocument", typeof(ReturnEntryResx))]
         AtTimeOfOriginalDocument = 0,
          /// <summary>
          /// Gets or sets AsPerTaxAuthority
          /// </summary>
         [EnumValue("AsPerTaxAuthority", typeof(ReturnEntryResx))]
         AsPerTaxAuthority = 1,
     }
}
