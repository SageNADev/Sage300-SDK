// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for DocumentType
     /// </summary>
     public enum DocumentType
     {
          /// <summary>
          /// Gets or sets Requisition
          /// </summary>
          Requisition = 1,
          /// <summary>
          /// Gets or sets PurchaseOrder
          /// </summary>
          PurchaseOrder = 2,
          /// <summary>
          /// Gets or sets Receipt
          /// </summary>
          Receipt = 3,
          /// <summary>
          /// Gets or sets Return
          /// </summary>
          Return = 4,
          /// <summary>
          /// Gets or sets PurchaseOrderLabel
          /// </summary>
          PurchaseOrderLabel = 102,
          /// <summary>
          /// Gets or sets ReturnLabel
          /// </summary>
          ReturnLabel = 104,
     }
}
