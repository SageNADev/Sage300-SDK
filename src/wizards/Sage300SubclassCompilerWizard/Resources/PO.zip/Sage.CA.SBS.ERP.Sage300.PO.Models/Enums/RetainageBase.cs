// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for RetainageBase
     /// </summary>
     public enum RetainageBase
     {
          /// <summary>
          /// Gets or sets TotalAfterTaxes
          /// </summary>
         [EnumValue("TotalAfterTaxes", typeof(ReturnEntryResx))]
         TotalAfterTaxes = 0,
          /// <summary>
          /// Gets or sets TotalBeforeTaxes
          /// </summary>
          [EnumValue("TotalBeforeTaxes", typeof(ReturnEntryResx))]
          TotalBeforeTaxes = 1,
     }
}
