﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for CreditDebitNote FromDocument
    /// </summary>
    public enum CreditDebitNoteFromDocument
    {
        /// <summary>
        /// Gets or sets Return
        /// </summary>
        [EnumValue("Return", typeof(POCommonResx))]
        Return = 4,
        /// <summary>
        /// Gets or sets Invoice
        /// </summary>
        [EnumValue("Invoice", typeof(POCommonResx))]
        Invoice = 5,
    }
}
