// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Discount Based On
     /// </summary>
     public enum DiscountBasedOn
     {
          /// <summary>
          /// Gets or sets Percentage
          /// </summary>
          [EnumValue("Percentage", typeof(VendorContractCostsResx), 1)] 
          Percentage = 1,
          /// <summary>
          /// Gets or sets Amount
          /// </summary>
          [EnumValue("Amount", typeof(POCommonResx), 2)] 
          Amount = 2,
     }
}
