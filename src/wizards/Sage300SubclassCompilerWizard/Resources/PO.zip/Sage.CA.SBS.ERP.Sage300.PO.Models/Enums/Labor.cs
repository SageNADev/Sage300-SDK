// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Labor
     /// </summary>
     public enum Labor
     {
          /// <summary>
          /// Gets or sets NotApplicable
          /// </summary>

 [EnumValue("NotApplicable", typeof(CommonResx))] 
         NotApplicable = 99,
     }
}
