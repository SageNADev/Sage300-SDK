// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Base Cost Type
     /// </summary>
     public enum BaseCostType
     {
          /// <summary>
          /// Gets or sets Base Unit Cost For Single Unit Of Measure
          /// </summary>
          [EnumValue("BaseUnitCostForSingleUnitOfMeasure", typeof(VendorContractCostsResx), 1)] 
          BaseUnitCostForSingleUnitOfMeasure = 1,
          /// <summary>
          /// Gets or sets Base Unit Cost For Multiple Units Of Measure
          /// </summary>
          [EnumValue("BaseUnitCostForMultipleUnitsOfMeasure", typeof(VendorContractCostsResx), 2)]
          BaseUnitCostForMultipleUnitsOfMeasure = 2,
     }
}
