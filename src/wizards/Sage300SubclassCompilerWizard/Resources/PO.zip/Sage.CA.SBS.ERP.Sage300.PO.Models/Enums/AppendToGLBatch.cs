// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for AppendToGLBatch
    /// </summary>
    public enum AppendToGLBatch
    {
        /// <summary>
        /// Gets or sets AddingToAnExistingBatch
        /// </summary>
        [EnumValue("AddingToAnExistingBatch", typeof(ICOptionResx))]
        AddingToAnExistingBatch = 1,
        /// <summary>
        /// Gets or sets CreatingANewBatch
        /// </summary>
        [EnumValue("CreatingANewBatch", typeof(ICOptionResx))]
        CreatingANewBatch = 0,
        /// <summary>
        /// Gets or sets CreatingAndPostingANewBatch
        /// </summary>
        [EnumValue("CreatingAndPostingANewBatch", typeof(ICOptionResx))]
        CreatingAndPostingANewBatch = 2
    }
}