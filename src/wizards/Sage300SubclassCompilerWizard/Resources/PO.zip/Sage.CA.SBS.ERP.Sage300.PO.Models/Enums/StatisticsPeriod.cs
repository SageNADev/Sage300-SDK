// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for StatisticsPeriod
    /// </summary>
    public enum StatisticsPeriod
    {
        /// <summary>
        /// Gets or sets Weekly
        /// </summary>
        [EnumValue("Weekly", typeof(ICOptionResx))]
        Weekly = 1,
        /// <summary>
        /// Gets or sets SevenDays
        /// </summary>
        [EnumValue("SevenDays", typeof(ICOptionResx))]
        SevenDays = 2,
        /// <summary>
        /// Gets or sets Biweekly
        /// </summary>
        [EnumValue("Biweekly", typeof(ICOptionResx))]
        Biweekly = 3,
        /// <summary>
        /// Gets or sets FourWeeks
        /// </summary>
        [EnumValue("FourWeeks", typeof(ICOptionResx))]
        FourWeeks = 4,
        /// <summary>
        /// Gets or sets Monthly
        /// </summary>
        [EnumValue("Monthly", typeof(ICOptionResx))]
        Monthly = 5,
        /// <summary>
        /// Gets or sets Bimonthly
        /// </summary>
        [EnumValue("Bimonthly", typeof(ICOptionResx))]
        Bimonthly = 6,
        /// <summary>
        /// Gets or sets Quarterly
        /// </summary>
        [EnumValue("Quarterly", typeof(ICOptionResx))]
        Quarterly = 7,
        /// <summary>
        /// Gets or sets Semiannually
        /// </summary>
        [EnumValue("Semiannually", typeof(ICOptionResx))]
        Semiannually = 8,
        /// <summary>
        /// Gets or sets Annually
        /// </summary>
        [EnumValue("Annually", typeof(ICOptionResx))]
        Annually = 9,
        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [EnumValue("FiscalPeriod", typeof(ICOptionResx))]
        FiscalPeriod = 10
    }
}