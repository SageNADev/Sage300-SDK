﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region using
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    public enum PurchaseOrderTypeWithAll
    {
        /// <summary>
        /// Gets or sets All
        /// </summary>
        [EnumValue("All", typeof(CommonResx), 0)]
        All = 0,

        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("Active", typeof(TemplatesResx), 1)]
        Active = 1,

        /// <summary>
        /// Gets or sets Standing
        /// </summary>
        [EnumValue("Standing", typeof(TemplatesResx), 2)]
        Standing = 2,

        /// <summary>
        /// Gets or sets Future
        /// </summary>
        [EnumValue("Future", typeof(TemplatesResx), 3)]
        Future = 3,

        /// <summary>
        /// Gets or sets Blanket
        /// </summary>
        [EnumValue("Blanket", typeof(TemplatesResx), 4)]
        Blanket = 4,
    }
}
