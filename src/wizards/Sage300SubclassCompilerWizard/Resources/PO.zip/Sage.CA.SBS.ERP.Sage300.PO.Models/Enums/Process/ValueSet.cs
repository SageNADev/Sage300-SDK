// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for ValueSet
    /// </summary>
    public enum ValueSet
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        No = 0,

        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        Yes = 1,

        /// <summary>
        /// Gets or sets NotApplicable
        /// </summary>
        [EnumValue("NotApplicable", typeof(CommonResx))]
        NotApplicable = 99
    }
}
