﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for SelectItem
    /// </summary>
    public enum Operations
    {
        /// <summary>
        /// Gets or sets PurchaseOrder
        /// </summary>
        [EnumValue("PurchaseOrders", typeof(POCommonResx))]
        Printed = 1,

        /// <summary>
        /// Gets or sets Return
        /// </summary>
        [EnumValue("Returns", typeof(POCommonResx))]
        Align = 2
    }
}
