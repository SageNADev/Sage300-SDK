// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for IncludeWhatItems
    /// </summary>
    public enum IncludeWhatItems
    {
        /// <summary>
        /// Gets or sets AllItems
        /// </summary>
        AllItems = 0,
        /// <summary>
        /// Gets or sets ItemswithInsufficientQuantities
        /// </summary>
        ItemswithInsufficientQuantities = 1,
        /// <summary>
        /// Gets or sets ItemsonBackorder
        /// </summary>
        ItemsonBackorder = 2,
    }
}
