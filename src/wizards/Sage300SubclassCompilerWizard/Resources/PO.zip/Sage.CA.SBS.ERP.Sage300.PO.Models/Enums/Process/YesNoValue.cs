// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
     /// <summary>
     /// Enum for YesNoValue
     /// </summary>
     public enum YesNoValue
     {
          /// <summary>
          /// Gets or sets No
          /// </summary>
          No = 1,

          /// <summary>
          /// Gets or sets Yes
          /// </summary>
          Yes = 0,
     }
}
