// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for ClearPurchaseStatistics
    /// </summary>
    public enum ClearPurchaseStatistics
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        [Display(Name = "No", ResourceType = typeof(CommonResx))]
        No = 0,
        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [Display(Name = "Yes", ResourceType = typeof(CommonResx))]
        Yes = 1,
    }
}
