// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for GeneratePOsfor
    /// </summary>
    public enum GeneratePOsfor
    {
        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        Vendor = 0,
        /// <summary>
        /// Gets or sets Order
        /// </summary>
        Order = 1,
    }
}
