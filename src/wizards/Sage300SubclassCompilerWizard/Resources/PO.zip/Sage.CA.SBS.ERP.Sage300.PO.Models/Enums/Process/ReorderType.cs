﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for ReorderType
    /// </summary>
    public enum ReorderType
    {
        /// <summary>
        /// Gets or sets AllItems
        /// </summary>
        [EnumValue("AllItems", typeof(CreatePOsFromICResx))]
        AllItems = 1,

        /// <summary>
        /// Gets or sets ItemsBelowMinimun
        /// </summary>
        [EnumValue("ItemsBelowMin", typeof(CreatePOsFromICResx))]
        ItemsBelowMinimun = 2,

        /// <summary>
        /// Gets or sets ItemsBelowMinimun
        /// </summary>
        [EnumValue("ItemsBelowProjSale", typeof(CreatePOsFromICResx))]
        ItemsBelowProjectedSalesFor = 3,
    }
}
