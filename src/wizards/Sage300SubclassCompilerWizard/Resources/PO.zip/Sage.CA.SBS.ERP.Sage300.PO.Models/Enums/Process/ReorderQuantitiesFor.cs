// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
     /// <summary>
     /// Enum for ReorderQuantitiesFor
     /// </summary>
     public enum ReorderQuantitiesFor
     {
          /// <summary>
          /// Gets or sets SpecificLocation
          /// </summary>
          [EnumValue("SpecificLocation", typeof(CreatePOsFromICResx))]  
          SpecificLocation = 1,
          
          /// <summary>
          /// Gets or sets AllLocations
          /// </summary>
          [EnumValue("ReorderforAllLocs", typeof(CreatePOsFromICResx))]  
          AllLocations = 2,
     }
}
