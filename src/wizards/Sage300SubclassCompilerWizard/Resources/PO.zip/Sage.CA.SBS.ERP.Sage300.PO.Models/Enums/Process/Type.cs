// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
     /// <summary>
     /// Enum for Type
     /// </summary>
     public enum Type
     {
          /// <summary>
          /// Gets or sets Text
          /// </summary>
          Text = 1,
          /// <summary>
          /// Gets or sets Amount
          /// </summary>
          Amount = 100,
          /// <summary>
          /// Gets or sets Number
          /// </summary>
          Number = 6,
          /// <summary>
          /// Gets or sets Integer
          /// </summary>
          Integer = 8,
          /// <summary>
          /// Gets or sets YesNo
          /// </summary>
          YesNo = 9,
          /// <summary>
          /// Gets or sets Date
          /// </summary>
          Date = 3,
          /// <summary>
          /// Gets or sets Time
          /// </summary>
          Time = 4,
     }
}
