// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
     /// <summary>
     /// Enum for Command
     /// </summary>
     public enum Command
     {
          /// <summary>
          /// Gets or sets NothingToProcess
          /// </summary>
          NothingToProcess = 0,
          /// <summary>
          /// Gets or sets InsertOptionalFields
          /// </summary>
          InsertOptionalFields = 1,
          /// <summary>
          /// Gets or sets DefaultAndTranferOptionalFields
          /// </summary>
          DefaultAndTranferOptionalFields = 2,
          /// <summary>
          /// Gets or sets DefaultOptFieldsDuringRecordGeneration
          /// </summary>
          DefaultOptFieldsDuringRecordGeneration = 3,
          /// <summary>
          /// Gets or sets RemoveOptionalFields
          /// </summary>
          RemoveOptionalFields = 4,
          /// <summary>
          /// Gets or sets TransferOptFieldsFromStandingDocument
          /// </summary>
          TransferOptFieldsFromStandingDocument = 5,
          /// <summary>
          /// Gets or sets InsertItemSerialOptionalFields
          /// </summary>
          InsertItemSerialOptionalFields = 6,
          /// <summary>
          /// Gets or sets InsertItemLotOptionalFields
          /// </summary>
          InsertItemLotOptionalFields = 7,
          /// <summary>
          /// Gets or sets AutogenerateSerials
          /// </summary>
          AutogenerateSerials = 21,
          /// <summary>
          /// Gets or sets AutogenerateLots
          /// </summary>
          AutogenerateLots = 22,
          /// <summary>
          /// Gets or sets AutoallocateSerials
          /// </summary>
          AutoallocateSerials = 23,
          /// <summary>
          /// Gets or sets AutoallocateLots
          /// </summary>
          AutoallocateLots = 24,
          /// <summary>
          /// Gets or sets ClearSerials
          /// </summary>
          ClearSerials = 25,
          /// <summary>
          /// Gets or sets ClearLots
          /// </summary>
          ClearLots = 26,
          /// <summary>
          /// Gets or sets AutoassignSerials
          /// </summary>
          AutoassignSerials = 27,
          /// <summary>
          /// Gets or sets AutoassignLots
          /// </summary>
          AutoassignLots = 28,
          /// <summary>
          /// Gets or sets CreateSerialsLotsList
          /// </summary>
          CreateSerialsLotsList = 29,
          /// <summary>
          /// Gets or sets PostSerialsLotsToICInventory
          /// </summary>
          PostSerialsLotsToICInventory = 31,
     }
}
