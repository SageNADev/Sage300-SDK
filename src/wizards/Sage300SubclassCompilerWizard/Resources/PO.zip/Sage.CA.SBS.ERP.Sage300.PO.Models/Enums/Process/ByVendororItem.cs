// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Process;
namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
     /// <summary>
     /// Enum for ByVendororItem
     /// </summary>
     public enum ByVendororItem
     {
          /// <summary>
          /// Gets or sets VendorNumber
          /// </summary>
          [EnumValue("VendorNumber", typeof(ClearHistoryResx))]
          VendorNumber = 1,
          /// <summary>
          /// Gets or sets ItemNumber
          /// </summary>
         [EnumValue("ItemNumber", typeof(ClearHistoryResx))] 
         ItemNumber = 0,
     }
}
