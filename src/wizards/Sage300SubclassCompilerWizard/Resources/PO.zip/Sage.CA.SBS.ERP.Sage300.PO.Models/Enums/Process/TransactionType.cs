// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum TransactionType
    {
        /// <summary>
        /// Gets or sets Default
        /// </summary>
        Default=0,

        /// <summary>
        /// Gets or sets Receipts
        /// </summary>
        Receipts = 1,

        /// <summary>
        /// Gets or sets Returns
        /// </summary>
        Returns = 2,

        /// <summary>
        /// Gets or sets Invoices
        /// </summary>
        Invoices = 3,

        /// <summary>
        /// Gets or sets CreditDebitNotes
        /// </summary>
        CreditDebitNotes = 4,
    }
}
