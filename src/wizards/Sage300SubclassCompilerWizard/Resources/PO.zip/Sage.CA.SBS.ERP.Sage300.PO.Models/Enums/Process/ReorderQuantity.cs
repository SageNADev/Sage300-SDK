﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Process
{
    /// <summary>
    /// Enum for ReorderQuantity
    /// </summary>
    public enum ReorderQuantity
    {
        /// <summary>
        /// Gets or sets UpToMaximum
        /// </summary>
        [EnumValue("UpToMaximum", typeof(CreatePOsFromICResx))]
        UpToMaximum = 1,

        /// <summary>
        /// Gets or sets AboveMaximum
        /// </summary>
        [EnumValue("AboveMaximum", typeof(CreatePOsFromICResx))]
        AboveMaximum = 2,

        /// <summary>
        /// Gets or sets UpToProjectedSalesFor
        /// </summary>
        [EnumValue("UpToProjSale", typeof(CreatePOsFromICResx))]
        UpToProjectedSalesFor = 3,

        /// <summary>
        /// Gets or sets UpToProjSale
        /// </summary>
        [EnumValue("AboveProjSale", typeof(CreatePOsFromICResx))]
        AboveProjectedSalesFor = 4,
    }
}
