// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for ProjectType
     /// </summary>
     public enum ProjectType
     {
          /// <summary>
          /// Gets or sets 
          /// </summary>
           None   = 0,
          /// <summary>
          /// Gets or sets TimeAndMaterials
          /// </summary>
          TimeAndMaterials = 1,
          /// <summary>
          /// Gets or sets FixedPrice
          /// </summary>
          FixedPrice = 2,
          /// <summary>
          /// Gets or sets CostPlus
          /// </summary>
          CostPlus = 3,
     }
}
