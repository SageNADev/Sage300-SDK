// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for CompletionStatus
     /// </summary>
     public enum CompletionStatus
     {
          /// <summary>
          /// Gets or sets No
          /// </summary>
          No = 1,
          /// <summary>
          /// Gets or sets Yes
          /// </summary>
          Yes = 2,
          /// <summary>
          /// Gets or sets Yes
          /// </summary>
          Yes1 = 3,
     }
}
