﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    ///  Enum for Currency
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// Gets or sets FunctionalCurrency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(POCommonResx))]
        FunctionalCurrency = 0,

        /// <summary>
        /// Gets or sets CustomerCurrency
        /// </summary>
        [EnumValue("VendorCurrency", typeof(POCommonResx))]
        VendorCurrency = 1,

    }
}
