// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for CreditDebitNoteTransactionType
    /// </summary>
    public enum CreditDebitNoteTransactionType
    {
        /// <summary>
        /// Gets or sets CreditNote
        /// </summary>
        [EnumValue("CreditNote", typeof(POCommonResx))]
        CreditNote = 6,
        /// <summary>
        /// Gets or sets DebitNote
        /// </summary>
        [EnumValue("DebitNote", typeof(POCommonResx))]
        DebitNote = 7,
    }
}
