// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for AppendToExistingGLBatch
     /// </summary>
     public enum AppendToExistingGLBatch
     {
          /// <summary>
          /// Gets or sets AddingToanExistingBatch
          /// </summary>
          AddingToanExistingBatch = 1,
          /// <summary>
          /// Gets or sets CreatingaNewBatch
          /// </summary>
          CreatingaNewBatch = 0,
          /// <summary>
          /// Gets or sets CreatingAndPostingaNewBatch
          /// </summary>
          CreatingAndPostingaNewBatch = 2,
     }
}
