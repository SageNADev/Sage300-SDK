﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for POType
    /// </summary>
    public enum POType
    {
        /// <summary>
        /// Gets or sets Active
        /// </summary>        
        [EnumValue("Generated", typeof(CommonResx))]
        Active = 1,

        /// <summary>
        /// Gets or sets Standing
        /// </summary>        
        [EnumValue("Generated", typeof(CommonResx))]
        Standing = 2,

        /// <summary>
        /// Gets or sets Future
        /// </summary>        
        [EnumValue("Generated", typeof(CommonResx))]
        Future = 3,

        /// <summary>
        /// Gets or sets Blanket
        /// </summary>
        
        [EnumValue("Generated", typeof(CommonResx))]
        Blanket = 4
    }
}
