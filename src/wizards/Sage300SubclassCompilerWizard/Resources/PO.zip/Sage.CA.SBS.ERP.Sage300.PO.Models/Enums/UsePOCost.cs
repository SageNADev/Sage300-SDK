﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for UsePOCost
    /// </summary>
    public enum UsePOCost
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>        
        [EnumValue("Generated", typeof(CommonResx))]
        No = 1,

        /// <summary>
        /// Gets or sets Yes
        /// </summary>        
        [EnumValue("Generated", typeof(CommonResx))]
        Yes = 0
    }
}
