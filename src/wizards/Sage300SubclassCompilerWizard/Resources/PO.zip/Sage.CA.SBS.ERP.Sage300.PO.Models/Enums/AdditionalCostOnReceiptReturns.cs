// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for AdditionalCostOnReceiptReturns
    /// </summary>
    public enum AdditionalCostOnReceiptReturns
    {
        /// <summary>
        /// Gets or sets Leave
        /// </summary>
        [EnumValue("Leave", typeof(ICOptionResx))]
        Leave = 1,
        /// <summary>
        /// Gets or sets Prorate
        /// </summary>
        [EnumValue("Prorate", typeof(ICOptionResx))]
        Prorate = 2
    }
}