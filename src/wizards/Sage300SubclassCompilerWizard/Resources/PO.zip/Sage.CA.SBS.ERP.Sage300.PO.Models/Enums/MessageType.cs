// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
	/// <summary>
	/// Enum for MessageType
	/// </summary>
	public enum MessageType
	{
		/// <summary>
		/// Gets or sets PurchaseOrder
		/// </summary>
        [EnumValue("PurchaseOrder", typeof(EmailMessagesResx))]
		PurchaseOrder = 0,

		/// <summary>
		/// Gets or sets Return
		/// </summary>
        [EnumValue("Return", typeof(POCommonResx))]
		Return = 1
	}
}
