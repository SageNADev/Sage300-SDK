/* Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for BillingType
    /// </summary>
    public enum BillingType
    {
        /// <summary>
        /// Gets or sets 
        /// </summary>
        None = 0,
        /// <summary>
        /// Gets or sets Nonbillable
        /// </summary>
        [EnumValue("BillingType_NonBillable", typeof(POCommonResx))]
        Nonbillable = 1,
        /// <summary>
        /// Gets or sets Billable
        /// </summary>
        [EnumValue("BillingType_Billable", typeof(POCommonResx))]
        Billable = 2,
        /// <summary>
        /// Gets or sets NoCharge
        /// </summary>
        [EnumValue("BillingType_NoCharge", typeof(POCommonResx))]
        NoCharge = 3,
    }
}
