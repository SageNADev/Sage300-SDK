// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for Select Generation By
    /// </summary>
    public enum SelectGenerationBy
    {
        /// <summary>
        /// Gets or sets Requisition Number
        /// </summary>
        RequisitionNumber = 0,

        /// <summary>
        /// Gets or sets Vendor Number
        /// </summary>
        VendorNumber = 1
    }
}
