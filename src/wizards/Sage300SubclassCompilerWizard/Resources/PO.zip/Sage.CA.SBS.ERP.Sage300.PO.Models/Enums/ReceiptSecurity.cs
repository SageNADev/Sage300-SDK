﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    ///  Enum for Receipt Security
    /// </summary>
    public enum ReceiptSecurity
    {
        POReceiptUpdate=0,
        APVendorUpdate=1,
        POHistoryInquire=2,
        POInvoiceUpdate=3,
        POInvoiceInquire=4,
        POTransactionOptionalField=5,
        POCostOn=6,
        OEOrderEntryInquire=7,
        POReceivingSlipPrint=8
    }
}
