// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for CreateSubledgerAuditDuring
     /// </summary>
     public enum CreateSubledgerAuditDuring
     {
          /// <summary>
          /// Gets or sets DayEndProcessing
          /// </summary>
          DayEndProcessing = 1,
          /// <summary>
          /// Gets or sets Posting
          /// </summary>
          Posting = 2,
     }
}
