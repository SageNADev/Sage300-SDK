// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region using

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for HistoryPeriodsBy
    /// </summary>
    public enum HistoryPeriodsBy
    {
        /// <summary>
        /// Gets or sets Weekly
        /// </summary>
        [EnumValue("Weekly", typeof(OptionsResx), 1)]
        Weekly = 1,
        /// <summary>
        /// Gets or sets SevenDays
        /// </summary>
        [EnumValue("SevenDays", typeof(OptionsResx), 2)]
        SevenDays = 2,
        /// <summary>
        /// Gets or sets Biweekly
        /// </summary>
        [EnumValue("BiWeekly", typeof(OptionsResx), 3)]
        Biweekly = 3,
        /// <summary>
        /// Gets or sets FourWeeks
        /// </summary>
        [EnumValue("FourWeeks", typeof(OptionsResx), 4)]
        FourWeeks = 4,
        /// <summary>
        /// Gets or sets Monthly
        /// </summary>
        [EnumValue("Monthly", typeof(OptionsResx), 5)]
        Monthly = 5,
        /// <summary>
        /// Gets or sets Bimonthly
        /// </summary>
        [EnumValue("BiMonthly", typeof(OptionsResx), 6)]
        Bimonthly = 6,
        /// <summary>
        /// Gets or sets Quarterly
        /// </summary>
        [EnumValue("Quarterly", typeof(OptionsResx), 7)]
        Quarterly = 7,
        /// <summary>
        /// Gets or sets Semiannually
        /// </summary>
        [EnumValue("SemiAnnually", typeof(OptionsResx), 8)]
        Semiannually = 8,
        /// <summary>
        /// Gets or sets Annually
        /// </summary>
        [EnumValue("Annually", typeof(OptionsResx), 9)]
        Annually = 9,
        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [EnumValue("FiscalPeriod", typeof(CommonResx), 10)]
        FiscalPeriod = 10,
    }
}
