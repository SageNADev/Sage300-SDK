// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for Location
    /// </summary>
    public enum Location
    {
        /// <summary>
        /// Gets or sets AdditionalCosts
        /// </summary>
        [EnumValue("AdditionalCosts", typeof(POCommonResx))]
        AdditionalCosts = 0,
        /// <summary>
        /// Gets or sets Requisitions
        /// </summary>
        [EnumValue("Requisitions", typeof(POCommonResx))]
        Requisitions = 1,
        /// <summary>
        /// Gets or sets RequisitionDetails
        /// </summary>
        [EnumValue("RequisitionDetails", typeof(OptionalFieldResx))]
        RequisitionDetails = 2,
        /// <summary>
        /// Gets or sets PurchaseOrders
        /// </summary>
        [EnumValue("PurchaseOrders", typeof(POCommonResx))]
        PurchaseOrders = 3,
        /// <summary>
        /// Gets or sets PurchaseOrderDetails
        /// </summary>
        [EnumValue("PurchaseOrderDetails", typeof(OptionalFieldResx))]
        PurchaseOrderDetails = 4,
        /// <summary>
        /// Gets or sets Receipts
        /// </summary>
        [EnumValue("Receipts", typeof(POCommonResx))]
        Receipts = 5,
        /// <summary>
        /// Gets or sets ReceiptDetails
        /// </summary>
        [EnumValue("ReceiptDetails", typeof(OptionalFieldResx))]
        ReceiptDetails = 6,
        /// <summary>
        /// Gets or sets ReceiptAdditionalCosts
        /// </summary>
        [EnumValue("ReceiptAdditionalCosts", typeof(OptionalFieldResx))]
        ReceiptAdditionalCosts = 7,
        /// <summary>
        /// Gets or sets ReceiptAdditionalCostDetails
        /// </summary>
        [EnumValue("ReceiptAdditionalCostDetails", typeof(OptionalFieldResx))]
        ReceiptAdditionalCostDetails = 8,
        /// <summary>
        /// Gets or sets Invoices
        /// </summary>
        [EnumValue("Invoices", typeof(POCommonResx))]
        Invoices = 9,
        /// <summary>
        /// Gets or sets InvoiceDetails
        /// </summary>
        [EnumValue("InvoiceDetails", typeof(OptionalFieldResx))]
        InvoiceDetails = 10,
        /// <summary>
        /// Gets or sets InvoiceAdditionalCostDetails
        /// </summary>
        [EnumValue("InvoiceAdditionalCostDetails", typeof(OptionalFieldResx))]
        InvoiceAdditionalCostDetails = 11,
        /// <summary>
        /// Gets or sets Returns
        /// </summary>
        [EnumValue("Returns", typeof(POCommonResx))]
        Returns = 12,
        /// <summary>
        /// Gets or sets ReturnDetails
        /// </summary>
        [EnumValue("ReturnDetails", typeof(OptionalFieldResx))]
        ReturnDetails = 13,
        /// <summary>
        /// Gets or sets CreditDebitNotes
        /// </summary>
        [EnumValue("CreditDebitNotes", typeof(OptionalFieldResx))]
        CreditDebitNotes = 14,
        /// <summary>
        /// Gets or sets CreditDebitNoteDetails
        /// </summary>
        [EnumValue("CreditDebitNoteDetails", typeof(OptionalFieldResx))]
        CreditDebitNoteDetails = 15,
        /// <summary>
        /// Gets or sets CreditDebitNoteAdditionalCostDetails
        /// </summary>
        [EnumValue("CreditDebitNoteAdditionalCostDetails", typeof(OptionalFieldResx))]
        CreditDebitNoteAdditionalCostDetails = 16,
    }
}
