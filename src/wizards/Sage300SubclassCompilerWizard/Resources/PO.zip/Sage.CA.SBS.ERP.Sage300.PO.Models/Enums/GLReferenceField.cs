// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for GLReferenceField
    /// </summary>
    public enum GLReferenceField
    {
        /// <summary>
        /// Gets or sets DocumentNumber
        /// </summary>
        [EnumValue("DocumentNumber", typeof(ICOptionResx))]
        DocumentNumber = 1,
        /// <summary>
        /// Gets or sets ReferenceNumber
        /// </summary>
        [EnumValue("ReferenceNumber", typeof(ICOptionResx))]
        ReferenceNumber = 2,
        /// <summary>
        /// Gets or sets SourceCodeDayEndNumberEntryNumber
        /// </summary>
        [EnumValue("SourceCodeDayEndNumberEntryNumber", typeof(ICOptionResx))]
        SourceCodeDayEndNumberEntryNumber = 3,
        /// <summary>
        /// Gets or sets HeaderDescription
        /// </summary>
        [EnumValue("HeaderDescription", typeof(ICOptionResx))]
        HeaderDescription = 4,
        /// <summary>
        /// Gets or sets CustomerVendorNumber
        /// </summary>
        [EnumValue("CustomerVendorNumber", typeof(ICOptionResx))]
        CustomerVendorNumber = 5,
        /// <summary>
        /// Gets or sets CustomerVendorName
        /// </summary>
        [EnumValue("CustomerVendorName", typeof(ICOptionResx))]
        CustomerVendorName = 6
    }
}