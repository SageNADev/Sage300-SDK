﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    public enum SelectedBy
    {
        /// <summary>
        /// Gets or sets CustomerNumber
        /// </summary>
        [EnumValue("VendorNumber", typeof(POCommonResx))]
        VendorNumber = 0,

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [EnumValue("ItemNumber", typeof(POCommonResx))]
        ItemNumber = 1,

    }
}
