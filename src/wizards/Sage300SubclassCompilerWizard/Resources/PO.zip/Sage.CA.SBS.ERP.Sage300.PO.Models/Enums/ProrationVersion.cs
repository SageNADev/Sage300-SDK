// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for ProrationVersion
     /// </summary>
     public enum ProrationVersion
     {
          /// <summary>
          /// Gets or sets Num30A
          /// </summary>
         [EnumValue("Num30A", typeof(ReturnEntryResx))]
         Num30A = 1,
          /// <summary>
          /// Gets or sets Num53B
          /// </summary>
         [EnumValue("Num53B", typeof(ReturnEntryResx))]
         Num53B = 2,
     }
}
