﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for CreditDebitNote Additional Cost Operation
    /// </summary>
    public enum CrdrAdditionalCostOperation
    {
        ApplyCost = 1,
        ReApplyCost = 2,
        ClearCost = 3,
        DeleteZeroCosts = 4
    }
}
