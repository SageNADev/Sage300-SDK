// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for SeparatorPeriod
    /// </summary>
    public enum SeparatorPeriod
    {
        /// <summary>
        /// Gets or sets Period
        /// </summary>
        [EnumValue("Period", typeof(ICOptionResx))]
        Period = 1
    }
}