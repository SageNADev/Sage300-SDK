// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Included Segment
     /// </summary>
     public enum IncludedSegment
     {
          /// <summary>
          /// Gets or sets None
          /// </summary>
          None = 0,
          /// <summary>
          /// Gets or sets Additional Cost
          /// </summary>
          AdditionalCost = 1,
          /// <summary>
          /// Gets or sets Additional Cost Description
          /// </summary>
          AdditionalCostDescription = 2,
          /// <summary>
          /// Gets or sets Bill To Description
          /// </summary>
          BillToDescription = 3,
          /// <summary>
          /// Gets or sets Bill To Location
          /// </summary>
          BillToLocation = 4,
          /// <summary>
          /// Gets or sets Category
          /// </summary>
          Category = 5,
          /// <summary>
          /// Gets or sets Comments
          /// </summary>
          Comments = 6,
          /// <summary>
          /// Gets or sets Contact Name
          /// </summary>
          ContactName = 7,
          /// <summary>
          /// Gets or sets Contract
          /// </summary>
          Contract = 8,
          /// <summary>
          /// Gets or sets Credit Note Number
          /// </summary>
          CreditNoteNumber = 37,
          /// <summary>
          /// Gets or sets Day End Number
          /// </summary>
          DayEndNumber = 9,
          /// <summary>
          /// Gets or sets Debit Note Number
          /// </summary>
          DebitNoteNumber = 38,
          /// <summary>
          /// Gets or sets Description
          /// </summary>
          Description = 10,
          /// <summary>
          /// Gets or sets Detail Description
          /// </summary>
          DetailDescription = 11,
          /// <summary>
          /// Gets or sets Document Number
          /// </summary>
          DocumentNumber = 12,
          /// <summary>
          /// Gets or sets DocumentType
          /// </summary>
          DocumentType = 13,
          /// <summary>
          /// Gets or sets Entry Number
          /// </summary>
          EntryNumber = 14,
          /// <summary>
          /// Gets or sets From Document
          /// </summary>
          FromDocument = 15,
          /// <summary>
          /// Gets or sets Invoice Number
          /// </summary>
          InvoiceNumber = 16,
          /// <summary>
          /// Gets or sets ItemNumber
          /// </summary>
          ItemNumber = 17,
          /// <summary>
          /// Gets or sets Location
          /// </summary>
          Location = 18,
          /// <summary>
          /// Gets or sets Location Name
          /// </summary>
          LocationName = 19,
          /// <summary>
          /// Gets or sets Manufacturers Item Number
          /// </summary>
          ManufacturersItemNumber = 20,
          /// <summary>
          /// Gets or sets Order Number
          /// </summary>
          OrderNumber = 21,
          /// <summary>
          /// Gets or sets Project
          /// </summary>
          Project = 22,
          /// <summary>
          /// Gets or sets Purchase Order Number
          /// </summary>
          PurchaseOrderNumber = 23,
          /// <summary>
          /// Gets or sets Receipt Number
          /// </summary>
          ReceiptNumber = 24,
          /// <summary>
          /// Gets or sets Reference
          /// </summary>
          Reference = 25,
          /// <summary>
          /// Gets or sets Remit ToLocation
          /// </summary>
          RemitToLocation = 26,
          /// <summary>
          /// Gets or sets Return Number
          /// </summary>
          ReturnNumber = 27,
          /// <summary>
          /// Gets or sets Return Invoice Number
          /// </summary>
          ReturnInvoiceNumber = 28,
          /// <summary>
          /// Gets or sets Ship To Location
          /// </summary>
          ShipToLocation = 29,
          /// <summary>
          /// Gets or sets Ship Via
          /// </summary>
          ShipVia = 30,
          /// <summary>
          /// Gets or sets Ship Via Description
          /// </summary>
          ShipViaDescription = 31,
          /// <summary>
          /// Gets or sets Source  Code
          /// </summary>
          SourceCode = 32,
          /// <summary>
          /// Gets or sets Unformatted Item Number
          /// </summary>
          UnformattedItemNumber = 33,
          /// <summary>
          /// Gets or sets Vendor Item Number
          /// </summary>
          VendorItemNumber = 34,
          /// <summary>
          /// Gets or sets Vendor Name
          /// </summary>
          VendorName = 35,
          /// <summary>
          /// Gets or sets Vendor Number
          /// </summary>
          VendorNumber = 36,
     }
}
