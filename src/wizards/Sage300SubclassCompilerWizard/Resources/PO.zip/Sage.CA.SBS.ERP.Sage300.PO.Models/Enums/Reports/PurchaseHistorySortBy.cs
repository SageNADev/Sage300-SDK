﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum For Purchase History Report Sort By Sort List
    /// </summary>
    public enum PurchaseHistorySortBy
    {
        /// <summary>
        /// Item Number
        /// </summary>
        [EnumValue("ItemNumber", typeof(POCommonResx), 2)]
        ItemNumber = 1,

        /// <summary>
        /// Vendor Number
        /// </summary>
        [EnumValue("VendorNumber", typeof(POCommonResx), 1)]
        VendorNumber = 2
    }
}
