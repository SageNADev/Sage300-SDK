﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{

    /// <summary>
    /// Enum Purchase Order Action Print Status
    /// </summary>
    public enum PurchaseOrderPrintStatus
    {
        #region enums

        /// <summary>
        ///  Gets or sets All 
        /// </summary>
        [EnumValue("PrntStatusAll", typeof(PurchaseOrderActionReportResx))]
        All = 1,

        /// <summary>
        ///  Gets or sets Posted 
        /// </summary>
        [EnumValue("Posted", typeof(CommonResx))]
        Posted = 2,

        /// <summary>
        ///  Gets or sets PurchaseOrderPrinted 
        /// </summary>
        [EnumValue("PrntStatusPrinted", typeof(PurchaseOrderActionReportResx))]
        PurchaseOrderPrinted = 3

        #endregion
    }
}