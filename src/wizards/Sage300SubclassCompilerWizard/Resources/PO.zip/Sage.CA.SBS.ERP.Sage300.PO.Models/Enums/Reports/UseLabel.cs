﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Use Label Enum
    /// </summary>
    public enum UseLabel
    {
        /// <summary>
        /// Gets or sets PORET01
        /// </summary>
        [EnumValue("POLABEL", typeof(MailingLabelsResx), 1)]
        POLABEL = 0,

        /// <summary>
        /// Gets or sets PORET02
        /// </summary>
        [EnumValue("POLABELP", typeof(MailingLabelsResx), 2)]
        POLABELP = 1,
    }
}
