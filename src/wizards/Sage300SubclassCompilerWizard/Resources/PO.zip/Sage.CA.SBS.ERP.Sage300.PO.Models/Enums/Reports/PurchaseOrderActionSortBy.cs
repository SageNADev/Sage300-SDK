﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum Purchase Order Action Sort By
    /// </summary>
    public enum PurchaseOrderActionSortBy
    {
        #region enums

        /// <summary>
        ///  Gets or sets PurchaseOrderNumber 
        /// </summary>
        [EnumValue("PurchaseOrderNumber", typeof(PurchaseOrderActionReportResx))]
        PurchaseOrderNumber = 1,

        /// <summary>
        ///  Gets or sets VendorNumber 
        /// </summary>
        [EnumValue("VendorNumber", typeof(POCommonResx))]
        VendorNumber = 2,

        /// <summary>
        ///  Gets or sets ItemNo 
        /// </summary>
        [EnumValue("ItemNumber", typeof(POCommonResx))]
        ItemNo = 3

        #endregion
    }
}