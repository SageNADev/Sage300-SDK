﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum For Purchase History Report Sort By Select List
    /// </summary>
    public enum PurchaseHistorySelectBy
    {
        /// <summary>
        /// Document Date
        /// </summary>
        [EnumValue("DocumentDate", typeof(POCommonResx))]
        DocumentDate = 0,

        /// <summary>
        /// Year and Period
        /// </summary>
        [EnumValue("YearPeriod", typeof(POCommonResx))]
        YearAndPeriod = 1
    }
}
