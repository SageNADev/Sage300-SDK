﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Currency Type
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(POCommonResx), 1)]
        FunctionalCurrency = 0,

        /// <summary>
        /// Gets or sets Vendor Currency
        /// </summary>
        [EnumValue("VendorCurrency", typeof(POCommonResx), 2)]
        VendorCurrency = 1,

    }
}
