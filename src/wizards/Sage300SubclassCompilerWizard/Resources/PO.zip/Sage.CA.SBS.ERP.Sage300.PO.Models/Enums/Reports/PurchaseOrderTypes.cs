﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum Purchase Order Types
    /// </summary>
    public enum PurchaseOrderTypes
    {
        #region enums

        /// <summary>
        ///  Gets or sets All 
        /// </summary>
        [EnumValue("POTypeAll", typeof(PurchaseOrderActionReportResx))]
        AllPurchaseOrders = 1,

        /// <summary>
        ///  Gets or sets NeverReceived 
        /// </summary>
        [EnumValue("POTypeNeverReceived", typeof(PurchaseOrderActionReportResx))]
        NeverReceived = 2,

        /// <summary>
        ///  Gets or sets POTypePartReceived 
        /// </summary>
        [EnumValue("POTypePartReceived", typeof(PurchaseOrderActionReportResx))]
        PartiallyReceived = 3,

        /// <summary>
        ///  Gets or sets NeverPartiallyReceived 
        /// </summary>
        [EnumValue("POTypeNeverOrPartRecvd", typeof(PurchaseOrderActionReportResx))]
        NeverPartiallyReceived = 4,

        /// <summary>
        ///  Gets or sets OnHold 
        /// </summary>
        [EnumValue("POTypeOnHold", typeof(PurchaseOrderActionReportResx))]
        OnHold = 5,

        #endregion

    }
}