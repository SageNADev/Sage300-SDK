﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    public enum TransactionReportType
    {
        /// <summary>
        /// Detail
        /// </summary>
        [EnumValue("Detail", typeof(EnumerationsResx))]
        Detail = 1,

        /// <summary>
        /// Summary
        /// </summary>
        [EnumValue("Summary", typeof(EnumerationsResx))]
        Summary = 2
    }
}
