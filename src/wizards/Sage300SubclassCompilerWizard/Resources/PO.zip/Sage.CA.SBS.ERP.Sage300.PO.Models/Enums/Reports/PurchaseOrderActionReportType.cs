﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum Purchase Order Action ReportType
    /// </summary>
    public enum PurchaseOrderActionReportType
    {
        #region enums

        /// <summary>
        ///  Gets or sets Detail 
        /// </summary>
        [EnumValue("Detail", typeof(POCommonResx))]
        Detail = 1,

        /// <summary>
        ///  Gets or sets Summary 
        /// </summary>
        [EnumValue("Summary", typeof(POCommonResx))]
        Summary = 2

        #endregion
    }
}