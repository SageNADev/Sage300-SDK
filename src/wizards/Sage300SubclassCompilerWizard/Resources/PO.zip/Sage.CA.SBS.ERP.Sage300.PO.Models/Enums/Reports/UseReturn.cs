﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Use Return Enum
    /// </summary>
    public enum UseReturn
    {
        /// <summary>
        /// Gets or sets PORET01
        /// </summary>
        [EnumValue("PORET01", typeof(ReturnsResx), 1)]
        PORET01 = 0,

        /// <summary>
        /// Gets or sets PORET02
        /// </summary>
        [EnumValue("PORET02", typeof(ReturnsResx), 2)]
        PORET02 = 1,
    }
}
