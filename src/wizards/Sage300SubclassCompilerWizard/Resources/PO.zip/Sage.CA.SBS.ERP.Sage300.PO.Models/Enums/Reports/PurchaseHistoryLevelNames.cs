﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Level Names For Purchase History Report
    /// </summary>
    public enum PurchaseHistoryLevelNames
    {
        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [EnumValue("Contract", typeof(PurchaseHistoryReportResx))]
        Contract = 0,

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [EnumValue("Project", typeof(PurchaseHistoryReportResx))]
        Project = 1,

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [EnumValue("Category", typeof(PurchaseHistoryReportResx))]
        Category = 4,


    }
}
