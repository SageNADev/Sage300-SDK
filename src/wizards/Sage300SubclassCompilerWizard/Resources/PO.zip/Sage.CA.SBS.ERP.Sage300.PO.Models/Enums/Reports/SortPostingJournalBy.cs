// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Sort Posting Journal By
    /// </summary>
    public enum SortPostingJournalBy
    {
        /// <summary>
        /// Day End Number
        /// </summary>
        DayEndNumber = 0,

        /// <summary>
        /// Transaction Date 
        /// </summary>
        TransactionDate = 1,

        /// <summary>
        /// Vendor Number
        /// </summary>
        VendorNumber = 2,

        /// <summary>
        /// Document Number
        /// </summary>
        DocumentNumber = 3,
    }
}