// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Sort by for Aged Purchase Order
    /// </summary>
    public enum SortBy
    {
        /// <summary>
        /// Gets or sets PONumber
        /// </summary>
        [EnumValue("PONumber", typeof(POCommonResx))]
        PONumber = 0,

        /// <summary>
        ///Vendor Number 
        /// </summary>
        [EnumValue("VendorNumber", typeof(POCommonResx))]
        VendorNumber = 1,

        /// <summary>
        ///Currency 
        /// </summary>
        [EnumValue("Currency", typeof(POCommonResx))]
        Currency = 2,


       
    }
}