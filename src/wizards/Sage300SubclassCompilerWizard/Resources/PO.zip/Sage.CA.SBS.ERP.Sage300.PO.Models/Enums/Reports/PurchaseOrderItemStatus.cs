﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{

    /// <summary>
    /// Enum Purchase Order Action Item Status
    /// </summary>
    public enum PurchaseOrderItemStatus
    {
        #region enums

        /// <summary>
        ///  Gets or sets All 
        /// </summary>
        [EnumValue("ItmStatusAll", typeof(PurchaseOrderActionReportResx))]
        All = 1,

        /// <summary>
        ///  Gets or sets CompletedWithNoReceipt 
        /// </summary>
        [EnumValue("ItmStatusCompNoRcpt", typeof(PurchaseOrderActionReportResx))]
        CompletedWithNoReceipt = 2,

        /// <summary>
        ///  Gets or sets Incomplete 
        /// </summary>
        [EnumValue("ItmStatusIncomplete", typeof(PurchaseOrderActionReportResx))]
        Incomplete = 3,

        /// <summary>
        ///  Gets or sets Completed 
        /// </summary>
        [EnumValue("Completed", typeof(PurchaseOrderActionReportResx))]
        Completed = 4,

        #endregion

    }
}