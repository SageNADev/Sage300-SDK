﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    public enum PurchaseOrderReportType
    {
         /// <summary>
        ///  Gets or sets POPOR01.RPT
        /// </summary>
        [EnumValue("POPOR01", typeof(PurchaseOrdersResx))]
        POPOR02 = 0,

        /// <summary>
        ///  Gets or sets Summary 
        /// </summary>
        [EnumValue("POPOR02", typeof(PurchaseOrdersResx))]
        POPOR02T = 1
    }
}
  