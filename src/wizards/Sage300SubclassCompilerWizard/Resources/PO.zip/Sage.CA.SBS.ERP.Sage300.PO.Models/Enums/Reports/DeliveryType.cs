﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
#endregion
namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    public enum DeliveryType
    {
        Email = 1,

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [EnumValue("Vendor", typeof(POCommonResx), 2)]
        Vendor = 2,

        /// <summary>
        /// Gets or sets PrintDestination
        /// </summary>
        [EnumValue("PrintDestination", typeof (POCommonResx), 1)] 
        PrintDestination = 3,
      
    }
}
