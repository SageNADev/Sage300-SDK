// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
	/// <summary>
	/// Enum for SelectItem
	/// </summary>
	public enum SelectItem
	{
		/// <summary>
		/// Gets or sets PurchaseOrder
		/// </summary>
        [EnumValue("PurchaseOrder", typeof(PurchaseOrderActionReportResx))]
		PurchaseOrder = 1,

		/// <summary>
		/// Gets or sets Return
		/// </summary>
        [EnumValue("Return", typeof(Resources.Forms.GLIntegrationResx))]
		Return = 2
	}
}
