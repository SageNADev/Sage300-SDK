﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Transaction Listing SortBy Type enum
    /// </summary>
    public enum TransactionListSortBy
    {
        #region Enum for TransactionListSortBy

        /// <summary>
        /// The Requisitions Number
        /// </summary>
        [EnumValue("RequisitionNumber", typeof(POCommonResx))]
        RequisitionsNumber = 0,


        /// <summary>
        /// The Purchase Orders Number
        /// </summary>
        [EnumValue("PurchaseOrdersNumber", typeof(TransactionListResx))]
        PurchaseOrdersNumber = 1,

        /// <summary>
        /// The Receipts Number
        /// </summary>
        [EnumValue("ReceiptNumber", typeof(POCommonResx))]
        ReceiptsNumber = 2,

        /// <summary>
        /// The Invoices Number 
        /// </summary>
        [EnumValue("InvoiceNumber", typeof(POCommonResx))]
        InvoicesNumber = 3,


        /// <summary>
        /// The Returns Number
        /// </summary>
        [EnumValue("ReturnsNumber", typeof(TransactionListResx))]
        ReturnsNumber = 4,

        /// <summary>
        /// The credit debit note number
        /// </summary>
        [EnumValue("CreditNotesNumber", typeof(TransactionListResx))]
        CreditNotesNumber = 5,

        /// <summary>
        /// The credit debit note number
        /// </summary>
        [EnumValue("DebitNotesNumber", typeof(TransactionListResx))]
        DebitNotesNumber = 6,

        /// <summary>
        ///Customer Number
        /// </summary>
        [EnumValue("VendorNumber", typeof(POCommonResx))]
        VendorNumber = 7,

        #endregion

    }
}
