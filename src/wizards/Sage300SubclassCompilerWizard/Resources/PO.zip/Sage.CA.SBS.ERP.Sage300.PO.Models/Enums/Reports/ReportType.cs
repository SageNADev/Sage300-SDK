﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Report Type Enum
    /// </summary>
    public enum ReportType
    {
        /// <summary>
        /// Gets or sets POPOR01
        /// </summary>
        [EnumValue("POPOR01", typeof(PurchaseOrdersResx), 1)]
        POPOR01 = 0,

        /// <summary>
        /// Gets or sets POPOR02
        /// </summary>
        [EnumValue("POPOR02", typeof(PurchaseOrdersResx), 2)]
        POPOR02 = 1,
    }
}
