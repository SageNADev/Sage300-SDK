﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    public enum TransactionPrintType
    {
        /// <summary>
        /// The orders
        /// </summary>
        [EnumValue("Requisitions", typeof(TransactionListResx))]
        Requisitions = 0,


        /// <summary>
        /// The orders
        /// </summary>
        [EnumValue("PurchaseOrders", typeof(TransactionListResx))]
        PurchaseOrders = 1,


        /// <summary>
        /// The orders
        /// </summary>
        [EnumValue("Receipts", typeof(POCommonResx))]
        Receipts = 2,


        /// <summary>
        /// The invoices
        /// </summary>
        [EnumValue("Invoices", typeof(POCommonResx))]
        Invoices = 3,

        /// <summary>
        /// The shipments
        /// </summary>
        [EnumValue("Returns", typeof(TransactionListResx))]
        Returns = 4,

        /// <summary>
        /// The credit  notes
        /// </summary>
        [EnumValue("CreditNotes", typeof(TransactionListResx))]
        CreditNotes = 5,

        /// <summary>
        /// The debit notes
        /// </summary>
        [EnumValue("DebitNotes", typeof(TransactionListResx))]
        DebitNotes = 6
    }
}
