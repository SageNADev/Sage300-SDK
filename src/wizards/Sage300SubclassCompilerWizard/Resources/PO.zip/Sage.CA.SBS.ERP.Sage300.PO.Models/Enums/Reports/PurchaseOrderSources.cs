﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion


namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum Purchase Order Sources
    /// </summary>
    public enum PurchaseOrderSources
    {

        #region enums

        /// <summary>
        ///  Gets or sets All 
        /// </summary>
        [EnumValue("POSourceAll", typeof(PurchaseOrderActionReportResx))]
        AllSource = 1,

        /// <summary>
        ///  Gets or sets Entered 
        /// </summary>
        [EnumValue("Entered", typeof(CommonResx))]
        Entered = 2,

        /// <summary>
        ///  Gets or sets Internet 
        /// </summary>
        [EnumValue("Internet", typeof(PurchaseOrderActionReportResx))]
        Internet = 3

        #endregion

    }
}