﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
#endregion
namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Delivery Method Type
    /// </summary>
    public enum DeliveryMethodType
    {
        /// <summary>
        /// Gets or sets Print Destination
        /// </summary>
        [EnumValue("PrintDestination", typeof(POCommonResx), 1)]
        PrintDestination = 3,

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [EnumValue("Vendor", typeof(POCommonResx), 2)]
        Vendor = 2,
    }
}
