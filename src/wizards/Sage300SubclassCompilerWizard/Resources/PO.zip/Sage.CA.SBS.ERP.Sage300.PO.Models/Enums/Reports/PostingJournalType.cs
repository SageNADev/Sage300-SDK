﻿
namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Posting Journal Type 
    /// </summary>
    public enum PostingJournalType
    {
        /// <summary>
        /// Gets or sets Adjustments
        /// </summary>	
        Receipt = 0,

        /// <summary>
        /// Gets or sets Assemblies
        /// </summary>	
        Return = 1,

        /// <summary>
        /// Gets or sets Receipts
        /// </summary>	
        Invoice = 2,

        /// <summary>
        /// Gets or sets Shipments
        /// </summary>	
        CreditDebitNote = 3,
    }
}
