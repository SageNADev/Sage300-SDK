﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Use Return Enum
    /// </summary>
    public enum UseRequisition
    {
        /// <summary>
        /// Gets or sets PORQN01
        /// </summary>
        [EnumValue("PORQN01", typeof(RequisitionsResx), 1)]
        PORQN01 = 0,

        /// <summary>
        /// Gets or sets PORQN02
        /// </summary>
        [EnumValue("PORQN02", typeof(RequisitionsResx), 2)]
        PORQN02 = 1,
    }
}
