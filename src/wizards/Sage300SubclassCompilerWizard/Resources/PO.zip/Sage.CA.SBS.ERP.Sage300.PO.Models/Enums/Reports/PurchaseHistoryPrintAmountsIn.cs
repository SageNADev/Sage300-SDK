﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum Print Amounts In
    /// </summary>
    public enum PurchaseHistoryPrintAmountsIn
    {
        /// <summary>
        /// Gets or sets Vendor Currency
        /// </summary>
        [EnumValue("VendorCurrency", typeof(POCommonResx), 2)]
        VendorCurrency = 0,

        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(POCommonResx), 1)]
        FunctionalCurrency = 1,
    }
}
