﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum for Print Amount In
    /// </summary>
    public enum PurchaseOrderPrintAmountIn
    {
        #region enums

        /// <summary>
        /// Gets or sets Functional Currency 
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(CommonResx))]
        FunctionalCurrency = 1,

        /// <summary>
        /// Gets or sets Source Currency 
        /// </summary>
        [EnumValue("SourceCurrency", typeof(PurchaseOrderActionReportResx))]
        SourceCurrency = 2

        #endregion
    }
}