﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Enum Purchase Order Action Select By
    /// </summary>
    public enum PurchaseOrderActionSelectBy
    {
        #region enums

        /// <summary>
        ///  Gets or sets Detail 
        /// </summary>
        [EnumValue("ExpectedArrivalDate", typeof(PurchaseOrderActionReportResx))]
        ExpectedArrivalDate = 1,

        /// <summary>
        ///  Gets or sets Summary 
        /// </summary>
        [EnumValue("PurchaseOrderDate", typeof(PurchaseOrderActionReportResx))]
        PurchaseOrderDate = 2

        #endregion

    }
}