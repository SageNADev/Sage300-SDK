﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.PO.Resources.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Models;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Reports
{
    /// <summary>
    /// Use Return Enum
    /// </summary>
    public enum UseReceivingSlip
    {
        /// <summary>
        /// Gets or sets PORCP01
        /// </summary>
        [EnumValue("PORCP01", typeof(ReceivingSlipsResx), 1)]
        PORCP01 = 0,

        /// <summary>
        /// Gets or sets PORCP02
        /// </summary>
        [EnumValue("PORCP02", typeof(ReceivingSlipsResx), 2)]
        PORCP02 = 1,

        /// <summary>
        /// Gets or sets PORCP03
        /// </summary>
        [EnumValue("PORCP03", typeof(ReceivingSlipsResx), 3)]
        PORCP03 = 2,

        /// <summary>
        /// Gets or sets PORCP02
        /// </summary>
        [EnumValue("PORCP04", typeof(ReceivingSlipsResx), 4)]
        PORCP04 = 3,

    }
}
