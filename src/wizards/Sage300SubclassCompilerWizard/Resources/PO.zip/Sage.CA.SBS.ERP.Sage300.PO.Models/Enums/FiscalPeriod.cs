// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for FiscalPeriod
     /// </summary>
     public enum FiscalPeriod
     {
          /// <summary>
          /// Gets or sets Num1
          /// </summary>
         [EnumValue("Num1", typeof(ReturnEntryResx))]
         Num1 = 1,
          /// <summary>
          /// Gets or sets Num2
          /// </summary>
         [EnumValue("Num2", typeof(ReturnEntryResx))]
         Num2 = 2,
          /// <summary>
          /// Gets or sets Num3
          /// </summary>
         [EnumValue("Num3", typeof(ReturnEntryResx))]
         Num3 = 3,
          /// <summary>
          /// Gets or sets Num4
          /// </summary>
         [EnumValue("Num4", typeof(ReturnEntryResx))]
         Num4 = 4,
          /// <summary>
          /// Gets or sets Num5
          /// </summary>
         [EnumValue("Num5", typeof(ReturnEntryResx))]
         Num5 = 5,
          /// <summary>
          /// Gets or sets Num6
          /// </summary>
         [EnumValue("Num6", typeof(ReturnEntryResx))]
         Num6 = 6,
          /// <summary>
          /// Gets or sets Num7
          /// </summary>
         [EnumValue("Num7", typeof(ReturnEntryResx))]
         Num7 = 7,
          /// <summary>
          /// Gets or sets Num8
          /// </summary>
         [EnumValue("Num8", typeof(ReturnEntryResx))]
         Num8 = 8,
          /// <summary>
          /// Gets or sets Num9
          /// </summary>
         [EnumValue("Num9", typeof(ReturnEntryResx))]
         Num9 = 9,
          /// <summary>
          /// Gets or sets Num10
          /// </summary>
         [EnumValue("Num10", typeof(ReturnEntryResx))]
         Num10 = 10,
          /// <summary>
          /// Gets or sets Num11
          /// </summary>
         [EnumValue("Num11", typeof(ReturnEntryResx))]
         Num11 = 11,
          /// <summary>
          /// Gets or sets Num12
          /// </summary>
         [EnumValue("Num12", typeof(ReturnEntryResx))]
         Num12 = 12,
     }
}
