// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for VendorType
    /// </summary>
    public enum VendorType
    {
        /// <summary>
        /// Gets or sets Vendor1
        /// </summary>
        [EnumValue("Vendor1", typeof(EnumerationsResx), 1)]
        Vendor1 = 1,

        /// <summary>
        /// Gets or sets Vendor2
        /// </summary>
        [EnumValue("Vendor2", typeof(EnumerationsResx), 2)]
        Vendor2 = 2,

        /// <summary>
        /// Gets or sets Vendor3
        /// </summary>
        [EnumValue("Vendor3", typeof(EnumerationsResx), 3)]
        Vendor3 = 3,

        /// <summary>
        /// Gets or sets Vendor4
        /// </summary>
        [EnumValue("Vendor4", typeof(EnumerationsResx), 4)]
        Vendor4 = 4,

        /// <summary>
        /// Gets or sets Vendor5
        /// </summary>
        [EnumValue("Vendor5", typeof(EnumerationsResx), 5)]
        Vendor5 = 5,

        /// <summary>
        /// Gets or sets Vendor6
        /// </summary>
        [EnumValue("Vendor6", typeof(EnumerationsResx), 6)]
        Vendor6 = 6,

        /// <summary>
        /// Gets or sets Vendor7
        /// </summary>
        [EnumValue("Vendor7", typeof(EnumerationsResx), 7)]
        Vendor7 = 7,

        /// <summary>
        /// Gets or sets Vendor8
        /// </summary>
        [EnumValue("Vendor8", typeof(EnumerationsResx), 8)]
        Vendor8 = 8,

        /// <summary>
        /// Gets or sets Vendor9
        /// </summary>
        [EnumValue("Vendor9", typeof(EnumerationsResx), 9)]
        Vendor9 = 9
    }
}
