// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for UpdateLocationDetailsMinQty
    /// </summary>
    public enum UpdateLocationDetailsMinQty
    {
        /// <summary>
        /// Gets or sets No
        /// </summary>
        [EnumValue("No", typeof(ICOptionResx))]
        No = 0,
        /// <summary>
        /// Gets or sets Yes
        /// </summary>
        [EnumValue("Yes", typeof(ICOptionResx))]
        Yes = 1
    }
}