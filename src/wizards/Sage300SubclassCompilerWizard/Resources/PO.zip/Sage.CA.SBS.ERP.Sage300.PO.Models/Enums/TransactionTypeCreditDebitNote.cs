// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for TransactionType
    /// </summary>
    public enum TransactionTypeCreditDebitNote
    {
        /// <summary>
        /// Gets or sets CreditNote
        /// </summary>
        CreditNote = 0,
        /// <summary>
        /// Gets or sets DebitNote
        /// </summary>
        DebitNote = 1,
    }
}
