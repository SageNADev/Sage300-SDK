// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for RetainageExchangeRate
     /// </summary>
     public enum RetainageExchangeRate
     {
          /// <summary>
          /// Gets or sets UseOriginalDocumentExchangeRate
          /// </summary>
         [EnumValue("UseOriginalDocumentExchangeRate", typeof(ReturnEntryResx))]
         UseOriginalDocumentExchangeRate = 0,
          /// <summary>
          /// Gets or sets UseCurrentExchangeRate
          /// </summary>
         [EnumValue("UseCurrentExchangeRate", typeof(ReturnEntryResx))]
         UseCurrentExchangeRate = 1,
     }
}
