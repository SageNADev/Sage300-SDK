// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for ConsolidateGLBatch
    /// </summary>
    public enum ConsolidateGLBatch
    {
        /// <summary>
        /// Gets or sets DoNotConsolidate
        /// </summary>
        [EnumValue("DoNotConsolidate", typeof(ICOptionResx))]
        DoNotConsolidate = 1,
        /// <summary>
        /// Gets or sets ConsolidateTransactionDetailsByAccount
        /// </summary>
        [EnumValue("ConsolidateTransactionDetailsByAccount", typeof(ICOptionResx))]
        ConsolidateTransactionDetailsByAccount = 9,
        /// <summary>
        /// Gets or sets ConsolidateByAccountAndFiscalPeriod
        /// </summary>
        [EnumValue("ConsolidateByAccountAndFiscalPeriod", typeof(ICOptionResx))]
        ConsolidateByAccountAndFiscalPeriod = 2,
        /// <summary>
        /// Gets or sets ConsolidateByAccountFiscalPeriodAndSource
        /// </summary>
        [EnumValue("ConsolidateByAccountFiscalPeriodAndSource", typeof(ICOptionResx))]
        ConsolidateByAccountFiscalPeriodAndSource = 3
    }
}