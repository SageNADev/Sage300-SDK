// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for PredTaxReportingRateOper
    /// </summary>
    public enum PredTaxReportingRateOper
    {
        /// <summary>
        /// Gets or sets Multiply 
        /// </summary>	
       [EnumValue("Multiply", typeof(POCommonResx))]
        Multiply = 1,

        /// <summary>
        /// Gets or sets Divide 
        /// </summary>	
        [EnumValue("Divide", typeof(POCommonResx))]
        Divide = 2,

    }
}
