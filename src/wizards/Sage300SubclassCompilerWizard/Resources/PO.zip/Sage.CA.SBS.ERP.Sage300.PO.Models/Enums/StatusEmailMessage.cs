// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
	/// <summary>
	/// Enum for Status
	/// </summary>
	public enum StatusEmailMessage
	{
		/// <summary>
		/// Gets or sets Inactive
		/// </summary>
        [EnumValue("Inactive", typeof(CommonResx))]
		Inactive = 0,

		/// <summary>
		/// Gets or sets Active
		/// </summary>
        [EnumValue("Active", typeof(CommonResx))]
		Active = 1
	}
}
