// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Rounding Method
     /// </summary>
     public enum RoundingMethod
     {
          /// <summary>
          /// Gets or sets No Rounding
          /// </summary>
          [EnumValue("NoRounding", typeof(VendorContractCostsResx), 1)] 
          NoRounding = 1,
          /// <summary>
          /// Gets or sets Round Up
          /// </summary>
          [EnumValue("RoundUp", typeof(VendorContractCostsResx), 2)]
          RoundUp = 2,
          /// <summary>
          /// Gets or sets Round Down
          /// </summary>
          [EnumValue("RoundDown", typeof(VendorContractCostsResx), 3)] 
          RoundDown = 3,
     }
}
