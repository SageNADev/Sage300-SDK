// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Type
     /// </summary>
     public enum Type
     {
          /// <summary>
          /// Gets or sets Text
          /// </summary>
         [EnumValue("Text", typeof(POCommonResx))] 
         Text = 1,
          /// <summary>
          /// Gets or sets Amount
          /// </summary>
         [EnumValue("Amount", typeof(POCommonResx))]  
         Amount = 100,
          /// <summary>
          /// Gets or sets Number
          /// </summary>
         [EnumValue("Number", typeof(POCommonResx))]  
         Number = 6,
          /// <summary>
          /// Gets or sets Integer
          /// </summary>
         [EnumValue("Integer", typeof(POCommonResx))]  
         Integer = 8,
          /// <summary>
          /// Gets or sets YesNo
          /// </summary>
         [EnumValue("YesNo", typeof(POCommonResx))]  
         YesNo = 9,
          /// <summary>
          /// Gets or sets Date
          /// </summary>
         [EnumValue("Date", typeof(POCommonResx))]  
         Date = 3,
          /// <summary>
          /// Gets or sets Time
          /// </summary>
          [EnumValue("Time", typeof(POCommonResx))] 
         Time = 4,
     }
}
