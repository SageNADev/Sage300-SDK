// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for DropShipType
     /// </summary>
     public enum DropShipType
     {
          /// <summary>
          /// Gets or sets AddressEntered
          /// </summary>
          AddressEntered = 2,
          /// <summary>
          /// Gets or sets InventoryLocationAddress
          /// </summary>
          InventoryLocationAddress = 3,
          /// <summary>
          /// Gets or sets CustomerAddress
          /// </summary>
          CustomerAddress = 4,
          /// <summary>
          /// Gets or sets CustomerShipToAddress
          /// </summary>
          CustomerShipToAddress = 5,
     }
}
