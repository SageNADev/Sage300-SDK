// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region using
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for DefaultPostingDate
    /// </summary>
    public enum DefaultPostingDate
    {
        /// <summary>
        /// Gets or sets DocumentDate
        /// </summary>
        [EnumValue("DocumentDate", typeof(POCommonResx), 1)]
        DocumentDate = 1,
        /// <summary>
        /// Gets or sets SessionDate
        /// </summary>
        [EnumValue("SessionDate", typeof(CommonResx), 1)]
        SessionDate = 2
    }
}
