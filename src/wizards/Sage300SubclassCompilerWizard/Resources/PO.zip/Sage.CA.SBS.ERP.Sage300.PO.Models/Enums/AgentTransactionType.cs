// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for AgentTransactionType
     /// </summary>
     public enum AgentTransactionType
     {
          /// <summary>
          /// Gets or sets None
          /// </summary>
         [EnumValue("None", typeof(CommonResx))] 
         None = 0,

          /// <summary>
          /// Gets or sets Receipt
          /// </summary>
         [EnumValue("Receipt", typeof(POCommonResx))]  
         Receipt = 3,

          /// <summary>
          /// Gets or sets Invoice
          /// </summary>
         [EnumValue("Invoice", typeof(POCommonResx))]  
         Invoice = 5,
     }
}
