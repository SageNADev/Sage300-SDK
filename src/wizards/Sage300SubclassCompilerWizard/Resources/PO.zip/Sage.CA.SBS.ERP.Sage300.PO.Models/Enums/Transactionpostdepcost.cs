// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for Transactionpostdepcost
     /// </summary>
     public enum TransactionPostDepCost
     {
          /// <summary>
          /// Gets or sets QuantityOnly
          /// </summary>
          QuantityOnly = 11,
          /// <summary>
          /// Gets or sets CostOnly
          /// </summary>
          CostOnly = 12,
          /// <summary>
          /// Gets or sets CostAndLedger
          /// </summary>
          CostAndLedger = 13,
     }
}
