// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for DeferredAPPosting
     /// </summary>
     public enum DeferredAPPosting
     {
          /// <summary>
          /// Gets or sets DuringDayEndProcessing
          /// </summary>
         [EnumValue("DuringDayEnd", typeof(Resources.Forms.GLIntegrationResx), 1)] 
         DuringDayEndProcessing = 0,
          /// <summary>
          /// Gets or sets On Request Using Create Batch Icon
          /// </summary>
         [EnumValue("OnRequestUsingIcon", typeof(Resources.Forms.GLIntegrationResx), 2)] 
         OnRequestUsingCreateBatchIcon = 1,
     }
}
