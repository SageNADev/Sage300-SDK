// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for StatisticsCalendar
    /// </summary>
    public enum StatisticsCalendar
    {
        /// <summary>
        /// Gets or sets CalendarYear
        /// </summary>
        [EnumValue("CalendarYear", typeof(ICOptionResx))]
        CalendarYear = 1,
        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [EnumValue("FiscalYear", typeof(ICOptionResx))]
        FiscalYear = 2
    }
}