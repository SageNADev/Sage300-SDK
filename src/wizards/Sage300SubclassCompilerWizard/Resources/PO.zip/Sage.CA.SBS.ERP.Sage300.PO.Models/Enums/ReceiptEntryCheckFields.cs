﻿namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    public enum ReceiptEntryCheckFields
    {
        Vendor = 0,
        PurchaseOrder = 1,
        Template = 2,
        Taxes=3,
        Itemtaxes = 4,
    }
    public enum ReceiptGridRefreshFields
    {
        General = 0,
        JobRelated = 1,
        Receipt = 2,
        Quantities=3,
        Taxes=4,
        DropShip=5,
        Order=6,
        PO=7,
        
    }
}
