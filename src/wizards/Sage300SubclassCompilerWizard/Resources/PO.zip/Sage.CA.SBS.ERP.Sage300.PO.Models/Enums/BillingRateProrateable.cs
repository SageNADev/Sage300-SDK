// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
     /// <summary>
     /// Enum for BillingRateProrateable
     /// </summary>
     public enum BillingRateProrateable
     {
          /// <summary>
          /// Gets or sets No
          /// </summary>
          No = 1,
          /// <summary>
          /// Gets or sets Yes
          /// </summary>
          Yes = 0,
     }
}
