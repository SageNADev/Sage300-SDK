// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Enums
{
    /// <summary>
    /// Enum for PeriodType
    /// </summary>
    public enum PeriodType
    {
        /// <summary>
        /// Gets or sets SevenDays
        /// </summary>
        [EnumValue("SevenDays", typeof(ICOptionResx))]
        SevenDays = 1,
        /// <summary>
        /// Gets or sets Weekly
        /// </summary>
        [EnumValue("Weekly", typeof(ICOptionResx))]
        Weekly = 2,
        /// <summary>
        /// Gets or sets Monthly
        /// </summary>
        [EnumValue("Monthly", typeof(ICOptionResx))]
        Monthly = 3
    }
}