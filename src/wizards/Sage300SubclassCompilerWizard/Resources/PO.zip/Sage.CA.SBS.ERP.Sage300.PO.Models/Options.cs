// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using GLIntegrationResx = Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms.GLIntegrationResx;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Class for P/O Option
    /// </summary>
    public partial class Options : ModelBase
    {
        /// <summary>
        /// constructor for P/O Options
        /// </summary>
        public Options()
        {
            DefaultItemCostList = new List<Dictionary<string, object>>();
            DeferredAPPostingList = new List<Dictionary<string, object>>();
        }

        /// <summary>
        /// Gets or sets KeyField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.KeyField, Id = Index.KeyField, FieldType = EntityFieldType.Int, Size = 2)]
        public int KeyField { get; set; }

        /// <summary>
        /// Gets or sets NextControlSequence
        /// </summary>
        [ViewField(Name = Fields.NextControlSequence, Id = Index.NextControlSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextControlSequence { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber
        /// </summary>
        [StringLength(34, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber
        /// </summary>
        [StringLength(34, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Contact
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets DefaultRateType
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultRateType", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultRateType, Id = Index.DefaultRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string DefaultRateType { get; set; }

        /// <summary>
        /// Gets or sets AllowNonInventoryItems
        /// </summary>
        [Display(Name = "NonInventoryItems", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.AllowNonInventoryItems, Id = Index.AllowNonInventoryItems, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowNonInventoryItems { get; set; }

        /// <summary>
        /// Gets or sets KeepPurchaseHistory
        /// </summary>
        [Display(Name = "AccumulatePH", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.KeepPurchaseHistory, Id = Index.KeepPurchaseHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool KeepPurchaseHistory { get; set; }

        /// <summary>
        /// Gets or sets KeepTransactionHistory
        /// </summary>
        [Display(Name = "TransactionHistory", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.KeepTransactionHistory, Id = Index.KeepTransactionHistory, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool KeepTransactionHistory { get; set; }

        /// <summary>
        /// Gets or sets KeepStatistics
        /// </summary>
        [Display(Name = "AccumulatePS", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.KeepStatistics, Id = Index.KeepStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool KeepStatistics { get; set; }

        /// <summary>
        /// Gets or sets EditStatistics
        /// </summary>
        [Display(Name = "EditStatistics", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.EditStatistics, Id = Index.EditStatistics, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool EditStatistics { get; set; }

        /// <summary>
        /// Gets or sets AccumulateHistoryBy
        /// </summary>
        [Display(Name = "Accumulateby", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.AccumulateHistoryBy, Id = Index.AccumulateHistoryBy, FieldType = EntityFieldType.Int, Size = 2)]
        public AccumulateHistoryBy AccumulateHistoryBy { get; set; }

        /// <summary>
        /// Gets or sets HistoryPeriodsBy
        /// </summary>
        [Display(Name = "PeriodType", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.HistoryPeriodsBy, Id = Index.HistoryPeriodsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public HistoryPeriodsBy HistoryPeriodsBy { get; set; }

        /// <summary>
        /// Gets or sets AccumulateStatisticsBy
        /// </summary>
        [Display(Name = "Accumulateby", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.AccumulateStatisticsBy, Id = Index.AccumulateStatisticsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public AccumulateStatisticsBy AccumulateStatisticsBy { get; set; }

        /// <summary>
        /// Gets or sets StatisticsPeriodsBy
        /// </summary>
        [Display(Name = "PeriodType", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.StatisticsPeriodsBy, Id = Index.StatisticsPeriodsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public StatisticsPeriodsBy StatisticsPeriodsBy { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod1
        /// </summary>
        [Range(typeof(int), "1", "999", ErrorMessageResourceName = "Range",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AgingPeriod1, Id = Index.AgingPeriod1, FieldType = EntityFieldType.Int, Size = 2)]
        public int AgingPeriod1 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod2
        /// </summary>
        [Range(typeof(int), "1", "999", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AgingPeriod2, Id = Index.AgingPeriod2, FieldType = EntityFieldType.Int, Size = 2)]
        public int AgingPeriod2 { get; set; }

        /// <summary>
        /// Gets or sets AgingPeriod3
        /// </summary>
        [Range(typeof(int), "1", "999", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.AgingPeriod3, Id = Index.AgingPeriod3, FieldType = EntityFieldType.Int, Size = 2)]
        public int AgingPeriod3 { get; set; }

        /// <summary>
        /// Gets or sets RequisitionLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RequisitionLength, Id = Index.RequisitionLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int RequisitionLength { get; set; }

        /// <summary>
        /// Gets or sets RequisitionPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RequisitionPrefix, Id = Index.RequisitionPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string RequisitionPrefix { get; set; }

        /// <summary>
        /// Gets or sets RequisitionNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.RequisitionNumber, Id = Index.RequisitionNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string RequisitionNumber { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderLength, Id = Index.PurchaseOrderLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int PurchaseOrderLength { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderPrefix, Id = Index.PurchaseOrderPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string PurchaseOrderPrefix { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%20D")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptLength, Id = Index.ReceiptLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReceiptLength { get; set; }

        /// <summary>
        /// Gets or sets ReceiptPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptPrefix, Id = Index.ReceiptPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReceiptPrefix { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets ReturnLength
        /// </summary>
        [Range(typeof(int), "1", "22", ErrorMessageResourceName = "Range", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReturnLength, Id = Index.ReturnLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReturnLength { get; set; }

        /// <summary>
        /// Gets or sets ReturnPrefix
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReturnPrefix, Id = Index.ReturnPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string ReturnPrefix { get; set; }

        /// <summary>
        /// Gets or sets ReturnNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReturnNumber, Id = Index.ReturnNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%19D")]
        public string ReturnNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultTemplateCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTemplateCode", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultTemplateCode, Id = Index.DefaultTemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultTemplateCode { get; set; }

        /// <summary>
        /// Gets or sets LastGLDayEndSequence
        /// </summary>
        [ViewField(Name = Fields.LastGLDayEndSequence, Id = Index.LastGLDayEndSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LastGLDayEndSequence { get; set; }

        /// <summary>
        /// Gets or sets AppendToExistingGLBatch
        /// </summary>
        [ViewField(Name = Fields.AppendToExistingGLBatch, Id = Index.AppendToExistingGLBatch, FieldType = EntityFieldType.Int, Size = 2)]
        public AppendToExistingGLBatch AppendToExistingGLBatch { get; set; }

        /// <summary>
        /// Gets or sets GLConsolidation
        /// </summary>
        [ViewField(Name = Fields.GLConsolidation, Id = Index.GLConsolidation, FieldType = EntityFieldType.Int, Size = 2)]
        public GLConsolidation GLConsolidation { get; set; }

        /// <summary>
        /// Gets or sets GenerateGLBatchesOnDemand
        /// </summary>
        [ViewField(Name = Fields.GenerateGLBatchesOnDemand, Id = Index.GenerateGLBatchesOnDemand, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GenerateGLBatchesOnDemand { get; set; }

        /// <summary>
        /// Gets or sets ContentsOfGLReference
        /// </summary>
        [ViewField(Name = Fields.ContentsOfGLReference, Id = Index.ContentsOfGLReference, FieldType = EntityFieldType.Int, Size = 2)]
        public ContentsOfGLReference ContentsOfGLReference { get; set; }

        /// <summary>
        /// Gets or sets ContentsOfGLDescription
        /// </summary>
        [ViewField(Name = Fields.ContentsOfGLDescription, Id = Index.ContentsOfGLDescription, FieldType = EntityFieldType.Int, Size = 2)]
        public ContentsOfGLDescription ContentsOfGLDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultInventoryExpenseAccoun
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultInventoryExpAcct", ResourceType = typeof(GLIntegrationResx))]
        //[ViewField(Name = Fields.DefaultInventoryExpenseAccount, Id = Index.DefaultInventoryExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DefaultInventoryExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets DefaultCostExpenseAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultCostExpAcct", ResourceType = typeof(GLIntegrationResx))]
        [ViewField(Name = Fields.DefaultCostExpenseAccount, Id = Index.DefaultCostExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DefaultCostExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets DefaultCost
        /// </summary>
        [Display(Name = "DefaultItemCost", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultCost, Id = Index.DefaultCost, FieldType = EntityFieldType.Int, Size = 2)]
        public int DefaultCost { get; set; }

        /// <summary>
        /// Gets or sets NonInventoryPayableClearingA
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NonInvPaybClrAcct", ResourceType = typeof(GLIntegrationResx))]
        //[ViewField(Name = Fields.NonInventoryPayableClearingAccount, Id = Index.NonInventoryPayableClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string NonInventoryPayableClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets PostToNonInvPbClrAcct
        /// </summary>
        [Display(Name = "CrtGLEntForNonInvExpFromRCPRET", ResourceType = typeof(GLIntegrationResx))]
        [ViewField(Name = Fields.PostToNonInvPbClrAcct, Id = Index.PostToNonInvPbClrAcct, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostToNonInvPbClrAcct { get; set; }

        /// <summary>
        /// Gets or sets ExpAdditionalCostPayableCle
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpensedAddCostPayableClearingAcct", ResourceType = typeof(GLIntegrationResx))]
        //[ViewField(Name = Fields.ExpAdditionalCostPayableClearingAccount, Id = Index.ExpAdditionalCostPayableClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExpAdditionalCostPayableClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets PostToExpAddlCostPbClr
        /// </summary>
        [Display(Name = "CrtGLEntryForExpAddCostsRCPRET", ResourceType = typeof(GLIntegrationResx))]
        [ViewField(Name = Fields.PostToExpAddlCostPbClr, Id = Index.PostToExpAddlCostPbClr, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool PostToExpAddlCostPbClr { get; set; }

        /// <summary>
        /// Gets or sets DeferredAPPosting
        /// </summary>
        [Display(Name = "PostAPBatches", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DeferredAPPosting, Id = Index.DeferredAPPosting, FieldType = EntityFieldType.Int, Size = 2)]
        public int DeferredAPPosting { get; set; }
        
        /// <summary>
        /// Gets or sets POAdjustments
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POAdjustments, Id = Index.POAdjustments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POAdjustments { get; set; }

        /// <summary>
        /// Gets or sets POConsolidation
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POConsolidation, Id = Index.POConsolidation, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POConsolidation { get; set; }

        /// <summary>
        /// Gets or sets POCreditNotes
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POCreditNotes, Id = Index.POCreditNotes, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets PODebitNotes
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PODebitNotes, Id = Index.PODebitNotes, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string PODebitNotes { get; set; }

        /// <summary>
        /// Gets or sets POInvoices
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POInvoices, Id = Index.POInvoices, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POInvoices { get; set; }

        /// <summary>
        /// Gets or sets POReceiptAdjustments
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POReceiptAdjustments, Id = Index.POReceiptAdjustments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POReceiptAdjustments { get; set; }

        /// <summary>
        /// Gets or sets POReceipts
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POReceipts, Id = Index.POReceipts, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POReceipts { get; set; }

        /// <summary>
        /// Gets or sets POReturnAdjustments
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POReturnAdjustments, Id = Index.POReturnAdjustments, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POReturnAdjustments { get; set; }

        /// <summary>
        /// Gets or sets POReturns
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POReturns, Id = Index.POReturns, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string POReturns { get; set; }

        /// <summary>
        /// Gets or sets AllowNonExistingVendors
        /// </summary>
        [Display(Name = "AllowNonExistingVendor", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.AllowNonExistingVendors, Id = Index.AllowNonExistingVendors, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowNonExistingVendors { get; set; }

        /// <summary>
        /// Gets or sets WarnifNonExistingItem
        /// </summary>
        [Display(Name = "NonInventoryItemWarn", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.WarnifNonExistingItem, Id = Index.WarnifNonExistingItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool WarnifNonExistingItem { get; set; }

        /// <summary>
        /// Gets or sets DefaultPostingDate
        /// </summary>
        [Display(Name = "DefaultPostingDate", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultPostingDate, Id = Index.DefaultPostingDate, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultPostingDate DefaultPostingDate { get; set; }

        /// <summary>
        /// Gets or sets RecentLastCostPostingAt
        /// </summary>
        [Display(Name = "UpdateRecentCostAndLastCost", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.RecentLastCostPostingAt, Id = Index.RecentLastCostPostingAt, FieldType = EntityFieldType.Int, Size = 2)]
        public RecentLastCostPostingAt RecentLastCostPostingAt { get; set; }

        /// <summary>
        /// Gets or sets DefaultCopyCostToPurchaseOr
        /// </summary>
        [Display(Name = "CopyCostsToPurchaseOrder", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.DefaultCopyCostToPurchaseOr, Id = Index.DefaultCopyCostToPurchaseOr, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DefaultCopyCostToPurchaseOr { get; set; }

        /// <summary>
        /// Gets or sets RequisitionManualApproval
        /// </summary>
        [Display(Name = "RQNManualApproval", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.RequisitionManualApproval, Id = Index.RequisitionManualApproval, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool RequisitionManualApproval { get; set; }

        /// <summary>
        /// Gets or sets AllowReceiptsInNegativeInven
        /// </summary>
        [ViewField(Name = Fields.AllowReceiptsInNegativeInven, Id = Index.AllowReceiptsInNegativeInven, FieldType = EntityFieldType.Int, Size = 2)]
        public AllowedType AllowReceiptsInNegativeInven { get; set; }

        /// <summary>
        /// Gets or sets DefaultRequisition
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultRequisition, Id = Index.DefaultRequisition, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultRequisition { get; set; }

        /// <summary>
        /// Gets or sets NextRequisition
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NextRequisition, Id = Index.NextRequisition, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextRequisition { get; set; }

        /// <summary>
        /// Gets or sets DefaultPurchaseOrder
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultPurchaseOrder, Id = Index.DefaultPurchaseOrder, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultPurchaseOrder { get; set; }

        /// <summary>
        /// Gets or sets NextPurchaseOrder
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NextPurchaseOrder, Id = Index.NextPurchaseOrder, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextPurchaseOrder { get; set; }

        /// <summary>
        /// Gets or sets DefaultReceipt
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultReceipt, Id = Index.DefaultReceipt, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReceipt { get; set; }

        /// <summary>
        /// Gets or sets NextReceipt
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NextReceipt, Id = Index.NextReceipt, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextReceipt { get; set; }

        /// <summary>
        /// Gets or sets DefaultReturn
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DefaultReturn, Id = Index.DefaultReturn, FieldType = EntityFieldType.Char, Size = 22)]
        public string DefaultReturn { get; set; }

        /// <summary>
        /// Gets or sets NextReturn
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NextReturn, Id = Index.NextReturn, FieldType = EntityFieldType.Char, Size = 22)]
        public string NextReturn { get; set; }

        /// <summary>
        /// Gets or sets HistoricalPeriodType
        /// </summary>
        [ViewField(Name = Fields.HistoricalPeriodType, Id = Index.HistoricalPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public int HistoricalPeriodType { get; set; }

        /// <summary>
        /// Gets or sets HistoricalPeriodLength
        /// </summary>
        [ViewField(Name = Fields.HistoricalPeriodLength, Id = Index.HistoricalPeriodLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int HistoricalPeriodLength { get; set; }

        /// <summary>
        /// Gets or sets HistoricalPeriods
        /// </summary>
        [ViewField(Name = Fields.HistoricalPeriods, Id = Index.HistoricalPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public int HistoricalPeriods { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriodType
        /// </summary>
        [ViewField(Name = Fields.StatisticalPeriodType, Id = Index.StatisticalPeriodType, FieldType = EntityFieldType.Int, Size = 2)]
        public int StatisticalPeriodType { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriodLength
        /// </summary>
        [ViewField(Name = Fields.StatisticalPeriodLength, Id = Index.StatisticalPeriodLength, FieldType = EntityFieldType.Int, Size = 2)]
        public int StatisticalPeriodLength { get; set; }

        /// <summary>
        /// Gets or sets StatisticalPeriods
        /// </summary>
        [ViewField(Name = Fields.StatisticalPeriods, Id = Index.StatisticalPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public int StatisticalPeriods { get; set; }

        /// <summary>
        /// Gets or sets DocumentFormatsSet
        /// </summary>
        [ViewField(Name = Fields.DocumentFormatsSet, Id = Index.DocumentFormatsSet, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool DocumentFormatsSet { get; set; }

        /// <summary>
        /// Gets or sets NextDayEndSequence
        /// </summary>
        [Display(Name = "NextDayEndNumber", ResourceType = typeof(OptionsResx))]
        [ViewField(Name = Fields.NextDayEndSequence, Id = Index.NextDayEndSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextDayEndSequence { get; set; }
        
        /// <summary>
        /// Gets or sets CostExpenseAcctDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CostExpenseAcctDesc, Id = Index.CostExpenseAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string CostExpenseAcctDesc { get; set; }

        /// <summary>
        /// Gets or sets InventoryExpenseAcctDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.InventoryExpenseAcctDesc, Id = Index.InventoryExpenseAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string InventoryExpenseAcctDesc { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets FractionalQuantities
        /// </summary>
        [ViewField(Name = Fields.FractionalQuantities, Id = Index.FractionalQuantities, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool FractionalQuantities { get; set; }

        /// <summary>
        /// Gets or sets HomeCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.HomeCurrency, Id = Index.HomeCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string HomeCurrency { get; set; }

        /// <summary>
        /// Gets or sets DatabaseDriverID
        /// </summary>
        [ViewField(Name = Fields.DatabaseDriverID, Id = Index.DatabaseDriverID, FieldType = EntityFieldType.Int, Size = 2)]
        public int DatabaseDriverID { get; set; }

        /// <summary>
        /// Gets or sets CostDuring
        /// </summary>
        [ViewField(Name = Fields.CostDuring, Id = Index.CostDuring, FieldType = EntityFieldType.Int, Size = 2)]
        public CostDuring CostDuring { get; set; }

        /// <summary>
        /// Gets or sets NonInvPblsClrAcctDesc
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.NonInvPblsClrAcctDesc, Id = Index.NonInvPblsClrAcctDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string NonInvPblsClrAcctDesc { get; set; }

        /// <summary>
        /// Gets or sets ExpAddlCostPblsClrAcct
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExpAddlCostPblsClrAcct, Id = Index.ExpAddlCostPblsClrAcct, FieldType = EntityFieldType.Char, Size = 60)]
        public string ExpAddlCostPblsClrAcct { get; set; }

        /// <summary>
        /// Gets or sets Action
        /// </summary>
        [ViewField(Name = Fields.Action, Id = Index.Action, FieldType = EntityFieldType.Int, Size = 2)]
        public int Action { get; set; }

        /// <summary>
        /// Gets or sets CreateSubledgerAuditDuring
        /// </summary>
        [ViewField(Name = Fields.CreateSubledgerAuditDuring, Id = Index.CreateSubledgerAuditDuring, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateSubledgerAuditDuring CreateSubledgerAuditDuring { get; set; }

        /// <summary>
        /// Gets or sets Transactionpostdepcost
        /// </summary>
        [ViewField(Name = Fields.Transactionpostdepcost, Id = Index.Transactionpostdepcost, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionPostDepCost Transactionpostdepcost { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Get or Set Item Cost List
        /// </summary>
        /// <remarks>Default Item Cost's Presentation List</remarks>
        public List<Dictionary<string, object>> DefaultItemCostList { get; set; }

        /// <summary>
        /// Get or Set Deferred A/P Posting List
        /// </summary>
        public List<Dictionary<string, object>> DeferredAPPostingList { get; set; }
    }
}
