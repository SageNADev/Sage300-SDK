// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for Return Line Serial
     /// </summary>
     public partial class ReturnLineSerial : ModelBase
     {
          /// <summary>
          /// Gets or sets ReturnSequenceKey
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal ReturnSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal LineNumber {get; set;}

          /// <summary>
          /// Gets or sets SerialNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string SerialNumber {get; set;}

          /// <summary>
          /// Gets or sets ReturnLineSequence
          /// </summary>
          [ViewField(Name = Fields.ReturnLineSequence, Id = Index.ReturnLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal ReturnLineSequence {get; set;}

          /// <summary>
          /// Gets or sets Returned
          /// </summary>
          [ViewField(Name = Fields.Returned, Id = Index.Returned, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool Returned {get; set;}

          /// <summary>
          /// Gets or sets SerialCount
          /// </summary>
          [ViewField(Name = Fields.SerialCount, Id = Index.SerialCount, FieldType = EntityFieldType.Long, Size = 4)]
          public long SerialCount {get; set;}
     }
}
