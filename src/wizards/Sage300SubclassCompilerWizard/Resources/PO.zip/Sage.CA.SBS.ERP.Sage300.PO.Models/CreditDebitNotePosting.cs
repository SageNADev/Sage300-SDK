// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Partial class for CreditDebitNotePosting
	/// </summary>
	public partial class CreditDebitNotePosting : ModelBase
	{
		/// <summary>
		/// Gets or sets HeaderSequence
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.HeaderSequence, Id = Index.HeaderSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal HeaderSequence {get; set;}

		/// <summary>
		/// Gets or sets OperationToPost
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.OperationToPost, Id = Index.OperationToPost, FieldType = EntityFieldType.Int, Size = 2)]
		public int OperationToPost {get; set;}

		/// <summary>
		/// Gets or sets LastPostingDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime LastPostingDate {get; set;}

		/// <summary>
		/// Gets or sets Completed
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
		public Completed Completed {get; set;}

		/// <summary>
		/// Gets or sets DateCompleted
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateCompleted {get; set;}

		/// <summary>
		/// Gets or sets CreditDebitNoteSequenceKey
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal CreditDebitNoteSequenceKey {get; set;}

		/// <summary>
		/// Gets or sets TransactionType
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
		public int TransactionType {get; set;}

		/// <summary>
		/// Gets or sets FromDocument
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.FromDocument, Id = Index.FromDocument, FieldType = EntityFieldType.Int, Size = 2)]
		public int FromDocument {get; set;}

		/// <summary>
		/// Gets or sets InvoiceSequenceKey
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.InvoiceSequenceKey, Id = Index.InvoiceSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal InvoiceSequenceKey {get; set;}

		/// <summary>
		/// Gets or sets ReceiptSequenceKey
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ReceiptSequenceKey {get; set;}

		/// <summary>
		/// Gets or sets ReturnSequenceKey
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal ReturnSequenceKey {get; set;}

		/// <summary>
		/// Gets or sets TaxClass1
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
		public int TaxClass1 {get; set;}

		/// <summary>
		/// Gets or sets TaxClass2
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
		public int TaxClass2 {get; set;}

		/// <summary>
		/// Gets or sets TaxClass3
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
		public int TaxClass3 {get; set;}

		/// <summary>
		/// Gets or sets TaxClass4
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
		public int TaxClass4 {get; set;}

		/// <summary>
		/// Gets or sets TaxClass5
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
		public int TaxClass5 {get; set;}

		/// <summary>
		/// Gets or sets ConversionSourceAmount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ConversionSourceAmount, Id = Index.ConversionSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ConversionSourceAmount {get; set;}

		/// <summary>
		/// Gets or sets ConversionFunctionalAmount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.ConversionFunctionalAmount, Id = Index.ConversionFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ConversionFunctionalAmount {get; set;}

		/// <summary>
		/// Gets or sets SourceDocumentTotal
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.SourceDocumentTotal, Id = Index.SourceDocumentTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal SourceDocumentTotal {get; set;}

		/// <summary>
		/// Gets or sets HasRetainage
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.HasRetainage, Id = Index.HasRetainage, FieldType = EntityFieldType.Bool, Size = 2)]
		public HasRetainage HasRetainage {get; set;}

		/// <summary>
		/// Gets or sets RetainageExchangeRate
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RetainageExchangeRate, Id = Index.RetainageExchangeRate, FieldType = EntityFieldType.Int, Size = 2)]
		public int RetainageExchangeRate {get; set;}

		/// <summary>
		/// Gets or sets RetainageAmount
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: OR remove 'Display' attribute if not required on property
		// TODO: Delete TODO statements when complete
		[Display(Name = "Generated", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal RetainageAmount {get; set;}

		#region UI Strings

		/// <summary>
		/// Gets Completed string value
		/// </summary>
		public string CompletedString
		{
			get { return EnumUtility.GetStringValue(Completed); }
		}

		/// <summary>
		/// Gets HasRetainage string value
		/// </summary>
		public string HasRetainageString
		{
			get { return EnumUtility.GetStringValue(HasRetainage); }
		}

		#endregion
	}
}
