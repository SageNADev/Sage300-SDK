// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for ReceiptFunction
    /// </summary>
    public partial class ReceiptFunction : ModelBase
    {
        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets SequenceToRetrieve
        /// </summary>
        [ViewField(Name = Fields.SequenceToRetrieve, Id = Index.SequenceToRetrieve, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal SequenceToRetrieve { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets TemplateCode
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TemplateCode, Id = Index.TemplateCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string TemplateCode { get; set; }

        /// <summary>
        /// Gets or sets PredecessorTimestamp
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PredecessorTimestamp, Id = Index.PredecessorTimestamp, FieldType = EntityFieldType.Char, Size = 24)]
        public string PredecessorTimestamp { get; set; }

        /// <summary>
        /// Gets or sets Function
        /// </summary>
        [ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
        public int Function { get; set; }

        /// <summary>
        /// Gets or sets DistributionReferencesExist
        /// </summary>
        [ViewField(Name = Fields.DistributionReferencesExist, Id = Index.DistributionReferencesExist, FieldType = EntityFieldType.Bool, Size = 2)]
        public DistributionReferencesExist DistributionReferencesExist { get; set; }

        /// <summary>
        /// Gets or sets AmountDistributionRefsExist
        /// </summary>
        [ViewField(Name = Fields.AmountDistributionRefsExist, Id = Index.AmountDistributionRefsExist, FieldType = EntityFieldType.Bool, Size = 2)]
        public AmountDistributionRefsExist AmountDistributionRefsExist { get; set; }

        /// <summary>
        /// Gets or sets BillingRateDistrRefsExist
        /// </summary>
        [ViewField(Name = Fields.BillingRateDistrRefsExist, Id = Index.BillingRateDistrRefsExist, FieldType = EntityFieldType.Bool, Size = 2)]
        public BillingRateDistrRefsExist BillingRateDistrRefsExist { get; set; }

        /// <summary>
        /// Gets or sets AmountProrateable
        /// </summary>
        [ViewField(Name = Fields.AmountProrateable, Id = Index.AmountProrateable, FieldType = EntityFieldType.Bool, Size = 2)]
        public AmountProrateable AmountProrateable { get; set; }

        /// <summary>
        /// Gets or sets BillingRateProrateable
        /// </summary>
        [ViewField(Name = Fields.BillingRateProrateable, Id = Index.BillingRateProrateable, FieldType = EntityFieldType.Bool, Size = 2)]
        public BillingRateProrateable BillingRateProrateable { get; set; }

        /// <summary>
        /// Gets or sets LineNodeFound
        /// </summary>
        [ViewField(Name = Fields.LineNodeFound, Id = Index.LineNodeFound, FieldType = EntityFieldType.Bool, Size = 2)]
        public LineNodeFound LineNodeFound { get; set; }

    }
}
