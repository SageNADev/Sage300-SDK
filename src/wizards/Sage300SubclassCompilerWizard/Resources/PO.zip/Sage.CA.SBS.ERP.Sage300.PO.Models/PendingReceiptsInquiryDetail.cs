// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for PendingReceiptDetail
    /// </summary>
    public partial class PendingReceiptsInquiryDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderLineSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PurchaseOrderLineSequence, Id = Index.PurchaseOrderLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderLineSequence { get; set; }

        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets ReceiptLineSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptLineSequence, Id = Index.ReceiptLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptLineSequence { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16)]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16)]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets CosCategory
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16)]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets QuantityOrdered
        /// </summary>
        [Display(Name = "QuantityOrdered", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

        /// <summary>
        /// Gets or sets POUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderUnitOfMeasure", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.POUnitOfMeasure, Id = Index.POUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string POUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets HasJob
        /// </summary>
        [ViewField(Name = Fields.HasJob, Id = Index.HasJob, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool HasJob { get; set; }

        /// <summary>
        /// Gets or sets ExpectedArrivalDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedArrivalDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExpectedArrivalDate, Id = Index.ExpectedArrivalDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpectedArrivalDate { get; set; }

        /// <summary>
        /// Gets or sets DateReceived
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateReceived", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.DateReceived, Id = Index.DateReceived, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateReceived { get; set; }

        /// <summary>
        /// Gets or sets DaysLate
        /// </summary>
        [Display(Name = "DaysLate", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.DaysLate, Id = Index.DaysLate, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysLate { get; set; }

        /// <summary>
        /// Gets or sets QuantityReceived
        /// </summary>
        [Display(Name = "QuantityReceived", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityReceived, Id = Index.QuantityReceived, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityReceived { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6)]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets IsComplete
        /// </summary>
        [Display(Name = "Generated", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.IsComplete, Id = Index.IsComplete, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsComplete IsComplete { get; set; }

        /// <summary>
        /// Gets or sets ReceiptUnits
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptUnitOfMeasure", ResourceType = typeof(PendingReceiptsInquiryResx))]
        [ViewField(Name = Fields.ReceiptUnits, Id = Index.ReceiptUnits, FieldType = EntityFieldType.Char, Size = 10)]
        public string ReceiptUnits { get; set; }

        #region UI Strings

        /// <summary>
        /// Gets IsComplete string value
        /// </summary>
        public string IsCompleteString
        {
            get { return EnumUtility.GetStringValue(IsComplete); }
        }

        #endregion
    }
}
