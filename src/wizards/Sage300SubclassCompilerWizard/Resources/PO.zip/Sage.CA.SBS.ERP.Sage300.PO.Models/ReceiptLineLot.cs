// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for ReceiptLineLot
    /// </summary>
    public partial class ReceiptLineLot : ModelBase
    {
        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets LotNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LotNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string LotNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptLineSequence
        /// </summary>
        [Display(Name = "ReceiptLineSequence", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptLineSequence, Id = Index.ReceiptLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptLineSequence { get; set; }

        /// <summary>
        /// Gets or sets ExpiryDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpiryDate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExpiryDate { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotStockQuantity
        /// </summary>
        [Display(Name = "LotStockQuantity", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.LotStockQuantity, Id = Index.LotStockQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotStockQuantity { get; set; }
    }
}
