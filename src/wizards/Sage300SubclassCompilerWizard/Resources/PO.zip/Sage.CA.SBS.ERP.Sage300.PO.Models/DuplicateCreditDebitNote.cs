// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Partial class for DuplicateCreditDebitNote
	/// </summary>
	public partial class DuplicateCreditDebitNote : ModelBase
	{
		/// <summary>
		/// Gets or sets CreditDebitNoteSequenceKey
		/// </summary>
		[Key]
		[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "CreditDebitNoteSequenceKey", ResourceType = typeof (CreditDebitNoteEntryResx))]
		[ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal CreditDebitNoteSequenceKey { get; set; }

		/// <summary>
		/// Gets or sets CreditDebitNoteNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
		[ViewField(Name = Fields.CreditDebitNoteNumber, Id = Index.CreditDebitNoteNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string CreditDebitNoteNumber { get; set; }

		/// <summary>
		/// Gets or sets RequireNewEntry
		/// </summary>
	    [Display(Name = "RequireNewEntry", ResourceType = typeof (CreditDebitNoteEntryResx))]
		[ViewField(Name = Fields.RequireNewEntry, Id = Index.RequireNewEntry, FieldType = EntityFieldType.Bool, Size = 2)]
		public RequireNewEntry RequireNewEntry { get; set; }

		/// <summary>
		/// Gets or sets Vendor
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
	    [Display(Name = "Vendor", ResourceType = typeof (POCommonResx))]
		[ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string Vendor { get; set; }

		/// <summary>
		/// Gets or sets Date
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "Date", ResourceType = typeof (CommonResx))]
		[ViewField(Name = Fields.Date, Id = Index.Date, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime Date { get; set; }

		/// <summary>
		/// Gets or sets Total
		/// </summary>
		[Display(Name = "Total", ResourceType = typeof (POCommonResx))]
		[ViewField(Name = Fields.Total, Id = Index.Total, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal Total { get; set; }

		/// <summary>
		/// Gets or sets NumberOfDuplicates
		/// </summary>
        [Display(Name = "NumberOfDuplicates", ResourceType = typeof(CreditDebitNoteEntryResx))]
		[ViewField(Name = Fields.NumberOfDuplicates, Id = Index.NumberOfDuplicates, FieldType = EntityFieldType.Int, Size = 2)]
		public int NumberOfDuplicates { get; set; }

		/// <summary>
		/// Gets or sets Function
		/// </summary>
        [Display(Name = "Function", ResourceType = typeof(CreditDebitNoteEntryResx))]
		[ViewField(Name = Fields.Function, Id = Index.Function, FieldType = EntityFieldType.Int, Size = 2)]
		public int Function { get; set; }

		#region UI Strings

		/// <summary>
		/// Gets RequireNewEntry string value
		/// </summary>
		public string RequireNewEntryString
		{
			get { return EnumUtility.GetStringValue(RequireNewEntry); }
		}

		#endregion
	}
}
