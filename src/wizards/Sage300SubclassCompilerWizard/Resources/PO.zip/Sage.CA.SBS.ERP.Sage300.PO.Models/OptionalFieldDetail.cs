/* Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for PO OptionalField
    /// </summary>
    public partial class OptionalFieldDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Int, Size = 2)]
        public Location Location { get; set; }

        /// <summary>
        /// Gets or sets OptionalField
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets DefaultValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultValue, Id = Index.DefaultValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultValue { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        [Display(Name = "Type", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.Type Type { get; set; }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        [Display(Name = "Length", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank AllowBlank { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public Validate Validate { get; set; }

        /// <summary>
        /// Gets or sets AutoInsert
        /// </summary>
        [Display(Name = "AutoInsert", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.AutoInsert, Id = Index.AutoInsert, FieldType = EntityFieldType.Int, Size = 2)]
        public Required AutoInsert { get; set; }

        /// <summary>
        /// Gets or sets ExternalCostTransactions
        /// </summary>
        [Display(Name = "ExternalCostTransactions", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.ExternalCostTransactions, Id = Index.ExternalCostTransactions, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting ExternalCostTransactions { get; set; }

        /// <summary>
        /// Gets or sets PayablesClearing
        /// </summary>
        [Display(Name = "PayablesClearing", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.PayablesClearing, Id = Index.PayablesClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting PayablesClearing { get; set; }

        /// <summary>
        /// Gets or sets PayablesClearing1
        /// </summary>
        [Display(Name = "PayablesClearing", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.PayablesClearing1, Id = Index.PayablesClearing1, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting PayablesClearing1 { get; set; }

        /// <summary>
        /// Gets or sets InventoryControl
        /// </summary>
        [Display(Name = "InventoryControl", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.InventoryControl, Id = Index.InventoryControl, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting InventoryControl { get; set; }

        /// <summary>
        /// Gets or sets NonStockClearing
        /// </summary>
        [Display(Name = "NonStockClearing", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.NonStockClearing, Id = Index.NonStockClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting NonStockClearing { get; set; }

        /// <summary>
        /// Gets or sets NonInventoryPayablesClearing
        /// </summary>
        [Display(Name = "NonInventoryPayablesClearing", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.NonInventoryPayablesClearing, Id = Index.NonInventoryPayablesClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting NonInventoryPayablesClearing { get; set; }

        /// <summary>
        /// Gets or sets NonInventoryPayablesClearing1
        /// </summary>
        [Display(Name = "NonInventoryPayablesClearing", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.NonInventoryPayablesClearing1, Id = Index.NonInventoryPayablesClearing1, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting NonInventoryPayablesClearing1 { get; set; }

        /// <summary>
        /// Gets or sets NonInventoryExpense
        /// </summary>
        [Display(Name = "NonInventoryExpense", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.NonInventoryExpense, Id = Index.NonInventoryExpense, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting NonInventoryExpense { get; set; }

        /// <summary>
        /// Gets or sets NonInventoryExpense1
        /// </summary>
        [Display(Name = "NonInventoryExpense", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.NonInventoryExpense1, Id = Index.NonInventoryExpense1, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting NonInventoryExpense1 { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostExpense
        /// </summary>
        [Display(Name = "AdditionalCostExpense", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.AdditionalCostExpense, Id = Index.AdditionalCostExpense, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting AdditionalCostExpense { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostExpense1
        /// </summary>
        [Display(Name = "AdditionalCostExpense", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.AdditionalCostExpense1, Id = Index.AdditionalCostExpense1, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting AdditionalCostExpense1 { get; set; }

        /// <summary>
        /// Gets or sets InvoicesOptionalFields
        /// </summary>
        [Display(Name = "InvoicesOptionalFields", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.InvoicesOptionalFields, Id = Index.InvoicesOptionalFields, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting InvoicesOptionalFields { get; set; }

        /// <summary>
        /// Gets or sets Labor
        /// </summary>
        [Display(Name = "Labor", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.Labor, Id = Index.Labor, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting Labor { get; set; }

        /// <summary>
        /// Gets or sets Overhead
        /// </summary>
        [Display(Name = "Overhead", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.Overhead, Id = Index.Overhead, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting Overhead { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostExpensePayablesClearing
        /// </summary>
        [Display(Name = "AdditionalCostExpensePayablesClearing", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.AdditionalCostExpensePayablesClearing, Id = Index.AdditionalCostExpensePayablesClearing, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting AdditionalCostExpensePayablesClearing { get; set; }

        /// <summary>
        /// Gets or sets AdditionalCostExpensePayablesClearing1
        /// </summary>
        [Display(Name = "AdditionalCostExpensePayablesClearing", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.AdditionalCostExpensePayablesClearing1, Id = Index.AdditionalCostExpensePayablesClearing1, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSetting AdditionalCostExpensePayablesClearing1 { get; set; }

        /// <summary>
        /// Gets or sets Required
        /// </summary>
        [Display(Name = "Required", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.Required, Id = Index.Required, FieldType = EntityFieldType.Int, Size = 2)]
        public Required Required { get; set; }

        /// <summary>
        /// Gets or sets ValueSet
        /// </summary>
        [Display(Name = "ValueSet", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.ValueSet, Id = Index.ValueSet, FieldType = EntityFieldType.Int, Size = 2)]
        public ValueSet ValueSet { get; set; }

        /// <summary>
        /// Gets or sets TypedDefaultValueFieldIndex
        /// </summary>
        [Display(Name = "TypedDefaultValueFieldIndex", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.TypedDefaultValueFieldIndex, Id = Index.TypedDefaultValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypedDefaultValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets DefaultTextValue
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultTextValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultTextValue, Id = Index.DefaultTextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string DefaultTextValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultMoneyValue
        /// </summary>
        [Display(Name = "DefaultMoneyValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultAmountValue, Id = Index.DefaultAmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DefaultAmountValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultNumberValue
        /// </summary>
        [Display(Name = "DefaultNumberValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultNumberValue, Id = Index.DefaultNumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DefaultNumberValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultIntegerValue
        /// </summary>
        [Display(Name = "DefaultIntegerValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultIntegerValue, Id = Index.DefaultIntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long DefaultIntegerValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultYesNoValue
        /// </summary>
        [Display(Name = "DefaultYesNoValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultYesNoValue, Id = Index.DefaultYesNoValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public AllowBlank DefaultYesNoValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultDateValue
        /// </summary>
        [Display(Name = "DefaultDateValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultDateValue, Id = Index.DefaultDateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DefaultDateValue { get; set; }

        /// <summary>
        /// Gets or sets DefaultTimeValue
        /// </summary>
        [Display(Name = "DefaultTimeValue", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultTimeValue, Id = Index.DefaultTimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime DefaultTimeValue { get; set; }

        /// <summary>
        /// Gets or sets OptionalFieldDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalFieldDescription", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.OptionalFieldDescription, Id = Index.OptionalFieldDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string OptionalFieldDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultValueDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DefaultValueDescription", ResourceType = typeof(OptionalFieldResx))]
        [ViewField(Name = Fields.DefaultValueDescription, Id = Index.DefaultValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultValueDescription { get; set; }

        /// <summary>
        /// Gets or Sets Multi Currency
        /// </summary>
        [IgnoreExportImport]
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Serial Number
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFieldsValue DefaultOptionField { get; set; }

        /// <summary>
        /// Gets or sets Default OptionField
        /// </summary>
        [IgnoreExportImport]
        public OptionalFields DefaultOptionFieldValue { get; set; }

        public bool IsExternalCostTransactions
        {
            get
            {
                return ExternalCostTransactions == TransactionSetting.Yes;
            }
            set
            {

                ExternalCostTransactions = value ? TransactionSetting.Yes : TransactionSetting.No;
            }
        }

        /// <summary>
        /// Gets or sets IsPayablesClearing.
        /// </summary>
        public bool IsPayablesClearing
        {
            get
            {
                return PayablesClearing == TransactionSetting.Yes;
            }
            set
            {
                PayablesClearing = value ? TransactionSetting.Yes : TransactionSetting.No;
            }
        }

        /// <summary>
        /// Gets or sets IsPayablesClearing1
        /// </summary>
        public bool IsPayablesClearing1
        {
            get
            {
                return PayablesClearing1 == TransactionSetting.Yes;
            }
            set
            {
                PayablesClearing1 = value ? TransactionSetting.Yes : TransactionSetting.No;
            }
        }

        /// <summary>
        /// Gets or sets IsInventoryControl
        /// </summary>
        public bool IsInventoryControl
        {
            get
            {
                return InventoryControl == TransactionSetting.Yes;
            }
            set
            {

                InventoryControl = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsNonStockClearing
        /// </summary>
        public bool IsNonStockClearing
        {
            get
            {
                return NonStockClearing == TransactionSetting.Yes;
            }
            set
            {

                NonStockClearing = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsNonInventoryPayablesClearing
        /// </summary>
        public bool IsNonInventoryPayablesClearing
        {
            get
            {
                return NonInventoryPayablesClearing == TransactionSetting.Yes;
            }
            set
            {

                NonInventoryPayablesClearing = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsNonInventoryPayablesClearing1
        /// </summary>
        public bool IsNonInventoryPayablesClearing1
        {
            get
            {
                return NonInventoryPayablesClearing1 == TransactionSetting.Yes;
            }
            set
            {

                NonInventoryPayablesClearing1 = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsNonInventoryExpense
        /// </summary>
        public bool IsNonInventoryExpense
        {
            get
            {
                return NonInventoryExpense == TransactionSetting.Yes;
            }
            set
            {

                NonInventoryExpense = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsNonInventoryExpense1
        /// </summary>
        public bool IsNonInventoryExpense1
        {
            get
            {
                return NonInventoryExpense1 == TransactionSetting.Yes;
            }
            set
            {

                NonInventoryExpense1 = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsAdditionalCostExpense
        /// </summary>
        public bool IsAdditionalCostExpense
        {
            get
            {
                return AdditionalCostExpense == TransactionSetting.Yes;
            }
            set
            {

                AdditionalCostExpense = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsAdditionalCostExpense1
        /// </summary>
        public bool IsAdditionalCostExpense1
        {
            get
            {
                return AdditionalCostExpense1 == TransactionSetting.Yes;
            }
            set
            {

                AdditionalCostExpense1 = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsInvoicesOptionalFields
        /// </summary>
        public bool IsInvoicesOptionalFields
        {
            get
            {
                return InvoicesOptionalFields == TransactionSetting.Yes;
            }
            set
            {

                InvoicesOptionalFields = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsLabor
        /// </summary>
        public bool IsLabor
        {
            get
            {
                return Labor == TransactionSetting.Yes;
            }
            set
            {

                Labor = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsOverhead
        /// </summary>
        public bool IsOverhead
        {
            get
            {
                return Overhead == TransactionSetting.Yes;
            }
            set
            {

                Overhead = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsAdditionalCostExpensePayablesClearing
        /// </summary>
        public bool IsAdditionalCostExpensePayablesClearing
        {
            get
            {
                return AdditionalCostExpensePayablesClearing == TransactionSetting.Yes;
            }
            set
            {

                AdditionalCostExpensePayablesClearing = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }

        /// <summary>
        /// Gets or sets IsAdditionalCostExpensePayablesClearing1
        /// </summary>
        public bool IsAdditionalCostExpensePayablesClearing1
        {
            get
            {
                return AdditionalCostExpensePayablesClearing1 == TransactionSetting.Yes;
            }
            set
            {

                AdditionalCostExpensePayablesClearing1 = value ? TransactionSetting.Yes : TransactionSetting.No;

            }
        }


        /// <summary>
        /// Checks G/L integration Settings
        /// </summary>
        public bool IsGLNonInventoryExpenseEnabled { get; set; }
        /// <summary>
        /// Checks G/L integration Settings
        /// </summary>
        public bool IsGLAdditionalCostEnabled { get; set; }
        /// <summary>
        /// Checks P/O options settings
        /// </summary>
        public bool IsPOAllowNonInventoryItems { get; set; }
        /// <summary>
        /// Checks I/C options settings
        /// </summary>
        public bool IsICAllowNonStockItems { get; set; }
        /// <summary>
        /// Checks if PM is active
        /// </summary>
        public bool IsPmActive { get; set; }

        #region Finder strings
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string LocationString
        {
            get { return EnumUtility.GetStringValue(Location); }
        }

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string AllowBlankString
        {
            get { return EnumUtility.GetStringValue(AllowBlank); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(Validate); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string AutoInsertString
        {
            get { return EnumUtility.GetStringValue(AutoInsert); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string ExternalCostTransactionsString
        {
            get { return EnumUtility.GetStringValue(ExternalCostTransactions); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string PayablesClearingString
        {
            get { return EnumUtility.GetStringValue(PayablesClearing); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string InventoryControlString
        {
            get { return EnumUtility.GetStringValue(InventoryControl); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string NonStockClearingString
        {
            get { return EnumUtility.GetStringValue(NonStockClearing); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string NonInventoryPayablesClearingString
        {
            get { return EnumUtility.GetStringValue(NonInventoryPayablesClearing); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string NonInventoryExpenseString
        {
            get { return EnumUtility.GetStringValue(NonInventoryExpense); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string InvoicesOptionalFieldsString
        {
            get { return EnumUtility.GetStringValue(InvoicesOptionalFields); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string LaborString
        {
            get { return EnumUtility.GetStringValue(Labor); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string OverheadString
        {
            get { return EnumUtility.GetStringValue(Overhead); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string AdditionalCostExpensePayablesClearingString
        {
            get { return EnumUtility.GetStringValue(AdditionalCostExpensePayablesClearing); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string RequiredString
        {
            get { return EnumUtility.GetStringValue(Required); }
        }
        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string ValueSetString
        {
            get { return EnumUtility.GetStringValue(ValueSet); }
        }

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string AdditionalCostExpenseString
        {
            get { return EnumUtility.GetStringValue(AdditionalCostExpense); }
        }

        /// <summary>
        /// Gets Printed string value
        /// </summary>
        public string DefaultYesNoValueString
        {
            get { return EnumUtility.GetStringValue(DefaultYesNoValue); }
        }

        #endregion
    }
}
