// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for CreditDebitNoteLine
    /// </summary>
    public partial class CreditDebitNoteLine : ModelBase
    {
        public CreditDebitNoteLine()
        {
            CreditDebitNoteComments = new EnumerableResponse<CreditDebitNoteComment>();
            CrdrNoteLineOptionalFields = new EnumerableResponse<CrdrNoteLineOptionalField>();
        }

        [IgnoreExportImport]
        [IsMvcSpecific]
        public IDictionary<string, object> Attributes { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreditDebitNoteSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets CRNLREV
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.LineNo, Id = Index.LineNo, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNo { get; set; }

        /// <summary>
        /// Gets or sets CreditDebitNoteLineSequence
        /// </summary>
        [Display(Name = "CreditDebitNoteLineSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CreditDebitNoteLineSequence, Id = Index.CreditDebitNoteLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CreditDebitNoteLineSequence { get; set; }

        /// <summary>
        /// Gets or sets CRDRNoteCommentSequence
        /// </summary>
        [Display(Name = "CrdrNoteCommentSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CrdrNoteCommentSequence, Id = Index.CrdrNoteCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CrdrNoteCommentSequence { get; set; }

        /// <summary>
        /// Gets or sets OrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string OrderNumber { get; set; }

        /// <summary>
        /// Gets or sets StoredInDatabaseTable
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "StoredInDatabaseTable", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
        public StoredInDatabaseTable StoredInDatabaseTable { get; set; }

        /// <summary>
        /// Gets or sets CompletionStatus
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CompletionStatus", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.CompletionStatus, Id = Index.CompletionStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public CompletionStatus CompletionStatus { get; set; }

        /// <summary>
        /// Gets or sets DateCompleted
        /// </summary>
        [IgnoreExportImport]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCompleted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets ReceiptLineSequence
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReceiptLineSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReceiptLineSequence, Id = Index.ReceiptLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptLineSequence { get; set; }

        /// <summary>
        /// Gets or sets ReturnSequenceKey
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReturnSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets ReturnLineSequence
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ReturnLineSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReturnLineSequence, Id = Index.ReturnLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnLineSequence { get; set; }

        /// <summary>
        /// Gets or sets InvoiceSequenceKey
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "InvoiceSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceSequenceKey, Id = Index.InvoiceSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets InvoiceLineSequence
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "InvoiceLineSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.InvoiceLineSequence, Id = Index.InvoiceLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal InvoiceLineSequence { get; set; }

        /// <summary>
        /// Gets or sets ItemExists
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ItemExists", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ItemExists, Id = Index.ItemExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public ItemExists ItemExists { get; set; }

        /// <summary>
        /// Gets or sets ItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Location
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

        /// <summary>
        /// Gets or sets ItemDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemDescription { get; set; }

        /// <summary>
        /// Gets or sets VendorItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorItemNo", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.VendorItemNumber, Id = Index.VendorItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
        public string VendorItemNumber { get; set; }

        /// <summary>
        /// Gets or sets Comments
        /// </summary>
        [Display(Name = "Comments", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Bool, Size = 2)]
        public Comments Comments { get; set; }

        /// <summary>
        /// Gets or sets UnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitofMeasure", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
        public string UnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets ReturningConversionFactor
        /// </summary>
        [Display(Name = "ReturningConversionFactor", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReturningConversionFactor, Id = Index.ReturningConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal ReturningConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets ReturningUnitDecimals
        /// </summary>
        [Display(Name = "ReturningUnitDecimals", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ReturningUnitDecimals, Id = Index.ReturningUnitDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReturningUnitDecimals { get; set; }

        /// <summary>
        /// Gets or sets StockUnitDecimals
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "StockUnitDecimals", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StockUnitDecimals, Id = Index.StockUnitDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int StockUnitDecimals { get; set; }

        /// <summary>
        /// Gets or sets Quantity
        /// </summary>
        [Display(Name = "Quantity", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Quantity, Id = Index.Quantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal Quantity { get; set; }

        /// <summary>
        /// Gets or sets StockingQuantityReturned
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "StockingQuantityReturned", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.StockingQuantityReturned, Id = Index.StockingQuantityReturned, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal StockingQuantityReturned { get; set; }

        /// <summary>
        /// Gets or sets UnitWeight
        /// </summary>
        [Display(Name = "UnitWeight", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal UnitWeight { get; set; }

        /// <summary>
        /// Gets or sets ExtendedWeight
        /// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets UnitCost
        /// </summary>
        [Display(Name = "UnitCost", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitCost { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost
        /// </summary>
        [Display(Name = "ExtendedCost", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost { get; set; }

        /// <summary>
        /// Gets or sets TaxBase1
        /// </summary>
        [Display(Name = "TaxBase1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase1, Id = Index.TaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase2
        /// </summary>
        [Display(Name = "TaxBase2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase2, Id = Index.TaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase3
        /// </summary>
        [Display(Name = "TaxBase3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase3, Id = Index.TaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase4
        /// </summary>
        [Display(Name = "TaxBase4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase4, Id = Index.TaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBase5
        /// </summary>
        [Display(Name = "TaxBase5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxBase5, Id = Index.TaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1
        /// </summary>
        [Display(Name = "TaxClass1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass1, Id = Index.TaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2
        /// </summary>
        [Display(Name = "TaxClass2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass2, Id = Index.TaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3
        /// </summary>
        [Display(Name = "TaxClass3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass3, Id = Index.TaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4
        /// </summary>
        [Display(Name = "TaxClass4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass4, Id = Index.TaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5
        /// </summary>
        [Display(Name = "TaxClass5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass5, Id = Index.TaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable1
        /// </summary>
        [Display(Name = "TaxIncludable1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncludable1, Id = Index.TaxIncludable1, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncludable1 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable2
        /// </summary>
        [Display(Name = "TaxIncludable2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncludable2, Id = Index.TaxIncludable2, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncludable2 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable3
        /// </summary>
        [Display(Name = "TaxIncludable3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncludable3, Id = Index.TaxIncludable3, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncludable3 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable4
        /// </summary>
        [Display(Name = "TaxIncludable4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncludable4, Id = Index.TaxIncludable4, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncludable4 { get; set; }

        /// <summary>
        /// Gets or sets TaxIncludable5
        /// </summary>
        [Display(Name = "TaxIncludable5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxIncludable5, Id = Index.TaxIncludable5, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool TaxIncludable5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1
        /// </summary>
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2
        /// </summary>
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3
        /// </summary>
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4
        /// </summary>
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5
        /// </summary>
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets NetOfTax
        /// </summary>
        [Display(Name = "NetofTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NetOfTax, Id = Index.NetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetOfTax { get; set; }

        /// <summary>
        /// Gets or sets TaxIncluded
        /// </summary>
        [Display(Name = "TaxIncluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxIncluded, Id = Index.TaxIncluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxIncluded { get; set; }

        /// <summary>
        /// Gets or sets TaxExcluded
        /// </summary>
        [Display(Name = "TaxExcluded", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TaxExcluded, Id = Index.TaxExcluded, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExcluded { get; set; }

        /// <summary>
        /// Gets or sets TotalTax
        /// </summary>
        [Display(Name = "TotalTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.TotalTax, Id = Index.TotalTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTax { get; set; }

        /// <summary>
        /// Gets or sets RecoverableTax
        /// </summary>
        [Display(Name = "RecoverableTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RecoverableTax, Id = Index.RecoverableTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RecoverableTax { get; set; }

        /// <summary>
        /// Gets or sets ExpensedTax
        /// </summary>
        [Display(Name = "ExpensedTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExpensedTax, Id = Index.ExpensedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExpensedTax { get; set; }

        /// <summary>
        /// Gets or sets AllocatedTax
        /// </summary>
        [Display(Name = "AllocatedTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.AllocatedTax, Id = Index.AllocatedTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AllocatedTax { get; set; }

        /// <summary>
        /// Gets or sets FuncNetOfTax
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "NetOfTax", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FuncNetOfTax, Id = Index.FuncNetOfTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncNetOfTax { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount1
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount1, Id = Index.FuncTaxIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount2
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount2, Id = Index.FuncTaxIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount3
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount3, Id = Index.FuncTaxIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount4
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount4, Id = Index.FuncTaxIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxIncludedAmount5
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxIncludedAmount5, Id = Index.FuncTaxIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount1
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount1, Id = Index.FuncTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount2
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount2, Id = Index.FuncTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount3
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount3, Id = Index.FuncTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount4
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount4, Id = Index.FuncTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxAllocatedAmount5
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxAllocatedAmount5, Id = Index.FuncTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount1
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount1, Id = Index.FuncTaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount2
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount2, Id = Index.FuncTaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount3
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount3, Id = Index.FuncTaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount4
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount4, Id = Index.FuncTaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxRecoverableAmount5
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxRecoverableAmount5, Id = Index.FuncTaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount1
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount1, Id = Index.FuncTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount2
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount2, Id = Index.FuncTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount3
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount3, Id = Index.FuncTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount4
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount4, Id = Index.FuncTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FuncTaxExpenseAmount5
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncTaxExpenseAmount5, Id = Index.FuncTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FuncExtendedAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "FuncExtendedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncExtendedAmount, Id = Index.FuncExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncExtendedAmount { get; set; }

        /// <summary>
        /// Gets or sets ExpenseAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpenseAccount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExpenseAccount, Id = Index.ExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets ManualProration
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ManualProration", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ManualProration, Id = Index.ManualProration, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ManualProration { get; set; }

        /// <summary>
        /// Gets or sets StockItem
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "StockItem", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
        public StockItem StockItem { get; set; }

        /// <summary>
        /// Gets or sets ReceiptNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReceiptNumber, Id = Index.ReceiptNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ReceiptNumber { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderSequenceKey
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PurchaseOrderSequenceKey", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderLineSequence
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "PurchaseOrderLineSequence", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.PurchaseOrderLineSequence, Id = Index.PurchaseOrderLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal PurchaseOrderLineSequence { get; set; }

        /// <summary>
        /// Gets or sets PurchaseOrderNumber
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PurchaseOrderNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.PurchaseOrderNumber, Id = Index.PurchaseOrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string PurchaseOrderNumber { get; set; }

        /// <summary>
        /// Gets or sets NonStockClearingAccount
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NonStockClearing", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.NonStockClearingAccount, Id = Index.NonStockClearingAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string NonStockClearingAccount { get; set; }

        /// <summary>
        /// Gets or sets ManufacturersItemNumber
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ManufacturersItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
        public string ManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets DiscountPercentage
        /// </summary>
        [Display(Name = "DiscountPercentage", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal DiscountPercentage { get; set; }

        /// <summary>
        /// Gets or sets DiscountAmount
        /// </summary>
        [Display(Name = "DiscountAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncDiscountAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "FuncDiscountAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.FuncDiscountAmount, Id = Index.FuncDiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDiscountAmount { get; set; }

        /// <summary>
        /// Gets or sets OptionalFields
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "OptionalFields", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets first
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "First", ResourceType = typeof(CommonResx))]
        public int First { get; set; }

        /// <summary>
        /// Gets or sets TaxClass1Description
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass1Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass1Description, Id = Index.TaxClass1Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass1Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass2Description
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass2Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass2Description, Id = Index.TaxClass2Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass2Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass3Description
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass3Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass3Description, Id = Index.TaxClass3Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass3Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass4Description
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass4Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass4Description, Id = Index.TaxClass4Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass4Description { get; set; }

        /// <summary>
        /// Gets or sets TaxClass5Description
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxClass5Description", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxClass5Description, Id = Index.TaxClass5Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxClass5Description { get; set; }

        /// <summary>
        /// Gets or sets ExpenseAccountDescription
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpenseAccountDescription", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExpenseAccountDescription, Id = Index.ExpenseAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ExpenseAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount1
        /// </summary>
        [Display(Name = "IncludedTaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount1, Id = Index.IncludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount2
        /// </summary>
        [Display(Name = "IncludedTaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount2, Id = Index.IncludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount3
        /// </summary>
        [Display(Name = "IncludedTaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount3, Id = Index.IncludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount4
        /// </summary>
        [Display(Name = "IncludedTaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount4, Id = Index.IncludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets IncludedTaxAmount5
        /// </summary>
        [Display(Name = "IncludedTaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.IncludedTaxAmount5, Id = Index.IncludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal IncludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount1
        /// </summary>
        [Display(Name = "ExcludedTaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount1, Id = Index.ExcludedTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount2
        /// </summary>
        [Display(Name = "ExcludedTaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount2, Id = Index.ExcludedTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount3
        /// </summary>
        [Display(Name = "ExcludedTaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount3, Id = Index.ExcludedTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount4
        /// </summary>
        [Display(Name = "ExcludedTaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount4, Id = Index.ExcludedTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets ExcludedTaxAmount5
        /// </summary>
        [Display(Name = "ExcludedTaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExcludedTaxAmount5, Id = Index.ExcludedTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExcludedTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets Completed
        /// </summary>
        [Display(Name = "Completed", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

        /// <summary>
        /// Gets or sets ExtraneousLineCount
        /// </summary>
        [Display(Name = "ExtraneousLineCount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtraneousLineCount, Id = Index.ExtraneousLineCount, FieldType = EntityFieldType.Long, Size = 4)]
        public long ExtraneousLineCount { get; set; }

        /// <summary>
        /// Gets or sets LinesTaxCalculationSees
        /// </summary>
        [Display(Name = "LinesTaxCalculationSees", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LinesTaxCalculationSees, Id = Index.LinesTaxCalculationSees, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesTaxCalculationSees { get; set; }

        /// <summary>
        /// Gets or sets LinesComplete
        /// </summary>
        [Display(Name = "LinesComplete", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.LinesComplete, Id = Index.LinesComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesComplete { get; set; }

        /// <summary>
        /// Gets or sets Line
        /// </summary>
        [Display(Name = "Line", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
        public long Line { get; set; }

        /// <summary>
        /// Gets or sets ExtendedStdCostInSrcCurr
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExtendedStdCostInSrcCurr", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedStdCostInSrcCurr, Id = Index.ExtendedStdCostInSrcCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedStdCostInSrcCurr { get; set; }

        /// <summary>
        /// Gets or sets ExtendedMRCostInSrcCurr
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExtendedMrCostInSrcCurr", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public decimal ExtendedMrCostInSrcCurr { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost1InSrcCurr
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExtendedCost1InSrcCurr", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedCost1InSrcCurr, Id = Index.ExtendedCost1InSrcCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost1InSrcCurr { get; set; }

        /// <summary>
        /// Gets or sets ExtendedCost2InSrcCurr
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExtendedCost2InSrcCurr", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedCost2InSrcCurr, Id = Index.ExtendedCost2InSrcCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedCost2InSrcCurr { get; set; }

        /// <summary>
        /// Gets or sets NonStockClearingAccountDesc
        /// </summary>
        [IgnoreExportImport]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NonStockClearingAccountDesc", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NonStockClearingAccountDesc, Id = Index.NonStockClearingAccountDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string NonStockClearingAccountDesc { get; set; }

        /// <summary>
        /// Gets or sets MapManufacturersItemNumber
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ManufacturersItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.MapManufacturersItemNumber, Id = Index.MapManufacturersItemNumber, FieldType = EntityFieldType.Bool, Size = 2)]
        public MapManufacturersItemNumber MapManufacturersItemNumber { get; set; }

        /// <summary>
        /// Gets or sets NetExtendedCost
        /// </summary>
        [Display(Name = "NetExtendedCost", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NetExtendedCost, Id = Index.NetExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NetExtendedCost { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets INVLREV
        /// </summary>
        [IgnoreExportImport]
        public decimal Invlrev { get; set; }

        // TODO: The naming convention of this property has to be manually evaluated
        /// <summary>
        /// Gets or sets RETLREV
        /// </summary>
        [IgnoreExportImport]
        public decimal Retlrev { get; set; }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Command", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets Contract
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Contract", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string Contract { get; set; }

        /// <summary>
        /// Gets or sets Project
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Project", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Project { get; set; }

        /// <summary>
        /// Gets or sets Category
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Category", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
        public string Category { get; set; }

        /// <summary>
        /// Gets or sets CostClass
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CostClass", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
        public CostClass CostClass { get; set; }

        /// <summary>
        /// Gets or sets BillingType
        /// </summary>
        [Display(Name = "BillingType", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.BillingType, Id = Index.BillingType, FieldType = EntityFieldType.Int, Size = 2)]
        public BillingType BillingType { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BillingCurrency", ResourceType = typeof(POCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.BillingCurrency, Id = Index.BillingCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string BillingCurrency { get; set; }

        /// <summary>
        /// Gets or sets ARItemNumber
        /// </summary>
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ARItemNumber, Id = Index.ARItemNumber, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string ARItemNumber { get; set; }

        /// <summary>
        /// Gets or sets ARUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ARItemUOM", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ARUnitOfMeasure, Id = Index.ARUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10C")]
        public string ARUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets RetainagePercentage
        /// </summary>
        [Display(Name = "RetainagePercentage", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RetainagePercentage, Id = Index.RetainagePercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
        public decimal RetainagePercentage { get; set; }

        /// <summary>
        /// Gets or sets RetentionPeriod
        /// </summary>
        [Display(Name = "RetentionPeriod", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RetentionPeriod, Id = Index.RetentionPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int RetentionPeriod { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmount
        /// </summary>
        [Display(Name = "RetainageAmount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RetainageAmount, Id = Index.RetainageAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RetainageDateDue", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RetainageDueDate, Id = Index.RetainageDueDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RetainageDueDate { get; set; }

        /// <summary>
        /// Gets or sets RetainageAmountOverridden
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageAmountOverridden", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageAmountOverridden, Id = Index.RetainageAmountOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public RetainageAmountOverridden RetainageAmountOverridden { get; set; }

        /// <summary>
        /// Gets or sets RetainageDueDateOverridden
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "RetainageDueDateOverridden", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageDueDateOverridden, Id = Index.RetainageDueDateOverridden, FieldType = EntityFieldType.Bool, Size = 2)]
        public RetainageDueDateOverridden RetainageDueDateOverridden { get; set; }

        /// <summary>
        /// Gets or sets ProjectStyle
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ProjectStyle", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectStyle ProjectStyle { get; set; }

        /// <summary>
        /// Gets or sets ProjectType
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ProjectType", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
        public ProjectType ProjectType { get; set; }

        /// <summary>
        /// Gets or sets AccountingMethod
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "AccountingMethod", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AccountingMethod, Id = Index.AccountingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public AccountingMethod AccountingMethod { get; set; }

        /// <summary>
        /// Gets or sets UnformattedContractCode
        /// </summary>
        [IgnoreExportImport]
        [StringLength(16, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnformattedContractCode", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
        public string UnformattedContractCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmt5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount1
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount1, Id = Index.TaxReportingExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount2
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount2, Id = Index.TaxReportingExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount3
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount3, Id = Index.TaxReportingExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount4
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount4, Id = Index.TaxReportingExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpenseAmount5
        /// </summary>
        [Display(Name = "TaxReportingExpenseAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpenseAmount5, Id = Index.TaxReportingExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount1, Id = Index.TaxReportingIncludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount2, Id = Index.TaxReportingIncludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount3, Id = Index.TaxReportingIncludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount4, Id = Index.TaxReportingIncludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount5, Id = Index.TaxReportingIncludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount1
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount1, Id = Index.TaxReportingExcludedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount2
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount2, Id = Index.TaxReportingExcludedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount3
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount3, Id = Index.TaxReportingExcludedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount4
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount4, Id = Index.TaxReportingExcludedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount5
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount5, Id = Index.TaxReportingExcludedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingTotalAmount
        /// </summary>
        [Display(Name = "TaxReportingTotalAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingTotalAmount, Id = Index.TaxReportingTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingIncludedAmount
        /// </summary>
        [Display(Name = "TaxReportingIncludedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingIncludedAmount, Id = Index.TaxReportingIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExcludedAmount
        /// </summary>
        [Display(Name = "TaxReportingExcludedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExcludedAmount, Id = Index.TaxReportingExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmount
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingRecoverableAmount, Id = Index.TaxReportingRecoverableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensedAmount
        /// </summary>
        [Display(Name = "TaxReportingExpensedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingExpensedAmount, Id = Index.TaxReportingExpensedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount, Id = Index.TaxReportingAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase1
        /// </summary>
        [Display(Name = "RetainageTaxBase1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase1, Id = Index.RetainageTaxBase1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase2
        /// </summary>
        [Display(Name = "RetainageTaxBase2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase2, Id = Index.RetainageTaxBase2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase3
        /// </summary>
        [Display(Name = "RetainageTaxBase3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase3, Id = Index.RetainageTaxBase3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase4
        /// </summary>
        [Display(Name = "RetainageTaxBase4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase4, Id = Index.RetainageTaxBase4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxBase5
        /// </summary>
        [Display(Name = "RetainageTaxBase5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxBase5, Id = Index.RetainageTaxBase5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxBase5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount1
        /// </summary>
        [Display(Name = "RetainageTaxAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount1, Id = Index.RetainageTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount2, Id = Index.RetainageTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount3, Id = Index.RetainageTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount4, Id = Index.RetainageTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAmount5, Id = Index.RetainageTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt1
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt1, Id = Index.RetainageTaxRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt2
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt2, Id = Index.RetainageTaxRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt3
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt3, Id = Index.RetainageTaxRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt4
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt4, Id = Index.RetainageTaxRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxRecoverableAmt5
        /// </summary>
        [Display(Name = "RetainageTaxRecoverableAmt5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxRecoverableAmt5, Id = Index.RetainageTaxRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount1
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount1, Id = Index.RetainageTaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount2
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount2, Id = Index.RetainageTaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount3
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount3, Id = Index.RetainageTaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount4
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount4, Id = Index.RetainageTaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxExpenseAmount5
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxExpenseAmount5, Id = Index.RetainageTaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount1
        /// </summary>
        [Display(Name = "RetainageTaxExpenseAmount1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount1, Id = Index.RetainageTaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount2
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount2, Id = Index.RetainageTaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount3
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount3, Id = Index.RetainageTaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount4
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount4, Id = Index.RetainageTaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxAllocatedAmount5
        /// </summary>
        [Display(Name = "RetainageTaxAllocatedAmount5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxAllocatedAmount5, Id = Index.RetainageTaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets RetainageTaxTotalAmount
        /// </summary>
        [Display(Name = "RetainageTaxTotalAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.RetainageTaxTotalAmount, Id = Index.RetainageTaxTotalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RetainageTaxTotalAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt1
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt1", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt1, Id = Index.TaxAmountPlusRtgTaxAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt2
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt2", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt2, Id = Index.TaxAmountPlusRtgTaxAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt3
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt3", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt3, Id = Index.TaxAmountPlusRtgTaxAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt4
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt4", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt4, Id = Index.TaxAmountPlusRtgTaxAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountPlusRtgTaxAmt5
        /// </summary>
        [Display(Name = "TaxAmountPlusRtgTaxAmt5", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.TaxAmountPlusRtgTaxAmt5, Id = Index.TaxAmountPlusRtgTaxAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmountPlusRtgTaxAmt5 { get; set; }

        /// <summary>
        /// Gets or sets UnitCostIsManual
        /// </summary>
        [Display(Name = "UnitCostIsManual", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnitCostIsManual, Id = Index.UnitCostIsManual, FieldType = EntityFieldType.Bool, Size = 2)]
        public UnitCostIsManual UnitCostIsManual { get; set; }

        /// <summary>
        /// Gets or sets WeightUnitOfMeasure
        /// </summary>
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "WeightUnitofMeasure", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
        public string WeightUnitOfMeasure { get; set; }

        /// <summary>
        /// Gets or sets WeightConversion
        /// </summary>
        [Display(Name = "WeightConversion", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.WeightConversion, Id = Index.WeightConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal WeightConversion { get; set; }

        /// <summary>
        /// Gets or sets DefaultUnitWeight
        /// </summary>
        [Display(Name = "DefaultUnitWeight", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DefaultUnitWeight, Id = Index.DefaultUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefaultUnitWeight { get; set; }

        /// <summary>
        /// Gets or sets DefaultExtendedWeight
        /// </summary>
        [Display(Name = "DefaultExtendedWeight", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DefaultExtendedWeight, Id = Index.DefaultExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal DefaultExtendedWeight { get; set; }

        /// <summary>
        /// Gets or sets BillingRateConversionFactor
        /// </summary>
        [Display(Name = "BillingRateConversionFactor", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.BillingRateConversionFactor, Id = Index.BillingRateConversionFactor, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRateConversionFactor { get; set; }

        /// <summary>
        /// Gets or sets UnitBillingAmount
        /// </summary>
        [Display(Name = "UnitBillingAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.UnitBillingAmount, Id = Index.UnitBillingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal UnitBillingAmount { get; set; }

        /// <summary>
        /// Gets or sets ExtendedBillingAmount
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "ExtendedBillingAmount", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ExtendedBillingAmount, Id = Index.ExtendedBillingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExtendedBillingAmount { get; set; }

        /// <summary>
        /// Gets or sets SerialLotQuantityToProcess
        /// </summary>
        [Display(Name = "SerialLotQuantityToProcess", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialLotQuantityToProcess, Id = Index.SerialLotQuantityToProcess, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal SerialLotQuantityToProcess { get; set; }

        /// <summary>
        /// Gets or sets NumberOfLotsToGenerate
        /// </summary>
        [Display(Name = "NumberOfLotsToGenerate", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.NumberOfLotsToGenerate, Id = Index.NumberOfLotsToGenerate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NumberOfLotsToGenerate { get; set; }

        /// <summary>
        /// Gets or sets QuantityperLot
        /// </summary>
        [Display(Name = "QuantityperLot", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.QuantityperLot, Id = Index.QuantityperLot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityperLot { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromSerial
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromSerial", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AllocateFromSerial, Id = Index.AllocateFromSerial, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromSerial { get; set; }

        /// <summary>
        /// Gets or sets AllocateFromLot
        /// </summary>
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AllocateFromLot", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.AllocateFromLot, Id = Index.AllocateFromLot, FieldType = EntityFieldType.Char, Size = 40)]
        public string AllocateFromLot { get; set; }

        /// <summary>
        /// Gets or sets SerialLotWindowHandle
        /// </summary>
        [Display(Name = "SerialLotWindowHandle", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialLotWindowHandle, Id = Index.SerialLotWindowHandle, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialLotWindowHandle { get; set; }

        /// <summary>
        /// Gets or sets SerialQuantity
        /// </summary>
        [Display(Name = "SerialQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.SerialQuantity, Id = Index.SerialQuantity, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialQuantity { get; set; }

        /// <summary>
        /// Gets or sets LotQuantity
        /// </summary>
        [Display(Name = "LotQuantity", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal LotQuantity { get; set; }

        /// <summary>
        /// Gets or sets ItemSerializedLotted
        /// </summary>
        [Display(Name = "ItemSerializedLotted", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.ItemSerializedLotted, Id = Index.ItemSerializedLotted, FieldType = EntityFieldType.Int, Size = 2)]
        public ItemSerializedLotted ItemSerializedLotted { get; set; }

        /// <summary>
        /// Gets or sets DetailNumber
        /// </summary>
        [Display(Name = "DetailNumber", ResourceType = typeof(CreditDebitNoteEntryResx))]
        [ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
        public int DetailNumber { get; set; }

        /// <summary>
        /// Gets or sets BillingCurrencyDecimal
        /// </summary>
        [ViewField(Name = Fields.BillingCurrencyDecimal, Id = Index.BillingCurrencyDecimal, FieldType = EntityFieldType.Int, Size = 2)]
        public int BillingCurrencyDecimal { get; set; }

        /// <summary>
        ///  Gets CostClassString
        /// </summary>
        [IgnoreExportImport]
        public string CostClassString => EnumUtility.GetStringValue(CostClass);

        /// <summary>
        /// Gets  or Sets the Discounted ExtenedCost
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "DiscountedExtendedCost", ResourceType = typeof(POCommonResx))]
        public decimal DiscountedExtendedCost {
            get { return ExtendedCost - DiscountAmount; }
        }

        ///// <summary>
        ///// Gets  or Sets the grid line number
        ///// </summary>
        //[IgnoreExportImport]
        //[Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        //public long LineNumber { get; set; }

        [IgnoreExportImport]
        public string OptionalFieldString { get; set; }

        /// <summary>
        /// Gets  or Sets comments items
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CreditDebitNoteComments", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public EnumerableResponse<CreditDebitNoteComment> CreditDebitNoteComments { get; set; }

        /// <summary>
        /// Gets  or Sets detail grid optional field items
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "CrdrNoteLineOptionalFields", ResourceType = typeof(CreditDebitNoteEntryResx))]
        public EnumerableResponse<CrdrNoteLineOptionalField> CrdrNoteLineOptionalFields { get; set; }
    }
}
