// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Return Comment
    /// </summary>
    public partial class ReturnComment : ModelBase
    {
        /// <summary>
        /// Gets or sets ReturnSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReturnSequenceKey", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ReturnSequenceKey, Id = Index.ReturnSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets CommentIdentifier
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CommentIdentifier", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.CommentIdentifier, Id = Index.CommentIdentifier, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal CommentIdentifier { get; set; }

        /// <summary>
        /// Gets or sets ReturnCommentSequence
        /// </summary>
        [Display(Name = "ReturnCommentSequence", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.ReturnCommentSequence, Id = Index.ReturnCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReturnCommentSequence { get; set; }

        /// <summary>
        /// Gets or sets StoredInDatabaseTable
        /// </summary>
        [IgnoreExportImport]
        // ReSharper disable once UnusedAutoPropertyAccessor.Global
        [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
        public StoredInDatabaseTable StoredInDatabaseTable { get; set; }

        /// <summary>
        /// Gets or sets LineType
        /// </summary>
        [Display(Name = "LineType", ResourceType = typeof(ReturnEntryResx))]
        [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
        public LineType LineType { get; set; }

        /// <summary>
        /// Gets or sets Comment
        /// </summary>
        [StringLength(80, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 80)]
        public string Comment { get; set; }
    }
}
