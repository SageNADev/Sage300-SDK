// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for PurchaseOrderComment
     /// </summary>
     public partial class PurchaseOrderComment : ModelBase
     {
          /// <summary>
          /// Gets or sets PurchaseOrderSequenceKey
          /// </summary>
          [Key]
          [Display(Name = "PurchaseOrderSequenceKey", ResourceType = typeof(PurchaseOrderEntryResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal PurchaseOrderSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets CommentIdentifier
          /// </summary>
          [Key]
          [Display(Name = "CommentIdentifier", ResourceType = typeof(PurchaseOrderEntryResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.CommentIdentifier, Id = Index.CommentIdentifier, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CommentIdentifier {get; set;}

          /// <summary>
          /// Gets or sets PurchaseOrderCommentSequence
          /// </summary>
          [Display(Name = "PurchaseOrderCommentSequence", ResourceType = typeof(PurchaseOrderEntryResx))]
          [ViewField(Name = Fields.PurchaseOrderCommentSequence, Id = Index.PurchaseOrderCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal PurchaseOrderCommentSequence {get; set;}

          /// <summary>
          /// Gets or sets StoredInDatabaseTable
          /// </summary>
          [IgnoreExportImport] 
          [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
          public StoredInDatabaseTable StoredInDatabaseTable {get; set;}

          /// <summary>
          /// Gets or sets LineType
          /// </summary>
          [Display(Name = "LineType", ResourceType = typeof(PurchaseOrderEntryResx))]
          [ViewField(Name = Fields.LineType, Id = Index.LineType, FieldType = EntityFieldType.Int, Size = 2)]
          public LineType LineType {get; set;}

          /// <summary>
          /// Gets or sets CommentsInstructions
          /// </summary>
          [Display(Name = "CommentsInstructions", ResourceType = typeof(POCommonResx))] 
          [StringLength(80, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.CommentsInstructions, Id = Index.CommentsInstructions, FieldType = EntityFieldType.Char, Size = 80)]
          public string CommentsInstructions {get; set;}

          #region UI

          /// <summary>
          ///  Gets or sets Attributes
          /// </summary>
          [IgnoreExportImport]
          public IDictionary<string, object> Attributes { get; set; }

          #endregion

     }
}
