// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Ship-Via Code Constants
    /// </summary>
    public partial class ShipViaCode
     {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0900";

          #region Properties
          /// <summary>
          /// Contains list of Ship-Via Code Field Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for Ship-Via
               /// </summary>
               public const string ShipVia = "CODE";

               /// <summary>
               /// Property for Ship-Via Name
               /// </summary>
               public const string ShipViaName = "NAME";

               /// <summary>
               /// Property for Address 1
               /// </summary>
               public const string Address1 = "ADDRESS1";

               /// <summary>
               /// Property for Address 2
               /// </summary>
               public const string Address2 = "ADDRESS2";

               /// <summary>
               /// Property for Address 3
               /// </summary>
               public const string Address3 = "ADDRESS3";

               /// <summary>
               /// Property for Address 4
               /// </summary>
               public const string Address4 = "ADDRESS4";

               /// <summary>
               /// Property for City
               /// </summary>
               public const string City = "CITY";

               /// <summary>
               /// Property for State Province
               /// </summary>
               public const string StateProvince = "STATE";

               /// <summary>
               /// Property for Zip/Postal Code
               /// </summary>
               public const string ZipPostalCode = "ZIP";

               /// <summary>
               /// Property for Country
               /// </summary>
               public const string Country = "COUNTRY";

               /// <summary>
               /// Property for Phone Number
               /// </summary>
               public const string PhoneNumber = "PHONE";

               /// <summary>
               /// Property for Fax Number
               /// </summary>
               public const string FaxNumber = "FAX";

               /// <summary>
               /// Property for Contact
               /// </summary>
               public const string Contact = "CONTACT";

               /// <summary>
               /// Property for Comment
               /// </summary>
               public const string Comment = "COMMENT";

               /// <summary>
               /// Property for Email
               /// </summary>
               public const string Email = "EMAIL";

               /// <summary>
               /// Property for Contact Phone
               /// </summary>
               public const string ContactPhone = "PHONEC";

               /// <summary>
               /// Property for Contact Fax
               /// </summary>
               public const string ContactFax = "FAXC";

               /// <summary>
               /// Property for Contact Email
               /// </summary>
               public const string ContactEmail = "EMAILC";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of Ship-Via Code Index Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for Ship-Via
               /// </summary>
               public const int ShipVia = 1;

               /// <summary>
               /// Property Indexer for Ship-Via Name
               /// </summary>
               public const int ShipViaName = 2;

               /// <summary>
               /// Property Indexer for Address 1
               /// </summary>
               public const int Address1 = 3;

               /// <summary>
               /// Property Indexer for Address 2
               /// </summary>
               public const int Address2 = 4;

               /// <summary>
               /// Property Indexer for Address 3
               /// </summary>
               public const int Address3 = 5;

               /// <summary>
               /// Property Indexer for Address 4
               /// </summary>
               public const int Address4 = 6;

               /// <summary>
               /// Property Indexer for City
               /// </summary>
               public const int City = 7;

               /// <summary>
               /// Property Indexer for State Province
               /// </summary>
               public const int StateProvince = 8;

               /// <summary>
               /// Property Indexer for Zip/Postal Code
               /// </summary>
               public const int ZipPostalCode = 9;

               /// <summary>
               /// Property Indexer for Country
               /// </summary>
               public const int Country = 10;

               /// <summary>
               /// Property Indexer for Phone Number
               /// </summary>
               public const int PhoneNumber = 11;

               /// <summary>
               /// Property Indexer for Fax Number
               /// </summary>
               public const int FaxNumber = 12;

               /// <summary>
               /// Property Indexer for Contact
               /// </summary>
               public const int Contact = 13;

               /// <summary>
               /// Property Indexer for Comment
               /// </summary>
               public const int Comment = 14;

               /// <summary>
               /// Property Indexer for Email
               /// </summary>
               public const int Email = 15;

               /// <summary>
               /// Property Indexer for Contact Phone
               /// </summary>
               public const int ContactPhone = 16;

               /// <summary>
               /// Property Indexer for Contact Fax
               /// </summary>
               public const int ContactFax = 17;

               /// <summary>
               /// Property Indexer for Contact Email
               /// </summary>
               public const int ContactEmail = 18;

          }
          #endregion

     }
}
