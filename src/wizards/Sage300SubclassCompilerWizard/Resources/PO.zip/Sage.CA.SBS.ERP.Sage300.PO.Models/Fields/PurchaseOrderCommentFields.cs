// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseOrderComment Constants
    /// </summary>
    public partial class PurchaseOrderComment
    {

        #region Public Constant

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0610";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
                    {"COMMENT", "CommentsInstructions"}
				};
            }
        }

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of PurchaseOrderComment Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for CommentIdentifier
            /// </summary>
            public const string CommentIdentifier = "PORCREV";

            /// <summary>
            /// Property for PurchaseOrderCommentSequence
            /// </summary>
            public const string PurchaseOrderCommentSequence = "PORCSEQ";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for LineType
            /// </summary>
            public const string LineType = "COMMENTTYP";

            /// <summary>
            /// Property for CommentsInstructions
            /// </summary>
            public const string CommentsInstructions = "COMMENT";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of PurchaseOrderComment Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 1;

            /// <summary>
            /// Property Indexer for CommentIdentifier
            /// </summary>
            public const int CommentIdentifier = 2;

            /// <summary>
            /// Property Indexer for PurchaseOrderCommentSequence
            /// </summary>
            public const int PurchaseOrderCommentSequence = 3;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 4;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 5;

            /// <summary>
            /// Property Indexer for CommentsInstructions
            /// </summary>
            public const int CommentsInstructions = 6;

        }

        #endregion

    }
}
