// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseHistory Constants
    /// </summary>
    public partial class PurchaseHistory
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0380";

        #region Properties

        /// <summary>
        /// Contains list of PurchaseHistory Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VENDOR";

            /// <summary>
            /// Property for ITEMNO
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for NoOfReceipts
            /// </summary>
            public const string NoOfReceipts = "RCPCOUNT";

            /// <summary>
            /// Property for QuantityReceived
            /// </summary>
            public const string QuantityReceived = "SQRECEIVED";

            /// <summary>
            /// Property for FuncTotalReceived
            /// </summary>
            public const string FuncTotalReceived = "FCRECEIVED";

            /// <summary>
            /// Property for SrceTotalReceived
            /// </summary>
            public const string SrceTotalReceived = "SCRECEIVED";

            /// <summary>
            /// Property for NoOfInvoices
            /// </summary>
            public const string NoOfInvoices = "INVCOUNT";

            /// <summary>
            /// Property for QuantityAdjustedonInvoices
            /// </summary>
            public const string QuantityAdjustedonInvoices = "SQINVADJ";

            /// <summary>
            /// Property for FuncAdjustedonInvoices
            /// </summary>
            public const string FuncAdjustedonInvoices = "FCINVADJ";

            /// <summary>
            /// Property for SrceAdjustedonInvoices
            /// </summary>
            public const string SrceAdjustedonInvoices = "SCINVADJ";

            /// <summary>
            /// Property for NoOfReturns
            /// </summary>
            public const string NoOfReturns = "RETCOUNT";

            /// <summary>
            /// Property for QuantityReturned
            /// </summary>
            public const string QuantityReturned = "SQRETURNED";

            /// <summary>
            /// Property for FuncReturnAmount
            /// </summary>
            public const string FuncReturnAmount = "FCRETURNED";

            /// <summary>
            /// Property for SrceReturnAmount
            /// </summary>
            public const string SrceReturnAmount = "SCRETURNED";

            /// <summary>
            /// Property for NoOfCreditNotes
            /// </summary>
            public const string NoOfCreditNotes = "CRNCOUNT";

            /// <summary>
            /// Property for QuantityCredited
            /// </summary>
            public const string QuantityCredited = "SQCRNADJ";

            /// <summary>
            /// Property for FuncCreditNoteAmount
            /// </summary>
            public const string FuncCreditNoteAmount = "FCCRNADJ";

            /// <summary>
            /// Property for SrceCreditNoteAmount
            /// </summary>
            public const string SrceCreditNoteAmount = "SCCRNADJ";

            /// <summary>
            /// Property for NoOfDebitNotes
            /// </summary>
            public const string NoOfDebitNotes = "DEBCOUNT";

            /// <summary>
            /// Property for QuantityDebited
            /// </summary>
            public const string QuantityDebited = "SQDEBADJ";

            /// <summary>
            /// Property for FuncDebitNoteAmount
            /// </summary>
            public const string FuncDebitNoteAmount = "FCDEBADJ";

            /// <summary>
            /// Property for SrceDebitNoteAmount
            /// </summary>
            public const string SrceDebitNoteAmount = "SCDEBADJ";

            /// <summary>
            /// Property for QuantityInvoiced
            /// </summary>
            public const string QuantityInvoiced = "SQINVTOTAL";

            /// <summary>
            /// Property for FuncTotalInvoiced
            /// </summary>
            public const string FuncTotalInvoiced = "FCINVTOTAL";

            /// <summary>
            /// Property for SrceTotalInvoiced
            /// </summary>
            public const string SrceTotalInvoiced = "SCINVTOTAL";

            /// <summary>
            /// Property for TotalCreditedQuantity
            /// </summary>
            public const string TotalCreditedQuantity = "SQCRNTOTAL";

            /// <summary>
            /// Property for FuncTotalCredited
            /// </summary>
            public const string FuncTotalCredited = "FCCRNTOTAL";

            /// <summary>
            /// Property for SrceTotalCredited
            /// </summary>
            public const string SrceTotalCredited = "SCCRNTOTAL";

            /// <summary>
            /// Property for TotalDebitedQuantity
            /// </summary>
            public const string TotalDebitedQuantity = "SQDEBTOTAL";

            /// <summary>
            /// Property for FuncTotalDebited
            /// </summary>
            public const string FuncTotalDebited = "FCDEBTOTAL";

            /// <summary>
            /// Property for SrceTotalDebited
            /// </summary>
            public const string SrceTotalDebited = "SCDEBTOTAL";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for VendorName
            /// </summary>
            public const string VendorName = "VENDNAME";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTITEMNO
            /// </summary>
            public const string FormattedItemNumber = "FMTITEMNO";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PurchaseHistory Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 1;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ITEMNO
            /// </summary>
            public const int ItemNumber = 2;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 3;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 4;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 5;

            /// <summary>
            /// Property Indexer for NoOfReceipts
            /// </summary>
            public const int NoOfReceipts = 6;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 7;

            /// <summary>
            /// Property Indexer for FuncTotalReceived
            /// </summary>
            public const int FuncTotalReceived = 8;

            /// <summary>
            /// Property Indexer for SrceTotalReceived
            /// </summary>
            public const int SrceTotalReceived = 9;

            /// <summary>
            /// Property Indexer for NoOfInvoices
            /// </summary>
            public const int NoOfInvoices = 10;

            /// <summary>
            /// Property Indexer for QuantityAdjustedonInvoices
            /// </summary>
            public const int QuantityAdjustedonInvoices = 11;

            /// <summary>
            /// Property Indexer for FuncAdjustedonInvoices
            /// </summary>
            public const int FuncAdjustedonInvoices = 12;

            /// <summary>
            /// Property Indexer for SrceAdjustedonInvoices
            /// </summary>
            public const int SrceAdjustedonInvoices = 13;

            /// <summary>
            /// Property Indexer for NoOfReturns
            /// </summary>
            public const int NoOfReturns = 14;

            /// <summary>
            /// Property Indexer for QuantityReturned
            /// </summary>
            public const int QuantityReturned = 15;

            /// <summary>
            /// Property Indexer for FuncReturnAmount
            /// </summary>
            public const int FuncReturnAmount = 16;

            /// <summary>
            /// Property Indexer for SrceReturnAmount
            /// </summary>
            public const int SrceReturnAmount = 17;

            /// <summary>
            /// Property Indexer for NoOfCreditNotes
            /// </summary>
            public const int NoOfCreditNotes = 18;

            /// <summary>
            /// Property Indexer for QuantityCredited
            /// </summary>
            public const int QuantityCredited = 19;

            /// <summary>
            /// Property Indexer for FuncCreditNoteAmount
            /// </summary>
            public const int FuncCreditNoteAmount = 20;

            /// <summary>
            /// Property Indexer for SrceCreditNoteAmount
            /// </summary>
            public const int SrceCreditNoteAmount = 21;

            /// <summary>
            /// Property Indexer for NoOfDebitNotes
            /// </summary>
            public const int NoOfDebitNotes = 22;

            /// <summary>
            /// Property Indexer for QuantityDebited
            /// </summary>
            public const int QuantityDebited = 23;

            /// <summary>
            /// Property Indexer for FuncDebitNoteAmount
            /// </summary>
            public const int FuncDebitNoteAmount = 24;

            /// <summary>
            /// Property Indexer for SrceDebitNoteAmount
            /// </summary>
            public const int SrceDebitNoteAmount = 25;

            /// <summary>
            /// Property Indexer for QuantityInvoiced
            /// </summary>
            public const int QuantityInvoiced = 26;

            /// <summary>
            /// Property Indexer for FuncTotalInvoiced
            /// </summary>
            public const int FuncTotalInvoiced = 27;

            /// <summary>
            /// Property Indexer for SrceTotalInvoiced
            /// </summary>
            public const int SrceTotalInvoiced = 28;

            /// <summary>
            /// Property Indexer for TotalCreditedQuantity
            /// </summary>
            public const int TotalCreditedQuantity = 29;

            /// <summary>
            /// Property Indexer for FuncTotalCredited
            /// </summary>
            public const int FuncTotalCredited = 30;

            /// <summary>
            /// Property Indexer for SrceTotalCredited
            /// </summary>
            public const int SrceTotalCredited = 31;

            /// <summary>
            /// Property Indexer for TotalDebitedQuantity
            /// </summary>
            public const int TotalDebitedQuantity = 32;

            /// <summary>
            /// Property Indexer for FuncTotalDebited
            /// </summary>
            public const int FuncTotalDebited = 33;

            /// <summary>
            /// Property Indexer for SrceTotalDebited
            /// </summary>
            public const int SrceTotalDebited = 34;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 50;

            /// <summary>
            /// Property Indexer for VendorName
            /// </summary>
            public const int VendorName = 51;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTITEMNO
            /// </summary>
            public const int FormattedItemNumber = 52;

        }

        #endregion
    }
}
