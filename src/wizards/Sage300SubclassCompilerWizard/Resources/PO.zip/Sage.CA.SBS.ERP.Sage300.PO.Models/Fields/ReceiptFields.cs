// Copyright (c) 1994-2023 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of Receipt Constants
    /// </summary>
    public partial class Receipt
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0700";
        public const string ImportEntityName = "PO0462";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"NEXTLSEQ", "NextLineSequence"},
                    {"LINES", "Lines"},
                    {"LINESPRORA", "NumberOfLinesProrated"},
                    {"LINESCMPL", "LinesComplete"},
                    {"COSTS", "Costs"},
                    {"COSTSPRORA", "NumberOfCostsProrated"},
                    {"COSTSCMPL", "CostsComplete"},
                    {"VENDS", "Vendors"},
                    {"VENDSCMPL", "VendorsCompleted"},
                    {"VENDSINVC", "VendorsInvoiced"},
                    {"TAXLINES", "LinesTaxCalculationSees"},
                    {"EXTRANEOUS", "ExtraneousLineCount"},
                    {"TAXAUTOCAL", "Autotaxcalculationonsave"},
                    {"ISPRINTED", "Printed"},
                    {"ISINVOICED", "Invoiced"},
                    {"ISCOMPLETE", "Completed"},
                    {"DTCOMPLETE", "DateCompleted"},
                    {"POSTDATE", "LastPostingDate"},
                    {"FISCYEAR", "FiscalYear"},
                    {"FISCPERIOD", "FiscalPeriod"},
                    {"RCPNUMBER", "ReceiptNumber"},
                    {"TEMPLATE", "TemplateCode"},
                    {"FOBPOINT", "FobPoint"},
                    {"VDCODE", "Vendor"},
                    {"VDEXISTS", "VendorExists"},
                    {"VDNAME", "Name"},
                    {"VDADDRESS1", "Address1"},
                    {"VDADDRESS2", "Address2"},
                    {"VDADDRESS3", "Address3"},
                    {"VDADDRESS4", "Address4"},
                    {"VDCITY", "City"},
                    {"VDSTATE", "StateProvince"},
                    {"VDZIP", "ZipPostalCode"},
                    {"VDCOUNTRY", "Country"},
                    {"VDPHONE", "PhoneNumber"},
                    {"VDFAX", "FaxNumber"},
                    {"VDCONTACT", "Contact"},
                    {"TERMSCODE", "TermsCode"},
                    {"PORHSEQ", "PurchaseOrderSequenceKey"},
                    {"PONUMBER", "PurchaseOrderNumber"},
                    {"INVNUMBER", "InvoiceNumber"},
                    {"DESCRIPTIO", "Description"},
                    {"REFERENCE", "Reference"},
                    {"COMMENT", "Comment"},
                    {"VIACODE", "ShipVia"},
                    {"VIANAME", "ShipViaName"},
                    {"CURRENCY", "Currency"},
                    {"VDEMAIL", "Email"},
                    {"VDPHONEC", "ContactPhone"},
                    {"VDFAXC", "ContactFax"},
                    {"VDEMAILC", "ContactEmail"},
                    {"BTCODE", "BillToLocation"},
                    {"BTDESC", "BillToLocationDescription"},
                    {"BTADDRESS1", "BillToAddress1"},
                    {"BTADDRESS2", "BillToAddress2"},
                    {"BTADDRESS3", "BillToAddress3"},
                    {"BTADDRESS4", "BillToAddress4"},
                    {"BTCITY", "BillToCity"},
                    {"BTSTATE", "BillToStateProvince"},
                    {"BTZIP", "BillToZipPostalCode"},
                    {"BTCOUNTRY", "BillToCountry"},
                    {"BTPHONE", "BillToPhoneNumber"},
                    {"BTFAX", "BillToFaxNumber"},
                    {"BTCONTACT", "BillToContact"},
                    {"STCODE", "ShipToLocation"},
                    {"STDESC", "ShipToLocationDescription"},
                    {"STADDRESS1", "ShipToAddress1"},
                    {"STADDRESS2", "ShipToAddress2"},
                    {"STADDRESS3", "ShipToAddress3"},
                    {"STADDRESS4", "ShipToAddress4"},
                    {"STCITY", "ShipToCity"},
                    {"STSTATE", "ShipToStateProvince"},
                    {"STZIP", "ShipToZipPostalCode"},
                    {"STCOUNTRY", "ShipToCountry"},
                    {"STPHONE", "ShipToPhoneNumber"},
                    {"STFAX", "ShipToFaxNumber"},
                    {"STCONTACT", "ShipToContact"},
                    {"BTEMAIL", "BillToEmail"},
                    {"BTPHONEC", "BillToContactPhone"},
                    {"BTFAXC", "BillToContactFax"},
                    {"BTEMAILC", "BillToContactEmail"},
                    {"STEMAIL", "ShipToEmail"},
                    {"STPHONEC", "ShipToContactPhone"},
                    {"STFAXC", "ShipToContactFax"},
                    {"STEMAILC", "ShipToContactEmail"},
                    {"TAXGROUP", "TaxGroup"},
                   
                    {"TXBASEALLO", "NetOfTax"},
                    {"TXINCLUDED", "TaxIncluded"},
                    {"TXEXCLUDED", "TaxExcluded"},
                    {"TAXAMOUNT", "TotalTax"},
                    {"TXRECVAMT", "TotalTaxRecoverable"},
                    {"TXEXPSAMT", "TotalTaxExpensed"},
                    {"TXALLOAMT", "TXALLOAMT"},
                    {"CURRENCYD", "CurrencyDescription"},
                    {"RATE", "ExchangeRate"},
                    {"RATETYPE", "RateType"},
                    {"RATEDATE", "RateDate"},
                    {"EXTWEIGHT", "ExtendedWeight"},
                    {"EXTENDED", "ExtendedCost"},
                    {"DOCTOTAL", "Total"},
                    {"AMOUNT", "AdditionalCosts"},
                    {"RQRECEIVED", "QuantityReceived"},
                    {"MPRORATED", "ManualProrationTotal"},
                    {"MTOPRORATE", "ManualToProrate"},
                    {"DISCPCT", "DiscountPercentage"},
                    {"DISCOUNT", "DiscountAmount"},
                    {"PDRATE", "PredecessorsExchangeRate"},
                    {"PDRATETYPE", "PredecessorsRateType"},
                    {"PDRATEDATE", "PredecessorsRateDate"},
                    {"RATETYPED", "RateTypeDescription"},
                    {"PDRATETYPD", "PredecessorsRateTypeDescript"},
                    {"UBALPRORAT", "UnbalancedManualProrationAmt"},
                    {"SUBTOTAL", "Subtotal"},
                    {"TRCURRENCY", "TaxReportingCurrency"},
                    {"RATERC", "TaxReportingExchangeRate"},
                    {"NETXTENDED", "NetExtendedCost"},
                    {"RATETYPERC", "TaxReportingRateType"},
                    {"RATEDATERC", "TaxReportingRateDate"},
                    {"PDRATERC", "PredTaxReportingExchRate"},
                    {"PDRATTYPRC", "PredTaxReportingRateType"},
                    {"PDRATEDTRC", "PredTaxReportingRateDate"},
                    {"TRCURRDESC", "TaxReportingCurrencyDesc"},
                    {"RATETYPRCD", "TaxReportingRateTypeDesc"},
                    {"PDRATTPRCD", "PredTaxRepRateTypeDesc"},
                    {"VALUES", "OptionalFields"},
                    {"MULTIPOR", "MultiplePurchaseOrders"},
                    {"PORS", "PurchaseOrders"},
                    {"VERPRORATE", "ProrationVersion"},
                    {"LASTRECEIP", "LastReceiptNumber"},
                    {"RCPDATE", "RCPDATE"},
                    {"RCPCOUNT", "NumberOfPostedReceipts"},
                    {"TAXGROUPD", "TaxGroupDescription"},
                    {"TERMSCODED", "TermsCodeDescription"},
                    {"SCURNDECML", "DecimalPlaces"},
                    {"TCBASEALLO", "NetOfTaxSum"},
                    {"TCINCLUDED", "TCINCLUDED"},
                    {"TCEXCLUDED", "TCEXCLUDED"},
                    {"LOCKED", "DocumentLocked"},
                    {"RATEEXISTS", "ExchangeRateExists"},
                    {"HASDETAILS", "HasDetails"},
                    {"VDACCTSET", "VendorAccountSet"},
                    {"VDACCTDESC", "VendorAccountSetDescription"},
                    {"DATEBUS", "PostingDate"},
                    {"ENTEREDBY", "EnteredBy"},

                    {"TARAMOUNT", "TaxReportingTotalAmount"},
                    {"TRINCLUDED", "TaxReportingIncludedAmount"},
                    {"TREXCLUDED", "TaxReportingExcludedAmount"},
                    {"TRRECVAMT", "TaxReportingRecoverableAmount"},
                    {"TREXPSAMT", "TaxReportingExpensedAmount"},
                    {"TRALLOAMT", "TaxReportingAllocatedAmount"},
                    {"DETAILNEXT", "NextDetailNumber"},
                    {"DATE", "ReceiptDate"},
                    {"HASJOB", "JobRelated"},
                    {"HASRTG", "HasRetainage"},
                    {"RAXAMOUNT", "RetainageTaxTotalAmount"},
                    {"RTGAMOUNT", "RetainageAmount"},
                    {"RTGRATE", "RetainageExchangeRate"},
                    {"RTGTERMS", "RetainageTermsCode"},
                    {"RTGTERMSD", "RetainageTermsCodeDescription"}
                };
            }
        }

        #endregion DynamicAttributes

        #region Fields Properties

        /// <summary>
        /// Contains list of Receipt Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for NextLineSequence
            /// </summary>
            public const string NextLineSequence = "NEXTLSEQ";

            /// <summary>
            /// Property for Lines
            /// </summary>
            public const string Lines = "LINES";

            /// <summary>
            /// Property for NumberOfLinesProrated
            /// </summary>
            public const string NumberOfLinesProrated = "LINESPRORA";

            /// <summary>
            /// Property for LinesComplete
            /// </summary>
            public const string LinesComplete = "LINESCMPL";

            /// <summary>
            /// Property for Costs
            /// </summary>
            public const string Costs = "COSTS";

            /// <summary>
            /// Property for NumberOfCostsProrated
            /// </summary>
            public const string NumberOfCostsProrated = "COSTSPRORA";

            /// <summary>
            /// Property for CostsComplete
            /// </summary>
            public const string CostsComplete = "COSTSCMPL";

            /// <summary>
            /// Property for Vendors
            /// </summary>
            public const string Vendors = "VENDS";

            /// <summary>
            /// Property for VendorsCompleted
            /// </summary>
            public const string VendorsCompleted = "VENDSCMPL";

            /// <summary>
            /// Property for VendorsInvoiced
            /// </summary>
            public const string VendorsInvoiced = "VENDSINVC";

            /// <summary>
            /// Property for LinesTaxCalculationSees
            /// </summary>
            public const string LinesTaxCalculationSees = "TAXLINES";

            /// <summary>
            /// Property for ExtraneousLineCount
            /// </summary>
            public const string ExtraneousLineCount = "EXTRANEOUS";

            /// <summary>
            /// Property for AutoTaxCalculationOnSave
            /// </summary>
            public const string AutoTaxCalculationOnSave = "TAXAUTOCAL";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "ISPRINTED";

            /// <summary>
            /// Property for Invoiced
            /// </summary>
            public const string Invoiced = "ISINVOICED";

            /// <summary>
            /// Property for Completed
            /// </summary>
            public const string Completed = "ISCOMPLETE";

            /// <summary>
            /// Property for DateCompleted
            /// </summary>
            public const string DateCompleted = "DTCOMPLETE";

            /// <summary>
            /// Property for LastPostingDate
            /// </summary>
            public const string LastPostingDate = "POSTDATE";

            /// <summary>
            /// Property for ReceiptDate
            /// </summary>
            public const string ReceiptDate = "DATE";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for ReceiptNumber
            /// </summary>
            public const string ReceiptNumber = "RCPNUMBER";

            /// <summary>
            /// Property for TemplateCode
            /// </summary>
            public const string TemplateCode = "TEMPLATE";

            /// <summary>
            /// Property for FOBPoint
            /// </summary>
            public const string FobPoint = "FOBPOINT";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VDCODE";

            /// <summary>
            /// Property for VendorExists
            /// </summary>
            public const string VendorExists = "VDEXISTS";

            /// <summary>
            /// Property for Name
            /// </summary>
            public const string Name = "VDNAME";

            /// <summary>
            /// Property for Address1
            /// </summary>
            public const string Address1 = "VDADDRESS1";

            /// <summary>
            /// Property for Address2
            /// </summary>
            public const string Address2 = "VDADDRESS2";

            /// <summary>
            /// Property for Address3
            /// </summary>
            public const string Address3 = "VDADDRESS3";

            /// <summary>
            /// Property for Address4
            /// </summary>
            public const string Address4 = "VDADDRESS4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "VDCITY";

            /// <summary>
            /// Property for StateProvince
            /// </summary>
            public const string StateProvince = "VDSTATE";

            /// <summary>
            /// Property for ZipPostalCode
            /// </summary>
            public const string ZipPostalCode = "VDZIP";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "VDCOUNTRY";

            /// <summary>
            /// Property for PhoneNumber
            /// </summary>
            public const string PhoneNumber = "VDPHONE";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "VDFAX";

            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "VDCONTACT";

            /// <summary>
            /// Property for TermsCode
            /// </summary>
            public const string TermsCode = "TERMSCODE";

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for InvoiceNumber
            /// </summary>
            public const string InvoiceNumber = "INVNUMBER";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESCRIPTIO";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for ShipVia
            /// </summary>
            public const string ShipVia = "VIACODE";

            /// <summary>
            /// Property for ShipViaName
            /// </summary>
            public const string ShipViaName = "VIANAME";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateSpread
            /// </summary>
            public const string RateSpread = "SPREAD";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for RateMatchType
            /// </summary>
            public const string RateMatchType = "RATEMATCH";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperation
            /// </summary>
            public const string RateOperation = "RATEOPER";

            /// <summary>
            /// Property for RateOverridden
            /// </summary>
            public const string RateOverridden = "RATEOVER";

            /// <summary>
            /// Property for DecimalPlaces
            /// </summary>
            public const string DecimalPlaces = "SCURNDECML";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTENDED";

            /// <summary>
            /// Property for Total
            /// </summary>
            public const string Total = "DOCTOTAL";

            /// <summary>
            /// Property for AdditionalCosts
            /// </summary>
            public const string AdditionalCosts = "AMOUNT";

            /// <summary>
            /// Property for QuantityReceived
            /// </summary>
            public const string QuantityReceived = "RQRECEIVED";

            /// <summary>
            /// Property for TaxGroup
            /// </summary>
            public const string TaxGroup = "TAXGROUP";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAXAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAXAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAXAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAXAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAXAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxBase1
            /// </summary>
            public const string TaxBase1 = "TAXBASE1";

            /// <summary>
            /// Property for TaxBase2
            /// </summary>
            public const string TaxBase2 = "TAXBASE2";

            /// <summary>
            /// Property for TaxBase3
            /// </summary>
            public const string TaxBase3 = "TAXBASE3";

            /// <summary>
            /// Property for TaxBase4
            /// </summary>
            public const string TaxBase4 = "TAXBASE4";

            /// <summary>
            /// Property for TaxBase5
            /// </summary>
            public const string TaxBase5 = "TAXBASE5";

            /// <summary>
            /// Property for IncludedTaxAmount1
            /// </summary>
            public const string IncludedTaxAmount1 = "TXINCLUDE1";

            /// <summary>
            /// Property for IncludedTaxAmount2
            /// </summary>
            public const string IncludedTaxAmount2 = "TXINCLUDE2";

            /// <summary>
            /// Property for IncludedTaxAmount3
            /// </summary>
            public const string IncludedTaxAmount3 = "TXINCLUDE3";

            /// <summary>
            /// Property for IncludedTaxAmount4
            /// </summary>
            public const string IncludedTaxAmount4 = "TXINCLUDE4";

            /// <summary>
            /// Property for IncludedTaxAmount5
            /// </summary>
            public const string IncludedTaxAmount5 = "TXINCLUDE5";

            /// <summary>
            /// Property for ExcludedTaxAmount1
            /// </summary>
            public const string ExcludedTaxAmount1 = "TXEXCLUDE1";

            /// <summary>
            /// Property for ExcludedTaxAmount2
            /// </summary>
            public const string ExcludedTaxAmount2 = "TXEXCLUDE2";

            /// <summary>
            /// Property for ExcludedTaxAmount3
            /// </summary>
            public const string ExcludedTaxAmount3 = "TXEXCLUDE3";

            /// <summary>
            /// Property for ExcludedTaxAmount4
            /// </summary>
            public const string ExcludedTaxAmount4 = "TXEXCLUDE4";

            /// <summary>
            /// Property for ExcludedTaxAmount5
            /// </summary>
            public const string ExcludedTaxAmount5 = "TXEXCLUDE5";

            /// <summary>
            /// Property for TaxAmount1
            /// </summary>
            public const string TaxAmount1 = "TAXAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2
            /// </summary>
            public const string TaxAmount2 = "TAXAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3
            /// </summary>
            public const string TaxAmount3 = "TAXAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4
            /// </summary>
            public const string TaxAmount4 = "TAXAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5
            /// </summary>
            public const string TaxAmount5 = "TAXAMOUNT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1
            /// </summary>
            public const string TaxRecoverableAmount1 = "TXRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2
            /// </summary>
            public const string TaxRecoverableAmount2 = "TXRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3
            /// </summary>
            public const string TaxRecoverableAmount3 = "TXRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4
            /// </summary>
            public const string TaxRecoverableAmount4 = "TXRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5
            /// </summary>
            public const string TaxRecoverableAmount5 = "TXRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1
            /// </summary>
            public const string TaxExpenseAmount1 = "TXEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2
            /// </summary>
            public const string TaxExpenseAmount2 = "TXEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3
            /// </summary>
            public const string TaxExpenseAmount3 = "TXEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4
            /// </summary>
            public const string TaxExpenseAmount4 = "TXEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5
            /// </summary>
            public const string TaxExpenseAmount5 = "TXEXPSAMT5";

            /// <summary>
            /// Property for TaxAllocatedAmount1
            /// </summary>
            public const string TaxAllocatedAmount1 = "TXALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2
            /// </summary>
            public const string TaxAllocatedAmount2 = "TXALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3
            /// </summary>
            public const string TaxAllocatedAmount3 = "TXALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4
            /// </summary>
            public const string TaxAllocatedAmount4 = "TXALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5
            /// </summary>
            public const string TaxAllocatedAmount5 = "TXALLOAMT5";

            /// <summary>
            /// Property for NetOfTax
            /// </summary>
            public const string NetOfTax = "TXBASEALLO";

            /// <summary>
            /// Property for TaxIncluded
            /// </summary>
            public const string TaxIncluded = "TXINCLUDED";

            /// <summary>
            /// Property for TaxExcluded
            /// </summary>
            public const string TaxExcluded = "TXEXCLUDED";

            /// <summary>
            /// Property for TotalTax
            /// </summary>
            public const string TotalTax = "TAXAMOUNT";

            /// <summary>
            /// Property for TotalTaxRecoverable
            /// </summary>
            public const string TotalTaxRecoverable = "TXRECVAMT";

            /// <summary>
            /// Property for TotalTaxExpensed
            /// </summary>
            public const string TotalTaxExpensed = "TXEXPSAMT";

            /// <summary>
            /// Property for TotalTaxAllocated
            /// </summary>
            public const string TotalTaxAllocated = "TXALLOAMT";

            /// <summary>
            /// Property for ManualProrationTotal
            /// </summary>
            public const string ManualProrationTotal = "MPRORATED";

            /// <summary>
            /// Property for ManualToProrate
            /// </summary>
            public const string ManualToProrate = "MTOPRORATE";

            /// <summary>
            /// Property for ConversionSourceAmount
            /// </summary>
            public const string ConversionSourceAmount = "SCAMOUNT";

            /// <summary>
            /// Property for ConversionFunctionalAmount
            /// </summary>
            public const string ConversionFunctionalAmount = "FCAMOUNT";

            /// <summary>
            /// Property for MultiplePurchaseOrders
            /// </summary>
            public const string MultiplePurchaseOrders = "MULTIPOR";

            /// <summary>
            /// Property for PurchaseOrders
            /// </summary>
            public const string PurchaseOrders = "PORS";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "VDEMAIL";

            /// <summary>
            /// Property for ContactPhone
            /// </summary>
            public const string ContactPhone = "VDPHONEC";

            /// <summary>
            /// Property for ContactFax
            /// </summary>
            public const string ContactFax = "VDFAXC";

            /// <summary>
            /// Property for ContactEmail
            /// </summary>
            public const string ContactEmail = "VDEMAILC";

            /// <summary>
            /// Property for DiscountPercentage
            /// </summary>
            public const string DiscountPercentage = "DISCPCT";

            /// <summary>
            /// Property for DiscountAmount
            /// </summary>
            public const string DiscountAmount = "DISCOUNT";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for ProrationVersion
            /// </summary>
            public const string ProrationVersion = "VERPRORATE";

            /// <summary>
            /// Property for HasRetainage
            /// </summary>
            public const string HasRetainage = "HASRTG";

            /// <summary>
            /// Property for RetainageExchangeRate
            /// </summary>
            public const string RetainageExchangeRate = "RTGRATE";

            /// <summary>
            /// Property for BillToLocation
            /// </summary>
            public const string BillToLocation = "BTCODE";

            /// <summary>
            /// Property for BillToLocationDescription
            /// </summary>
            public const string BillToLocationDescription = "BTDESC";

            /// <summary>
            /// Property for BillToAddress1
            /// </summary>
            public const string BillToAddress1 = "BTADDRESS1";

            /// <summary>
            /// Property for BillToAddress2
            /// </summary>
            public const string BillToAddress2 = "BTADDRESS2";

            /// <summary>
            /// Property for BillToAddress3
            /// </summary>
            public const string BillToAddress3 = "BTADDRESS3";

            /// <summary>
            /// Property for BillToAddress4
            /// </summary>
            public const string BillToAddress4 = "BTADDRESS4";

            /// <summary>
            /// Property for BillToCity
            /// </summary>
            public const string BillToCity = "BTCITY";

            /// <summary>
            /// Property for BillToStateProvince
            /// </summary>
            public const string BillToStateProvince = "BTSTATE";

            /// <summary>
            /// Property for BillToZipPostalCode
            /// </summary>
            public const string BillToZipPostalCode = "BTZIP";

            /// <summary>
            /// Property for BillToCountry
            /// </summary>
            public const string BillToCountry = "BTCOUNTRY";

            /// <summary>
            /// Property for BillToPhoneNumber
            /// </summary>
            public const string BillToPhoneNumber = "BTPHONE";

            /// <summary>
            /// Property for BillToFaxNumber
            /// </summary>
            public const string BillToFaxNumber = "BTFAX";

            /// <summary>
            /// Property for BillToContact
            /// </summary>
            public const string BillToContact = "BTCONTACT";

            /// <summary>
            /// Property for ShipToLocation
            /// </summary>
            public const string ShipToLocation = "STCODE";

            /// <summary>
            /// Property for ShipToLocationDescription
            /// </summary>
            public const string ShipToLocationDescription = "STDESC";

            /// <summary>
            /// Property for ShipToAddress1
            /// </summary>
            public const string ShipToAddress1 = "STADDRESS1";

            /// <summary>
            /// Property for ShipToAddress2
            /// </summary>
            public const string ShipToAddress2 = "STADDRESS2";

            /// <summary>
            /// Property for ShipToAddress3
            /// </summary>
            public const string ShipToAddress3 = "STADDRESS3";

            /// <summary>
            /// Property for ShipToAddress4
            /// </summary>
            public const string ShipToAddress4 = "STADDRESS4";

            /// <summary>
            /// Property for ShipToCity
            /// </summary>
            public const string ShipToCity = "STCITY";

            /// <summary>
            /// Property for ShipToStateProvince
            /// </summary>
            public const string ShipToStateProvince = "STSTATE";

            /// <summary>
            /// Property for ShipToZipPostalCode
            /// </summary>
            public const string ShipToZipPostalCode = "STZIP";

            /// <summary>
            /// Property for ShipToCountry
            /// </summary>
            public const string ShipToCountry = "STCOUNTRY";

            /// <summary>
            /// Property for ShipToPhoneNumber
            /// </summary>
            public const string ShipToPhoneNumber = "STPHONE";

            /// <summary>
            /// Property for ShipToFaxNumber
            /// </summary>
            public const string ShipToFaxNumber = "STFAX";

            /// <summary>
            /// Property for ShipToContact
            /// </summary>
            public const string ShipToContact = "STCONTACT";

            /// <summary>
            /// Property for PredecessorsExchangeRate
            /// </summary>
            public const string PredecessorsExchangeRate = "PDRATE";

            /// <summary>
            /// Property for PredecessorsRateType
            /// </summary>
            public const string PredecessorsRateType = "PDRATETYPE";

            /// <summary>
            /// Property for PredecessorsRateDate
            /// </summary>
            public const string PredecessorsRateDate = "PDRATEDATE";

            /// <summary>
            /// Property for PredecessorsRateOperation
            /// </summary>
            public const string PredecessorsRateOperation = "PDRATEOPER";

            /// <summary>
            /// Property for PredecessorsRateOverridden
            /// </summary>
            public const string PredecessorsRateOverridden = "PDRATEOVER";

            /// <summary>
            /// Property for BillToEmail
            /// </summary>
            public const string BillToEmail = "BTEMAIL";

            /// <summary>
            /// Property for BillToContactPhone
            /// </summary>
            public const string BillToContactPhone = "BTPHONEC";

            /// <summary>
            /// Property for BillToContactFax
            /// </summary>
            public const string BillToContactFax = "BTFAXC";

            /// <summary>
            /// Property for BillToContactEmail
            /// </summary>
            public const string BillToContactEmail = "BTEMAILC";

            /// <summary>
            /// Property for ShipToEmail
            /// </summary>
            public const string ShipToEmail = "STEMAIL";

            /// <summary>
            /// Property for ShipToContactPhone
            /// </summary>
            public const string ShipToContactPhone = "STPHONEC";

            /// <summary>
            /// Property for ShipToContactFax
            /// </summary>
            public const string ShipToContactFax = "STFAXC";

            /// <summary>
            /// Property for ShipToContactEmail
            /// </summary>
            public const string ShipToContactEmail = "STEMAILC";

            /// <summary>
            /// Property for TaxClass1Description
            /// </summary>
            public const string TaxClass1Description = "TAXCLASS1D";

            /// <summary>
            /// Property for TaxClass2Description
            /// </summary>
            public const string TaxClass2Description = "TAXCLASS2D";

            /// <summary>
            /// Property for TaxClass3Description
            /// </summary>
            public const string TaxClass3Description = "TAXCLASS3D";

            /// <summary>
            /// Property for TaxClass4Description
            /// </summary>
            public const string TaxClass4Description = "TAXCLASS4D";

            /// <summary>
            /// Property for TaxClass5Description
            /// </summary>
            public const string TaxClass5Description = "TAXCLASS5D";

            /// <summary>
            /// Property for TaxAuthority1Description
            /// </summary>
            public const string TaxAuthority1Description = "TAXAUTH1D";

            /// <summary>
            /// Property for TaxAuthority2Description
            /// </summary>
            public const string TaxAuthority2Description = "TAXAUTH2D";

            /// <summary>
            /// Property for TaxAuthority3Description
            /// </summary>
            public const string TaxAuthority3Description = "TAXAUTH3D";

            /// <summary>
            /// Property for TaxAuthority4Description
            /// </summary>
            public const string TaxAuthority4Description = "TAXAUTH4D";

            /// <summary>
            /// Property for TaxAuthority5Description
            /// </summary>
            public const string TaxAuthority5Description = "TAXAUTH5D";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "CURRENCYD";

            /// <summary>
            /// Property for RateTypeDescription
            /// </summary>
            public const string RateTypeDescription = "RATETYPED";

            /// <summary>
            /// Property for LastReceiptNumber
            /// </summary>
            public const string LastReceiptNumber = "LASTRECEIP";

            /// <summary>
            /// Property for RcpDate
            /// </summary>
            public const string RcpDate = "RCPDATE";

            /// <summary>
            /// Property for NumberOfPostedReceipts
            /// </summary>
            public const string NumberOfPostedReceipts = "RCPCOUNT";

            /// <summary>
            /// Property for TaxGroupDescription
            /// </summary>
            public const string TaxGroupDescription = "TAXGROUPD";

            /// <summary>
            /// Property for TermsCodeDescription
            /// </summary>
            public const string TermsCodeDescription = "TERMSCODED";

            /// <summary>
            /// Property for PredecessorsRateTypeDesc
            /// </summary>
            public const string PredecessorsRateTypeDesc = "PDRATETYPD";

            /// <summary>
            /// Property for NetOfTaxSum
            /// </summary>
            public const string NetOfTaxSum = "TCBASEALLO";

            /// <summary>
            /// Property for TaxIncluded1Sum
            /// </summary>
            public const string TaxIncluded1Sum = "TCINCLUDE1";

            /// <summary>
            /// Property for TaxIncluded2Sum
            /// </summary>
            public const string TaxIncluded2Sum = "TCINCLUDE2";

            /// <summary>
            /// Property for TaxIncluded3Sum
            /// </summary>
            public const string TaxIncluded3Sum = "TCINCLUDE3";

            /// <summary>
            /// Property for TaxIncluded4Sum
            /// </summary>
            public const string TaxIncluded4Sum = "TCINCLUDE4";

            /// <summary>
            /// Property for TaxIncluded5Sum
            /// </summary>
            public const string TaxIncluded5Sum = "TCINCLUDE5";

            /// <summary>
            /// Property for TaxAllocatedAmount1Sum
            /// </summary>
            public const string TaxAllocatedAmount1Sum = "TCALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2Sum
            /// </summary>
            public const string TaxAllocatedAmount2Sum = "TCALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3Sum
            /// </summary>
            public const string TaxAllocatedAmount3Sum = "TCALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4Sum
            /// </summary>
            public const string TaxAllocatedAmount4Sum = "TCALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5Sum
            /// </summary>
            public const string TaxAllocatedAmount5Sum = "TCALLOAMT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1Sum
            /// </summary>
            public const string TaxRecoverableAmount1Sum = "TCRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2Sum
            /// </summary>
            public const string TaxRecoverableAmount2Sum = "TCRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3Sum
            /// </summary>
            public const string TaxRecoverableAmount3Sum = "TCRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4Sum
            /// </summary>
            public const string TaxRecoverableAmount4Sum = "TCRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5Sum
            /// </summary>
            public const string TaxRecoverableAmount5Sum = "TCRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1Sum
            /// </summary>
            public const string TaxExpenseAmount1Sum = "TCEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2Sum
            /// </summary>
            public const string TaxExpenseAmount2Sum = "TCEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3Sum
            /// </summary>
            public const string TaxExpenseAmount3Sum = "TCEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4Sum
            /// </summary>
            public const string TaxExpenseAmount4Sum = "TCEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5Sum
            /// </summary>
            public const string TaxExpenseAmount5Sum = "TCEXPSAMT5";

            /// <summary>
            /// Property for TotalTaxAllocated1
            /// </summary>
            public const string TotalTaxAllocated1 = "TCALLOAMT";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TCINCLUDED";

            /// <summary>
            /// Property for TaxExcluded1
            /// </summary>
            public const string TaxExcluded1 = "TCEXCLUDED";

            /// <summary>
            /// Property for TotalUnbalancedTax
            /// </summary>
            public const string TotalUnbalancedTax = "UBALTAXAMT";

            /// <summary>
            /// Property for TotalUnbalancedAllocatedTax
            /// </summary>
            public const string TotalUnbalancedAllocatedTax = "UBALTXALLO";

            /// <summary>
            /// Property for UnbalancedManualProrationAmt
            /// </summary>
            public const string UnbalancedManualProrationAmt = "UBALPRORAT";

            /// <summary>
            /// Property for Subtotal
            /// </summary>
            public const string Subtotal = "SUBTOTAL";

            /// <summary>
            /// Property for TaxcalculationIspending
            /// </summary>
            public const string TaxcalculationIspending = "PENDINGCAL";

            /// <summary>
            /// Property for DocumentLocked
            /// </summary>
            public const string DocumentLocked = "LOCKED";

            /// <summary>
            /// Property for IsDocumentDeletable
            /// </summary>
            public const string IsDocumentDeletable = "CANDELETE";

            /// <summary>
            /// Property for ExchangeRateExists
            /// </summary>
            public const string ExchangeRateExists = "RATEEXISTS";

            /// <summary>
            /// Property for HasDetails
            /// </summary>
            public const string HasDetails = "HASDETAILS";

            /// <summary>
            /// Property for DiscountAmountSum
            /// </summary>
            public const string DiscountAmountSum = "DISCOUNTC";

            /// <summary>
            /// Property for NetExtendedCost
            /// </summary>
            public const string NetExtendedCost = "NETXTENDED";

            /// <summary>
            /// Property for DayEndNumber
            /// </summary>
            public const string DayEndNumber = "POSTSEQNUM";

            /// <summary>
            /// Property for RetainageTermsCode
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";

            /// <summary>
            /// Property for JobRelatedLines
            /// </summary>
            public const string JobRelatedLines = "JOBLINES";

            /// <summary>
            /// Property for JobRelatedCosts
            /// </summary>
            public const string JobRelatedCosts = "JOBCOSTS";

            /// <summary>
            /// Property for BillableLines
            /// </summary>
            public const string BillableLines = "BILLLINES";

            /// <summary>
            /// Property for CostBillingRatesProrated
            /// </summary>
            public const string CostBillingRatesProrated = "COSTSBLPRO";

            /// <summary>
            /// Property for Command
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for RetainageTermsCodeDescription
            /// </summary>
            public const string RetainageTermsCodeDescription = "RTGTERMSD";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "HASJOB";

            /// <summary>
            /// Property for RetainageBase
            /// </summary>
            public const string RetainageBase = "RTGBASE";

            /// <summary>
            /// Property for RetainageAmount
            /// </summary>
            public const string RetainageAmount = "RTGAMOUNT";

            /// <summary>
            /// Property for UnretainedTotal
            /// </summary>
            public const string UnretainedTotal = "URTDTOTAL";

            /// <summary>
            /// Property for TaxReportingCurrency
            /// </summary>
            public const string TaxReportingCurrency = "TRCURRENCY";

            /// <summary>
            /// Property for TaxReportingExchangeRate
            /// </summary>
            public const string TaxReportingExchangeRate = "RATERC";

            /// <summary>
            /// Property for TaxReportingRateSpread
            /// </summary>
            public const string TaxReportingRateSpread = "SPREADRC";

            /// <summary>
            /// Property for TaxReportingRateType
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";

            /// <summary>
            /// Property for TaxReportingRateMatchType
            /// </summary>
            public const string TaxReportingRateMatchType = "RATEMTCHRC";

            /// <summary>
            /// Property for TaxReportingRateDate
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";

            /// <summary>
            /// Property for TaxReportingRateOperation
            /// </summary>
            public const string TaxReportingRateOperation = "RATEOPERRC";

            /// <summary>
            /// Property for TaxReportingRateOverridden
            /// </summary>
            public const string TaxReportingRateOverridden = "RATERCOVER";

            /// <summary>
            /// Property for TaxReportingDecimalPlaces
            /// </summary>
            public const string TaxReportingDecimalPlaces = "RCURNDECML";

            /// <summary>
            /// Property for TaxReportingAmount1
            /// </summary>
            public const string TaxReportingAmount1 = "TARAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2
            /// </summary>
            public const string TaxReportingAmount2 = "TARAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3
            /// </summary>
            public const string TaxReportingAmount3 = "TARAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4
            /// </summary>
            public const string TaxReportingAmount4 = "TARAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5
            /// </summary>
            public const string TaxReportingAmount5 = "TARAMOUNT5";

            /// <summary>
            /// Property for TaxReportingIncludedAmount1
            /// </summary>
            public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncludedAmount2
            /// </summary>
            public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncludedAmount3
            /// </summary>
            public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncludedAmount4
            /// </summary>
            public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncludedAmount5
            /// </summary>
            public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcludedAmount1
            /// </summary>
            public const string TaxReportingExcludedAmount1 = "TREXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcludedAmount2
            /// </summary>
            public const string TaxReportingExcludedAmount2 = "TREXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcludedAmount3
            /// </summary>
            public const string TaxReportingExcludedAmount3 = "TREXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcludedAmount4
            /// </summary>
            public const string TaxReportingExcludedAmount4 = "TREXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcludedAmount5
            /// </summary>
            public const string TaxReportingExcludedAmount5 = "TREXCLUDE5";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt1
            /// </summary>
            public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt2
            /// </summary>
            public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt3
            /// </summary>
            public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt4
            /// </summary>
            public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt5
            /// </summary>
            public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

            /// <summary>
            /// Property for TaxReportingExpenseAmount1
            /// </summary>
            public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

            /// <summary>
            /// Property for TaxReportingExpenseAmount2
            /// </summary>
            public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

            /// <summary>
            /// Property for TaxReportingExpenseAmount3
            /// </summary>
            public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

            /// <summary>
            /// Property for TaxReportingExpenseAmount4
            /// </summary>
            public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

            /// <summary>
            /// Property for TaxReportingExpenseAmount5
            /// </summary>
            public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount1
            /// </summary>
            public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount2
            /// </summary>
            public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount3
            /// </summary>
            public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount4
            /// </summary>
            public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount5
            /// </summary>
            public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

            /// <summary>
            /// Property for PredTaxReportingExchRate
            /// </summary>
            public const string PredTaxReportingExchRate = "PDRATERC";

            /// <summary>
            /// Property for PredTaxReportingRateType
            /// </summary>
            public const string PredTaxReportingRateType = "PDRATTYPRC";

            /// <summary>
            /// Property for PredTaxReportingRateDate
            /// </summary>
            public const string PredTaxReportingRateDate = "PDRATEDTRC";

            /// <summary>
            /// Property for PredTaxReportingRateOper
            /// </summary>
            public const string PredTaxReportingRateOper = "PDRATEOPRC";

            /// <summary>
            /// Property for PredTaxReportingRateOverrd
            /// </summary>
            public const string PredTaxReportingRateOverrd = "PDRATERCOV";

            /// <summary>
            /// Property for TaxReportingExchRateExists
            /// </summary>
            public const string TaxReportingExchRateExists = "RATERCEXST";

            /// <summary>
            /// Property for DerivedTaxReportingExchRate
            /// </summary>
            public const string DerivedTaxReportingExchRate = "RATERCC";

            /// <summary>
            /// Property for TaxReportingCurrencyDesc
            /// </summary>
            public const string TaxReportingCurrencyDesc = "TRCURRDESC";

            /// <summary>
            /// Property for TaxReportingRateTypeDesc
            /// </summary>
            public const string TaxReportingRateTypeDesc = "RATETYPRCD";

            /// <summary>
            /// Property for PredTaxRepRateTypeDesc
            /// </summary>
            public const string PredTaxRepRateTypeDesc = "PDRATTPRCD";

            /// <summary>
            /// Property for TaxReportingTotalAmount
            /// </summary>
            public const string TaxReportingTotalAmount = "TARAMOUNT";

            /// <summary>
            /// Property for TaxReportingIncludedAmount
            /// </summary>
            public const string TaxReportingIncludedAmount = "TRINCLUDED";

            /// <summary>
            /// Property for TaxReportingExcludedAmount
            /// </summary>
            public const string TaxReportingExcludedAmount = "TREXCLUDED";

            /// <summary>
            /// Property for TaxReportingRecoverableAmount
            /// </summary>
            public const string TaxReportingRecoverableAmount = "TRRECVAMT";

            /// <summary>
            /// Property for TaxReportingExpensedAmount
            /// </summary>
            public const string TaxReportingExpensedAmount = "TREXPSAMT";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount
            /// </summary>
            public const string TaxReportingAllocatedAmount = "TRALLOAMT";

            /// <summary>
            /// Property for TaxBase1Sum
            /// </summary>
            public const string TaxBase1Sum = "TACBASE1";

            /// <summary>
            /// Property for TaxBase2Sum
            /// </summary>
            public const string TaxBase2Sum = "TACBASE2";

            /// <summary>
            /// Property for TaxBase3Sum
            /// </summary>
            public const string TaxBase3Sum = "TACBASE3";

            /// <summary>
            /// Property for TaxBase4Sum
            /// </summary>
            public const string TaxBase4Sum = "TACBASE4";

            /// <summary>
            /// Property for TaxBase5Sum
            /// </summary>
            public const string TaxBase5Sum = "TACBASE5";

            /// <summary>
            /// Property for TaxAmount1Sum
            /// </summary>
            public const string TaxAmount1Sum = "TACAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2Sum
            /// </summary>
            public const string TaxAmount2Sum = "TACAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3Sum
            /// </summary>
            public const string TaxAmount3Sum = "TACAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4Sum
            /// </summary>
            public const string TaxAmount4Sum = "TACAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5Sum
            /// </summary>
            public const string TaxAmount5Sum = "TACAMOUNT5";

            /// <summary>
            /// Property for TaxExcluded1Sum
            /// </summary>
            public const string TaxExcluded1Sum = "TCEXCLUDE1";

            /// <summary>
            /// Property for TaxExcluded2Sum
            /// </summary>
            public const string TaxExcluded2Sum = "TCEXCLUDE2";

            /// <summary>
            /// Property for TaxExcluded3Sum
            /// </summary>
            public const string TaxExcluded3Sum = "TCEXCLUDE3";

            /// <summary>
            /// Property for TaxExcluded4Sum
            /// </summary>
            public const string TaxExcluded4Sum = "TCEXCLUDE4";

            /// <summary>
            /// Property for TaxExcluded5Sum
            /// </summary>
            public const string TaxExcluded5Sum = "TCEXCLUDE5";

            /// <summary>
            /// Property for TaxReportingAmount1Sum
            /// </summary>
            public const string TaxReportingAmount1Sum = "TALAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2Sum
            /// </summary>
            public const string TaxReportingAmount2Sum = "TALAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3Sum
            /// </summary>
            public const string TaxReportingAmount3Sum = "TALAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4Sum
            /// </summary>
            public const string TaxReportingAmount4Sum = "TALAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5Sum
            /// </summary>
            public const string TaxReportingAmount5Sum = "TALAMOUNT5";

            /// <summary>
            /// Property for TaxReportingIncluded1Sum
            /// </summary>
            public const string TaxReportingIncluded1Sum = "TLINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncluded2Sum
            /// </summary>
            public const string TaxReportingIncluded2Sum = "TLINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncluded3Sum
            /// </summary>
            public const string TaxReportingIncluded3Sum = "TLINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncluded4Sum
            /// </summary>
            public const string TaxReportingIncluded4Sum = "TLINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncluded5Sum
            /// </summary>
            public const string TaxReportingIncluded5Sum = "TLINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcluded1Sum
            /// </summary>
            public const string TaxReportingExcluded1Sum = "TLEXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcluded2Sum
            /// </summary>
            public const string TaxReportingExcluded2Sum = "TLEXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcluded3Sum
            /// </summary>
            public const string TaxReportingExcluded3Sum = "TLEXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcluded4Sum
            /// </summary>
            public const string TaxReportingExcluded4Sum = "TLEXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcluded5Sum
            /// </summary>
            public const string TaxReportingExcluded5Sum = "TLEXCLUDE5";

            /// <summary>
            /// Property for TaxRepAllocatedAmount1Sum
            /// </summary>
            public const string TaxRepAllocatedAmount1Sum = "TLALLOAMT1";

            /// <summary>
            /// Property for TaxRepAllocatedAmount2Sum
            /// </summary>
            public const string TaxRepAllocatedAmount2Sum = "TLALLOAMT2";

            /// <summary>
            /// Property for TaxRepAllocatedAmount3Sum
            /// </summary>
            public const string TaxRepAllocatedAmount3Sum = "TLALLOAMT3";

            /// <summary>
            /// Property for TaxRepAllocatedAmount4Sum
            /// </summary>
            public const string TaxRepAllocatedAmount4Sum = "TLALLOAMT4";

            /// <summary>
            /// Property for TaxRepAllocatedAmount5Sum
            /// </summary>
            public const string TaxRepAllocatedAmount5Sum = "TLALLOAMT5";

            /// <summary>
            /// Property for TaxRepRecoverableAmt1Sum
            /// </summary>
            public const string TaxRepRecoverableAmt1Sum = "TLRECVAMT1";

            /// <summary>
            /// Property for TaxRepRecoverableAmt2Sum
            /// </summary>
            public const string TaxRepRecoverableAmt2Sum = "TLRECVAMT2";

            /// <summary>
            /// Property for TaxRepRecoverableAmt3Sum
            /// </summary>
            public const string TaxRepRecoverableAmt3Sum = "TLRECVAMT3";

            /// <summary>
            /// Property for TaxRepRecoverableAmt4Sum
            /// </summary>
            public const string TaxRepRecoverableAmt4Sum = "TLRECVAMT4";

            /// <summary>
            /// Property for TaxRepRecoverableAmt5Sum
            /// </summary>
            public const string TaxRepRecoverableAmt5Sum = "TLRECVAMT5";

            /// <summary>
            /// Property for TaxRepExpenseAmount1Sum
            /// </summary>
            public const string TaxRepExpenseAmount1Sum = "TLEXPSAMT1";

            /// <summary>
            /// Property for TaxRepExpenseAmount2Sum
            /// </summary>
            public const string TaxRepExpenseAmount2Sum = "TLEXPSAMT2";

            /// <summary>
            /// Property for TaxRepExpenseAmount3Sum
            /// </summary>
            public const string TaxRepExpenseAmount3Sum = "TLEXPSAMT3";

            /// <summary>
            /// Property for TaxRepExpenseAmount4Sum
            /// </summary>
            public const string TaxRepExpenseAmount4Sum = "TLEXPSAMT4";

            /// <summary>
            /// Property for TaxRepExpenseAmount5Sum
            /// </summary>
            public const string TaxRepExpenseAmount5Sum = "TLEXPSAMT5";

            /// <summary>
            /// Property for ReportRetainageTax
            /// </summary>
            public const string ReportRetainageTax = "RTGTAXREP";

            /// <summary>
            /// Property for RetainageTaxBase1
            /// </summary>
            public const string RetainageTaxBase1 = "RAXBASE1";

            /// <summary>
            /// Property for RetainageTaxBase2
            /// </summary>
            public const string RetainageTaxBase2 = "RAXBASE2";

            /// <summary>
            /// Property for RetainageTaxBase3
            /// </summary>
            public const string RetainageTaxBase3 = "RAXBASE3";

            /// <summary>
            /// Property for RetainageTaxBase4
            /// </summary>
            public const string RetainageTaxBase4 = "RAXBASE4";

            /// <summary>
            /// Property for RetainageTaxBase5
            /// </summary>
            public const string RetainageTaxBase5 = "RAXBASE5";

            /// <summary>
            /// Property for RetainageTaxAmount1
            /// </summary>
            public const string RetainageTaxAmount1 = "RAXAMOUNT1";

            /// <summary>
            /// Property for RetainageTaxAmount2
            /// </summary>
            public const string RetainageTaxAmount2 = "RAXAMOUNT2";

            /// <summary>
            /// Property for RetainageTaxAmount3
            /// </summary>
            public const string RetainageTaxAmount3 = "RAXAMOUNT3";

            /// <summary>
            /// Property for RetainageTaxAmount4
            /// </summary>
            public const string RetainageTaxAmount4 = "RAXAMOUNT4";

            /// <summary>
            /// Property for RetainageTaxAmount5
            /// </summary>
            public const string RetainageTaxAmount5 = "RAXAMOUNT5";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt1
            /// </summary>
            public const string RetainageTaxRecoverableAmt1 = "RXRECVAMT1";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt2
            /// </summary>
            public const string RetainageTaxRecoverableAmt2 = "RXRECVAMT2";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt3
            /// </summary>
            public const string RetainageTaxRecoverableAmt3 = "RXRECVAMT3";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt4
            /// </summary>
            public const string RetainageTaxRecoverableAmt4 = "RXRECVAMT4";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt5
            /// </summary>
            public const string RetainageTaxRecoverableAmt5 = "RXRECVAMT5";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount1
            /// </summary>
            public const string RetainageTaxExpenseAmount1 = "RXEXPSAMT1";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount2
            /// </summary>
            public const string RetainageTaxExpenseAmount2 = "RXEXPSAMT2";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount3
            /// </summary>
            public const string RetainageTaxExpenseAmount3 = "RXEXPSAMT3";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount4
            /// </summary>
            public const string RetainageTaxExpenseAmount4 = "RXEXPSAMT4";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount5
            /// </summary>
            public const string RetainageTaxExpenseAmount5 = "RXEXPSAMT5";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount1
            /// </summary>
            public const string RetainageTaxAllocatedAmount1 = "RXALLOAMT1";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount2
            /// </summary>
            public const string RetainageTaxAllocatedAmount2 = "RXALLOAMT2";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount3
            /// </summary>
            public const string RetainageTaxAllocatedAmount3 = "RXALLOAMT3";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount4
            /// </summary>
            public const string RetainageTaxAllocatedAmount4 = "RXALLOAMT4";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount5
            /// </summary>
            public const string RetainageTaxAllocatedAmount5 = "RXALLOAMT5";

            /// <summary>
            /// Property for WarnOnRetainageTaxShift
            /// </summary>
            public const string WarnOnRetainageTaxShift = "RTGTXSHIFT";

            /// <summary>
            /// Property for RetainageTaxTotalAmount
            /// </summary>
            public const string RetainageTaxTotalAmount = "RAXAMOUNT";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt1 = "TXRXAMT1";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt2 = "TXRXAMT2";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt3 = "TXRXAMT3";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt4 = "TXRXAMT4";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt5 = "TXRXAMT5";

            /// <summary>
            /// Property for RetainageTaxBase1Sum
            /// </summary>
            public const string RetainageTaxBase1Sum = "RACBASE1";

            /// <summary>
            /// Property for RetainageTaxBase2Sum
            /// </summary>
            public const string RetainageTaxBase2Sum = "RACBASE2";

            /// <summary>
            /// Property for RetainageTaxBase3Sum
            /// </summary>
            public const string RetainageTaxBase3Sum = "RACBASE3";

            /// <summary>
            /// Property for RetainageTaxBase4Sum
            /// </summary>
            public const string RetainageTaxBase4Sum = "RACBASE4";

            /// <summary>
            /// Property for RetainageTaxBase5Sum
            /// </summary>
            public const string RetainageTaxBase5Sum = "RACBASE5";

            /// <summary>
            /// Property for RetainageTaxAmount1Sum
            /// </summary>
            public const string RetainageTaxAmount1Sum = "RACAMOUNT1";

            /// <summary>
            /// Property for RetainageTaxAmount2Sum
            /// </summary>
            public const string RetainageTaxAmount2Sum = "RACAMOUNT2";

            /// <summary>
            /// Property for RetainageTaxAmount3Sum
            /// </summary>
            public const string RetainageTaxAmount3Sum = "RACAMOUNT3";

            /// <summary>
            /// Property for RetainageTaxAmount4Sum
            /// </summary>
            public const string RetainageTaxAmount4Sum = "RACAMOUNT4";

            /// <summary>
            /// Property for RetainageTaxAmount5Sum
            /// </summary>
            public const string RetainageTaxAmount5Sum = "RACAMOUNT5";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt1Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt1Sum = "RCRECVAMT1";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt2Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt2Sum = "RCRECVAMT2";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt3Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt3Sum = "RCRECVAMT3";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt4Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt4Sum = "RCRECVAMT4";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt5Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt5Sum = "RCRECVAMT5";

            /// <summary>
            /// Property for RtgTaxExpenseAmount1Sum
            /// </summary>
            public const string RtgTaxExpenseAmount1Sum = "RCEXPSAMT1";

            /// <summary>
            /// Property for RtgTaxExpenseAmount2Sum
            /// </summary>
            public const string RtgTaxExpenseAmount2Sum = "RCEXPSAMT2";

            /// <summary>
            /// Property for RtgTaxExpenseAmount3Sum
            /// </summary>
            public const string RtgTaxExpenseAmount3Sum = "RCEXPSAMT3";

            /// <summary>
            /// Property for RtgTaxExpenseAmount4Sum
            /// </summary>
            public const string RtgTaxExpenseAmount4Sum = "RCEXPSAMT4";

            /// <summary>
            /// Property for RtgTaxExpenseAmount5Sum
            /// </summary>
            public const string RtgTaxExpenseAmount5Sum = "RCEXPSAMT5";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount1Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount1Sum = "RCALLOAMT1";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount2Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount2Sum = "RCALLOAMT2";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount3Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount3Sum = "RCALLOAMT3";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount4Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount4Sum = "RCALLOAMT4";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount5Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount5Sum = "RCALLOAMT5";

            /// <summary>
            /// Property for VendorAccountSet
            /// </summary>
            public const string VendorAccountSet = "VDACCTSET";

            /// <summary>
            /// Property for VendorAccountSetDescription
            /// </summary>
            public const string VendorAccountSetDescription = "VDACCTDESC";

            /// <summary>
            /// Property for PostingDate
            /// </summary>
            public const string PostingDate = "DATEBUS";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "DETAILNEXT";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of Receipt Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for NextLineSequence
            /// </summary>
            public const int NextLineSequence = 2;

            /// <summary>
            /// Property Indexer for Lines
            /// </summary>
            public const int Lines = 3;

            /// <summary>
            /// Property Indexer for NumberOfLinesProrated
            /// </summary>
            public const int NumberOfLinesProrated = 4;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 5;

            /// <summary>
            /// Property Indexer for Costs
            /// </summary>
            public const int Costs = 6;

            /// <summary>
            /// Property Indexer for NumberOfCostsProrated
            /// </summary>
            public const int NumberOfCostsProrated = 7;

            /// <summary>
            /// Property Indexer for CostsComplete
            /// </summary>
            public const int CostsComplete = 8;

            /// <summary>
            /// Property Indexer for Vendors
            /// </summary>
            public const int Vendors = 9;

            /// <summary>
            /// Property Indexer for VendorsCompleted
            /// </summary>
            public const int VendorsCompleted = 10;

            /// <summary>
            /// Property Indexer for VendorsInvoiced
            /// </summary>
            public const int VendorsInvoiced = 11;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 12;

            /// <summary>
            /// Property Indexer for ExtraneousLineCount
            /// </summary>
            public const int ExtraneousLineCount = 13;

            /// <summary>
            /// Property Indexer for AutoTaxCalculationOnSave
            /// </summary>
            public const int AutoTaxCalculationOnSave = 14;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 15;

            /// <summary>
            /// Property Indexer for Invoiced
            /// </summary>
            public const int Invoiced = 16;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 17;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 18;

            /// <summary>
            /// Property Indexer for LastPostingDate
            /// </summary>
            public const int LastPostingDate = 19;
            
            /// <summary>
            /// Property Indexer for ReceiptDate
            /// </summary>
            public const int ReceiptDate = 20;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 21;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 22;

            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 23;

            /// <summary>
            /// Property Indexer for TemplateCode
            /// </summary>
            public const int TemplateCode = 24;

            /// <summary>
            /// Property Indexer for FOBPoint
            /// </summary>
            public const int FobPoint = 25;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 26;

            /// <summary>
            /// Property Indexer for VendorExists
            /// </summary>
            public const int VendorExists = 27;

            /// <summary>
            /// Property Indexer for Name
            /// </summary>
            public const int Name = 28;

            /// <summary>
            /// Property Indexer for Address1
            /// </summary>
            public const int Address1 = 29;

            /// <summary>
            /// Property Indexer for Address2
            /// </summary>
            public const int Address2 = 30;

            /// <summary>
            /// Property Indexer for Address3
            /// </summary>
            public const int Address3 = 31;

            /// <summary>
            /// Property Indexer for Address4
            /// </summary>
            public const int Address4 = 32;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 33;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 34;

            /// <summary>
            /// Property Indexer for ZipPostalCode
            /// </summary>
            public const int ZipPostalCode = 35;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 36;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 37;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 38;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 39;

            /// <summary>
            /// Property Indexer for TermsCode
            /// </summary>
            public const int TermsCode = 40;

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 41;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 42;

            /// <summary>
            /// Property Indexer for InvoiceNumber
            /// </summary>
            public const int InvoiceNumber = 43;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 44;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 45;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 46;

            /// <summary>
            /// Property Indexer for ShipVia
            /// </summary>
            public const int ShipVia = 47;

            /// <summary>
            /// Property Indexer for ShipViaName
            /// </summary>
            public const int ShipViaName = 48;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 57;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 58;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 59;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 60;

            /// <summary>
            /// Property Indexer for RateMatchType
            /// </summary>
            public const int RateMatchType = 61;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 62;

            /// <summary>
            /// Property Indexer for RateOperation
            /// </summary>
            public const int RateOperation = 63;

            /// <summary>
            /// Property Indexer for RateOverridden
            /// </summary>
            public const int RateOverridden = 64;

            /// <summary>
            /// Property Indexer for DecimalPlaces
            /// </summary>
            public const int DecimalPlaces = 65;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 66;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 67;

            /// <summary>
            /// Property Indexer for Total
            /// </summary>
            public const int Total = 68;

            /// <summary>
            /// Property Indexer for AdditionalCosts
            /// </summary>
            public const int AdditionalCosts = 69;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 70;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 71;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 72;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 73;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 74;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 75;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 76;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 77;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 78;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 79;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 80;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 81;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 82;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 83;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 84;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 85;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 86;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 87;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 88;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 89;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 90;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 91;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 92;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 93;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 94;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 95;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 96;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 97;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 98;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 99;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 100;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 101;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 102;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 103;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 104;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 105;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 106;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 107;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 108;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 109;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 110;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 111;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 112;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 113;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 114;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 115;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 116;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 117;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 118;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 119;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 120;

            /// <summary>
            /// Property Indexer for TotalTaxRecoverable
            /// </summary>
            public const int TotalTaxRecoverable = 121;

            /// <summary>
            /// Property Indexer for TotalTaxExpensed
            /// </summary>
            public const int TotalTaxExpensed = 122;

            /// <summary>
            /// Property Indexer for TotalTaxAllocated
            /// </summary>
            public const int TotalTaxAllocated = 123;

            /// <summary>
            /// Property Indexer for ManualProrationTotal
            /// </summary>
            public const int ManualProrationTotal = 124;

            /// <summary>
            /// Property Indexer for ManualToProrate
            /// </summary>
            public const int ManualToProrate = 125;

            /// <summary>
            /// Property Indexer for ConversionSourceAmount
            /// </summary>
            public const int ConversionSourceAmount = 126;

            /// <summary>
            /// Property Indexer for ConversionFunctionalAmount
            /// </summary>
            public const int ConversionFunctionalAmount = 127;

            /// <summary>
            /// Property Indexer for MultiplePurchaseOrders
            /// </summary>
            public const int MultiplePurchaseOrders = 128;

            /// <summary>
            /// Property Indexer for PurchaseOrders
            /// </summary>
            public const int PurchaseOrders = 129;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 130;

            /// <summary>
            /// Property Indexer for ContactPhone
            /// </summary>
            public const int ContactPhone = 131;

            /// <summary>
            /// Property Indexer for ContactFax
            /// </summary>
            public const int ContactFax = 132;

            /// <summary>
            /// Property Indexer for ContactEmail
            /// </summary>
            public const int ContactEmail = 133;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 134;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 135;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 136;

            /// <summary>
            /// Property Indexer for ProrationVersion
            /// </summary>
            public const int ProrationVersion = 137;

            /// <summary>
            /// Property Indexer for HasRetainage
            /// </summary>
            public const int HasRetainage = 138;

            /// <summary>
            /// Property Indexer for RetainageExchangeRate
            /// </summary>
            public const int RetainageExchangeRate = 139;

            /// <summary>
            /// Property Indexer for BillToLocation
            /// </summary>
            public const int BillToLocation = 140;

            /// <summary>
            /// Property Indexer for BillToLocationDescription
            /// </summary>
            public const int BillToLocationDescription = 141;

            /// <summary>
            /// Property Indexer for BillToAddress1
            /// </summary>
            public const int BillToAddress1 = 142;

            /// <summary>
            /// Property Indexer for BillToAddress2
            /// </summary>
            public const int BillToAddress2 = 143;

            /// <summary>
            /// Property Indexer for BillToAddress3
            /// </summary>
            public const int BillToAddress3 = 144;

            /// <summary>
            /// Property Indexer for BillToAddress4
            /// </summary>
            public const int BillToAddress4 = 145;

            /// <summary>
            /// Property Indexer for BillToCity
            /// </summary>
            public const int BillToCity = 146;

            /// <summary>
            /// Property Indexer for BillToStateProvince
            /// </summary>
            public const int BillToStateProvince = 147;

            /// <summary>
            /// Property Indexer for BillToZipPostalCode
            /// </summary>
            public const int BillToZipPostalCode = 148;

            /// <summary>
            /// Property Indexer for BillToCountry
            /// </summary>
            public const int BillToCountry = 149;

            /// <summary>
            /// Property Indexer for BillToPhoneNumber
            /// </summary>
            public const int BillToPhoneNumber = 150;

            /// <summary>
            /// Property Indexer for BillToFaxNumber
            /// </summary>
            public const int BillToFaxNumber = 151;

            /// <summary>
            /// Property Indexer for BillToContact
            /// </summary>
            public const int BillToContact = 152;

            /// <summary>
            /// Property Indexer for ShipToLocation
            /// </summary>
            public const int ShipToLocation = 153;

            /// <summary>
            /// Property Indexer for ShipToLocationDescription
            /// </summary>
            public const int ShipToLocationDescription = 154;

            /// <summary>
            /// Property Indexer for ShipToAddress1
            /// </summary>
            public const int ShipToAddress1 = 155;

            /// <summary>
            /// Property Indexer for ShipToAddress2
            /// </summary>
            public const int ShipToAddress2 = 156;

            /// <summary>
            /// Property Indexer for ShipToAddress3
            /// </summary>
            public const int ShipToAddress3 = 157;

            /// <summary>
            /// Property Indexer for ShipToAddress4
            /// </summary>
            public const int ShipToAddress4 = 158;

            /// <summary>
            /// Property Indexer for ShipToCity
            /// </summary>
            public const int ShipToCity = 159;

            /// <summary>
            /// Property Indexer for ShipToStateProvince
            /// </summary>
            public const int ShipToStateProvince = 160;

            /// <summary>
            /// Property Indexer for ShipToZipPostalCode
            /// </summary>
            public const int ShipToZipPostalCode = 161;

            /// <summary>
            /// Property Indexer for ShipToCountry
            /// </summary>
            public const int ShipToCountry = 162;

            /// <summary>
            /// Property Indexer for ShipToPhoneNumber
            /// </summary>
            public const int ShipToPhoneNumber = 163;

            /// <summary>
            /// Property Indexer for ShipToFaxNumber
            /// </summary>
            public const int ShipToFaxNumber = 164;

            /// <summary>
            /// Property Indexer for ShipToContact
            /// </summary>
            public const int ShipToContact = 165;

            /// <summary>
            /// Property Indexer for PredecessorsExchangeRate
            /// </summary>
            public const int PredecessorsExchangeRate = 166;

            /// <summary>
            /// Property Indexer for PredecessorsRateType
            /// </summary>
            public const int PredecessorsRateType = 167;

            /// <summary>
            /// Property Indexer for PredecessorsRateDate
            /// </summary>
            public const int PredecessorsRateDate = 168;

            /// <summary>
            /// Property Indexer for PredecessorsRateOperation
            /// </summary>
            public const int PredecessorsRateOperation = 169;

            /// <summary>
            /// Property Indexer for PredecessorsRateOverridden
            /// </summary>
            public const int PredecessorsRateOverridden = 170;

            /// <summary>
            /// Property Indexer for BillToEmail
            /// </summary>
            public const int BillToEmail = 171;

            /// <summary>
            /// Property Indexer for BillToContactPhone
            /// </summary>
            public const int BillToContactPhone = 172;

            /// <summary>
            /// Property Indexer for BillToContactFax
            /// </summary>
            public const int BillToContactFax = 173;

            /// <summary>
            /// Property Indexer for BillToContactEmail
            /// </summary>
            public const int BillToContactEmail = 174;

            /// <summary>
            /// Property Indexer for ShipToEmail
            /// </summary>
            public const int ShipToEmail = 175;

            /// <summary>
            /// Property Indexer for ShipToContactPhone
            /// </summary>
            public const int ShipToContactPhone = 176;

            /// <summary>
            /// Property Indexer for ShipToContactFax
            /// </summary>
            public const int ShipToContactFax = 177;

            /// <summary>
            /// Property Indexer for ShipToContactEmail
            /// </summary>
            public const int ShipToContactEmail = 178;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 180;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 181;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 182;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 183;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 184;

            /// <summary>
            /// Property Indexer for TaxAuthority1Description
            /// </summary>
            public const int TaxAuthority1Description = 185;

            /// <summary>
            /// Property Indexer for TaxAuthority2Description
            /// </summary>
            public const int TaxAuthority2Description = 186;

            /// <summary>
            /// Property Indexer for TaxAuthority3Description
            /// </summary>
            public const int TaxAuthority3Description = 187;

            /// <summary>
            /// Property Indexer for TaxAuthority4Description
            /// </summary>
            public const int TaxAuthority4Description = 188;

            /// <summary>
            /// Property Indexer for TaxAuthority5Description
            /// </summary>
            public const int TaxAuthority5Description = 189;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 190;

            /// <summary>
            /// Property Indexer for RateTypeDescription
            /// </summary>
            public const int RateTypeDescription = 191;

            /// <summary>
            /// Property Indexer for LastReceiptNumber
            /// </summary>
            public const int LastReceiptNumber = 192;
            
            /// <summary>
            /// Property Indexer for RcpDate
            /// </summary>
            public const int RcpDate = 193;

            /// <summary>
            /// Property Indexer for NumberOfPostedReceipts
            /// </summary>
            public const int NumberOfPostedReceipts = 194;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 195;

            /// <summary>
            /// Property Indexer for TermsCodeDescription
            /// </summary>
            public const int TermsCodeDescription = 196;

            /// <summary>
            /// Property Indexer for PredecessorsRateTypeDesc
            /// </summary>
            public const int PredecessorsRateTypeDesc = 197;

            /// <summary>
            /// Property Indexer for NetOfTaxSum
            /// </summary>
            public const int NetOfTaxSum = 198;

            /// <summary>
            /// Property Indexer for TaxIncluded1Sum
            /// </summary>
            public const int TaxIncluded1Sum = 199;

            /// <summary>
            /// Property Indexer for TaxIncluded2Sum
            /// </summary>
            public const int TaxIncluded2Sum = 200;

            /// <summary>
            /// Property Indexer for TaxIncluded3Sum
            /// </summary>
            public const int TaxIncluded3Sum = 201;

            /// <summary>
            /// Property Indexer for TaxIncluded4Sum
            /// </summary>
            public const int TaxIncluded4Sum = 202;

            /// <summary>
            /// Property Indexer for TaxIncluded5Sum
            /// </summary>
            public const int TaxIncluded5Sum = 203;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1Sum
            /// </summary>
            public const int TaxAllocatedAmount1Sum = 204;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2Sum
            /// </summary>
            public const int TaxAllocatedAmount2Sum = 205;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3Sum
            /// </summary>
            public const int TaxAllocatedAmount3Sum = 206;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4Sum
            /// </summary>
            public const int TaxAllocatedAmount4Sum = 207;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5Sum
            /// </summary>
            public const int TaxAllocatedAmount5Sum = 208;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1Sum
            /// </summary>
            public const int TaxRecoverableAmount1Sum = 209;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2Sum
            /// </summary>
            public const int TaxRecoverableAmount2Sum = 210;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3Sum
            /// </summary>
            public const int TaxRecoverableAmount3Sum = 211;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4Sum
            /// </summary>
            public const int TaxRecoverableAmount4Sum = 212;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5Sum
            /// </summary>
            public const int TaxRecoverableAmount5Sum = 213;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1Sum
            /// </summary>
            public const int TaxExpenseAmount1Sum = 214;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2Sum
            /// </summary>
            public const int TaxExpenseAmount2Sum = 215;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3Sum
            /// </summary>
            public const int TaxExpenseAmount3Sum = 216;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4Sum
            /// </summary>
            public const int TaxExpenseAmount4Sum = 217;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5Sum
            /// </summary>
            public const int TaxExpenseAmount5Sum = 218;

            /// <summary>
            /// Property Indexer for TotalTaxAllocated1
            /// </summary>
            public const int TotalTaxAllocated1 = 219;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 220;

            /// <summary>
            /// Property Indexer for TaxExcluded1
            /// </summary>
            public const int TaxExcluded1 = 221;

            /// <summary>
            /// Property Indexer for TotalUnbalancedTax
            /// </summary>
            public const int TotalUnbalancedTax = 222;

            /// <summary>
            /// Property Indexer for TotalUnbalancedAllocatedTax
            /// </summary>
            public const int TotalUnbalancedAllocatedTax = 223;

            /// <summary>
            /// Property Indexer for UnbalancedManualProrationAmt
            /// </summary>
            public const int UnbalancedManualProrationAmt = 224;

            /// <summary>
            /// Property Indexer for Subtotal
            /// </summary>
            public const int Subtotal = 225;

            /// <summary>
            /// Property Indexer for TaxcalculationIspending
            /// </summary>
            public const int TaxcalculationIspending = 226;

            /// <summary>
            /// Property Indexer for DocumentLocked
            /// </summary>
            public const int DocumentLocked = 227;

            /// <summary>
            /// Property Indexer for IsDocumentDeletable
            /// </summary>
            public const int IsDocumentDeletable = 228;

            /// <summary>
            /// Property Indexer for ExchangeRateExists
            /// </summary>
            public const int ExchangeRateExists = 229;

            /// <summary>
            /// Property Indexer for HasDetails
            /// </summary>
            public const int HasDetails = 230;

            /// <summary>
            /// Property Indexer for DiscountAmountSum
            /// </summary>
            public const int DiscountAmountSum = 231;

            /// <summary>
            /// Property Indexer for NetExtendedCost
            /// </summary>
            public const int NetExtendedCost = 232;

            /// <summary>
            /// Property Indexer for DayEndNumber
            /// </summary>
            public const int DayEndNumber = 233;

            /// <summary>
            /// Property Indexer for RetainageTermsCode
            /// </summary>
            public const int RetainageTermsCode = 234;

            /// <summary>
            /// Property Indexer for JobRelatedLines
            /// </summary>
            public const int JobRelatedLines = 235;

            /// <summary>
            /// Property Indexer for JobRelatedCosts
            /// </summary>
            public const int JobRelatedCosts = 236;

            /// <summary>
            /// Property Indexer for BillableLines
            /// </summary>
            public const int BillableLines = 237;

            /// <summary>
            /// Property Indexer for CostBillingRatesProrated
            /// </summary>
            public const int CostBillingRatesProrated = 238;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 239;

            /// <summary>
            /// Property Indexer for RetainageTermsCodeDescription
            /// </summary>
            public const int RetainageTermsCodeDescription = 240;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 241;

            /// <summary>
            /// Property Indexer for RetainageBase
            /// </summary>
            public const int RetainageBase = 242;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 243;

            /// <summary>
            /// Property Indexer for UnretainedTotal
            /// </summary>
            public const int UnretainedTotal = 244;

            /// <summary>
            /// Property Indexer for TaxReportingCurrency
            /// </summary>
            public const int TaxReportingCurrency = 245;

            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate
            /// </summary>
            public const int TaxReportingExchangeRate = 246;

            /// <summary>
            /// Property Indexer for TaxReportingRateSpread
            /// </summary>
            public const int TaxReportingRateSpread = 247;

            /// <summary>
            /// Property Indexer for TaxReportingRateType
            /// </summary>
            public const int TaxReportingRateType = 248;

            /// <summary>
            /// Property Indexer for TaxReportingRateMatchType
            /// </summary>
            public const int TaxReportingRateMatchType = 249;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate
            /// </summary>
            public const int TaxReportingRateDate = 250;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperation
            /// </summary>
            public const int TaxReportingRateOperation = 251;

            /// <summary>
            /// Property Indexer for TaxReportingRateOverridden
            /// </summary>
            public const int TaxReportingRateOverridden = 252;

            /// <summary>
            /// Property Indexer for TaxReportingDecimalPlaces
            /// </summary>
            public const int TaxReportingDecimalPlaces = 253;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 254;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 255;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 256;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 257;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 258;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 259;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 260;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 261;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 262;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 263;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 264;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 265;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 266;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 267;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 268;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 269;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 270;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 271;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 272;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 273;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 274;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 275;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 276;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 277;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 278;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 279;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 280;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 281;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 282;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 283;

            /// <summary>
            /// Property Indexer for PredTaxReportingExchRate
            /// </summary>
            public const int PredTaxReportingExchRate = 284;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateType
            /// </summary>
            public const int PredTaxReportingRateType = 285;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateDate
            /// </summary>
            public const int PredTaxReportingRateDate = 286;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateOper
            /// </summary>
            public const int PredTaxReportingRateOper = 287;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateOverrd
            /// </summary>
            public const int PredTaxReportingRateOverrd = 288;

            /// <summary>
            /// Property Indexer for TaxReportingExchRateExists
            /// </summary>
            public const int TaxReportingExchRateExists = 289;

            /// <summary>
            /// Property Indexer for DerivedTaxReportingExchRate
            /// </summary>
            public const int DerivedTaxReportingExchRate = 290;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyDesc
            /// </summary>
            public const int TaxReportingCurrencyDesc = 291;

            /// <summary>
            /// Property Indexer for TaxReportingRateTypeDesc
            /// </summary>
            public const int TaxReportingRateTypeDesc = 292;

            /// <summary>
            /// Property Indexer for PredTaxRepRateTypeDesc
            /// </summary>
            public const int PredTaxRepRateTypeDesc = 293;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 294;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 295;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 296;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 297;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmt
            /// </summary>
            public const int TaxReportingExpensedAmt = 298;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 299;

            /// <summary>
            /// Property Indexer for TaxBase1Sum
            /// </summary>
            public const int TaxBase1Sum = 300;

            /// <summary>
            /// Property Indexer for TaxBase2Sum
            /// </summary>
            public const int TaxBase2Sum = 301;

            /// <summary>
            /// Property Indexer for TaxBase3Sum
            /// </summary>
            public const int TaxBase3Sum = 302;

            /// <summary>
            /// Property Indexer for TaxBase4Sum
            /// </summary>
            public const int TaxBase4Sum = 303;

            /// <summary>
            /// Property Indexer for TaxBase5Sum
            /// </summary>
            public const int TaxBase5Sum = 304;

            /// <summary>
            /// Property Indexer for TaxAmount1Sum
            /// </summary>
            public const int TaxAmount1Sum = 305;

            /// <summary>
            /// Property Indexer for TaxAmount2Sum
            /// </summary>
            public const int TaxAmount2Sum = 306;

            /// <summary>
            /// Property Indexer for TaxAmount3Sum
            /// </summary>
            public const int TaxAmount3Sum = 307;

            /// <summary>
            /// Property Indexer for TaxAmount4Sum
            /// </summary>
            public const int TaxAmount4Sum = 308;

            /// <summary>
            /// Property Indexer for TaxAmount5Sum
            /// </summary>
            public const int TaxAmount5Sum = 309;

            /// <summary>
            /// Property Indexer for TaxExcluded1Sum
            /// </summary>
            public const int TaxExcluded1Sum = 310;

            /// <summary>
            /// Property Indexer for TaxExcluded2Sum
            /// </summary>
            public const int TaxExcluded2Sum = 311;

            /// <summary>
            /// Property Indexer for TaxExcluded3Sum
            /// </summary>
            public const int TaxExcluded3Sum = 312;

            /// <summary>
            /// Property Indexer for TaxExcluded4Sum
            /// </summary>
            public const int TaxExcluded4Sum = 313;

            /// <summary>
            /// Property Indexer for TaxExcluded5Sum
            /// </summary>
            public const int TaxExcluded5Sum = 314;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1Sum
            /// </summary>
            public const int TaxReportingAmount1Sum = 315;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2Sum
            /// </summary>
            public const int TaxReportingAmount2Sum = 316;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3Sum
            /// </summary>
            public const int TaxReportingAmount3Sum = 317;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4Sum
            /// </summary>
            public const int TaxReportingAmount4Sum = 318;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5Sum
            /// </summary>
            public const int TaxReportingAmount5Sum = 319;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded1Sum
            /// </summary>
            public const int TaxReportingIncluded1Sum = 320;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded2Sum
            /// </summary>
            public const int TaxReportingIncluded2Sum = 321;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded3Sum
            /// </summary>
            public const int TaxReportingIncluded3Sum = 322;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded4Sum
            /// </summary>
            public const int TaxReportingIncluded4Sum = 323;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded5Sum
            /// </summary>
            public const int TaxReportingIncluded5Sum = 324;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded1Sum
            /// </summary>
            public const int TaxReportingExcluded1Sum = 325;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded2Sum
            /// </summary>
            public const int TaxReportingExcluded2Sum = 326;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded3Sum
            /// </summary>
            public const int TaxReportingExcluded3Sum = 327;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded4Sum
            /// </summary>
            public const int TaxReportingExcluded4Sum = 328;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded5Sum
            /// </summary>
            public const int TaxReportingExcluded5Sum = 329;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount1Sum
            /// </summary>
            public const int TaxRepAllocatedAmount1Sum = 330;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount2Sum
            /// </summary>
            public const int TaxRepAllocatedAmount2Sum = 331;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount3Sum
            /// </summary>
            public const int TaxRepAllocatedAmount3Sum = 332;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount4Sum
            /// </summary>
            public const int TaxRepAllocatedAmount4Sum = 333;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount5Sum
            /// </summary>
            public const int TaxRepAllocatedAmount5Sum = 334;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt1Sum
            /// </summary>
            public const int TaxRepRecoverableAmt1Sum = 335;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt2Sum
            /// </summary>
            public const int TaxRepRecoverableAmt2Sum = 336;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt3Sum
            /// </summary>
            public const int TaxRepRecoverableAmt3Sum = 337;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt4Sum
            /// </summary>
            public const int TaxRepRecoverableAmt4Sum = 338;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt5Sum
            /// </summary>
            public const int TaxRepRecoverableAmt5Sum = 339;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount1Sum
            /// </summary>
            public const int TaxRepExpenseAmount1Sum = 340;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount2Sum
            /// </summary>
            public const int TaxRepExpenseAmount2Sum = 341;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount3Sum
            /// </summary>
            public const int TaxRepExpenseAmount3Sum = 342;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount4Sum
            /// </summary>
            public const int TaxRepExpenseAmount4Sum = 343;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount5Sum
            /// </summary>
            public const int TaxRepExpenseAmount5Sum = 344;

            /// <summary>
            /// Property Indexer for ReportRetainageTax
            /// </summary>
            public const int ReportRetainageTax = 345;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 346;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 347;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 348;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 349;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 350;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 351;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 352;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 353;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 354;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 355;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt1
            /// </summary>
            public const int RetainageTaxRecoverableAmt1 = 356;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt2
            /// </summary>
            public const int RetainageTaxRecoverableAmt2 = 357;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt3
            /// </summary>
            public const int RetainageTaxRecoverableAmt3 = 358;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt4
            /// </summary>
            public const int RetainageTaxRecoverableAmt4 = 359;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt5
            /// </summary>
            public const int RetainageTaxRecoverableAmt5 = 360;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount1
            /// </summary>
            public const int RetainageTaxExpenseAmount1 = 361;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount2
            /// </summary>
            public const int RetainageTaxExpenseAmount2 = 362;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount3
            /// </summary>
            public const int RetainageTaxExpenseAmount3 = 363;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount4
            /// </summary>
            public const int RetainageTaxExpenseAmount4 = 364;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount5
            /// </summary>
            public const int RetainageTaxExpenseAmount5 = 365;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount1
            /// </summary>
            public const int RetainageTaxAllocatedAmount1 = 366;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount2
            /// </summary>
            public const int RetainageTaxAllocatedAmount2 = 367;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount3
            /// </summary>
            public const int RetainageTaxAllocatedAmount3 = 368;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount4
            /// </summary>
            public const int RetainageTaxAllocatedAmount4 = 369;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount5
            /// </summary>
            public const int RetainageTaxAllocatedAmount5 = 370;

            /// <summary>
            /// Property Indexer for WarnOnRetainageTaxShift
            /// </summary>
            public const int WarnOnRetainageTaxShift = 371;

            /// <summary>
            /// Property Indexer for RetainageTaxTotalAmount
            /// </summary>
            public const int RetainageTaxTotalAmount = 372;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt1 = 373;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt2 = 374;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt3 = 375;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt4 = 376;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt5 = 377;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1Sum
            /// </summary>
            public const int RetainageTaxBase1Sum = 378;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2Sum
            /// </summary>
            public const int RetainageTaxBase2Sum = 379;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3Sum
            /// </summary>
            public const int RetainageTaxBase3Sum = 380;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4Sum
            /// </summary>
            public const int RetainageTaxBase4Sum = 381;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5Sum
            /// </summary>
            public const int RetainageTaxBase5Sum = 382;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1Sum
            /// </summary>
            public const int RetainageTaxAmount1Sum = 383;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2Sum
            /// </summary>
            public const int RetainageTaxAmount2Sum = 384;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3Sum
            /// </summary>
            public const int RetainageTaxAmount3Sum = 385;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4Sum
            /// </summary>
            public const int RetainageTaxAmount4Sum = 386;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5Sum
            /// </summary>
            public const int RetainageTaxAmount5Sum = 387;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt1Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt1Sum = 388;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt2Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt2Sum = 389;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt3Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt3Sum = 390;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt4Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt4Sum = 391;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt5Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt5Sum = 392;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount1Sum
            /// </summary>
            public const int RtgTaxExpenseAmount1Sum = 393;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount2Sum
            /// </summary>
            public const int RtgTaxExpenseAmount2Sum = 394;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount3Sum
            /// </summary>
            public const int RtgTaxExpenseAmount3Sum = 395;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount4Sum
            /// </summary>
            public const int RtgTaxExpenseAmount4Sum = 396;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount5Sum
            /// </summary>
            public const int RtgTaxExpenseAmount5Sum = 397;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount1Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount1Sum = 398;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount2Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount2Sum = 399;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount3Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount3Sum = 400;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount4Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount4Sum = 401;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount5Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount5Sum = 402;

            /// <summary>
            /// Property Indexer for VendorAccountSet
            /// </summary>
            public const int VendorAccountSet = 403;

            /// <summary>
            /// Property Indexer for VendorAccountSetDescription
            /// </summary>
            public const int VendorAccountSetDescription = 404;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 405;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 406;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 407;
            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 408;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 409;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 410;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 411;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 412;
            /// <summary>
            /// Property Indexer for customer detail tax amount 1
            /// </summary>
            public const int CustomerDetailTaxAmount1 = 413;
            /// <summary>
            /// Property Indexer for customer detail tax amount 2
            /// </summary>
            public const int CustomerDetailTaxAmount2 = 414;
            /// <summary>
            /// Property Indexer for customer detail tax amount 3
            /// </summary>
            public const int CustomerDetailTaxAmount3 = 415;
            /// <summary>
            /// Property Indexer for customer detail tax amount 4
            /// </summary>
            public const int CustomerDetailTaxAmount4 = 416;
            /// <summary>
            /// Property Indexer for customer detail tax amount 5
            /// </summary>
            public const int CustomerDetailTaxAmount5 = 417;

            /// <summary>
            /// Property Indexer for customer tax amount 1
            /// </summary>
            public const int CustomerTaxAmount1 = 423;
            /// <summary>
            /// Property Indexer for customer tax amount 2
            /// </summary>
            public const int CustomerTaxAmount2 = 424;
            /// <summary>
            /// Property Indexer for customer tax amount 3
            /// </summary>
            public const int CustomerTaxAmount3 = 425;
            /// <summary>
            /// Property Indexer for customer tax amount 4
            /// </summary>
            public const int CustomerTaxAmount4 = 426;
            /// <summary>
            /// Property Indexer for customer tax amount 5
            /// </summary>
            public const int CustomerTaxAmount5 = 427;
            /// <summary>
            /// Property Indexer for customer tax amount
            /// </summary>
            public const int CustomerTaxAmount = 428;
            /// <summary>
            /// Property Indexer for Excluded Tax Less Reverse Charge
            /// </summary>
            public const int ExcludedTaxLessReverseCharge = 429;

        }

        #endregion

        #region Order Keys

        /// <summary>
        /// Order Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Receipt Key
            /// </summary>
            public const int ReceiptSequenceKey = 0;

            /// <summary>
            /// Receipt Number Key
            /// </summary>
            public const int ReceiptNumber = 1;
        }

        #endregion
    }
}
