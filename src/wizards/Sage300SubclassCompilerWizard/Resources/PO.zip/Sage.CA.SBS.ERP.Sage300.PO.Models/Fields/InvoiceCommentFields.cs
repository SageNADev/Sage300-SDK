// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceComment Constants
    /// </summary>
    public partial class InvoiceComment
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0416";

        #region Properties
        /// <summary>
        /// Contains list of InvoiceComment Constants
        /// </summary>
        public class Fields : BaseFields
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of InvoiceComment Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for CommentIdentifier
            /// </summary>
            public const int CommentIdentifier = 2;

            /// <summary>
            /// Property Indexer for InvoiceCommentSequence
            /// </summary>
            public const int InvoiceCommentSequence = 3;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 4;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 5;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 6;

        }
        #endregion
    }
}
