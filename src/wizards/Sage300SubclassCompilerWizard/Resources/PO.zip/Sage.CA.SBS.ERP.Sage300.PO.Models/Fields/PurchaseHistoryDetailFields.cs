// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseHistoryDetail Constants
    /// </summary>
    public partial class PurchaseHistoryDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0384";

        #region Properties

        /// <summary>
        /// Contains list of PurchaseHistoryDetail Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VENDOR";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ITEMNO
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "FISCPERIOD";

            /// <summary>
            /// Property for TransactionDate
            /// </summary>
            public const string TransactionDate = "TRANSDATE";

            /// <summary>
            /// Property for DayEndNumber
            /// </summary>
            public const string DayEndNumber = "POSTSEQNUM";

            /// <summary>
            /// Property for TransactionSequence
            /// </summary>
            public const string TransactionSequence = "ENTRYNUM";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "LINESEQ";

            /// <summary>
            /// Property for HeaderSequence
            /// </summary>
            public const string HeaderSequence = "HEADSEQ";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRANSTYPE";

            /// <summary>
            /// Property for DocumentNumber
            /// </summary>
            public const string DocumentNumber = "DOCNUMBER";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for QuantityRqPosted
            /// </summary>
            public const string QuantityRqPosted = "RQPOSTED";

            /// <summary>
            /// Property for StockingQuantitySqPosted
            /// </summary>
            public const string StockingQuantitySqPosted = "SQPOSTED";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UNIT";

            /// <summary>
            /// Property for ConversionFactor
            /// </summary>
            public const string ConversionFactor = "CONV";

            /// <summary>
            /// Property for SrceCost
            /// </summary>
            public const string SrceCost = "SCEXTENDED";

            /// <summary>
            /// Property for FuncCost
            /// </summary>
            public const string FuncCost = "FCEXTENDED";

            /// <summary>
            /// Property for DaysToReceive
            /// </summary>
            public const string DaysToReceive = "RCPDAYS";

            /// <summary>
            /// Property for TotalQuantity
            /// </summary>
            public const string TotalQuantity = "RQTOTAL";

            /// <summary>
            /// Property for StockingTotalQuantity
            /// </summary>
            public const string StockingTotalQuantity = "SQTOTAL";

            /// <summary>
            /// Property for SrceTotalCost
            /// </summary>
            public const string SrceTotalCost = "SCTOTAL";

            /// <summary>
            /// Property for FuncTotalCost
            /// </summary>
            public const string FuncTotalCost = "FCTOTAL";

            /// <summary>
            /// Property for DiscountAmount
            /// </summary>
            public const string DiscountAmount = "SCDISCOUNT";

            /// <summary>
            /// Property for FuncDiscountAmount
            /// </summary>
            public const string FuncDiscountAmount = "FCDISCOUNT";

            /// <summary>
            /// Property for TotalDiscount
            /// </summary>
            public const string TotalDiscount = "SCDISCTOT";

            /// <summary>
            /// Property for FunctionalTotalDiscount
            /// </summary>
            public const string FunctionalTotalDiscount = "FCDISCTOT";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for VendorName
            /// </summary>
            public const string VendorName = "VENDNAME";

            /// <summary>
            /// Property for EntryQuantityReceived
            /// </summary>
            public const string EntryQuantityReceived = "RQRECEIVED";

            /// <summary>
            /// Property for QuantityReceived
            /// </summary>
            public const string QuantityReceived = "SQRECEIVED";

            /// <summary>
            /// Property for FuncReceivedAmount
            /// </summary>
            public const string FuncReceivedAmount = "FCRECEIVED";

            /// <summary>
            /// Property for SrceReceivedAmount
            /// </summary>
            public const string SrceReceivedAmount = "SCRECEIVED";

            /// <summary>
            /// Property for EntryQuantityAdjonInvoices
            /// </summary>
            public const string EntryQuantityAdjonInvoices = "RQINVADJ";

            /// <summary>
            /// Property for QuantityAdjustedonInvoices
            /// </summary>
            public const string QuantityAdjustedonInvoices = "SQINVADJ";

            /// <summary>
            /// Property for FuncAdjustedonInvoices
            /// </summary>
            public const string FuncAdjustedonInvoices = "FCINVADJ";

            /// <summary>
            /// Property for SrceAdjustedonInvoices
            /// </summary>
            public const string SrceAdjustedonInvoices = "SCINVADJ";

            /// <summary>
            /// Property for EntryQuantityReturned
            /// </summary>
            public const string EntryQuantityReturned = "RQRETURNED";

            /// <summary>
            /// Property for QuantityReturned
            /// </summary>
            public const string QuantityReturned = "SQRETURNED";

            /// <summary>
            /// Property for FuncReturnAmount
            /// </summary>
            public const string FuncReturnAmount = "FCRETURNED";

            /// <summary>
            /// Property for SrceReturnAmount
            /// </summary>
            public const string SrceReturnAmount = "SCRETURNED";

            /// <summary>
            /// Property for EntryQuantityCredited
            /// </summary>
            public const string EntryQuantityCredited = "RQCRNADJ";

            /// <summary>
            /// Property for QuantityCredited
            /// </summary>
            public const string QuantityCredited = "SQCRNADJ";

            /// <summary>
            /// Property for FuncCreditNoteAmount
            /// </summary>
            public const string FuncCreditNoteAmount = "FCCRNADJ";

            /// <summary>
            /// Property for SrceCreditNoteAmount
            /// </summary>
            public const string SrceCreditNoteAmount = "SCCRNADJ";

            /// <summary>
            /// Property for EntryQuantityDebited
            /// </summary>
            public const string EntryQuantityDebited = "RQDEBADJ";

            /// <summary>
            /// Property for QuantityDebited
            /// </summary>
            public const string QuantityDebited = "SQDEBADJ";

            /// <summary>
            /// Property for FuncDebitNoteAmount
            /// </summary>
            public const string FuncDebitNoteAmount = "FCDEBADJ";

            /// <summary>
            /// Property for SrceDebitNoteAmount
            /// </summary>
            public const string SrceDebitNoteAmount = "SCDEBADJ";

            /// <summary>
            /// Property for EntryTotalQuantityInvoiced
            /// </summary>
            public const string EntryTotalQuantityInvoiced = "RQINVTOTAL";

            /// <summary>
            /// Property for TotalQuantityInvoiced
            /// </summary>
            public const string TotalQuantityInvoiced = "SQINVTOTAL";

            /// <summary>
            /// Property for FuncInvoiceTotal
            /// </summary>
            public const string FuncInvoiceTotal = "FCINVTOTAL";

            /// <summary>
            /// Property for SrceInvoiceTotal
            /// </summary>
            public const string SrceInvoiceTotal = "SCINVTOTAL";

            /// <summary>
            /// Property for EntryTotalQuantityCredited
            /// </summary>
            public const string EntryTotalQuantityCredited = "RQCRNTOTAL";

            /// <summary>
            /// Property for TotalQuantityCredited
            /// </summary>
            public const string TotalQuantityCredited = "SQCRNTOTAL";

            /// <summary>
            /// Property for FuncCreditNoteTotal
            /// </summary>
            public const string FuncCreditNoteTotal = "FCCRNTOTAL";

            /// <summary>
            /// Property for SrceCreditNoteTotal
            /// </summary>
            public const string SrceCreditNoteTotal = "SCCRNTOTAL";

            /// <summary>
            /// Property for EntryTotalQuantityDebited
            /// </summary>
            public const string EntryTotalQuantityDebited = "RQDEBTOTAL";

            /// <summary>
            /// Property for TotalQuantityDebited
            /// </summary>
            public const string TotalQuantityDebited = "SQDEBTOTAL";

            /// <summary>
            /// Property for FuncDebitNoteTotal
            /// </summary>
            public const string FuncDebitNoteTotal = "FCDEBTOTAL";

            /// <summary>
            /// Property for SrceDebitNoteTotal
            /// </summary>
            public const string SrceDebitNoteTotal = "SCDEBTOTAL";

            /// <summary>
            /// Property for RQDISPLAY
            /// </summary>
            public const string QuantityRqDisplay = "RQDISPLAY";

            /// <summary>
            /// Property for StockingQuantitySqDisplay
            /// </summary>
            public const string StockingQuantitySqDisplay = "SQDISPLAY";

            /// <summary>
            /// Property for FunctionalAmount
            /// </summary>
            public const string FunctionalAmount = "FCDISPLAY";

            /// <summary>
            /// Property for SourceAmount
            /// </summary>
            public const string SourceAmount = "SCDISPLAY";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for FMTITEMNO
            /// </summary>
            public const string FormattedItemNumber = "FMTITEMNO";

            /// <summary>
            /// Property for SrceNetExtendedAmount
            /// </summary>
            public const string SrceNetExtendedAmount = "SCNETXTEND";

            /// <summary>
            /// Property for FuncNetExtendedAmount
            /// </summary>
            public const string FuncNetExtendedAmount = "FCNETXTEND";

            /// <summary>
            /// Property for SrceTotalNetCost
            /// </summary>
            public const string SrceTotalNetCost = "SCNETXTOT";

            /// <summary>
            /// Property for FuncTotalNetCost
            /// </summary>
            public const string FuncTotalNetCost = "FCNETXTOT";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CCATEGORY";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PurchaseHistoryDetail Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 1;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ITEMNO
            /// </summary>
            public const int ItemNumber = 2;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 3;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 4;

            /// <summary>
            /// Property Indexer for TransactionDate
            /// </summary>
            public const int TransactionDate = 5;

            /// <summary>
            /// Property Indexer for DayEndNumber
            /// </summary>
            public const int DayEndNumber = 6;

            /// <summary>
            /// Property Indexer for TransactionSequence
            /// </summary>
            public const int TransactionSequence = 7;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 8;

            /// <summary>
            /// Property Indexer for HeaderSequence
            /// </summary>
            public const int HeaderSequence = 9;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 10;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 11;

            /// <summary>
            /// Property Indexer for DocumentNumber
            /// </summary>
            public const int DocumentNumber = 12;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 13;

            /// <summary>
            /// Property Indexer for QuantityRqPosted
            /// </summary>
            public const int QuantityRqPosted = 14;

            /// <summary>
            /// Property Indexer for StockingQuantitySqPosted
            /// </summary>
            public const int StockingQuantitySqPosted = 15;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 16;

            /// <summary>
            /// Property Indexer for ConversionFactor
            /// </summary>
            public const int ConversionFactor = 17;

            /// <summary>
            /// Property Indexer for SrceCost
            /// </summary>
            public const int SrceCost = 18;

            /// <summary>
            /// Property Indexer for FuncCost
            /// </summary>
            public const int FuncCost = 19;

            /// <summary>
            /// Property Indexer for DaysToReceive
            /// </summary>
            public const int DaysToReceive = 20;

            /// <summary>
            /// Property Indexer for TotalQuantity
            /// </summary>
            public const int TotalQuantity = 21;

            /// <summary>
            /// Property Indexer for StockingTotalQuantity
            /// </summary>
            public const int StockingTotalQuantity = 22;

            /// <summary>
            /// Property Indexer for SrceTotalCost
            /// </summary>
            public const int SrceTotalCost = 23;

            /// <summary>
            /// Property Indexer for FuncTotalCost
            /// </summary>
            public const int FuncTotalCost = 24;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 25;

            /// <summary>
            /// Property Indexer for FuncDiscountAmount
            /// </summary>
            public const int FuncDiscountAmount = 26;

            /// <summary>
            /// Property Indexer for TotalDiscount
            /// </summary>
            public const int TotalDiscount = 27;

            /// <summary>
            /// Property Indexer for FunctionalTotalDiscount
            /// </summary>
            public const int FunctionalTotalDiscount = 28;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 30;

            /// <summary>
            /// Property Indexer for VendorName
            /// </summary>
            public const int VendorName = 31;

            /// <summary>
            /// Property Indexer for EntryQuantityReceived
            /// </summary>
            public const int EntryQuantityReceived = 32;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 33;

            /// <summary>
            /// Property Indexer for FuncReceivedAmount
            /// </summary>
            public const int FuncReceivedAmount = 34;

            /// <summary>
            /// Property Indexer for SrceReceivedAmount
            /// </summary>
            public const int SrceReceivedAmount = 35;

            /// <summary>
            /// Property Indexer for EntryQuantityAdjonInvoices
            /// </summary>
            public const int EntryQuantityAdjonInvoices = 36;

            /// <summary>
            /// Property Indexer for QuantityAdjustedonInvoices
            /// </summary>
            public const int QuantityAdjustedonInvoices = 37;

            /// <summary>
            /// Property Indexer for FuncAdjustedonInvoices
            /// </summary>
            public const int FuncAdjustedonInvoices = 38;

            /// <summary>
            /// Property Indexer for SrceAdjustedonInvoices
            /// </summary>
            public const int SrceAdjustedonInvoices = 39;

            /// <summary>
            /// Property Indexer for EntryQuantityReturned
            /// </summary>
            public const int EntryQuantityReturned = 40;

            /// <summary>
            /// Property Indexer for QuantityReturned
            /// </summary>
            public const int QuantityReturned = 41;

            /// <summary>
            /// Property Indexer for FuncReturnAmount
            /// </summary>
            public const int FuncReturnAmount = 42;

            /// <summary>
            /// Property Indexer for SrceReturnAmount
            /// </summary>
            public const int SrceReturnAmount = 43;

            /// <summary>
            /// Property Indexer for EntryQuantityCredited
            /// </summary>
            public const int EntryQuantityCredited = 44;

            /// <summary>
            /// Property Indexer for QuantityCredited
            /// </summary>
            public const int QuantityCredited = 45;

            /// <summary>
            /// Property Indexer for FuncCreditNoteAmount
            /// </summary>
            public const int FuncCreditNoteAmount = 46;

            /// <summary>
            /// Property Indexer for SrceCreditNoteAmount
            /// </summary>
            public const int SrceCreditNoteAmount = 47;

            /// <summary>
            /// Property Indexer for EntryQuantityDebited
            /// </summary>
            public const int EntryQuantityDebited = 48;

            /// <summary>
            /// Property Indexer for QuantityDebited
            /// </summary>
            public const int QuantityDebited = 49;

            /// <summary>
            /// Property Indexer for FuncDebitNoteAmount
            /// </summary>
            public const int FuncDebitNoteAmount = 50;

            /// <summary>
            /// Property Indexer for SrceDebitNoteAmount
            /// </summary>
            public const int SrceDebitNoteAmount = 51;

            /// <summary>
            /// Property Indexer for EntryTotalQuantityInvoiced
            /// </summary>
            public const int EntryTotalQuantityInvoiced = 52;

            /// <summary>
            /// Property Indexer for TotalQuantityInvoiced
            /// </summary>
            public const int TotalQuantityInvoiced = 53;

            /// <summary>
            /// Property Indexer for FuncInvoiceTotal
            /// </summary>
            public const int FuncInvoiceTotal = 54;

            /// <summary>
            /// Property Indexer for SrceInvoiceTotal
            /// </summary>
            public const int SrceInvoiceTotal = 55;

            /// <summary>
            /// Property Indexer for EntryTotalQuantityCredited
            /// </summary>
            public const int EntryTotalQuantityCredited = 56;

            /// <summary>
            /// Property Indexer for TotalQuantityCredited
            /// </summary>
            public const int TotalQuantityCredited = 57;

            /// <summary>
            /// Property Indexer for FuncCreditNoteTotal
            /// </summary>
            public const int FuncCreditNoteTotal = 58;

            /// <summary>
            /// Property Indexer for SrceCreditNoteTotal
            /// </summary>
            public const int SrceCreditNoteTotal = 59;

            /// <summary>
            /// Property Indexer for EntryTotalQuantityDebited
            /// </summary>
            public const int EntryTotalQuantityDebited = 60;

            /// <summary>
            /// Property Indexer for TotalQuantityDebited
            /// </summary>
            public const int TotalQuantityDebited = 61;

            /// <summary>
            /// Property Indexer for FuncDebitNoteTotal
            /// </summary>
            public const int FuncDebitNoteTotal = 62;

            /// <summary>
            /// Property Indexer for SrceDebitNoteTotal
            /// </summary>
            public const int SrceDebitNoteTotal = 63;

            /// <summary>
            /// Property Indexer for QuantityRqDisplay
            /// </summary>
            public const int QuantityRqDisplay = 64;

            /// <summary>
            /// Property Indexer for StockingQuantitySqDisplay
            /// </summary>
            public const int StockingQuantitySqDisplay = 65;

            /// <summary>
            /// Property Indexer for FunctionalAmount
            /// </summary>
            public const int FunctionalAmount = 66;

            /// <summary>
            /// Property Indexer for SourceAmount
            /// </summary>
            public const int SourceAmount = 67;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for FMTITEMNO
            /// </summary>
            public const int FormattedItemNumber = 68;

            /// <summary>
            /// Property Indexer for SrceNetExtendedAmount
            /// </summary>
            public const int SrceNetExtendedAmount = 69;

            /// <summary>
            /// Property Indexer for FuncNetExtendedAmount
            /// </summary>
            public const int FuncNetExtendedAmount = 70;

            /// <summary>
            /// Property Indexer for SrceTotalNetCost
            /// </summary>
            public const int SrceTotalNetCost = 71;

            /// <summary>
            /// Property Indexer for FuncTotalNetCost
            /// </summary>
            public const int FuncTotalNetCost = 72;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 73;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 74;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 75;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 76;

        }

        #endregion
    }
}
