// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of Requisition Constants
    /// </summary>
    public partial class Requisition
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0760";

        /// <summary>
        /// Dynamic attributes contain a reverse mapping of field and property 
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"NEXTLSEQ", "NextLineSequence"},
					{"LINES", "Lines"},
					{"LINESCMPL", "LinesComplete"},
					{"LINESORDER", "LinesOrdered"},
					{"ISPRINTED", "Printed"},
					{"ISCOMPLETE", "Completed"},
					{"DTCOMPLETE", "DateCompleted"},
					{"POSTDATE", "LastPostingDate"},
					{"DATE", "RequisitionDate"},
					{"RQNNUMBER", "RequisitionNumber"},
					{"VDCODE", "Vendor"},
					{"VDEXISTS", "VendorExists"},
					{"VDNAME", "Name"},
					{"ONHOLD", "OnHold"},
					{"ORDEREDON", "OrderDate"},
					{"EXPARRIVAL", "DateRequired"},
					{"EXPIRATION", "ExpirationDate"},
					{"DESCRIPTIO", "Description"},
					{"REFERENCE", "Reference"},
					{"COMMENT", "Comment"},
					{"OQORDERED", "QuantityOrdered"},
					{"REQUESTBY", "Requestedby"},
					{"DOCSOURCE", "DocumentSource"},
					{"VALUES", "OptionalFields"},
					{"JOBLINES", "JobRelatedLines"},
					{"STCODE", "Location"},
					{"STDESC", "LocationDescription"},
					{"APPROVED", "ApprovalStatus"},
					{"APPROVER", "ApproverID"},
					{"ENTEREDBY", "EnteredBy"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"FCEXTENDED", "FuncExtendedAmount"},
					{"VDONHOLD", "VendorOnHold"},
					{"LOCKED", "DocumentLocked"},
					{"EXPIRED", "RequisitionHasExpired"},
					{"CANDELETE", "IsDocumentDeletable"},
					{"ISACTIVE", "IsRecordActive"},
					{"HASDETAILS", "HasDetails"},
					{"CPACTIVE", "IsCanadianPayrollActive"},
					{"UPACTIVE", "IsUSPayrollActive"},
					{"PROCESSCMD", "Command"},
					{"HASJOB", "JobRelated"},
					{"APPNAME", "ApproverName"},
					{"FCCURRENCY", "FunctionalCurrency"},
					{"DETAILNEXT", "NextDetailNumber"}
				};
            }
        }

        #region Properties
        /// <summary>
        /// Contains list of Requisition Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for RequisitionSequenceKey
            /// </summary>
            public const string RequisitionSequenceKey = "RQNHSEQ";

            /// <summary>
            /// Property for NextLineSequence
            /// </summary>
            public const string NextLineSequence = "NEXTLSEQ";

            /// <summary>
            /// Property for Lines
            /// </summary>
            public const string Lines = "LINES";

            /// <summary>
            /// Property for LinesComplete
            /// </summary>
            public const string LinesComplete = "LINESCMPL";

            /// <summary>
            /// Property for LinesOrdered
            /// </summary>
            public const string LinesOrdered = "LINESORDER";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "ISPRINTED";

            /// <summary>
            /// Property for Completed
            /// </summary>
            public const string Completed = "ISCOMPLETE";

            /// <summary>
            /// Property for DateCompleted
            /// </summary>
            public const string DateCompleted = "DTCOMPLETE";

            /// <summary>
            /// Property for LastPostingDate
            /// </summary>
            public const string LastPostingDate = "POSTDATE";

            /// <summary>
            /// Property for RequisitionDate
            /// </summary>
            public const string RequisitionDate = "DATE";

            /// <summary>
            /// Property for RequisitionNumber
            /// </summary>
            public const string RequisitionNumber = "RQNNUMBER";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VDCODE";

            /// <summary>
            /// Property for VendorExists
            /// </summary>
            public const string VendorExists = "VDEXISTS";

            /// <summary>
            /// Property for Name
            /// </summary>
            public const string Name = "VDNAME";

            /// <summary>
            /// Property for OnHold
            /// </summary>
            public const string OnHold = "ONHOLD";

            /// <summary>
            /// Property for OrderDate
            /// </summary>
            public const string OrderDate = "ORDEREDON";

            /// <summary>
            /// Property for DateRequired
            /// </summary>
            public const string DateRequired = "EXPARRIVAL";

            /// <summary>
            /// Property for ExpirationDate
            /// </summary>
            public const string ExpirationDate = "EXPIRATION";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESCRIPTIO";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for QuantityOrdered
            /// </summary>
            public const string QuantityOrdered = "OQORDERED";

            /// <summary>
            /// Property for Requestedby
            /// </summary>
            public const string Requestedby = "REQUESTBY";

            /// <summary>
            /// Property for DocumentSource
            /// </summary>
            public const string DocumentSource = "DOCSOURCE";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for JobRelatedLines
            /// </summary>
            public const string JobRelatedLines = "JOBLINES";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "STCODE";

            /// <summary>
            /// Property for LocationDescription
            /// </summary>
            public const string LocationDescription = "STDESC";

            /// <summary>
            /// Property for ApprovalStatus
            /// </summary>
            public const string ApprovalStatus = "APPROVED";

            /// <summary>
            /// Property for ApproverID
            /// </summary>
            public const string ApproverID = "APPROVER";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for FuncExtendedAmount
            /// </summary>
            public const string FuncExtendedAmount = "FCEXTENDED";

            /// <summary>
            /// Property for VendorOnHold
            /// </summary>
            public const string VendorOnHold = "VDONHOLD";

            /// <summary>
            /// Property for DocumentLocked
            /// </summary>
            public const string DocumentLocked = "LOCKED";

            /// <summary>
            /// Property for RequisitionHasExpired
            /// </summary>
            public const string RequisitionHasExpired = "EXPIRED";

            /// <summary>
            /// Property for IsDocumentDeletable
            /// </summary>
            public const string IsDocumentDeletable = "CANDELETE";

            /// <summary>
            /// Property for IsRecordActive
            /// </summary>
            public const string IsRecordActive = "ISACTIVE";

            /// <summary>
            /// Property for HasDetails
            /// </summary>
            public const string HasDetails = "HASDETAILS";

            /// <summary>
            /// Property for IsCanadianPayrollActive
            /// </summary>
            public const string IsCanadianPayrollActive = "CPACTIVE";

            /// <summary>
            /// Property for IsUSPayrollActive
            /// </summary>            
            // ReSharper disable once UnusedMember.Global
            // ReSharper disable once InconsistentNaming
            public const string IsUSPayrollActive = "UPACTIVE";

            /// <summary>
            /// Property for Command
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "HASJOB";

            /// <summary>
            /// Property for ApproverName
            /// </summary>
            public const string ApproverName = "APPNAME";

            /// <summary>
            /// Property for FunctionalCurrency
            /// </summary>
            public const string FunctionalCurrency = "FCCURRENCY";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "DETAILNEXT";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of Requisition Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for RequisitionSequenceKey
            /// </summary>
            public const int RequisitionSequenceKey = 1;

            /// <summary>
            /// Property Indexer for NextLineSequence
            /// </summary>
            public const int NextLineSequence = 2;

            /// <summary>
            /// Property Indexer for Lines
            /// </summary>
            public const int Lines = 3;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 4;

            /// <summary>
            /// Property Indexer for LinesOrdered
            /// </summary>
            public const int LinesOrdered = 5;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 6;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 7;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 8;

            /// <summary>
            /// Property Indexer for LastPostingDate
            /// </summary>
            public const int LastPostingDate = 9;

            /// <summary>
            /// Property Indexer for RequisitionDate
            /// </summary>
            public const int RequisitionDate = 10;

            /// <summary>
            /// Property Indexer for RequisitionNumber
            /// </summary>
            public const int RequisitionNumber = 11;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 12;

            /// <summary>
            /// Property Indexer for VendorExists
            /// </summary>
            public const int VendorExists = 13;

            /// <summary>
            /// Property Indexer for Name
            /// </summary>
            public const int Name = 14;

            /// <summary>
            /// Property Indexer for OnHold
            /// </summary>
            public const int OnHold = 15;

            /// <summary>
            /// Property Indexer for OrderDate
            /// </summary>
            public const int OrderDate = 16;

            /// <summary>
            /// Property Indexer for DateRequired
            /// </summary>
            public const int DateRequired = 17;

            /// <summary>
            /// Property Indexer for ExpirationDate
            /// </summary>
            public const int ExpirationDate = 18;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 19;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 20;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 21;

            /// <summary>
            /// Property Indexer for QuantityOrdered
            /// </summary>
            public const int QuantityOrdered = 29;

            /// <summary>
            /// Property Indexer for Requestedby
            /// </summary>
            public const int Requestedby = 30;

            /// <summary>
            /// Property Indexer for DocumentSource
            /// </summary>
            public const int DocumentSource = 31;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 32;

            /// <summary>
            /// Property Indexer for JobRelatedLines
            /// </summary>
            public const int JobRelatedLines = 33;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 121;

            /// <summary>
            /// Property Indexer for LocationDescription
            /// </summary>
            public const int LocationDescription = 122;

            /// <summary>
            /// Property Indexer for ApprovalStatus
            /// </summary>
            public const int ApprovalStatus = 131;

            /// <summary>
            /// Property Indexer for ApproverID
            /// </summary>
            public const int ApproverID = 132;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 139;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 141;

            /// <summary>
            /// Property Indexer for FuncExtendedAmount
            /// </summary>
            public const int FuncExtendedAmount = 142;

            /// <summary>
            /// Property Indexer for VendorOnHold
            /// </summary>
            public const int VendorOnHold = 151;

            /// <summary>
            /// Property Indexer for DocumentLocked
            /// </summary>
            public const int DocumentLocked = 152;

            /// <summary>
            /// Property Indexer for RequisitionHasExpired
            /// </summary>
            public const int RequisitionHasExpired = 153;

            /// <summary>
            /// Property Indexer for IsDocumentDeletable
            /// </summary>
            public const int IsDocumentDeletable = 154;

            /// <summary>
            /// Property Indexer for IsRecordActive
            /// </summary>
            public const int IsRecordActive = 155;

            /// <summary>
            /// Property Indexer for HasDetails
            /// </summary>
            public const int HasDetails = 156;

            /// <summary>
            /// Property Indexer for IsCanadianPayrollActive
            /// </summary>
            public const int IsCanadianPayrollActive = 157;

            /// <summary>
            /// Property Indexer for IsUSPayrollActive
            /// </summary>            
            // ReSharper disable once InconsistentNaming
            public const int IsUSPayrollActive = 158;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 159;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 160;

            /// <summary>
            /// Property Indexer for ApproverName
            /// </summary>
            public const int ApproverName = 161;

            /// <summary>
            /// Property Indexer for FunctionalCurrency
            /// </summary>
            public const int FunctionalCurrency = 162;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 163;
        }

        /// <summary>
        /// Order Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Requisition Key
            /// </summary>
            public const int RequisitionSequenceKey = 0;

            /// <summary>
            /// Requisition Number Key
            /// </summary>
            public const int RequisitionNumber = 1;
        }
        #endregion
    }
}