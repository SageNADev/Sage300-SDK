// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace

{
     /// <summary>
     /// Contains list of Cost Constants
     /// </summary>
     public partial class Cost
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0297";

          #region Properties
          /// <summary>
          /// Contains list of Cost Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Sequence
               /// </summary>
               public const string Sequence = "SEQUENCE";

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for TaxGroup
               /// </summary>
               public const string TaxGroup = "TAXGROUP";

               /// <summary>
               /// Property for TaxAuthority1
               /// </summary>
               public const string TaxAuthority1 = "TAXAUTH1";

               /// <summary>
               /// Property for TaxAuthority2
               /// </summary>
               public const string TaxAuthority2 = "TAXAUTH2";

               /// <summary>
               /// Property for TaxAuthority3
               /// </summary>
               public const string TaxAuthority3 = "TAXAUTH3";

               /// <summary>
               /// Property for TaxAuthority4
               /// </summary>
               public const string TaxAuthority4 = "TAXAUTH4";

               /// <summary>
               /// Property for TaxAuthority5
               /// </summary>
               public const string TaxAuthority5 = "TAXAUTH5";

               /// <summary>
               /// Property for VendorTaxClass1
               /// </summary>
               public const string VendorTaxClass1 = "TAXVCLASS1";

               /// <summary>
               /// Property for VendorTaxClass2
               /// </summary>
               public const string VendorTaxClass2 = "TAXVCLASS2";

               /// <summary>
               /// Property for VendorTaxClass3
               /// </summary>
               public const string VendorTaxClass3 = "TAXVCLASS3";

               /// <summary>
               /// Property for VendorTaxClass4
               /// </summary>
               public const string VendorTaxClass4 = "TAXVCLASS4";

               /// <summary>
               /// Property for VendorTaxClass5
               /// </summary>
               public const string VendorTaxClass5 = "TAXVCLASS5";

               /// <summary>
               /// Property for CostTaxClass1
               /// </summary>
               public const string CostTaxClass1 = "TAXICLASS1";

               /// <summary>
               /// Property for CostTaxClass2
               /// </summary>
               public const string CostTaxClass2 = "TAXICLASS2";

               /// <summary>
               /// Property for CostTaxClass3
               /// </summary>
               public const string CostTaxClass3 = "TAXICLASS3";

               /// <summary>
               /// Property for CostTaxClass4
               /// </summary>
               public const string CostTaxClass4 = "TAXICLASS4";

               /// <summary>
               /// Property for CostTaxClass5
               /// </summary>
               public const string CostTaxClass5 = "TAXICLASS5";

               /// <summary>
               /// Property for TaxIncludable1
               /// </summary>
               public const string TaxIncludable1 = "TAXINCLUD1";

               /// <summary>
               /// Property for TaxIncludable2
               /// </summary>
               public const string TaxIncludable2 = "TAXINCLUD2";

               /// <summary>
               /// Property for TaxIncludable3
               /// </summary>
               public const string TaxIncludable3 = "TAXINCLUD3";

               /// <summary>
               /// Property for TaxIncludable4
               /// </summary>
               public const string TaxIncludable4 = "TAXINCLUD4";

               /// <summary>
               /// Property for TaxIncludable5
               /// </summary>
               public const string TaxIncludable5 = "TAXINCLUD5";

               /// <summary>
               /// Property for ContractDate
               /// </summary>
               public const string ContractDate = "QUERYDATE";

               /// <summary>
               /// Property for UnitCost
               /// </summary>
               public const string UnitCost = "UNITCOST";

               /// <summary>
               /// Property for CostingunitOfmeasure
               /// </summary>
               public const string CostingunitOfmeasure = "COSTUNIT";

               /// <summary>
               /// Property for Currency
               /// </summary>
               public const string Currency = "CURRENCY";

               /// <summary>
               /// Property for ExchangeRate
               /// </summary>
               public const string ExchangeRate = "RATE";

               /// <summary>
               /// Property for RateOperation
               /// </summary>
               public const string RateOperation = "RATEOPER";

               /// <summary>
               /// Property for Vendor
               /// </summary>
               public const string Vendor = "VDCODE";

               /// <summary>
               /// Property for QuantityFrom
               /// </summary>
               public const string QuantityFrom = "QTYFROM";

               /// <summary>
               /// Property for QuantityTo
               /// </summary>
               public const string QuantityTo = "QTYTO";

               /// <summary>
               /// Property for CostType
               /// </summary>
               public const string CostType = "COSTTYPE";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of Cost Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Sequence
               /// </summary>
               public const int Sequence = 1;

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 2;

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 3;

               /// <summary>
               /// Property Indexer for TaxGroup
               /// </summary>
               public const int TaxGroup = 4;

               /// <summary>
               /// Property Indexer for TaxAuthority1
               /// </summary>
               public const int TaxAuthority1 = 5;

               /// <summary>
               /// Property Indexer for TaxAuthority2
               /// </summary>
               public const int TaxAuthority2 = 6;

               /// <summary>
               /// Property Indexer for TaxAuthority3
               /// </summary>
               public const int TaxAuthority3 = 7;

               /// <summary>
               /// Property Indexer for TaxAuthority4
               /// </summary>
               public const int TaxAuthority4 = 8;

               /// <summary>
               /// Property Indexer for TaxAuthority5
               /// </summary>
               public const int TaxAuthority5 = 9;

               /// <summary>
               /// Property Indexer for VendorTaxClass1
               /// </summary>
               public const int VendorTaxClass1 = 10;

               /// <summary>
               /// Property Indexer for VendorTaxClass2
               /// </summary>
               public const int VendorTaxClass2 = 11;

               /// <summary>
               /// Property Indexer for VendorTaxClass3
               /// </summary>
               public const int VendorTaxClass3 = 12;

               /// <summary>
               /// Property Indexer for VendorTaxClass4
               /// </summary>
               public const int VendorTaxClass4 = 13;

               /// <summary>
               /// Property Indexer for VendorTaxClass5
               /// </summary>
               public const int VendorTaxClass5 = 14;

               /// <summary>
               /// Property Indexer for CostTaxClass1
               /// </summary>
               public const int CostTaxClass1 = 15;

               /// <summary>
               /// Property Indexer for CostTaxClass2
               /// </summary>
               public const int CostTaxClass2 = 16;

               /// <summary>
               /// Property Indexer for CostTaxClass3
               /// </summary>
               public const int CostTaxClass3 = 17;

               /// <summary>
               /// Property Indexer for CostTaxClass4
               /// </summary>
               public const int CostTaxClass4 = 18;

               /// <summary>
               /// Property Indexer for CostTaxClass5
               /// </summary>
               public const int CostTaxClass5 = 19;

               /// <summary>
               /// Property Indexer for TaxIncludable1
               /// </summary>
               public const int TaxIncludable1 = 20;

               /// <summary>
               /// Property Indexer for TaxIncludable2
               /// </summary>
               public const int TaxIncludable2 = 21;

               /// <summary>
               /// Property Indexer for TaxIncludable3
               /// </summary>
               public const int TaxIncludable3 = 22;

               /// <summary>
               /// Property Indexer for TaxIncludable4
               /// </summary>
               public const int TaxIncludable4 = 23;

               /// <summary>
               /// Property Indexer for TaxIncludable5
               /// </summary>
               public const int TaxIncludable5 = 24;

               /// <summary>
               /// Property Indexer for ContractDate
               /// </summary>
               public const int ContractDate = 25;

               /// <summary>
               /// Property Indexer for UnitCost
               /// </summary>
               public const int UnitCost = 26;

               /// <summary>
               /// Property Indexer for CostingunitOfmeasure
               /// </summary>
               public const int CostingunitOfmeasure = 27;

               /// <summary>
               /// Property Indexer for Currency
               /// </summary>
               public const int Currency = 28;

               /// <summary>
               /// Property Indexer for ExchangeRate
               /// </summary>
               public const int ExchangeRate = 29;

               /// <summary>
               /// Property Indexer for RateOperation
               /// </summary>
               public const int RateOperation = 30;

               /// <summary>
               /// Property Indexer for Vendor
               /// </summary>
               public const int Vendor = 31;

               /// <summary>
               /// Property Indexer for QuantityFrom
               /// </summary>
               public const int QuantityFrom = 32;

               /// <summary>
               /// Property Indexer for QuantityTo
               /// </summary>
               public const int QuantityTo = 33;

               /// <summary>
               /// Property Indexer for CostType
               /// </summary>
               public const int CostType = 34;

          }
          #endregion

     }
}
