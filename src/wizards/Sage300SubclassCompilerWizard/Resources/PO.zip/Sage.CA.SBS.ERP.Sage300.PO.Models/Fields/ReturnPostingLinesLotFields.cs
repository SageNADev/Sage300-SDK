// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Contains list of Return Posting Lines Lot Constants
	/// </summary>
	public partial class ReturnPostingLinesLot
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "PO0828";

		#region Properties

		/// <summary>
		/// Contains list of ReturnPostingLinesLot Field Constants
		/// </summary>
		public class Fields
		{
			/// <summary>
			/// Property for HeaderSequence
			/// </summary>
			public const string HeaderSequence = "CRNISEQ";

			/// <summary>
			/// Property for CreditDebitNoteSequenceKey
			/// </summary>
			public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

			/// <summary>
			/// Property for CreditDebitNoteLineSequence
			/// </summary>
			public const string CreditDebitNoteLineSequence = "CRNLSEQ";

			/// <summary>
			/// Property for LotNumber
			/// </summary>
			public const string LotNumber = "LOTNUMF";

			/// <summary>
			/// Property for OldQuantity
			/// </summary>
			public const string OldQuantity = "RQPREV";

			/// <summary>
			/// Property for CurrentQuantity
			/// </summary>
			public const string CurrentQuantity = "RQCURR";

			/// <summary>
			/// Property for OldStockQuantity
			/// </summary>
			public const string OldStockQuantity = "SQPREV";

			/// <summary>
			/// Property for CurrentStockQuantity
			/// </summary>
			public const string CurrentStockQuantity = "SQCURR";

			/// <summary>
			/// Property for OperationToPost
			/// </summary>
			public const string OperationToPost = "OPERATION";
		}
		#endregion

		#region Properties
		/// <summary>
		/// Contains list of ReturnPostingLinesLot Index Constants
		/// </summary>
		public class Index
		{
			/// <summary>
			/// Property Indexer for HeaderSequence
			/// </summary>
			public const int HeaderSequence = 1;

			/// <summary>
			/// Property Indexer for CreditDebitNoteSequenceKey
			/// </summary>
			public const int CreditDebitNoteSequenceKey = 2;

			/// <summary>
			/// Property Indexer for CreditDebitNoteLineSequence
			/// </summary>
			public const int CreditDebitNoteLineSequence = 3;

			/// <summary>
			/// Property Indexer for LotNumber
			/// </summary>
			public const int LotNumber = 4;

			/// <summary>
			/// Property Indexer for OldQuantity
			/// </summary>
			public const int OldQuantity = 5;

			/// <summary>
			/// Property Indexer for CurrentQuantity
			/// </summary>
			public const int CurrentQuantity = 6;

			/// <summary>
			/// Property Indexer for OldStockQuantity
			/// </summary>
			public const int OldStockQuantity = 7;

			/// <summary>
			/// Property Indexer for CurrentStockQuantity
			/// </summary>
			public const int CurrentStockQuantity = 8;

			/// <summary>
			/// Property Indexer for OperationToPost
			/// </summary>
			public const int OperationToPost = 9;
		}
		#endregion
	}
}