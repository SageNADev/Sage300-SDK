// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of ReturnPostingLinesSerial Constants
    /// </summary>
    public partial class ReturnPostingLinesSerial
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0821";

        #region Properties

        /// <summary>
        /// Contains list of ReturnPostingLinesSerial Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for HeaderSequence
            /// </summary>
            public const string HeaderSequence = "CRNISEQ";

            /// <summary>
            /// Property for CreditDebitNoteSequenceKey
            /// </summary>
            public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

            /// <summary>
            /// Property for CreditDebitNoteLineSequence
            /// </summary>
            public const string CreditDebitNoteLineSequence = "CRNLSEQ";

            /// <summary>
            /// Property for SerialNumber
            /// </summary>
            public const string SerialNumber = "SERIALNUMF";

            /// <summary>
            /// Property for OperationToPost
            /// </summary>
            public const string OperationToPost = "OPERATION";

            /// <summary>
            /// Property for SerialCount
            /// </summary>
            public const string SerialCount = "SCOUNT";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of ReturnPostingLinesSerial Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for HeaderSequence
            /// </summary>
            public const int HeaderSequence = 1;

            /// <summary>
            /// Property Indexer for CreditDebitNoteSequenceKey
            /// </summary>
            public const int CreditDebitNoteSequenceKey = 2;

            /// <summary>
            /// Property Indexer for CreditDebitNoteLineSequence
            /// </summary>
            public const int CreditDebitNoteLineSequence = 3;

            /// <summary>
            /// Property Indexer for SerialNumber
            /// </summary>
            public const int SerialNumber = 4;

            /// <summary>
            /// Property Indexer for OperationToPost
            /// </summary>
            public const int OperationToPost = 5;

            /// <summary>
            /// Property Indexer for SerialCount
            /// </summary>
            public const int SerialCount = 50;
        }
        #endregion
    }
}