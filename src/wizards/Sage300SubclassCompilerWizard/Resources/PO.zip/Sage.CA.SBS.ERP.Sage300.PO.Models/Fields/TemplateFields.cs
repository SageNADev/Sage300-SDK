// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseOrderTemplate Constants
    /// </summary>
    public partial class Template
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0605";

        #region Properties
        /// <summary>
        /// Contains list of PurchaseOrderTemplate Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for TemplateCode
            /// </summary>
            public const string TemplateCode = "TEMPLATE";

            /// <summary>
            /// Property for TemplateDescription
            /// </summary>
            public const string TemplateDescription = "PLATEDESC";

            /// <summary>
            /// Property for PurchaseOrderType
            /// </summary>
            public const string PurchaseOrderType = "ORDTYPE";

            /// <summary>
            /// Property for PurchaseOrderType string
            /// </summary>
            public const string PurchaseOrderTypeString = "ORDTYPE";

            /// <summary>
            /// Property for FOBPoint
            /// </summary>
            public const string FOBPoint = "FOB";

            /// <summary>
            /// Property for OnHold
            /// </summary>
            public const string OnHold = "ONHOLD";

            /// <summary>
            /// Property for OnHold string
            /// </summary>
            public const string OnHoldString = "ONHOLD";

            /// <summary>
            /// Property for ShipToLocation
            /// </summary>
            public const string ShipToLocation = "STLOC";

            /// <summary>
            /// Property for BillToLocation
            /// </summary>
            public const string BillToLocation = "BTLOC";

            /// <summary>
            /// Property for DESC
            /// </summary>
            public const string Description = "DESC";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for ShipVia
            /// </summary>
            public const string ShipVia = "SHIPVIA";

            /// <summary>
            /// Property for TaxGroup
            /// </summary>
            public const string TaxGroup = "TAXGROUP";

            /// <summary>
            /// Property for TermsCode
            /// </summary>
            public const string TermsCode = "TERMS";

            /// <summary>
            /// Property for ShipViaName
            /// </summary>
            public const string ShipViaName = "SHPVIADESC";

            /// <summary>
            /// Property for TermsCodeDescription
            /// </summary>
            public const string TermsCodeDescription = "TERMSDESC";

            /// <summary>
            /// Property for TaxGroupDescription
            /// </summary>
            public const string TaxGroupDescription = "TXGRPDESC";

            /// <summary>
            /// Property for ShipToLocationDescription
            /// </summary>
            public const string ShipToLocationDescription = "STLOCDESC";

            /// <summary>
            /// Property for BillToLocationDescription
            /// </summary>
            public const string BillToLocationDescription = "BTLOCDESC";

            /// <summary>
            /// Property for TaxGroupCurrency
            /// </summary>
            public const string TaxGroupCurrency = "CURRENCYTG";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of PurchaseOrderTemplate Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for TemplateCode
            /// </summary>
            public const int TemplateCode = 1;

            /// <summary>
            /// Property Indexer for TemplateDescription
            /// </summary>
            public const int TemplateDescription = 2;

            /// <summary>
            /// Property Indexer for PurchaseOrderType
            /// </summary>
            public const int PurchaseOrderType = 3;

            /// <summary>
            /// Property Indexer for PurchaseOrderType String
            /// </summary>
            public const int PurchaseOrderTypeString = 3;

            /// <summary>
            /// Property Indexer for FOBPoint
            /// </summary>
            public const int FOBPoint = 4;

            /// <summary>
            /// Property Indexer for OnHold
            /// </summary>
            public const int OnHold = 5;

            /// <summary>
            /// Property Indexer for OnHold String
            /// </summary>
            public const int OnHoldString = 5;

            /// <summary>
            /// Property Indexer for ShipToLocation
            /// </summary>
            public const int ShipToLocation = 6;

            /// <summary>
            /// Property Indexer for BillToLocation
            /// </summary>
            public const int BillToLocation = 7;

            /// <summary>
            /// Property Indexer for DESC
            /// </summary>
            public const int Description = 8;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 9;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 10;

            /// <summary>
            /// Property Indexer for ShipVia
            /// </summary>
            public const int ShipVia = 11;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 12;

            /// <summary>
            /// Property Indexer for TermsCode
            /// </summary>
            public const int TermsCode = 13;

            /// <summary>
            /// Property Indexer for ShipViaName
            /// </summary>
            public const int ShipViaName = 25;

            /// <summary>
            /// Property Indexer for TermsCodeDescription
            /// </summary>
            public const int TermsCodeDescription = 26;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 27;

            /// <summary>
            /// Property Indexer for ShipToLocationDescription
            /// </summary>
            public const int ShipToLocationDescription = 28;

            /// <summary>
            /// Property Indexer for BillToLocationDescription
            /// </summary>
            public const int BillToLocationDescription = 29;

            /// <summary>
            /// Property Indexer for TaxGroupCurrency
            /// </summary>
            public const int TaxGroupCurrency = 30;

        }
        #endregion

    }
}
