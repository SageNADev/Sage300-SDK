// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of ReturnLineSerial Constants
     /// </summary>
     public partial class ReturnLineSerial
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0790";

          #region Properties
          /// <summary>
          /// Contains list of ReturnLineSerial Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for ReturnSequenceKey
               /// </summary>
               public const string ReturnSequenceKey = "RETHSEQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "RETLREV";

               /// <summary>
               /// Property for SerialNumber
               /// </summary>
               public const string SerialNumber = "SERIALNUMF";

               /// <summary>
               /// Property for ReturnLineSequence
               /// </summary>
               public const string ReturnLineSequence = "RETLSEQ";

               /// <summary>
               /// Property for Returned
               /// </summary>
               public const string Returned = "MOVED";

               /// <summary>
               /// Property for SerialCount
               /// </summary>
               public const string SerialCount = "SCOUNT";
          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of ReturnLineSerial Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for ReturnSequenceKey
               /// </summary>
               public const int ReturnSequenceKey = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for SerialNumber
               /// </summary>
               public const int SerialNumber = 3;

               /// <summary>
               /// Property Indexer for ReturnLineSequence
               /// </summary>
               public const int ReturnLineSequence = 4;

               /// <summary>
               /// Property Indexer for Returned
               /// </summary>
               public const int Returned = 5;

               /// <summary>
               /// Property Indexer for SerialCount
               /// </summary>
               public const int SerialCount = 50;
          }
          #endregion
     }
}