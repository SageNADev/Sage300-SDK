// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptFunction Constants
    /// </summary>
    public partial class ReceiptFunction
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0699";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"LOADSEQ", "SequenceToRetrieve"}
				};
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ReceiptFunction Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for SequenceToRetrieve
            /// </summary>
            public const string SequenceToRetrieve = "LOADSEQ";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "LOADPORNUM";

            /// <summary>
            /// Property for TemplateCode
            /// </summary>
            public const string TemplateCode = "TEMPLATE";

            /// <summary>
            /// Property for PredecessorTimestamp
            /// </summary>
            public const string PredecessorTimestamp = "PREADTSTMP";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for DistributionReferencesExist
            /// </summary>
            public const string DistributionReferencesExist = "DISTREFS";

            /// <summary>
            /// Property for AmountDistributionRefsExist
            /// </summary>
            public const string AmountDistributionRefsExist = "AMTDSTREFS";

            /// <summary>
            /// Property for BillingRateDistrRefsExist
            /// </summary>
            public const string BillingRateDistrRefsExist = "BRTDSTREFS";

            /// <summary>
            /// Property for AmountProrateable
            /// </summary>
            public const string AmountProrateable = "AMTPRORAT";

            /// <summary>
            /// Property for BillingRateProrateable
            /// </summary>
            public const string BillingRateProrateable = "BRTPRORAT";

            /// <summary>
            /// Property for LineNodeFound
            /// </summary>
            public const string LineNodeFound = "FOUND";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ReceiptFunction Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for SequenceToRetrieve
            /// </summary>
            public const int SequenceToRetrieve = 2;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 3;

            /// <summary>
            /// Property Indexer for TemplateCode
            /// </summary>
            public const int TemplateCode = 4;

            /// <summary>
            /// Property Indexer for PredecessorTimestamp
            /// </summary>
            public const int PredecessorTimestamp = 5;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 6;

            /// <summary>
            /// Property Indexer for DistributionReferencesExist
            /// </summary>
            public const int DistributionReferencesExist = 7;

            /// <summary>
            /// Property Indexer for AmountDistributionRefsExist
            /// </summary>
            public const int AmountDistributionRefsExist = 8;

            /// <summary>
            /// Property Indexer for BillingRateDistrRefsExist
            /// </summary>
            public const int BillingRateDistrRefsExist = 9;

            /// <summary>
            /// Property Indexer for AmountProrateable
            /// </summary>
            public const int AmountProrateable = 10;

            /// <summary>
            /// Property Indexer for BillingRateProrateable
            /// </summary>
            public const int BillingRateProrateable = 11;

            /// <summary>
            /// Property Indexer for LineNodeFound
            /// </summary>
            public const int LineNodeFound = 12;

        }

        #endregion

    }
}