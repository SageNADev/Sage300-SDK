// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Contains list of DuplicateCreditDebitNote Constants
	/// </summary>
	public partial class DuplicateCreditDebitNote
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "PO0308";

		#region Properties

		/// <summary>
		/// Contains list of DuplicateCreditDebitNote Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for CreditDebitNoteSequenceKey
			/// </summary>
			public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

			/// <summary>
			/// Property for CreditDebitNoteNumber
			/// </summary>
			public const string CreditDebitNoteNumber = "CRNNUMBER";

			/// <summary>
			/// Property for RequireNewEntry
			/// </summary>
			public const string RequireNewEntry = "REQUIRENEW";

			/// <summary>
			/// Property for Vendor
			/// </summary>
			public const string Vendor = "VDCODE";

			/// <summary>
			/// Property for Date
			/// </summary>
			public const string Date = "DOCDATE";

			/// <summary>
			/// Property for Total
			/// </summary>
			public const string Total = "DOCTOTAL";

			/// <summary>
			/// Property for NumberOfDuplicates
			/// </summary>
			public const string NumberOfDuplicates = "DUPLICATES";

			/// <summary>
			/// Property for Function
			/// </summary>
			public const string Function = "FUNCTION";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of DuplicateCreditDebitNote Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for CreditDebitNoteSequenceKey
			/// </summary>
			public const int CreditDebitNoteSequenceKey = 1;

			/// <summary>
			/// Property Indexer for CreditDebitNoteNumber
			/// </summary>
			public const int CreditDebitNoteNumber = 2;

			/// <summary>
			/// Property Indexer for RequireNewEntry
			/// </summary>
			public const int RequireNewEntry = 3;

			/// <summary>
			/// Property Indexer for Vendor
			/// </summary>
			public const int Vendor = 4;

			/// <summary>
			/// Property Indexer for Date
			/// </summary>
			public const int Date = 5;

			/// <summary>
			/// Property Indexer for Total
			/// </summary>
			public const int Total = 6;

			/// <summary>
			/// Property Indexer for NumberOfDuplicates
			/// </summary>
			public const int NumberOfDuplicates = 7;

			/// <summary>
			/// Property Indexer for Function
			/// </summary>
			public const int Function = 8;

		}

		#endregion

	}
}
