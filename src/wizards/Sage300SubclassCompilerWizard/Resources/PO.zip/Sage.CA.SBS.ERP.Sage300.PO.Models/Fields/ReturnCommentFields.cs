// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of ReturnComment Constants
     /// </summary>
     public partial class ReturnComment
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0729";

          #region Properties
          /// <summary>
          /// Contains list of Return Comment Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for ReturnSequenceKey
               /// </summary>
               public const string ReturnSequenceKey = "RETHSEQ";

               /// <summary>
               /// Property for CommentIdentifier
               /// </summary>
               public const string CommentIdentifier = "RETCREV";

               /// <summary>
               /// Property for ReturnCommentSequence
               /// </summary>
               public const string ReturnCommentSequence = "RETCSEQ";

               /// <summary>
               /// Property for StoredInDatabaseTable
               /// </summary>
               public const string StoredInDatabaseTable = "INDBTABLE";

               /// <summary>
               /// Property for LineType
               /// </summary>
               public const string LineType = "COMMENTTYP";

               /// <summary>
               /// Property for Comment
               /// </summary>
               public const string Comment = "COMMENT";
          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of Return Comment Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for ReturnSequenceKey
               /// </summary>
               public const int ReturnSequenceKey = 1;

               /// <summary>
               /// Property Indexer for CommentIdentifier
               /// </summary>
               public const int CommentIdentifier = 2;

               /// <summary>
               /// Property Indexer for ReturnCommentSequence
               /// </summary>
               public const int ReturnCommentSequence = 3;

               /// <summary>
               /// Property Indexer for StoredInDatabaseTable
               /// </summary>
               public const int StoredInDatabaseTable = 4;

               /// <summary>
               /// Property Indexer for LineType
               /// </summary>
               public const int LineType = 5;

               /// <summary>
               /// Property Indexer for Comment
               /// </summary>
               public const int Comment = 6;
          }
          #endregion
     }
}