// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of PO OptionalField Constants
     /// </summary>
    public partial class OptionalFieldDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "PO0580";

          #region Properties

          /// <summary>
          /// Contains list of PO OptionalField Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for OptionalField
               /// </summary>
               public const string OptionalField = "OPTFIELD";

               /// <summary>
               /// Property for DefaultValue
               /// </summary>
               public const string DefaultValue = "DEFVAL";

               /// <summary>
               /// Property for Type
               /// </summary>
               public const string Type = "TYPE";

               /// <summary>
               /// Property for Type String
               /// </summary>
               public const string TypeString = "TYPE";

               /// <summary>
               /// Property for Length
               /// </summary>
               public const string Length = "LENGTH";

               /// <summary>
               /// Property for Decimals
               /// </summary>
               public const string Decimals = "DECIMALS";

               /// <summary>
               /// Property for AllowBlank
               /// </summary>
               public const string AllowBlank = "ALLOWNULL";

               /// <summary>
               /// Property for Validate
               /// </summary>
               public const string Validate = "VALIDATE";

               /// <summary>
               /// Property for AutoInsert
               /// </summary>
               public const string AutoInsert = "INITFLAG";

               /// <summary>
               /// Property for ExternalCostTransactions
               /// </summary>
               public const string ExternalCostTransactions = "SWPM";
            
               /// <summary>
               /// Property for PayablesClearing
               /// </summary>
               public const string PayablesClearing = "SWPAYCLRPO";
         
               /// <summary>
               /// Property for PayablesClearing1
               /// </summary>
               public const string PayablesClearing1 = "SWPAYCLRAP";

               /// <summary>
               /// Property for InventoryControl
               /// </summary>
               public const string InventoryControl = "SWICCTL";

               /// <summary>
               /// Property for NonStockClearing
               /// </summary>
               public const string NonStockClearing = "SWNSCLR";
         
               /// <summary>
               /// Property for NonInventoryPayablesClearing
               /// </summary>
               public const string NonInventoryPayablesClearing = "SWNIPCLRPO";
            
               /// <summary>
               /// Property for NonInventoryPayablesClearing1
               /// </summary>
               public const string NonInventoryPayablesClearing1 = "SWNIPCLRAP";
          
               /// <summary>
               /// Property for NonInventoryExpense
               /// </summary>
               public const string NonInventoryExpense = "SWNIEXPPO";
            
               /// <summary>
               /// Property for NonInventoryExpense1
               /// </summary>
               public const string NonInventoryExpense1 = "SWNIEXPAP";
           
               /// <summary>
               /// Property for AdditionalCostExpense
               /// </summary>
               public const string AdditionalCostExpense = "SWACEXPPO";
             
               /// <summary>
               /// Property for AdditionalCostExpense1
               /// </summary>
               public const string AdditionalCostExpense1 = "SWACEXPAP";

               /// <summary>
               /// Property for InvoicesOptionalFields
               /// </summary>
               public const string InvoicesOptionalFields = "SWAPINV";

               /// <summary>
               /// Property for Labor
               /// </summary>
               public const string Labor = "SWPMLABOR";

               /// <summary>
               /// Property for Overhead
               /// </summary>
               public const string Overhead = "SWPMOH";
              
               /// <summary>
               /// Property for AdditionalCostExpensePayablesClearing
               /// </summary>
               public const string AdditionalCostExpensePayablesClearing = "SWACPCLRPO";
              
               /// <summary>
               /// Property for AdditionalCostExpensePayablesClearing1
               /// </summary>
               public const string AdditionalCostExpensePayablesClearing1 = "SWACPCLRAP";

               /// <summary>
               /// Property for Required
               /// </summary>
               public const string Required = "SWREQUIRED";

               /// <summary>
               /// Property for ValueSet
               /// </summary>
               public const string ValueSet = "SWSET";

               /// <summary>
               /// Property for TypedDefaultValueFieldIndex
               /// </summary>
               public const string TypedDefaultValueFieldIndex = "DVINDEX";

               /// <summary>
               /// Property for DefaultTextValue
               /// </summary>
               public const string DefaultTextValue = "DVIFTEXT";

               /// <summary>
               /// Property for DefaultMoneyValue
               /// </summary>
               public const string DefaultAmountValue = "DVIFMONEY";

               /// <summary>
               /// Property for DefaultNumberValue
               /// </summary>
               public const string DefaultNumberValue = "DVIFNUM";

               /// <summary>
               /// Property for DefaultIntegerValue
               /// </summary>
               public const string DefaultIntegerValue = "DVIFLONG";

               /// <summary>
               /// Property for DefaultYesNoValue
               /// </summary>
               public const string DefaultYesNoValue = "DVIFBOOL";

               /// <summary>
               /// Property for DefaultDateValue
               /// </summary>
               public const string DefaultDateValue = "DVIFDATE";

               /// <summary>
               /// Property for DefaultTimeValue
               /// </summary>
               public const string DefaultTimeValue = "DVIFTIME";

               /// <summary>
               /// Property for OptionalFieldDescription
               /// </summary>
               public const string OptionalFieldDescription = "FDESC";

               /// <summary>
               /// Property for DefaultValueDescription
               /// </summary>
               public const string DefaultValueDescription = "VDESC";
          }

          #endregion

          #region Properties

          /// <summary>
          /// Contains list of PO OptionalField Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for OptionalField
               /// </summary>
               public const int OptionalField = 2;

               /// <summary>
               /// Property Indexer for DefaultValue
               /// </summary>
               public const int DefaultValue = 3;

               /// <summary>
               /// Property Indexer for Type
               /// </summary>
               public const int Type = 4;

               /// <summary>
               /// Property Indexer for Length
               /// </summary>
               public const int Length = 5;

               /// <summary>
               /// Property Indexer for Decimals
               /// </summary>
               public const int Decimals = 6;

               /// <summary>
               /// Property Indexer for AllowBlank
               /// </summary>
               public const int AllowBlank = 7;

               /// <summary>
               /// Property Indexer for Validate
               /// </summary>
               public const int Validate = 8;

               /// <summary>
               /// Property Indexer for AutoInsert
               /// </summary>
               public const int AutoInsert = 9;

               /// <summary>
               /// Property Indexer for ExternalCostTransactions
               /// </summary>
               public const int ExternalCostTransactions = 10;
           
               /// <summary>
               /// Property Indexer for PayablesClearing
               /// </summary>
               public const int PayablesClearing = 11;
        
               /// <summary>
               /// Property Indexer for PayablesClearing1
               /// </summary>
               public const int PayablesClearing1 = 12;

               /// <summary>
               /// Property Indexer for InventoryControl
               /// </summary>
               public const int InventoryControl = 13;

               /// <summary>
               /// Property Indexer for NonStockClearing
               /// </summary>
               public const int NonStockClearing = 14;
            
               /// <summary>
               /// Property Indexer for NonInventoryPayablesClearing
               /// </summary>
               public const int NonInventoryPayablesClearing = 15;
       
               /// <summary>
               /// Property Indexer for NonInventoryPayablesClearing1
               /// </summary>
               public const int NonInventoryPayablesClearing1 = 16;
        
               /// <summary>
               /// Property Indexer for NonInventoryExpense
               /// </summary>
               public const int NonInventoryExpense = 17;
            
               /// <summary>
               /// Property Indexer for NonInventoryExpense1
               /// </summary>
               public const int NonInventoryExpense1 = 18;

               /// <summary>
               /// Property Indexer for AdditionalCostExpense
               /// </summary>
               public const int AdditionalCostExpense = 19;

               /// <summary>
               /// Property Indexer for AdditionalCostExpense1
               /// </summary>
               public const int AdditionalCostExpense1 = 20;

               /// <summary>
               /// Property Indexer for InvoicesOptionalFields
               /// </summary>
               public const int InvoicesOptionalFields = 21;

               /// <summary>
               /// Property Indexer for Labor
               /// </summary>
               public const int Labor = 22;

               /// <summary>
               /// Property Indexer for Overhead
               /// </summary>
               public const int Overhead = 23;

               /// <summary>
               /// Property Indexer for AdditionalCostExpensePayablesClearing
               /// </summary>
               public const int AdditionalCostExpensePayablesClearing = 24;

               /// <summary>
               /// Property Indexer for AdditionalCostExpensePayablesClearing1
               /// </summary>
               public const int AdditionalCostExpensePayablesClearing1 = 25;

               /// <summary>
               /// Property Indexer for Required
               /// </summary>
               public const int Required = 26;

               /// <summary>
               /// Property Indexer for ValueSet
               /// </summary>
               public const int ValueSet = 27;

               /// <summary>
               /// Property Indexer for TypedDefaultValueFieldIndex
               /// </summary>
               public const int TypedDefaultValueFieldIndex = 40;

               /// <summary>
               /// Property Indexer for DefaultTextValue
               /// </summary>
               public const int DefaultTextValue = 41;

               /// <summary>
               /// Property Indexer for DefaultMoneyValue
               /// </summary>
               public const int DefaultAmountValue = 42;

               /// <summary>
               /// Property Indexer for DefaultNumberValue
               /// </summary>
               public const int DefaultNumberValue = 43;

               /// <summary>
               /// Property Indexer for DefaultIntegerValue
               /// </summary>
               public const int DefaultIntegerValue = 44;

               /// <summary>
               /// Property Indexer for DefaultYesNoValue
               /// </summary>
               public const int DefaultYesNoValue = 45;

               /// <summary>
               /// Property Indexer for DefaultDateValue
               /// </summary>
               public const int DefaultDateValue = 46;

               /// <summary>
               /// Property Indexer for DefaultTimeValue
               /// </summary>
               public const int DefaultTimeValue = 47;

               /// <summary>
               /// Property Indexer for OptionalFieldDescription
               /// </summary>
               public const int OptionalFieldDescription = 48;

               /// <summary>
               /// Property Indexer for DefaultValueDescription
               /// </summary>
               public const int DefaultValueDescription = 49;
          }

          #endregion
     }
}
