// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of Vendor Contract Cost Constants
     /// </summary>
     public partial class VendorContractCost
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0181";

          #region Field Properties

          /// <summary>
          /// Contains list of Vendor Contract Cost Field Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Item Number
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for Vendor Number
               /// </summary>
               public const string VendorNumber = "VDCODE";

               /// <summary>
               /// Property for Contract Cost Description
               /// </summary>
               public const string ContractCostDescription = "VCPDESC";

               /// <summary>
               /// Property for Base Cost Type
               /// </summary>
               public const string BaseCostType = "BCOSTTYPE";

               /// <summary>
               /// Property for Base Cost Amount
               /// </summary>
               public const string BaseCostAmount = "BAMOUNT";

               /// <summary>
               /// Property for Base Unit
               /// </summary>
               public const string BaseUnit = "DEFBUNIT";

               /// <summary>
               /// Property for Base Unit Conversion
               /// </summary>
               public const string BaseUnitConversion = "BASECONV";

               /// <summary>
               /// Property for Sale Cost Type
               /// </summary>
               public const string SaleCostType = "SCOSTTYPE";

               /// <summary>
               /// Property for Sale Cost Based On
               /// </summary>
               public const string SaleCostBasedOn = "SDEFUSING";

               /// <summary>
               /// Property for Percentage Of Base
               /// </summary>
               public const string PercentageOfBase = "SPERCENT";

               /// <summary>
               /// Property for Discount Amount
               /// </summary>
               public const string DiscountAmount = "SDAMOUNT";

               /// <summary>
               /// Property for Fixed Amount
               /// </summary>
               public const string FixedAmount = "SFAMOUNT";

               /// <summary>
               /// Property for Sale Unit
               /// </summary>
               public const string SaleUnit = "DEFSUNIT";

               /// <summary>
               /// Property for Sale Unit Conversion
               /// </summary>
               public const string SaleUnitConversion = "SALECONV";

               /// <summary>
               /// Property for Sale Starts
               /// </summary>
               public const string SaleStarts = "SALESTART";

               /// <summary>
               /// Property for Sale Ends
               /// </summary>
               public const string SaleEnds = "SALEEND";

               /// <summary>
               /// Property for Discount Based On
               /// </summary>
               public const string DiscountBasedOn = "COSTFMT";

               /// <summary>
               /// Property for Quantity Level 0
               /// </summary>
               public const string QuantityLevel0 = "COSTQTY0";

               /// <summary>
               /// Property for Quantity Level 1
               /// </summary>
               public const string QuantityLevel1 = "COSTQTY1";

               /// <summary>
               /// Property for Quantity Level 2
               /// </summary>
               public const string QuantityLevel2 = "COSTQTY2";

               /// <summary>
               /// Property for Quantity Level 3
               /// </summary>
               public const string QuantityLevel3 = "COSTQTY3";

               /// <summary>
               /// Property for Quantity Level 4
               /// </summary>
               public const string QuantityLevel4 = "COSTQTY4";

               /// <summary>
               /// Property for Quantity Level 5
               /// </summary>
               public const string QuantityLevel5 = "COSTQTY5";

               /// <summary>
               /// Property for Quantity Level 6
               /// </summary>
               public const string QuantityLevel6 = "COSTQTY6";

               /// <summary>
               /// Property for Quantity Level 7
               /// </summary>
               public const string QuantityLevel7 = "COSTQTY7";

               /// <summary>
               /// Property for Quantity Level 8
               /// </summary>
               public const string QuantityLevel8 = "COSTQTY8";

               /// <summary>
               /// Property for Quantity Level 9
               /// </summary>
               public const string QuantityLevel9 = "COSTQTY9";

               /// <summary>
               /// Property for Percentage Level 0
               /// </summary>
               public const string PercentageLevel0 = "PRCNTLVL0";

               /// <summary>
               /// Property for Percentage Level 1
               /// </summary>
               public const string PercentageLevel1 = "PRCNTLVL1";

               /// <summary>
               /// Property for Percentage Level 2
               /// </summary>
               public const string PercentageLevel2 = "PRCNTLVL2";

               /// <summary>
               /// Property for Percentage Level 3
               /// </summary>
               public const string PercentageLevel3 = "PRCNTLVL3";

               /// <summary>
               /// Property for Percentage Level 4
               /// </summary>
               public const string PercentageLevel4 = "PRCNTLVL4";

               /// <summary>
               /// Property for Percentage Level 5
               /// </summary>
               public const string PercentageLevel5 = "PRCNTLVL5";

               /// <summary>
               /// Property for Percentage Level 6
               /// </summary>
               public const string PercentageLevel6 = "PRCNTLVL6";

               /// <summary>
               /// Property for Percentage Level 7
               /// </summary>
               public const string PercentageLevel7 = "PRCNTLVL7";

               /// <summary>
               /// Property for Percentage Level 8
               /// </summary>
               public const string PercentageLevel8 = "PRCNTLVL8";

               /// <summary>
               /// Property for Percentage Level 9
               /// </summary>
               public const string PercentageLevel9 = "PRCNTLVL9";

               /// <summary>
               /// Property for Amount Level 0
               /// </summary>
               public const string AmountLevel0 = "AMOUNTLVL0";

               /// <summary>
               /// Property for Amount Level 1
               /// </summary>
               public const string AmountLevel1 = "AMOUNTLVL1";

               /// <summary>
               /// Property for Amount Level 2
               /// </summary>
               public const string AmountLevel2 = "AMOUNTLVL2";

               /// <summary>
               /// Property for Amount Level 3
               /// </summary>
               public const string AmountLevel3 = "AMOUNTLVL3";

               /// <summary>
               /// Property for Amount Level 4
               /// </summary>
               public const string AmountLevel4 = "AMOUNTLVL4";

               /// <summary>
               /// Property for Amount Level 5
               /// </summary>
               public const string AmountLevel5 = "AMOUNTLVL5";

               /// <summary>
               /// Property for Amount Level 6
               /// </summary>
               public const string AmountLevel6 = "AMOUNTLVL6";

               /// <summary>
               /// Property for Amount Level 7
               /// </summary>
               public const string AmountLevel7 = "AMOUNTLVL7";

               /// <summary>
               /// Property for Amount Level 8
               /// </summary>
               public const string AmountLevel8 = "AMOUNTLVL8";

               /// <summary>
               /// Property for Amount Level 9
               /// </summary>
               public const string AmountLevel9 = "AMOUNTLVL9";

               /// <summary>
               /// Property for Rounding Method
               /// </summary>
               public const string RoundingMethod = "ROUNDMETHD";

               /// <summary>
               /// Property for Round To a Multiple Of
               /// </summary>
               public const string RoundToMultipleOf = "ROUNDAMT";

               /// <summary>
               /// Property for Item Description
               /// </summary>
               public const string ItemDescription = "ITEMDESC";

               /// <summary>
               /// Property for Formatted Item Number
               /// </summary>
               public const string FormattedItemNumber = "FMTITEMNO";

               /// <summary>
               /// Property for Unit Of Measure
               /// </summary>
               public const string UnitOfMeasure = "STOCKUNIT";

               /// <summary>
               /// Property for Calculated Sale Cost
               /// </summary>
               public const string CalculatedSaleCost = "DSALECOST";

               /// <summary>
               /// Property for COST QTY TO X
               /// </summary>
               public const string CostQtyToX = "COSTQTYTOX";

               /// <summary>
               /// Property for Quantity To 0
               /// </summary>
               public const string QuantityTo0 = "COSTQTYTO0";

               /// <summary>
               /// Property for Quantity To 1
               /// </summary>
               public const string QuantityTo1 = "COSTQTYTO1";

               /// <summary>
               /// Property for Quantity To 2
               /// </summary>
               public const string QuantityTo2 = "COSTQTYTO2";

               /// <summary>
               /// Property for Quantity To 3
               /// </summary>
               public const string QuantityTo3 = "COSTQTYTO3";

               /// <summary>
               /// Property for Quantity To 4
               /// </summary>
               public const string QuantityTo4 = "COSTQTYTO4";

               /// <summary>
               /// Property for Quantity To 5
               /// </summary>
               public const string QuantityTo5 = "COSTQTYTO5";

               /// <summary>
               /// Property for Quantity To 6
               /// </summary>
               public const string QuantityTo6 = "COSTQTYTO6";

               /// <summary>
               /// Property for Quantity To 7
               /// </summary>
               public const string QuantityTo7 = "COSTQTYTO7";

               /// <summary>
               /// Property for Quantity To 8
               /// </summary>
               public const string QuantityTo8 = "COSTQTYTO8";

               /// <summary>
               /// Property for Quantity To 9
               /// </summary>
               public const string QuantityTo9 = "COSTQTYTO9";

               /// <summary>
               /// Property for Quantity Next 0
               /// </summary>
               public const string QuantityNext0 = "COSTQTYNX0";

               /// <summary>
               /// Property for Quantity Next 1
               /// </summary>
               public const string QuantityNext1 = "COSTQTYNX1";

               /// <summary>
               /// Property for Quantity Next 2
               /// </summary>
               public const string QuantityNext2 = "COSTQTYNX2";

               /// <summary>
               /// Property for Quantity Next 3
               /// </summary>
               public const string QuantityNext3 = "COSTQTYNX3";

               /// <summary>
               /// Property for Quantity Next 4
               /// </summary>
               public const string QuantityNext4 = "COSTQTYNX4";

               /// <summary>
               /// Property for Quantity Next 5
               /// </summary>
               public const string QuantityNext5 = "COSTQTYNX5";

               /// <summary>
               /// Property for Quantity Next 6
               /// </summary>
               public const string QuantityNext6 = "COSTQTYNX6";

               /// <summary>
               /// Property for Quantity Next 7
               /// </summary>
               public const string QuantityNext7 = "COSTQTYNX7";

               /// <summary>
               /// Property for Quantity Next 8
               /// </summary>
               public const string QuantityNext8 = "COSTQTYNX8";

               /// <summary>
               /// Property for Quantity Next 9
               /// </summary>
               public const string QuantityNext9 = "COSTQTYNX9";

               /// <summary>
               /// Property for Discounted Amount 0
               /// </summary>
               public const string DiscountedAmount0 = "DDISCOUNT0";

               /// <summary>
               /// Property for Discounted Amount 1
               /// </summary>
               public const string DiscountedAmount1 = "DDISCOUNT1";

               /// <summary>
               /// Property for Discounted Amount 2
               /// </summary>
               public const string DiscountedAmount2 = "DDISCOUNT2";

               /// <summary>
               /// Property for Discounted Amount 3
               /// </summary>
               public const string DiscountedAmount3 = "DDISCOUNT3";

               /// <summary>
               /// Property for Discounted Amount 4
               /// </summary>
               public const string DiscountedAmount4 = "DDISCOUNT4";

               /// <summary>
               /// Property for Discounted Amount 5
               /// </summary>
               public const string DiscountedAmount5 = "DDISCOUNT5";

               /// <summary>
               /// Property for Discounted Amount 6
               /// </summary>
               public const string DiscountedAmount6 = "DDISCOUNT6";

               /// <summary>
               /// Property for Discounted Amount 7
               /// </summary>
               public const string DiscountedAmount7 = "DDISCOUNT7";

               /// <summary>
               /// Property for Discounted Amount 8
               /// </summary>
               public const string DiscountedAmount8 = "DDISCOUNT8";

               /// <summary>
               /// Property for Discounted Amount 9
               /// </summary>
               public const string DiscountedAmount9 = "DDISCOUNT9";
              
               /// <summary>
               /// Property for LEVEL USED X
               /// </summary>
               public const string LevelUsedX = "LEVELUSEDX";

               /// <summary>
               /// Property for Level Used 0
               /// </summary>
               public const string LevelUsed0 = "LEVELUSED0";

               /// <summary>
               /// Property for Level Used 1
               /// </summary>
               public const string LevelUsed1 = "LEVELUSED1";

               /// <summary>
               /// Property for Level Used 2
               /// </summary>
               public const string LevelUsed2 = "LEVELUSED2";

               /// <summary>
               /// Property for Level Used 3
               /// </summary>
               public const string LevelUsed3 = "LEVELUSED3";

               /// <summary>
               /// Property for Level Used 4
               /// </summary>
               public const string LevelUsed4 = "LEVELUSED4";

               /// <summary>
               /// Property for Level Used 5
               /// </summary>
               public const string LevelUsed5 = "LEVELUSED5";

               /// <summary>
               /// Property for Level Used 6
               /// </summary>
               public const string LevelUsed6 = "LEVELUSED6";

               /// <summary>
               /// Property for LevelUsed 7
               /// </summary>
               public const string LevelUsed7 = "LEVELUSED7";

               /// <summary>
               /// Property for Level Used 8
               /// </summary>
               public const string LevelUsed8 = "LEVELUSED8";

               /// <summary>
               /// Property for Level Used 9
               /// </summary>
               public const string LevelUsed9 = "LEVELUSED9";
              
               /// <summary>
               /// Property for LEVEL USED Z
               /// </summary>
               public const string LevelUsedZ = "LEVELUSEDZ";

               /// <summary>
               /// Property for Quantity Maximum
               /// </summary>
               public const string QuantityMaximum = "COSTQTYINF";

               /// <summary>
               /// Property for Quantity Increment
               /// </summary>
               public const string QuantityIncrement = "COSTQTYEPS";

               /// <summary>
               /// Property for Vendor Currency
               /// </summary>
               public const string VendorCurrency = "VDCURR";

               /// <summary>
               /// Property for Name
               /// </summary>
               public const string Name = "VDNAME";

          }

          #endregion

          #region Index Properties

          /// <summary>
          /// Contains list of Vendor Contract Cost Index Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Item Number
               /// </summary>
               public const int ItemNumber = 1;

               /// <summary>
               /// Property Indexer for Vendor Number
               /// </summary>
               public const int VendorNumber = 2;

               /// <summary>
               /// Property Indexer for Contract Cost Description
               /// </summary>
               public const int ContractCostDescription = 3;

               /// <summary>
               /// Property Indexer for Base Cost Type
               /// </summary>
               public const int BaseCostType = 6;

               /// <summary>
               /// Property Indexer for Base Cost Amount
               /// </summary>
               public const int BaseCostAmount = 7;

               /// <summary>
               /// Property Indexer for Base Unit
               /// </summary>
               public const int BaseUnit = 8;

               /// <summary>
               /// Property Indexer for Base Unit Conversion
               /// </summary>
               public const int BaseUnitConversion = 9;

               /// <summary>
               /// Property Indexer for Sale Cost Type
               /// </summary>
               public const int SaleCostType = 10;

               /// <summary>
               /// Property Indexer for Sale Cost Based On
               /// </summary>
               public const int SaleCostBasedOn = 11;

               /// <summary>
               /// Property Indexer for Percentage Of Base
               /// </summary>
               public const int PercentageOfBase = 12;

               /// <summary>
               /// Property Indexer for Discount Amount
               /// </summary>
               public const int DiscountAmount = 13;

               /// <summary>
               /// Property Indexer for Fixed Amount
               /// </summary>
               public const int FixedAmount = 14;

               /// <summary>
               /// Property Indexer for Sale Unit
               /// </summary>
               public const int SaleUnit = 15;

               /// <summary>
               /// Property Indexer for Sale Unit Conversion
               /// </summary>
               public const int SaleUnitConversion = 16;

               /// <summary>
               /// Property Indexer for Sale Starts
               /// </summary>
               public const int SaleStarts = 17;

               /// <summary>
               /// Property Indexer for Sale Ends
               /// </summary>
               public const int SaleEnds = 18;

               /// <summary>
               /// Property Indexer for Discount Based On
               /// </summary>
               public const int DiscountBasedOn = 22;

               /// <summary>
               /// Property Indexer for Quantity Level 0
               /// </summary>
               public const int QuantityLevel0 = 25;

               /// <summary>
               /// Property Indexer for Quantity Level 1
               /// </summary>
               public const int QuantityLevel1 = 26;

               /// <summary>
               /// Property Indexer for Quantity Level 2
               /// </summary>
               public const int QuantityLevel2 = 27;

               /// <summary>
               /// Property Indexer for Quantity Level 3
               /// </summary>
               public const int QuantityLevel3 = 28;

               /// <summary>
               /// Property Indexer for Quantity Level 4
               /// </summary>
               public const int QuantityLevel4 = 29;

               /// <summary>
               /// Property Indexer for Quantity Level 5
               /// </summary>
               public const int QuantityLevel5 = 30;

               /// <summary>
               /// Property Indexer for Quantity Level 6
               /// </summary>
               public const int QuantityLevel6 = 31;

               /// <summary>
               /// Property Indexer for Quantity Level 7
               /// </summary>
               public const int QuantityLevel7 = 32;

               /// <summary>
               /// Property Indexer for Quantity Level 8
               /// </summary>
               public const int QuantityLevel8 = 33;

               /// <summary>
               /// Property Indexer for Quantity Level 9
               /// </summary>
               public const int QuantityLevel9 = 34;

               /// <summary>
               /// Property Indexer for Percentage Level 0
               /// </summary>
               public const int PercentageLevel0 = 37;

               /// <summary>
               /// Property Indexer for Percentage Level 1
               /// </summary>
               public const int PercentageLevel1 = 38;

               /// <summary>
               /// Property Indexer for PercentageLevel 2
               /// </summary>
               public const int PercentageLevel2 = 39;

               /// <summary>
               /// Property Indexer for Percentage Level 3
               /// </summary>
               public const int PercentageLevel3 = 40;

               /// <summary>
               /// Property Indexer for Percentage Level 4
               /// </summary>
               public const int PercentageLevel4 = 41;

               /// <summary>
               /// Property Indexer for Percentage Level5
               /// </summary>
               public const int PercentageLevel5 = 42;

               /// <summary>
               /// Property Indexer for Percentage Level 6
               /// </summary>
               public const int PercentageLevel6 = 43;

               /// <summary>
               /// Property Indexer for Percentage Level 7
               /// </summary>
               public const int PercentageLevel7 = 44;

               /// <summary>
               /// Property Indexer for Percentage Level 8
               /// </summary>
               public const int PercentageLevel8 = 45;

               /// <summary>
               /// Property Indexer for Percentage Level 9
               /// </summary>
               public const int PercentageLevel9 = 46;

               /// <summary>
               /// Property Indexer for Amount Level 0
               /// </summary>
               public const int AmountLevel0 = 49;

               /// <summary>
               /// Property Indexer for Amount Level 1
               /// </summary>
               public const int AmountLevel1 = 50;

               /// <summary>
               /// Property Indexer for Amount Level 2
               /// </summary>
               public const int AmountLevel2 = 51;

               /// <summary>
               /// Property Indexer for Amount Level 3
               /// </summary>
               public const int AmountLevel3 = 52;

               /// <summary>
               /// Property Indexer for Amount Level 4
               /// </summary>
               public const int AmountLevel4 = 53;

               /// <summary>
               /// Property Indexer for Amount Level 5
               /// </summary>
               public const int AmountLevel5 = 54;

               /// <summary>
               /// Property Indexer for Amount Level 6
               /// </summary>
               public const int AmountLevel6 = 55;

               /// <summary>
               /// Property Indexer for Amount Level 7
               /// </summary>
               public const int AmountLevel7 = 56;

               /// <summary>
               /// Property Indexer for Amount Level 8
               /// </summary>
               public const int AmountLevel8 = 57;

               /// <summary>
               /// Property Indexer for Amount Level 9
               /// </summary>
               public const int AmountLevel9 = 58;

               /// <summary>
               /// Property Indexer for Rounding Method
               /// </summary>
               public const int RoundingMethod = 61;

               /// <summary>
               /// Property Indexer for Round  To a MultipleOf
               /// </summary>
               public const int RoundToMultipleOf = 62;

               /// <summary>
               /// Property Indexer for Item Description
               /// </summary>
               public const int ItemDescription = 71;

               /// <summary>
               /// Property Indexer for Formatted Item Number
               /// </summary>
               public const int FormattedItemNumber = 72;

               /// <summary>
               /// Property Indexer for Unit Of Measure
               /// </summary>
               public const int UnitOfMeasure = 73;

               /// <summary>
               /// Property Indexer for Calculated Sale Cost
               /// </summary>
               public const int CalculatedSaleCost = 74;
              
               /// <summary>
               /// Property Indexer for COST QTY TO X
               /// </summary>
               public const int CostQtyToX = 77;

               /// <summary>
               /// Property Indexer for Quantity To 0
               /// </summary>
               public const int QuantityTo0 = 78;

               /// <summary>
               /// Property Indexer for Quantity To 1
               /// </summary>
               public const int QuantityTo1 = 79;

               /// <summary>
               /// Property Indexer for Quantity To 2
               /// </summary>
               public const int QuantityTo2 = 80;

               /// <summary>
               /// Property Indexer for Quantity To 3
               /// </summary>
               public const int QuantityTo3 = 81;

               /// <summary>
               /// Property Indexer for Quantity To 4
               /// </summary>
               public const int QuantityTo4 = 82;

               /// <summary>
               /// Property Indexer for Quantity To 5
               /// </summary>
               public const int QuantityTo5 = 83;

               /// <summary>
               /// Property Indexer for Quantity To 6
               /// </summary>
               public const int QuantityTo6 = 84;

               /// <summary>
               /// Property Indexer for Quantity To 7
               /// </summary>
               public const int QuantityTo7 = 85;

               /// <summary>
               /// Property Indexer for Quantity To 8
               /// </summary>
               public const int QuantityTo8 = 86;

               /// <summary>
               /// Property Indexer for Quantity To 9
               /// </summary>
               public const int QuantityTo9 = 87;

               /// <summary>
               /// Property Indexer for Quantity Next 0
               /// </summary>
               public const int QuantityNext0 = 90;

               /// <summary>
               /// Property Indexer for Quantity Next 1
               /// </summary>
               public const int QuantityNext1 = 91;

               /// <summary>
               /// Property Indexer for Quantity Next 2
               /// </summary>
               public const int QuantityNext2 = 92;

               /// <summary>
               /// Property Indexer for Quantity Next 3
               /// </summary>
               public const int QuantityNext3 = 93;

               /// <summary>
               /// Property Indexer for Quantity Next 4
               /// </summary>
               public const int QuantityNext4 = 94;

               /// <summary>
               /// Property Indexer for Quantity Next 5
               /// </summary>
               public const int QuantityNext5 = 95;

               /// <summary>
               /// Property Indexer for QuantityNext 6
               /// </summary>
               public const int QuantityNext6 = 96;

               /// <summary>
               /// Property Indexer for Quantity Next 7 
               /// </summary>
               public const int QuantityNext7 = 97;

               /// <summary>
               /// Property Indexer for Quantity Next 8
               /// </summary>
               public const int QuantityNext8 = 98;

               /// <summary>
               /// Property Indexer for Quantity Next 9
               /// </summary>
               public const int QuantityNext9 = 99;

               /// <summary>
               /// Property Indexer for Discounted Amount 0
               /// </summary>
               public const int DiscountedAmount0 = 102;

               /// <summary>
               /// Property Indexer for Discounted Amount 1
               /// </summary>
               public const int DiscountedAmount1 = 103;

               /// <summary>
               /// Property Indexer for Discounted Amount 2
               /// </summary>
               public const int DiscountedAmount2 = 104;

               /// <summary>
               /// Property Indexer for Discounted Amount 3
               /// </summary>
               public const int DiscountedAmount3 = 105;

               /// <summary>
               /// Property Indexer for Discounted Amount 4
               /// </summary>
               public const int DiscountedAmount4 = 106;

               /// <summary>
               /// Property Indexer for Discounted Amount 5
               /// </summary>
               public const int DiscountedAmount5 = 107;

               /// <summary>
               /// Property Indexer for Discounted Amount 6
               /// </summary>
               public const int DiscountedAmount6 = 108;

               /// <summary>
               /// Property Indexer for Discounted Amount 7
               /// </summary>
               public const int DiscountedAmount7 = 109;

               /// <summary>
               /// Property Indexer for Discounted Amount 8
               /// </summary>
               public const int DiscountedAmount8 = 110;

               /// <summary>
               /// Property Indexer for Discounted Amount 9
               /// </summary>
               public const int DiscountedAmount9 = 111;
               
               /// <summary>
               /// Property Indexer for LEVEL USED X
               /// </summary>
               public const int LevelUsedX = 114;

               /// <summary>
               /// Property Indexer for Level Used 0
               /// </summary>
               public const int LevelUsed0 = 115;

               /// <summary>
               /// Property Indexer for Level Used 1
               /// </summary>
               public const int LevelUsed1 = 116;

               /// <summary>
               /// Property Indexer for Level Used 2
               /// </summary>
               public const int LevelUsed2 = 117;

               /// <summary>
               /// Property Indexer for Level Used 3
               /// </summary>
               public const int LevelUsed3 = 118;

               /// <summary>
               /// Property Indexer for Level Used 4
               /// </summary>
               public const int LevelUsed4 = 119;

               /// <summary>
               /// Property Indexer for Level Used 5
               /// </summary>
               public const int LevelUsed5 = 120;

               /// <summary>
               /// Property Indexer for Level Used 6
               /// </summary>
               public const int LevelUsed6 = 121;

               /// <summary>
               /// Property Indexer for Level Used 7
               /// </summary>
               public const int LevelUsed7 = 122;

               /// <summary>
               /// Property Indexer for Level Used 8
               /// </summary>
               public const int LevelUsed8 = 123;

               /// <summary>
               /// Property Indexer for Level Used 9
               /// </summary>
               public const int LevelUsed9 = 124;
              
               /// <summary>
               /// Property Indexer for LEVEL USED Z
               /// </summary>
               public const int LevelUsedZ = 125;

               /// <summary>
               /// Property Indexer for Quantity Maximum
               /// </summary>
               public const int QuantityMaximum = 128;

               /// <summary>
               /// Property Indexer for Quantity Increment
               /// </summary>
               public const int QuantityIncrement = 129;

               /// <summary>
               /// Property Indexer for Vendor Currency
               /// </summary>
               public const int VendorCurrency = 130;

               /// <summary>
               /// Property Indexer for Name
               /// </summary>
               public const int Name = 131;

          }

          #endregion

     }
}
