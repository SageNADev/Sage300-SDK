// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of CreditDebitNoteComment Constants
     /// </summary>
     public partial class CreditDebitNoteComment
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0309";

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteComment Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CreditDebitNoteSequenceKey
               /// </summary>
               public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

               /// <summary>
               /// Property for CommentIdentifier
               /// </summary>
               public const string CommentIdentifier = "CRNCREV";

               /// <summary>
               /// Property for CRDRNoteCommentSequence
               /// </summary>
               public const string CRDRNoteCommentSequence = "CRNCSEQ";

               /// <summary>
               /// Property for StoredInDatabaseTable
               /// </summary>
               public const string StoredInDatabaseTable = "INDBTABLE";

               /// <summary>
               /// Property for LineType
               /// </summary>
               public const string LineType = "COMMENTTYP";

               /// <summary>
               /// Property for Comment
               /// </summary>
               public const string Comment = "COMMENT";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteComment Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CreditDebitNoteSequenceKey
               /// </summary>
               public const int CreditDebitNoteSequenceKey = 1;

               /// <summary>
               /// Property Indexer for CommentIdentifier
               /// </summary>
               public const int CommentIdentifier = 2;

               /// <summary>
               /// Property Indexer for CRDRNoteCommentSequence
               /// </summary>
               public const int CRDRNoteCommentSequence = 3;

               /// <summary>
               /// Property Indexer for StoredInDatabaseTable
               /// </summary>
               public const int StoredInDatabaseTable = 4;

               /// <summary>
               /// Property Indexer for LineType
               /// </summary>
               public const int LineType = 5;

               /// <summary>
               /// Property Indexer for Comment
               /// </summary>
               public const int Comment = 6;

          }
          #endregion

     }
}
