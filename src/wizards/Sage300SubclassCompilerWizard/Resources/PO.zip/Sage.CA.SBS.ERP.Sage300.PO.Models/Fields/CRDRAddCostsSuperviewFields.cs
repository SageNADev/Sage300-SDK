// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of CRDRAdd.CostsSuperview Constants
     /// </summary>
     public partial class CrdrAddCostsSuperview
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0325";

         /// <summary>
         /// Dynamic Attributes contain a reverse mapping of field and property
         /// </summary>
         [IsMvcSpecific] 
         [IgnoreExportImport]
         public static Dictionary<string, string> DynamicAttributes
         {
             get
             {
                 return new Dictionary<string, string>
				{
					{"RCPHSEQ", "ReceiptSequenceKey"},
					{"RCPSSEQ", "ReceiptCostSequence"},
					{"INVHSEQ", "InvoiceSequenceKey"},
					{"INVSSEQ", "InvoiceCostSequence"},
					{"AMOUNT", "Amount"},
					{"REFERENCE", "Reference"},
					{"COMMENT", "Comment"},
					{"RCPNUMBER", "ReceiptNumber"},
					{"RCPHSEQA", "ApplyToReceiptSequenceKey"},
					{"RCPNUMBERA", "ApplyToReceiptNumber"},
					{"CONTRACT", "Contract"},
					{"PROJECT", "Project"},
					{"CCATEGORY", "Category"},
                    {"BILLTYPE", "BillingType"},
                    {"RESOURCE", "Resource"},
                    {"BILLRATE", "BillingRate"},
					{"ARITEMNO", "ARItemNumber"},
					{"ARUNIT", "ARUnitOfMeasure"},
					{"CALCOVRHD", "CalculateOverhead"},
					{"CALCLABOR", "CalculateLabor"},
					{"RTGPERCENT", "RetainagePercentage"},
					{"RTGDAYS", "RetentionPeriod"},
					{"RTGAMOUNT", "RetainageAmount"},
					{"RTGDATEDUE", "RetainageDueDate"},
					{"ISCOMPLETE", "Completed"},

                    {"ADDCOST", "AdditionalCost"},
					{"GLEXPACCT", "ExpenseAccount"},
					{"GLRETACCT", "ReturnAccount"},
					{"PRORMETHOD", "ProrationMethod"},
					{"REPRORATE", "ReprorationMethod"},
					{"DESCRIPTIO", "Description"},
					
					
				};
             }
         }

          #region Properties
          /// <summary>
          /// Contains list of CRDRAdd.CostsSuperview Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CreditDebitNoteSequenceKey
               /// </summary>
               public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for CRNSREV
               /// </summary>
               public const string LineNo = "CRNSREV";

               /// <summary>
               /// Property for CreditDebitNoteCostSequence
               /// </summary>
               public const string CreditDebitNoteCostSequence = "CRNSSEQ";

               /// <summary>
               /// Property for CompletionStatus
               /// </summary>
               public const string CompletionStatus = "COMPLETION";

               /// <summary>
               /// Property for DateCompleted
               /// </summary>
               public const string DateCompleted = "DTCOMPLETE";

               /// <summary>
               /// Property for StoredInDatabaseTable
               /// </summary>
               public const string StoredInDatabaseTable = "INDBTABLE";

               /// <summary>
               /// Property for ReceiptSequenceKey
               /// </summary>
               public const string ReceiptSequenceKey = "RCPHSEQ";

               /// <summary>
               /// Property for ReceiptCostSequence
               /// </summary>
               public const string ReceiptCostSequence = "RCPSSEQ";

               /// <summary>
               /// Property for InvoiceSequenceKey
               /// </summary>
               public const string InvoiceSequenceKey = "INVHSEQ";

               /// <summary>
               /// Property for InvoiceCostSequence
               /// </summary>
               public const string InvoiceCostSequence = "INVSSEQ";

               /// <summary>
               /// Property for AdditionalCost
               /// </summary>
               public const string AdditionalCost = "ADDCOST";

               /// <summary>
               /// Property for ExpenseAccount
               /// </summary>
               public const string ExpenseAccount = "GLEXPACCT";

               /// <summary>
               /// Property for ReturnAccount
               /// </summary>
               public const string ReturnAccount = "GLRETACCT";

               /// <summary>
               /// Property for Amount
               /// </summary>
               public const string Amount = "AMOUNT";

               /// <summary>
               /// Property for ProrationMethod
               /// </summary>
               public const string ProrationMethod = "PRORMETHOD";

               /// <summary>
               /// Property for ReprorationMethod
               /// </summary>
               public const string ReprorationMethod = "REPRORATE";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESCRIPTIO";

               /// <summary>
               /// Property for Reference
               /// </summary>
               public const string Reference = "REFERENCE";

               /// <summary>
               /// Property for Comment
               /// </summary>
               public const string Comment = "COMMENT";

               /// <summary>
               /// Property for CostTaxClass1
               /// </summary>
               public const string CostTaxClass1 = "TAXICLASS1";

               /// <summary>
               /// Property for CostTaxClass2
               /// </summary>
               public const string CostTaxClass2 = "TAXICLASS2";

               /// <summary>
               /// Property for CostTaxClass3
               /// </summary>
               public const string CostTaxClass3 = "TAXICLASS3";

               /// <summary>
               /// Property for CostTaxClass4
               /// </summary>
               public const string CostTaxClass4 = "TAXICLASS4";

               /// <summary>
               /// Property for CostTaxClass5
               /// </summary>
               public const string CostTaxClass5 = "TAXICLASS5";

               /// <summary>
               /// Property for TaxBase1
               /// </summary>
               public const string TaxBase1 = "TAXBASE1";

               /// <summary>
               /// Property for TaxBase2
               /// </summary>
               public const string TaxBase2 = "TAXBASE2";

               /// <summary>
               /// Property for TaxBase3
               /// </summary>
               public const string TaxBase3 = "TAXBASE3";

               /// <summary>
               /// Property for TaxBase4
               /// </summary>
               public const string TaxBase4 = "TAXBASE4";

               /// <summary>
               /// Property for TaxBase5
               /// </summary>
               public const string TaxBase5 = "TAXBASE5";

               /// <summary>
               /// Property for TaxRate1
               /// </summary>
               public const string TaxRate1 = "TAXRATE1";

               /// <summary>
               /// Property for TaxRate2
               /// </summary>
               public const string TaxRate2 = "TAXRATE2";

               /// <summary>
               /// Property for TaxRate3
               /// </summary>
               public const string TaxRate3 = "TAXRATE3";

               /// <summary>
               /// Property for TaxRate4
               /// </summary>
               public const string TaxRate4 = "TAXRATE4";

               /// <summary>
               /// Property for TaxRate5
               /// </summary>
               public const string TaxRate5 = "TAXRATE5";

               /// <summary>
               /// Property for TaxAmount1
               /// </summary>
               public const string TaxAmount1 = "TAXAMOUNT1";

               /// <summary>
               /// Property for TaxAmount2
               /// </summary>
               public const string TaxAmount2 = "TAXAMOUNT2";

               /// <summary>
               /// Property for TaxAmount3
               /// </summary>
               public const string TaxAmount3 = "TAXAMOUNT3";

               /// <summary>
               /// Property for TaxAmount4
               /// </summary>
               public const string TaxAmount4 = "TAXAMOUNT4";

               /// <summary>
               /// Property for TaxAmount5
               /// </summary>
               public const string TaxAmount5 = "TAXAMOUNT5";

               /// <summary>
               /// Property for TaxIncludable1
               /// </summary>
               public const string TaxIncludable1 = "TAXINCLUD1";

               /// <summary>
               /// Property for TaxIncludable2
               /// </summary>
               public const string TaxIncludable2 = "TAXINCLUD2";

               /// <summary>
               /// Property for TaxIncludable3
               /// </summary>
               public const string TaxIncludable3 = "TAXINCLUD3";

               /// <summary>
               /// Property for TaxIncludable4
               /// </summary>
               public const string TaxIncludable4 = "TAXINCLUD4";

               /// <summary>
               /// Property for TaxIncludable5
               /// </summary>
               public const string TaxIncludable5 = "TAXINCLUD5";

               /// <summary>
               /// Property for TaxAllocatedAmount1
               /// </summary>
               public const string TaxAllocatedAmount1 = "TXALLOAMT1";

               /// <summary>
               /// Property for TaxAllocatedAmount2
               /// </summary>
               public const string TaxAllocatedAmount2 = "TXALLOAMT2";

               /// <summary>
               /// Property for TaxAllocatedAmount3
               /// </summary>
               public const string TaxAllocatedAmount3 = "TXALLOAMT3";

               /// <summary>
               /// Property for TaxAllocatedAmount4
               /// </summary>
               public const string TaxAllocatedAmount4 = "TXALLOAMT4";

               /// <summary>
               /// Property for TaxAllocatedAmount5
               /// </summary>
               public const string TaxAllocatedAmount5 = "TXALLOAMT5";

               /// <summary>
               /// Property for TaxRecoverableAmount1
               /// </summary>
               public const string TaxRecoverableAmount1 = "TXRECVAMT1";

               /// <summary>
               /// Property for TaxRecoverableAmount2
               /// </summary>
               public const string TaxRecoverableAmount2 = "TXRECVAMT2";

               /// <summary>
               /// Property for TaxRecoverableAmount3
               /// </summary>
               public const string TaxRecoverableAmount3 = "TXRECVAMT3";

               /// <summary>
               /// Property for TaxRecoverableAmount4
               /// </summary>
               public const string TaxRecoverableAmount4 = "TXRECVAMT4";

               /// <summary>
               /// Property for TaxRecoverableAmount5
               /// </summary>
               public const string TaxRecoverableAmount5 = "TXRECVAMT5";

               /// <summary>
               /// Property for TaxExpenseAmount1
               /// </summary>
               public const string TaxExpenseAmount1 = "TXEXPSAMT1";

               /// <summary>
               /// Property for TaxExpenseAmount2
               /// </summary>
               public const string TaxExpenseAmount2 = "TXEXPSAMT2";

               /// <summary>
               /// Property for TaxExpenseAmount3
               /// </summary>
               public const string TaxExpenseAmount3 = "TXEXPSAMT3";

               /// <summary>
               /// Property for TaxExpenseAmount4
               /// </summary>
               public const string TaxExpenseAmount4 = "TXEXPSAMT4";

               /// <summary>
               /// Property for TaxExpenseAmount5
               /// </summary>
               public const string TaxExpenseAmount5 = "TXEXPSAMT5";

               /// <summary>
               /// Property for NetOfTax
               /// </summary>
               public const string NetOfTax = "TXBASEALLO";

               /// <summary>
               /// Property for TaxIncluded
               /// </summary>
               public const string TaxIncluded = "TXINCLUDED";

               /// <summary>
               /// Property for TaxExcluded
               /// </summary>
               public const string TaxExcluded = "TXEXCLUDED";

               /// <summary>
               /// Property for TotalTax
               /// </summary>
               public const string TotalTax = "TAXAMOUNT";

               /// <summary>
               /// Property for TotalTaxRecoverable
               /// </summary>
               public const string TotalTaxRecoverable = "TXRECVAMT";

               /// <summary>
               /// Property for TotalTaxExpensed
               /// </summary>
               public const string TotalTaxExpensed = "TXEXPSAMT";

               /// <summary>
               /// Property for TotalTaxAllocated
               /// </summary>
               public const string TotalTaxAllocated = "TXALLOAMT";

               /// <summary>
               /// Property for FuncNetOfTax
               /// </summary>
               public const string FuncNetOfTax = "TFBASEALLO";

               /// <summary>
               /// Property for FuncTaxIncludedAmount1
               /// </summary>
               public const string FuncTaxIncludedAmount1 = "TFINCLUDE1";

               /// <summary>
               /// Property for FuncTaxIncludedAmount2
               /// </summary>
               public const string FuncTaxIncludedAmount2 = "TFINCLUDE2";

               /// <summary>
               /// Property for FuncTaxIncludedAmount3
               /// </summary>
               public const string FuncTaxIncludedAmount3 = "TFINCLUDE3";

               /// <summary>
               /// Property for FuncTaxIncludedAmount4
               /// </summary>
               public const string FuncTaxIncludedAmount4 = "TFINCLUDE4";

               /// <summary>
               /// Property for FuncTaxIncludedAmount5
               /// </summary>
               public const string FuncTaxIncludedAmount5 = "TFINCLUDE5";

               /// <summary>
               /// Property for FuncTaxAllocatedAmount1
               /// </summary>
               public const string FuncTaxAllocatedAmount1 = "TFALLOAMT1";

               /// <summary>
               /// Property for FuncTaxAllocatedAmount2
               /// </summary>
               public const string FuncTaxAllocatedAmount2 = "TFALLOAMT2";

               /// <summary>
               /// Property for FuncTaxAllocatedAmount3
               /// </summary>
               public const string FuncTaxAllocatedAmount3 = "TFALLOAMT3";

               /// <summary>
               /// Property for FuncTaxAllocatedAmount4
               /// </summary>
               public const string FuncTaxAllocatedAmount4 = "TFALLOAMT4";

               /// <summary>
               /// Property for FuncTaxAllocatedAmount5
               /// </summary>
               public const string FuncTaxAllocatedAmount5 = "TFALLOAMT5";

               /// <summary>
               /// Property for FuncTaxRecoverableAmount1
               /// </summary>
               public const string FuncTaxRecoverableAmount1 = "TFRECVAMT1";

               /// <summary>
               /// Property for FuncTaxRecoverableAmount2
               /// </summary>
               public const string FuncTaxRecoverableAmount2 = "TFRECVAMT2";

               /// <summary>
               /// Property for FuncTaxRecoverableAmount3
               /// </summary>
               public const string FuncTaxRecoverableAmount3 = "TFRECVAMT3";

               /// <summary>
               /// Property for FuncTaxRecoverableAmount4
               /// </summary>
               public const string FuncTaxRecoverableAmount4 = "TFRECVAMT4";

               /// <summary>
               /// Property for FuncTaxRecoverableAmount5
               /// </summary>
               public const string FuncTaxRecoverableAmount5 = "TFRECVAMT5";

               /// <summary>
               /// Property for FuncTaxExpenseAmount1
               /// </summary>
               public const string FuncTaxExpenseAmount1 = "TFEXPSAMT1";

               /// <summary>
               /// Property for FuncTaxExpenseAmount2
               /// </summary>
               public const string FuncTaxExpenseAmount2 = "TFEXPSAMT2";

               /// <summary>
               /// Property for FuncTaxExpenseAmount3
               /// </summary>
               public const string FuncTaxExpenseAmount3 = "TFEXPSAMT3";

               /// <summary>
               /// Property for FuncTaxExpenseAmount4
               /// </summary>
               public const string FuncTaxExpenseAmount4 = "TFEXPSAMT4";

               /// <summary>
               /// Property for FuncTaxExpenseAmount5
               /// </summary>
               public const string FuncTaxExpenseAmount5 = "TFEXPSAMT5";

               /// <summary>
               /// Property for ReceiptNumber
               /// </summary>
               public const string ReceiptNumber = "RCPNUMBER";

               /// <summary>
               /// Property for ApplyToReceiptSequenceKey
               /// </summary>
               public const string ApplyToReceiptSequenceKey = "RCPHSEQA";

               /// <summary>
               /// Property for ApplyToReceiptNumber
               /// </summary>
               public const string ApplyToReceiptNumber = "RCPNUMBERA";

               /// <summary>
               /// Property for InvoiceCostGroupSequence
               /// </summary>
               public const string InvoiceCostGroupSequence = "INVSSEQG";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for Contract
               /// </summary>
               public const string Contract = "CONTRACT";

               /// <summary>
               /// Property for Project
               /// </summary>
               public const string Project = "PROJECT";

               /// <summary>
               /// Property for Category
               /// </summary>
               public const string Category = "CCATEGORY";

               /// <summary>
               /// Property for CostClass
               /// </summary>
               public const string CostClass = "COSTCLASS";

               /// <summary>
               /// Property for Resource
               /// </summary>
               public const string Resource = "RESOURCE";

               /// <summary>
               /// Property for BillingType
               /// </summary>
               public const string BillingType = "BILLTYPE";

               /// <summary>
               /// Property for BillingRate
               /// </summary>
               public const string BillingRate = "BILLRATE";

               /// <summary>
               /// Property for BillingCurrency
               /// </summary>
               public const string BillingCurrency = "BILLCURR";

               /// <summary>
               /// Property for ARItemNumber
               /// </summary>
               public const string ARItemNumber = "ARITEMNO";

               /// <summary>
               /// Property for ARUnitOfMeasure
               /// </summary>
               public const string ARUnitOfMeasure = "ARUNIT";

               /// <summary>
               /// Property for CalculateOverhead
               /// </summary>
               public const string CalculateOverhead = "CALCOVRHD";

               /// <summary>
               /// Property for CalculateLabor
               /// </summary>
               public const string CalculateLabor = "CALCLABOR";

               /// <summary>
               /// Property for RetainagePercentage
               /// </summary>
               public const string RetainagePercentage = "RTGPERCENT";

               /// <summary>
               /// Property for RetentionPeriod
               /// </summary>
               public const string RetentionPeriod = "RTGDAYS";

               /// <summary>
               /// Property for RetainageAmount
               /// </summary>
               public const string RetainageAmount = "RTGAMOUNT";

               /// <summary>
               /// Property for RetainageDueDate
               /// </summary>
               public const string RetainageDueDate = "RTGDATEDUE";

               /// <summary>
               /// Property for RetainageAmountOverridden
               /// </summary>
               public const string RetainageAmountOverridden = "RTGAMTOVER";

               /// <summary>
               /// Property for RetainageDueDateOverridden
               /// </summary>
               public const string RetainageDueDateOverridden = "RTGDDTOVER";

               /// <summary>
               /// Property for CostDistributions
               /// </summary>
               public const string CostDistributions = "COSTDISTS";

               /// <summary>
               /// Property for ManualCostDistributions
               /// </summary>
               public const string ManualCostDistributions = "MANDISTS";

               /// <summary>
               /// Property for ExtraneousCostDistributions
               /// </summary>
               public const string ExtraneousCostDistributions = "EXTDISTS";

               /// <summary>
               /// Property for TaxReportingAmount1
               /// </summary>
               public const string TaxReportingAmount1 = "TARAMOUNT1";

               /// <summary>
               /// Property for TaxReportingAmount2
               /// </summary>
               public const string TaxReportingAmount2 = "TARAMOUNT2";

               /// <summary>
               /// Property for TaxReportingAmount3
               /// </summary>
               public const string TaxReportingAmount3 = "TARAMOUNT3";

               /// <summary>
               /// Property for TaxReportingAmount4
               /// </summary>
               public const string TaxReportingAmount4 = "TARAMOUNT4";

               /// <summary>
               /// Property for TaxReportingAmount5
               /// </summary>
               public const string TaxReportingAmount5 = "TARAMOUNT5";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount1
               /// </summary>
               public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount2
               /// </summary>
               public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount3
               /// </summary>
               public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount4
               /// </summary>
               public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount5
               /// </summary>
               public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt1
               /// </summary>
               public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt2
               /// </summary>
               public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt3
               /// </summary>
               public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt4
               /// </summary>
               public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

               /// <summary>
               /// Property for TaxReportingRecoverableAmt5
               /// </summary>
               public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

               /// <summary>
               /// Property for TaxReportingExpenseAmount1
               /// </summary>
               public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

               /// <summary>
               /// Property for TaxReportingExpenseAmount2
               /// </summary>
               public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

               /// <summary>
               /// Property for TaxReportingExpenseAmount3
               /// </summary>
               public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

               /// <summary>
               /// Property for TaxReportingExpenseAmount4
               /// </summary>
               public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

               /// <summary>
               /// Property for TaxReportingExpenseAmount5
               /// </summary>
               public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

               /// <summary>
               /// Property for ExpenseAccountDescription
               /// </summary>
               public const string ExpenseAccountDescription = "GLEXPACCTD";

               /// <summary>
               /// Property for ReturnExpenseAccountDesc
               /// </summary>
               public const string ReturnExpenseAccountDesc = "GLRETACCTD";

               /// <summary>
               /// Property for TaxClass1Description
               /// </summary>
               public const string TaxClass1Description = "TXICLASS1D";

               /// <summary>
               /// Property for TaxClass2Description
               /// </summary>
               public const string TaxClass2Description = "TXICLASS2D";

               /// <summary>
               /// Property for TaxClass3Description
               /// </summary>
               public const string TaxClass3Description = "TXICLASS3D";

               /// <summary>
               /// Property for TaxClass4Description
               /// </summary>
               public const string TaxClass4Description = "TXICLASS4D";

               /// <summary>
               /// Property for TaxClass5Description
               /// </summary>
               public const string TaxClass5Description = "TXICLASS5D";

               /// <summary>
               /// Property for IncludedTaxAmount1
               /// </summary>
               public const string IncludedTaxAmount1 = "TXINCLUDE1";

               /// <summary>
               /// Property for IncludedTaxAmount2
               /// </summary>
               public const string IncludedTaxAmount2 = "TXINCLUDE2";

               /// <summary>
               /// Property for IncludedTaxAmount3
               /// </summary>
               public const string IncludedTaxAmount3 = "TXINCLUDE3";

               /// <summary>
               /// Property for IncludedTaxAmount4
               /// </summary>
               public const string IncludedTaxAmount4 = "TXINCLUDE4";

               /// <summary>
               /// Property for IncludedTaxAmount5
               /// </summary>
               public const string IncludedTaxAmount5 = "TXINCLUDE5";

               /// <summary>
               /// Property for ExcludedTaxAmount1
               /// </summary>
               public const string ExcludedTaxAmount1 = "TXEXCLUDE1";

               /// <summary>
               /// Property for ExcludedTaxAmount2
               /// </summary>
               public const string ExcludedTaxAmount2 = "TXEXCLUDE2";

               /// <summary>
               /// Property for ExcludedTaxAmount3
               /// </summary>
               public const string ExcludedTaxAmount3 = "TXEXCLUDE3";

               /// <summary>
               /// Property for ExcludedTaxAmount4
               /// </summary>
               public const string ExcludedTaxAmount4 = "TXEXCLUDE4";

               /// <summary>
               /// Property for ExcludedTaxAmount5
               /// </summary>
               public const string ExcludedTaxAmount5 = "TXEXCLUDE5";

               /// <summary>
               /// Property for ManualToProrate
               /// </summary>
               public const string ManualToProrate = "MTOPRORATE";

               /// <summary>
               /// Property for Completed
               /// </summary>
               public const string Completed = "ISCOMPLETE";

               /// <summary>
               /// Property for LinesTaxCalculationSees
               /// </summary>
               public const string LinesTaxCalculationSees = "TAXLINE";

               /// <summary>
               /// Property for CostsComplete
               /// </summary>
               public const string CostsComplete = "COSTCMPL";

               /// <summary>
               /// Property for Costs
               /// </summary>
               public const string Costs = "COST";

               /// <summary>
               /// Property for InvoiceRevision (INVSREV)
               /// </summary>
               public const string InvoiceRevision = "INVSREV";

               /// <summary>
               /// Property for RecieptRevision (RCPSREV)
               /// </summary>
               public const string RecieptRevision = "RCPSREV";

               /// <summary>
               /// Property for Command
               /// </summary>
               public const string Command = "PROCESSCMD";

               /// <summary>
               /// Property for JobRelatedCost
               /// </summary>
               public const string JobRelatedCost = "JOBCOST";

               /// <summary>
               /// Property for AmountDistributionSum
               /// </summary>
               public const string AmountDistributionSum = "AMOUNTC";

               /// <summary>
               /// Property for BillingRateDistributionSum
               /// </summary>
               public const string BillingRateDistributionSum = "BILLRATEC";

               /// <summary>
               /// Property for ProjectStyle
               /// </summary>
               public const string ProjectStyle = "CONTSTYLE";

               /// <summary>
               /// Property for ProjectType
               /// </summary>
               public const string ProjectType = "PROJTYPE";

               /// <summary>
               /// Property for AccountingMethod
               /// </summary>
               public const string AccountingMethod = "REVREC";

               /// <summary>
               /// Property for UnformattedContractCode
               /// </summary>
               public const string UnformattedContractCode = "UFMTCONTNO";

               /// <summary>
               /// Property for TaxReportingIncludedAmount1
               /// </summary>
               public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

               /// <summary>
               /// Property for TaxReportingIncludedAmount2
               /// </summary>
               public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

               /// <summary>
               /// Property for TaxReportingIncludedAmount3
               /// </summary>
               public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

               /// <summary>
               /// Property for TaxReportingIncludedAmount4
               /// </summary>
               public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

               /// <summary>
               /// Property for TaxReportingIncludedAmount5
               /// </summary>
               public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

               /// <summary>
               /// Property for TaxReportingExcludedAmount1
               /// </summary>
               public const string TaxReportingExcludedAmount1 = "TREXCLUDE1";

               /// <summary>
               /// Property for TaxReportingExcludedAmount2
               /// </summary>
               public const string TaxReportingExcludedAmount2 = "TREXCLUDE2";

               /// <summary>
               /// Property for TaxReportingExcludedAmount3
               /// </summary>
               public const string TaxReportingExcludedAmount3 = "TREXCLUDE3";

               /// <summary>
               /// Property for TaxReportingExcludedAmount4
               /// </summary>
               public const string TaxReportingExcludedAmount4 = "TREXCLUDE4";

               /// <summary>
               /// Property for TaxReportingExcludedAmount5
               /// </summary>
               public const string TaxReportingExcludedAmount5 = "TREXCLUDE5";

               /// <summary>
               /// Property for TaxReportingTotalAmount
               /// </summary>
               public const string TaxReportingTotalAmount = "TARAMOUNT";

               /// <summary>
               /// Property for TaxReportingIncludedAmount
               /// </summary>
               public const string TaxReportingIncludedAmount = "TRINCLUDED";

               /// <summary>
               /// Property for TaxReportingExcludedAmount
               /// </summary>
               public const string TaxReportingExcludedAmount = "TREXCLUDED";

               /// <summary>
               /// Property for TaxReportingRecoverableAmount
               /// </summary>
               public const string TaxReportingRecoverableAmount = "TRRECVAMT";

               /// <summary>
               /// Property for TaxReportingExpensedAmount
               /// </summary>
               public const string TaxReportingExpensedAmount = "TREXPSAMT";

               /// <summary>
               /// Property for TaxReportingAllocatedAmount
               /// </summary>
               public const string TaxReportingAllocatedAmount = "TRALLOAMT";

               /// <summary>
               /// Property for RetainageTaxBase1
               /// </summary>
               public const string RetainageTaxBase1 = "RAXBASE1";

               /// <summary>
               /// Property for RetainageTaxBase2
               /// </summary>
               public const string RetainageTaxBase2 = "RAXBASE2";

               /// <summary>
               /// Property for RetainageTaxBase3
               /// </summary>
               public const string RetainageTaxBase3 = "RAXBASE3";

               /// <summary>
               /// Property for RetainageTaxBase4
               /// </summary>
               public const string RetainageTaxBase4 = "RAXBASE4";

               /// <summary>
               /// Property for RetainageTaxBase5
               /// </summary>
               public const string RetainageTaxBase5 = "RAXBASE5";

               /// <summary>
               /// Property for RetainageTaxAmount1
               /// </summary>
               public const string RetainageTaxAmount1 = "RAXAMOUNT1";

               /// <summary>
               /// Property for RetainageTaxAmount2
               /// </summary>
               public const string RetainageTaxAmount2 = "RAXAMOUNT2";

               /// <summary>
               /// Property for RetainageTaxAmount3
               /// </summary>
               public const string RetainageTaxAmount3 = "RAXAMOUNT3";

               /// <summary>
               /// Property for RetainageTaxAmount4
               /// </summary>
               public const string RetainageTaxAmount4 = "RAXAMOUNT4";

               /// <summary>
               /// Property for RetainageTaxAmount5
               /// </summary>
               public const string RetainageTaxAmount5 = "RAXAMOUNT5";

               /// <summary>
               /// Property for Function
               /// </summary>
               public const string Function = "FUNCTION";

               /// <summary>
               /// Property for RetainageTaxRecoverableAmt1
               /// </summary>
               public const string RetainageTaxRecoverableAmt1 = "RXRECVAMT1";

               /// <summary>
               /// Property for RetainageTaxRecoverableAmt2
               /// </summary>
               public const string RetainageTaxRecoverableAmt2 = "RXRECVAMT2";

               /// <summary>
               /// Property for RetainageTaxRecoverableAmt3
               /// </summary>
               public const string RetainageTaxRecoverableAmt3 = "RXRECVAMT3";

               /// <summary>
               /// Property for RetainageTaxRecoverableAmt4
               /// </summary>
               public const string RetainageTaxRecoverableAmt4 = "RXRECVAMT4";

               /// <summary>
               /// Property for RetainageTaxRecoverableAmt5
               /// </summary>
               public const string RetainageTaxRecoverableAmt5 = "RXRECVAMT5";

               /// <summary>
               /// Property for RetainageTaxExpenseAmount1
               /// </summary>
               public const string RetainageTaxExpenseAmount1 = "RXEXPSAMT1";

               /// <summary>
               /// Property for RetainageTaxExpenseAmount2
               /// </summary>
               public const string RetainageTaxExpenseAmount2 = "RXEXPSAMT2";

               /// <summary>
               /// Property for RetainageTaxExpenseAmount3
               /// </summary>
               public const string RetainageTaxExpenseAmount3 = "RXEXPSAMT3";

               /// <summary>
               /// Property for RetainageTaxExpenseAmount4
               /// </summary>
               public const string RetainageTaxExpenseAmount4 = "RXEXPSAMT4";

               /// <summary>
               /// Property for RetainageTaxExpenseAmount5
               /// </summary>
               public const string RetainageTaxExpenseAmount5 = "RXEXPSAMT5";

               /// <summary>
               /// Property for RetainageTaxAllocatedAmount1
               /// </summary>
               public const string RetainageTaxAllocatedAmount1 = "RXALLOAMT1";

               /// <summary>
               /// Property for RetainageTaxAllocatedAmount2
               /// </summary>
               public const string RetainageTaxAllocatedAmount2 = "RXALLOAMT2";

               /// <summary>
               /// Property for RetainageTaxAllocatedAmount3
               /// </summary>
               public const string RetainageTaxAllocatedAmount3 = "RXALLOAMT3";

               /// <summary>
               /// Property for RetainageTaxAllocatedAmount4
               /// </summary>
               public const string RetainageTaxAllocatedAmount4 = "RXALLOAMT4";

               /// <summary>
               /// Property for RetainageTaxAllocatedAmount5
               /// </summary>
               public const string RetainageTaxAllocatedAmount5 = "RXALLOAMT5";

               /// <summary>
               /// Property for RetainageTaxTotalAmount
               /// </summary>
               public const string RetainageTaxTotalAmount = "RAXAMOUNT";

               /// <summary>
               /// Property for TaxAmountPlusRtgTaxAmt1
               /// </summary>
               public const string TaxAmountPlusRtgTaxAmt1 = "TXRXAMT1";

               /// <summary>
               /// Property for TaxAmountPlusRtgTaxAmt2
               /// </summary>
               public const string TaxAmountPlusRtgTaxAmt2 = "TXRXAMT2";

               /// <summary>
               /// Property for TaxAmountPlusRtgTaxAmt3
               /// </summary>
               public const string TaxAmountPlusRtgTaxAmt3 = "TXRXAMT3";

               /// <summary>
               /// Property for TaxAmountPlusRtgTaxAmt4
               /// </summary>
               public const string TaxAmountPlusRtgTaxAmt4 = "TXRXAMT4";

               /// <summary>
               /// Property for TaxAmountPlusRtgTaxAmt5
               /// </summary>
               public const string TaxAmountPlusRtgTaxAmt5 = "TXRXAMT5";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CRDRAdd.CostsSuperview Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CreditDebitNoteSequenceKey
               /// </summary>
               public const int CreditDebitNoteSequenceKey = 1;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for CRNSREV
               /// </summary>
               public const int LineNo = 2;

               /// <summary>
               /// Property Indexer for CreditDebitNoteCostSequence
               /// </summary>
               public const int CreditDebitNoteCostSequence = 3;

               /// <summary>
               /// Property Indexer for CompletionStatus
               /// </summary>
               public const int CompletionStatus = 4;

               /// <summary>
               /// Property Indexer for DateCompleted
               /// </summary>
               public const int DateCompleted = 5;

               /// <summary>
               /// Property Indexer for StoredInDatabaseTable
               /// </summary>
               public const int StoredInDatabaseTable = 6;

               /// <summary>
               /// Property Indexer for ReceiptSequenceKey
               /// </summary>
               public const int ReceiptSequenceKey = 7;

               /// <summary>
               /// Property Indexer for ReceiptCostSequence
               /// </summary>
               public const int ReceiptCostSequence = 8;

               /// <summary>
               /// Property Indexer for InvoiceSequenceKey
               /// </summary>
               public const int InvoiceSequenceKey = 9;

               /// <summary>
               /// Property Indexer for InvoiceCostSequence
               /// </summary>
               public const int InvoiceCostSequence = 10;

               /// <summary>
               /// Property Indexer for AdditionalCost
               /// </summary>
               public const int AdditionalCost = 11;

               /// <summary>
               /// Property Indexer for ExpenseAccount
               /// </summary>
               public const int ExpenseAccount = 12;

               /// <summary>
               /// Property Indexer for ReturnAccount
               /// </summary>
               public const int ReturnAccount = 13;

               /// <summary>
               /// Property Indexer for Amount
               /// </summary>
               public const int Amount = 14;

               /// <summary>
               /// Property Indexer for ProrationMethod
               /// </summary>
               public const int ProrationMethod = 15;

               /// <summary>
               /// Property Indexer for ReprorationMethod
               /// </summary>
               public const int ReprorationMethod = 16;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 17;

               /// <summary>
               /// Property Indexer for Reference
               /// </summary>
               public const int Reference = 18;

               /// <summary>
               /// Property Indexer for Comment
               /// </summary>
               public const int Comment = 19;

               /// <summary>
               /// Property Indexer for CostTaxClass1
               /// </summary>
               public const int CostTaxClass1 = 20;

               /// <summary>
               /// Property Indexer for CostTaxClass2
               /// </summary>
               public const int CostTaxClass2 = 21;

               /// <summary>
               /// Property Indexer for CostTaxClass3
               /// </summary>
               public const int CostTaxClass3 = 22;

               /// <summary>
               /// Property Indexer for CostTaxClass4
               /// </summary>
               public const int CostTaxClass4 = 23;

               /// <summary>
               /// Property Indexer for CostTaxClass5
               /// </summary>
               public const int CostTaxClass5 = 24;

               /// <summary>
               /// Property Indexer for TaxBase1
               /// </summary>
               public const int TaxBase1 = 25;

               /// <summary>
               /// Property Indexer for TaxBase2
               /// </summary>
               public const int TaxBase2 = 26;

               /// <summary>
               /// Property Indexer for TaxBase3
               /// </summary>
               public const int TaxBase3 = 27;

               /// <summary>
               /// Property Indexer for TaxBase4
               /// </summary>
               public const int TaxBase4 = 28;

               /// <summary>
               /// Property Indexer for TaxBase5
               /// </summary>
               public const int TaxBase5 = 29;

               /// <summary>
               /// Property Indexer for TaxRate1
               /// </summary>
               public const int TaxRate1 = 30;

               /// <summary>
               /// Property Indexer for TaxRate2
               /// </summary>
               public const int TaxRate2 = 31;

               /// <summary>
               /// Property Indexer for TaxRate3
               /// </summary>
               public const int TaxRate3 = 32;

               /// <summary>
               /// Property Indexer for TaxRate4
               /// </summary>
               public const int TaxRate4 = 33;

               /// <summary>
               /// Property Indexer for TaxRate5
               /// </summary>
               public const int TaxRate5 = 34;

               /// <summary>
               /// Property Indexer for TaxAmount1
               /// </summary>
               public const int TaxAmount1 = 35;

               /// <summary>
               /// Property Indexer for TaxAmount2
               /// </summary>
               public const int TaxAmount2 = 36;

               /// <summary>
               /// Property Indexer for TaxAmount3
               /// </summary>
               public const int TaxAmount3 = 37;

               /// <summary>
               /// Property Indexer for TaxAmount4
               /// </summary>
               public const int TaxAmount4 = 38;

               /// <summary>
               /// Property Indexer for TaxAmount5
               /// </summary>
               public const int TaxAmount5 = 39;

               /// <summary>
               /// Property Indexer for TaxIncludable1
               /// </summary>
               public const int TaxIncludable1 = 40;

               /// <summary>
               /// Property Indexer for TaxIncludable2
               /// </summary>
               public const int TaxIncludable2 = 41;

               /// <summary>
               /// Property Indexer for TaxIncludable3
               /// </summary>
               public const int TaxIncludable3 = 42;

               /// <summary>
               /// Property Indexer for TaxIncludable4
               /// </summary>
               public const int TaxIncludable4 = 43;

               /// <summary>
               /// Property Indexer for TaxIncludable5
               /// </summary>
               public const int TaxIncludable5 = 44;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount1
               /// </summary>
               public const int TaxAllocatedAmount1 = 45;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount2
               /// </summary>
               public const int TaxAllocatedAmount2 = 46;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount3
               /// </summary>
               public const int TaxAllocatedAmount3 = 47;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount4
               /// </summary>
               public const int TaxAllocatedAmount4 = 48;

               /// <summary>
               /// Property Indexer for TaxAllocatedAmount5
               /// </summary>
               public const int TaxAllocatedAmount5 = 49;

               /// <summary>
               /// Property Indexer for TaxRecoverableAmount1
               /// </summary>
               public const int TaxRecoverableAmount1 = 50;

               /// <summary>
               /// Property Indexer for TaxRecoverableAmount2
               /// </summary>
               public const int TaxRecoverableAmount2 = 51;

               /// <summary>
               /// Property Indexer for TaxRecoverableAmount3
               /// </summary>
               public const int TaxRecoverableAmount3 = 52;

               /// <summary>
               /// Property Indexer for TaxRecoverableAmount4
               /// </summary>
               public const int TaxRecoverableAmount4 = 53;

               /// <summary>
               /// Property Indexer for TaxRecoverableAmount5
               /// </summary>
               public const int TaxRecoverableAmount5 = 54;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount1
               /// </summary>
               public const int TaxExpenseAmount1 = 55;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount2
               /// </summary>
               public const int TaxExpenseAmount2 = 56;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount3
               /// </summary>
               public const int TaxExpenseAmount3 = 57;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount4
               /// </summary>
               public const int TaxExpenseAmount4 = 58;

               /// <summary>
               /// Property Indexer for TaxExpenseAmount5
               /// </summary>
               public const int TaxExpenseAmount5 = 59;

               /// <summary>
               /// Property Indexer for NetOfTax
               /// </summary>
               public const int NetOfTax = 60;

               /// <summary>
               /// Property Indexer for TaxIncluded
               /// </summary>
               public const int TaxIncluded = 61;

               /// <summary>
               /// Property Indexer for TaxExcluded
               /// </summary>
               public const int TaxExcluded = 62;

               /// <summary>
               /// Property Indexer for TotalTax
               /// </summary>
               public const int TotalTax = 63;

               /// <summary>
               /// Property Indexer for TotalTaxRecoverable
               /// </summary>
               public const int TotalTaxRecoverable = 64;

               /// <summary>
               /// Property Indexer for TotalTaxExpensed
               /// </summary>
               public const int TotalTaxExpensed = 65;

               /// <summary>
               /// Property Indexer for TotalTaxAllocated
               /// </summary>
               public const int TotalTaxAllocated = 66;

               /// <summary>
               /// Property Indexer for FuncNetOfTax
               /// </summary>
               public const int FuncNetOfTax = 67;

               /// <summary>
               /// Property Indexer for FuncTaxIncludedAmount1
               /// </summary>
               public const int FuncTaxIncludedAmount1 = 68;

               /// <summary>
               /// Property Indexer for FuncTaxIncludedAmount2
               /// </summary>
               public const int FuncTaxIncludedAmount2 = 69;

               /// <summary>
               /// Property Indexer for FuncTaxIncludedAmount3
               /// </summary>
               public const int FuncTaxIncludedAmount3 = 70;

               /// <summary>
               /// Property Indexer for FuncTaxIncludedAmount4
               /// </summary>
               public const int FuncTaxIncludedAmount4 = 71;

               /// <summary>
               /// Property Indexer for FuncTaxIncludedAmount5
               /// </summary>
               public const int FuncTaxIncludedAmount5 = 72;

               /// <summary>
               /// Property Indexer for FuncTaxAllocatedAmount1
               /// </summary>
               public const int FuncTaxAllocatedAmount1 = 73;

               /// <summary>
               /// Property Indexer for FuncTaxAllocatedAmount2
               /// </summary>
               public const int FuncTaxAllocatedAmount2 = 74;

               /// <summary>
               /// Property Indexer for FuncTaxAllocatedAmount3
               /// </summary>
               public const int FuncTaxAllocatedAmount3 = 75;

               /// <summary>
               /// Property Indexer for FuncTaxAllocatedAmount4
               /// </summary>
               public const int FuncTaxAllocatedAmount4 = 76;

               /// <summary>
               /// Property Indexer for FuncTaxAllocatedAmount5
               /// </summary>
               public const int FuncTaxAllocatedAmount5 = 77;

               /// <summary>
               /// Property Indexer for FuncTaxRecoverableAmount1
               /// </summary>
               public const int FuncTaxRecoverableAmount1 = 78;

               /// <summary>
               /// Property Indexer for FuncTaxRecoverableAmount2
               /// </summary>
               public const int FuncTaxRecoverableAmount2 = 79;

               /// <summary>
               /// Property Indexer for FuncTaxRecoverableAmount3
               /// </summary>
               public const int FuncTaxRecoverableAmount3 = 80;

               /// <summary>
               /// Property Indexer for FuncTaxRecoverableAmount4
               /// </summary>
               public const int FuncTaxRecoverableAmount4 = 81;

               /// <summary>
               /// Property Indexer for FuncTaxRecoverableAmount5
               /// </summary>
               public const int FuncTaxRecoverableAmount5 = 82;

               /// <summary>
               /// Property Indexer for FuncTaxExpenseAmount1
               /// </summary>
               public const int FuncTaxExpenseAmount1 = 83;

               /// <summary>
               /// Property Indexer for FuncTaxExpenseAmount2
               /// </summary>
               public const int FuncTaxExpenseAmount2 = 84;

               /// <summary>
               /// Property Indexer for FuncTaxExpenseAmount3
               /// </summary>
               public const int FuncTaxExpenseAmount3 = 85;

               /// <summary>
               /// Property Indexer for FuncTaxExpenseAmount4
               /// </summary>
               public const int FuncTaxExpenseAmount4 = 86;

               /// <summary>
               /// Property Indexer for FuncTaxExpenseAmount5
               /// </summary>
               public const int FuncTaxExpenseAmount5 = 87;

               /// <summary>
               /// Property Indexer for ReceiptNumber
               /// </summary>
               public const int ReceiptNumber = 88;

               /// <summary>
               /// Property Indexer for ApplyToReceiptSequenceKey
               /// </summary>
               public const int ApplyToReceiptSequenceKey = 89;

               /// <summary>
               /// Property Indexer for ApplyToReceiptNumber
               /// </summary>
               public const int ApplyToReceiptNumber = 90;

               /// <summary>
               /// Property Indexer for InvoiceCostGroupSequence
               /// </summary>
               public const int InvoiceCostGroupSequence = 91;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 92;

               /// <summary>
               /// Property Indexer for Contract
               /// </summary>
               public const int Contract = 93;

               /// <summary>
               /// Property Indexer for Project
               /// </summary>
               public const int Project = 94;

               /// <summary>
               /// Property Indexer for Category
               /// </summary>
               public const int Category = 95;

               /// <summary>
               /// Property Indexer for CostClass
               /// </summary>
               public const int CostClass = 96;

               /// <summary>
               /// Property Indexer for Resource
               /// </summary>
               public const int Resource = 97;

               /// <summary>
               /// Property Indexer for BillingType
               /// </summary>
               public const int BillingType = 98;

               /// <summary>
               /// Property Indexer for BillingRate
               /// </summary>
               public const int BillingRate = 99;

               /// <summary>
               /// Property Indexer for BillingCurrency
               /// </summary>
               public const int BillingCurrency = 100;

               /// <summary>
               /// Property Indexer for ARItemNumber
               /// </summary>
               public const int ARItemNumber = 101;

               /// <summary>
               /// Property Indexer for ARUnitOfMeasure
               /// </summary>
               public const int ARUnitOfMeasure = 102;

               /// <summary>
               /// Property Indexer for CalculateOverhead
               /// </summary>
               public const int CalculateOverhead = 103;

               /// <summary>
               /// Property Indexer for CalculateLabor
               /// </summary>
               public const int CalculateLabor = 104;

               /// <summary>
               /// Property Indexer for RetainagePercentage
               /// </summary>
               public const int RetainagePercentage = 105;

               /// <summary>
               /// Property Indexer for RetentionPeriod
               /// </summary>
               public const int RetentionPeriod = 106;

               /// <summary>
               /// Property Indexer for RetainageAmount
               /// </summary>
               public const int RetainageAmount = 107;

               /// <summary>
               /// Property Indexer for RetainageDueDate
               /// </summary>
               public const int RetainageDueDate = 108;

               /// <summary>
               /// Property Indexer for RetainageAmountOverridden
               /// </summary>
               public const int RetainageAmountOverridden = 109;

               /// <summary>
               /// Property Indexer for RetainageDueDateOverridden
               /// </summary>
               public const int RetainageDueDateOverridden = 110;

               /// <summary>
               /// Property Indexer for CostDistributions
               /// </summary>
               public const int CostDistributions = 111;

               /// <summary>
               /// Property Indexer for ManualCostDistributions
               /// </summary>
               public const int ManualCostDistributions = 112;

               /// <summary>
               /// Property Indexer for ExtraneousCostDistributions
               /// </summary>
               public const int ExtraneousCostDistributions = 113;

               /// <summary>
               /// Property Indexer for TaxReportingAmount1
               /// </summary>
               public const int TaxReportingAmount1 = 114;

               /// <summary>
               /// Property Indexer for TaxReportingAmount2
               /// </summary>
               public const int TaxReportingAmount2 = 115;

               /// <summary>
               /// Property Indexer for TaxReportingAmount3
               /// </summary>
               public const int TaxReportingAmount3 = 116;

               /// <summary>
               /// Property Indexer for TaxReportingAmount4
               /// </summary>
               public const int TaxReportingAmount4 = 117;

               /// <summary>
               /// Property Indexer for TaxReportingAmount5
               /// </summary>
               public const int TaxReportingAmount5 = 118;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount1
               /// </summary>
               public const int TaxReportingAllocatedAmount1 = 119;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount2
               /// </summary>
               public const int TaxReportingAllocatedAmount2 = 120;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount3
               /// </summary>
               public const int TaxReportingAllocatedAmount3 = 121;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount4
               /// </summary>
               public const int TaxReportingAllocatedAmount4 = 122;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount5
               /// </summary>
               public const int TaxReportingAllocatedAmount5 = 123;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt1
               /// </summary>
               public const int TaxReportingRecoverableAmt1 = 124;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt2
               /// </summary>
               public const int TaxReportingRecoverableAmt2 = 125;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt3
               /// </summary>
               public const int TaxReportingRecoverableAmt3 = 126;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt4
               /// </summary>
               public const int TaxReportingRecoverableAmt4 = 127;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmt5
               /// </summary>
               public const int TaxReportingRecoverableAmt5 = 128;

               /// <summary>
               /// Property Indexer for TaxReportingExpenseAmount1
               /// </summary>
               public const int TaxReportingExpenseAmount1 = 129;

               /// <summary>
               /// Property Indexer for TaxReportingExpenseAmount2
               /// </summary>
               public const int TaxReportingExpenseAmount2 = 130;

               /// <summary>
               /// Property Indexer for TaxReportingExpenseAmount3
               /// </summary>
               public const int TaxReportingExpenseAmount3 = 131;

               /// <summary>
               /// Property Indexer for TaxReportingExpenseAmount4
               /// </summary>
               public const int TaxReportingExpenseAmount4 = 132;

               /// <summary>
               /// Property Indexer for TaxReportingExpenseAmount5
               /// </summary>
               public const int TaxReportingExpenseAmount5 = 133;

               /// <summary>
               /// Property Indexer for ExpenseAccountDescription
               /// </summary>
               public const int ExpenseAccountDescription = 141;

               /// <summary>
               /// Property Indexer for ReturnExpenseAccountDesc
               /// </summary>
               public const int ReturnExpenseAccountDesc = 142;

               /// <summary>
               /// Property Indexer for TaxClass1Description
               /// </summary>
               public const int TaxClass1Description = 143;

               /// <summary>
               /// Property Indexer for TaxClass2Description
               /// </summary>
               public const int TaxClass2Description = 144;

               /// <summary>
               /// Property Indexer for TaxClass3Description
               /// </summary>
               public const int TaxClass3Description = 145;

               /// <summary>
               /// Property Indexer for TaxClass4Description
               /// </summary>
               public const int TaxClass4Description = 146;

               /// <summary>
               /// Property Indexer for TaxClass5Description
               /// </summary>
               public const int TaxClass5Description = 147;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount1
               /// </summary>
               public const int IncludedTaxAmount1 = 148;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount2
               /// </summary>
               public const int IncludedTaxAmount2 = 149;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount3
               /// </summary>
               public const int IncludedTaxAmount3 = 150;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount4
               /// </summary>
               public const int IncludedTaxAmount4 = 151;

               /// <summary>
               /// Property Indexer for IncludedTaxAmount5
               /// </summary>
               public const int IncludedTaxAmount5 = 152;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount1
               /// </summary>
               public const int ExcludedTaxAmount1 = 153;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount2
               /// </summary>
               public const int ExcludedTaxAmount2 = 154;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount3
               /// </summary>
               public const int ExcludedTaxAmount3 = 155;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount4
               /// </summary>
               public const int ExcludedTaxAmount4 = 156;

               /// <summary>
               /// Property Indexer for ExcludedTaxAmount5
               /// </summary>
               public const int ExcludedTaxAmount5 = 157;

               /// <summary>
               /// Property Indexer for ManualToProrate
               /// </summary>
               public const int ManualToProrate = 158;

               /// <summary>
               /// Property Indexer for Completed
               /// </summary>
               public const int Completed = 159;

               /// <summary>
               /// Property Indexer for LinesTaxCalculationSees
               /// </summary>
               public const int LinesTaxCalculationSees = 160;

               /// <summary>
               /// Property Indexer for CostsComplete
               /// </summary>
               public const int CostsComplete = 161;

               /// <summary>
               /// Property Indexer for Costs
               /// </summary>
               public const int Costs = 162;

               /// <summary>
               /// Property Indexer for InvoiceRevision (INVSREV)
               /// </summary>
               public const int InvoiceRevision = 163;

               /// <summary>
               /// Property Indexer for RecieptRevision (RCPSREV)
               /// </summary>
               public const int RecieptRevision = 164;

               /// <summary>
               /// Property Indexer for Command
               /// </summary>
               public const int Command = 165;

               /// <summary>
               /// Property Indexer for JobRelatedCost
               /// </summary>
               public const int JobRelatedCost = 166;

               /// <summary>
               /// Property Indexer for AmountDistributionSum
               /// </summary>
               public const int AmountDistributionSum = 167;

               /// <summary>
               /// Property Indexer for BillingRateDistributionSum
               /// </summary>
               public const int BillingRateDistributionSum = 168;

               /// <summary>
               /// Property Indexer for ProjectStyle
               /// </summary>
               public const int ProjectStyle = 169;

               /// <summary>
               /// Property Indexer for ProjectType
               /// </summary>
               public const int ProjectType = 170;

               /// <summary>
               /// Property Indexer for AccountingMethod
               /// </summary>
               public const int AccountingMethod = 171;

               /// <summary>
               /// Property Indexer for UnformattedContractCode
               /// </summary>
               public const int UnformattedContractCode = 172;

               /// <summary>
               /// Property Indexer for TaxReportingIncludedAmount1
               /// </summary>
               public const int TaxReportingIncludedAmount1 = 173;

               /// <summary>
               /// Property Indexer for TaxReportingIncludedAmount2
               /// </summary>
               public const int TaxReportingIncludedAmount2 = 174;

               /// <summary>
               /// Property Indexer for TaxReportingIncludedAmount3
               /// </summary>
               public const int TaxReportingIncludedAmount3 = 175;

               /// <summary>
               /// Property Indexer for TaxReportingIncludedAmount4
               /// </summary>
               public const int TaxReportingIncludedAmount4 = 176;

               /// <summary>
               /// Property Indexer for TaxReportingIncludedAmount5
               /// </summary>
               public const int TaxReportingIncludedAmount5 = 177;

               /// <summary>
               /// Property Indexer for TaxReportingExcludedAmount1
               /// </summary>
               public const int TaxReportingExcludedAmount1 = 178;

               /// <summary>
               /// Property Indexer for TaxReportingExcludedAmount2
               /// </summary>
               public const int TaxReportingExcludedAmount2 = 179;

               /// <summary>
               /// Property Indexer for TaxReportingExcludedAmount3
               /// </summary>
               public const int TaxReportingExcludedAmount3 = 180;

               /// <summary>
               /// Property Indexer for TaxReportingExcludedAmount4
               /// </summary>
               public const int TaxReportingExcludedAmount4 = 181;

               /// <summary>
               /// Property Indexer for TaxReportingExcludedAmount5
               /// </summary>
               public const int TaxReportingExcludedAmount5 = 182;

               /// <summary>
               /// Property Indexer for TaxReportingTotalAmount
               /// </summary>
               public const int TaxReportingTotalAmount = 183;

               /// <summary>
               /// Property Indexer for TaxReportingIncludedAmount
               /// </summary>
               public const int TaxReportingIncludedAmount = 184;

               /// <summary>
               /// Property Indexer for TaxReportingExcludedAmount
               /// </summary>
               public const int TaxReportingExcludedAmount = 185;

               /// <summary>
               /// Property Indexer for TaxReportingRecoverableAmount
               /// </summary>
               public const int TaxReportingRecoverableAmount = 186;

               /// <summary>
               /// Property Indexer for TaxReportingExpensedAmount
               /// </summary>
               public const int TaxReportingExpensedAmount = 187;

               /// <summary>
               /// Property Indexer for TaxReportingAllocatedAmount
               /// </summary>
               public const int TaxReportingAllocatedAmount = 188;

               /// <summary>
               /// Property Indexer for RetainageTaxBase1
               /// </summary>
               public const int RetainageTaxBase1 = 189;

               /// <summary>
               /// Property Indexer for RetainageTaxBase2
               /// </summary>
               public const int RetainageTaxBase2 = 190;

               /// <summary>
               /// Property Indexer for RetainageTaxBase3
               /// </summary>
               public const int RetainageTaxBase3 = 191;

               /// <summary>
               /// Property Indexer for RetainageTaxBase4
               /// </summary>
               public const int RetainageTaxBase4 = 192;

               /// <summary>
               /// Property Indexer for RetainageTaxBase5
               /// </summary>
               public const int RetainageTaxBase5 = 193;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount1
               /// </summary>
               public const int RetainageTaxAmount1 = 194;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount2
               /// </summary>
               public const int RetainageTaxAmount2 = 195;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount3
               /// </summary>
               public const int RetainageTaxAmount3 = 196;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount4
               /// </summary>
               public const int RetainageTaxAmount4 = 197;

               /// <summary>
               /// Property Indexer for RetainageTaxAmount5
               /// </summary>
               public const int RetainageTaxAmount5 = 198;

               /// <summary>
               /// Property Indexer for Function
               /// </summary>
               public const int Function = 200;

               /// <summary>
               /// Property Indexer for RetainageTaxRecoverableAmt1
               /// </summary>
               public const int RetainageTaxRecoverableAmt1 = 201;

               /// <summary>
               /// Property Indexer for RetainageTaxRecoverableAmt2
               /// </summary>
               public const int RetainageTaxRecoverableAmt2 = 202;

               /// <summary>
               /// Property Indexer for RetainageTaxRecoverableAmt3
               /// </summary>
               public const int RetainageTaxRecoverableAmt3 = 203;

               /// <summary>
               /// Property Indexer for RetainageTaxRecoverableAmt4
               /// </summary>
               public const int RetainageTaxRecoverableAmt4 = 204;

               /// <summary>
               /// Property Indexer for RetainageTaxRecoverableAmt5
               /// </summary>
               public const int RetainageTaxRecoverableAmt5 = 205;

               /// <summary>
               /// Property Indexer for RetainageTaxExpenseAmount1
               /// </summary>
               public const int RetainageTaxExpenseAmount1 = 206;

               /// <summary>
               /// Property Indexer for RetainageTaxExpenseAmount2
               /// </summary>
               public const int RetainageTaxExpenseAmount2 = 207;

               /// <summary>
               /// Property Indexer for RetainageTaxExpenseAmount3
               /// </summary>
               public const int RetainageTaxExpenseAmount3 = 208;

               /// <summary>
               /// Property Indexer for RetainageTaxExpenseAmount4
               /// </summary>
               public const int RetainageTaxExpenseAmount4 = 209;

               /// <summary>
               /// Property Indexer for RetainageTaxExpenseAmount5
               /// </summary>
               public const int RetainageTaxExpenseAmount5 = 210;

               /// <summary>
               /// Property Indexer for RetainageTaxAllocatedAmount1
               /// </summary>
               public const int RetainageTaxAllocatedAmount1 = 211;

               /// <summary>
               /// Property Indexer for RetainageTaxAllocatedAmount2
               /// </summary>
               public const int RetainageTaxAllocatedAmount2 = 212;

               /// <summary>
               /// Property Indexer for RetainageTaxAllocatedAmount3
               /// </summary>
               public const int RetainageTaxAllocatedAmount3 = 213;

               /// <summary>
               /// Property Indexer for RetainageTaxAllocatedAmount4
               /// </summary>
               public const int RetainageTaxAllocatedAmount4 = 214;

               /// <summary>
               /// Property Indexer for RetainageTaxAllocatedAmount5
               /// </summary>
               public const int RetainageTaxAllocatedAmount5 = 215;

               /// <summary>
               /// Property Indexer for RetainageTaxTotalAmount
               /// </summary>
               public const int RetainageTaxTotalAmount = 216;

               /// <summary>
               /// Property Indexer for TaxAmountPlusRtgTaxAmt1
               /// </summary>
               public const int TaxAmountPlusRtgTaxAmt1 = 217;

               /// <summary>
               /// Property Indexer for TaxAmountPlusRtgTaxAmt2
               /// </summary>
               public const int TaxAmountPlusRtgTaxAmt2 = 218;

               /// <summary>
               /// Property Indexer for TaxAmountPlusRtgTaxAmt3
               /// </summary>
               public const int TaxAmountPlusRtgTaxAmt3 = 219;

               /// <summary>
               /// Property Indexer for TaxAmountPlusRtgTaxAmt4
               /// </summary>
               public const int TaxAmountPlusRtgTaxAmt4 = 220;

               /// <summary>
               /// Property Indexer for TaxAmountPlusRtgTaxAmt5
               /// </summary>
               public const int TaxAmountPlusRtgTaxAmt5 = 221;

          }
          #endregion

     }
}
