// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of CreditDebitNoteLineLot Constants
     /// </summary>
     public partial class CreditDebitNoteLineLot
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0829";

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteLineLot Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CreditDebitNoteSequenceKey
               /// </summary>
               public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "CRNLREV";

               /// <summary>
               /// Property for LotNumber
               /// </summary>
               public const string LotNumber = "LOTNUMF";

               /// <summary>
               /// Property for CreditDebitNoteLineSequence
               /// </summary>
               public const string CreditDebitNoteLineSequence = "CRNLSEQ";

               /// <summary>
               /// Property for ExpiryDate
               /// </summary>
               public const string ExpiryDate = "EXPIRYDATE";

               /// <summary>
               /// Property for LotQuantity
               /// </summary>
               public const string LotQuantity = "QTY";

               /// <summary>
               /// Property for StockLotQuantity
               /// </summary>
               public const string StockLotQuantity = "QTYSQ";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteLineLot Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CreditDebitNoteSequenceKey
               /// </summary>
               public const int CreditDebitNoteSequenceKey = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for LotNumber
               /// </summary>
               public const int LotNumber = 3;

               /// <summary>
               /// Property Indexer for CreditDebitNoteLineSequence
               /// </summary>
               public const int CreditDebitNoteLineSequence = 4;

               /// <summary>
               /// Property Indexer for ExpiryDate
               /// </summary>
               public const int ExpiryDate = 5;

               /// <summary>
               /// Property Indexer for LotQuantity
               /// </summary>
               public const int LotQuantity = 6;

               /// <summary>
               /// Property Indexer for StockLotQuantity
               /// </summary>
               public const int StockLotQuantity = 7;

          }
          #endregion

     }
}
