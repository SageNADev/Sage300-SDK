// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace
using System.Collections.Generic;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of ReturnLine Constants
    /// </summary>
    public partial class ReturnLine
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0735";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {Fields.Contract, nameof(Contract)},
                    {Fields.Project, nameof(Project)},
                    {Fields.Category, nameof(Category)},
                    {"ITEMNO", "ItemNumber"},
                    {"ITEMDESC", "ItemDescription"},
                    {"LOCATION", "Location"},
                    {"RQRECEIVED", "QuantityReceived"},
					{"SCRECEIVED", "ExtendedCost"},
					{"SCDISCRCVD", "DiscountReceived"},
					{"RQRETURNED", "QuantityReturned"},
					{"RETUNIT", "UnitOfMeasure"},
					{"UNITCOST", "UnitCost"},
					{"EXTENDED", "ReturnCost"},
					{"DISCPCT", "DiscountPercentage"},
                    {"DISCOUNT", "DiscountAmount"},
					{"DISCOUNTF", "FuncDiscountAmount"},
					{"TXINCLUDED", "TaxIncluded"},
                    {"TXBASEALLO", "NetOfTax"},
                    {"TXALLOAMT", "AllocatedTax"},
					{"WEIGHTUNIT", "WeightUnitOfMeasure"},
					{"UNITWEIGHT", "UnitWeight"},
                    {"EXTWEIGHT", "ExtendedWeight"},
                    {"VENDITEMNO", "VendorItemNumber"},
					{"OEONUMBER", "OrderNumber"},
					{"HASCOMMENT", "Comments"},
                    {"GLACEXPENS", "ExpenseAccount"},
                    {"GLNONSTKCR", "NonStockClearingAccount"},
					{"MANITEMNO", "ManufacturersItemNumber"},
                    {"VALUES", "OptionalFields"},
                    {Fields.BillingType, nameof(BillingType)},
                    {Fields.BillingRate, nameof(BillingRate)},
                    {Fields.ARItemNumber, nameof(ARItemNumber)},
                    {Fields.ARUnitOfMeasure, nameof(ARUnitOfMeasure)},
                    {Fields.RetainageAmount, nameof(RetainageAmount)},
                    {Fields.RetainagePercentage, nameof(RetainagePercentage)},
                    {Fields.RetentionPeriod, nameof(RetentionPeriod)},
                };
            }
        }

        #region Properties
        /// <summary>
        /// Contains list of ReturnLine Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReturnSequenceKey
            /// </summary>
            public const string ReturnSequenceKey = "RETHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "RETLREV";

            /// <summary>
            /// Property for ReturnLineSequence
            /// </summary>
            public const string ReturnLineSequence = "RETLSEQ";

            /// <summary>
            /// Property for ReturnCommentSequence
            /// </summary>
            public const string ReturnCommentSequence = "RETCSEQ";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "OEONUMBER";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for PostedToIC
            /// </summary>
            public const string PostedToIC = "POSTEDTOIC";

            /// <summary>
            /// Property for CompletionStatus
            /// </summary>
            public const string CompletionStatus = "COMPLETION";

            /// <summary>
            /// Property for DateCompleted
            /// </summary>
            public const string DateCompleted = "DTCOMPLETE";

            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for ReceiptLineSequence
            /// </summary>
            public const string ReceiptLineSequence = "RCPLSEQ";

            /// <summary>
            /// Property for ItemExists
            /// </summary>
            public const string ItemExists = "ITEMEXISTS";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for VendorItemNumber
            /// </summary>
            public const string VendorItemNumber = "VENDITEMNO";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "HASCOMMENT";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "RETUNIT";

            /// <summary>
            /// Property for ReturningConversionFactor
            /// </summary>
            public const string ReturningConversionFactor = "RETCONV";

            /// <summary>
            /// Property for ReturningUnitDecimals
            /// </summary>
            public const string ReturningUnitDecimals = "RETDECML";

            /// <summary>
            /// Property for StockUnitDecimals
            /// </summary>
            public const string StockUnitDecimals = "STOCKDECML";

            /// <summary>
            /// Property for QuantityReceived
            /// </summary>
            public const string QuantityReceived = "RQRECEIVED";

            /// <summary>
            /// Property for StockingQuantityReceived
            /// </summary>
            public const string StockingQuantityReceived = "SQRECEIVED";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "SCRECEIVED";

            /// <summary>
            /// Property for QuantityPreviouslyReturned
            /// </summary>
            public const string QuantityPreviouslyReturned = "RQPREVRETN";

            /// <summary>
            /// Property for QuantityReturned
            /// </summary>
            public const string QuantityReturned = "RQRETURNED";

            /// <summary>
            /// Property for StockingQuantityReturned
            /// </summary>
            public const string StockingQuantityReturned = "SQRETURNED";

            /// <summary>
            /// Property for UnitWeight
            /// </summary>
            public const string UnitWeight = "UNITWEIGHT";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for ReturnCost
            /// </summary>
            public const string ReturnCost = "EXTENDED";

            /// <summary>
            /// Property for TaxBase1
            /// </summary>
            public const string TaxBase1 = "TAXBASE1";

            /// <summary>
            /// Property for TaxBase2
            /// </summary>
            public const string TaxBase2 = "TAXBASE2";

            /// <summary>
            /// Property for TaxBase3
            /// </summary>
            public const string TaxBase3 = "TAXBASE3";

            /// <summary>
            /// Property for TaxBase4
            /// </summary>
            public const string TaxBase4 = "TAXBASE4";

            /// <summary>
            /// Property for TaxBase5
            /// </summary>
            public const string TaxBase5 = "TAXBASE5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxRate1
            /// </summary>
            public const string TaxRate1 = "TAXRATE1";

            /// <summary>
            /// Property for TaxRate2
            /// </summary>
            public const string TaxRate2 = "TAXRATE2";

            /// <summary>
            /// Property for TaxRate3
            /// </summary>
            public const string TaxRate3 = "TAXRATE3";

            /// <summary>
            /// Property for TaxRate4
            /// </summary>
            public const string TaxRate4 = "TAXRATE4";

            /// <summary>
            /// Property for TaxRate5
            /// </summary>
            public const string TaxRate5 = "TAXRATE5";

            /// <summary>
            /// Property for TaxIncludable1
            /// </summary>
            public const string TaxIncludable1 = "TAXINCLUD1";

            /// <summary>
            /// Property for TaxIncludable2
            /// </summary>
            public const string TaxIncludable2 = "TAXINCLUD2";

            /// <summary>
            /// Property for TaxIncludable3
            /// </summary>
            public const string TaxIncludable3 = "TAXINCLUD3";

            /// <summary>
            /// Property for TaxIncludable4
            /// </summary>
            public const string TaxIncludable4 = "TAXINCLUD4";

            /// <summary>
            /// Property for TaxIncludable5
            /// </summary>
            public const string TaxIncludable5 = "TAXINCLUD5";

            /// <summary>
            /// Property for TaxAmount1
            /// </summary>
            public const string TaxAmount1 = "TAXAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2
            /// </summary>
            public const string TaxAmount2 = "TAXAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3
            /// </summary>
            public const string TaxAmount3 = "TAXAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4
            /// </summary>
            public const string TaxAmount4 = "TAXAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5
            /// </summary>
            public const string TaxAmount5 = "TAXAMOUNT5";

            /// <summary>
            /// Property for TaxAllocatedAmount1
            /// </summary>
            public const string TaxAllocatedAmount1 = "TXALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2
            /// </summary>
            public const string TaxAllocatedAmount2 = "TXALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3
            /// </summary>
            public const string TaxAllocatedAmount3 = "TXALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4
            /// </summary>
            public const string TaxAllocatedAmount4 = "TXALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5
            /// </summary>
            public const string TaxAllocatedAmount5 = "TXALLOAMT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1
            /// </summary>
            public const string TaxRecoverableAmount1 = "TXRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2
            /// </summary>
            public const string TaxRecoverableAmount2 = "TXRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3
            /// </summary>
            public const string TaxRecoverableAmount3 = "TXRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4
            /// </summary>
            public const string TaxRecoverableAmount4 = "TXRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5
            /// </summary>
            public const string TaxRecoverableAmount5 = "TXRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1
            /// </summary>
            public const string TaxExpenseAmount1 = "TXEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2
            /// </summary>
            public const string TaxExpenseAmount2 = "TXEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3
            /// </summary>
            public const string TaxExpenseAmount3 = "TXEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4
            /// </summary>
            public const string TaxExpenseAmount4 = "TXEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5
            /// </summary>
            public const string TaxExpenseAmount5 = "TXEXPSAMT5";

            /// <summary>
            /// Property for NetOfTax
            /// </summary>
            public const string NetOfTax = "TXBASEALLO";

            /// <summary>
            /// Property for TaxIncluded
            /// </summary>
            public const string TaxIncluded = "TXINCLUDED";

            /// <summary>
            /// Property for TaxExcluded
            /// </summary>
            public const string TaxExcluded = "TXEXCLUDED";

            /// <summary>
            /// Property for TotalTax
            /// </summary>
            public const string TotalTax = "TAXAMOUNT";

            /// <summary>
            /// Property for RecoverableTax
            /// </summary>
            public const string RecoverableTax = "TXRECVAMT";

            /// <summary>
            /// Property for ExpensedTax
            /// </summary>
            public const string ExpensedTax = "TXEXPSAMT";

            /// <summary>
            /// Property for AllocatedTax
            /// </summary>
            public const string AllocatedTax = "TXALLOAMT";

            /// <summary>
            /// Property for FuncNetOfTax
            /// </summary>
            public const string FuncNetOfTax = "TFBASEALLO";

            /// <summary>
            /// Property for FuncTaxIncludedAmount1
            /// </summary>
            public const string FuncTaxIncludedAmount1 = "TFINCLUDE1";

            /// <summary>
            /// Property for FuncTaxIncludedAmount2
            /// </summary>
            public const string FuncTaxIncludedAmount2 = "TFINCLUDE2";

            /// <summary>
            /// Property for FuncTaxIncludedAmount3
            /// </summary>
            public const string FuncTaxIncludedAmount3 = "TFINCLUDE3";

            /// <summary>
            /// Property for FuncTaxIncludedAmount4
            /// </summary>
            public const string FuncTaxIncludedAmount4 = "TFINCLUDE4";

            /// <summary>
            /// Property for FuncTaxIncludedAmount5
            /// </summary>
            public const string FuncTaxIncludedAmount5 = "TFINCLUDE5";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount1
            /// </summary>
            public const string FuncTaxAllocatedAmount1 = "TFALLOAMT1";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount2
            /// </summary>
            public const string FuncTaxAllocatedAmount2 = "TFALLOAMT2";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount3
            /// </summary>
            public const string FuncTaxAllocatedAmount3 = "TFALLOAMT3";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount4
            /// </summary>
            public const string FuncTaxAllocatedAmount4 = "TFALLOAMT4";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount5
            /// </summary>
            public const string FuncTaxAllocatedAmount5 = "TFALLOAMT5";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount1
            /// </summary>
            public const string FuncTaxRecoverableAmount1 = "TFRECVAMT1";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount2
            /// </summary>
            public const string FuncTaxRecoverableAmount2 = "TFRECVAMT2";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount3
            /// </summary>
            public const string FuncTaxRecoverableAmount3 = "TFRECVAMT3";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount4
            /// </summary>
            public const string FuncTaxRecoverableAmount4 = "TFRECVAMT4";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount5
            /// </summary>
            public const string FuncTaxRecoverableAmount5 = "TFRECVAMT5";

            /// <summary>
            /// Property for FuncTaxExpenseAmount1
            /// </summary>
            public const string FuncTaxExpenseAmount1 = "TFEXPSAMT1";

            /// <summary>
            /// Property for FuncTaxExpenseAmount2
            /// </summary>
            public const string FuncTaxExpenseAmount2 = "TFEXPSAMT2";

            /// <summary>
            /// Property for FuncTaxExpenseAmount3
            /// </summary>
            public const string FuncTaxExpenseAmount3 = "TFEXPSAMT3";

            /// <summary>
            /// Property for FuncTaxExpenseAmount4
            /// </summary>
            public const string FuncTaxExpenseAmount4 = "TFEXPSAMT4";

            /// <summary>
            /// Property for FuncTaxExpenseAmount5
            /// </summary>
            public const string FuncTaxExpenseAmount5 = "TFEXPSAMT5";

            /// <summary>
            /// Property for ExpenseAccount
            /// </summary>
            public const string ExpenseAccount = "GLACEXPENS";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for PurchaseOrderLineSequence
            /// </summary>
            public const string PurchaseOrderLineSequence = "PORLSEQ";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for NonStockClearingAccount
            /// </summary>
            public const string NonStockClearingAccount = "GLNONSTKCR";

            /// <summary>
            /// Property for ManufacturersItemNumber
            /// </summary>
            public const string ManufacturersItemNumber = "MANITEMNO";

            /// <summary>
            /// Property for DiscountReceived
            /// </summary>
            public const string DiscountReceived = "SCDISCRCVD";

            /// <summary>
            /// Property for DiscountPercentage
            /// </summary>
            public const string DiscountPercentage = "DISCPCT";

            /// <summary>
            /// Property for DiscountAmount
            /// </summary>
            public const string DiscountAmount = "DISCOUNT";

            /// <summary>
            /// Property for FuncDiscountAmount
            /// </summary>
            public const string FuncDiscountAmount = "DISCOUNTF";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CCATEGORY";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCURR";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEMNO";

            /// <summary>
            /// Property for ARUnitOfMeasure
            /// </summary>
            public const string ARUnitOfMeasure = "ARUNIT";

            /// <summary>
            /// Property for RetainagePercentage
            /// </summary>
            public const string RetainagePercentage = "RTGPERCENT";

            /// <summary>
            /// Property for RetentionPeriod
            /// </summary>
            public const string RetentionPeriod = "RTGDAYS";

            /// <summary>
            /// Property for RetainageAmount
            /// </summary>
            public const string RetainageAmount = "RTGAMOUNT";

            /// <summary>
            /// Property for RetainageAmountOverridden
            /// </summary>
            public const string RetainageAmountOverridden = "RTGAMTOVER";

            /// <summary>
            /// Property for TaxClass1Description
            /// </summary>
            public const string TaxClass1Description = "TAXCLASS1D";

            /// <summary>
            /// Property for TaxClass2Description
            /// </summary>
            public const string TaxClass2Description = "TAXCLASS2D";

            /// <summary>
            /// Property for TaxClass3Description
            /// </summary>
            public const string TaxClass3Description = "TAXCLASS3D";

            /// <summary>
            /// Property for TaxClass4Description
            /// </summary>
            public const string TaxClass4Description = "TAXCLASS4D";

            /// <summary>
            /// Property for TaxClass5Description
            /// </summary>
            public const string TaxClass5Description = "TAXCLASS5D";

            /// <summary>
            /// Property for ExpenseAccountDescription
            /// </summary>
            public const string ExpenseAccountDescription = "GLACEXPNSD";

            /// <summary>
            /// Property for IncludedTaxAmount1
            /// </summary>
            public const string IncludedTaxAmount1 = "TXINCLUDE1";

            /// <summary>
            /// Property for IncludedTaxAmount2
            /// </summary>
            public const string IncludedTaxAmount2 = "TXINCLUDE2";

            /// <summary>
            /// Property for IncludedTaxAmount3
            /// </summary>
            public const string IncludedTaxAmount3 = "TXINCLUDE3";

            /// <summary>
            /// Property for IncludedTaxAmount4
            /// </summary>
            public const string IncludedTaxAmount4 = "TXINCLUDE4";

            /// <summary>
            /// Property for IncludedTaxAmount5
            /// </summary>
            public const string IncludedTaxAmount5 = "TXINCLUDE5";

            /// <summary>
            /// Property for ExcludedTaxAmount1
            /// </summary>
            public const string ExcludedTaxAmount1 = "TXEXCLUDE1";

            /// <summary>
            /// Property for ExcludedTaxAmount2
            /// </summary>
            public const string ExcludedTaxAmount2 = "TXEXCLUDE2";

            /// <summary>
            /// Property for ExcludedTaxAmount3
            /// </summary>
            public const string ExcludedTaxAmount3 = "TXEXCLUDE3";

            /// <summary>
            /// Property for ExcludedTaxAmount4
            /// </summary>
            public const string ExcludedTaxAmount4 = "TXEXCLUDE4";

            /// <summary>
            /// Property for ExcludedTaxAmount5
            /// </summary>
            public const string ExcludedTaxAmount5 = "TXEXCLUDE5";

            /// <summary>
            /// Property for Completed
            /// </summary>
            public const string Completed = "ISCOMPLETE";

            /// <summary>
            /// Property for ExtraneousLineCount
            /// </summary>
            public const string ExtraneousLineCount = "EXTRANEOUS";

            /// <summary>
            /// Property for LinesTaxCalculationSees
            /// </summary>
            public const string LinesTaxCalculationSees = "TAXLINE";

            /// <summary>
            /// Property for LinesComplete
            /// </summary>
            public const string LinesComplete = "LINECMPL";

            /// <summary>
            /// Property for Line
            /// </summary>
            public const string Line = "LINE";

            /// <summary>
            /// Property for ExtendedStdCostInSrcCurr
            /// </summary>
            public const string ExtendedStdCostInSrcCurr = "EXSTDCOST";

            /// <summary>
            /// Property for ExtendedMRCostInSrcCurr
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string ExtendedMRCostInSrcCurr = "EXMRCOST";

            /// <summary>
            /// Property for ExtendedCost1InSrcCurr
            /// </summary>
            public const string ExtendedCost1InSrcCurr = "EXALT1COST";

            /// <summary>
            /// Property for ExtendedCost2InSrcCurr
            /// </summary>
            public const string ExtendedCost2InSrcCurr = "EXALT2COST";

            /// <summary>
            /// Property for NonStockClearingAccountDesc
            /// </summary>
            public const string NonStockClearingAccountDesc = "GLNONSTKCD";

            /// <summary>
            /// Property for InterprocessCommID
            /// </summary>
            public const string InterprocessCommID = "IPCID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string ForcePopupSN = "FORCEPOPSN";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string PopupSN = "POPUPSN";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string CloseSN = "CLOSESN";

            /// <summary>
            /// Property for LTSetID
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string LTSetID = "LTSETID";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string ForcePopupLT = "FORCEPOPLT";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string PopupLT = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string CloseLT = "CLOSELT";

            /// <summary>
            /// Property for MapManufacturersItemNumber
            /// </summary>
            public const string MapManufacturersItemNumber = "MAPMANITEM";

            /// <summary>
            /// Property for NetReturnCost
            /// </summary>
            public const string NetReturnCost = "NETXTENDED";

            /// <summary>
            /// Property for RCPLREV
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const string RCPLREV = "RCPLREV";

            /// <summary>
            /// Property for Command
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for UnformattedContractCode
            /// </summary>
            public const string UnformattedContractCode = "UFMTCONTNO";

            /// <summary>
            /// Property for TaxReportingAmount1
            /// </summary>
            public const string TaxReportingAmount1 = "TARAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2
            /// </summary>
            public const string TaxReportingAmount2 = "TARAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3
            /// </summary>
            public const string TaxReportingAmount3 = "TARAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4
            /// </summary>
            public const string TaxReportingAmount4 = "TARAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5
            /// </summary>
            public const string TaxReportingAmount5 = "TARAMOUNT5";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount1
            /// </summary>
            public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount2
            /// </summary>
            public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount3
            /// </summary>
            public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount4
            /// </summary>
            public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount5
            /// </summary>
            public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt1
            /// </summary>
            public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt2
            /// </summary>
            public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt3
            /// </summary>
            public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt4
            /// </summary>
            public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt5
            /// </summary>
            public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

            /// <summary>
            /// Property for TaxReportingExpenseAmount1
            /// </summary>
            public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

            /// <summary>
            /// Property for TaxReportingExpenseAmount2
            /// </summary>
            public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

            /// <summary>
            /// Property for TaxReportingExpenseAmount3
            /// </summary>
            public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

            /// <summary>
            /// Property for TaxReportingExpenseAmount4
            /// </summary>
            public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

            /// <summary>
            /// Property for TaxReportingExpenseAmount5
            /// </summary>
            public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

            /// <summary>
            /// Property for TaxReportingIncludedAmount1
            /// </summary>
            public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncludedAmount2
            /// </summary>
            public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncludedAmount3
            /// </summary>
            public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncludedAmount4
            /// </summary>
            public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncludedAmount5
            /// </summary>
            public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcludedAmount1
            /// </summary>
            public const string TaxReportingExcludedAmount1 = "TREXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcludedAmount2
            /// </summary>
            public const string TaxReportingExcludedAmount2 = "TREXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcludedAmount3
            /// </summary>
            public const string TaxReportingExcludedAmount3 = "TREXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcludedAmount4
            /// </summary>
            public const string TaxReportingExcludedAmount4 = "TREXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcludedAmount5
            /// </summary>
            public const string TaxReportingExcludedAmount5 = "TREXCLUDE5";

            /// <summary>
            /// Property for TaxReportingTotalAmount
            /// </summary>
            public const string TaxReportingTotalAmount = "TARAMOUNT";

            /// <summary>
            /// Property for TaxReportingIncludedAmount
            /// </summary>
            public const string TaxReportingIncludedAmount = "TRINCLUDED";

            /// <summary>
            /// Property for TaxReportingExcludedAmount
            /// </summary>
            public const string TaxReportingExcludedAmount = "TREXCLUDED";

            /// <summary>
            /// Property for TaxReportingRecoverableAmount
            /// </summary>
            public const string TaxReportingRecoverableAmount = "TRRECVAMT";

            /// <summary>
            /// Property for TaxReportingExpensedAmount
            /// </summary>
            public const string TaxReportingExpensedAmount = "TREXPSAMT";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount
            /// </summary>
            public const string TaxReportingAllocatedAmount = "TRALLOAMT";

            /// <summary>
            /// Property for RetainageTaxBase1
            /// </summary>
            public const string RetainageTaxBase1 = "RAXBASE1";

            /// <summary>
            /// Property for RetainageTaxBase2
            /// </summary>
            public const string RetainageTaxBase2 = "RAXBASE2";

            /// <summary>
            /// Property for RetainageTaxBase3
            /// </summary>
            public const string RetainageTaxBase3 = "RAXBASE3";

            /// <summary>
            /// Property for RetainageTaxBase4
            /// </summary>
            public const string RetainageTaxBase4 = "RAXBASE4";

            /// <summary>
            /// Property for RetainageTaxBase5
            /// </summary>
            public const string RetainageTaxBase5 = "RAXBASE5";

            /// <summary>
            /// Property for RetainageTaxAmount1
            /// </summary>
            public const string RetainageTaxAmount1 = "RAXAMOUNT1";

            /// <summary>
            /// Property for RetainageTaxAmount2
            /// </summary>
            public const string RetainageTaxAmount2 = "RAXAMOUNT2";

            /// <summary>
            /// Property for RetainageTaxAmount3
            /// </summary>
            public const string RetainageTaxAmount3 = "RAXAMOUNT3";

            /// <summary>
            /// Property for RetainageTaxAmount4
            /// </summary>
            public const string RetainageTaxAmount4 = "RAXAMOUNT4";

            /// <summary>
            /// Property for RetainageTaxAmount5
            /// </summary>
            public const string RetainageTaxAmount5 = "RAXAMOUNT5";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt1
            /// </summary>
            public const string RetainageTaxRecoverableAmt1 = "RXRECVAMT1";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt2
            /// </summary>
            public const string RetainageTaxRecoverableAmt2 = "RXRECVAMT2";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt3
            /// </summary>
            public const string RetainageTaxRecoverableAmt3 = "RXRECVAMT3";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt4
            /// </summary>
            public const string RetainageTaxRecoverableAmt4 = "RXRECVAMT4";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt5
            /// </summary>
            public const string RetainageTaxRecoverableAmt5 = "RXRECVAMT5";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount1
            /// </summary>
            public const string RetainageTaxExpenseAmount1 = "RXEXPSAMT1";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount2
            /// </summary>
            public const string RetainageTaxExpenseAmount2 = "RXEXPSAMT2";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount3
            /// </summary>
            public const string RetainageTaxExpenseAmount3 = "RXEXPSAMT3";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount4
            /// </summary>
            public const string RetainageTaxExpenseAmount4 = "RXEXPSAMT4";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount5
            /// </summary>
            public const string RetainageTaxExpenseAmount5 = "RXEXPSAMT5";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount1
            /// </summary>
            public const string RetainageTaxAllocatedAmount1 = "RXALLOAMT1";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount2
            /// </summary>
            public const string RetainageTaxAllocatedAmount2 = "RXALLOAMT2";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount3
            /// </summary>
            public const string RetainageTaxAllocatedAmount3 = "RXALLOAMT3";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount4
            /// </summary>
            public const string RetainageTaxAllocatedAmount4 = "RXALLOAMT4";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount5
            /// </summary>
            public const string RetainageTaxAllocatedAmount5 = "RXALLOAMT5";

            /// <summary>
            /// Property for RetainageTaxTotalAmount
            /// </summary>
            public const string RetainageTaxTotalAmount = "RAXAMOUNT";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt1 = "TXRXAMT1";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt2 = "TXRXAMT2";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt3 = "TXRXAMT3";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt4 = "TXRXAMT4";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt5 = "TXRXAMT5";

            /// <summary>
            /// Property for UnitCostIsManual
            /// </summary>
            public const string UnitCostIsManual = "UCISMANUAL";

            /// <summary>
            /// Property for WeightUnitOfMeasure
            /// </summary>
            public const string WeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for WeightConversion
            /// </summary>
            public const string WeightConversion = "WEIGHTCONV";

            /// <summary>
            /// Property for DefaultUnitWeight
            /// </summary>
            public const string DefaultUnitWeight = "DEFUWEIGHT";

            /// <summary>
            /// Property for DefaultExtendedWeight
            /// </summary>
            public const string DefaultExtendedWeight = "DEFEXTWGHT";

            /// <summary>
            /// Property for BillingRateConversionFactor
            /// </summary>
            public const string BillingRateConversionFactor = "BILLRATECV";

            /// <summary>
            /// Property for UnitBillingAmount
            /// </summary>
            public const string UnitBillingAmount = "UNITBILLSR";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "EXTBILLSR";

            /// <summary>
            /// Property for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Property for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Property for QuantityperLot
            /// </summary>
            public const string QuantityperLot = "XPERLOTQTY";

            /// <summary>
            /// Property for AllocateFromSerial
            /// </summary>
            public const string AllocateFromSerial = "SALLOCFROM";

            /// <summary>
            /// Property for AllocateFromLot
            /// </summary>
            public const string AllocateFromLot = "LALLOCFROM";

            /// <summary>
            /// Property for SerialLotWindowHandle
            /// </summary>
            public const string SerialLotWindowHandle = "METERHWND";

            /// <summary>
            /// Property for SerialQuantity
            /// </summary>
            public const string SerialQuantity = "SERIALQTY";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "LOTQTY";

            /// <summary>
            /// Property for ItemSerializedLotted
            /// </summary>
            public const string ItemSerializedLotted = "SLITEM";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for BillingCurrencyDecimal
            /// </summary>
            public const string BillingCurrencyDecimal = "BILLCURDEC";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of ReturnLine Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReturnSequenceKey
            /// </summary>
            public const int ReturnSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ReturnLineSequence
            /// </summary>
            public const int ReturnLineSequence = 3;

            /// <summary>
            /// Property Indexer for ReturnCommentSequence
            /// </summary>
            public const int ReturnCommentSequence = 4;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 5;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 6;

            /// <summary>
            /// Property Indexer for PostedToIC
            /// </summary>
            public const int PostedToIC = 7;

            /// <summary>
            /// Property Indexer for CompletionStatus
            /// </summary>
            public const int CompletionStatus = 8;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 9;

            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 10;

            /// <summary>
            /// Property Indexer for ReceiptLineSequence
            /// </summary>
            public const int ReceiptLineSequence = 11;

            /// <summary>
            /// Property Indexer for ItemExists
            /// </summary>
            public const int ItemExists = 12;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 13;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 14;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 15;

            /// <summary>
            /// Property Indexer for VendorItemNumber
            /// </summary>
            public const int VendorItemNumber = 16;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 17;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 18;

            /// <summary>
            /// Property Indexer for ReturningConversionFactor
            /// </summary>
            public const int ReturningConversionFactor = 19;

            /// <summary>
            /// Property Indexer for ReturningUnitDecimals
            /// </summary>
            public const int ReturningUnitDecimals = 20;

            /// <summary>
            /// Property Indexer for StockUnitDecimals
            /// </summary>
            public const int StockUnitDecimals = 21;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 22;

            /// <summary>
            /// Property Indexer for StockingQuantityReceived
            /// </summary>
            public const int StockingQuantityReceived = 23;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 24;

            /// <summary>
            /// Property Indexer for QuantityPreviouslyReturned
            /// </summary>
            public const int QuantityPreviouslyReturned = 25;

            /// <summary>
            /// Property Indexer for QuantityReturned
            /// </summary>
            public const int QuantityReturned = 26;

            /// <summary>
            /// Property Indexer for StockingQuantityReturned
            /// </summary>
            public const int StockingQuantityReturned = 27;

            /// <summary>
            /// Property Indexer for UnitWeight
            /// </summary>
            public const int UnitWeight = 28;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 29;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 30;

            /// <summary>
            /// Property Indexer for ReturnCost
            /// </summary>
            public const int ReturnCost = 31;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 32;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 33;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 34;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 35;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 36;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 37;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 38;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 39;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 40;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 41;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 42;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 43;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 44;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 45;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 46;

            /// <summary>
            /// Property Indexer for TaxIncludable1
            /// </summary>
            public const int TaxIncludable1 = 47;

            /// <summary>
            /// Property Indexer for TaxIncludable2
            /// </summary>
            public const int TaxIncludable2 = 48;

            /// <summary>
            /// Property Indexer for TaxIncludable3
            /// </summary>
            public const int TaxIncludable3 = 49;

            /// <summary>
            /// Property Indexer for TaxIncludable4
            /// </summary>
            public const int TaxIncludable4 = 50;

            /// <summary>
            /// Property Indexer for TaxIncludable5
            /// </summary>
            public const int TaxIncludable5 = 51;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 52;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 53;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 54;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 55;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 56;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 57;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 58;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 59;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 60;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 61;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 62;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 63;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 64;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 65;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 66;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 67;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 68;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 69;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 70;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 71;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 72;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 73;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 74;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 75;

            /// <summary>
            /// Property Indexer for RecoverableTax
            /// </summary>
            public const int RecoverableTax = 76;

            /// <summary>
            /// Property Indexer for ExpensedTax
            /// </summary>
            public const int ExpensedTax = 77;

            /// <summary>
            /// Property Indexer for AllocatedTax
            /// </summary>
            public const int AllocatedTax = 78;

            /// <summary>
            /// Property Indexer for FuncNetOfTax
            /// </summary>
            public const int FuncNetOfTax = 79;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount1
            /// </summary>
            public const int FuncTaxIncludedAmount1 = 80;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount2
            /// </summary>
            public const int FuncTaxIncludedAmount2 = 81;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount3
            /// </summary>
            public const int FuncTaxIncludedAmount3 = 82;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount4
            /// </summary>
            public const int FuncTaxIncludedAmount4 = 83;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount5
            /// </summary>
            public const int FuncTaxIncludedAmount5 = 84;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount1
            /// </summary>
            public const int FuncTaxAllocatedAmount1 = 85;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount2
            /// </summary>
            public const int FuncTaxAllocatedAmount2 = 86;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount3
            /// </summary>
            public const int FuncTaxAllocatedAmount3 = 87;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount4
            /// </summary>
            public const int FuncTaxAllocatedAmount4 = 88;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount5
            /// </summary>
            public const int FuncTaxAllocatedAmount5 = 89;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount1
            /// </summary>
            public const int FuncTaxRecoverableAmount1 = 90;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount2
            /// </summary>
            public const int FuncTaxRecoverableAmount2 = 91;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount3
            /// </summary>
            public const int FuncTaxRecoverableAmount3 = 92;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount4
            /// </summary>
            public const int FuncTaxRecoverableAmount4 = 93;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount5
            /// </summary>
            public const int FuncTaxRecoverableAmount5 = 94;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount1
            /// </summary>
            public const int FuncTaxExpenseAmount1 = 95;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount2
            /// </summary>
            public const int FuncTaxExpenseAmount2 = 96;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount3
            /// </summary>
            public const int FuncTaxExpenseAmount3 = 97;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount4
            /// </summary>
            public const int FuncTaxExpenseAmount4 = 98;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount5
            /// </summary>
            public const int FuncTaxExpenseAmount5 = 99;

            /// <summary>
            /// Property Indexer for ExpenseAccount
            /// </summary>
            public const int ExpenseAccount = 100;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 101;

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 102;

            /// <summary>
            /// Property Indexer for PurchaseOrderLineSequence
            /// </summary>
            public const int PurchaseOrderLineSequence = 103;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 104;

            /// <summary>
            /// Property Indexer for NonStockClearingAccount
            /// </summary>
            public const int NonStockClearingAccount = 105;

            /// <summary>
            /// Property Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 106;

            /// <summary>
            /// Property Indexer for DiscountReceived
            /// </summary>
            public const int DiscountReceived = 107;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 108;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 109;

            /// <summary>
            /// Property Indexer for FuncDiscountAmount
            /// </summary>
            public const int FuncDiscountAmount = 110;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 111;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 112;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 113;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 114;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 115;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 116;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 117;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 118;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 119;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 120;

            /// <summary>
            /// Property Indexer for RetainagePercentage
            /// </summary>
            public const int RetainagePercentage = 121;

            /// <summary>
            /// Property Indexer for RetentionPeriod
            /// </summary>
            public const int RetentionPeriod = 122;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 123;

            /// <summary>
            /// Property Indexer for RetainageAmountOverridden
            /// </summary>
            public const int RetainageAmountOverridden = 124;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 141;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 142;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 143;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 144;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 145;

            /// <summary>
            /// Property Indexer for ExpenseAccountDescription
            /// </summary>
            public const int ExpenseAccountDescription = 146;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 147;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 148;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 149;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 150;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 151;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 152;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 153;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 154;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 155;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 156;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 157;

            /// <summary>
            /// Property Indexer for ExtraneousLineCount
            /// </summary>
            public const int ExtraneousLineCount = 158;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 159;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 160;

            /// <summary>
            /// Property Indexer for Line
            /// </summary>
            public const int Line = 161;

            /// <summary>
            /// Property Indexer for ExtendedStdCostInSrcCurr
            /// </summary>
            public const int ExtendedStdCostInSrcCurr = 162;

            /// <summary>
            /// Property Indexer for ExtendedMRCostInSrcCurr
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int ExtendedMRCostInSrcCurr = 163;

            /// <summary>
            /// Property Indexer for ExtendedCost1InSrcCurr
            /// </summary>
            public const int ExtendedCost1InSrcCurr = 164;

            /// <summary>
            /// Property Indexer for ExtendedCost2InSrcCurr
            /// </summary>
            public const int ExtendedCost2InSrcCurr = 165;

            /// <summary>
            /// Property Indexer for NonStockClearingAccountDesc
            /// </summary>
            public const int NonStockClearingAccountDesc = 166;

            /// <summary>
            /// Property Indexer for InterprocessCommID
            /// </summary>
            public const int InterprocessCommID = 167;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int ForcePopupSN = 168;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int PopupSN = 169;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int CloseSN = 170;

            /// <summary>
            /// Property Indexer for LTSetID
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int LTSetID = 171;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int ForcePopupLT = 172;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int PopupLT = 173;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int CloseLT = 174;

            /// <summary>
            /// Property Indexer for MapManufacturersItemNumber
            /// </summary>
            public const int MapManufacturersItemNumber = 175;

            /// <summary>
            /// Property Indexer for NetReturnCost
            /// </summary>
            public const int NetReturnCost = 176;

            /// <summary>
            /// Property Indexer for RCPLREV
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int RCPLREV = 177;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 178;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 179;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 180;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 181;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 182;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 183;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 184;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 185;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 186;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 187;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 188;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 189;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 190;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 191;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 192;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 193;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 194;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 195;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 196;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 197;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 198;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 199;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 200;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 201;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 202;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 203;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 204;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 205;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 206;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 207;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 208;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 209;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 210;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 211;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 212;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 213;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 214;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 215;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 216;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 217;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 218;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 219;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 220;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 221;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 222;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 223;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 224;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 225;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 226;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 227;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 228;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt1
            /// </summary>
            public const int RetainageTaxRecoverableAmt1 = 229;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt2
            /// </summary>
            public const int RetainageTaxRecoverableAmt2 = 230;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt3
            /// </summary>
            public const int RetainageTaxRecoverableAmt3 = 231;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt4
            /// </summary>
            public const int RetainageTaxRecoverableAmt4 = 232;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt5
            /// </summary>
            public const int RetainageTaxRecoverableAmt5 = 233;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount1
            /// </summary>
            public const int RetainageTaxExpenseAmount1 = 234;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount2
            /// </summary>
            public const int RetainageTaxExpenseAmount2 = 235;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount3
            /// </summary>
            public const int RetainageTaxExpenseAmount3 = 236;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount4
            /// </summary>
            public const int RetainageTaxExpenseAmount4 = 237;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount5
            /// </summary>
            public const int RetainageTaxExpenseAmount5 = 238;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount1
            /// </summary>
            public const int RetainageTaxAllocatedAmount1 = 239;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount2
            /// </summary>
            public const int RetainageTaxAllocatedAmount2 = 240;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount3
            /// </summary>
            public const int RetainageTaxAllocatedAmount3 = 241;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount4
            /// </summary>
            public const int RetainageTaxAllocatedAmount4 = 242;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount5
            /// </summary>
            public const int RetainageTaxAllocatedAmount5 = 243;

            /// <summary>
            /// Property Indexer for RetainageTaxTotalAmount
            /// </summary>
            public const int RetainageTaxTotalAmount = 244;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt1 = 245;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt2 = 246;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt3 = 247;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt4 = 248;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt5 = 249;

            /// <summary>
            /// Property Indexer for UnitCostIsManual
            /// </summary>
            public const int UnitCostIsManual = 250;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure
            /// </summary>
            public const int WeightUnitOfMeasure = 251;

            /// <summary>
            /// Property Indexer for WeightConversion
            /// </summary>
            public const int WeightConversion = 252;

            /// <summary>
            /// Property Indexer for DefaultUnitWeight
            /// </summary>
            public const int DefaultUnitWeight = 253;

            /// <summary>
            /// Property Indexer for DefaultExtendedWeight
            /// </summary>
            public const int DefaultExtendedWeight = 254;

            /// <summary>
            /// Property Indexer for BillingRateConversionFactor
            /// </summary>
            public const int BillingRateConversionFactor = 255;

            /// <summary>
            /// Property Indexer for UnitBillingAmount
            /// </summary>
            public const int UnitBillingAmount = 256;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 257;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 258;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 259;

            /// <summary>
            /// Property Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 260;

            /// <summary>
            /// Property Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 261;

            /// <summary>
            /// Property Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 262;

            /// <summary>
            /// Property Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 263;

            /// <summary>
            /// Property Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 264;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 265;

            /// <summary>
            /// Property Indexer for ItemSerializedLotted
            /// </summary>
            public const int ItemSerializedLotted = 266;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 267;

            /// <summary>
            /// Property Indexer for BillingCurrencyDecimal
            /// </summary>
            public const int BillingCurrencyDecimal = 268;
        }
        #endregion
    }
}