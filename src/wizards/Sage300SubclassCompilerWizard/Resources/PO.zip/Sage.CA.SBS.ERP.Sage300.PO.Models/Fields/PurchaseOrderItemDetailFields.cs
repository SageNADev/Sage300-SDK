// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseOrderItemDetail Constants
    /// </summary>
    public partial class PurchaseOrderItemDetail
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0634";

        #region Properties

        /// <summary>
        /// Contains list of PurchaseOrderItemDetail Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for PurchaseOrderLineSequence
            /// </summary>
            public const string PurchaseOrderLineSequence = "PORLSEQ";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "ORDNUMBER";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "ORDERUNIT";

            /// <summary>
            /// Property for QuantityOrdered
            /// </summary>
            public const string QuantityOrdered = "OQORDERED";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ExpectedArrivalDate
            /// </summary>
            public const string ExpectedArrivalDate = "EXPARRIVAL";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VDCODE";

            /// <summary>
            /// Property for VendorName
            /// </summary>
            public const string VendorName = "VDNAME";

            /// <summary>
            /// Property for PurchaseOrderType
            /// </summary>
            public const string PurchaseOrderType = "PORTYPE";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PurchaseOrderItemDetail Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 1;

            /// <summary>
            /// Property Indexer for PurchaseOrderLineSequence
            /// </summary>
            public const int PurchaseOrderLineSequence = 2;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 3;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 4;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 5;

            /// <summary>
            /// Property Indexer for QuantityOrdered
            /// </summary>
            public const int QuantityOrdered = 6;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 7;

            /// <summary>
            /// Property Indexer for ExpectedArrivalDate
            /// </summary>
            public const int ExpectedArrivalDate = 8;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 9;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 10;

            /// <summary>
            /// Property Indexer for VendorName
            /// </summary>
            public const int VendorName = 11;

            /// <summary>
            /// Property Indexer for PurchaseOrderType
            /// </summary>
            public const int PurchaseOrderType = 12;

        }

        #endregion

    }
}
