// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of Vendor Contract Included Tax Constants
     /// </summary>
     public partial class VendorContractIncludedTax
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0183";

          #region Field Properties
          /// <summary>
          /// Contains list of Vendor Contract Included Tax Field Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Item Number
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for Vendor
               /// </summary>
               public const string Vendor = "VDCODE";

               /// <summary>
               /// Property for Tax Authority
               /// </summary>
               public const string TaxAuthority = "TAXAUTH";

               /// <summary>
               /// Property for Tax Class
               /// </summary>
               public const string TaxClass = "TAXCLASS";

               /// <summary>
               /// Property for Tax Authority Description
               /// </summary>
               public const string TaxAuthorityDescription = "TAXAUTHD";

               /// <summary>
               /// Property for Tax Class Description
               /// </summary>
               public const string TaxClassDescription = "TAXCLASSD";

          }
          #endregion

          #region Index Properties
          /// <summary>
          /// Contains list of Vendor Contract Included Tax Index Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Item Number
               /// </summary>
               public const int ItemNumber = 1;

               /// <summary>
               /// Property Indexer for Vendor
               /// </summary>
               public const int Vendor = 2;

               /// <summary>
               /// Property Indexer for Tax Authority
               /// </summary>
               public const int TaxAuthority = 3;

               /// <summary>
               /// Property Indexer for Tax Class
               /// </summary>
               public const int TaxClass = 4;

               /// <summary>
               /// Property Indexer for Tax Authority Description
               /// </summary>
               public const int TaxAuthorityDescription = 11;

               /// <summary>
               /// Property Indexer for Tax Class Description
               /// </summary>
               public const int TaxClassDescription = 12;

          }
          #endregion

     }
}
