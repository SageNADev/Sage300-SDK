/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of P/O Options Constants
    /// </summary>
    public partial class Options
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "PO0600";

        #region Properties
        /// <summary>
        /// Contains list of PurchaseOrderOption Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for KeyField
            /// </summary>
            public const string KeyField = "DUMMY";

            /// <summary>
            /// Property for NextControlSequence
            /// </summary>
            public const string NextControlSequence = "NEXTSEQ";

            /// <summary>
            /// Property for PhoneNumber
            /// </summary>
            public const string PhoneNumber = "PHONE";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "CONTACT";

            /// <summary>
            /// Property for DefaultRateType
            /// </summary>
            public const string DefaultRateType = "RATETYPE";

            /// <summary>
            /// Property for AllowNonInventoryItems
            /// </summary>
            public const string AllowNonInventoryItems = "NOXITEMPER";

            /// <summary>
            /// Property for KeepPurchaseHistory
            /// </summary>
            public const string KeepPurchaseHistory = "ORDHIST";

            /// <summary>
            /// Property for KeepTransactionHistory
            /// </summary>
            public const string KeepTransactionHistory = "TRANHIST";

            /// <summary>
            /// Property for KeepStatistics
            /// </summary>
            public const string KeepStatistics = "KEEPSTAT";

            /// <summary>
            /// Property for EditStatistics
            /// </summary>
            public const string EditStatistics = "EDITSTAT";

            /// <summary>
            /// Property for AccumulateHistoryBy
            /// </summary>
            public const string AccumulateHistoryBy = "ORDYEAR";

            /// <summary>
            /// Property for HistoryPeriodsBy
            /// </summary>
            public const string HistoryPeriodsBy = "ORDPERIOD";

            /// <summary>
            /// Property for AccumulateStatisticsBy
            /// </summary>
            public const string AccumulateStatisticsBy = "STATYEAR";

            /// <summary>
            /// Property for StatisticsPeriodsBy
            /// </summary>
            public const string StatisticsPeriodsBy = "STATPERIOD";

            /// <summary>
            /// Property for AgingPeriod1
            /// </summary>
            public const string AgingPeriod1 = "AGEDAYS1";

            /// <summary>
            /// Property for AgingPeriod2
            /// </summary>
            public const string AgingPeriod2 = "AGEDAYS2";

            /// <summary>
            /// Property for AgingPeriod3
            /// </summary>
            public const string AgingPeriod3 = "AGEDAYS3";

            /// <summary>
            /// Property for RequisitionLength
            /// </summary>
            public const string RequisitionLength = "RQNNUMBERL";

            /// <summary>
            /// Property for RequisitionPrefix
            /// </summary>
            public const string RequisitionPrefix = "RQNPREFIXD";

            /// <summary>
            /// Property for RequisitionNumber
            /// </summary>
            public const string RequisitionNumber = "RQNBODYD";

            /// <summary>
            /// Property for PurchaseOrderLength
            /// </summary>
            public const string PurchaseOrderLength = "PORNUMBERL";

            /// <summary>
            /// Property for PurchaseOrderPrefix
            /// </summary>
            public const string PurchaseOrderPrefix = "PORPREFIXD";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PORBODYD";

            /// <summary>
            /// Property for ReceiptLength
            /// </summary>
            public const string ReceiptLength = "RCPNUMBERL";

            /// <summary>
            /// Property for ReceiptPrefix
            /// </summary>
            public const string ReceiptPrefix = "RCPPREFIXD";

            /// <summary>
            /// Property for ReceiptNumber
            /// </summary>
            public const string ReceiptNumber = "RCPBODYD";

            /// <summary>
            /// Property for ReturnLength
            /// </summary>
            public const string ReturnLength = "RETNUMBERL";

            /// <summary>
            /// Property for ReturnPrefix
            /// </summary>
            public const string ReturnPrefix = "RETPREFIXD";

            /// <summary>
            /// Property for ReturnNumber
            /// </summary>
            public const string ReturnNumber = "RETBODYD";

            /// <summary>
            /// Property for DefaultTemplateCode
            /// </summary>
            public const string DefaultTemplateCode = "DEFTEMP";

            /// <summary>
            /// Property for LastGLDayEndSequence
            /// </summary>
            public const string LastGLDayEndSequence = "LGENDAYEND";

            /// <summary>
            /// Property for AppendToExistingGLBatch
            /// </summary>
            public const string AppendToExistingGLBatch = "APPENDGL";

            /// <summary>
            /// Property for GLConsolidation
            /// </summary>
            public const string GLConsolidation = "CONSOLGL";

            /// <summary>
            /// Property for GenerateGLBatchesOnDemand
            /// </summary>
            public const string GenerateGLBatchesOnDemand = "DEFERGL";

            /// <summary>
            /// Property for ContentsOfGLReference
            /// </summary>
            public const string ContentsOfGLReference = "REFERENCGL";

            /// <summary>
            /// Property for ContentsOfGLDescription
            /// </summary>
            public const string ContentsOfGLDescription = "DESCRIPTGL";

            /// <summary>
            /// Property for DefaultInventoryExpenseAccoun
            /// </summary>
            public const string DefaultInventoryExpenseAccoun = "GLACEXPENS";

            /// <summary>
            /// Property for DefaultCostExpenseAccount
            /// </summary>
            public const string DefaultCostExpenseAccount = "GLCSTACCT";

            /// <summary>
            /// Property for DefaultCost
            /// </summary>
            public const string DefaultCost = "DEFCOST";

            /// <summary>
            /// Property for NonInventoryPayableClearingA
            /// </summary>
            public const string NonInventoryPayableClearingA = "NIPAYBACCT";

            /// <summary>
            /// Property for PostToNonInvPbClrAcct
            /// </summary>
            public const string PostToNonInvPbClrAcct = "NONINVTOGL";

            /// <summary>
            /// Property for ExpAdditionalCostPayableCle
            /// </summary>
            public const string ExpAdditionalCostPayableCle = "EAPAYBACCT";

            /// <summary>
            /// Property for PostToExpAddlCostPbClr
            /// </summary>
            public const string PostToExpAddlCostPbClr = "EXPADDTOGL";

            /// <summary>
            /// Property for DeferredAPPosting
            /// </summary>
            public const string DeferredAPPosting = "DEFERAPPST";

            /// <summary>
            /// Property for POAdjustments
            /// </summary>
            public const string POAdjustments = "SRCTYPEAD";

            /// <summary>
            /// Property for POConsolidation
            /// </summary>
            public const string POConsolidation = "SRCTYPECO";

            /// <summary>
            /// Property for POCreditNotes
            /// </summary>
            public const string POCreditNotes = "SRCTYPECR";

            /// <summary>
            /// Property for PODebitNotes
            /// </summary>
            public const string PODebitNotes = "SRCTYPEDB";

            /// <summary>
            /// Property for POInvoices
            /// </summary>
            public const string POInvoices = "SRCTYPEIN";

            /// <summary>
            /// Property for POReceiptAdjustments
            /// </summary>
            public const string POReceiptAdjustments = "SRCTYPERA";

            /// <summary>
            /// Property for POReceipts
            /// </summary>
            public const string POReceipts = "SRCTYPERC";

            /// <summary>
            /// Property for POReturnAdjustments
            /// </summary>
            public const string POReturnAdjustments = "SRCTYPERJ";

            /// <summary>
            /// Property for POReturns
            /// </summary>
            public const string POReturns = "SRCTYPERT";

            /// <summary>
            /// Property for AllowNonExistingVendors
            /// </summary>
            public const string AllowNonExistingVendors = "ALLOWNXVD";

            /// <summary>
            /// Property for WarnifNonExistingItem
            /// </summary>
            public const string WarnifNonExistingItem = "WARNNOITEM";

            /// <summary>
            /// Property for DefaultPostingDate
            /// </summary>
            public const string DefaultPostingDate = "DATEBUSDFT";

            /// <summary>
            /// Property for RecentLastCostPostingAt
            /// </summary>
            public const string RecentLastCostPostingAt = "POSTRECENT";

            /// <summary>
            /// Property for DefaultCopyCostToPurchaseOr
            /// </summary>
            public const string DefaultCopyCostToPurchaseOr = "CPCOSTTOPO";

            /// <summary>
            /// Property for RequisitionManualApproval
            /// </summary>
            public const string RequisitionManualApproval = "RQNMANAPPR";

            /// <summary>
            /// Property for AllowReceiptsInNegativeInven
            /// </summary>
            public const string AllowReceiptsInNegativeInven = "RCPNEGINV";

            /// <summary>
            /// Property for DefaultRequisition
            /// </summary>
            public const string DefaultRequisition = "RQNDEFAULT";

            /// <summary>
            /// Property for NextRequisition
            /// </summary>
            public const string NextRequisition = "RQNVALUE";

            /// <summary>
            /// Property for DefaultPurchaseOrder
            /// </summary>
            public const string DefaultPurchaseOrder = "PORDEFAULT";

            /// <summary>
            /// Property for NextPurchaseOrder
            /// </summary>
            public const string NextPurchaseOrder = "PORVALUE";

            /// <summary>
            /// Property for DefaultReceipt
            /// </summary>
            public const string DefaultReceipt = "RCPDEFAULT";

            /// <summary>
            /// Property for NextReceipt
            /// </summary>
            public const string NextReceipt = "RCPVALUE";

            /// <summary>
            /// Property for DefaultReturn
            /// </summary>
            public const string DefaultReturn = "RETDEFAULT";

            /// <summary>
            /// Property for NextReturn
            /// </summary>
            public const string NextReturn = "RETVALUE";

            /// <summary>
            /// Property for HistoricalPeriodType
            /// </summary>
            public const string HistoricalPeriodType = "ORDPRDTYP";

            /// <summary>
            /// Property for HistoricalPeriodLength
            /// </summary>
            public const string HistoricalPeriodLength = "ORDPRDLNG";

            /// <summary>
            /// Property for HistoricalPeriods
            /// </summary>
            public const string HistoricalPeriods = "ORDPRDS";

            /// <summary>
            /// Property for StatisticalPeriodType
            /// </summary>
            public const string StatisticalPeriodType = "STATPRDTYP";

            /// <summary>
            /// Property for StatisticalPeriodLength
            /// </summary>
            public const string StatisticalPeriodLength = "STATPRDLNG";

            /// <summary>
            /// Property for StatisticalPeriods
            /// </summary>
            public const string StatisticalPeriods = "STATPRDS";

            /// <summary>
            /// Property for DocumentFormatsSet
            /// </summary>
            public const string DocumentFormatsSet = "DOCSETUP";

            /// <summary>
            /// Property for NextDayEndSequence
            /// </summary>
            public const string NextDayEndSequence = "NEXTDAYEND";

            /// <summary>
            /// Property for CostExpenseAcctDesc
            /// </summary>
            public const string CostExpenseAcctDesc = "GLCSTACCTD";

            /// <summary>
            /// Property for InventoryExpenseAcctDesc
            /// </summary>
            public const string InventoryExpenseAcctDesc = "GLACEXPNSD";

            /// <summary>
            /// Property for WeightUnitOfMeasure
            /// </summary>
            public const string WeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for FractionalQuantities
            /// </summary>
            public const string FractionalQuantities = "FRACTQTY";

            /// <summary>
            /// Property for HomeCurrency
            /// </summary>
            public const string HomeCurrency = "HOMECURR";

            /// <summary>
            /// Property for DatabaseDriverID
            /// </summary>
            public const string DatabaseDriverID = "DRIVERID";

            /// <summary>
            /// Property for CostDuring
            /// </summary>
            public const string CostDuring = "COSTDURING";

            /// <summary>
            /// Property for NonInvPblsClrAcctDesc
            /// </summary>
            public const string NonInvPblsClrAcctDesc = "NIPAYBACCD";

            /// <summary>
            /// Property for ExpAddlCostPblsClrAcct
            /// </summary>
            public const string ExpAddlCostPblsClrAcct = "EAPAYBACCD";

            /// <summary>
            /// Property for Action
            /// </summary>
            public const string Action = "ACTION";

            /// <summary>
            /// Property for CreateSubledgerAuditDuring
            /// </summary>
            public const string CreateSubledgerAuditDuring = "SLAUDURING";

            /// <summary>
            /// Property for Transactionpostdepcost
            /// </summary>
            public const string Transactionpostdepcost = "TPOSTACTN";

            /// <summary>
            /// Property for TaxGroupDescription
            /// </summary>
            public const string TaxGroupDescription = "TAXGROUPD";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of PurchaseOrderOption Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for KeyField
            /// </summary>
            public const int KeyField = 1;

            /// <summary>
            /// Property Indexer for NextControlSequence
            /// </summary>
            public const int NextControlSequence = 2;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 3;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 4;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 5;

            /// <summary>
            /// Property Indexer for DefaultRateType
            /// </summary>
            public const int DefaultRateType = 6;

            /// <summary>
            /// Property Indexer for AllowNonInventoryItems
            /// </summary>
            public const int AllowNonInventoryItems = 7;

            /// <summary>
            /// Property Indexer for KeepPurchaseHistory
            /// </summary>
            public const int KeepPurchaseHistory = 8;

            /// <summary>
            /// Property Indexer for KeepTransactionHistory
            /// </summary>
            public const int KeepTransactionHistory = 9;

            /// <summary>
            /// Property Indexer for KeepStatistics
            /// </summary>
            public const int KeepStatistics = 10;

            /// <summary>
            /// Property Indexer for EditStatistics
            /// </summary>
            public const int EditStatistics = 11;

            /// <summary>
            /// Property Indexer for AccumulateHistoryBy
            /// </summary>
            public const int AccumulateHistoryBy = 12;

            /// <summary>
            /// Property Indexer for HistoryPeriodsBy
            /// </summary>
            public const int HistoryPeriodsBy = 13;

            /// <summary>
            /// Property Indexer for AccumulateStatisticsBy
            /// </summary>
            public const int AccumulateStatisticsBy = 14;

            /// <summary>
            /// Property Indexer for StatisticsPeriodsBy
            /// </summary>
            public const int StatisticsPeriodsBy = 15;

            /// <summary>
            /// Property Indexer for AgingPeriod1
            /// </summary>
            public const int AgingPeriod1 = 16;

            /// <summary>
            /// Property Indexer for AgingPeriod2
            /// </summary>
            public const int AgingPeriod2 = 17;

            /// <summary>
            /// Property Indexer for AgingPeriod3
            /// </summary>
            public const int AgingPeriod3 = 18;

            /// <summary>
            /// Property Indexer for RequisitionLength
            /// </summary>
            public const int RequisitionLength = 19;

            /// <summary>
            /// Property Indexer for RequisitionPrefix
            /// </summary>
            public const int RequisitionPrefix = 20;

            /// <summary>
            /// Property Indexer for RequisitionNumber
            /// </summary>
            public const int RequisitionNumber = 21;

            /// <summary>
            /// Property Indexer for PurchaseOrderLength
            /// </summary>
            public const int PurchaseOrderLength = 22;

            /// <summary>
            /// Property Indexer for PurchaseOrderPrefix
            /// </summary>
            public const int PurchaseOrderPrefix = 23;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 24;

            /// <summary>
            /// Property Indexer for ReceiptLength
            /// </summary>
            public const int ReceiptLength = 25;

            /// <summary>
            /// Property Indexer for ReceiptPrefix
            /// </summary>
            public const int ReceiptPrefix = 26;

            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 27;

            /// <summary>
            /// Property Indexer for ReturnLength
            /// </summary>
            public const int ReturnLength = 28;

            /// <summary>
            /// Property Indexer for ReturnPrefix
            /// </summary>
            public const int ReturnPrefix = 29;

            /// <summary>
            /// Property Indexer for ReturnNumber
            /// </summary>
            public const int ReturnNumber = 30;

            /// <summary>
            /// Property Indexer for DefaultTemplateCode
            /// </summary>
            public const int DefaultTemplateCode = 31;

            /// <summary>
            /// Property Indexer for LastGLDayEndSequence
            /// </summary>
            public const int LastGLDayEndSequence = 54;

            /// <summary>
            /// Property Indexer for AppendToExistingGLBatch
            /// </summary>
            public const int AppendToExistingGLBatch = 55;

            /// <summary>
            /// Property Indexer for GLConsolidation
            /// </summary>
            public const int GLConsolidation = 56;

            /// <summary>
            /// Property Indexer for GenerateGLBatchesOnDemand
            /// </summary>
            public const int GenerateGLBatchesOnDemand = 57;

            /// <summary>
            /// Property Indexer for ContentsOfGLReference
            /// </summary>
            public const int ContentsOfGLReference = 58;

            /// <summary>
            /// Property Indexer for ContentsOfGLDescription
            /// </summary>
            public const int ContentsOfGLDescription = 59;

            /// <summary>
            /// Property Indexer for DefaultInventoryExpenseAccount
            /// </summary>
            public const int DefaultInventoryExpenseAccount = 60;

            /// <summary>
            /// Property Indexer for DefaultCostExpenseAccount
            /// </summary>
            public const int DefaultCostExpenseAccount = 61;

            /// <summary>
            /// Property Indexer for DefaultCost
            /// </summary>
            public const int DefaultCost = 62;

            /// <summary>
            /// Property Indexer for NonInventoryPayableClearingAccount
            /// </summary>
            public const int NonInventoryPayableClearingAccount = 63;

            /// <summary>
            /// Property Indexer for PostToNonInvPbClrAcct
            /// </summary>
            public const int PostToNonInvPbClrAcct = 64;

            /// <summary>
            /// Property Indexer for ExpAdditionalCostPayableClearingAccount
            /// </summary>
            public const int ExpAdditionalCostPayableClearingAccount = 65;

            /// <summary>
            /// Property Indexer for PostToExpAddlCostPbClr
            /// </summary>
            public const int PostToExpAddlCostPbClr = 66;

            /// <summary>
            /// Property Indexer for DeferredAPPosting
            /// </summary>
            public const int DeferredAPPosting = 67;

            /// <summary>
            /// Property Indexer for POAdjustments
            /// </summary>
            public const int POAdjustments = 68;

            /// <summary>
            /// Property Indexer for POConsolidation
            /// </summary>
            public const int POConsolidation = 69;

            /// <summary>
            /// Property Indexer for POCreditNotes
            /// </summary>
            public const int POCreditNotes = 70;

            /// <summary>
            /// Property Indexer for PODebitNotes
            /// </summary>
            public const int PODebitNotes = 71;

            /// <summary>
            /// Property Indexer for POInvoices
            /// </summary>
            public const int POInvoices = 72;

            /// <summary>
            /// Property Indexer for POReceiptAdjustments
            /// </summary>
            public const int POReceiptAdjustments = 73;

            /// <summary>
            /// Property Indexer for POReceipts
            /// </summary>
            public const int POReceipts = 74;

            /// <summary>
            /// Property Indexer for POReturnAdjustments
            /// </summary>
            public const int POReturnAdjustments = 75;

            /// <summary>
            /// Property Indexer for POReturns
            /// </summary>
            public const int POReturns = 76;

            /// <summary>
            /// Property Indexer for AllowNonExistingVendors
            /// </summary>
            public const int AllowNonExistingVendors = 77;

            /// <summary>
            /// Property Indexer for WarnifNonExistingItem
            /// </summary>
            public const int WarnifNonExistingItem = 78;

            /// <summary>
            /// Property Indexer for DefaultPostingDate
            /// </summary>
            public const int DefaultPostingDate = 79;

            /// <summary>
            /// Property Indexer for RecentLastCostPostingAt
            /// </summary>
            public const int RecentLastCostPostingAt = 80;

            /// <summary>
            /// Property Indexer for DefaultCopyCostToPurchaseOr
            /// </summary>
            public const int DefaultCopyCostToPurchaseOr = 81;

            /// <summary>
            /// Property Indexer for RequisitionManualApproval
            /// </summary>
            public const int RequisitionManualApproval = 82;

            /// <summary>
            /// Property Indexer for AllowReceiptsInNegativeInven
            /// </summary>
            public const int AllowReceiptsInNegativeInven = 83;

            /// <summary>
            /// Property Indexer for DefaultRequisition
            /// </summary>
            public const int DefaultRequisition = 101;

            /// <summary>
            /// Property Indexer for NextRequisition
            /// </summary>
            public const int NextRequisition = 102;

            /// <summary>
            /// Property Indexer for DefaultPurchaseOrder
            /// </summary>
            public const int DefaultPurchaseOrder = 103;

            /// <summary>
            /// Property Indexer for NextPurchaseOrder
            /// </summary>
            public const int NextPurchaseOrder = 104;

            /// <summary>
            /// Property Indexer for DefaultReceipt
            /// </summary>
            public const int DefaultReceipt = 105;

            /// <summary>
            /// Property Indexer for NextReceipt
            /// </summary>
            public const int NextReceipt = 106;

            /// <summary>
            /// Property Indexer for DefaultReturn
            /// </summary>
            public const int DefaultReturn = 107;

            /// <summary>
            /// Property Indexer for NextReturn
            /// </summary>
            public const int NextReturn = 108;

            /// <summary>
            /// Property Indexer for HistoricalPeriodType
            /// </summary>
            public const int HistoricalPeriodType = 109;

            /// <summary>
            /// Property Indexer for HistoricalPeriodLength
            /// </summary>
            public const int HistoricalPeriodLength = 110;

            /// <summary>
            /// Property Indexer for HistoricalPeriods
            /// </summary>
            public const int HistoricalPeriods = 111;

            /// <summary>
            /// Property Indexer for StatisticalPeriodType
            /// </summary>
            public const int StatisticalPeriodType = 112;

            /// <summary>
            /// Property Indexer for StatisticalPeriodLength
            /// </summary>
            public const int StatisticalPeriodLength = 113;

            /// <summary>
            /// Property Indexer for StatisticalPeriods
            /// </summary>
            public const int StatisticalPeriods = 114;

            /// <summary>
            /// Property Indexer for DocumentFormatsSet
            /// </summary>
            public const int DocumentFormatsSet = 115;

            /// <summary>
            /// Property Indexer for NextDayEndSequence
            /// </summary>
            public const int NextDayEndSequence = 116;

            /// <summary>
            /// Property Indexer for CostExpenseAcctDesc
            /// </summary>
            public const int CostExpenseAcctDesc = 117;

            /// <summary>
            /// Property Indexer for InventoryExpenseAcctDesc
            /// </summary>
            public const int InventoryExpenseAcctDesc = 118;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure
            /// </summary>
            public const int WeightUnitOfMeasure = 119;

            /// <summary>
            /// Property Indexer for FractionalQuantities
            /// </summary>
            public const int FractionalQuantities = 120;

            /// <summary>
            /// Property Indexer for HomeCurrency
            /// </summary>
            public const int HomeCurrency = 121;

            /// <summary>
            /// Property Indexer for DatabaseDriverID
            /// </summary>
            public const int DatabaseDriverID = 122;

            /// <summary>
            /// Property Indexer for CostDuring
            /// </summary>
            public const int CostDuring = 123;

            /// <summary>
            /// Property Indexer for NonInvPblsClrAcctDesc
            /// </summary>
            public const int NonInvPblsClrAcctDesc = 124;

            /// <summary>
            /// Property Indexer for ExpAddlCostPblsClrAcct
            /// </summary>
            public const int ExpAddlCostPblsClrAcct = 125;

            /// <summary>
            /// Property Indexer for Action
            /// </summary>
            public const int Action = 126;

            /// <summary>
            /// Property Indexer for CreateSubledgerAuditDuring
            /// </summary>
            public const int CreateSubledgerAuditDuring = 127;

            /// <summary>
            /// Property Indexer for Transactionpostdepcost
            /// </summary>
            public const int Transactionpostdepcost = 128;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 129;

        }
        #endregion

    }
}
