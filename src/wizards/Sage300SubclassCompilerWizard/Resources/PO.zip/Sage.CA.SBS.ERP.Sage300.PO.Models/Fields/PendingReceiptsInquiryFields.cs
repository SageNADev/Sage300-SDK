// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PendingReceipt Constants
    /// </summary>
    public partial class PendingReceiptsInquiry
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0722";

        #region Properties

        /// <summary>
        /// Contains list of PendingReceipt Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for PurchaseOrderLineSequence
            /// </summary>
            public const string PurchaseOrderLineSequence = "PORLSEQ";

            /// <summary>
            /// Property for ExpectedArrivalDate
            /// </summary>
            public const string ExpectedArrivalDate = "EXPARRIVAL";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for PurchaseOrderType
            /// </summary>
            public const string PurchaseOrderType = "PORTYPE";

            /// <summary>
            /// Property for VendorName
            /// </summary>
            public const string VendorName = "VDNAME";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VDCODE";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for PurchaseOrderDate
            /// </summary>
            public const string PurchaseOrderDate = "DATE";

            /// <summary>
            /// Property for QuantityOrdered
            /// </summary>
            public const string QuantityOrdered = "OQORDERED";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "UOM";

            /// <summary>
            /// Property for DateReceived
            /// </summary>
            public const string DateReceived = "DATERCVD";

            /// <summary>
            /// Property for IsComplete
            /// </summary>
            public const string IsComplete = "ISCOMPLETE";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "HASJOB";

            /// <summary>
            /// Property for ReceiptsExist
            /// </summary>
            public const string ReceiptsExist = "RCPEXIST";

            /// <summary>
            /// Property for DaysLate
            /// </summary>
            public const string DaysLate = "DAYSLATE";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of PendingReceipt Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 1;

            /// <summary>
            /// Property Indexer for PurchaseOrderLineSequence
            /// </summary>
            public const int PurchaseOrderLineSequence = 2;

            /// <summary>
            /// Property Indexer for ExpectedArrivalDate
            /// </summary>
            public const int ExpectedArrivalDate = 3;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 4;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 5;

            /// <summary>
            /// Property Indexer for PurchaseOrderType
            /// </summary>
            public const int PurchaseOrderType = 6;

            /// <summary>
            /// Property Indexer for VendorName
            /// </summary>
            public const int VendorName = 7;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 8;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 9;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 10;

            /// <summary>
            /// Property Indexer for PurchaseOrderDate
            /// </summary>
            public const int PurchaseOrderDate = 11;

            /// <summary>
            /// Property Indexer for QuantityOrdered
            /// </summary>
            public const int QuantityOrdered = 12;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 13;

            /// <summary>
            /// Property Indexer for DateReceived
            /// </summary>
            public const int DateReceived = 14;

            /// <summary>
            /// Property Indexer for IsComplete
            /// </summary>
            public const int IsComplete = 15;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 16;

            /// <summary>
            /// Property Indexer for ReceiptsExist
            /// </summary>
            public const int ReceiptsExist = 17;

            /// <summary>
            /// Property Indexer for DaysLate
            /// </summary>
            public const int DaysLate = 18;

        }

        #endregion

    }
}
