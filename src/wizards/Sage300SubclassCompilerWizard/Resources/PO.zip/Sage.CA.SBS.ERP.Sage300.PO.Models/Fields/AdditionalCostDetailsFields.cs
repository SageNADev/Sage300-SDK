// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.
// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of Additional Cost Details Constants
     /// </summary>
     public partial class AdditionalCostDetails
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0290";

          #region Field Properties
          /// <summary>
          /// Contains list of Additional Cost Detail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Additional Cost
               /// </summary>
               public const string AdditionalCost = "ADDCOST";

               /// <summary>
               /// Property for Tax Authority
               /// </summary>
               public const string TaxAuthority = "TAXAUTH";

               /// <summary>
               /// Property for Currency
               /// </summary>
               public const string Currency = "CURRENCY";

               /// <summary>
               /// Property for Tax Class
               /// </summary>
               public const string TaxClass = "TAXCLASS";

               /// <summary>
               /// Property for Tax Authority Description
               /// </summary>
               public const string TaxAuthorityDescription = "TAXAUTHD";

               /// <summary>
               /// Property for Tax Class Description
               /// </summary>
               public const string TaxClassDescription = "TAXCLASSD";

               /// <summary>
               /// Property for Line
               /// </summary>
               public const string Line = "LINE";

          }
          #endregion

          #region Index Properties
          /// <summary>
          /// Contains list of Additional Cost Detail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Additional Cost
               /// </summary>
               public const int AdditionalCost = 1;

               /// <summary>
               /// Property Indexer for Tax Authority
               /// </summary>
               public const int TaxAuthority = 2;

               /// <summary>
               /// Property Indexer for Currency
               /// </summary>
               public const int Currency = 3;

               /// <summary>
               /// Property Indexer for Tax Class
               /// </summary>
               public const int TaxClass = 4;

               /// <summary>
               /// Property Indexer for Tax Authority Description
               /// </summary>
               public const int TaxAuthorityDescription = 21;

               /// <summary>
               /// Property Indexer for Tax Class Description
               /// </summary>
               public const int TaxClassDescription = 22;

               /// <summary>
               /// Property Indexer for Line
               /// </summary>
               public const int Line = 23;

          }
          #endregion

     }
}
