// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Contains list of CreditDebitNotePostingLine Constants
	/// </summary>
	public partial class CreditDebitNotePostingLine
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "PO0316";

		#region Properties

		/// <summary>
		/// Contains list of CreditDebitNotePostingLine Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for HeaderSequence
			/// </summary>
			public const string HeaderSequence = "CRNISEQ";

			/// <summary>
			/// Property for CreditDebitNoteSequenceKey
			/// </summary>
			public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

			/// <summary>
			/// Property for CreditDebitNoteLineSequence
			/// </summary>
			public const string CreditDebitNoteLineSequence = "CRNLSEQ";

			/// <summary>
			/// Property for OperationToPost
			/// </summary>
			public const string OperationToPost = "OPERATION";

			/// <summary>
			/// Property for ReceiptSequenceKey
			/// </summary>
			public const string ReceiptSequenceKey = "RCPHSEQ";

			/// <summary>
			/// Property for ReceiptLineSequence
			/// </summary>
			public const string ReceiptLineSequence = "RCPLSEQ";

			/// <summary>
			/// Property for ReturnSequenceKey
			/// </summary>
			public const string ReturnSequenceKey = "RETHSEQ";

			/// <summary>
			/// Property for ReturnLineSequence
			/// </summary>
			public const string ReturnLineSequence = "RETLSEQ";

			/// <summary>
			/// Property for InvoiceSequenceKey
			/// </summary>
			public const string InvoiceSequenceKey = "INVHSEQ";

			/// <summary>
			/// Property for InvoiceLineSequence
			/// </summary>
			public const string InvoiceLineSequence = "INVLSEQ";

			/// <summary>
			/// Property for ItemDescription
			/// </summary>
			public const string ItemDescription = "ITEMDESC";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for STOCKUNIT
			/// </summary>
			public const string STOCKUNIT = "STOCKUNIT";

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property for RETUNIT
			/// </summary>
			public const string RETUNIT = "RETUNIT";

			/// <summary>
			/// Property for ReturningConversionFactor
			/// </summary>
			public const string ReturningConversionFactor = "RETCONV";

			/// <summary>
			/// Property for ReturningUnitDecimals
			/// </summary>
			public const string ReturningUnitDecimals = "RETDECML";

			/// <summary>
			/// Property for StockUnitDecimals
			/// </summary>
			public const string StockUnitDecimals = "STOCKDECML";

			/// <summary>
			/// Property for QuantityReturned
			/// </summary>
			public const string QuantityReturned = "RQRETURNED";

			/// <summary>
			/// Property for StockingQuantityReturned
			/// </summary>
			public const string StockingQuantityReturned = "SQRETURNED";

			/// <summary>
			/// Property for UnitCost
			/// </summary>
			public const string UnitCost = "UNITCOST";

			/// <summary>
			/// Property for ExtendedCost
			/// </summary>
			public const string ExtendedCost = "EXTENDED";

			/// <summary>
			/// Property for UnitWeight
			/// </summary>
			public const string UnitWeight = "UNITWEIGHT";

			/// <summary>
			/// Property for ExtendedWeight
			/// </summary>
			public const string ExtendedWeight = "EXTWEIGHT";

			/// <summary>
			/// Property for TaxBase1
			/// </summary>
			public const string TaxBase1 = "TAXBASE1";

			/// <summary>
			/// Property for TaxBase2
			/// </summary>
			public const string TaxBase2 = "TAXBASE2";

			/// <summary>
			/// Property for TaxBase3
			/// </summary>
			public const string TaxBase3 = "TAXBASE3";

			/// <summary>
			/// Property for TaxBase4
			/// </summary>
			public const string TaxBase4 = "TAXBASE4";

			/// <summary>
			/// Property for TaxBase5
			/// </summary>
			public const string TaxBase5 = "TAXBASE5";

			/// <summary>
			/// Property for TaxClass1
			/// </summary>
			public const string TaxClass1 = "TAXCLASS1";

			/// <summary>
			/// Property for TaxClass2
			/// </summary>
			public const string TaxClass2 = "TAXCLASS2";

			/// <summary>
			/// Property for TaxClass3
			/// </summary>
			public const string TaxClass3 = "TAXCLASS3";

			/// <summary>
			/// Property for TaxClass4
			/// </summary>
			public const string TaxClass4 = "TAXCLASS4";

			/// <summary>
			/// Property for TaxClass5
			/// </summary>
			public const string TaxClass5 = "TAXCLASS5";

			/// <summary>
			/// Property for TaxIncludable1
			/// </summary>
			public const string TaxIncludable1 = "TAXINCLUD1";

			/// <summary>
			/// Property for TaxIncludable2
			/// </summary>
			public const string TaxIncludable2 = "TAXINCLUD2";

			/// <summary>
			/// Property for TaxIncludable3
			/// </summary>
			public const string TaxIncludable3 = "TAXINCLUD3";

			/// <summary>
			/// Property for TaxIncludable4
			/// </summary>
			public const string TaxIncludable4 = "TAXINCLUD4";

			/// <summary>
			/// Property for TaxIncludable5
			/// </summary>
			public const string TaxIncludable5 = "TAXINCLUD5";

			/// <summary>
			/// Property for TaxAmount1
			/// </summary>
			public const string TaxAmount1 = "TAXAMOUNT1";

			/// <summary>
			/// Property for TaxAmount2
			/// </summary>
			public const string TaxAmount2 = "TAXAMOUNT2";

			/// <summary>
			/// Property for TaxAmount3
			/// </summary>
			public const string TaxAmount3 = "TAXAMOUNT3";

			/// <summary>
			/// Property for TaxAmount4
			/// </summary>
			public const string TaxAmount4 = "TAXAMOUNT4";

			/// <summary>
			/// Property for TaxAmount5
			/// </summary>
			public const string TaxAmount5 = "TAXAMOUNT5";

			/// <summary>
			/// Property for IncludedTaxAmount1
			/// </summary>
			public const string IncludedTaxAmount1 = "TXINCLUDE1";

			/// <summary>
			/// Property for IncludedTaxAmount2
			/// </summary>
			public const string IncludedTaxAmount2 = "TXINCLUDE2";

			/// <summary>
			/// Property for IncludedTaxAmount3
			/// </summary>
			public const string IncludedTaxAmount3 = "TXINCLUDE3";

			/// <summary>
			/// Property for IncludedTaxAmount4
			/// </summary>
			public const string IncludedTaxAmount4 = "TXINCLUDE4";

			/// <summary>
			/// Property for IncludedTaxAmount5
			/// </summary>
			public const string IncludedTaxAmount5 = "TXINCLUDE5";

			/// <summary>
			/// Property for TaxRecoverableAmount1
			/// </summary>
			public const string TaxRecoverableAmount1 = "TXRECVAMT1";

			/// <summary>
			/// Property for TaxRecoverableAmount2
			/// </summary>
			public const string TaxRecoverableAmount2 = "TXRECVAMT2";

			/// <summary>
			/// Property for TaxRecoverableAmount3
			/// </summary>
			public const string TaxRecoverableAmount3 = "TXRECVAMT3";

			/// <summary>
			/// Property for TaxRecoverableAmount4
			/// </summary>
			public const string TaxRecoverableAmount4 = "TXRECVAMT4";

			/// <summary>
			/// Property for TaxRecoverableAmount5
			/// </summary>
			public const string TaxRecoverableAmount5 = "TXRECVAMT5";

			/// <summary>
			/// Property for TaxExpenseAmount1
			/// </summary>
			public const string TaxExpenseAmount1 = "TXEXPSAMT1";

			/// <summary>
			/// Property for TaxExpenseAmount2
			/// </summary>
			public const string TaxExpenseAmount2 = "TXEXPSAMT2";

			/// <summary>
			/// Property for TaxExpenseAmount3
			/// </summary>
			public const string TaxExpenseAmount3 = "TXEXPSAMT3";

			/// <summary>
			/// Property for TaxExpenseAmount4
			/// </summary>
			public const string TaxExpenseAmount4 = "TXEXPSAMT4";

			/// <summary>
			/// Property for TaxExpenseAmount5
			/// </summary>
			public const string TaxExpenseAmount5 = "TXEXPSAMT5";

			/// <summary>
			/// Property for TaxAllocatedAmount1
			/// </summary>
			public const string TaxAllocatedAmount1 = "TXALLOAMT1";

			/// <summary>
			/// Property for TaxAllocatedAmount2
			/// </summary>
			public const string TaxAllocatedAmount2 = "TXALLOAMT2";

			/// <summary>
			/// Property for TaxAllocatedAmount3
			/// </summary>
			public const string TaxAllocatedAmount3 = "TXALLOAMT3";

			/// <summary>
			/// Property for TaxAllocatedAmount4
			/// </summary>
			public const string TaxAllocatedAmount4 = "TXALLOAMT4";

			/// <summary>
			/// Property for TaxAllocatedAmount5
			/// </summary>
			public const string TaxAllocatedAmount5 = "TXALLOAMT5";

			/// <summary>
			/// Property for NetOfTax
			/// </summary>
			public const string NetOfTax = "TXBASEALLO";

			/// <summary>
			/// Property for TaxIncluded
			/// </summary>
			public const string TaxIncluded = "TXINCLUDED";

			/// <summary>
			/// Property for TaxExcluded
			/// </summary>
			public const string TaxExcluded = "TXEXCLUDED";

			/// <summary>
			/// Property for TotalTax
			/// </summary>
			public const string TotalTax = "TAXAMOUNT";

			/// <summary>
			/// Property for TotalTaxRecoverable
			/// </summary>
			public const string TotalTaxRecoverable = "TXRECVAMT";

			/// <summary>
			/// Property for TotalTaxExpensed
			/// </summary>
			public const string TotalTaxExpensed = "TXEXPSAMT";

			/// <summary>
			/// Property for TotalTaxAllocated
			/// </summary>
			public const string TotalTaxAllocated = "TXALLOAMT";

			/// <summary>
			/// Property for FuncNetOfTax
			/// </summary>
			public const string FuncNetOfTax = "TFBASEALLO";

			/// <summary>
			/// Property for FuncTaxIncludedAmount1
			/// </summary>
			public const string FuncTaxIncludedAmount1 = "TFINCLUDE1";

			/// <summary>
			/// Property for FuncTaxIncludedAmount2
			/// </summary>
			public const string FuncTaxIncludedAmount2 = "TFINCLUDE2";

			/// <summary>
			/// Property for FuncTaxIncludedAmount3
			/// </summary>
			public const string FuncTaxIncludedAmount3 = "TFINCLUDE3";

			/// <summary>
			/// Property for FuncTaxIncludedAmount4
			/// </summary>
			public const string FuncTaxIncludedAmount4 = "TFINCLUDE4";

			/// <summary>
			/// Property for FuncTaxIncludedAmount5
			/// </summary>
			public const string FuncTaxIncludedAmount5 = "TFINCLUDE5";

			/// <summary>
			/// Property for FuncTaxAllocatedAmount1
			/// </summary>
			public const string FuncTaxAllocatedAmount1 = "TFALLOAMT1";

			/// <summary>
			/// Property for FuncTaxAllocatedAmount2
			/// </summary>
			public const string FuncTaxAllocatedAmount2 = "TFALLOAMT2";

			/// <summary>
			/// Property for FuncTaxAllocatedAmount3
			/// </summary>
			public const string FuncTaxAllocatedAmount3 = "TFALLOAMT3";

			/// <summary>
			/// Property for FuncTaxAllocatedAmount4
			/// </summary>
			public const string FuncTaxAllocatedAmount4 = "TFALLOAMT4";

			/// <summary>
			/// Property for FuncTaxAllocatedAmount5
			/// </summary>
			public const string FuncTaxAllocatedAmount5 = "TFALLOAMT5";

			/// <summary>
			/// Property for FuncTaxRecoverableAmount1
			/// </summary>
			public const string FuncTaxRecoverableAmount1 = "TFRECVAMT1";

			/// <summary>
			/// Property for FuncTaxRecoverableAmount2
			/// </summary>
			public const string FuncTaxRecoverableAmount2 = "TFRECVAMT2";

			/// <summary>
			/// Property for FuncTaxRecoverableAmount3
			/// </summary>
			public const string FuncTaxRecoverableAmount3 = "TFRECVAMT3";

			/// <summary>
			/// Property for FuncTaxRecoverableAmount4
			/// </summary>
			public const string FuncTaxRecoverableAmount4 = "TFRECVAMT4";

			/// <summary>
			/// Property for FuncTaxRecoverableAmount5
			/// </summary>
			public const string FuncTaxRecoverableAmount5 = "TFRECVAMT5";

			/// <summary>
			/// Property for FuncTaxExpenseAmount1
			/// </summary>
			public const string FuncTaxExpenseAmount1 = "TFEXPSAMT1";

			/// <summary>
			/// Property for FuncTaxExpenseAmount2
			/// </summary>
			public const string FuncTaxExpenseAmount2 = "TFEXPSAMT2";

			/// <summary>
			/// Property for FuncTaxExpenseAmount3
			/// </summary>
			public const string FuncTaxExpenseAmount3 = "TFEXPSAMT3";

			/// <summary>
			/// Property for FuncTaxExpenseAmount4
			/// </summary>
			public const string FuncTaxExpenseAmount4 = "TFEXPSAMT4";

			/// <summary>
			/// Property for FuncTaxExpenseAmount5
			/// </summary>
			public const string FuncTaxExpenseAmount5 = "TFEXPSAMT5";

			/// <summary>
			/// Property for ExpenseAccount
			/// </summary>
			public const string ExpenseAccount = "GLACEXPENS";

			/// <summary>
			/// Property for NonStockClearingAccount
			/// </summary>
			public const string NonStockClearingAccount = "GLNONSTKCR";

			/// <summary>
			/// Property for DiscountPercentage
			/// </summary>
			public const string DiscountPercentage = "DISCPCT";

			/// <summary>
			/// Property for DiscountAmount
			/// </summary>
			public const string DiscountAmount = "DISCOUNT";

			/// <summary>
			/// Property for FuncDiscountAmount
			/// </summary>
			public const string FuncDiscountAmount = "DISCOUNTF";

			/// <summary>
			/// Property for BillingRate
			/// </summary>
			public const string BillingRate = "BILLRATE";

			/// <summary>
			/// Property for RetainagePercentage
			/// </summary>
			public const string RetainagePercentage = "RTGPERCENT";

			/// <summary>
			/// Property for RetentionPeriod
			/// </summary>
			public const string RetentionPeriod = "RTGDAYS";

			/// <summary>
			/// Property for RetainageAmount
			/// </summary>
			public const string RetainageAmount = "RTGAMOUNT";

			/// <summary>
			/// Property for RetainageDueDate
			/// </summary>
			public const string RetainageDueDate = "RTGDATEDUE";

			/// <summary>
			/// Property for RetainageAmountOverridden
			/// </summary>
			public const string RetainageAmountOverridden = "RTGAMTOVER";

			/// <summary>
			/// Property for RetainageDueDateOverridden
			/// </summary>
			public const string RetainageDueDateOverridden = "RTGDDTOVER";

			/// <summary>
			/// Property for TaxReportingIncludedAmount1
			/// </summary>
			public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

			/// <summary>
			/// Property for TaxReportingIncludedAmount2
			/// </summary>
			public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

			/// <summary>
			/// Property for TaxReportingIncludedAmount3
			/// </summary>
			public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

			/// <summary>
			/// Property for TaxReportingIncludedAmount4
			/// </summary>
			public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

			/// <summary>
			/// Property for TaxReportingIncludedAmount5
			/// </summary>
			public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

			/// <summary>
			/// Property for TaxReportingRecoverableAmt1
			/// </summary>
			public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

			/// <summary>
			/// Property for TaxReportingRecoverableAmt2
			/// </summary>
			public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

			/// <summary>
			/// Property for TaxReportingRecoverableAmt3
			/// </summary>
			public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

			/// <summary>
			/// Property for TaxReportingRecoverableAmt4
			/// </summary>
			public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

			/// <summary>
			/// Property for TaxReportingRecoverableAmt5
			/// </summary>
			public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

			/// <summary>
			/// Property for TaxReportingExpenseAmount1
			/// </summary>
			public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

			/// <summary>
			/// Property for TaxReportingExpenseAmount2
			/// </summary>
			public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

			/// <summary>
			/// Property for TaxReportingExpenseAmount3
			/// </summary>
			public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

			/// <summary>
			/// Property for TaxReportingExpenseAmount4
			/// </summary>
			public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

			/// <summary>
			/// Property for TaxReportingExpenseAmount5
			/// </summary>
			public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

			/// <summary>
			/// Property for TaxReportingAllocatedAmount1
			/// </summary>
			public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

			/// <summary>
			/// Property for TaxReportingAllocatedAmount2
			/// </summary>
			public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

			/// <summary>
			/// Property for TaxReportingAllocatedAmount3
			/// </summary>
			public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

			/// <summary>
			/// Property for TaxReportingAllocatedAmount4
			/// </summary>
			public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

			/// <summary>
			/// Property for TaxReportingAllocatedAmount5
			/// </summary>
			public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

			/// <summary>
			/// Property for RetainageTaxBase1
			/// </summary>
			public const string RetainageTaxBase1 = "RAXBASE1";

			/// <summary>
			/// Property for RetainageTaxBase2
			/// </summary>
			public const string RetainageTaxBase2 = "RAXBASE2";

			/// <summary>
			/// Property for RetainageTaxBase3
			/// </summary>
			public const string RetainageTaxBase3 = "RAXBASE3";

			/// <summary>
			/// Property for RetainageTaxBase4
			/// </summary>
			public const string RetainageTaxBase4 = "RAXBASE4";

			/// <summary>
			/// Property for RetainageTaxBase5
			/// </summary>
			public const string RetainageTaxBase5 = "RAXBASE5";

			/// <summary>
			/// Property for RetainageTaxRecoverableAmt1
			/// </summary>
			public const string RetainageTaxRecoverableAmt1 = "RXRECVAMT1";

			/// <summary>
			/// Property for RetainageTaxRecoverableAmt2
			/// </summary>
			public const string RetainageTaxRecoverableAmt2 = "RXRECVAMT2";

			/// <summary>
			/// Property for RetainageTaxRecoverableAmt3
			/// </summary>
			public const string RetainageTaxRecoverableAmt3 = "RXRECVAMT3";

			/// <summary>
			/// Property for RetainageTaxRecoverableAmt4
			/// </summary>
			public const string RetainageTaxRecoverableAmt4 = "RXRECVAMT4";

			/// <summary>
			/// Property for RetainageTaxRecoverableAmt5
			/// </summary>
			public const string RetainageTaxRecoverableAmt5 = "RXRECVAMT5";

			/// <summary>
			/// Property for RetainageTaxExpenseAmount1
			/// </summary>
			public const string RetainageTaxExpenseAmount1 = "RXEXPSAMT1";

			/// <summary>
			/// Property for RetainageTaxExpenseAmount2
			/// </summary>
			public const string RetainageTaxExpenseAmount2 = "RXEXPSAMT2";

			/// <summary>
			/// Property for RetainageTaxExpenseAmount3
			/// </summary>
			public const string RetainageTaxExpenseAmount3 = "RXEXPSAMT3";

			/// <summary>
			/// Property for RetainageTaxExpenseAmount4
			/// </summary>
			public const string RetainageTaxExpenseAmount4 = "RXEXPSAMT4";

			/// <summary>
			/// Property for RetainageTaxExpenseAmount5
			/// </summary>
			public const string RetainageTaxExpenseAmount5 = "RXEXPSAMT5";

			/// <summary>
			/// Property for RetainageTaxAllocatedAmount1
			/// </summary>
			public const string RetainageTaxAllocatedAmount1 = "RXALLOAMT1";

			/// <summary>
			/// Property for RetainageTaxAllocatedAmount2
			/// </summary>
			public const string RetainageTaxAllocatedAmount2 = "RXALLOAMT2";

			/// <summary>
			/// Property for RetainageTaxAllocatedAmount3
			/// </summary>
			public const string RetainageTaxAllocatedAmount3 = "RXALLOAMT3";

			/// <summary>
			/// Property for RetainageTaxAllocatedAmount4
			/// </summary>
			public const string RetainageTaxAllocatedAmount4 = "RXALLOAMT4";

			/// <summary>
			/// Property for RetainageTaxAllocatedAmount5
			/// </summary>
			public const string RetainageTaxAllocatedAmount5 = "RXALLOAMT5";

			/// <summary>
			/// Property for WeightUnitOfMeasure
			/// </summary>
			public const string WeightUnitOfMeasure = "WEIGHTUNIT";

			/// <summary>
			/// Property for WeightConversion
			/// </summary>
			public const string WeightConversion = "WEIGHTCONV";

			/// <summary>
			/// Property for DefaultUnitWeight
			/// </summary>
			public const string DefaultUnitWeight = "DEFUWEIGHT";

			/// <summary>
			/// Property for DefaultExtendedWeight
			/// </summary>
			public const string DefaultExtendedWeight = "DEFEXTWGHT";

			/// <summary>
			/// Property for IsQuantityPosted
			/// </summary>
			public const string IsQuantityPosted = "QTYPOSTED";

			/// <summary>
			/// Property for Last
			/// </summary>
			public const string Last = "LAST";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of CreditDebitNotePostingLine Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for HeaderSequence
			/// </summary>
			public const int HeaderSequence = 1;

			/// <summary>
			/// Property Indexer for CreditDebitNoteSequenceKey
			/// </summary>
			public const int CreditDebitNoteSequenceKey = 2;

			/// <summary>
			/// Property Indexer for CreditDebitNoteLineSequence
			/// </summary>
			public const int CreditDebitNoteLineSequence = 3;

			/// <summary>
			/// Property Indexer for OperationToPost
			/// </summary>
			public const int OperationToPost = 4;

			/// <summary>
			/// Property Indexer for ReceiptSequenceKey
			/// </summary>
			public const int ReceiptSequenceKey = 5;

			/// <summary>
			/// Property Indexer for ReceiptLineSequence
			/// </summary>
			public const int ReceiptLineSequence = 6;

			/// <summary>
			/// Property Indexer for ReturnSequenceKey
			/// </summary>
			public const int ReturnSequenceKey = 7;

			/// <summary>
			/// Property Indexer for ReturnLineSequence
			/// </summary>
			public const int ReturnLineSequence = 8;

			/// <summary>
			/// Property Indexer for InvoiceSequenceKey
			/// </summary>
			public const int InvoiceSequenceKey = 9;

			/// <summary>
			/// Property Indexer for InvoiceLineSequence
			/// </summary>
			public const int InvoiceLineSequence = 10;

			/// <summary>
			/// Property Indexer for ItemDescription
			/// </summary>
			public const int ItemDescription = 11;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for STOCKUNIT
			/// </summary>
			public const int STOCKUNIT = 12;

			// TODO: The naming convention of this property has to be manually evaluated
			/// <summary>
			/// Property Indexer for RETUNIT
			/// </summary>
			public const int RETUNIT = 13;

			/// <summary>
			/// Property Indexer for ReturningConversionFactor
			/// </summary>
			public const int ReturningConversionFactor = 14;

			/// <summary>
			/// Property Indexer for ReturningUnitDecimals
			/// </summary>
			public const int ReturningUnitDecimals = 15;

			/// <summary>
			/// Property Indexer for StockUnitDecimals
			/// </summary>
			public const int StockUnitDecimals = 16;

			/// <summary>
			/// Property Indexer for QuantityReturned
			/// </summary>
			public const int QuantityReturned = 17;

			/// <summary>
			/// Property Indexer for StockingQuantityReturned
			/// </summary>
			public const int StockingQuantityReturned = 18;

			/// <summary>
			/// Property Indexer for UnitCost
			/// </summary>
			public const int UnitCost = 19;

			/// <summary>
			/// Property Indexer for ExtendedCost
			/// </summary>
			public const int ExtendedCost = 20;

			/// <summary>
			/// Property Indexer for UnitWeight
			/// </summary>
			public const int UnitWeight = 21;

			/// <summary>
			/// Property Indexer for ExtendedWeight
			/// </summary>
			public const int ExtendedWeight = 22;

			/// <summary>
			/// Property Indexer for TaxBase1
			/// </summary>
			public const int TaxBase1 = 23;

			/// <summary>
			/// Property Indexer for TaxBase2
			/// </summary>
			public const int TaxBase2 = 24;

			/// <summary>
			/// Property Indexer for TaxBase3
			/// </summary>
			public const int TaxBase3 = 25;

			/// <summary>
			/// Property Indexer for TaxBase4
			/// </summary>
			public const int TaxBase4 = 26;

			/// <summary>
			/// Property Indexer for TaxBase5
			/// </summary>
			public const int TaxBase5 = 27;

			/// <summary>
			/// Property Indexer for TaxClass1
			/// </summary>
			public const int TaxClass1 = 28;

			/// <summary>
			/// Property Indexer for TaxClass2
			/// </summary>
			public const int TaxClass2 = 29;

			/// <summary>
			/// Property Indexer for TaxClass3
			/// </summary>
			public const int TaxClass3 = 30;

			/// <summary>
			/// Property Indexer for TaxClass4
			/// </summary>
			public const int TaxClass4 = 31;

			/// <summary>
			/// Property Indexer for TaxClass5
			/// </summary>
			public const int TaxClass5 = 32;

			/// <summary>
			/// Property Indexer for TaxIncludable1
			/// </summary>
			public const int TaxIncludable1 = 33;

			/// <summary>
			/// Property Indexer for TaxIncludable2
			/// </summary>
			public const int TaxIncludable2 = 34;

			/// <summary>
			/// Property Indexer for TaxIncludable3
			/// </summary>
			public const int TaxIncludable3 = 35;

			/// <summary>
			/// Property Indexer for TaxIncludable4
			/// </summary>
			public const int TaxIncludable4 = 36;

			/// <summary>
			/// Property Indexer for TaxIncludable5
			/// </summary>
			public const int TaxIncludable5 = 37;

			/// <summary>
			/// Property Indexer for TaxAmount1
			/// </summary>
			public const int TaxAmount1 = 38;

			/// <summary>
			/// Property Indexer for TaxAmount2
			/// </summary>
			public const int TaxAmount2 = 39;

			/// <summary>
			/// Property Indexer for TaxAmount3
			/// </summary>
			public const int TaxAmount3 = 40;

			/// <summary>
			/// Property Indexer for TaxAmount4
			/// </summary>
			public const int TaxAmount4 = 41;

			/// <summary>
			/// Property Indexer for TaxAmount5
			/// </summary>
			public const int TaxAmount5 = 42;

			/// <summary>
			/// Property Indexer for IncludedTaxAmount1
			/// </summary>
			public const int IncludedTaxAmount1 = 43;

			/// <summary>
			/// Property Indexer for IncludedTaxAmount2
			/// </summary>
			public const int IncludedTaxAmount2 = 44;

			/// <summary>
			/// Property Indexer for IncludedTaxAmount3
			/// </summary>
			public const int IncludedTaxAmount3 = 45;

			/// <summary>
			/// Property Indexer for IncludedTaxAmount4
			/// </summary>
			public const int IncludedTaxAmount4 = 46;

			/// <summary>
			/// Property Indexer for IncludedTaxAmount5
			/// </summary>
			public const int IncludedTaxAmount5 = 47;

			/// <summary>
			/// Property Indexer for TaxRecoverableAmount1
			/// </summary>
			public const int TaxRecoverableAmount1 = 48;

			/// <summary>
			/// Property Indexer for TaxRecoverableAmount2
			/// </summary>
			public const int TaxRecoverableAmount2 = 49;

			/// <summary>
			/// Property Indexer for TaxRecoverableAmount3
			/// </summary>
			public const int TaxRecoverableAmount3 = 50;

			/// <summary>
			/// Property Indexer for TaxRecoverableAmount4
			/// </summary>
			public const int TaxRecoverableAmount4 = 51;

			/// <summary>
			/// Property Indexer for TaxRecoverableAmount5
			/// </summary>
			public const int TaxRecoverableAmount5 = 52;

			/// <summary>
			/// Property Indexer for TaxExpenseAmount1
			/// </summary>
			public const int TaxExpenseAmount1 = 53;

			/// <summary>
			/// Property Indexer for TaxExpenseAmount2
			/// </summary>
			public const int TaxExpenseAmount2 = 54;

			/// <summary>
			/// Property Indexer for TaxExpenseAmount3
			/// </summary>
			public const int TaxExpenseAmount3 = 55;

			/// <summary>
			/// Property Indexer for TaxExpenseAmount4
			/// </summary>
			public const int TaxExpenseAmount4 = 56;

			/// <summary>
			/// Property Indexer for TaxExpenseAmount5
			/// </summary>
			public const int TaxExpenseAmount5 = 57;

			/// <summary>
			/// Property Indexer for TaxAllocatedAmount1
			/// </summary>
			public const int TaxAllocatedAmount1 = 58;

			/// <summary>
			/// Property Indexer for TaxAllocatedAmount2
			/// </summary>
			public const int TaxAllocatedAmount2 = 59;

			/// <summary>
			/// Property Indexer for TaxAllocatedAmount3
			/// </summary>
			public const int TaxAllocatedAmount3 = 60;

			/// <summary>
			/// Property Indexer for TaxAllocatedAmount4
			/// </summary>
			public const int TaxAllocatedAmount4 = 61;

			/// <summary>
			/// Property Indexer for TaxAllocatedAmount5
			/// </summary>
			public const int TaxAllocatedAmount5 = 62;

			/// <summary>
			/// Property Indexer for NetOfTax
			/// </summary>
			public const int NetOfTax = 63;

			/// <summary>
			/// Property Indexer for TaxIncluded
			/// </summary>
			public const int TaxIncluded = 64;

			/// <summary>
			/// Property Indexer for TaxExcluded
			/// </summary>
			public const int TaxExcluded = 65;

			/// <summary>
			/// Property Indexer for TotalTax
			/// </summary>
			public const int TotalTax = 66;

			/// <summary>
			/// Property Indexer for TotalTaxRecoverable
			/// </summary>
			public const int TotalTaxRecoverable = 67;

			/// <summary>
			/// Property Indexer for TotalTaxExpensed
			/// </summary>
			public const int TotalTaxExpensed = 68;

			/// <summary>
			/// Property Indexer for TotalTaxAllocated
			/// </summary>
			public const int TotalTaxAllocated = 69;

			/// <summary>
			/// Property Indexer for FuncNetOfTax
			/// </summary>
			public const int FuncNetOfTax = 70;

			/// <summary>
			/// Property Indexer for FuncTaxIncludedAmount1
			/// </summary>
			public const int FuncTaxIncludedAmount1 = 71;

			/// <summary>
			/// Property Indexer for FuncTaxIncludedAmount2
			/// </summary>
			public const int FuncTaxIncludedAmount2 = 72;

			/// <summary>
			/// Property Indexer for FuncTaxIncludedAmount3
			/// </summary>
			public const int FuncTaxIncludedAmount3 = 73;

			/// <summary>
			/// Property Indexer for FuncTaxIncludedAmount4
			/// </summary>
			public const int FuncTaxIncludedAmount4 = 74;

			/// <summary>
			/// Property Indexer for FuncTaxIncludedAmount5
			/// </summary>
			public const int FuncTaxIncludedAmount5 = 75;

			/// <summary>
			/// Property Indexer for FuncTaxAllocatedAmount1
			/// </summary>
			public const int FuncTaxAllocatedAmount1 = 76;

			/// <summary>
			/// Property Indexer for FuncTaxAllocatedAmount2
			/// </summary>
			public const int FuncTaxAllocatedAmount2 = 77;

			/// <summary>
			/// Property Indexer for FuncTaxAllocatedAmount3
			/// </summary>
			public const int FuncTaxAllocatedAmount3 = 78;

			/// <summary>
			/// Property Indexer for FuncTaxAllocatedAmount4
			/// </summary>
			public const int FuncTaxAllocatedAmount4 = 79;

			/// <summary>
			/// Property Indexer for FuncTaxAllocatedAmount5
			/// </summary>
			public const int FuncTaxAllocatedAmount5 = 80;

			/// <summary>
			/// Property Indexer for FuncTaxRecoverableAmount1
			/// </summary>
			public const int FuncTaxRecoverableAmount1 = 81;

			/// <summary>
			/// Property Indexer for FuncTaxRecoverableAmount2
			/// </summary>
			public const int FuncTaxRecoverableAmount2 = 82;

			/// <summary>
			/// Property Indexer for FuncTaxRecoverableAmount3
			/// </summary>
			public const int FuncTaxRecoverableAmount3 = 83;

			/// <summary>
			/// Property Indexer for FuncTaxRecoverableAmount4
			/// </summary>
			public const int FuncTaxRecoverableAmount4 = 84;

			/// <summary>
			/// Property Indexer for FuncTaxRecoverableAmount5
			/// </summary>
			public const int FuncTaxRecoverableAmount5 = 85;

			/// <summary>
			/// Property Indexer for FuncTaxExpenseAmount1
			/// </summary>
			public const int FuncTaxExpenseAmount1 = 86;

			/// <summary>
			/// Property Indexer for FuncTaxExpenseAmount2
			/// </summary>
			public const int FuncTaxExpenseAmount2 = 87;

			/// <summary>
			/// Property Indexer for FuncTaxExpenseAmount3
			/// </summary>
			public const int FuncTaxExpenseAmount3 = 88;

			/// <summary>
			/// Property Indexer for FuncTaxExpenseAmount4
			/// </summary>
			public const int FuncTaxExpenseAmount4 = 89;

			/// <summary>
			/// Property Indexer for FuncTaxExpenseAmount5
			/// </summary>
			public const int FuncTaxExpenseAmount5 = 90;

			/// <summary>
			/// Property Indexer for ExpenseAccount
			/// </summary>
			public const int ExpenseAccount = 91;

			/// <summary>
			/// Property Indexer for NonStockClearingAccount
			/// </summary>
			public const int NonStockClearingAccount = 92;

			/// <summary>
			/// Property Indexer for DiscountPercentage
			/// </summary>
			public const int DiscountPercentage = 93;

			/// <summary>
			/// Property Indexer for DiscountAmount
			/// </summary>
			public const int DiscountAmount = 94;

			/// <summary>
			/// Property Indexer for FuncDiscountAmount
			/// </summary>
			public const int FuncDiscountAmount = 95;

			/// <summary>
			/// Property Indexer for BillingRate
			/// </summary>
			public const int BillingRate = 96;

			/// <summary>
			/// Property Indexer for RetainagePercentage
			/// </summary>
			public const int RetainagePercentage = 97;

			/// <summary>
			/// Property Indexer for RetentionPeriod
			/// </summary>
			public const int RetentionPeriod = 98;

			/// <summary>
			/// Property Indexer for RetainageAmount
			/// </summary>
			public const int RetainageAmount = 99;

			/// <summary>
			/// Property Indexer for RetainageDueDate
			/// </summary>
			public const int RetainageDueDate = 100;

			/// <summary>
			/// Property Indexer for RetainageAmountOverridden
			/// </summary>
			public const int RetainageAmountOverridden = 101;

			/// <summary>
			/// Property Indexer for RetainageDueDateOverridden
			/// </summary>
			public const int RetainageDueDateOverridden = 102;

			/// <summary>
			/// Property Indexer for TaxReportingIncludedAmount1
			/// </summary>
			public const int TaxReportingIncludedAmount1 = 103;

			/// <summary>
			/// Property Indexer for TaxReportingIncludedAmount2
			/// </summary>
			public const int TaxReportingIncludedAmount2 = 104;

			/// <summary>
			/// Property Indexer for TaxReportingIncludedAmount3
			/// </summary>
			public const int TaxReportingIncludedAmount3 = 105;

			/// <summary>
			/// Property Indexer for TaxReportingIncludedAmount4
			/// </summary>
			public const int TaxReportingIncludedAmount4 = 106;

			/// <summary>
			/// Property Indexer for TaxReportingIncludedAmount5
			/// </summary>
			public const int TaxReportingIncludedAmount5 = 107;

			/// <summary>
			/// Property Indexer for TaxReportingRecoverableAmt1
			/// </summary>
			public const int TaxReportingRecoverableAmt1 = 108;

			/// <summary>
			/// Property Indexer for TaxReportingRecoverableAmt2
			/// </summary>
			public const int TaxReportingRecoverableAmt2 = 109;

			/// <summary>
			/// Property Indexer for TaxReportingRecoverableAmt3
			/// </summary>
			public const int TaxReportingRecoverableAmt3 = 110;

			/// <summary>
			/// Property Indexer for TaxReportingRecoverableAmt4
			/// </summary>
			public const int TaxReportingRecoverableAmt4 = 111;

			/// <summary>
			/// Property Indexer for TaxReportingRecoverableAmt5
			/// </summary>
			public const int TaxReportingRecoverableAmt5 = 112;

			/// <summary>
			/// Property Indexer for TaxReportingExpenseAmount1
			/// </summary>
			public const int TaxReportingExpenseAmount1 = 113;

			/// <summary>
			/// Property Indexer for TaxReportingExpenseAmount2
			/// </summary>
			public const int TaxReportingExpenseAmount2 = 114;

			/// <summary>
			/// Property Indexer for TaxReportingExpenseAmount3
			/// </summary>
			public const int TaxReportingExpenseAmount3 = 115;

			/// <summary>
			/// Property Indexer for TaxReportingExpenseAmount4
			/// </summary>
			public const int TaxReportingExpenseAmount4 = 116;

			/// <summary>
			/// Property Indexer for TaxReportingExpenseAmount5
			/// </summary>
			public const int TaxReportingExpenseAmount5 = 117;

			/// <summary>
			/// Property Indexer for TaxReportingAllocatedAmount1
			/// </summary>
			public const int TaxReportingAllocatedAmount1 = 118;

			/// <summary>
			/// Property Indexer for TaxReportingAllocatedAmount2
			/// </summary>
			public const int TaxReportingAllocatedAmount2 = 119;

			/// <summary>
			/// Property Indexer for TaxReportingAllocatedAmount3
			/// </summary>
			public const int TaxReportingAllocatedAmount3 = 120;

			/// <summary>
			/// Property Indexer for TaxReportingAllocatedAmount4
			/// </summary>
			public const int TaxReportingAllocatedAmount4 = 121;

			/// <summary>
			/// Property Indexer for TaxReportingAllocatedAmount5
			/// </summary>
			public const int TaxReportingAllocatedAmount5 = 122;

			/// <summary>
			/// Property Indexer for RetainageTaxBase1
			/// </summary>
			public const int RetainageTaxBase1 = 123;

			/// <summary>
			/// Property Indexer for RetainageTaxBase2
			/// </summary>
			public const int RetainageTaxBase2 = 124;

			/// <summary>
			/// Property Indexer for RetainageTaxBase3
			/// </summary>
			public const int RetainageTaxBase3 = 125;

			/// <summary>
			/// Property Indexer for RetainageTaxBase4
			/// </summary>
			public const int RetainageTaxBase4 = 126;

			/// <summary>
			/// Property Indexer for RetainageTaxBase5
			/// </summary>
			public const int RetainageTaxBase5 = 127;

			/// <summary>
			/// Property Indexer for RetainageTaxRecoverableAmt1
			/// </summary>
			public const int RetainageTaxRecoverableAmt1 = 128;

			/// <summary>
			/// Property Indexer for RetainageTaxRecoverableAmt2
			/// </summary>
			public const int RetainageTaxRecoverableAmt2 = 129;

			/// <summary>
			/// Property Indexer for RetainageTaxRecoverableAmt3
			/// </summary>
			public const int RetainageTaxRecoverableAmt3 = 130;

			/// <summary>
			/// Property Indexer for RetainageTaxRecoverableAmt4
			/// </summary>
			public const int RetainageTaxRecoverableAmt4 = 131;

			/// <summary>
			/// Property Indexer for RetainageTaxRecoverableAmt5
			/// </summary>
			public const int RetainageTaxRecoverableAmt5 = 132;

			/// <summary>
			/// Property Indexer for RetainageTaxExpenseAmount1
			/// </summary>
			public const int RetainageTaxExpenseAmount1 = 133;

			/// <summary>
			/// Property Indexer for RetainageTaxExpenseAmount2
			/// </summary>
			public const int RetainageTaxExpenseAmount2 = 134;

			/// <summary>
			/// Property Indexer for RetainageTaxExpenseAmount3
			/// </summary>
			public const int RetainageTaxExpenseAmount3 = 135;

			/// <summary>
			/// Property Indexer for RetainageTaxExpenseAmount4
			/// </summary>
			public const int RetainageTaxExpenseAmount4 = 136;

			/// <summary>
			/// Property Indexer for RetainageTaxExpenseAmount5
			/// </summary>
			public const int RetainageTaxExpenseAmount5 = 137;

			/// <summary>
			/// Property Indexer for RetainageTaxAllocatedAmount1
			/// </summary>
			public const int RetainageTaxAllocatedAmount1 = 138;

			/// <summary>
			/// Property Indexer for RetainageTaxAllocatedAmount2
			/// </summary>
			public const int RetainageTaxAllocatedAmount2 = 139;

			/// <summary>
			/// Property Indexer for RetainageTaxAllocatedAmount3
			/// </summary>
			public const int RetainageTaxAllocatedAmount3 = 140;

			/// <summary>
			/// Property Indexer for RetainageTaxAllocatedAmount4
			/// </summary>
			public const int RetainageTaxAllocatedAmount4 = 141;

			/// <summary>
			/// Property Indexer for RetainageTaxAllocatedAmount5
			/// </summary>
			public const int RetainageTaxAllocatedAmount5 = 142;

			/// <summary>
			/// Property Indexer for WeightUnitOfMeasure
			/// </summary>
			public const int WeightUnitOfMeasure = 143;

			/// <summary>
			/// Property Indexer for WeightConversion
			/// </summary>
			public const int WeightConversion = 144;

			/// <summary>
			/// Property Indexer for DefaultUnitWeight
			/// </summary>
			public const int DefaultUnitWeight = 145;

			/// <summary>
			/// Property Indexer for DefaultExtendedWeight
			/// </summary>
			public const int DefaultExtendedWeight = 146;

			/// <summary>
			/// Property Indexer for IsQuantityPosted
			/// </summary>
			public const int IsQuantityPosted = 147;

			/// <summary>
			/// Property Indexer for Last
			/// </summary>
			public const int Last = 150;

		}

		#endregion

	}
}
