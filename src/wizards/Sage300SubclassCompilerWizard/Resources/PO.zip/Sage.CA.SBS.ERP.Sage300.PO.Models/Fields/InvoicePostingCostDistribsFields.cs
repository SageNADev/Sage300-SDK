// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoicePostingCostDistribs. Constants
    /// </summary>
    public partial class InvoicePostingCostDistribs
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0417";

        #region Properties
        /// <summary>
        /// Contains list of InvoicePostingCostDistribs. Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for INVISEQ
            /// </summary>
            public const string InvIseq = "INVISEQ";

            /// <summary>
            /// Property for INVHSEQ
            /// </summary>
            public const string InvHseq = "INVHSEQ";

            /// <summary>
            /// Property for InvoiceCostSequence
            /// </summary>
            public const string InvoiceCostSequence = "INVSSEQ";

            /// <summary>
            /// Property for LineSequence
            /// </summary>
            public const string LineSequence = "LSEQ";

            /// <summary>
            /// Property for OperationToPost
            /// </summary>
            public const string OperationToPost = "OPERATION";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of InvoicePostingCostDistribs. Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for INVISEQ
            /// </summary>
            public const int InvIseq = 1;

            /// <summary>
            /// Property Indexer for INVHSEQ
            /// </summary>
            public const int InvHseq = 2;

            /// <summary>
            /// Property Indexer for InvoiceCostSequence
            /// </summary>
            public const int InvoiceCostSequence = 3;

            /// <summary>
            /// Property Indexer for LineSequence
            /// </summary>
            public const int LineSequence = 4;

            /// <summary>
            /// Property Indexer for OperationToPost
            /// </summary>
            public const int OperationToPost = 5;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 6;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 7;
        }

        #endregion
    }
}
