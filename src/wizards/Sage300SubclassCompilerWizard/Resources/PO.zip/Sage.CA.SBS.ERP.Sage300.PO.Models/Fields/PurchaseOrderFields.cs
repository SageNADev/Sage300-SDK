// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseOrder Constants
    /// </summary>
    public partial class PurchaseOrder
    {

        #region Public Constant

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0620";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"LINES", "Lines"},
                    {"LABELCOUNT", "NumberOfLabels"},
                    {"DATE", "PurchaseOrderDate"},
					{"PONUMBER", "PurchaseOrderNumber"},
					{"TEMPLATE", "TemplateCode"},
					{"FOBPOINT", "FreeOnBoardPoint"},
					{"VDCODE", "Vendor"},
					{"VDNAME", "Name"},
                    {"VDADDRESS1", "Address1"},
                    {"VDADDRESS2", "Address2"},
                    {"VDADDRESS3", "Address3"},
                    {"VDADDRESS4", "Address4"},
                    {"VDCITY", "City"},
                    {"VDSTATE", "StateProvince"},
                    {"VDZIP", "ZipPostalCode"},
                    {"VDCOUNTRY", "Country"},
                    {"VDPHONE", "PhoneNumber"},
                    {"VDFAX", "FaxNumber"},
                    {"VDCONTACT", "Contact"},
                    {"TERMSCODE", "TermsCode"},
					{"HASRQNDATA", "IsRequisitions"},
					{"PORTYPE", "PurchaseOrderType"},
					{"ONHOLD", "OnHold"},
                    {"HASJOB", "JobRelated"},
				    {"EXPARRIVAL", "ExpectedArrivalDate"},
					{"VCORIGINAL", "AmountOriginallyAuthorized"},
					{"VCAVAILABL", "AmountRemaining"},
					{"DESCRIPTIO", "Description"},
					{"REFERENCE", "Reference"},
					{"COMMENT", "Comment"},
					{"VIACODE", "ShipVia"},
					{"VIANAME", "ShipViaName"},
					{"LASTRECEIP", "LastReceiptNumber"},
                    {"CURRENCY", "Currency"},
					{"RATE", "ExchangeRate"},
					{"RATETYPE", "RateType"},
					{"RATEDATE", "RateDate"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"EXTENDED", "ExtendedCost"},
					{"DOCTOTAL", "Total"},
					{"TAXGROUP", "TaxGroup"},
                    {"TXINCLUDED", "TaxIncluded"},
					{"TAXAMOUNT", "TotalTax"},
					{"BTCODE", "BillToLocation"},
                    {"BTDESC", "BillToLocationDescription"},
                    {"BTADDRESS1", "BillToAddress1"},
                    {"BTADDRESS2", "BillToAddress2"},
                    {"BTADDRESS3", "BillToAddress3"},
                    {"BTADDRESS4", "BillToAddress4"},
                    {"BTCITY", "BillToCity"},
                    {"BTSTATE", "BillToStateProvince"},
                    {"BTZIP", "BillToZipPostalCode"},
                    {"BTCOUNTRY", "BillToCountry"},
                    {"BTPHONE", "BillToPhoneNumber"},
                    {"BTFAX", "BillToFaxNumber"},
                    {"BTCONTACT", "BillToContact"},
					{"STCODE", "ShipToLocation"},
                    {"STDESC", "ShipToLocationDescription"},
                    {"STADDRESS1", "ShipToAddress1"},
                    {"STADDRESS2", "ShipToAddress2"},
                    {"STADDRESS3", "ShipToAddress3"},
                    {"STADDRESS4", "ShipToAddress4"},
                    {"STCITY", "ShipToCity"},
                    {"STSTATE", "ShipToStateProvince"},
                    {"STZIP", "ShipToZipPostalCode"},
                    {"STCOUNTRY", "ShipToCountry"},
                    {"STPHONE", "ShipToPhoneNumber"},
                    {"STFAX", "ShipToFaxNumber"},
                    {"STCONTACT", "ShipToContact"},
                    {"CURRENCYD", "CurrencyDescription"},
					{"RATETYPED", "RateTypeDescription"},
					{"TAXGROUPD", "TaxGroupDescription"},
					{"TERMSCODED", "TermsCodeDescription"},
                    {"SUBTOTAL", "Subtotal"},
                    {"VDEMAIL", "Email"},
                    {"VDPHONEC", "ContactPhone"},
                    {"VDFAXC", "ContactFax"},
                    {"VDEMAILC", "ContactEmail"},
                    {"BTEMAIL", "BillToEmail"},
                    {"BTPHONEC", "BillToContactPhone"},
                    {"BTFAXC", "BillToContactFax"},
                    {"BTEMAILC", "BillToContactEmail"},
                    {"STEMAIL", "ShipToEmail"},
                    {"STPHONEC", "ShipToContactPhone"},
                    {"STFAXC", "ShipToContactFax"},
                    {"STEMAILC", "ShipToContactEmail"},
					{"DISCPCT", "DiscountPercentage"},
					{"DISCOUNT", "DiscountAmount"},
					{"NETXTENDED", "NetExtendedCost"},
					{"TRCURRENCY", "TaxReportingCurrency"},
					{"RATERC", "TaxReportingExchangeRate"},
					{"RATETYPERC", "TaxReportingRateType"},
					{"RATEDATERC", "TaxReportingRateDate"},
					{"TRCURRDESC", "TaxReportingCurrencyDesc"},
					{"RATETYPRCD", "TaxReportingRateTypeDesc"},
					{"TARAMOUNT", "TaxReportingTotalAmount"},
					{"TRINCLUDED", "TaxReportingIncludedAmount"},
					{"TREXCLUDED", "TaxReportingExcludedAmount"},
					{"VDACCTSET", "VendorAccountSet"},
					{"VDACCTDESC", "VendorAccountSetDescription"},
					{"ENTEREDBY", "EnteredBy"},
				};
            }
        }

        #endregion

        #region Field Properties

        /// <summary>
        /// Contains list of PurchaseOrder Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for NextLineSequence
            /// </summary>
            public const string NextLineSequence = "NEXTLSEQ";

            /// <summary>
            /// Property for Lines
            /// </summary>
            public const string Lines = "LINES";

            /// <summary>
            /// Property for LinesComplete
            /// </summary>
            public const string LinesComplete = "LINESCMPL";

            /// <summary>
            /// Property for LinesTaxCalculationSees
            /// </summary>
            public const string LinesTaxCalculationSees = "TAXLINES";

            /// <summary>
            /// Property for Requisitions
            /// </summary>
            public const string Requisitions = "RQNS";

            /// <summary>
            /// Property for RequisitionsCompleted
            /// </summary>
            public const string RequisitionsCompleted = "RQNSCMPL";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "ISPRINTED";

            /// <summary>
            /// Property for AutoTaxCalculationOnSave
            /// </summary>
            public const string AutoTaxCalculationOnSave = "TAXAUTOCAL";

            /// <summary>
            /// Property for LabelsPrinted
            /// </summary>
            public const string LabelsPrinted = "LABELPRINT";

            /// <summary>
            /// Property for NumberOfLabels
            /// </summary>
            public const string NumberOfLabels = "LABELCOUNT";

            /// <summary>
            /// Property for Completed
            /// </summary>
            public const string Completed = "ISCOMPLETE";

            /// <summary>
            /// Property for DateCompleted
            /// </summary>
            public const string DateCompleted = "DTCOMPLETE";

            /// <summary>
            /// Property for LastPostingDate
            /// </summary>
            public const string LastPostingDate = "POSTDATE";

            /// <summary>
            /// Property for PurchaseOrderDate
            /// </summary>
            public const string PurchaseOrderDate = "DATE";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for TemplateCode
            /// </summary>
            public const string TemplateCode = "TEMPLATE";

            /// <summary>
            /// Property for FreeOnBoardPoint
            /// </summary>
            public const string FreeOnBoardPoint = "FOBPOINT";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VDCODE";

            /// <summary>
            /// Property for VendorExists
            /// </summary>
            public const string VendorExists = "VDEXISTS";

            /// <summary>
            /// Property for Name
            /// </summary>
            public const string Name = "VDNAME";

            /// <summary>
            /// Property for Address1
            /// </summary>
            public const string Address1 = "VDADDRESS1";

            /// <summary>
            /// Property for Address2
            /// </summary>
            public const string Address2 = "VDADDRESS2";

            /// <summary>
            /// Property for Address3
            /// </summary>
            public const string Address3 = "VDADDRESS3";

            /// <summary>
            /// Property for Address4
            /// </summary>
            public const string Address4 = "VDADDRESS4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "VDCITY";

            /// <summary>
            /// Property for StateProvince
            /// </summary>
            public const string StateProvince = "VDSTATE";

            /// <summary>
            /// Property for ZipPostalCode
            /// </summary>
            public const string ZipPostalCode = "VDZIP";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "VDCOUNTRY";

            /// <summary>
            /// Property for PhoneNumber
            /// </summary>
            public const string PhoneNumber = "VDPHONE";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "VDFAX";

            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "VDCONTACT";

            /// <summary>
            /// Property for TermsCode
            /// </summary>
            public const string TermsCode = "TERMSCODE";

            /// <summary>
            /// Property for bool Requisitions
            /// </summary>
            public const string IsRequisitions = "HASRQNDATA";

            /// <summary>
            /// Property for PurchaseOrderType
            /// </summary>
            public const string PurchaseOrderType = "PORTYPE";

            /// <summary>
            /// Property for OnHold
            /// </summary>
            public const string OnHold = "ONHOLD";

            /// <summary>
            /// Property for OrderDate
            /// </summary>
            public const string OrderDate = "ORDEREDON";

            /// <summary>
            /// Property for ExpectedArrivalDate
            /// </summary>
            public const string ExpectedArrivalDate = "EXPARRIVAL";

            /// <summary>
            /// Property for AmountOriginallyAuthorized
            /// </summary>
            public const string AmountOriginallyAuthorized = "VCORIGINAL";

            /// <summary>
            /// Property for AmountRemaining
            /// </summary>
            public const string AmountRemaining = "VCAVAILABL";

            /// <summary>
            /// Property for Description
            /// </summary>
            public const string Description = "DESCRIPTIO";

            /// <summary>
            /// Property for Reference
            /// </summary>
            public const string Reference = "REFERENCE";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";

            /// <summary>
            /// Property for ShipVia
            /// </summary>
            public const string ShipVia = "VIACODE";

            /// <summary>
            /// Property for ShipViaName
            /// </summary>
            public const string ShipViaName = "VIANAME";

            /// <summary>
            /// Property for LastReceiptNumber
            /// </summary>
            public const string LastReceiptNumber = "LASTRECEIP";

            /// <summary>
            /// Property for ReceiptDate
            /// </summary>
            public const string ReceiptDate = "RCPDATE";

            /// <summary>
            /// Property for NumberOfPostedReceipts
            /// </summary>
            public const string NumberOfPostedReceipts = "RCPCOUNT";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateSpread
            /// </summary>
            public const string RateSpread = "SPREAD";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for RateMatchType
            /// </summary>
            public const string RateMatchType = "RATEMATCH";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperation
            /// </summary>
            public const string RateOperation = "RATEOPER";

            /// <summary>
            /// Property for RateOverridden
            /// </summary>
            public const string RateOverridden = "RATEOVER";

            /// <summary>
            /// Property for DecimalPlaces
            /// </summary>
            public const string DecimalPlaces = "SCURNDECML";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTENDED";

            /// <summary>
            /// Property for Total
            /// </summary>
            public const string Total = "DOCTOTAL";

            /// <summary>
            /// Property for ExtendedReceivedAmount
            /// </summary>
            public const string ExtendedReceivedAmount = "EXTRECEIVE";

            /// <summary>
            /// Property for ExtendedCanceledAmount
            /// </summary>
            public const string ExtendedCanceledAmount = "EXTCANCEL";

            /// <summary>
            /// Property for QuantityOrdered
            /// </summary>
            public const string QuantityOrdered = "OQORDERED";

            /// <summary>
            /// Property for TaxGroup
            /// </summary>
            public const string TaxGroup = "TAXGROUP";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAXAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAXAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAXAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAXAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAXAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxBase1
            /// </summary>
            public const string TaxBase1 = "TAXBASE1";

            /// <summary>
            /// Property for TaxBase2
            /// </summary>
            public const string TaxBase2 = "TAXBASE2";

            /// <summary>
            /// Property for TaxBase3
            /// </summary>
            public const string TaxBase3 = "TAXBASE3";

            /// <summary>
            /// Property for TaxBase4
            /// </summary>
            public const string TaxBase4 = "TAXBASE4";

            /// <summary>
            /// Property for TaxBase5
            /// </summary>
            public const string TaxBase5 = "TAXBASE5";

            /// <summary>
            /// Property for IncludedTaxAmount1
            /// </summary>
            public const string IncludedTaxAmount1 = "TXINCLUDE1";

            /// <summary>
            /// Property for IncludedTaxAmount2
            /// </summary>
            public const string IncludedTaxAmount2 = "TXINCLUDE2";

            /// <summary>
            /// Property for IncludedTaxAmount3
            /// </summary>
            public const string IncludedTaxAmount3 = "TXINCLUDE3";

            /// <summary>
            /// Property for IncludedTaxAmount4
            /// </summary>
            public const string IncludedTaxAmount4 = "TXINCLUDE4";

            /// <summary>
            /// Property for IncludedTaxAmount5
            /// </summary>
            public const string IncludedTaxAmount5 = "TXINCLUDE5";

            /// <summary>
            /// Property for ExcludedTaxAmount1
            /// </summary>
            public const string ExcludedTaxAmount1 = "TXEXCLUDE1";

            /// <summary>
            /// Property for ExcludedTaxAmount2
            /// </summary>
            public const string ExcludedTaxAmount2 = "TXEXCLUDE2";

            /// <summary>
            /// Property for ExcludedTaxAmount3
            /// </summary>
            public const string ExcludedTaxAmount3 = "TXEXCLUDE3";

            /// <summary>
            /// Property for ExcludedTaxAmount4
            /// </summary>
            public const string ExcludedTaxAmount4 = "TXEXCLUDE4";

            /// <summary>
            /// Property for ExcludedTaxAmount5
            /// </summary>
            public const string ExcludedTaxAmount5 = "TXEXCLUDE5";

            /// <summary>
            /// Property for TaxAmount1
            /// </summary>
            public const string TaxAmount1 = "TAXAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2
            /// </summary>
            public const string TaxAmount2 = "TAXAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3
            /// </summary>
            public const string TaxAmount3 = "TAXAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4
            /// </summary>
            public const string TaxAmount4 = "TAXAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5
            /// </summary>
            public const string TaxAmount5 = "TAXAMOUNT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1
            /// </summary>
            public const string TaxRecoverableAmount1 = "TXRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2
            /// </summary>
            public const string TaxRecoverableAmount2 = "TXRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3
            /// </summary>
            public const string TaxRecoverableAmount3 = "TXRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4
            /// </summary>
            public const string TaxRecoverableAmount4 = "TXRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5
            /// </summary>
            public const string TaxRecoverableAmount5 = "TXRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1
            /// </summary>
            public const string TaxExpenseAmount1 = "TXEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2
            /// </summary>
            public const string TaxExpenseAmount2 = "TXEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3
            /// </summary>
            public const string TaxExpenseAmount3 = "TXEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4
            /// </summary>
            public const string TaxExpenseAmount4 = "TXEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5
            /// </summary>
            public const string TaxExpenseAmount5 = "TXEXPSAMT5";

            /// <summary>
            /// Property for TaxAllocatedAmount1
            /// </summary>
            public const string TaxAllocatedAmount1 = "TXALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2
            /// </summary>
            public const string TaxAllocatedAmount2 = "TXALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3
            /// </summary>
            public const string TaxAllocatedAmount3 = "TXALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4
            /// </summary>
            public const string TaxAllocatedAmount4 = "TXALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5
            /// </summary>
            public const string TaxAllocatedAmount5 = "TXALLOAMT5";

            /// <summary>
            /// Property for NetOfTax
            /// </summary>
            public const string NetOfTax = "TXBASEALLO";

            /// <summary>
            /// Property for TaxIncluded
            /// </summary>
            public const string TaxIncluded = "TXINCLUDED";

            /// <summary>
            /// Property for TaxExcluded
            /// </summary>
            public const string TaxExcluded = "TXEXCLUDED";

            /// <summary>
            /// Property for TotalTax
            /// </summary>
            public const string TotalTax = "TAXAMOUNT";

            /// <summary>
            /// Property for TotalTaxRecoverable
            /// </summary>
            public const string TotalTaxRecoverable = "TXRECVAMT";

            /// <summary>
            /// Property for TotalTaxExpensed
            /// </summary>
            public const string TotalTaxExpensed = "TXEXPSAMT";

            /// <summary>
            /// Property for TotalTaxAllocated
            /// </summary>
            public const string TotalTaxAllocated = "TXALLOAMT";

            /// <summary>
            /// Property for DocumentSource
            /// </summary>
            public const string DocumentSource = "DOCSOURCE";

            /// <summary>
            /// Property for AmountReceivedToDate
            /// </summary>
            public const string AmountReceivedToDate = "SRRECEIVED";

            /// <summary>
            /// Property for ExtendedOrderAmount
            /// </summary>
            public const string ExtendedOrderAmount = "SREXTORDER";

            /// <summary>
            /// Property for BillToLocation
            /// </summary>
            public const string BillToLocation = "BTCODE";

            /// <summary>
            /// Property for BillToLocationDescription
            /// </summary>
            public const string BillToLocationDescription = "BTDESC";

            /// <summary>
            /// Property for BillToAddress1
            /// </summary>
            public const string BillToAddress1 = "BTADDRESS1";

            /// <summary>
            /// Property for BillToAddress2
            /// </summary>
            public const string BillToAddress2 = "BTADDRESS2";

            /// <summary>
            /// Property for BillToAddress3
            /// </summary>
            public const string BillToAddress3 = "BTADDRESS3";

            /// <summary>
            /// Property for BillToAddress4
            /// </summary>
            public const string BillToAddress4 = "BTADDRESS4";

            /// <summary>
            /// Property for BillToCity
            /// </summary>
            public const string BillToCity = "BTCITY";

            /// <summary>
            /// Property for BillToStateProvince
            /// </summary>
            public const string BillToStateProvince = "BTSTATE";

            /// <summary>
            /// Property for BillToZipPostalCode
            /// </summary>
            public const string BillToZipPostalCode = "BTZIP";

            /// <summary>
            /// Property for BillToCountry
            /// </summary>
            public const string BillToCountry = "BTCOUNTRY";

            /// <summary>
            /// Property for BillToPhoneNumber
            /// </summary>
            public const string BillToPhoneNumber = "BTPHONE";

            /// <summary>
            /// Property for BillToFaxNumber
            /// </summary>
            public const string BillToFaxNumber = "BTFAX";

            /// <summary>
            /// Property for BillToContact
            /// </summary>
            public const string BillToContact = "BTCONTACT";

            /// <summary>
            /// Property for ShipToLocation
            /// </summary>
            public const string ShipToLocation = "STCODE";

            /// <summary>
            /// Property for ShipToLocationDescription
            /// </summary>
            public const string ShipToLocationDescription = "STDESC";

            /// <summary>
            /// Property for ShipToAddress1
            /// </summary>
            public const string ShipToAddress1 = "STADDRESS1";

            /// <summary>
            /// Property for ShipToAddress2
            /// </summary>
            public const string ShipToAddress2 = "STADDRESS2";

            /// <summary>
            /// Property for ShipToAddress3
            /// </summary>
            public const string ShipToAddress3 = "STADDRESS3";

            /// <summary>
            /// Property for ShipToAddress4
            /// </summary>
            public const string ShipToAddress4 = "STADDRESS4";

            /// <summary>
            /// Property for ShipToCity
            /// </summary>
            public const string ShipToCity = "STCITY";

            /// <summary>
            /// Property for ShipToStateProvince
            /// </summary>
            public const string ShipToStateProvince = "STSTATE";

            /// <summary>
            /// Property for ShipToZipPostalCode
            /// </summary>
            public const string ShipToZipPostalCode = "STZIP";

            /// <summary>
            /// Property for ShipToCountry
            /// </summary>
            public const string ShipToCountry = "STCOUNTRY";

            /// <summary>
            /// Property for ShipToPhoneNumber
            /// </summary>
            public const string ShipToPhoneNumber = "STPHONE";

            /// <summary>
            /// Property for ShipToFaxNumber
            /// </summary>
            public const string ShipToFaxNumber = "STFAX";

            /// <summary>
            /// Property for ShipToContact
            /// </summary>
            public const string ShipToContact = "STCONTACT";

            /// <summary>
            /// Property for TaxClass1Description
            /// </summary>
            public const string TaxClass1Description = "TAXCLASS1D";

            /// <summary>
            /// Property for TaxClass2Description
            /// </summary>
            public const string TaxClass2Description = "TAXCLASS2D";

            /// <summary>
            /// Property for TaxClass3Description
            /// </summary>
            public const string TaxClass3Description = "TAXCLASS3D";

            /// <summary>
            /// Property for TaxClass4Description
            /// </summary>
            public const string TaxClass4Description = "TAXCLASS4D";

            /// <summary>
            /// Property for TaxClass5Description
            /// </summary>
            public const string TaxClass5Description = "TAXCLASS5D";

            /// <summary>
            /// Property for TaxAuthority1Description
            /// </summary>
            public const string TaxAuthority1Description = "TAXAUTH1D";

            /// <summary>
            /// Property for TaxAuthority2Description
            /// </summary>
            public const string TaxAuthority2Description = "TAXAUTH2D";

            /// <summary>
            /// Property for TaxAuthority3Description
            /// </summary>
            public const string TaxAuthority3Description = "TAXAUTH3D";

            /// <summary>
            /// Property for TaxAuthority4Description
            /// </summary>
            public const string TaxAuthority4Description = "TAXAUTH4D";

            /// <summary>
            /// Property for TaxAuthority5Description
            /// </summary>
            public const string TaxAuthority5Description = "TAXAUTH5D";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "CURRENCYD";

            /// <summary>
            /// Property for RateTypeDescription
            /// </summary>
            public const string RateTypeDescription = "RATETYPED";

            /// <summary>
            /// Property for TaxGroupDescription
            /// </summary>
            public const string TaxGroupDescription = "TAXGROUPD";

            /// <summary>
            /// Property for TermsCodeDescription
            /// </summary>
            public const string TermsCodeDescription = "TERMSCODED";

            /// <summary>
            /// Property for NetOfTaxSum
            /// </summary>
            public const string NetOfTaxSum = "TCBASEALLO";

            /// <summary>
            /// Property for TaxIncluded1Sum
            /// </summary>
            public const string TaxIncluded1Sum = "TCINCLUDE1";

            /// <summary>
            /// Property for TaxIncluded2Sum
            /// </summary>
            public const string TaxIncluded2Sum = "TCINCLUDE2";

            /// <summary>
            /// Property for TaxIncluded3Sum
            /// </summary>
            public const string TaxIncluded3Sum = "TCINCLUDE3";

            /// <summary>
            /// Property for TaxIncluded4Sum
            /// </summary>
            public const string TaxIncluded4Sum = "TCINCLUDE4";

            /// <summary>
            /// Property for TaxIncluded5Sum
            /// </summary>
            public const string TaxIncluded5Sum = "TCINCLUDE5";

            /// <summary>
            /// Property for TaxAllocatedAmount1Sum
            /// </summary>
            public const string TaxAllocatedAmount1Sum = "TCALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2Sum
            /// </summary>
            public const string TaxAllocatedAmount2Sum = "TCALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3Sum
            /// </summary>
            public const string TaxAllocatedAmount3Sum = "TCALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4Sum
            /// </summary>
            public const string TaxAllocatedAmount4Sum = "TCALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5Sum
            /// </summary>
            public const string TaxAllocatedAmount5Sum = "TCALLOAMT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1Sum
            /// </summary>
            public const string TaxRecoverableAmount1Sum = "TCRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2Sum
            /// </summary>
            public const string TaxRecoverableAmount2Sum = "TCRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3Sum
            /// </summary>
            public const string TaxRecoverableAmount3Sum = "TCRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4Sum
            /// </summary>
            public const string TaxRecoverableAmount4Sum = "TCRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5Sum
            /// </summary>
            public const string TaxRecoverableAmount5Sum = "TCRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1Sum
            /// </summary>
            public const string TaxExpenseAmount1Sum = "TCEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2Sum
            /// </summary>
            public const string TaxExpenseAmount2Sum = "TCEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3Sum
            /// </summary>
            public const string TaxExpenseAmount3Sum = "TCEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4Sum
            /// </summary>
            public const string TaxExpenseAmount4Sum = "TCEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5Sum
            /// </summary>
            public const string TaxExpenseAmount5Sum = "TCEXPSAMT5";

            /// <summary>
            /// Property for TotalCTaxAllocated
            /// </summary>
            public const string TotalCTaxAllocated = "TCALLOAMT";

            /// <summary>
            /// Property for TaxCIncluded
            /// </summary>
            public const string TaxCIncluded = "TCINCLUDED";

            /// <summary>
            /// Property for TaxCExcluded
            /// </summary>
            public const string TaxCExcluded = "TCEXCLUDED";

            /// <summary>
            /// Property for TotalUnbalancedTax
            /// </summary>
            public const string TotalUnbalancedTax = "UBALTAXAMT";

            /// <summary>
            /// Property for TotalUnbalancedAllocatedTax
            /// </summary>
            public const string TotalUnbalancedAllocatedTax = "UBALTXALLO";

            /// <summary>
            /// Property for Subtotal
            /// </summary>
            public const string Subtotal = "SUBTOTAL";

            /// <summary>
            /// Property for TaxcalculationIspending
            /// </summary>
            public const string TaxcalculationIspending = "PENDINGCAL";

            /// <summary>
            /// Property for DocumentLocked
            /// </summary>
            public const string DocumentLocked = "LOCKED";

            /// <summary>
            /// Property for IsDocumentDeletable
            /// </summary>
            public const string IsDocumentDeletable = "CANDELETE";

            /// <summary>
            /// Property for IsRecordActive
            /// </summary>
            public const string IsRecordActive = "ISACTIVE";

            /// <summary>
            /// Property for ExchangeRateExists
            /// </summary>
            public const string ExchangeRateExists = "RATEEXISTS";

            /// <summary>
            /// Property for HasDetails
            /// </summary>
            public const string HasDetails = "HASDETAILS";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "VDEMAIL";

            /// <summary>
            /// Property for ContactPhone
            /// </summary>
            public const string ContactPhone = "VDPHONEC";

            /// <summary>
            /// Property for ContactFax
            /// </summary>
            public const string ContactFax = "VDFAXC";

            /// <summary>
            /// Property for ContactEmail
            /// </summary>
            public const string ContactEmail = "VDEMAILC";

            /// <summary>
            /// Property for BillToEmail
            /// </summary>
            public const string BillToEmail = "BTEMAIL";

            /// <summary>
            /// Property for BillToContactPhone
            /// </summary>
            public const string BillToContactPhone = "BTPHONEC";

            /// <summary>
            /// Property for BillToContactFax
            /// </summary>
            public const string BillToContactFax = "BTFAXC";

            /// <summary>
            /// Property for BillToContactEmail
            /// </summary>
            public const string BillToContactEmail = "BTEMAILC";

            /// <summary>
            /// Property for ShipToEmail
            /// </summary>
            public const string ShipToEmail = "STEMAIL";

            /// <summary>
            /// Property for ShipToContactPhone
            /// </summary>
            public const string ShipToContactPhone = "STPHONEC";

            /// <summary>
            /// Property for ShipToContactFax
            /// </summary>
            public const string ShipToContactFax = "STFAXC";

            /// <summary>
            /// Property for ShipToContactEmail
            /// </summary>
            public const string ShipToContactEmail = "STEMAILC";

            /// <summary>
            /// Property for DiscountPercentage
            /// </summary>
            public const string DiscountPercentage = "DISCPCT";

            /// <summary>
            /// Property for DiscountAmount
            /// </summary>
            public const string DiscountAmount = "DISCOUNT";

            /// <summary>
            /// Property for DiscountAmountSum
            /// </summary>
            public const string DiscountAmountSum = "DISCOUNTC";

            /// <summary>
            /// Property for NetExtendedCost
            /// </summary>
            public const string NetExtendedCost = "NETXTENDED";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for Command
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for RequisitionNumber
            /// </summary>
            public const string RequisitionNumber = "RQNNUMBER";

            /// <summary>
            /// Property for RequisitionSequenceKey
            /// </summary>
            public const string RequisitionSequenceKey = "RQNHSEQ";

            /// <summary>
            /// Property for ConversionSourceAmount
            /// </summary>
            public const string ConversionSourceAmount = "SCAMOUNT";

            /// <summary>
            /// Property for ConversionFunctionalAmount
            /// </summary>
            public const string ConversionFunctionalAmount = "FCAMOUNT";

            /// <summary>
            /// Property for JobRelatedLines
            /// </summary>
            public const string JobRelatedLines = "JOBLINES";

            /// <summary>
            /// Property for ProcessCommandSequenceNumber
            /// </summary>
            public const string ProcessCommandSequenceNumber = "OOVERSEQ";

            /// <summary>
            /// Property for FunctionalIsReset
            /// </summary>
            public const string FunctionalIsReset = "FCISRESET";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "HASJOB";

            /// <summary>
            /// Property for AgentTransactionType
            /// </summary>
            public const string AgentTransactionType = "AGENTTTYPE";

            /// <summary>
            /// Property for AgentSequenceKey
            /// </summary>
            public const string AgentSequenceKey = "AGENTHSEQ";

            /// <summary>
            /// Property for AgentDayendTransactionNumber
            /// </summary>
            public const string AgentDayendTransactionNumber = "AGTRANSNUM";

            /// <summary>
            /// Property for AgentDocumentNumber
            /// </summary>
            public const string AgentDocumentNumber = "AGDOCNUM";

            /// <summary>
            /// Property for AgentSourceDocument
            /// </summary>
            public const string AgentSourceDocument = "AGSRCDOC";

            /// <summary>
            /// Property for AgentIsFromMultipleDocuments
            /// </summary>
            public const string AgentIsFromMultipleDocuments = "AGMULTIDOC";

            /// <summary>
            /// Property for AgentDate
            /// </summary>
            public const string AgentDate = "AGDATE";

            /// <summary>
            /// Property for AgentFiscalYear
            /// </summary>
            public const string AgentFiscalYear = "AGFISCYEAR";

            /// <summary>
            /// Property for AgentFiscalPeriod
            /// </summary>
            public const string AgentFiscalPeriod = "AGFISCPER";

            /// <summary>
            /// Property for AgentDescription
            /// </summary>
            public const string AgentDescription = "AGDESC";

            /// <summary>
            /// Property for AgentReference
            /// </summary>
            public const string AgentReference = "AGREF";

            /// <summary>
            /// Property for TaxReportingCurrency
            /// </summary>
            public const string TaxReportingCurrency = "TRCURRENCY";

            /// <summary>
            /// Property for TaxReportingExchangeRate
            /// </summary>
            public const string TaxReportingExchangeRate = "RATERC";

            /// <summary>
            /// Property for TaxReportingRateSpread
            /// </summary>
            public const string TaxReportingRateSpread = "SPREADRC";

            /// <summary>
            /// Property for TaxReportingRateType
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";

            /// <summary>
            /// Property for TaxReportingRateMatchType
            /// </summary>
            public const string TaxReportingRateMatchType = "RATEMTCHRC";

            /// <summary>
            /// Property for TaxReportingRateDate
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";

            /// <summary>
            /// Property for TaxReportingRateOperation
            /// </summary>
            public const string TaxReportingRateOperation = "RATEOPERRC";

            /// <summary>
            /// Property for TaxReportingRateOverridden
            /// </summary>
            public const string TaxReportingRateOverridden = "RATERCOVER";

            /// <summary>
            /// Property for TaxReportingDecimalPlaces
            /// </summary>
            public const string TaxReportingDecimalPlaces = "RCURNDECML";

            /// <summary>
            /// Property for TaxReportingAmount1
            /// </summary>
            public const string TaxReportingAmount1 = "TARAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2
            /// </summary>
            public const string TaxReportingAmount2 = "TARAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3
            /// </summary>
            public const string TaxReportingAmount3 = "TARAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4
            /// </summary>
            public const string TaxReportingAmount4 = "TARAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5
            /// </summary>
            public const string TaxReportingAmount5 = "TARAMOUNT5";

            /// <summary>
            /// Property for TaxReportingIncludedAmount1
            /// </summary>
            public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncludedAmount2
            /// </summary>
            public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncludedAmount3
            /// </summary>
            public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncludedAmount4
            /// </summary>
            public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncludedAmount5
            /// </summary>
            public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcludedAmount1
            /// </summary>
            public const string TaxReportingExcludedAmount1 = "TREXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcludedAmount2
            /// </summary>
            public const string TaxReportingExcludedAmount2 = "TREXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcludedAmount3
            /// </summary>
            public const string TaxReportingExcludedAmount3 = "TREXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcludedAmount4
            /// </summary>
            public const string TaxReportingExcludedAmount4 = "TREXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcludedAmount5
            /// </summary>
            public const string TaxReportingExcludedAmount5 = "TREXCLUDE5";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt1
            /// </summary>
            public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt2
            /// </summary>
            public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt3
            /// </summary>
            public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt4
            /// </summary>
            public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt5
            /// </summary>
            public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

            /// <summary>
            /// Property for TaxReportingExpenseAmount1
            /// </summary>
            public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

            /// <summary>
            /// Property for TaxReportingExpenseAmount2
            /// </summary>
            public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

            /// <summary>
            /// Property for TaxReportingExpenseAmount3
            /// </summary>
            public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

            /// <summary>
            /// Property for TaxReportingExpenseAmount4
            /// </summary>
            public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

            /// <summary>
            /// Property for TaxReportingExpenseAmount5
            /// </summary>
            public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount1
            /// </summary>
            public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount2
            /// </summary>
            public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount3
            /// </summary>
            public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount4
            /// </summary>
            public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount5
            /// </summary>
            public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

            /// <summary>
            /// Property for TaxReportingExchRateExists
            /// </summary>
            public const string TaxReportingExchRateExists = "RATERCEXST";

            /// <summary>
            /// Property for DerivedTaxReportingExchRate
            /// </summary>
            public const string DerivedTaxReportingExchRate = "RATERCC";

            /// <summary>
            /// Property for TaxReportingCurrencyDesc
            /// </summary>
            public const string TaxReportingCurrencyDesc = "TRCURRDESC";

            /// <summary>
            /// Property for TaxReportingRateTypeDesc
            /// </summary>
            public const string TaxReportingRateTypeDesc = "RATETYPRCD";

            /// <summary>
            /// Property for TaxReportingTotalAmount
            /// </summary>
            public const string TaxReportingTotalAmount = "TARAMOUNT";

            /// <summary>
            /// Property for TaxReportingIncludedAmount
            /// </summary>
            public const string TaxReportingIncludedAmount = "TRINCLUDED";

            /// <summary>
            /// Property for TaxReportingExcludedAmount
            /// </summary>
            public const string TaxReportingExcludedAmount = "TREXCLUDED";

            /// <summary>
            /// Property for TaxReportingRecoverableAmount
            /// </summary>
            public const string TaxReportingRecoverableAmount = "TRRECVAMT";

            /// <summary>
            /// Property for TaxReportingExpensedAmount
            /// </summary>
            public const string TaxReportingExpensedAmount = "TREXPSAMT";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount
            /// </summary>
            public const string TaxReportingAllocatedAmount = "TRALLOAMT";

            /// <summary>
            /// Property for TaxBase1Sum
            /// </summary>
            public const string TaxBase1Sum = "TACBASE1";

            /// <summary>
            /// Property for TaxBase2Sum
            /// </summary>
            public const string TaxBase2Sum = "TACBASE2";

            /// <summary>
            /// Property for TaxBase3Sum
            /// </summary>
            public const string TaxBase3Sum = "TACBASE3";

            /// <summary>
            /// Property for TaxBase4Sum
            /// </summary>
            public const string TaxBase4Sum = "TACBASE4";

            /// <summary>
            /// Property for TaxBase5Sum
            /// </summary>
            public const string TaxBase5Sum = "TACBASE5";

            /// <summary>
            /// Property for TaxAmount1Sum
            /// </summary>
            public const string TaxAmount1Sum = "TACAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2Sum
            /// </summary>
            public const string TaxAmount2Sum = "TACAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3Sum
            /// </summary>
            public const string TaxAmount3Sum = "TACAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4Sum
            /// </summary>
            public const string TaxAmount4Sum = "TACAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5Sum
            /// </summary>
            public const string TaxAmount5Sum = "TACAMOUNT5";

            /// <summary>
            /// Property for TaxExcluded1Sum
            /// </summary>
            public const string TaxExcluded1Sum = "TCEXCLUDE1";

            /// <summary>
            /// Property for TaxExcluded2Sum
            /// </summary>
            public const string TaxExcluded2Sum = "TCEXCLUDE2";

            /// <summary>
            /// Property for TaxExcluded3Sum
            /// </summary>
            public const string TaxExcluded3Sum = "TCEXCLUDE3";

            /// <summary>
            /// Property for TaxExcluded4Sum
            /// </summary>
            public const string TaxExcluded4Sum = "TCEXCLUDE4";

            /// <summary>
            /// Property for TaxExcluded5Sum
            /// </summary>
            public const string TaxExcluded5Sum = "TCEXCLUDE5";

            /// <summary>
            /// Property for TaxReportingAmount1Sum
            /// </summary>
            public const string TaxReportingAmount1Sum = "TALAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2Sum
            /// </summary>
            public const string TaxReportingAmount2Sum = "TALAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3Sum
            /// </summary>
            public const string TaxReportingAmount3Sum = "TALAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4Sum
            /// </summary>
            public const string TaxReportingAmount4Sum = "TALAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5Sum
            /// </summary>
            public const string TaxReportingAmount5Sum = "TALAMOUNT5";

            /// <summary>
            /// Property for TaxReportingIncluded1Sum
            /// </summary>
            public const string TaxReportingIncluded1Sum = "TLINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncluded2Sum
            /// </summary>
            public const string TaxReportingIncluded2Sum = "TLINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncluded3Sum
            /// </summary>
            public const string TaxReportingIncluded3Sum = "TLINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncluded4Sum
            /// </summary>
            public const string TaxReportingIncluded4Sum = "TLINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncluded5Sum
            /// </summary>
            public const string TaxReportingIncluded5Sum = "TLINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcluded1Sum
            /// </summary>
            public const string TaxReportingExcluded1Sum = "TLEXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcluded2Sum
            /// </summary>
            public const string TaxReportingExcluded2Sum = "TLEXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcluded3Sum
            /// </summary>
            public const string TaxReportingExcluded3Sum = "TLEXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcluded4Sum
            /// </summary>
            public const string TaxReportingExcluded4Sum = "TLEXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcluded5Sum
            /// </summary>
            public const string TaxReportingExcluded5Sum = "TLEXCLUDE5";

            /// <summary>
            /// Property for TaxRepAllocatedAmount1Sum
            /// </summary>
            public const string TaxRepAllocatedAmount1Sum = "TLALLOAMT1";

            /// <summary>
            /// Property for TaxRepAllocatedAmount2Sum
            /// </summary>
            public const string TaxRepAllocatedAmount2Sum = "TLALLOAMT2";

            /// <summary>
            /// Property for TaxRepAllocatedAmount3Sum
            /// </summary>
            public const string TaxRepAllocatedAmount3Sum = "TLALLOAMT3";

            /// <summary>
            /// Property for TaxRepAllocatedAmount4Sum
            /// </summary>
            public const string TaxRepAllocatedAmount4Sum = "TLALLOAMT4";

            /// <summary>
            /// Property for TaxRepAllocatedAmount5Sum
            /// </summary>
            public const string TaxRepAllocatedAmount5Sum = "TLALLOAMT5";

            /// <summary>
            /// Property for TaxRepRecoverableAmt1Sum
            /// </summary>
            public const string TaxRepRecoverableAmt1Sum = "TLRECVAMT1";

            /// <summary>
            /// Property for TaxRepRecoverableAmt2Sum
            /// </summary>
            public const string TaxRepRecoverableAmt2Sum = "TLRECVAMT2";

            /// <summary>
            /// Property for TaxRepRecoverableAmt3Sum
            /// </summary>
            public const string TaxRepRecoverableAmt3Sum = "TLRECVAMT3";

            /// <summary>
            /// Property for TaxRepRecoverableAmt4Sum
            /// </summary>
            public const string TaxRepRecoverableAmt4Sum = "TLRECVAMT4";

            /// <summary>
            /// Property for TaxRepRecoverableAmt5Sum
            /// </summary>
            public const string TaxRepRecoverableAmt5Sum = "TLRECVAMT5";

            /// <summary>
            /// Property for TaxRepExpenseAmount1Sum
            /// </summary>
            public const string TaxRepExpenseAmount1Sum = "TLEXPSAMT1";

            /// <summary>
            /// Property for TaxRepExpenseAmount2Sum
            /// </summary>
            public const string TaxRepExpenseAmount2Sum = "TLEXPSAMT2";

            /// <summary>
            /// Property for TaxRepExpenseAmount3Sum
            /// </summary>
            public const string TaxRepExpenseAmount3Sum = "TLEXPSAMT3";

            /// <summary>
            /// Property for TaxRepExpenseAmount4Sum
            /// </summary>
            public const string TaxRepExpenseAmount4Sum = "TLEXPSAMT4";

            /// <summary>
            /// Property for TaxRepExpenseAmount5Sum
            /// </summary>
            public const string TaxRepExpenseAmount5Sum = "TLEXPSAMT5";

            /// <summary>
            /// Property for VendorAccountSet
            /// </summary>
            public const string VendorAccountSet = "VDACCTSET";

            /// <summary>
            /// Property for VendorAccountSetDescription
            /// </summary>
            public const string VendorAccountSetDescription = "VDACCTDESC";

            /// <summary>
            /// Property for EnteredBy
            /// </summary>
            public const string EnteredBy = "ENTEREDBY";

            /// <summary>
            /// Property for NextDetailNumber
            /// </summary>
            public const string NextDetailNumber = "DETAILNEXT";

        }
        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of PurchaseOrder Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 1;

            /// <summary>
            /// Property Indexer for NextLineSequence
            /// </summary>
            public const int NextLineSequence = 2;

            /// <summary>
            /// Property Indexer for Lines
            /// </summary>
            public const int Lines = 3;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 4;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 5;

            /// <summary>
            /// Property Indexer for Requisitions
            /// </summary>
            public const int Requisitions = 6;

            /// <summary>
            /// Property Indexer for RequisitionsCompleted
            /// </summary>
            public const int RequisitionsCompleted = 7;

            /// <summary>
            /// Property Indexer for Printed
            /// </summary>
            public const int Printed = 8;

            /// <summary>
            /// Property Indexer for AutoTaxCalculationOnSave
            /// </summary>
            public const int AutoTaxCalculationOnSave = 9;

            /// <summary>
            /// Property Indexer for LabelsPrinted
            /// </summary>
            public const int LabelsPrinted = 10;

            /// <summary>
            /// Property Indexer for NumberOfLabels
            /// </summary>
            public const int NumberOfLabels = 11;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 12;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 13;

            /// <summary>
            /// Property Indexer for LastPostingDate
            /// </summary>
            public const int LastPostingDate = 14;

            /// <summary>
            /// Property Indexer for PurchaseOrderDate
            /// </summary>
            public const int PurchaseOrderDate = 15;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 16;

            /// <summary>
            /// Property Indexer for TemplateCode
            /// </summary>
            public const int TemplateCode = 17;

            /// <summary>
            /// Property Indexer for FreeOnBoardPoint
            /// </summary>
            public const int FreeOnBoardPoint = 18;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 19;

            /// <summary>
            /// Property Indexer for VendorExists
            /// </summary>
            public const int VendorExists = 20;

            /// <summary>
            /// Property Indexer for Name
            /// </summary>
            public const int Name = 21;

            /// <summary>
            /// Property Indexer for Address1
            /// </summary>
            public const int Address1 = 22;

            /// <summary>
            /// Property Indexer for Address2
            /// </summary>
            public const int Address2 = 23;

            /// <summary>
            /// Property Indexer for Address3
            /// </summary>
            public const int Address3 = 24;

            /// <summary>
            /// Property Indexer for Address4
            /// </summary>
            public const int Address4 = 25;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 26;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 27;

            /// <summary>
            /// Property Indexer for ZipPostalCode
            /// </summary>
            public const int ZipPostalCode = 28;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 29;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 30;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 31;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 32;

            /// <summary>
            /// Property Indexer for TermsCode
            /// </summary>
            public const int TermsCode = 33;

            /// <summary>
            /// Property Indexer for IsRequisitions
            /// </summary>
            public const int IsRequisitions = 34;

            /// <summary>
            /// Property Indexer for PurchaseOrderType
            /// </summary>
            public const int PurchaseOrderType = 35;

            /// <summary>
            /// Property Indexer for OnHold
            /// </summary>
            public const int OnHold = 36;

            /// <summary>
            /// Property Indexer for OrderDate
            /// </summary>
            public const int OrderDate = 37;

            /// <summary>
            /// Property Indexer for ExpectedArrivalDate
            /// </summary>
            public const int ExpectedArrivalDate = 38;

            /// <summary>
            /// Property Indexer for AmountOriginallyAuthorized
            /// </summary>
            public const int AmountOriginallyAuthorized = 39;

            /// <summary>
            /// Property Indexer for AmountRemaining
            /// </summary>
            public const int AmountRemaining = 40;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 41;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 42;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 43;

            /// <summary>
            /// Property Indexer for ShipVia
            /// </summary>
            public const int ShipVia = 44;

            /// <summary>
            /// Property Indexer for ShipViaName
            /// </summary>
            public const int ShipViaName = 45;

            /// <summary>
            /// Property Indexer for LastReceiptNumber
            /// </summary>
            public const int LastReceiptNumber = 46;

            /// <summary>
            /// Property Indexer for ReceiptDate
            /// </summary>
            public const int ReceiptDate = 47;

            /// <summary>
            /// Property Indexer for NumberOfPostedReceipts
            /// </summary>
            public const int NumberOfPostedReceipts = 48;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 57;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 58;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 59;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 60;

            /// <summary>
            /// Property Indexer for RateMatchType
            /// </summary>
            public const int RateMatchType = 61;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 62;

            /// <summary>
            /// Property Indexer for RateOperation
            /// </summary>
            public const int RateOperation = 63;

            /// <summary>
            /// Property Indexer for RateOverridden
            /// </summary>
            public const int RateOverridden = 64;

            /// <summary>
            /// Property Indexer for DecimalPlaces
            /// </summary>
            public const int DecimalPlaces = 65;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 66;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 67;

            /// <summary>
            /// Property Indexer for Total
            /// </summary>
            public const int Total = 68;

            /// <summary>
            /// Property Indexer for ExtendedReceivedAmount
            /// </summary>
            public const int ExtendedReceivedAmount = 69;

            /// <summary>
            /// Property Indexer for ExtendedCanceledAmount
            /// </summary>
            public const int ExtendedCanceledAmount = 70;

            /// <summary>
            /// Property Indexer for QuantityOrdered
            /// </summary>
            public const int QuantityOrdered = 71;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 72;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 73;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 74;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 75;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 76;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 77;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 78;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 79;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 80;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 81;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 82;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 83;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 84;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 85;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 86;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 87;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 88;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 89;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 90;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 91;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 92;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 93;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 94;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 95;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 96;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 97;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 98;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 99;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 100;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 101;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 102;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 103;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 104;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 105;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 106;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 107;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 108;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 109;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 110;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 111;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 112;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 113;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 114;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 115;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 116;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 117;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 118;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 119;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 120;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 121;

            /// <summary>
            /// Property Indexer for TotalTaxRecoverable
            /// </summary>
            public const int TotalTaxRecoverable = 122;

            /// <summary>
            /// Property Indexer for TotalTaxExpensed
            /// </summary>
            public const int TotalTaxExpensed = 123;

            /// <summary>
            /// Property Indexer for TotalTaxAllocated
            /// </summary>
            public const int TotalTaxAllocated = 124;

            /// <summary>
            /// Property Indexer for DocumentSource
            /// </summary>
            public const int DocumentSource = 125;

            /// <summary>
            /// Property Indexer for AmountReceivedToDate
            /// </summary>
            public const int AmountReceivedToDate = 136;

            /// <summary>
            /// Property Indexer for ExtendedOrderAmount
            /// </summary>
            public const int ExtendedOrderAmount = 137;

            /// <summary>
            /// Property Indexer for BillToLocation
            /// </summary>
            public const int BillToLocation = 138;

            /// <summary>
            /// Property Indexer for BillToLocationDescription
            /// </summary>
            public const int BillToLocationDescription = 139;

            /// <summary>
            /// Property Indexer for BillToAddress1
            /// </summary>
            public const int BillToAddress1 = 140;

            /// <summary>
            /// Property Indexer for BillToAddress2
            /// </summary>
            public const int BillToAddress2 = 141;

            /// <summary>
            /// Property Indexer for BillToAddress3
            /// </summary>
            public const int BillToAddress3 = 142;

            /// <summary>
            /// Property Indexer for BillToAddress4
            /// </summary>
            public const int BillToAddress4 = 143;

            /// <summary>
            /// Property Indexer for BillToCity
            /// </summary>
            public const int BillToCity = 144;

            /// <summary>
            /// Property Indexer for BillToStateProvince
            /// </summary>
            public const int BillToStateProvince = 145;

            /// <summary>
            /// Property Indexer for BillToZipPostalCode
            /// </summary>
            public const int BillToZipPostalCode = 146;

            /// <summary>
            /// Property Indexer for BillToCountry
            /// </summary>
            public const int BillToCountry = 147;

            /// <summary>
            /// Property Indexer for BillToPhoneNumber
            /// </summary>
            public const int BillToPhoneNumber = 148;

            /// <summary>
            /// Property Indexer for BillToFaxNumber
            /// </summary>
            public const int BillToFaxNumber = 149;

            /// <summary>
            /// Property Indexer for BillToContact
            /// </summary>
            public const int BillToContact = 150;

            /// <summary>
            /// Property Indexer for ShipToLocation
            /// </summary>
            public const int ShipToLocation = 151;

            /// <summary>
            /// Property Indexer for ShipToLocationDescription
            /// </summary>
            public const int ShipToLocationDescription = 152;

            /// <summary>
            /// Property Indexer for ShipToAddress1
            /// </summary>
            public const int ShipToAddress1 = 153;

            /// <summary>
            /// Property Indexer for ShipToAddress2
            /// </summary>
            public const int ShipToAddress2 = 154;

            /// <summary>
            /// Property Indexer for ShipToAddress3
            /// </summary>
            public const int ShipToAddress3 = 155;

            /// <summary>
            /// Property Indexer for ShipToAddress4
            /// </summary>
            public const int ShipToAddress4 = 156;

            /// <summary>
            /// Property Indexer for ShipToCity
            /// </summary>
            public const int ShipToCity = 157;

            /// <summary>
            /// Property Indexer for ShipToStateProvince
            /// </summary>
            public const int ShipToStateProvince = 158;

            /// <summary>
            /// Property Indexer for ShipToZipPostalCode
            /// </summary>
            public const int ShipToZipPostalCode = 159;

            /// <summary>
            /// Property Indexer for ShipToCountry
            /// </summary>
            public const int ShipToCountry = 160;

            /// <summary>
            /// Property Indexer for ShipToPhoneNumber
            /// </summary>
            public const int ShipToPhoneNumber = 161;

            /// <summary>
            /// Property Indexer for ShipToFaxNumber
            /// </summary>
            public const int ShipToFaxNumber = 162;

            /// <summary>
            /// Property Indexer for ShipToContact
            /// </summary>
            public const int ShipToContact = 163;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 171;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 172;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 173;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 174;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 175;

            /// <summary>
            /// Property Indexer for TaxAuthority1Description
            /// </summary>
            public const int TaxAuthority1Description = 176;

            /// <summary>
            /// Property Indexer for TaxAuthority2Description
            /// </summary>
            public const int TaxAuthority2Description = 177;

            /// <summary>
            /// Property Indexer for TaxAuthority3Description
            /// </summary>
            public const int TaxAuthority3Description = 178;

            /// <summary>
            /// Property Indexer for TaxAuthority4Description
            /// </summary>
            public const int TaxAuthority4Description = 179;

            /// <summary>
            /// Property Indexer for TaxAuthority5Description
            /// </summary>
            public const int TaxAuthority5Description = 180;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 181;

            /// <summary>
            /// Property Indexer for RateTypeDescription
            /// </summary>
            public const int RateTypeDescription = 182;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 183;

            /// <summary>
            /// Property Indexer for TermsCodeDescription
            /// </summary>
            public const int TermsCodeDescription = 184;

            /// <summary>
            /// Property Indexer for NetOfTaxSum
            /// </summary>
            public const int NetOfTaxSum = 185;

            /// <summary>
            /// Property Indexer for TaxIncluded1Sum
            /// </summary>
            public const int TaxIncluded1Sum = 186;

            /// <summary>
            /// Property Indexer for TaxIncluded2Sum
            /// </summary>
            public const int TaxIncluded2Sum = 187;

            /// <summary>
            /// Property Indexer for TaxIncluded3Sum
            /// </summary>
            public const int TaxIncluded3Sum = 188;

            /// <summary>
            /// Property Indexer for TaxIncluded4Sum
            /// </summary>
            public const int TaxIncluded4Sum = 189;

            /// <summary>
            /// Property Indexer for TaxIncluded5Sum
            /// </summary>
            public const int TaxIncluded5Sum = 190;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1Sum
            /// </summary>
            public const int TaxAllocatedAmount1Sum = 191;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2Sum
            /// </summary>
            public const int TaxAllocatedAmount2Sum = 192;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3Sum
            /// </summary>
            public const int TaxAllocatedAmount3Sum = 193;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4Sum
            /// </summary>
            public const int TaxAllocatedAmount4Sum = 194;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5Sum
            /// </summary>
            public const int TaxAllocatedAmount5Sum = 195;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1Sum
            /// </summary>
            public const int TaxRecoverableAmount1Sum = 196;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2Sum
            /// </summary>
            public const int TaxRecoverableAmount2Sum = 197;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3Sum
            /// </summary>
            public const int TaxRecoverableAmount3Sum = 198;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4Sum
            /// </summary>
            public const int TaxRecoverableAmount4Sum = 199;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5Sum
            /// </summary>
            public const int TaxRecoverableAmount5Sum = 200;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1Sum
            /// </summary>
            public const int TaxExpenseAmount1Sum = 201;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2Sum
            /// </summary>
            public const int TaxExpenseAmount2Sum = 202;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3Sum
            /// </summary>
            public const int TaxExpenseAmount3Sum = 203;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4Sum
            /// </summary>
            public const int TaxExpenseAmount4Sum = 204;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5Sum
            /// </summary>
            public const int TaxExpenseAmount5Sum = 205;

            /// <summary>
            /// Property Indexer for TotalCTaxAllocated
            /// </summary>
            public const int TotalCTaxAllocated = 206;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for TCINCLUDED
            /// </summary>
            public const int TaxCIncluded = 207;

            /// <summary>
            /// Property Indexer for TaxCExcluded
            /// </summary>
            public const int TaxCExcluded = 208;

            /// <summary>
            /// Property Indexer for TotalUnbalancedTax
            /// </summary>
            public const int TotalUnbalancedTax = 209;

            /// <summary>
            /// Property Indexer for TotalUnbalancedAllocatedTax
            /// </summary>
            public const int TotalUnbalancedAllocatedTax = 210;

            /// <summary>
            /// Property Indexer for Subtotal
            /// </summary>
            public const int Subtotal = 211;

            /// <summary>
            /// Property Indexer for TaxcalculationIspending
            /// </summary>
            public const int TaxcalculationIspending = 212;

            /// <summary>
            /// Property Indexer for DocumentLocked
            /// </summary>
            public const int DocumentLocked = 213;

            /// <summary>
            /// Property Indexer for IsDocumentDeletable
            /// </summary>
            public const int IsDocumentDeletable = 214;

            /// <summary>
            /// Property Indexer for IsRecordActive
            /// </summary>
            public const int IsRecordActive = 215;

            /// <summary>
            /// Property Indexer for ExchangeRateExists
            /// </summary>
            public const int ExchangeRateExists = 216;

            /// <summary>
            /// Property Indexer for HasDetails
            /// </summary>
            public const int HasDetails = 217;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 218;

            /// <summary>
            /// Property Indexer for ContactPhone
            /// </summary>
            public const int ContactPhone = 219;

            /// <summary>
            /// Property Indexer for ContactFax
            /// </summary>
            public const int ContactFax = 220;

            /// <summary>
            /// Property Indexer for ContactEmail
            /// </summary>
            public const int ContactEmail = 221;

            /// <summary>
            /// Property Indexer for BillToEmail
            /// </summary>
            public const int BillToEmail = 222;

            /// <summary>
            /// Property Indexer for BillToContactPhone
            /// </summary>
            public const int BillToContactPhone = 223;

            /// <summary>
            /// Property Indexer for BillToContactFax
            /// </summary>
            public const int BillToContactFax = 224;

            /// <summary>
            /// Property Indexer for BillToContactEmail
            /// </summary>
            public const int BillToContactEmail = 225;

            /// <summary>
            /// Property Indexer for ShipToEmail
            /// </summary>
            public const int ShipToEmail = 226;

            /// <summary>
            /// Property Indexer for ShipToContactPhone
            /// </summary>
            public const int ShipToContactPhone = 227;

            /// <summary>
            /// Property Indexer for ShipToContactFax
            /// </summary>
            public const int ShipToContactFax = 228;

            /// <summary>
            /// Property Indexer for ShipToContactEmail
            /// </summary>
            public const int ShipToContactEmail = 229;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 230;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 231;

            /// <summary>
            /// Property Indexer for DiscountAmountSum
            /// </summary>
            public const int DiscountAmountSum = 232;

            /// <summary>
            /// Property Indexer for NetExtendedCost
            /// </summary>
            public const int NetExtendedCost = 233;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 234;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 235;

            /// <summary>
            /// Property Indexer for RequisitionNumber
            /// </summary>
            public const int RequisitionNumber = 236;

            /// <summary>
            /// Property Indexer for RequisitionSequenceKey
            /// </summary>
            public const int RequisitionSequenceKey = 237;

            /// <summary>
            /// Property Indexer for ConversionSourceAmount
            /// </summary>
            public const int ConversionSourceAmount = 238;

            /// <summary>
            /// Property Indexer for ConversionFunctionalAmount
            /// </summary>
            public const int ConversionFunctionalAmount = 239;

            /// <summary>
            /// Property Indexer for JobRelatedLines
            /// </summary>
            public const int JobRelatedLines = 240;

            /// <summary>
            /// Property Indexer for ProcessCommandSequenceNumber
            /// </summary>
            public const int ProcessCommandSequenceNumber = 241;

            /// <summary>
            /// Property Indexer for FunctionalIsReset
            /// </summary>
            public const int FunctionalIsReset = 242;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 243;

            /// <summary>
            /// Property Indexer for AgentTransactionType
            /// </summary>
            public const int AgentTransactionType = 244;

            /// <summary>
            /// Property Indexer for AgentSequenceKey
            /// </summary>
            public const int AgentSequenceKey = 245;

            /// <summary>
            /// Property Indexer for AgentDayendTransactionNumber
            /// </summary>
            public const int AgentDayendTransactionNumber = 246;

            /// <summary>
            /// Property Indexer for AgentDocumentNumber
            /// </summary>
            public const int AgentDocumentNumber = 247;

            /// <summary>
            /// Property Indexer for AgentSourceDocument
            /// </summary>
            public const int AgentSourceDocument = 248;

            /// <summary>
            /// Property Indexer for AgentIsFromMultipleDocuments
            /// </summary>
            public const int AgentIsFromMultipleDocuments = 249;

            /// <summary>
            /// Property Indexer for AgentDate
            /// </summary>
            public const int AgentDate = 250;

            /// <summary>
            /// Property Indexer for AgentFiscalYear
            /// </summary>
            public const int AgentFiscalYear = 251;

            /// <summary>
            /// Property Indexer for AgentFiscalPeriod
            /// </summary>
            public const int AgentFiscalPeriod = 252;

            /// <summary>
            /// Property Indexer for AgentDescription
            /// </summary>
            public const int AgentDescription = 253;

            /// <summary>
            /// Property Indexer for AgentReference
            /// </summary>
            public const int AgentReference = 254;

            /// <summary>
            /// Property Indexer for TaxReportingCurrency
            /// </summary>
            public const int TaxReportingCurrency = 255;

            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate
            /// </summary>
            public const int TaxReportingExchangeRate = 256;

            /// <summary>
            /// Property Indexer for TaxReportingRateSpread
            /// </summary>
            public const int TaxReportingRateSpread = 257;

            /// <summary>
            /// Property Indexer for TaxReportingRateType
            /// </summary>
            public const int TaxReportingRateType = 258;

            /// <summary>
            /// Property Indexer for TaxReportingRateMatchType
            /// </summary>
            public const int TaxReportingRateMatchType = 259;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate
            /// </summary>
            public const int TaxReportingRateDate = 260;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperation
            /// </summary>
            public const int TaxReportingRateOperation = 261;

            /// <summary>
            /// Property Indexer for TaxReportingRateOverridden
            /// </summary>
            public const int TaxReportingRateOverridden = 262;

            /// <summary>
            /// Property Indexer for TaxReportingDecimalPlaces
            /// </summary>
            public const int TaxReportingDecimalPlaces = 263;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 264;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 265;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 266;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 267;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 268;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 269;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 270;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 271;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 272;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 273;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 274;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 275;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 276;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 277;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 278;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 279;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 280;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 281;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 282;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 283;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 284;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 285;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 286;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 287;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 288;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 289;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 290;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 291;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 292;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 293;

            /// <summary>
            /// Property Indexer for TaxReportingExchRateExists
            /// </summary>
            public const int TaxReportingExchRateExists = 294;

            /// <summary>
            /// Property Indexer for DerivedTaxReportingExchRate
            /// </summary>
            public const int DerivedTaxReportingExchRate = 295;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyDesc
            /// </summary>
            public const int TaxReportingCurrencyDesc = 296;

            /// <summary>
            /// Property Indexer for TaxReportingRateTypeDesc
            /// </summary>
            public const int TaxReportingRateTypeDesc = 297;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 298;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 299;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 300;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 301;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 302;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 303;

            /// <summary>
            /// Property Indexer for TaxBase1Sum
            /// </summary>
            public const int TaxBase1Sum = 304;

            /// <summary>
            /// Property Indexer for TaxBase2Sum
            /// </summary>
            public const int TaxBase2Sum = 305;

            /// <summary>
            /// Property Indexer for TaxBase3Sum
            /// </summary>
            public const int TaxBase3Sum = 306;

            /// <summary>
            /// Property Indexer for TaxBase4Sum
            /// </summary>
            public const int TaxBase4Sum = 307;

            /// <summary>
            /// Property Indexer for TaxBase5Sum
            /// </summary>
            public const int TaxBase5Sum = 308;

            /// <summary>
            /// Property Indexer for TaxAmount1Sum
            /// </summary>
            public const int TaxAmount1Sum = 309;

            /// <summary>
            /// Property Indexer for TaxAmount2Sum
            /// </summary>
            public const int TaxAmount2Sum = 310;

            /// <summary>
            /// Property Indexer for TaxAmount3Sum
            /// </summary>
            public const int TaxAmount3Sum = 311;

            /// <summary>
            /// Property Indexer for TaxAmount4Sum
            /// </summary>
            public const int TaxAmount4Sum = 312;

            /// <summary>
            /// Property Indexer for TaxAmount5Sum
            /// </summary>
            public const int TaxAmount5Sum = 313;

            /// <summary>
            /// Property Indexer for TaxExcluded1Sum
            /// </summary>
            public const int TaxExcluded1Sum = 314;

            /// <summary>
            /// Property Indexer for TaxExcluded2Sum
            /// </summary>
            public const int TaxExcluded2Sum = 315;

            /// <summary>
            /// Property Indexer for TaxExcluded3Sum
            /// </summary>
            public const int TaxExcluded3Sum = 316;

            /// <summary>
            /// Property Indexer for TaxExcluded4Sum
            /// </summary>
            public const int TaxExcluded4Sum = 317;

            /// <summary>
            /// Property Indexer for TaxExcluded5Sum
            /// </summary>
            public const int TaxExcluded5Sum = 318;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1Sum
            /// </summary>
            public const int TaxReportingAmount1Sum = 319;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2Sum
            /// </summary>
            public const int TaxReportingAmount2Sum = 320;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3Sum
            /// </summary>
            public const int TaxReportingAmount3Sum = 321;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4Sum
            /// </summary>
            public const int TaxReportingAmount4Sum = 322;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5Sum
            /// </summary>
            public const int TaxReportingAmount5Sum = 323;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded1Sum
            /// </summary>
            public const int TaxReportingIncluded1Sum = 324;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded2Sum
            /// </summary>
            public const int TaxReportingIncluded2Sum = 325;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded3Sum
            /// </summary>
            public const int TaxReportingIncluded3Sum = 326;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded4Sum
            /// </summary>
            public const int TaxReportingIncluded4Sum = 327;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded5Sum
            /// </summary>
            public const int TaxReportingIncluded5Sum = 328;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded1Sum
            /// </summary>
            public const int TaxReportingExcluded1Sum = 329;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded2Sum
            /// </summary>
            public const int TaxReportingExcluded2Sum = 330;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded3Sum
            /// </summary>
            public const int TaxReportingExcluded3Sum = 331;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded4Sum
            /// </summary>
            public const int TaxReportingExcluded4Sum = 332;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded5Sum
            /// </summary>
            public const int TaxReportingExcluded5Sum = 333;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount1Sum
            /// </summary>
            public const int TaxRepAllocatedAmount1Sum = 334;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount2Sum
            /// </summary>
            public const int TaxRepAllocatedAmount2Sum = 335;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount3Sum
            /// </summary>
            public const int TaxRepAllocatedAmount3Sum = 336;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount4Sum
            /// </summary>
            public const int TaxRepAllocatedAmount4Sum = 337;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount5Sum
            /// </summary>
            public const int TaxRepAllocatedAmount5Sum = 338;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt1Sum
            /// </summary>
            public const int TaxRepRecoverableAmt1Sum = 339;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt2Sum
            /// </summary>
            public const int TaxRepRecoverableAmt2Sum = 340;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt3Sum
            /// </summary>
            public const int TaxRepRecoverableAmt3Sum = 341;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt4Sum
            /// </summary>
            public const int TaxRepRecoverableAmt4Sum = 342;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt5Sum
            /// </summary>
            public const int TaxRepRecoverableAmt5Sum = 343;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount1Sum
            /// </summary>
            public const int TaxRepExpenseAmount1Sum = 344;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount2Sum
            /// </summary>
            public const int TaxRepExpenseAmount2Sum = 345;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount3Sum
            /// </summary>
            public const int TaxRepExpenseAmount3Sum = 346;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount4Sum
            /// </summary>
            public const int TaxRepExpenseAmount4Sum = 347;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount5Sum
            /// </summary>
            public const int TaxRepExpenseAmount5Sum = 348;

            /// <summary>
            /// Property Indexer for VendorAccountSet
            /// </summary>
            public const int VendorAccountSet = 349;

            /// <summary>
            /// Property Indexer for VendorAccountSetDescription
            /// </summary>
            public const int VendorAccountSetDescription = 350;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 351;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 352;

            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 353;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 354;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 355;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 356;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 357;
            /// <summary>
            /// Property Indexer for customer detail tax amount 1
            /// </summary>
            public const int CustomerDetailTaxAmount1 = 358;
            /// <summary>
            /// Property Indexer for customer detail tax amount 2
            /// </summary>
            public const int CustomerDetailTaxAmount2 = 359;
            /// <summary>
            /// Property Indexer for customer detail tax amount 3
            /// </summary>
            public const int CustomerDetailTaxAmount3 = 360;
            /// <summary>
            /// Property Indexer for customer detail tax amount 4
            /// </summary>
            public const int CustomerDetailTaxAmount4 = 361;
            /// <summary>
            /// Property Indexer for customer detail tax amount 5
            /// </summary>
            public const int CustomerDetailTaxAmount5 = 362;

            /// <summary>
            /// Property Indexer for customer tax amount 1
            /// </summary>
            public const int CustomerTaxAmount1 = 368;
            /// <summary>
            /// Property Indexer for customer tax amount 2
            /// </summary>
            public const int CustomerTaxAmount2 = 369;
            /// <summary>
            /// Property Indexer for customer tax amount 3
            /// </summary>
            public const int CustomerTaxAmount3 = 370;
            /// <summary>
            /// Property Indexer for customer tax amount 4
            /// </summary>
            public const int CustomerTaxAmount4 = 371;
            /// <summary>
            /// Property Indexer for customer tax amount 5
            /// </summary>
            public const int CustomerTaxAmount5 = 372;
            /// <summary>
            /// Property Indexer for customer tax amount
            /// </summary>
            public const int CustomerTaxAmount = 373;
            /// <summary>
            /// Property Indexer for Excluded Tax Less Reverse Charge
            /// </summary>
            public const int ExcludedTaxLessReverseCharge = 374;
        }
        #endregion

        #region Keys

        /// <summary>
        /// Order Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Order Uniquifier Key
            /// </summary>
            public const int PurchaseOrderSequenceKey = 0;

            /// <summary>
            /// Order Number Key
            /// </summary>
            public const int PurchaseOrderNumber = 1;
        }

        #endregion
    }
}
