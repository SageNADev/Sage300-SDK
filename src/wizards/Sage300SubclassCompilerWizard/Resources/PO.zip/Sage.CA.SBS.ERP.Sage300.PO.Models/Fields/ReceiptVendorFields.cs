// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptVendor Constants
    /// </summary>
    public partial class ReceiptVendor
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0718";
        public const string ImportEntityName = "PO0468";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
                    {"VDCODE", "Vendor"},
                    {"COSTS", "Costs"},
					{"VDNAME", "Name"},
                    {"VDADDRESS1", "Address1"},
                    {"VDADDRESS2", "Address2"},
                    {"VDADDRESS3", "Address3"},
                    {"VDADDRESS4", "Address4"},
                    {"VDCITY", "City"},
                    {"VDSTATE", "StateProvince"},
                    {"VDZIP", "ZipPostalCode"},
                    {"VDCOUNTRY", "Country"},
                    {"VDPHONE", "PhoneNumber"},
                    {"VDFAX", "FaxNumber"},
                    {"VDCONTACT", "Contact"},
                    {"TERMSCODE", "TermsCode"},
                    {"CURRENCY", "Currency"},
                    {"RATE", "ExchangeRate"},
                    {"RATETYPE", "RateType"},
                    {"RATEDATE", "RateDate"},
                    {"TAXGROUP", "TaxGroup"},
                    {"TXINCLUDED", "TaxIncluded"},
                    {"TAXAMOUNT", "TotalTax"},
                    {"VDEMAIL", "Email"},
                    {"VDPHONEC", "ContactPhone"},
                    {"VDFAXC", "ContactFax"},
                    {"VDEMAILC", "ContactEmail"},
                    {"TERMSCODED", "TermsCodeDescription"},
                    {"RATETYPED", "RateTypeDescription"},
                    {"TAXGROUPD", "TaxGroupDescription"},
                    {"VDACCTSET", "VendorAccountSet"},
                    {"VDACCTDESC", "VendorAccountSetDescription"},
                    {"TRCURRENCY","TaxReportingCurrency"},
                    {"RATERC","TaxReportingExchangeRate"},
                    {"RATEDATERC","TaxReportingRateDate"},
                    {"RATETYPERC","TaxReportingRateType"},
                    { Fields.HasRetainage, "HasRetainage" },
                    { Fields.RetainageTermsCode, "RetainageTermsCode" },
                    { Fields.RetainageExchangeRate, "RetainageExchangeRate" }
				};
            }
        }

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of ReceiptVendor Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VDCODE";

            /// <summary>
            /// Property for Costs
            /// </summary>
            public const string Costs = "COSTS";

            /// <summary>
            /// Property for NumberOfCostsProrated
            /// </summary>
            public const string NumberOfCostsProrated = "COSTSPRORA";

            /// <summary>
            /// Property for CostsComplete
            /// </summary>
            public const string CostsComplete = "COSTSCMPL";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for AutoTaxCalculationOnSave
            /// </summary>
            public const string AutoTaxCalculationOnSave = "TAXAUTOCAL";

            /// <summary>
            /// Property for Invoiced
            /// </summary>
            public const string Invoiced = "ISINVOICED";

            /// <summary>
            /// Property for InvoiceNumber
            /// </summary>
            public const string InvoiceNumber = "INVNUMBER";

            /// <summary>
            /// Property for VendorExists
            /// </summary>
            public const string VendorExists = "VDEXISTS";

            /// <summary>
            /// Property for Name
            /// </summary>
            public const string Name = "VDNAME";

            /// <summary>
            /// Property for Address1
            /// </summary>
            public const string Address1 = "VDADDRESS1";

            /// <summary>
            /// Property for Address2
            /// </summary>
            public const string Address2 = "VDADDRESS2";

            /// <summary>
            /// Property for Address3
            /// </summary>
            public const string Address3 = "VDADDRESS3";

            /// <summary>
            /// Property for Address4
            /// </summary>
            public const string Address4 = "VDADDRESS4";

            /// <summary>
            /// Property for City
            /// </summary>
            public const string City = "VDCITY";

            /// <summary>
            /// Property for StateProvince
            /// </summary>
            public const string StateProvince = "VDSTATE";

            /// <summary>
            /// Property for ZipPostalCode
            /// </summary>
            public const string ZipPostalCode = "VDZIP";

            /// <summary>
            /// Property for Country
            /// </summary>
            public const string Country = "VDCOUNTRY";

            /// <summary>
            /// Property for PhoneNumber
            /// </summary>
            public const string PhoneNumber = "VDPHONE";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "VDFAX";

            /// <summary>
            /// Property for Contact
            /// </summary>
            public const string Contact = "VDCONTACT";

            /// <summary>
            /// Property for TermsCode
            /// </summary>
            public const string TermsCode = "TERMSCODE";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for ExchangeRate
            /// </summary>
            public const string ExchangeRate = "RATE";

            /// <summary>
            /// Property for RateSpread
            /// </summary>
            public const string RateSpread = "SPREAD";

            /// <summary>
            /// Property for RateType
            /// </summary>
            public const string RateType = "RATETYPE";

            /// <summary>
            /// Property for RateMatchType
            /// </summary>
            public const string RateMatchType = "RATEMATCH";

            /// <summary>
            /// Property for RateDate
            /// </summary>
            public const string RateDate = "RATEDATE";

            /// <summary>
            /// Property for RateOperation
            /// </summary>
            public const string RateOperation = "RATEOPER";

            /// <summary>
            /// Property for RateOverridden
            /// </summary>
            public const string RateOverridden = "RATEOVER";

            /// <summary>
            /// Property for DecimalPlaces
            /// </summary>
            public const string DecimalPlaces = "SCURNDECML";

            /// <summary>
            /// Property for Total
            /// </summary>
            public const string Total = "DOCTOTAL";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for TaxGroup
            /// </summary>
            public const string TaxGroup = "TAXGROUP";

            /// <summary>
            /// Property for TaxAuthority1
            /// </summary>
            public const string TaxAuthority1 = "TAXAUTH1";

            /// <summary>
            /// Property for TaxAuthority2
            /// </summary>
            public const string TaxAuthority2 = "TAXAUTH2";

            /// <summary>
            /// Property for TaxAuthority3
            /// </summary>
            public const string TaxAuthority3 = "TAXAUTH3";

            /// <summary>
            /// Property for TaxAuthority4
            /// </summary>
            public const string TaxAuthority4 = "TAXAUTH4";

            /// <summary>
            /// Property for TaxAuthority5
            /// </summary>
            public const string TaxAuthority5 = "TAXAUTH5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxBase1
            /// </summary>
            public const string TaxBase1 = "TAXBASE1";

            /// <summary>
            /// Property for TaxBase2
            /// </summary>
            public const string TaxBase2 = "TAXBASE2";

            /// <summary>
            /// Property for TaxBase3
            /// </summary>
            public const string TaxBase3 = "TAXBASE3";

            /// <summary>
            /// Property for TaxBase4
            /// </summary>
            public const string TaxBase4 = "TAXBASE4";

            /// <summary>
            /// Property for TaxBase5
            /// </summary>
            public const string TaxBase5 = "TAXBASE5";

            /// <summary>
            /// Property for IncludedTaxAmount1
            /// </summary>
            public const string IncludedTaxAmount1 = "TXINCLUDE1";

            /// <summary>
            /// Property for IncludedTaxAmount2
            /// </summary>
            public const string IncludedTaxAmount2 = "TXINCLUDE2";

            /// <summary>
            /// Property for IncludedTaxAmount3
            /// </summary>
            public const string IncludedTaxAmount3 = "TXINCLUDE3";

            /// <summary>
            /// Property for IncludedTaxAmount4
            /// </summary>
            public const string IncludedTaxAmount4 = "TXINCLUDE4";

            /// <summary>
            /// Property for IncludedTaxAmount5
            /// </summary>
            public const string IncludedTaxAmount5 = "TXINCLUDE5";

            /// <summary>
            /// Property for ExcludedTaxAmount1
            /// </summary>
            public const string ExcludedTaxAmount1 = "TXEXCLUDE1";

            /// <summary>
            /// Property for ExcludedTaxAmount2
            /// </summary>
            public const string ExcludedTaxAmount2 = "TXEXCLUDE2";

            /// <summary>
            /// Property for ExcludedTaxAmount3
            /// </summary>
            public const string ExcludedTaxAmount3 = "TXEXCLUDE3";

            /// <summary>
            /// Property for ExcludedTaxAmount4
            /// </summary>
            public const string ExcludedTaxAmount4 = "TXEXCLUDE4";

            /// <summary>
            /// Property for ExcludedTaxAmount5
            /// </summary>
            public const string ExcludedTaxAmount5 = "TXEXCLUDE5";

            /// <summary>
            /// Property for TaxAmount1
            /// </summary>
            public const string TaxAmount1 = "TAXAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2
            /// </summary>
            public const string TaxAmount2 = "TAXAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3
            /// </summary>
            public const string TaxAmount3 = "TAXAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4
            /// </summary>
            public const string TaxAmount4 = "TAXAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5
            /// </summary>
            public const string TaxAmount5 = "TAXAMOUNT5";

            /// <summary>
            /// Property for TaxAllocatedAmount1
            /// </summary>
            public const string TaxAllocatedAmount1 = "TXALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2
            /// </summary>
            public const string TaxAllocatedAmount2 = "TXALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3
            /// </summary>
            public const string TaxAllocatedAmount3 = "TXALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4
            /// </summary>
            public const string TaxAllocatedAmount4 = "TXALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5
            /// </summary>
            public const string TaxAllocatedAmount5 = "TXALLOAMT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1
            /// </summary>
            public const string TaxRecoverableAmount1 = "TXRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2
            /// </summary>
            public const string TaxRecoverableAmount2 = "TXRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3
            /// </summary>
            public const string TaxRecoverableAmount3 = "TXRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4
            /// </summary>
            public const string TaxRecoverableAmount4 = "TXRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5
            /// </summary>
            public const string TaxRecoverableAmount5 = "TXRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1
            /// </summary>
            public const string TaxExpenseAmount1 = "TXEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2
            /// </summary>
            public const string TaxExpenseAmount2 = "TXEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3
            /// </summary>
            public const string TaxExpenseAmount3 = "TXEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4
            /// </summary>
            public const string TaxExpenseAmount4 = "TXEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5
            /// </summary>
            public const string TaxExpenseAmount5 = "TXEXPSAMT5";

            /// <summary>
            /// Property for NetOfTax
            /// </summary>
            public const string NetOfTax = "TXBASEALLO";

            /// <summary>
            /// Property for TaxIncluded
            /// </summary>
            public const string TaxIncluded = "TXINCLUDED";

            /// <summary>
            /// Property for TaxExcluded
            /// </summary>
            public const string TaxExcluded = "TXEXCLUDED";

            /// <summary>
            /// Property for TotalTax
            /// </summary>
            public const string TotalTax = "TAXAMOUNT";

            /// <summary>
            /// Property for TotalTaxRecoverable
            /// </summary>
            public const string TotalTaxRecoverable = "TXRECVAMT";

            /// <summary>
            /// Property for TotalTaxExpensed
            /// </summary>
            public const string TotalTaxExpensed = "TXEXPSAMT";

            /// <summary>
            /// Property for TotalTaxAllocated
            /// </summary>
            public const string TotalTaxAllocated = "TXALLOAMT";

            /// <summary>
            /// Property for ConversionSourceAmount
            /// </summary>
            public const string ConversionSourceAmount = "SCAMOUNT";

            /// <summary>
            /// Property for ConversionFunctionalAmount
            /// </summary>
            public const string ConversionFunctionalAmount = "FCAMOUNT";

            /// <summary>
            /// Property for ManualToProrate
            /// </summary>
            public const string ManualToProrate = "MTOPRORATE";

            /// <summary>
            /// Property for TaxLines
            /// </summary>
            public const string TaxLines = "TAXLINES";

            /// <summary>
            /// Property for Completed
            /// </summary>
            public const string Completed = "ISCOMPLETE";

            /// <summary>
            /// Property for DateCompleted
            /// </summary>
            public const string DateCompleted = "DTCOMPLETE";

            /// <summary>
            /// Property for Email
            /// </summary>
            public const string Email = "VDEMAIL";

            /// <summary>
            /// Property for ContactPhone
            /// </summary>
            public const string ContactPhone = "VDPHONEC";

            /// <summary>
            /// Property for ContactFax
            /// </summary>
            public const string ContactFax = "VDFAXC";

            /// <summary>
            /// Property for ContactEmail
            /// </summary>
            public const string ContactEmail = "VDEMAILC";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for JobRelatedCosts
            /// </summary>
            public const string JobRelatedCosts = "JOBCOSTS";

            /// <summary>
            /// Property for CostBillingRatesProrated
            /// </summary>
            public const string CostBillingRatesProrated = "COSTSBLPRO";

            /// <summary>
            /// Property for HasRetainage
            /// </summary>
            public const string HasRetainage = "HASRTG";

            /// <summary>
            /// Property for RetainageExchangeRate
            /// </summary>
            public const string RetainageExchangeRate = "RTGRATE";

            /// <summary>
            /// Property for RetainageTermsCode
            /// </summary>
            public const string RetainageTermsCode = "RTGTERMS";

            /// <summary>
            /// Property for RetainageAmount
            /// </summary>
            public const string RetainageAmount = "RTGAMOUNT";

            /// <summary>
            /// Property for TaxReportingCurrency
            /// </summary>
            public const string TaxReportingCurrency = "TRCURRENCY";

            /// <summary>
            /// Property for TaxReportingExchangeRate
            /// </summary>
            public const string TaxReportingExchangeRate = "RATERC";

            /// <summary>
            /// Property for TaxReportingRateSpread
            /// </summary>
            public const string TaxReportingRateSpread = "SPREADRC";

            /// <summary>
            /// Property for TaxReportingRateType
            /// </summary>
            public const string TaxReportingRateType = "RATETYPERC";

            /// <summary>
            /// Property for TaxReportingRateMatchType
            /// </summary>
            public const string TaxReportingRateMatchType = "RATEMTCHRC";

            /// <summary>
            /// Property for TaxReportingRateDate
            /// </summary>
            public const string TaxReportingRateDate = "RATEDATERC";

            /// <summary>
            /// Property for TaxReportingRateOperation
            /// </summary>
            public const string TaxReportingRateOperation = "RATEOPERRC";

            /// <summary>
            /// Property for TaxReportingRateOverridden
            /// </summary>
            public const string TaxReportingRateOverridden = "RATERCOVER";

            /// <summary>
            /// Property for TaxReportingDecimalPlaces
            /// </summary>
            public const string TaxReportingDecimalPlaces = "RCURNDECML";

            /// <summary>
            /// Property for TaxReportingAmount1
            /// </summary>
            public const string TaxReportingAmount1 = "TARAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2
            /// </summary>
            public const string TaxReportingAmount2 = "TARAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3
            /// </summary>
            public const string TaxReportingAmount3 = "TARAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4
            /// </summary>
            public const string TaxReportingAmount4 = "TARAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5
            /// </summary>
            public const string TaxReportingAmount5 = "TARAMOUNT5";

            /// <summary>
            /// Property for TaxReportingIncludedAmount1
            /// </summary>
            public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncludedAmount2
            /// </summary>
            public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncludedAmount3
            /// </summary>
            public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncludedAmount4
            /// </summary>
            public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncludedAmount5
            /// </summary>
            public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcludedAmount1
            /// </summary>
            public const string TaxReportingExcludedAmount1 = "TREXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcludedAmount2
            /// </summary>
            public const string TaxReportingExcludedAmount2 = "TREXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcludedAmount3
            /// </summary>
            public const string TaxReportingExcludedAmount3 = "TREXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcludedAmount4
            /// </summary>
            public const string TaxReportingExcludedAmount4 = "TREXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcludedAmount5
            /// </summary>
            public const string TaxReportingExcludedAmount5 = "TREXCLUDE5";

            /// <summary>
            /// Property for CurrencyDescription
            /// </summary>
            public const string CurrencyDescription = "CURRENCYD";

            /// <summary>
            /// Property for TermsCodeDescription
            /// </summary>
            public const string TermsCodeDescription = "TERMSCODED";

            /// <summary>
            /// Property for RateTypeDescription
            /// </summary>
            public const string RateTypeDescription = "RATETYPED";

            /// <summary>
            /// Property for TaxGroupDescription
            /// </summary>
            public const string TaxGroupDescription = "TAXGROUPD";

            /// <summary>
            /// Property for TaxClass1Description
            /// </summary>
            public const string TaxClass1Description = "TAXCLASS1D";

            /// <summary>
            /// Property for TaxClass2Description
            /// </summary>
            public const string TaxClass2Description = "TAXCLASS2D";

            /// <summary>
            /// Property for TaxClass3Description
            /// </summary>
            public const string TaxClass3Description = "TAXCLASS3D";

            /// <summary>
            /// Property for TaxClass4Description
            /// </summary>
            public const string TaxClass4Description = "TAXCLASS4D";

            /// <summary>
            /// Property for TaxClass5Description
            /// </summary>
            public const string TaxClass5Description = "TAXCLASS5D";

            /// <summary>
            /// Property for TaxAuthority1Description
            /// </summary>
            public const string TaxAuthority1Description = "TAXAUTH1D";

            /// <summary>
            /// Property for TaxAuthority2Description
            /// </summary>
            public const string TaxAuthority2Description = "TAXAUTH2D";

            /// <summary>
            /// Property for TaxAuthority3Description
            /// </summary>
            public const string TaxAuthority3Description = "TAXAUTH3D";

            /// <summary>
            /// Property for TaxAuthority4Description
            /// </summary>
            public const string TaxAuthority4Description = "TAXAUTH4D";

            /// <summary>
            /// Property for TaxAuthority5Description
            /// </summary>
            public const string TaxAuthority5Description = "TAXAUTH5D";

            /// <summary>
            /// Property for NetOfTaxSum
            /// </summary>
            public const string NetOfTaxSum = "TCBASEALLO";

            /// <summary>
            /// Property for TaxIncluded1Sum
            /// </summary>
            public const string TaxIncluded1Sum = "TCINCLUDE1";

            /// <summary>
            /// Property for TaxIncluded2Sum
            /// </summary>
            public const string TaxIncluded2Sum = "TCINCLUDE2";

            /// <summary>
            /// Property for TaxIncluded3Sum
            /// </summary>
            public const string TaxIncluded3Sum = "TCINCLUDE3";

            /// <summary>
            /// Property for TaxIncluded4Sum
            /// </summary>
            public const string TaxIncluded4Sum = "TCINCLUDE4";

            /// <summary>
            /// Property for TaxIncluded5Sum
            /// </summary>
            public const string TaxIncluded5Sum = "TCINCLUDE5";

            /// <summary>
            /// Property for TaxAllocatedAmount1Sum
            /// </summary>
            public const string TaxAllocatedAmount1Sum = "TCALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2Sum
            /// </summary>
            public const string TaxAllocatedAmount2Sum = "TCALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3Sum
            /// </summary>
            public const string TaxAllocatedAmount3Sum = "TCALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4Sum
            /// </summary>
            public const string TaxAllocatedAmount4Sum = "TCALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5Sum
            /// </summary>
            public const string TaxAllocatedAmount5Sum = "TCALLOAMT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1Sum
            /// </summary>
            public const string TaxRecoverableAmount1Sum = "TCRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2Sum
            /// </summary>
            public const string TaxRecoverableAmount2Sum = "TCRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3Sum
            /// </summary>
            public const string TaxRecoverableAmount3Sum = "TCRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4Sum
            /// </summary>
            public const string TaxRecoverableAmount4Sum = "TCRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5Sum
            /// </summary>
            public const string TaxRecoverableAmount5Sum = "TCRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1Sum
            /// </summary>
            public const string TaxExpenseAmount1Sum = "TCEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2Sum
            /// </summary>
            public const string TaxExpenseAmount2Sum = "TCEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3Sum
            /// </summary>
            public const string TaxExpenseAmount3Sum = "TCEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4Sum
            /// </summary>
            public const string TaxExpenseAmount4Sum = "TCEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5Sum
            /// </summary>
            public const string TaxExpenseAmount5Sum = "TCEXPSAMT5";

            /// <summary>
            /// Property for TotalTaxAllocated1
            /// </summary>
            public const string TotalTaxAllocated1 = "TCALLOAMT";

            /// <summary>
            /// Property for TaxIncluded1
            /// </summary>
            public const string TaxIncluded1 = "TCINCLUDED";

            /// <summary>
            /// Property for TaxExcluded1
            /// </summary>
            public const string TaxExcluded1 = "TCEXCLUDED";

            /// <summary>
            /// Property for TotalUnbalancedTax
            /// </summary>
            public const string TotalUnbalancedTax = "UBALTAXAMT";

            /// <summary>
            /// Property for TotalUnbalancedAllocatedTax
            /// </summary>
            public const string TotalUnbalancedAllocatedTax = "UBALTXALLO";

            /// <summary>
            /// Property for PrimaryNetOfTax
            /// </summary>
            public const string PrimaryNetOfTax = "TPBASEALLO";

            /// <summary>
            /// Property for PrimaryIncludedTaxAmount1
            /// </summary>
            public const string PrimaryIncludedTaxAmount1 = "TPINCLUDE1";

            /// <summary>
            /// Property for PrimaryIncludedTaxAmount2
            /// </summary>
            public const string PrimaryIncludedTaxAmount2 = "TPINCLUDE2";

            /// <summary>
            /// Property for PrimaryIncludedTaxAmount3
            /// </summary>
            public const string PrimaryIncludedTaxAmount3 = "TPINCLUDE3";

            /// <summary>
            /// Property for PrimaryIncludedTaxAmount4
            /// </summary>
            public const string PrimaryIncludedTaxAmount4 = "TPINCLUDE4";

            /// <summary>
            /// Property for PrimaryIncludedTaxAmount5
            /// </summary>
            public const string PrimaryIncludedTaxAmount5 = "TPINCLUDE5";

            /// <summary>
            /// Property for PrimaryTaxAllocatedAmount1
            /// </summary>
            public const string PrimaryTaxAllocatedAmount1 = "TPALLOAMT1";

            /// <summary>
            /// Property for PrimaryTaxAllocatedAmount2
            /// </summary>
            public const string PrimaryTaxAllocatedAmount2 = "TPALLOAMT2";

            /// <summary>
            /// Property for PrimaryTaxAllocatedAmount3
            /// </summary>
            public const string PrimaryTaxAllocatedAmount3 = "TPALLOAMT3";

            /// <summary>
            /// Property for PrimaryTaxAllocatedAmount4
            /// </summary>
            public const string PrimaryTaxAllocatedAmount4 = "TPALLOAMT4";

            /// <summary>
            /// Property for PrimaryTaxAllocatedAmount5
            /// </summary>
            public const string PrimaryTaxAllocatedAmount5 = "TPALLOAMT5";

            /// <summary>
            /// Property for PrimaryTaxRecoverableAmount1
            /// </summary>
            public const string PrimaryTaxRecoverableAmount1 = "TPRECVAMT1";

            /// <summary>
            /// Property for PrimaryTaxRecoverableAmount2
            /// </summary>
            public const string PrimaryTaxRecoverableAmount2 = "TPRECVAMT2";

            /// <summary>
            /// Property for PrimaryTaxRecoverableAmount3
            /// </summary>
            public const string PrimaryTaxRecoverableAmount3 = "TPRECVAMT3";

            /// <summary>
            /// Property for PrimaryTaxRecoverableAmount4
            /// </summary>
            public const string PrimaryTaxRecoverableAmount4 = "TPRECVAMT4";

            /// <summary>
            /// Property for PrimaryTaxRecoverableAmount5
            /// </summary>
            public const string PrimaryTaxRecoverableAmount5 = "TPRECVAMT5";

            /// <summary>
            /// Property for PrimaryTaxExpenseAmount1
            /// </summary>
            public const string PrimaryTaxExpenseAmount1 = "TPEXPSAMT1";

            /// <summary>
            /// Property for PrimaryTaxExpenseAmount2
            /// </summary>
            public const string PrimaryTaxExpenseAmount2 = "TPEXPSAMT2";

            /// <summary>
            /// Property for PrimaryTaxExpenseAmount3
            /// </summary>
            public const string PrimaryTaxExpenseAmount3 = "TPEXPSAMT3";

            /// <summary>
            /// Property for PrimaryTaxExpenseAmount4
            /// </summary>
            public const string PrimaryTaxExpenseAmount4 = "TPEXPSAMT4";

            /// <summary>
            /// Property for PrimaryTaxExpenseAmount5
            /// </summary>
            public const string PrimaryTaxExpenseAmount5 = "TPEXPSAMT5";

            /// <summary>
            /// Property for Amount1
            /// </summary>
            public const string Amount1 = "PAMOUNT";

            /// <summary>
            /// Property for Subtotal
            /// </summary>
            public const string Subtotal = "SUBTOTAL";

            /// <summary>
            /// Property for Vendors
            /// </summary>
            public const string Vendors = "VEND";

            /// <summary>
            /// Property for VendorsCompleted
            /// </summary>
            public const string VendorsCompleted = "VENDCMPL";

            /// <summary>
            /// Property for VendorsInvoiced
            /// </summary>
            public const string VendorsInvoiced = "VENDINVC";

            /// <summary>
            /// Property for TaxcalculationIspending
            /// </summary>
            public const string TaxcalculationIspending = "PENDINGCAL";

            /// <summary>
            /// Property for DocumentLocked
            /// </summary>
            public const string DocumentLocked = "LOCKED";

            /// <summary>
            /// Property for ExchangeRateExists
            /// </summary>
            public const string ExchangeRateExists = "RATEEXISTS";

            /// <summary>
            /// Property for IsThisVendorPrimary
            /// </summary>
            public const string IsThisVendorPrimary = "ISPRIMARY";

            /// <summary>
            /// Property for HasDetails
            /// </summary>
            public const string HasDetails = "HASDETAILS";

            /// <summary>
            /// Property for TaxLines1
            /// </summary>
            public const string TaxLines1 = "PTAXLINES";

            /// <summary>
            /// Property for Command
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for RetainageTermsCodeDescription
            /// </summary>
            public const string RetainageTermsCodeDescription = "RTGTERMSD";

            /// <summary>
            /// Property for PrimaryRetainageAmount
            /// </summary>
            public const string PrimaryRetainageAmount = "PRTGAMOUNT";

            /// <summary>
            /// Property for UnretainedTotal
            /// </summary>
            public const string UnretainedTotal = "URTDTOTAL";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt1
            /// </summary>
            public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt2
            /// </summary>
            public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt3
            /// </summary>
            public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt4
            /// </summary>
            public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt5
            /// </summary>
            public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

            /// <summary>
            /// Property for TaxReportingExpenseAmount1
            /// </summary>
            public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

            /// <summary>
            /// Property for TaxReportingExpenseAmount2
            /// </summary>
            public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

            /// <summary>
            /// Property for TaxReportingExpenseAmount3
            /// </summary>
            public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

            /// <summary>
            /// Property for TaxReportingExpenseAmount4
            /// </summary>
            public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

            /// <summary>
            /// Property for TaxReportingExpenseAmount5
            /// </summary>
            public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount1
            /// </summary>
            public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount2
            /// </summary>
            public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount3
            /// </summary>
            public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount4
            /// </summary>
            public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount5
            /// </summary>
            public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

            /// <summary>
            /// Property for TaxReportingExchRateExists
            /// </summary>
            public const string TaxReportingExchRateExists = "RATERCEXST";

            /// <summary>
            /// Property for DerivedTaxReportingExchRate
            /// </summary>
            public const string DerivedTaxReportingExchRate = "RATERCC";

            /// <summary>
            /// Property for TaxReportingCurrencyDesc
            /// </summary>
            public const string TaxReportingCurrencyDesc = "TRCURRDESC";

            /// <summary>
            /// Property for TaxReportingRateTypeDesc
            /// </summary>
            public const string TaxReportingRateTypeDesc = "RATETYPRCD";

            /// <summary>
            /// Property for TaxReportingTotalAmount
            /// </summary>
            public const string TaxReportingTotalAmount = "TARAMOUNT";

            /// <summary>
            /// Property for TaxReportingIncludedAmount
            /// </summary>
            public const string TaxReportingIncludedAmount = "TRINCLUDED";

            /// <summary>
            /// Property for TaxReportingExcludedAmount
            /// </summary>
            public const string TaxReportingExcludedAmount = "TREXCLUDED";

            /// <summary>
            /// Property for TaxReportingRecoverableAmount
            /// </summary>
            public const string TaxReportingRecoverableAmount = "TRRECVAMT";

            /// <summary>
            /// Property for TaxReportingExpensedAmount
            /// </summary>
            public const string TaxReportingExpensedAmount = "TREXPSAMT";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount
            /// </summary>
            public const string TaxReportingAllocatedAmount = "TRALLOAMT";

            /// <summary>
            /// Property for TaxBase1Sum
            /// </summary>
            public const string TaxBase1Sum = "TACBASE1";

            /// <summary>
            /// Property for TaxBase2Sum
            /// </summary>
            public const string TaxBase2Sum = "TACBASE2";

            /// <summary>
            /// Property for TaxBase3Sum
            /// </summary>
            public const string TaxBase3Sum = "TACBASE3";

            /// <summary>
            /// Property for TaxBase4Sum
            /// </summary>
            public const string TaxBase4Sum = "TACBASE4";

            /// <summary>
            /// Property for TaxBase5Sum
            /// </summary>
            public const string TaxBase5Sum = "TACBASE5";

            /// <summary>
            /// Property for TaxAmount1Sum
            /// </summary>
            public const string TaxAmount1Sum = "TACAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2Sum
            /// </summary>
            public const string TaxAmount2Sum = "TACAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3Sum
            /// </summary>
            public const string TaxAmount3Sum = "TACAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4Sum
            /// </summary>
            public const string TaxAmount4Sum = "TACAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5Sum
            /// </summary>
            public const string TaxAmount5Sum = "TACAMOUNT5";

            /// <summary>
            /// Property for TaxExcluded1Sum
            /// </summary>
            public const string TaxExcluded1Sum = "TCEXCLUDE1";

            /// <summary>
            /// Property for TaxExcluded2Sum
            /// </summary>
            public const string TaxExcluded2Sum = "TCEXCLUDE2";

            /// <summary>
            /// Property for TaxExcluded3Sum
            /// </summary>
            public const string TaxExcluded3Sum = "TCEXCLUDE3";

            /// <summary>
            /// Property for TaxExcluded4Sum
            /// </summary>
            public const string TaxExcluded4Sum = "TCEXCLUDE4";

            /// <summary>
            /// Property for TaxExcluded5Sum
            /// </summary>
            public const string TaxExcluded5Sum = "TCEXCLUDE5";

            /// <summary>
            /// Property for TaxReportingAmount1Sum
            /// </summary>
            public const string TaxReportingAmount1Sum = "TALAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2Sum
            /// </summary>
            public const string TaxReportingAmount2Sum = "TALAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3Sum
            /// </summary>
            public const string TaxReportingAmount3Sum = "TALAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4Sum
            /// </summary>
            public const string TaxReportingAmount4Sum = "TALAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5Sum
            /// </summary>
            public const string TaxReportingAmount5Sum = "TALAMOUNT5";

            /// <summary>
            /// Property for TaxReportingIncluded1Sum
            /// </summary>
            public const string TaxReportingIncluded1Sum = "TLINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncluded2Sum
            /// </summary>
            public const string TaxReportingIncluded2Sum = "TLINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncluded3Sum
            /// </summary>
            public const string TaxReportingIncluded3Sum = "TLINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncluded4Sum
            /// </summary>
            public const string TaxReportingIncluded4Sum = "TLINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncluded5Sum
            /// </summary>
            public const string TaxReportingIncluded5Sum = "TLINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcluded1Sum
            /// </summary>
            public const string TaxReportingExcluded1Sum = "TLEXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcluded2Sum
            /// </summary>
            public const string TaxReportingExcluded2Sum = "TLEXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcluded3Sum
            /// </summary>
            public const string TaxReportingExcluded3Sum = "TLEXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcluded4Sum
            /// </summary>
            public const string TaxReportingExcluded4Sum = "TLEXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcluded5Sum
            /// </summary>
            public const string TaxReportingExcluded5Sum = "TLEXCLUDE5";

            /// <summary>
            /// Property for TaxRepAllocatedAmount1Sum
            /// </summary>
            public const string TaxRepAllocatedAmount1Sum = "TLALLOAMT1";

            /// <summary>
            /// Property for TaxRepAllocatedAmount2Sum
            /// </summary>
            public const string TaxRepAllocatedAmount2Sum = "TLALLOAMT2";

            /// <summary>
            /// Property for TaxRepAllocatedAmount3Sum
            /// </summary>
            public const string TaxRepAllocatedAmount3Sum = "TLALLOAMT3";

            /// <summary>
            /// Property for TaxRepAllocatedAmount4Sum
            /// </summary>
            public const string TaxRepAllocatedAmount4Sum = "TLALLOAMT4";

            /// <summary>
            /// Property for TaxRepAllocatedAmount5Sum
            /// </summary>
            public const string TaxRepAllocatedAmount5Sum = "TLALLOAMT5";

            /// <summary>
            /// Property for TaxRepRecoverableAmt1Sum
            /// </summary>
            public const string TaxRepRecoverableAmt1Sum = "TLRECVAMT1";

            /// <summary>
            /// Property for TaxRepRecoverableAmt2Sum
            /// </summary>
            public const string TaxRepRecoverableAmt2Sum = "TLRECVAMT2";

            /// <summary>
            /// Property for TaxRepRecoverableAmt3Sum
            /// </summary>
            public const string TaxRepRecoverableAmt3Sum = "TLRECVAMT3";

            /// <summary>
            /// Property for TaxRepRecoverableAmt4Sum
            /// </summary>
            public const string TaxRepRecoverableAmt4Sum = "TLRECVAMT4";

            /// <summary>
            /// Property for TaxRepRecoverableAmt5Sum
            /// </summary>
            public const string TaxRepRecoverableAmt5Sum = "TLRECVAMT5";

            /// <summary>
            /// Property for TaxRepExpenseAmount1Sum
            /// </summary>
            public const string TaxRepExpenseAmount1Sum = "TLEXPSAMT1";

            /// <summary>
            /// Property for TaxRepExpenseAmount2Sum
            /// </summary>
            public const string TaxRepExpenseAmount2Sum = "TLEXPSAMT2";

            /// <summary>
            /// Property for TaxRepExpenseAmount3Sum
            /// </summary>
            public const string TaxRepExpenseAmount3Sum = "TLEXPSAMT3";

            /// <summary>
            /// Property for TaxRepExpenseAmount4Sum
            /// </summary>
            public const string TaxRepExpenseAmount4Sum = "TLEXPSAMT4";

            /// <summary>
            /// Property for TaxRepExpenseAmount5Sum
            /// </summary>
            public const string TaxRepExpenseAmount5Sum = "TLEXPSAMT5";

            /// <summary>
            /// Property for PrimaryTaxBase1
            /// </summary>
            public const string PrimaryTaxBase1 = "TAPBASE1";

            /// <summary>
            /// Property for PrimaryTaxBase2
            /// </summary>
            public const string PrimaryTaxBase2 = "TAPBASE2";

            /// <summary>
            /// Property for PrimaryTaxBase3
            /// </summary>
            public const string PrimaryTaxBase3 = "TAPBASE3";

            /// <summary>
            /// Property for PrimaryTaxBase4
            /// </summary>
            public const string PrimaryTaxBase4 = "TAPBASE4";

            /// <summary>
            /// Property for PrimaryTaxBase5
            /// </summary>
            public const string PrimaryTaxBase5 = "TAPBASE5";

            /// <summary>
            /// Property for PrimaryTaxAmount1
            /// </summary>
            public const string PrimaryTaxAmount1 = "TAPAMOUNT1";

            /// <summary>
            /// Property for PrimaryTaxAmount2
            /// </summary>
            public const string PrimaryTaxAmount2 = "TAPAMOUNT2";

            /// <summary>
            /// Property for PrimaryTaxAmount3
            /// </summary>
            public const string PrimaryTaxAmount3 = "TAPAMOUNT3";

            /// <summary>
            /// Property for PrimaryTaxAmount4
            /// </summary>
            public const string PrimaryTaxAmount4 = "TAPAMOUNT4";

            /// <summary>
            /// Property for PrimaryTaxAmount5
            /// </summary>
            public const string PrimaryTaxAmount5 = "TAPAMOUNT5";

            /// <summary>
            /// Property for PrimaryExcludedTaxAmount1
            /// </summary>
            public const string PrimaryExcludedTaxAmount1 = "TPEXCLUDE1";

            /// <summary>
            /// Property for PrimaryExcludedTaxAmount2
            /// </summary>
            public const string PrimaryExcludedTaxAmount2 = "TPEXCLUDE2";

            /// <summary>
            /// Property for PrimaryExcludedTaxAmount3
            /// </summary>
            public const string PrimaryExcludedTaxAmount3 = "TPEXCLUDE3";

            /// <summary>
            /// Property for PrimaryExcludedTaxAmount4
            /// </summary>
            public const string PrimaryExcludedTaxAmount4 = "TPEXCLUDE4";

            /// <summary>
            /// Property for PrimaryExcludedTaxAmount5
            /// </summary>
            public const string PrimaryExcludedTaxAmount5 = "TPEXCLUDE5";

            /// <summary>
            /// Property for PrmTaxRepAmount1
            /// </summary>
            public const string PrmTaxRepAmount1 = "TAMAMOUNT1";

            /// <summary>
            /// Property for PrmTaxRepAmount2
            /// </summary>
            public const string PrmTaxRepAmount2 = "TAMAMOUNT2";

            /// <summary>
            /// Property for PrmTaxRepAmount3
            /// </summary>
            public const string PrmTaxRepAmount3 = "TAMAMOUNT3";

            /// <summary>
            /// Property for PrmTaxRepAmount4
            /// </summary>
            public const string PrmTaxRepAmount4 = "TAMAMOUNT4";

            /// <summary>
            /// Property for PrmTaxRepAmount5
            /// </summary>
            public const string PrmTaxRepAmount5 = "TAMAMOUNT5";

            /// <summary>
            /// Property for PrmTaxRepIncludedAmount1
            /// </summary>
            public const string PrmTaxRepIncludedAmount1 = "TMINCLUDE1";

            /// <summary>
            /// Property for PrmTaxRepIncludedAmount2
            /// </summary>
            public const string PrmTaxRepIncludedAmount2 = "TMINCLUDE2";

            /// <summary>
            /// Property for PrmTaxRepIncludedAmount3
            /// </summary>
            public const string PrmTaxRepIncludedAmount3 = "TMINCLUDE3";

            /// <summary>
            /// Property for PrmTaxRepIncludedAmount4
            /// </summary>
            public const string PrmTaxRepIncludedAmount4 = "TMINCLUDE4";

            /// <summary>
            /// Property for PrmTaxRepIncludedAmount5
            /// </summary>
            public const string PrmTaxRepIncludedAmount5 = "TMINCLUDE5";

            /// <summary>
            /// Property for PrmTaxRepExcludedAmount1
            /// </summary>
            public const string PrmTaxRepExcludedAmount1 = "TMEXCLUDE1";

            /// <summary>
            /// Property for PrmTaxRepExcludedAmount2
            /// </summary>
            public const string PrmTaxRepExcludedAmount2 = "TMEXCLUDE2";

            /// <summary>
            /// Property for PrmTaxRepExcludedAmount3
            /// </summary>
            public const string PrmTaxRepExcludedAmount3 = "TMEXCLUDE3";

            /// <summary>
            /// Property for PrmTaxRepExcludedAmount4
            /// </summary>
            public const string PrmTaxRepExcludedAmount4 = "TMEXCLUDE4";

            /// <summary>
            /// Property for PrmTaxRepExcludedAmount5
            /// </summary>
            public const string PrmTaxRepExcludedAmount5 = "TMEXCLUDE5";

            /// <summary>
            /// Property for PrmTaxRepAllocatedAmount1
            /// </summary>
            public const string PrmTaxRepAllocatedAmount1 = "TMALLOAMT1";

            /// <summary>
            /// Property for PrmTaxRepAllocatedAmount2
            /// </summary>
            public const string PrmTaxRepAllocatedAmount2 = "TMALLOAMT2";

            /// <summary>
            /// Property for PrmTaxRepAllocatedAmount3
            /// </summary>
            public const string PrmTaxRepAllocatedAmount3 = "TMALLOAMT3";

            /// <summary>
            /// Property for PrmTaxRepAllocatedAmount4
            /// </summary>
            public const string PrmTaxRepAllocatedAmount4 = "TMALLOAMT4";

            /// <summary>
            /// Property for PrmTaxRepAllocatedAmount5
            /// </summary>
            public const string PrmTaxRepAllocatedAmount5 = "TMALLOAMT5";

            /// <summary>
            /// Property for PrmTaxRepRecoverableAmt1
            /// </summary>
            public const string PrmTaxRepRecoverableAmt1 = "TMRECVAMT1";

            /// <summary>
            /// Property for PrmTaxRepRecoverableAmt2
            /// </summary>
            public const string PrmTaxRepRecoverableAmt2 = "TMRECVAMT2";

            /// <summary>
            /// Property for PrmTaxRepRecoverableAmt3
            /// </summary>
            public const string PrmTaxRepRecoverableAmt3 = "TMRECVAMT3";

            /// <summary>
            /// Property for PrmTaxRepRecoverableAmt4
            /// </summary>
            public const string PrmTaxRepRecoverableAmt4 = "TMRECVAMT4";

            /// <summary>
            /// Property for PrmTaxRepRecoverableAmt5
            /// </summary>
            public const string PrmTaxRepRecoverableAmt5 = "TMRECVAMT5";

            /// <summary>
            /// Property for PrmTaxRepExpenseAmount1
            /// </summary>
            public const string PrmTaxRepExpenseAmount1 = "TMEXPSAMT1";

            /// <summary>
            /// Property for PrmTaxRepExpenseAmount2
            /// </summary>
            public const string PrmTaxRepExpenseAmount2 = "TMEXPSAMT2";

            /// <summary>
            /// Property for PrmTaxRepExpenseAmount3
            /// </summary>
            public const string PrmTaxRepExpenseAmount3 = "TMEXPSAMT3";

            /// <summary>
            /// Property for PrmTaxRepExpenseAmount4
            /// </summary>
            public const string PrmTaxRepExpenseAmount4 = "TMEXPSAMT4";

            /// <summary>
            /// Property for PrmTaxRepExpenseAmount5
            /// </summary>
            public const string PrmTaxRepExpenseAmount5 = "TMEXPSAMT5";

            /// <summary>
            /// Property for RetainageTaxBase1
            /// </summary>
            public const string RetainageTaxBase1 = "RAXBASE1";

            /// <summary>
            /// Property for RetainageTaxBase2
            /// </summary>
            public const string RetainageTaxBase2 = "RAXBASE2";

            /// <summary>
            /// Property for RetainageTaxBase3
            /// </summary>
            public const string RetainageTaxBase3 = "RAXBASE3";

            /// <summary>
            /// Property for RetainageTaxBase4
            /// </summary>
            public const string RetainageTaxBase4 = "RAXBASE4";

            /// <summary>
            /// Property for RetainageTaxBase5
            /// </summary>
            public const string RetainageTaxBase5 = "RAXBASE5";

            /// <summary>
            /// Property for RetainageTaxAmount1
            /// </summary>
            public const string RetainageTaxAmount1 = "RAXAMOUNT1";

            /// <summary>
            /// Property for RetainageTaxAmount2
            /// </summary>
            public const string RetainageTaxAmount2 = "RAXAMOUNT2";

            /// <summary>
            /// Property for RetainageTaxAmount3
            /// </summary>
            public const string RetainageTaxAmount3 = "RAXAMOUNT3";

            /// <summary>
            /// Property for RetainageTaxAmount4
            /// </summary>
            public const string RetainageTaxAmount4 = "RAXAMOUNT4";

            /// <summary>
            /// Property for RetainageTaxAmount5
            /// </summary>
            public const string RetainageTaxAmount5 = "RAXAMOUNT5";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt1
            /// </summary>
            public const string RetainageTaxRecoverableAmt1 = "RXRECVAMT1";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt2
            /// </summary>
            public const string RetainageTaxRecoverableAmt2 = "RXRECVAMT2";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt3
            /// </summary>
            public const string RetainageTaxRecoverableAmt3 = "RXRECVAMT3";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt4
            /// </summary>
            public const string RetainageTaxRecoverableAmt4 = "RXRECVAMT4";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt5
            /// </summary>
            public const string RetainageTaxRecoverableAmt5 = "RXRECVAMT5";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount1
            /// </summary>
            public const string RetainageTaxExpenseAmount1 = "RXEXPSAMT1";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount2
            /// </summary>
            public const string RetainageTaxExpenseAmount2 = "RXEXPSAMT2";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount3
            /// </summary>
            public const string RetainageTaxExpenseAmount3 = "RXEXPSAMT3";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount4
            /// </summary>
            public const string RetainageTaxExpenseAmount4 = "RXEXPSAMT4";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount5
            /// </summary>
            public const string RetainageTaxExpenseAmount5 = "RXEXPSAMT5";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount1
            /// </summary>
            public const string RetainageTaxAllocatedAmount1 = "RXALLOAMT1";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount2
            /// </summary>
            public const string RetainageTaxAllocatedAmount2 = "RXALLOAMT2";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount3
            /// </summary>
            public const string RetainageTaxAllocatedAmount3 = "RXALLOAMT3";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount4
            /// </summary>
            public const string RetainageTaxAllocatedAmount4 = "RXALLOAMT4";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount5
            /// </summary>
            public const string RetainageTaxAllocatedAmount5 = "RXALLOAMT5";

            /// <summary>
            /// Property for WarnOnRetainageTaxShift
            /// </summary>
            public const string WarnOnRetainageTaxShift = "RTGTXSHIFT";

            /// <summary>
            /// Property for RetainageTaxTotalAmount
            /// </summary>
            public const string RetainageTaxTotalAmount = "RAXAMOUNT";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt1 = "TXRXAMT1";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt2 = "TXRXAMT2";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt3 = "TXRXAMT3";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt4 = "TXRXAMT4";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt5 = "TXRXAMT5";

            /// <summary>
            /// Property for RetainageTaxBase1Sum
            /// </summary>
            public const string RetainageTaxBase1Sum = "RACBASE1";

            /// <summary>
            /// Property for RetainageTaxBase2Sum
            /// </summary>
            public const string RetainageTaxBase2Sum = "RACBASE2";

            /// <summary>
            /// Property for RetainageTaxBase3Sum
            /// </summary>
            public const string RetainageTaxBase3Sum = "RACBASE3";

            /// <summary>
            /// Property for RetainageTaxBase4Sum
            /// </summary>
            public const string RetainageTaxBase4Sum = "RACBASE4";

            /// <summary>
            /// Property for RetainageTaxBase5Sum
            /// </summary>
            public const string RetainageTaxBase5Sum = "RACBASE5";

            /// <summary>
            /// Property for RetainageTaxAmount1Sum
            /// </summary>
            public const string RetainageTaxAmount1Sum = "RACAMOUNT1";

            /// <summary>
            /// Property for RetainageTaxAmount2Sum
            /// </summary>
            public const string RetainageTaxAmount2Sum = "RACAMOUNT2";

            /// <summary>
            /// Property for RetainageTaxAmount3Sum
            /// </summary>
            public const string RetainageTaxAmount3Sum = "RACAMOUNT3";

            /// <summary>
            /// Property for RetainageTaxAmount4Sum
            /// </summary>
            public const string RetainageTaxAmount4Sum = "RACAMOUNT4";

            /// <summary>
            /// Property for RetainageTaxAmount5Sum
            /// </summary>
            public const string RetainageTaxAmount5Sum = "RACAMOUNT5";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt1Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt1Sum = "RCRECVAMT1";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt2Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt2Sum = "RCRECVAMT2";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt3Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt3Sum = "RCRECVAMT3";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt4Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt4Sum = "RCRECVAMT4";

            /// <summary>
            /// Property for RtgTaxRecoverableAmt5Sum
            /// </summary>
            public const string RtgTaxRecoverableAmt5Sum = "RCRECVAMT5";

            /// <summary>
            /// Property for RtgTaxExpenseAmount1Sum
            /// </summary>
            public const string RtgTaxExpenseAmount1Sum = "RCEXPSAMT1";

            /// <summary>
            /// Property for RtgTaxExpenseAmount2Sum
            /// </summary>
            public const string RtgTaxExpenseAmount2Sum = "RCEXPSAMT2";

            /// <summary>
            /// Property for RtgTaxExpenseAmount3Sum
            /// </summary>
            public const string RtgTaxExpenseAmount3Sum = "RCEXPSAMT3";

            /// <summary>
            /// Property for RtgTaxExpenseAmount4Sum
            /// </summary>
            public const string RtgTaxExpenseAmount4Sum = "RCEXPSAMT4";

            /// <summary>
            /// Property for RtgTaxExpenseAmount5Sum
            /// </summary>
            public const string RtgTaxExpenseAmount5Sum = "RCEXPSAMT5";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount1Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount1Sum = "RCALLOAMT1";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount2Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount2Sum = "RCALLOAMT2";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount3Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount3Sum = "RCALLOAMT3";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount4Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount4Sum = "RCALLOAMT4";

            /// <summary>
            /// Property for RtgTaxAllocatedAmount5Sum
            /// </summary>
            public const string RtgTaxAllocatedAmount5Sum = "RCALLOAMT5";

            /// <summary>
            /// Property for PrimaryRetainageTaxBase1
            /// </summary>
            public const string PrimaryRetainageTaxBase1 = "RAPBASE1";

            /// <summary>
            /// Property for PrimaryRetainageTaxBase2
            /// </summary>
            public const string PrimaryRetainageTaxBase2 = "RAPBASE2";

            /// <summary>
            /// Property for PrimaryRetainageTaxBase3
            /// </summary>
            public const string PrimaryRetainageTaxBase3 = "RAPBASE3";

            /// <summary>
            /// Property for PrimaryRetainageTaxBase4
            /// </summary>
            public const string PrimaryRetainageTaxBase4 = "RAPBASE4";

            /// <summary>
            /// Property for PrimaryRetainageTaxBase5
            /// </summary>
            public const string PrimaryRetainageTaxBase5 = "RAPBASE5";

            /// <summary>
            /// Property for PrimaryRetainageTaxAmount1
            /// </summary>
            public const string PrimaryRetainageTaxAmount1 = "RAPAMOUNT1";

            /// <summary>
            /// Property for PrimaryRetainageTaxAmount2
            /// </summary>
            public const string PrimaryRetainageTaxAmount2 = "RAPAMOUNT2";

            /// <summary>
            /// Property for PrimaryRetainageTaxAmount3
            /// </summary>
            public const string PrimaryRetainageTaxAmount3 = "RAPAMOUNT3";

            /// <summary>
            /// Property for PrimaryRetainageTaxAmount4
            /// </summary>
            public const string PrimaryRetainageTaxAmount4 = "RAPAMOUNT4";

            /// <summary>
            /// Property for PrimaryRetainageTaxAmount5
            /// </summary>
            public const string PrimaryRetainageTaxAmount5 = "RAPAMOUNT5";

            /// <summary>
            /// Property for PrmRtgTaxRecoverableAmt1
            /// </summary>
            public const string PrmRtgTaxRecoverableAmt1 = "RPRECVAMT1";

            /// <summary>
            /// Property for PrmRtgTaxRecoverableAmt2
            /// </summary>
            public const string PrmRtgTaxRecoverableAmt2 = "RPRECVAMT2";

            /// <summary>
            /// Property for PrmRtgTaxRecoverableAmt3
            /// </summary>
            public const string PrmRtgTaxRecoverableAmt3 = "RPRECVAMT3";

            /// <summary>
            /// Property for PrmRtgTaxRecoverableAmt4
            /// </summary>
            public const string PrmRtgTaxRecoverableAmt4 = "RPRECVAMT4";

            /// <summary>
            /// Property for PrmRtgTaxRecoverableAmt5
            /// </summary>
            public const string PrmRtgTaxRecoverableAmt5 = "RPRECVAMT5";

            /// <summary>
            /// Property for PrmRtgTaxExpenseAmount1
            /// </summary>
            public const string PrmRtgTaxExpenseAmount1 = "RPEXPSAMT1";

            /// <summary>
            /// Property for PrmRtgTaxExpenseAmount2
            /// </summary>
            public const string PrmRtgTaxExpenseAmount2 = "RPEXPSAMT2";

            /// <summary>
            /// Property for PrmRtgTaxExpenseAmount3
            /// </summary>
            public const string PrmRtgTaxExpenseAmount3 = "RPEXPSAMT3";

            /// <summary>
            /// Property for PrmRtgTaxExpenseAmount4
            /// </summary>
            public const string PrmRtgTaxExpenseAmount4 = "RPEXPSAMT4";

            /// <summary>
            /// Property for PrmRtgTaxExpenseAmount5
            /// </summary>
            public const string PrmRtgTaxExpenseAmount5 = "RPEXPSAMT5";

            /// <summary>
            /// Property for PrmRtgTaxAllocatedAmount1
            /// </summary>
            public const string PrmRtgTaxAllocatedAmount1 = "RPALLOAMT1";

            /// <summary>
            /// Property for PrmRtgTaxAllocatedAmount2
            /// </summary>
            public const string PrmRtgTaxAllocatedAmount2 = "RPALLOAMT2";

            /// <summary>
            /// Property for PrmRtgTaxAllocatedAmount3
            /// </summary>
            public const string PrmRtgTaxAllocatedAmount3 = "RPALLOAMT3";

            /// <summary>
            /// Property for PrmRtgTaxAllocatedAmount4
            /// </summary>
            public const string PrmRtgTaxAllocatedAmount4 = "RPALLOAMT4";

            /// <summary>
            /// Property for PrmRtgTaxAllocatedAmount5
            /// </summary>
            public const string PrmRtgTaxAllocatedAmount5 = "RPALLOAMT5";

            /// <summary>
            /// Property for VendorAccountSet
            /// </summary>
            public const string VendorAccountSet = "VDACCTSET";

            /// <summary>
            /// Property for VendorAccountSetDescription
            /// </summary>
            public const string VendorAccountSetDescription = "VDACCTDESC";

            /// <summary>
            /// Property for Vendor Import Export
            /// </summary>
            public const string VendorImportExport = "VDIMPEXP";

        }
        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ReceiptVendor Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 2;

            /// <summary>
            /// Property Indexer for Costs
            /// </summary>
            public const int Costs = 3;

            /// <summary>
            /// Property Indexer for NumberOfCostsProrated
            /// </summary>
            public const int NumberOfCostsProrated = 4;

            /// <summary>
            /// Property Indexer for CostsComplete
            /// </summary>
            public const int CostsComplete = 5;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 6;

            /// <summary>
            /// Property Indexer for AutoTaxCalculationOnSave
            /// </summary>
            public const int AutoTaxCalculationOnSave = 7;

            /// <summary>
            /// Property Indexer for Invoiced
            /// </summary>
            public const int Invoiced = 8;

            /// <summary>
            /// Property Indexer for InvoiceNumber
            /// </summary>
            public const int InvoiceNumber = 9;

            /// <summary>
            /// Property Indexer for VendorExists
            /// </summary>
            public const int VendorExists = 10;

            /// <summary>
            /// Property Indexer for Name
            /// </summary>
            public const int Name = 11;

            /// <summary>
            /// Property Indexer for Address1
            /// </summary>
            public const int Address1 = 12;

            /// <summary>
            /// Property Indexer for Address2
            /// </summary>
            public const int Address2 = 13;

            /// <summary>
            /// Property Indexer for Address3
            /// </summary>
            public const int Address3 = 14;

            /// <summary>
            /// Property Indexer for Address4
            /// </summary>
            public const int Address4 = 15;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 16;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 17;

            /// <summary>
            /// Property Indexer for ZipPostalCode
            /// </summary>
            public const int ZipPostalCode = 18;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 19;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 20;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 21;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 22;

            /// <summary>
            /// Property Indexer for TermsCode
            /// </summary>
            public const int TermsCode = 23;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 24;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 25;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 26;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 27;

            /// <summary>
            /// Property Indexer for RateMatchType
            /// </summary>
            public const int RateMatchType = 28;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 29;

            /// <summary>
            /// Property Indexer for RateOperation
            /// </summary>
            public const int RateOperation = 30;

            /// <summary>
            /// Property Indexer for RateOverridden
            /// </summary>
            public const int RateOverridden = 31;

            /// <summary>
            /// Property Indexer for DecimalPlaces
            /// </summary>
            public const int DecimalPlaces = 32;

            /// <summary>
            /// Property Indexer for Total
            /// </summary>
            public const int Total = 33;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 34;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 35;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 36;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 37;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 38;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 39;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 40;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 41;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 42;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 43;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 44;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 45;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 46;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 47;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 48;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 49;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 50;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 51;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 52;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 53;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 54;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 55;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 56;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 57;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 58;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 59;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 60;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 61;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 62;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 63;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 64;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 65;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 66;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 67;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 68;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 69;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 70;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 71;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 72;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 73;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 74;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 75;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 76;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 77;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 78;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 79;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 80;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 81;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 82;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 83;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 84;

            /// <summary>
            /// Property Indexer for TotalTaxRecoverable
            /// </summary>
            public const int TotalTaxRecoverable = 85;

            /// <summary>
            /// Property Indexer for TotalTaxExpensed
            /// </summary>
            public const int TotalTaxExpensed = 86;

            /// <summary>
            /// Property Indexer for TotalTaxAllocated
            /// </summary>
            public const int TotalTaxAllocated = 87;

            /// <summary>
            /// Property Indexer for ConversionSourceAmount
            /// </summary>
            public const int ConversionSourceAmount = 88;

            /// <summary>
            /// Property Indexer for ConversionFunctionalAmount
            /// </summary>
            public const int ConversionFunctionalAmount = 89;

            /// <summary>
            /// Property Indexer for ManualToProrate
            /// </summary>
            public const int ManualToProrate = 90;

            /// <summary>
            /// Property Indexer for TaxLines
            /// </summary>
            public const int TaxLines = 91;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 92;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 93;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 94;

            /// <summary>
            /// Property Indexer for ContactPhone
            /// </summary>
            public const int ContactPhone = 95;

            /// <summary>
            /// Property Indexer for ContactFax
            /// </summary>
            public const int ContactFax = 96;

            /// <summary>
            /// Property Indexer for ContactEmail
            /// </summary>
            public const int ContactEmail = 97;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 98;

            /// <summary>
            /// Property Indexer for JobRelatedCosts
            /// </summary>
            public const int JobRelatedCosts = 99;

            /// <summary>
            /// Property Indexer for CostBillingRatesProrated
            /// </summary>
            public const int CostBillingRatesProrated = 100;

            /// <summary>
            /// Property Indexer for HasRetainage
            /// </summary>
            public const int HasRetainage = 101;

            /// <summary>
            /// Property Indexer for RetainageExchangeRate
            /// </summary>
            public const int RetainageExchangeRate = 102;

            /// <summary>
            /// Property Indexer for RetainageTermsCode
            /// </summary>
            public const int RetainageTermsCode = 103;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 104;

            /// <summary>
            /// Property Indexer for TaxReportingCurrency
            /// </summary>
            public const int TaxReportingCurrency = 105;

            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate
            /// </summary>
            public const int TaxReportingExchangeRate = 106;

            /// <summary>
            /// Property Indexer for TaxReportingRateSpread
            /// </summary>
            public const int TaxReportingRateSpread = 107;

            /// <summary>
            /// Property Indexer for TaxReportingRateType
            /// </summary>
            public const int TaxReportingRateType = 108;

            /// <summary>
            /// Property Indexer for TaxReportingRateMatchType
            /// </summary>
            public const int TaxReportingRateMatchType = 109;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate
            /// </summary>
            public const int TaxReportingRateDate = 110;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperation
            /// </summary>
            public const int TaxReportingRateOperation = 111;

            /// <summary>
            /// Property Indexer for TaxReportingRateOverridden
            /// </summary>
            public const int TaxReportingRateOverridden = 112;

            /// <summary>
            /// Property Indexer for TaxReportingDecimalPlaces
            /// </summary>
            public const int TaxReportingDecimalPlaces = 113;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 114;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 115;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 116;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 117;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 118;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 119;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 120;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 121;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 122;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 123;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 124;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 125;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 126;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 127;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 128;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 141;

            /// <summary>
            /// Property Indexer for TermsCodeDescription
            /// </summary>
            public const int TermsCodeDescription = 142;

            /// <summary>
            /// Property Indexer for RateTypeDescription
            /// </summary>
            public const int RateTypeDescription = 143;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 144;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 145;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 146;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 147;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 148;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 149;

            /// <summary>
            /// Property Indexer for TaxAuthority1Description
            /// </summary>
            public const int TaxAuthority1Description = 150;

            /// <summary>
            /// Property Indexer for TaxAuthority2Description
            /// </summary>
            public const int TaxAuthority2Description = 151;

            /// <summary>
            /// Property Indexer for TaxAuthority3Description
            /// </summary>
            public const int TaxAuthority3Description = 152;

            /// <summary>
            /// Property Indexer for TaxAuthority4Description
            /// </summary>
            public const int TaxAuthority4Description = 153;

            /// <summary>
            /// Property Indexer for TaxAuthority5Description
            /// </summary>
            public const int TaxAuthority5Description = 154;

            /// <summary>
            /// Property Indexer for NetOfTaxSum
            /// </summary>
            public const int NetOfTaxSum = 155;

            /// <summary>
            /// Property Indexer for TaxIncluded1Sum
            /// </summary>
            public const int TaxIncluded1Sum = 156;

            /// <summary>
            /// Property Indexer for TaxIncluded2Sum
            /// </summary>
            public const int TaxIncluded2Sum = 157;

            /// <summary>
            /// Property Indexer for TaxIncluded3Sum
            /// </summary>
            public const int TaxIncluded3Sum = 158;

            /// <summary>
            /// Property Indexer for TaxIncluded4Sum
            /// </summary>
            public const int TaxIncluded4Sum = 159;

            /// <summary>
            /// Property Indexer for TaxIncluded5Sum
            /// </summary>
            public const int TaxIncluded5Sum = 160;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1Sum
            /// </summary>
            public const int TaxAllocatedAmount1Sum = 161;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2Sum
            /// </summary>
            public const int TaxAllocatedAmount2Sum = 162;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3Sum
            /// </summary>
            public const int TaxAllocatedAmount3Sum = 163;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4Sum
            /// </summary>
            public const int TaxAllocatedAmount4Sum = 164;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5Sum
            /// </summary>
            public const int TaxAllocatedAmount5Sum = 165;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1Sum
            /// </summary>
            public const int TaxRecoverableAmount1Sum = 166;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2Sum
            /// </summary>
            public const int TaxRecoverableAmount2Sum = 167;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3Sum
            /// </summary>
            public const int TaxRecoverableAmount3Sum = 168;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4Sum
            /// </summary>
            public const int TaxRecoverableAmount4Sum = 169;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5Sum
            /// </summary>
            public const int TaxRecoverableAmount5Sum = 170;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1Sum
            /// </summary>
            public const int TaxExpenseAmount1Sum = 171;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2Sum
            /// </summary>
            public const int TaxExpenseAmount2Sum = 172;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3Sum
            /// </summary>
            public const int TaxExpenseAmount3Sum = 173;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4Sum
            /// </summary>
            public const int TaxExpenseAmount4Sum = 174;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5Sum
            /// </summary>
            public const int TaxExpenseAmount5Sum = 175;

            /// <summary>
            /// Property Indexer for TotalTaxAllocated1
            /// </summary>
            public const int TotalTaxAllocated1 = 176;

            /// <summary>
            /// Property Indexer for TaxIncluded1
            /// </summary>
            public const int TaxIncluded1 = 177;

            /// <summary>
            /// Property Indexer for TaxExcluded1
            /// </summary>
            public const int TaxExcluded1 = 178;

            /// <summary>
            /// Property Indexer for TotalUnbalancedTax
            /// </summary>
            public const int TotalUnbalancedTax = 179;

            /// <summary>
            /// Property Indexer for TotalUnbalancedAllocatedTax
            /// </summary>
            public const int TotalUnbalancedAllocatedTax = 180;

            /// <summary>
            /// Property Indexer for PrimaryNetOfTax
            /// </summary>
            public const int PrimaryNetOfTax = 181;

            /// <summary>
            /// Property Indexer for PrimaryIncludedTaxAmount1
            /// </summary>
            public const int PrimaryIncludedTaxAmount1 = 182;

            /// <summary>
            /// Property Indexer for PrimaryIncludedTaxAmount2
            /// </summary>
            public const int PrimaryIncludedTaxAmount2 = 183;

            /// <summary>
            /// Property Indexer for PrimaryIncludedTaxAmount3
            /// </summary>
            public const int PrimaryIncludedTaxAmount3 = 184;

            /// <summary>
            /// Property Indexer for PrimaryIncludedTaxAmount4
            /// </summary>
            public const int PrimaryIncludedTaxAmount4 = 185;

            /// <summary>
            /// Property Indexer for PrimaryIncludedTaxAmount5
            /// </summary>
            public const int PrimaryIncludedTaxAmount5 = 186;

            /// <summary>
            /// Property Indexer for PrimaryTaxAllocatedAmount1
            /// </summary>
            public const int PrimaryTaxAllocatedAmount1 = 187;

            /// <summary>
            /// Property Indexer for PrimaryTaxAllocatedAmount2
            /// </summary>
            public const int PrimaryTaxAllocatedAmount2 = 188;

            /// <summary>
            /// Property Indexer for PrimaryTaxAllocatedAmount3
            /// </summary>
            public const int PrimaryTaxAllocatedAmount3 = 189;

            /// <summary>
            /// Property Indexer for PrimaryTaxAllocatedAmount4
            /// </summary>
            public const int PrimaryTaxAllocatedAmount4 = 190;

            /// <summary>
            /// Property Indexer for PrimaryTaxAllocatedAmount5
            /// </summary>
            public const int PrimaryTaxAllocatedAmount5 = 191;

            /// <summary>
            /// Property Indexer for PrimaryTaxRecoverableAmount1
            /// </summary>
            public const int PrimaryTaxRecoverableAmount1 = 192;

            /// <summary>
            /// Property Indexer for PrimaryTaxRecoverableAmount2
            /// </summary>
            public const int PrimaryTaxRecoverableAmount2 = 193;

            /// <summary>
            /// Property Indexer for PrimaryTaxRecoverableAmount3
            /// </summary>
            public const int PrimaryTaxRecoverableAmount3 = 194;

            /// <summary>
            /// Property Indexer for PrimaryTaxRecoverableAmount4
            /// </summary>
            public const int PrimaryTaxRecoverableAmount4 = 195;

            /// <summary>
            /// Property Indexer for PrimaryTaxRecoverableAmount5
            /// </summary>
            public const int PrimaryTaxRecoverableAmount5 = 196;

            /// <summary>
            /// Property Indexer for PrimaryTaxExpenseAmount1
            /// </summary>
            public const int PrimaryTaxExpenseAmount1 = 197;

            /// <summary>
            /// Property Indexer for PrimaryTaxExpenseAmount2
            /// </summary>
            public const int PrimaryTaxExpenseAmount2 = 198;

            /// <summary>
            /// Property Indexer for PrimaryTaxExpenseAmount3
            /// </summary>
            public const int PrimaryTaxExpenseAmount3 = 199;

            /// <summary>
            /// Property Indexer for PrimaryTaxExpenseAmount4
            /// </summary>
            public const int PrimaryTaxExpenseAmount4 = 200;

            /// <summary>
            /// Property Indexer for PrimaryTaxExpenseAmount5
            /// </summary>
            public const int PrimaryTaxExpenseAmount5 = 201;

            /// <summary>
            /// Property Indexer for Amount1
            /// </summary>
            public const int Amount1 = 202;

            /// <summary>
            /// Property Indexer for Subtotal
            /// </summary>
            public const int Subtotal = 203;

            /// <summary>
            /// Property Indexer for Vendors
            /// </summary>
            public const int Vendors = 204;

            /// <summary>
            /// Property Indexer for VendorsCompleted
            /// </summary>
            public const int VendorsCompleted = 205;

            /// <summary>
            /// Property Indexer for VendorsInvoiced
            /// </summary>
            public const int VendorsInvoiced = 206;

            /// <summary>
            /// Property Indexer for TaxcalculationIspending
            /// </summary>
            public const int TaxcalculationIspending = 207;

            /// <summary>
            /// Property Indexer for DocumentLocked
            /// </summary>
            public const int DocumentLocked = 208;

            /// <summary>
            /// Property Indexer for ExchangeRateExists
            /// </summary>
            public const int ExchangeRateExists = 209;

            /// <summary>
            /// Property Indexer for IsThisVendorPrimary
            /// </summary>
            public const int IsThisVendorPrimary = 210;

            /// <summary>
            /// Property Indexer for HasDetails
            /// </summary>
            public const int HasDetails = 211;

            /// <summary>
            /// Property Indexer for TaxLines1
            /// </summary>
            public const int TaxLines1 = 212;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 213;

            /// <summary>
            /// Property Indexer for RetainageTermsCodeDescription
            /// </summary>
            public const int RetainageTermsCodeDescription = 214;

            /// <summary>
            /// Property Indexer for PrimaryRetainageAmount
            /// </summary>
            public const int PrimaryRetainageAmount = 215;

            /// <summary>
            /// Property Indexer for UnretainedTotal
            /// </summary>
            public const int UnretainedTotal = 216;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 217;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 218;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 219;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 220;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 221;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 222;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 223;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 224;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 225;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 226;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 227;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 228;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 229;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 230;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 231;

            /// <summary>
            /// Property Indexer for TaxReportingExchRateExists
            /// </summary>
            public const int TaxReportingExchRateExists = 232;

            /// <summary>
            /// Property Indexer for DerivedTaxReportingExchRate
            /// </summary>
            public const int DerivedTaxReportingExchRate = 233;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyDesc
            /// </summary>
            public const int TaxReportingCurrencyDesc = 234;

            /// <summary>
            /// Property Indexer for TaxReportingRateTypeDesc
            /// </summary>
            public const int TaxReportingRateTypeDesc = 235;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 236;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 237;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 238;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 239;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 240;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 241;

            /// <summary>
            /// Property Indexer for TaxBase1Sum
            /// </summary>
            public const int TaxBase1Sum = 242;

            /// <summary>
            /// Property Indexer for TaxBase2Sum
            /// </summary>
            public const int TaxBase2Sum = 243;

            /// <summary>
            /// Property Indexer for TaxBase3Sum
            /// </summary>
            public const int TaxBase3Sum = 244;

            /// <summary>
            /// Property Indexer for TaxBase4Sum
            /// </summary>
            public const int TaxBase4Sum = 245;

            /// <summary>
            /// Property Indexer for TaxBase5Sum
            /// </summary>
            public const int TaxBase5Sum = 246;

            /// <summary>
            /// Property Indexer for TaxAmount1Sum
            /// </summary>
            public const int TaxAmount1Sum = 247;

            /// <summary>
            /// Property Indexer for TaxAmount2Sum
            /// </summary>
            public const int TaxAmount2Sum = 248;

            /// <summary>
            /// Property Indexer for TaxAmount3Sum
            /// </summary>
            public const int TaxAmount3Sum = 249;

            /// <summary>
            /// Property Indexer for TaxAmount4Sum
            /// </summary>
            public const int TaxAmount4Sum = 250;

            /// <summary>
            /// Property Indexer for TaxAmount5Sum
            /// </summary>
            public const int TaxAmount5Sum = 251;

            /// <summary>
            /// Property Indexer for TaxExcluded1Sum
            /// </summary>
            public const int TaxExcluded1Sum = 252;

            /// <summary>
            /// Property Indexer for TaxExcluded2Sum
            /// </summary>
            public const int TaxExcluded2Sum = 253;

            /// <summary>
            /// Property Indexer for TaxExcluded3Sum
            /// </summary>
            public const int TaxExcluded3Sum = 254;

            /// <summary>
            /// Property Indexer for TaxExcluded4Sum
            /// </summary>
            public const int TaxExcluded4Sum = 255;

            /// <summary>
            /// Property Indexer for TaxExcluded5Sum
            /// </summary>
            public const int TaxExcluded5Sum = 256;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1Sum
            /// </summary>
            public const int TaxReportingAmount1Sum = 257;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2Sum
            /// </summary>
            public const int TaxReportingAmount2Sum = 258;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3Sum
            /// </summary>
            public const int TaxReportingAmount3Sum = 259;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4Sum
            /// </summary>
            public const int TaxReportingAmount4Sum = 260;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5Sum
            /// </summary>
            public const int TaxReportingAmount5Sum = 261;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded1Sum
            /// </summary>
            public const int TaxReportingIncluded1Sum = 262;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded2Sum
            /// </summary>
            public const int TaxReportingIncluded2Sum = 263;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded3Sum
            /// </summary>
            public const int TaxReportingIncluded3Sum = 264;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded4Sum
            /// </summary>
            public const int TaxReportingIncluded4Sum = 265;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded5Sum
            /// </summary>
            public const int TaxReportingIncluded5Sum = 266;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded1Sum
            /// </summary>
            public const int TaxReportingExcluded1Sum = 267;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded2Sum
            /// </summary>
            public const int TaxReportingExcluded2Sum = 268;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded3Sum
            /// </summary>
            public const int TaxReportingExcluded3Sum = 269;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded4Sum
            /// </summary>
            public const int TaxReportingExcluded4Sum = 270;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded5Sum
            /// </summary>
            public const int TaxReportingExcluded5Sum = 271;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount1Sum
            /// </summary>
            public const int TaxRepAllocatedAmount1Sum = 272;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount2Sum
            /// </summary>
            public const int TaxRepAllocatedAmount2Sum = 273;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount3Sum
            /// </summary>
            public const int TaxRepAllocatedAmount3Sum = 274;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount4Sum
            /// </summary>
            public const int TaxRepAllocatedAmount4Sum = 275;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount5Sum
            /// </summary>
            public const int TaxRepAllocatedAmount5Sum = 276;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt1Sum
            /// </summary>
            public const int TaxRepRecoverableAmt1Sum = 277;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt2Sum
            /// </summary>
            public const int TaxRepRecoverableAmt2Sum = 278;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt3Sum
            /// </summary>
            public const int TaxRepRecoverableAmt3Sum = 279;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt4Sum
            /// </summary>
            public const int TaxRepRecoverableAmt4Sum = 280;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt5Sum
            /// </summary>
            public const int TaxRepRecoverableAmt5Sum = 281;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount1Sum
            /// </summary>
            public const int TaxRepExpenseAmount1Sum = 282;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount2Sum
            /// </summary>
            public const int TaxRepExpenseAmount2Sum = 283;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount3Sum
            /// </summary>
            public const int TaxRepExpenseAmount3Sum = 284;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount4Sum
            /// </summary>
            public const int TaxRepExpenseAmount4Sum = 285;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount5Sum
            /// </summary>
            public const int TaxRepExpenseAmount5Sum = 286;

            /// <summary>
            /// Property Indexer for PrimaryTaxBase1
            /// </summary>
            public const int PrimaryTaxBase1 = 287;

            /// <summary>
            /// Property Indexer for PrimaryTaxBase2
            /// </summary>
            public const int PrimaryTaxBase2 = 288;

            /// <summary>
            /// Property Indexer for PrimaryTaxBase3
            /// </summary>
            public const int PrimaryTaxBase3 = 289;

            /// <summary>
            /// Property Indexer for PrimaryTaxBase4
            /// </summary>
            public const int PrimaryTaxBase4 = 290;

            /// <summary>
            /// Property Indexer for PrimaryTaxBase5
            /// </summary>
            public const int PrimaryTaxBase5 = 291;

            /// <summary>
            /// Property Indexer for PrimaryTaxAmount1
            /// </summary>
            public const int PrimaryTaxAmount1 = 292;

            /// <summary>
            /// Property Indexer for PrimaryTaxAmount2
            /// </summary>
            public const int PrimaryTaxAmount2 = 293;

            /// <summary>
            /// Property Indexer for PrimaryTaxAmount3
            /// </summary>
            public const int PrimaryTaxAmount3 = 294;

            /// <summary>
            /// Property Indexer for PrimaryTaxAmount4
            /// </summary>
            public const int PrimaryTaxAmount4 = 295;

            /// <summary>
            /// Property Indexer for PrimaryTaxAmount5
            /// </summary>
            public const int PrimaryTaxAmount5 = 296;

            /// <summary>
            /// Property Indexer for PrimaryExcludedTaxAmount1
            /// </summary>
            public const int PrimaryExcludedTaxAmount1 = 297;

            /// <summary>
            /// Property Indexer for PrimaryExcludedTaxAmount2
            /// </summary>
            public const int PrimaryExcludedTaxAmount2 = 298;

            /// <summary>
            /// Property Indexer for PrimaryExcludedTaxAmount3
            /// </summary>
            public const int PrimaryExcludedTaxAmount3 = 299;

            /// <summary>
            /// Property Indexer for PrimaryExcludedTaxAmount4
            /// </summary>
            public const int PrimaryExcludedTaxAmount4 = 300;

            /// <summary>
            /// Property Indexer for PrimaryExcludedTaxAmount5
            /// </summary>
            public const int PrimaryExcludedTaxAmount5 = 301;

            /// <summary>
            /// Property Indexer for PrmTaxRepAmount1
            /// </summary>
            public const int PrmTaxRepAmount1 = 302;

            /// <summary>
            /// Property Indexer for PrmTaxRepAmount2
            /// </summary>
            public const int PrmTaxRepAmount2 = 303;

            /// <summary>
            /// Property Indexer for PrmTaxRepAmount3
            /// </summary>
            public const int PrmTaxRepAmount3 = 304;

            /// <summary>
            /// Property Indexer for PrmTaxRepAmount4
            /// </summary>
            public const int PrmTaxRepAmount4 = 305;

            /// <summary>
            /// Property Indexer for PrmTaxRepAmount5
            /// </summary>
            public const int PrmTaxRepAmount5 = 306;

            /// <summary>
            /// Property Indexer for PrmTaxRepIncludedAmount1
            /// </summary>
            public const int PrmTaxRepIncludedAmount1 = 307;

            /// <summary>
            /// Property Indexer for PrmTaxRepIncludedAmount2
            /// </summary>
            public const int PrmTaxRepIncludedAmount2 = 308;

            /// <summary>
            /// Property Indexer for PrmTaxRepIncludedAmount3
            /// </summary>
            public const int PrmTaxRepIncludedAmount3 = 309;

            /// <summary>
            /// Property Indexer for PrmTaxRepIncludedAmount4
            /// </summary>
            public const int PrmTaxRepIncludedAmount4 = 310;

            /// <summary>
            /// Property Indexer for PrmTaxRepIncludedAmount5
            /// </summary>
            public const int PrmTaxRepIncludedAmount5 = 311;

            /// <summary>
            /// Property Indexer for PrmTaxRepExcludedAmount1
            /// </summary>
            public const int PrmTaxRepExcludedAmount1 = 312;

            /// <summary>
            /// Property Indexer for PrmTaxRepExcludedAmount2
            /// </summary>
            public const int PrmTaxRepExcludedAmount2 = 313;

            /// <summary>
            /// Property Indexer for PrmTaxRepExcludedAmount3
            /// </summary>
            public const int PrmTaxRepExcludedAmount3 = 314;

            /// <summary>
            /// Property Indexer for PrmTaxRepExcludedAmount4
            /// </summary>
            public const int PrmTaxRepExcludedAmount4 = 315;

            /// <summary>
            /// Property Indexer for PrmTaxRepExcludedAmount5
            /// </summary>
            public const int PrmTaxRepExcludedAmount5 = 316;

            /// <summary>
            /// Property Indexer for PrmTaxRepAllocatedAmount1
            /// </summary>
            public const int PrmTaxRepAllocatedAmount1 = 317;

            /// <summary>
            /// Property Indexer for PrmTaxRepAllocatedAmount2
            /// </summary>
            public const int PrmTaxRepAllocatedAmount2 = 318;

            /// <summary>
            /// Property Indexer for PrmTaxRepAllocatedAmount3
            /// </summary>
            public const int PrmTaxRepAllocatedAmount3 = 319;

            /// <summary>
            /// Property Indexer for PrmTaxRepAllocatedAmount4
            /// </summary>
            public const int PrmTaxRepAllocatedAmount4 = 320;

            /// <summary>
            /// Property Indexer for PrmTaxRepAllocatedAmount5
            /// </summary>
            public const int PrmTaxRepAllocatedAmount5 = 321;

            /// <summary>
            /// Property Indexer for PrmTaxRepRecoverableAmt1
            /// </summary>
            public const int PrmTaxRepRecoverableAmt1 = 322;

            /// <summary>
            /// Property Indexer for PrmTaxRepRecoverableAmt2
            /// </summary>
            public const int PrmTaxRepRecoverableAmt2 = 323;

            /// <summary>
            /// Property Indexer for PrmTaxRepRecoverableAmt3
            /// </summary>
            public const int PrmTaxRepRecoverableAmt3 = 324;

            /// <summary>
            /// Property Indexer for PrmTaxRepRecoverableAmt4
            /// </summary>
            public const int PrmTaxRepRecoverableAmt4 = 325;

            /// <summary>
            /// Property Indexer for PrmTaxRepRecoverableAmt5
            /// </summary>
            public const int PrmTaxRepRecoverableAmt5 = 326;

            /// <summary>
            /// Property Indexer for PrmTaxRepExpenseAmount1
            /// </summary>
            public const int PrmTaxRepExpenseAmount1 = 327;

            /// <summary>
            /// Property Indexer for PrmTaxRepExpenseAmount2
            /// </summary>
            public const int PrmTaxRepExpenseAmount2 = 328;

            /// <summary>
            /// Property Indexer for PrmTaxRepExpenseAmount3
            /// </summary>
            public const int PrmTaxRepExpenseAmount3 = 329;

            /// <summary>
            /// Property Indexer for PrmTaxRepExpenseAmount4
            /// </summary>
            public const int PrmTaxRepExpenseAmount4 = 330;

            /// <summary>
            /// Property Indexer for PrmTaxRepExpenseAmount5
            /// </summary>
            public const int PrmTaxRepExpenseAmount5 = 331;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 332;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 333;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 334;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 335;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 336;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 337;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 338;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 339;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 340;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 341;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt1
            /// </summary>
            public const int RetainageTaxRecoverableAmt1 = 342;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt2
            /// </summary>
            public const int RetainageTaxRecoverableAmt2 = 343;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt3
            /// </summary>
            public const int RetainageTaxRecoverableAmt3 = 344;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt4
            /// </summary>
            public const int RetainageTaxRecoverableAmt4 = 345;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt5
            /// </summary>
            public const int RetainageTaxRecoverableAmt5 = 346;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount1
            /// </summary>
            public const int RetainageTaxExpenseAmount1 = 347;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount2
            /// </summary>
            public const int RetainageTaxExpenseAmount2 = 348;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount3
            /// </summary>
            public const int RetainageTaxExpenseAmount3 = 349;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount4
            /// </summary>
            public const int RetainageTaxExpenseAmount4 = 350;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount5
            /// </summary>
            public const int RetainageTaxExpenseAmount5 = 351;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount1
            /// </summary>
            public const int RetainageTaxAllocatedAmount1 = 352;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount2
            /// </summary>
            public const int RetainageTaxAllocatedAmount2 = 353;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount3
            /// </summary>
            public const int RetainageTaxAllocatedAmount3 = 354;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount4
            /// </summary>
            public const int RetainageTaxAllocatedAmount4 = 355;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount5
            /// </summary>
            public const int RetainageTaxAllocatedAmount5 = 356;

            /// <summary>
            /// Property Indexer for WarnOnRetainageTaxShift
            /// </summary>
            public const int WarnOnRetainageTaxShift = 357;

            /// <summary>
            /// Property Indexer for RetainageTaxTotalAmount
            /// </summary>
            public const int RetainageTaxTotalAmount = 358;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt1 = 359;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt2 = 360;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt3 = 361;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt4 = 362;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt5 = 363;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1Sum
            /// </summary>
            public const int RetainageTaxBase1Sum = 364;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2Sum
            /// </summary>
            public const int RetainageTaxBase2Sum = 365;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3Sum
            /// </summary>
            public const int RetainageTaxBase3Sum = 366;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4Sum
            /// </summary>
            public const int RetainageTaxBase4Sum = 367;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5Sum
            /// </summary>
            public const int RetainageTaxBase5Sum = 368;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1Sum
            /// </summary>
            public const int RetainageTaxAmount1Sum = 369;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2Sum
            /// </summary>
            public const int RetainageTaxAmount2Sum = 370;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3Sum
            /// </summary>
            public const int RetainageTaxAmount3Sum = 371;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4Sum
            /// </summary>
            public const int RetainageTaxAmount4Sum = 372;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5Sum
            /// </summary>
            public const int RetainageTaxAmount5Sum = 373;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt1Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt1Sum = 374;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt2Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt2Sum = 375;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt3Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt3Sum = 376;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt4Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt4Sum = 377;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt5Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt5Sum = 378;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount1Sum
            /// </summary>
            public const int RtgTaxExpenseAmount1Sum = 379;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount2Sum
            /// </summary>
            public const int RtgTaxExpenseAmount2Sum = 380;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount3Sum
            /// </summary>
            public const int RtgTaxExpenseAmount3Sum = 381;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount4Sum
            /// </summary>
            public const int RtgTaxExpenseAmount4Sum = 382;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount5Sum
            /// </summary>
            public const int RtgTaxExpenseAmount5Sum = 383;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount1Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount1Sum = 384;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount2Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount2Sum = 385;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount3Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount3Sum = 386;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount4Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount4Sum = 387;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount5Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount5Sum = 388;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxBase1
            /// </summary>
            public const int PrimaryRetainageTaxBase1 = 389;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxBase2
            /// </summary>
            public const int PrimaryRetainageTaxBase2 = 390;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxBase3
            /// </summary>
            public const int PrimaryRetainageTaxBase3 = 391;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxBase4
            /// </summary>
            public const int PrimaryRetainageTaxBase4 = 392;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxBase5
            /// </summary>
            public const int PrimaryRetainageTaxBase5 = 393;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxAmount1
            /// </summary>
            public const int PrimaryRetainageTaxAmount1 = 394;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxAmount2
            /// </summary>
            public const int PrimaryRetainageTaxAmount2 = 395;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxAmount3
            /// </summary>
            public const int PrimaryRetainageTaxAmount3 = 396;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxAmount4
            /// </summary>
            public const int PrimaryRetainageTaxAmount4 = 397;

            /// <summary>
            /// Property Indexer for PrimaryRetainageTaxAmount5
            /// </summary>
            public const int PrimaryRetainageTaxAmount5 = 398;

            /// <summary>
            /// Property Indexer for PrmRtgTaxRecoverableAmt1
            /// </summary>
            public const int PrmRtgTaxRecoverableAmt1 = 399;

            /// <summary>
            /// Property Indexer for PrmRtgTaxRecoverableAmt2
            /// </summary>
            public const int PrmRtgTaxRecoverableAmt2 = 400;

            /// <summary>
            /// Property Indexer for PrmRtgTaxRecoverableAmt3
            /// </summary>
            public const int PrmRtgTaxRecoverableAmt3 = 401;

            /// <summary>
            /// Property Indexer for PrmRtgTaxRecoverableAmt4
            /// </summary>
            public const int PrmRtgTaxRecoverableAmt4 = 402;

            /// <summary>
            /// Property Indexer for PrmRtgTaxRecoverableAmt5
            /// </summary>
            public const int PrmRtgTaxRecoverableAmt5 = 403;

            /// <summary>
            /// Property Indexer for PrmRtgTaxExpenseAmount1
            /// </summary>
            public const int PrmRtgTaxExpenseAmount1 = 404;

            /// <summary>
            /// Property Indexer for PrmRtgTaxExpenseAmount2
            /// </summary>
            public const int PrmRtgTaxExpenseAmount2 = 405;

            /// <summary>
            /// Property Indexer for PrmRtgTaxExpenseAmount3
            /// </summary>
            public const int PrmRtgTaxExpenseAmount3 = 406;

            /// <summary>
            /// Property Indexer for PrmRtgTaxExpenseAmount4
            /// </summary>
            public const int PrmRtgTaxExpenseAmount4 = 407;

            /// <summary>
            /// Property Indexer for PrmRtgTaxExpenseAmount5
            /// </summary>
            public const int PrmRtgTaxExpenseAmount5 = 408;

            /// <summary>
            /// Property Indexer for PrmRtgTaxAllocatedAmount1
            /// </summary>
            public const int PrmRtgTaxAllocatedAmount1 = 409;

            /// <summary>
            /// Property Indexer for PrmRtgTaxAllocatedAmount2
            /// </summary>
            public const int PrmRtgTaxAllocatedAmount2 = 410;

            /// <summary>
            /// Property Indexer for PrmRtgTaxAllocatedAmount3
            /// </summary>
            public const int PrmRtgTaxAllocatedAmount3 = 411;

            /// <summary>
            /// Property Indexer for PrmRtgTaxAllocatedAmount4
            /// </summary>
            public const int PrmRtgTaxAllocatedAmount4 = 412;

            /// <summary>
            /// Property Indexer for PrmRtgTaxAllocatedAmount5
            /// </summary>
            public const int PrmRtgTaxAllocatedAmount5 = 413;

            /// <summary>
            /// Property Indexer for VendorAccountSet
            /// </summary>
            public const int VendorAccountSet = 414;

            /// <summary>
            /// Property Indexer for VendorAccountSetDescription
            /// </summary>
            public const int VendorAccountSetDescription = 415;

            /// <summary>
            /// Property for Vendor Import Export
            /// </summary>
            public const int VendorImportExport = 417;

        }

        #endregion
    }
}