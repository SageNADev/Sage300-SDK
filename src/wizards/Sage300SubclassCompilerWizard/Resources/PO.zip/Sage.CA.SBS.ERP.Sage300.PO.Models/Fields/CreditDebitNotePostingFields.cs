// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Contains list of CreditDebitNotePosting Constants
	/// </summary>
	public partial class CreditDebitNotePosting
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "PO0312";

		#region Properties

		/// <summary>
		/// Contains list of CreditDebitNotePosting Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for HeaderSequence
			/// </summary>
			public const string HeaderSequence = "CRNISEQ";

			/// <summary>
			/// Property for OperationToPost
			/// </summary>
			public const string OperationToPost = "OPERATION";

			/// <summary>
			/// Property for LastPostingDate
			/// </summary>
			public const string LastPostingDate = "POSTDATE";

			/// <summary>
			/// Property for Completed
			/// </summary>
			public const string Completed = "ISCOMPLETE";

			/// <summary>
			/// Property for DateCompleted
			/// </summary>
			public const string DateCompleted = "DTCOMPLETE";

			/// <summary>
			/// Property for CreditDebitNoteSequenceKey
			/// </summary>
			public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

			/// <summary>
			/// Property for TransactionType
			/// </summary>
			public const string TransactionType = "TRANSTYPE";

			/// <summary>
			/// Property for FromDocument
			/// </summary>
			public const string FromDocument = "FROMDOC";

			/// <summary>
			/// Property for InvoiceSequenceKey
			/// </summary>
			public const string InvoiceSequenceKey = "INVHSEQ";

			/// <summary>
			/// Property for ReceiptSequenceKey
			/// </summary>
			public const string ReceiptSequenceKey = "RCPHSEQ";

			/// <summary>
			/// Property for ReturnSequenceKey
			/// </summary>
			public const string ReturnSequenceKey = "RETHSEQ";

			/// <summary>
			/// Property for TaxClass1
			/// </summary>
			public const string TaxClass1 = "TAXCLASS1";

			/// <summary>
			/// Property for TaxClass2
			/// </summary>
			public const string TaxClass2 = "TAXCLASS2";

			/// <summary>
			/// Property for TaxClass3
			/// </summary>
			public const string TaxClass3 = "TAXCLASS3";

			/// <summary>
			/// Property for TaxClass4
			/// </summary>
			public const string TaxClass4 = "TAXCLASS4";

			/// <summary>
			/// Property for TaxClass5
			/// </summary>
			public const string TaxClass5 = "TAXCLASS5";

			/// <summary>
			/// Property for ConversionSourceAmount
			/// </summary>
			public const string ConversionSourceAmount = "SCAMOUNT";

			/// <summary>
			/// Property for ConversionFunctionalAmount
			/// </summary>
			public const string ConversionFunctionalAmount = "FCAMOUNT";

			/// <summary>
			/// Property for SourceDocumentTotal
			/// </summary>
			public const string SourceDocumentTotal = "SCDOCTOTAL";

			/// <summary>
			/// Property for HasRetainage
			/// </summary>
			public const string HasRetainage = "HASRTG";

			/// <summary>
			/// Property for RetainageExchangeRate
			/// </summary>
			public const string RetainageExchangeRate = "RTGRATE";

			/// <summary>
			/// Property for RetainageAmount
			/// </summary>
			public const string RetainageAmount = "SCRTGAMT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of CreditDebitNotePosting Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for HeaderSequence
			/// </summary>
			public const int HeaderSequence = 1;

			/// <summary>
			/// Property Indexer for OperationToPost
			/// </summary>
			public const int OperationToPost = 2;

			/// <summary>
			/// Property Indexer for LastPostingDate
			/// </summary>
			public const int LastPostingDate = 3;

			/// <summary>
			/// Property Indexer for Completed
			/// </summary>
			public const int Completed = 4;

			/// <summary>
			/// Property Indexer for DateCompleted
			/// </summary>
			public const int DateCompleted = 5;

			/// <summary>
			/// Property Indexer for CreditDebitNoteSequenceKey
			/// </summary>
			public const int CreditDebitNoteSequenceKey = 6;

			/// <summary>
			/// Property Indexer for TransactionType
			/// </summary>
			public const int TransactionType = 7;

			/// <summary>
			/// Property Indexer for FromDocument
			/// </summary>
			public const int FromDocument = 8;

			/// <summary>
			/// Property Indexer for InvoiceSequenceKey
			/// </summary>
			public const int InvoiceSequenceKey = 9;

			/// <summary>
			/// Property Indexer for ReceiptSequenceKey
			/// </summary>
			public const int ReceiptSequenceKey = 10;

			/// <summary>
			/// Property Indexer for ReturnSequenceKey
			/// </summary>
			public const int ReturnSequenceKey = 11;

			/// <summary>
			/// Property Indexer for TaxClass1
			/// </summary>
			public const int TaxClass1 = 12;

			/// <summary>
			/// Property Indexer for TaxClass2
			/// </summary>
			public const int TaxClass2 = 13;

			/// <summary>
			/// Property Indexer for TaxClass3
			/// </summary>
			public const int TaxClass3 = 14;

			/// <summary>
			/// Property Indexer for TaxClass4
			/// </summary>
			public const int TaxClass4 = 15;

			/// <summary>
			/// Property Indexer for TaxClass5
			/// </summary>
			public const int TaxClass5 = 16;

			/// <summary>
			/// Property Indexer for ConversionSourceAmount
			/// </summary>
			public const int ConversionSourceAmount = 17;

			/// <summary>
			/// Property Indexer for ConversionFunctionalAmount
			/// </summary>
			public const int ConversionFunctionalAmount = 18;

			/// <summary>
			/// Property Indexer for SourceDocumentTotal
			/// </summary>
			public const int SourceDocumentTotal = 19;

			/// <summary>
			/// Property Indexer for HasRetainage
			/// </summary>
			public const int HasRetainage = 20;

			/// <summary>
			/// Property Indexer for RetainageExchangeRate
			/// </summary>
			public const int RetainageExchangeRate = 21;

			/// <summary>
			/// Property Indexer for RetainageAmount
			/// </summary>
			public const int RetainageAmount = 22;

		}

		#endregion

	}
}
