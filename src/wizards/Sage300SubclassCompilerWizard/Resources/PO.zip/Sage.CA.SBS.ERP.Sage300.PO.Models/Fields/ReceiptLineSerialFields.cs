// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptLineSerial Constants
    /// </summary>
    public partial class ReceiptLineSerial
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0780";
        public const string ImportEntityName = "PO0465";

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of ReceiptLineSerial Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "RCPLREV";

            /// <summary>
            /// Property for SerialNumber
            /// </summary>
            public const string SerialNumber = "SERIALNUMF";

            /// <summary>
            /// Property for ReceiptLineSequence
            /// </summary>
            public const string ReceiptLineSequence = "RCPLSEQ";

            /// <summary>
            /// Property for SerialCount
            /// </summary>
            public const string SerialCount = "SCOUNT";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ReceiptLineSerial Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for SerialNumber
            /// </summary>
            public const int SerialNumber = 3;

            /// <summary>
            /// Property Indexer for ReceiptLineSequence
            /// </summary>
            public const int ReceiptLineSequence = 4;

            /// <summary>
            /// Property Indexer for SerialCount
            /// </summary>
            public const int SerialCount = 50;
        }

        #endregion
    }
}
