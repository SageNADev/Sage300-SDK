// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptComment Constants
    /// </summary>
    public partial class ReceiptComment
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0695";
        public const string ImportEntityName = "PO0460";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"RCPCSEQ", "ReceiptCommentSequence"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"COMMENTTYP", "LineType"},
					{"COMMENT", "Comment"}
				};
            }
        }

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of ReceiptComment Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for CommentIdentifier
            /// </summary>
            public const string CommentIdentifier = "RCPCREV";

            /// <summary>
            /// Property for ReceiptCommentSequence
            /// </summary>
            public const string ReceiptCommentSequence = "RCPCSEQ";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for LineType
            /// </summary>
            public const string LineType = "COMMENTTYP";

            /// <summary>
            /// Property for Comment
            /// </summary>
            public const string Comment = "COMMENT";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ReceiptComment Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for CommentIdentifier
            /// </summary>
            public const int CommentIdentifier = 2;

            /// <summary>
            /// Property Indexer for ReceiptCommentSequence
            /// </summary>
            public const int ReceiptCommentSequence = 3;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 4;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 5;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 6;
        }

        #endregion
    }
}