// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of Requisition Comment Constants
    /// </summary>
    public partial class RequisitionComment
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0750";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"RQNCSEQ", "RequisitionCommentSequence"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"COMMENTTYP", "LineType"},
					{"COMMENT", "CommentsInstructions"}
				};
            }
        }

        #region Properties
        /// <summary>
        /// Contains list of Requisition Comment Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for RequisitionSequenceKey
            /// </summary>
            public const string RequisitionSequenceKey = "RQNHSEQ";

            /// <summary>
            /// Property for CommentIdentifier
            /// </summary>
            public const string CommentIdentifier = "RQNCREV";

            /// <summary>
            /// Property for RequisitionCommentSequence
            /// </summary>
            public const string RequisitionCommentSequence = "RQNCSEQ";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for LineType
            /// </summary>
            public const string LineType = "COMMENTTYP";

            /// <summary>
            /// Property for CommentsInstructions
            /// </summary>
            public const string CommentsInstructions = "COMMENT";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of RequisitionComment Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for RequisitionSequenceKey
            /// </summary>
            public const int RequisitionSequenceKey = 1;

            /// <summary>
            /// Property Indexer for CommentIdentifier
            /// </summary>
            public const int CommentIdentifier = 2;

            /// <summary>
            /// Property Indexer for RequisitionCommentSequence
            /// </summary>
            public const int RequisitionCommentSequence = 3;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 4;

            /// <summary>
            /// Property Indexer for LineType
            /// </summary>
            public const int LineType = 5;

            /// <summary>
            /// Property Indexer for CommentsInstructions
            /// </summary>
            public const int CommentsInstructions = 6;
        }
        #endregion
    }
}