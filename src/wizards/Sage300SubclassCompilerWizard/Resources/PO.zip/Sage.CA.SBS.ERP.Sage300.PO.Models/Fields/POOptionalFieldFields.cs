// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.
// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of POOptionalField Constants
     /// </summary>
     public partial class POOptionalField
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0580";

          #region Properties
          /// <summary>
          /// Contains list of POOptionalField Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for OptionalField
               /// </summary>
               public const string OptionalField = "OPTFIELD";

               /// <summary>
               /// Property for DefaultValue
               /// </summary>
               public const string DefaultValue = "DEFVAL";

               /// <summary>
               /// Property for Type
               /// </summary>
               public const string Type = "TYPE";

               /// <summary>
               /// Property for Length
               /// </summary>
               public const string Length = "LENGTH";

               /// <summary>
               /// Property for Decimals
               /// </summary>
               public const string Decimals = "DECIMALS";

               /// <summary>
               /// Property for AllowBlank
               /// </summary>
               public const string AllowBlank = "ALLOWNULL";

               /// <summary>
               /// Property for Validate
               /// </summary>
               public const string Validate = "VALIDATE";

               /// <summary>
               /// Property for AutoInsert
               /// </summary>
               public const string AutoInsert = "INITFLAG";

               /// <summary>
               /// Property for ExternalCostTransactions
               /// </summary>
               public const string ExternalCostTransactions = "SWPM";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWPAYCLRPO
               /// </summary>
               public const string SWPAYCLRPO = "SWPAYCLRPO";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWPAYCLRAP
               /// </summary>
               public const string SWPAYCLRAP = "SWPAYCLRAP";

               /// <summary>
               /// Property for InventoryControl
               /// </summary>
               public const string InventoryControl = "SWICCTL";

               /// <summary>
               /// Property for NonStockClearing
               /// </summary>
               public const string NonStockClearing = "SWNSCLR";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWNIPCLRPO
               /// </summary>
               public const string SWNIPCLRPO = "SWNIPCLRPO";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWNIPCLRAP
               /// </summary>
               public const string SWNIPCLRAP = "SWNIPCLRAP";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWNIEXPPO
               /// </summary>
               public const string SWNIEXPPO = "SWNIEXPPO";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWNIEXPAP
               /// </summary>
               public const string SWNIEXPAP = "SWNIEXPAP";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWACEXPPO
               /// </summary>
               public const string SWACEXPPO = "SWACEXPPO";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWACEXPAP
               /// </summary>
               public const string SWACEXPAP = "SWACEXPAP";

               /// <summary>
               /// Property for InvoicesOptionalFields
               /// </summary>
               public const string InvoicesOptionalFields = "SWAPINV";

               /// <summary>
               /// Property for Labor
               /// </summary>
               public const string Labor = "SWPMLABOR";

               /// <summary>
               /// Property for Overhead
               /// </summary>
               public const string Overhead = "SWPMOH";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWACPCLRPO
               /// </summary>
               public const string SWACPCLRPO = "SWACPCLRPO";

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property for SWACPCLRAP
               /// </summary>
               public const string SWACPCLRAP = "SWACPCLRAP";

               /// <summary>
               /// Property for Required
               /// </summary>
               public const string Required = "SWREQUIRED";

               /// <summary>
               /// Property for ValueSet
               /// </summary>
               public const string ValueSet = "SWSET";

               /// <summary>
               /// Property for TypedDefaultValueFieldIndex
               /// </summary>
               public const string TypedDefaultValueFieldIndex = "DVINDEX";

               /// <summary>
               /// Property for DefaultTextValue
               /// </summary>
               public const string DefaultTextValue = "DVIFTEXT";

               /// <summary>
               /// Property for DefaultMoneyValue
               /// </summary>
               public const string DefaultMoneyValue = "DVIFMONEY";

               /// <summary>
               /// Property for DefaultNumberValue
               /// </summary>
               public const string DefaultNumberValue = "DVIFNUM";

               /// <summary>
               /// Property for DefaultIntegerValue
               /// </summary>
               public const string DefaultIntegerValue = "DVIFLONG";

               /// <summary>
               /// Property for DefaultYesNoValue
               /// </summary>
               public const string DefaultYesNoValue = "DVIFBOOL";

               /// <summary>
               /// Property for DefaultDateValue
               /// </summary>
               public const string DefaultDateValue = "DVIFDATE";

               /// <summary>
               /// Property for DefaultTimeValue
               /// </summary>
               public const string DefaultTimeValue = "DVIFTIME";

               /// <summary>
               /// Property for OptionalFieldDescription
               /// </summary>
               public const string OptionalFieldDescription = "FDESC";

               /// <summary>
               /// Property for DefaultValueDescription
               /// </summary>
               public const string DefaultValueDescription = "VDESC";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of POOptionalField Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for OptionalField
               /// </summary>
               public const int OptionalField = 2;

               /// <summary>
               /// Property Indexer for DefaultValue
               /// </summary>
               public const int DefaultValue = 3;

               /// <summary>
               /// Property Indexer for Type
               /// </summary>
               public const int Type = 4;

               /// <summary>
               /// Property Indexer for Length
               /// </summary>
               public const int Length = 5;

               /// <summary>
               /// Property Indexer for Decimals
               /// </summary>
               public const int Decimals = 6;

               /// <summary>
               /// Property Indexer for AllowBlank
               /// </summary>
               public const int AllowBlank = 7;

               /// <summary>
               /// Property Indexer for Validate
               /// </summary>
               public const int Validate = 8;

               /// <summary>
               /// Property Indexer for AutoInsert
               /// </summary>
               public const int AutoInsert = 9;

               /// <summary>
               /// Property Indexer for ExternalCostTransactions
               /// </summary>
               public const int ExternalCostTransactions = 10;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWPAYCLRPO
               /// </summary>
               public const int SWPAYCLRPO = 11;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWPAYCLRAP
               /// </summary>
               public const int SWPAYCLRAP = 12;

               /// <summary>
               /// Property Indexer for InventoryControl
               /// </summary>
               public const int InventoryControl = 13;

               /// <summary>
               /// Property Indexer for NonStockClearing
               /// </summary>
               public const int NonStockClearing = 14;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWNIPCLRPO
               /// </summary>
               public const int SWNIPCLRPO = 15;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWNIPCLRAP
               /// </summary>
               public const int SWNIPCLRAP = 16;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWNIEXPPO
               /// </summary>
               public const int SWNIEXPPO = 17;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWNIEXPAP
               /// </summary>
               public const int SWNIEXPAP = 18;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWACEXPPO
               /// </summary>
               public const int SWACEXPPO = 19;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWACEXPAP
               /// </summary>
               public const int SWACEXPAP = 20;

               /// <summary>
               /// Property Indexer for InvoicesOptionalFields
               /// </summary>
               public const int InvoicesOptionalFields = 21;

               /// <summary>
               /// Property Indexer for Labor
               /// </summary>
               public const int Labor = 22;

               /// <summary>
               /// Property Indexer for Overhead
               /// </summary>
               public const int Overhead = 23;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWACPCLRPO
               /// </summary>
               public const int SWACPCLRPO = 24;

               // TODO: The naming convention of this property has to be manually evaluated
               /// <summary>
               /// Property Indexer for SWACPCLRAP
               /// </summary>
               public const int SWACPCLRAP = 25;

               /// <summary>
               /// Property Indexer for Required
               /// </summary>
               public const int Required = 26;

               /// <summary>
               /// Property Indexer for ValueSet
               /// </summary>
               public const int ValueSet = 27;

               /// <summary>
               /// Property Indexer for TypedDefaultValueFieldIndex
               /// </summary>
               public const int TypedDefaultValueFieldIndex = 40;

               /// <summary>
               /// Property Indexer for DefaultTextValue
               /// </summary>
               public const int DefaultTextValue = 41;

               /// <summary>
               /// Property Indexer for DefaultMoneyValue
               /// </summary>
               public const int DefaultMoneyValue = 42;

               /// <summary>
               /// Property Indexer for DefaultNumberValue
               /// </summary>
               public const int DefaultNumberValue = 43;

               /// <summary>
               /// Property Indexer for DefaultIntegerValue
               /// </summary>
               public const int DefaultIntegerValue = 44;

               /// <summary>
               /// Property Indexer for DefaultYesNoValue
               /// </summary>
               public const int DefaultYesNoValue = 45;

               /// <summary>
               /// Property Indexer for DefaultDateValue
               /// </summary>
               public const int DefaultDateValue = 46;

               /// <summary>
               /// Property Indexer for DefaultTimeValue
               /// </summary>
               public const int DefaultTimeValue = 47;

               /// <summary>
               /// Property Indexer for OptionalFieldDescription
               /// </summary>
               public const int OptionalFieldDescription = 48;

               /// <summary>
               /// Property Indexer for DefaultValueDescription
               /// </summary>
               public const int DefaultValueDescription = 49;

          }
          #endregion

     }
}
