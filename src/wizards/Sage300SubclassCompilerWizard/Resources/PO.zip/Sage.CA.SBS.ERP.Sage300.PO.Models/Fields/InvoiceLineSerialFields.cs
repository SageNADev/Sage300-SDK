// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceLineSerial Constants
    /// </summary>
    public partial class InvoiceLineSerial
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0810";

        #region Properties

        /// <summary>
        /// Contains list of InvoiceLineSerial Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for InvoiceSequenceKey
            /// </summary>
            public const string InvoiceSequenceKey = "INVHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "INVLREV";

            /// <summary>
            /// Property for SerialNumber
            /// </summary>
            public const string SerialNumber = "SERIALNUMF";

            /// <summary>
            /// Property for InvoiceLineSequence
            /// </summary>
            public const string InvoiceLineSequence = "INVLSEQ";

            /// <summary>
            /// Property for SerialCount
            /// </summary>
            public const string SerialCount = "SCOUNT";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoiceLineSerial Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for SerialNumber
            /// </summary>
            public const int SerialNumber = 3;

            /// <summary>
            /// Property Indexer for InvoiceLineSequence
            /// </summary>
            public const int InvoiceLineSequence = 4;

            /// <summary>
            /// Property Indexer for SerialCount
            /// </summary>
            public const int SerialCount = 50;
        }

        #endregion
    }
}
