// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of POOptionalFieldLocation Constants
     /// </summary>
     public partial class POOptionalFieldLocation
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0585";

          #region Properties
          /// <summary>
          /// Contains list of POOptionalFieldLocation Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of POOptionalFieldLocation Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 1;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 2;

          }
          #endregion

     }
}
