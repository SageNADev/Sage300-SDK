// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceAdditionalCost Constants
    /// </summary>
    public partial class InvoiceAdditionalCost
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0440";

        #region Properties
        /// <summary>
        /// Contains list of InvoiceAdditionalCost Constants
        /// </summary>
        public class Fields : BaseFields
        {

        }
        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoiceAdditionalCost Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for INVSREV
            /// </summary>
            public const int InvSrev = 2;

            /// <summary>
            /// Property Indexer for InvoiceCostSequence
            /// </summary>
            public const int InvoiceCostSequence = 3;

            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 4;

            /// <summary>
            /// Property Indexer for ReceiptCostSequence
            /// </summary>
            public const int ReceiptCostSequence = 5;

            /// <summary>
            /// Property Indexer for ReturnSequenceKey
            /// </summary>
            public const int ReturnSequenceKey = 6;

            /// <summary>
            /// Property Indexer for ReturnCostSequence
            /// </summary>
            public const int ReturnCostSequence = 7;

            /// <summary>
            /// Property Indexer for CompletionStatus
            /// </summary>
            public const int CompletionStatus = 8;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 9;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 10;

            /// <summary>
            /// Property Indexer for AdditionalCost
            /// </summary>
            public const int AdditionalCost = 11;

            /// <summary>
            /// Property Indexer for ExpenseAccount
            /// </summary>
            public const int ExpenseAccount = 12;

            /// <summary>
            /// Property Indexer for ReturnAccount
            /// </summary>
            public const int ReturnAccount = 13;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 14;

            /// <summary>
            /// Property Indexer for ProrationMethod
            /// </summary>
            public const int ProrationMethod = 15;

            /// <summary>
            /// Property Indexer for ReprorationMethod
            /// </summary>
            public const int ReprorationMethod = 16;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 17;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 18;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 19;

            /// <summary>
            /// Property Indexer for CostTaxClass1
            /// </summary>
            public const int CostTaxClass1 = 20;

            /// <summary>
            /// Property Indexer for CostTaxClass2
            /// </summary>
            public const int CostTaxClass2 = 21;

            /// <summary>
            /// Property Indexer for CostTaxClass3
            /// </summary>
            public const int CostTaxClass3 = 22;

            /// <summary>
            /// Property Indexer for CostTaxClass4
            /// </summary>
            public const int CostTaxClass4 = 23;

            /// <summary>
            /// Property Indexer for CostTaxClass5
            /// </summary>
            public const int CostTaxClass5 = 24;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 25;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 26;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 27;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 28;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 29;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 30;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 31;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 32;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 33;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 34;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 35;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 36;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 37;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 38;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 39;

            /// <summary>
            /// Property Indexer for TaxIncludable1
            /// </summary>
            public const int TaxIncludable1 = 40;

            /// <summary>
            /// Property Indexer for TaxIncludable2
            /// </summary>
            public const int TaxIncludable2 = 41;

            /// <summary>
            /// Property Indexer for TaxIncludable3
            /// </summary>
            public const int TaxIncludable3 = 42;

            /// <summary>
            /// Property Indexer for TaxIncludable4
            /// </summary>
            public const int TaxIncludable4 = 43;

            /// <summary>
            /// Property Indexer for TaxIncludable5
            /// </summary>
            public const int TaxIncludable5 = 44;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 45;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 46;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 47;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 48;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 49;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 50;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 51;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 52;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 53;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 54;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 55;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 56;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 57;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 58;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 59;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 60;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 61;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 62;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 63;

            /// <summary>
            /// Property Indexer for TotalTaxRecoverable
            /// </summary>
            public const int TotalTaxRecoverable = 64;

            /// <summary>
            /// Property Indexer for TotalTaxExpensed
            /// </summary>
            public const int TotalTaxExpensed = 65;

            /// <summary>
            /// Property Indexer for TotalTaxAllocated
            /// </summary>
            public const int TotalTaxAllocated = 66;

            /// <summary>
            /// Property Indexer for FuncNetOfTax
            /// </summary>
            public const int FuncNetOfTax = 67;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount1
            /// </summary>
            public const int FuncTaxIncludedAmount1 = 68;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount2
            /// </summary>
            public const int FuncTaxIncludedAmount2 = 69;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount3
            /// </summary>
            public const int FuncTaxIncludedAmount3 = 70;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount4
            /// </summary>
            public const int FuncTaxIncludedAmount4 = 71;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount5
            /// </summary>
            public const int FuncTaxIncludedAmount5 = 72;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount1
            /// </summary>
            public const int FuncTaxAllocatedAmount1 = 73;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount2
            /// </summary>
            public const int FuncTaxAllocatedAmount2 = 74;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount3
            /// </summary>
            public const int FuncTaxAllocatedAmount3 = 75;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount4
            /// </summary>
            public const int FuncTaxAllocatedAmount4 = 76;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount5
            /// </summary>
            public const int FuncTaxAllocatedAmount5 = 77;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount1
            /// </summary>
            public const int FuncTaxRecoverableAmount1 = 78;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount2
            /// </summary>
            public const int FuncTaxRecoverableAmount2 = 79;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount3
            /// </summary>
            public const int FuncTaxRecoverableAmount3 = 80;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount4
            /// </summary>
            public const int FuncTaxRecoverableAmount4 = 81;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount5
            /// </summary>
            public const int FuncTaxRecoverableAmount5 = 82;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount1
            /// </summary>
            public const int FuncTaxExpenseAmount1 = 83;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount2
            /// </summary>
            public const int FuncTaxExpenseAmount2 = 84;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount3
            /// </summary>
            public const int FuncTaxExpenseAmount3 = 85;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount4
            /// </summary>
            public const int FuncTaxExpenseAmount4 = 86;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount5
            /// </summary>
            public const int FuncTaxExpenseAmount5 = 87;

            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 88;

            /// <summary>
            /// Property Indexer for ApplyToReceiptSequenceKey
            /// </summary>
            public const int ApplyToReceiptSequenceKey = 89;

            /// <summary>
            /// Property Indexer for ApplyToReceiptNumber
            /// </summary>
            public const int ApplyToReceiptNumber = 90;

            /// <summary>
            /// Property Indexer for InvoiceCostGroupSequence
            /// </summary>
            public const int InvoiceCostGroupSequence = 91;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 92;

            /// <summary>
            /// Property Indexer for PaymentDiscountable
            /// </summary>
            public const int PaymentDiscountable = 93;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 94;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 95;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 96;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 97;

            /// <summary>
            /// Property Indexer for Resource
            /// </summary>
            public const int Resource = 98;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 99;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 100;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 101;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 102;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 103;

            /// <summary>
            /// Property Indexer for CalculateOverhead
            /// </summary>
            public const int CalculateOverhead = 104;

            /// <summary>
            /// Property Indexer for CalculateLabor
            /// </summary>
            public const int CalculateLabor = 105;

            /// <summary>
            /// Property Indexer for RetainagePercentage
            /// </summary>
            public const int RetainagePercentage = 106;

            /// <summary>
            /// Property Indexer for RetentionPeriod
            /// </summary>
            public const int RetentionPeriod = 107;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 108;

            /// <summary>
            /// Property Indexer for RetainageDueDate
            /// </summary>
            public const int RetainageDueDate = 109;

            /// <summary>
            /// Property Indexer for RetainageAmountOverridden
            /// </summary>
            public const int RetainageAmountOverridden = 110;

            /// <summary>
            /// Property Indexer for RetainageDueDateOverridden
            /// </summary>
            public const int RetainageDueDateOverridden = 111;

            /// <summary>
            /// Property Indexer for CostDistributions
            /// </summary>
            public const int CostDistributions = 112;

            /// <summary>
            /// Property Indexer for ManualCostDistributions
            /// </summary>
            public const int ManualCostDistributions = 113;

            /// <summary>
            /// Property Indexer for ExtraneousCostDistributions
            /// </summary>
            public const int ExtraneousCostDistributions = 114;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 115;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 116;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 117;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 118;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 119;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 120;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 121;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 122;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 123;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 124;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 125;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 126;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 127;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 128;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 129;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 130;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 131;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 132;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 133;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 134;

            /// <summary>
            /// Property Indexer for ExpenseAccountDescription
            /// </summary>
            public const int ExpenseAccountDescription = 141;

            /// <summary>
            /// Property Indexer for ReturnExpenseAccountDesc
            /// </summary>
            public const int ReturnExpenseAccountDesc = 142;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 143;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 144;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 145;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 146;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 147;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 148;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 149;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 150;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 151;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 152;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 153;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 154;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 155;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 156;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 157;

            /// <summary>
            /// Property Indexer for ManualToProrate
            /// </summary>
            public const int ManualToProrate = 158;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 159;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 160;

            /// <summary>
            /// Property Indexer for CostsComplete
            /// </summary>
            public const int CostsComplete = 161;

            /// <summary>
            /// Property Indexer for Costs
            /// </summary>
            public const int Costs = 162;

            /// <summary>
            /// Property Indexer for RCPSREV
            /// </summary>
            public const int RcpSrev = 163;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 164;

            /// <summary>
            /// Property Indexer for PaymentDiscountBaseWithTax
            /// </summary>
            public const int PaymentDiscountBaseWithTax = 165;

            /// <summary>
            /// Property Indexer for PaymentDiscountBaseWithoutTa
            /// </summary>
            public const int PaymentDiscountBaseWithoutTa = 166;

            /// <summary>
            /// Property Indexer for JobRelatedCost
            /// </summary>
            public const int JobRelatedCost = 167;

            /// <summary>
            /// Property Indexer for AmountDistributionSum
            /// </summary>
            public const int AmountDistributionSum = 168;

            /// <summary>
            /// Property Indexer for BillingRateDistributionSum
            /// </summary>
            public const int BillingRateDistributionSum = 169;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 170;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 171;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 172;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 173;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 174;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 175;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 176;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 177;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 178;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 179;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 180;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 181;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 182;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 183;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 184;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 185;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 186;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 187;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 188;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 189;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 190;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 191;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 192;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 193;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 194;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 195;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 196;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 197;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 198;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 199;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt1
            /// </summary>
            public const int RetainageTaxRecoverableAmt1 = 201;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt2
            /// </summary>
            public const int RetainageTaxRecoverableAmt2 = 202;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt3
            /// </summary>
            public const int RetainageTaxRecoverableAmt3 = 203;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt4
            /// </summary>
            public const int RetainageTaxRecoverableAmt4 = 204;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt5
            /// </summary>
            public const int RetainageTaxRecoverableAmt5 = 205;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount1
            /// </summary>
            public const int RetainageTaxExpenseAmount1 = 206;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount2
            /// </summary>
            public const int RetainageTaxExpenseAmount2 = 207;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount3
            /// </summary>
            public const int RetainageTaxExpenseAmount3 = 208;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount4
            /// </summary>
            public const int RetainageTaxExpenseAmount4 = 209;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount5
            /// </summary>
            public const int RetainageTaxExpenseAmount5 = 210;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount1
            /// </summary>
            public const int RetainageTaxAllocatedAmount1 = 211;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount2
            /// </summary>
            public const int RetainageTaxAllocatedAmount2 = 212;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount3
            /// </summary>
            public const int RetainageTaxAllocatedAmount3 = 213;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount4
            /// </summary>
            public const int RetainageTaxAllocatedAmount4 = 214;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount5
            /// </summary>
            public const int RetainageTaxAllocatedAmount5 = 215;

            /// <summary>
            /// Property Indexer for RetainageTaxTotalAmount
            /// </summary>
            public const int RetainageTaxTotalAmount = 216;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt1 = 217;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt2 = 218;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt3 = 219;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt4 = 220;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt5 = 221;

        }
        #endregion
    }
}
