// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceLineLot Constants
    /// </summary>
    public partial class InvoiceLineLot
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0819";

        #region Properties

        /// <summary>
        /// Contains list of InvoiceLineLot Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for InvoiceSequenceKey
            /// </summary>
            public const string InvoiceSequenceKey = "INVHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "INVLREV";

            /// <summary>
            /// Property for LotNumber
            /// </summary>
            public const string LotNumber = "LOTNUMF";

            /// <summary>
            /// Property for InvoiceLineSequence
            /// </summary>
            public const string InvoiceLineSequence = "INVLSEQ";

            /// <summary>
            /// Property for ExpiryDate
            /// </summary>
            public const string ExpiryDate = "EXPIRYDATE";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "QTY";

            /// <summary>
            /// Property for LotStockQuantity
            /// </summary>
            public const string LotStockQuantity = "QTYSQ";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoiceLineLot Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for LotNumber
            /// </summary>
            public const int LotNumber = 3;

            /// <summary>
            /// Property Indexer for InvoiceLineSequence
            /// </summary>
            public const int InvoiceLineSequence = 4;

            /// <summary>
            /// Property Indexer for ExpiryDate
            /// </summary>
            public const int ExpiryDate = 5;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 6;

            /// <summary>
            /// Property Indexer for LotStockQuantity
            /// </summary>
            public const int LotStockQuantity = 7;
        }

        #endregion
    }
}
