// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

#region Namespaces
using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of ICOptions Constants
    /// </summary>
    public partial class ICOptions
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0121";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
                {
                    {"FRACTQTY", "FractionalQuantities"},
                    {"MULTICURR", "Multicurrency"},
                    {"HYHEN", "UseHyhenAsItemSeparator"},
                    {"FWDSLASH", "UseForwardSlashAsItemSepara"},
                    {"BCKSLASH", "UseBackSlashAsItemSeparator"},
                    {"ASTERISK", "UseAsteriskAsItemSeparator"},
                    {"PERIOD", "UsePeriodAsItemSeparator"},
                    {"LFTPARENS", "UseLeftParenthesisAsItemSep"},
                    {"RGTPARENS", "UseRightParenthesisAsItemSe"},
                    {"POUNDSGN", "UsePoundSignAsItemSeparator"},
                    {"RECNONSTK", "AllowReceiptOfNonStockItems"},
                    {"DELPROMPT", "PromptToDeleteDuringPosting"},
                    {"DEFUOM", "OnlyUseDefinedUOM"},
                    {"SHYPHEN", "SerialsHyphenAsSeparator"},
                    {"SFWDSLASH", "SerialsFwdSlashAsSeparator"},
                    {"SBCKSLASH", "SerialsBackSlashAsSeparator"},
                    {"SASTERISK", "SerialsAsteriskAsSeparator"},
                    {"SPERIOD", "SerialsPeriodAsSeparator"},
                    {"SLFPARENS", "SerialsLeftParenthesisAsSep"},
                    {"SRGTPARENS", "SerialsRightParenthesisAsSep"},
                    {"SPOUNDSIGN", "SerialsPoundSignAsSeparator"},
                    {"SLFBRACKT", "SerialsLeftBracketAsSep"},
                    {"SRGTBRACKT", "SerialsRightBracketAsSep"},
                    {"SLFBRACE", "SerialsLeftBraceAsSep"},
                    {"SRGTBRACE", "SerialsRightBraceAsSep"},
                    {"LOTMASK", "LotNumberMask"},
                    {"LHYPHEN", "LotsHyphenAsSeparator"},
                    {"LFWDSLASH", "LotsFwdSlashAsSeparator"},
                    {"LBCKSLASH", "LotsBackSlashAsSeparator"},
                    {"LASTERISK", "LotsAsteriskAsSeparator"},
                    {"LPERIOD", "LotsPeriodAsSeparator"},
                    {"LLFPARENS", "LotsLeftParenthesisAsSep"},
                    {"LRGTPARENS", "LotsRightParenthesisAsSep"},
                    {"LPOUNDSIGN", "LotsPoundSignAsSeparator"},
                    {"LLFBRACKT", "LotsLeftBracketAsSeparator"},
                    {"LRGTBRACKT", "LotsRightBracketAsSeparator"},
                    {"LLFBRACE", "LotsLeftBraceAsSeparator"},
                    {"LRGTBRACE", "LotsRightBraceAsSeparator"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of ICOptions Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for DummyField
            /// </summary>
            public const string DummyField = "DUMMY";

            /// <summary>
            /// Property for ContactName
            /// </summary>
            public const string ContactName = "CONTACT";

            /// <summary>
            /// Property for PhoneNumber
            /// </summary>
            public const string PhoneNumber = "PHONE";

            /// <summary>
            /// Property for FaxNumber
            /// </summary>
            public const string FaxNumber = "FAX";

            /// <summary>
            /// Property for FractionalQuantities
            /// </summary>
            public const string FractionalQuantities = "FRACTQTY";

            /// <summary>
            /// Property for AllowNegativeQuantities
            /// </summary>
            public const string AllowNegativeQuantities = "NEGQTY";

            /// <summary>
            /// Property for KeepTransactionHistory
            /// </summary>
            public const string KeepTransactionHistory = "TRANSHIST";

            /// <summary>
            /// Property for InterfaceWithJobCost
            /// </summary>
            public const string InterfaceWithJobCost = "JOBCOST";

            /// <summary>
            /// Property for GLReferenceField
            /// </summary>
            public const string GLReferenceField = "REFCHOICE";

            /// <summary>
            /// Property for GLDescriptionField
            /// </summary>
            public const string GLDescriptionField = "DESCCHOICE";

            /// <summary>
            /// Property for DefaultWeightUnitOfMeasure
            /// </summary>
            public const string DefaultWeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for Cost1Name
            /// </summary>
            public const string Cost1Name = "COST1NAME";

            /// <summary>
            /// Property for Cost2Name
            /// </summary>
            public const string Cost2Name = "COST2NAME";

            /// <summary>
            /// Property for DayEndTransactionsOutstanding
            /// </summary>
            public const string DayEndTransactionsOutstanding = "DAYEND";

            /// <summary>
            /// Property for NextTransactionNumber
            /// </summary>
            public const string NextTransactionNumber = "TRANSNUM";

            /// <summary>
            /// Property for NextAlternateItemSetNumber
            /// </summary>
            public const string NextAlternateItemSetNumber = "NXTALTSET";

            /// <summary>
            /// Property for GLTransCreatedThruDayEnd
            /// </summary>
            public const string GLTransCreatedThruDayEnd = "GLDAYEND";

            /// <summary>
            /// Property for NextAdjustmentEntrySequence
            /// </summary>
            public const string NextAdjustmentEntrySequence = "ADJENSEQ";

            /// <summary>
            /// Property for NextAssemblyEntrySequence
            /// </summary>
            public const string NextAssemblyEntrySequence = "ASSMENSEQ";

            /// <summary>
            /// Property for NextReceiptEntrySequence
            /// </summary>
            public const string NextReceiptEntrySequence = "RECENSEQ";

            /// <summary>
            /// Property for NextShipmentEntrySequence
            /// </summary>
            public const string NextShipmentEntrySequence = "SHIPENSEQ";

            /// <summary>
            /// Property for NextTransferEntrySequence
            /// </summary>
            public const string NextTransferEntrySequence = "TRANFENSEQ";

            /// <summary>
            /// Property for NextHistoryEntrySequence
            /// </summary>
            public const string NextHistoryEntrySequence = "HISTENSEQ";

            /// <summary>
            /// Property for NextDayEndPostingSequence
            /// </summary>
            public const string NextDayEndPostingSequence = "DAYENDSEQ";

            /// <summary>
            /// Property for Multicurrency
            /// </summary>
            public const string Multicurrency = "MULTICURR";

            /// <summary>
            /// Property for DeferredGLPosting
            /// </summary>
            public const string DeferredGLPosting = "DEFERGLPST";

            /// <summary>
            /// Property for AppendToGLBatch
            /// </summary>
            public const string AppendToGLBatch = "APPENDGL";

            /// <summary>
            /// Property for ConsolidateGLBatch
            /// </summary>
            public const string ConsolidateGLBatch = "CONSOLGL";

            /// <summary>
            /// Property for StatisticsCalendar
            /// </summary>
            public const string StatisticsCalendar = "STATCALNDR";

            /// <summary>
            /// Property for StatisticsPeriod
            /// </summary>
            public const string StatisticsPeriod = "STATPRD";

            /// <summary>
            /// Property for EditStatistics
            /// </summary>
            public const string EditStatistics = "STATEDIT";

            /// <summary>
            /// Property for AllowItemsAtAllLocations
            /// </summary>
            public const string AllowItemsAtAllLocations = "CRTITEMLOC";

            /// <summary>
            /// Property for AdditionalCostOnReceiptReturns
            /// </summary>
            public const string AdditionalCostOnReceiptReturns = "ADDCSTTYPE";

            /// <summary>
            /// Property for DefaultRateType
            /// </summary>
            public const string DefaultRateType = "RATETYPE";

            /// <summary>
            /// Property for DefaultItemStructure
            /// </summary>
            public const string DefaultItemStructure = "ITEMBRKID";

            /// <summary>
            /// Property for AccumulateItemStatistics
            /// </summary>
            public const string AccumulateItemStatistics = "STATACCUM";

            /// <summary>
            /// Property for PostToClosedFiscalPeriods
            /// </summary>
            public const string PostToClosedFiscalPeriods = "PSTTOCLOSD";

            /// <summary>
            /// Property for PeriodType
            /// </summary>
            public const string PeriodType = "PERIODTYPE";

            /// <summary>
            /// Property for PeriodLength
            /// </summary>
            public const string PeriodLength = "PERIODLENG";

            /// <summary>
            /// Property for FractionalQuantityDecimals
            /// </summary>
            public const string FractionalQuantityDecimals = "FRACTDEC";

            /// <summary>
            /// Property for ConversionFactorDecimals
            /// </summary>
            public const string ConversionFactorDecimals = "FACTORDEC";

            /// <summary>
            /// Property for StatisticalPeriods
            /// </summary>
            public const string StatisticalPeriods = "STATPRDS";

            /// <summary>
            /// Property for UseHyhenAsItemSeparator
            /// </summary>
            public const string UseHyhenAsItemSeparator = "HYHEN";

            /// <summary>
            /// Property for UseForwardSlashAsItemSepara
            /// </summary>
            public const string UseForwardSlashAsItemSepara = "FWDSLASH";

            /// <summary>
            /// Property for UseBackSlashAsItemSeparator
            /// </summary>
            public const string UseBackSlashAsItemSeparator = "BCKSLASH";

            /// <summary>
            /// Property for UseAsteriskAsItemSeparator
            /// </summary>
            public const string UseAsteriskAsItemSeparator = "ASTERISK";

            /// <summary>
            /// Property for UsePeriodAsItemSeparator
            /// </summary>
            public const string UsePeriodAsItemSeparator = "PERIOD";

            /// <summary>
            /// Property for UseLeftParenthesisAsItemSep
            /// </summary>
            public const string UseLeftParenthesisAsItemSep = "LFTPARENS";

            /// <summary>
            /// Property for UseRightParenthesisAsItemSe
            /// </summary>
            public const string UseRightParenthesisAsItemSe = "RGTPARENS";

            /// <summary>
            /// Property for UsePoundSignAsItemSeparator
            /// </summary>
            public const string UsePoundSignAsItemSeparator = "POUNDSGN";

            /// <summary>
            /// Property for AllowReceiptOfNonStockItems
            /// </summary>
            public const string AllowReceiptOfNonStockItems = "RECNONSTK";

            /// <summary>
            /// Property for PromptToDeleteDuringPosting
            /// </summary>
            public const string PromptToDeleteDuringPosting = "DELPROMPT";

            /// <summary>
            /// Property for CostDuring
            /// </summary>
            public const string CostDuring = "COSTDURING";

            /// <summary>
            /// Property for AssemblyNumberLength
            /// </summary>
            public const string AssemblyNumberLength = "ASSNUMBERL";

            /// <summary>
            /// Property for AssemblyNumberPrefix
            /// </summary>
            public const string AssemblyNumberPrefix = "ASSPREFIXD";

            /// <summary>
            /// Property for NextAssemblyNumberDescription
            /// </summary>
            public const string NextAssemblyNumberDescription = "ASSBODYD";

            /// <summary>
            /// Property for DisassemblyNumberLength
            /// </summary>
            public const string DisassemblyNumberLength = "DASNUMBERL";

            /// <summary>
            /// Property for DisassemblyNumberPrefix
            /// </summary>
            public const string DisassemblyNumberPrefix = "DASPREFIXD";

            /// <summary>
            /// Property for NextDisassemblyNumberDescription
            /// </summary>
            public const string NextDisassemblyNumberDescription = "DASBODYD";

            /// <summary>
            /// Property for TransferNumberLength
            /// </summary>
            public const string TransferNumberLength = "TRFNUMBERL";

            /// <summary>
            /// Property for TransferNumberPrefix
            /// </summary>
            public const string TransferNumberPrefix = "TRFPREFIXD";

            /// <summary>
            /// Property for NextTransferNumberDescription
            /// </summary>
            public const string NextTransferNumberDescription = "TRFBODYD";

            /// <summary>
            /// Property for AdjustmentNumberLength
            /// </summary>
            public const string AdjustmentNumberLength = "ADJNUMBERL";

            /// <summary>
            /// Property for AdjustmentNumberPrefix
            /// </summary>
            public const string AdjustmentNumberPrefix = "ADJPREFIXD";

            /// <summary>
            /// Property for NextAdjustmentNumberDescription
            /// </summary>
            public const string NextAdjustmentNumberDescription = "ADJBODYD";

            /// <summary>
            /// Property for ShipmentNumberLength
            /// </summary>
            public const string ShipmentNumberLength = "SHPNUMBERL";

            /// <summary>
            /// Property for ShipmentNumberPrefix
            /// </summary>
            public const string ShipmentNumberPrefix = "SHPPREFIXD";

            /// <summary>
            /// Property for NextShipmentNumberDescription
            /// </summary>
            public const string NextShipmentNumberDescription = "SHPBODYD";

            /// <summary>
            /// Property for ShipmentReturnNumberLength
            /// </summary>
            public const string ShipmentReturnNumberLength = "SRTNUMBERL";

            /// <summary>
            /// Property for ShipmentReturnNumberPrefix
            /// </summary>
            public const string ShipmentReturnNumberPrefix = "SRTPREFIXD";

            /// <summary>
            /// Property for NextShipmentReturnNumberDescription
            /// </summary>
            public const string NextShipmentReturnNumberDescription = "SRTBODYD";

            /// <summary>
            /// Property for ReceiptNumberLength
            /// </summary>
            public const string ReceiptNumberLength = "RCPNUMBERL";

            /// <summary>
            /// Property for ReceiptNumberPrefix
            /// </summary>
            public const string ReceiptNumberPrefix = "RCPPREFIXD";

            /// <summary>
            /// Property for NextReceiptNumberDescription
            /// </summary>
            public const string NextReceiptNumberDescription = "RCPBODYD";

            /// <summary>
            /// Property for TransitReceiptNumberLength
            /// </summary>
            public const string TransitReceiptNumberLength = "TRCNUMBERL";

            /// <summary>
            /// Property for TransitReceiptNumberPrefix
            /// </summary>
            public const string TransitReceiptNumberPrefix = "TRCPREFIXD";

            /// <summary>
            /// Property for NextTransitReceiptNumberDescription
            /// </summary>
            public const string NextTransitReceiptNumberDescription = "TRCBODYD";

            /// <summary>
            /// Property for NextNonCostedReceiptDayEnd
            /// </summary>
            public const string NextNonCostedReceiptDayEnd = "RECDESEQ";

            /// <summary>
            /// Property for SeparatorHyhen
            /// </summary>
            public const string SeparatorHyhen = "SPHYHEN";

            /// <summary>
            /// Property for SeparatorForwardSlash
            /// </summary>
            public const string SeparatorForwardSlash = "SPFWDSLASH";

            /// <summary>
            /// Property for SeparatorBackSlash
            /// </summary>
            public const string SeparatorBackSlash = "SPBCKSLASH";

            /// <summary>
            /// Property for SeparatorAsterisk
            /// </summary>
            public const string SeparatorAsterisk = "SPASTERISK";

            /// <summary>
            /// Property for SeparatorPeriod
            /// </summary>
            public const string SeparatorPeriod = "SPPERIOD";

            /// <summary>
            /// Property for SeparatorLeftParenthesis
            /// </summary>
            public const string SeparatorLeftParenthesis = "SPLPARENS";

            /// <summary>
            /// Property for SeparatorRightParenthesis
            /// </summary>
            public const string SeparatorRightParenthesis = "SPRPARENS";

            /// <summary>
            /// Property for SeparatorNumberSign
            /// </summary>
            public const string SeparatorNumberSign = "SPPOUNDSGN";

            /// <summary>
            /// Property for HomeCurrency
            /// </summary>
            public const string HomeCurrency = "HOMECURR";

            /// <summary>
            /// Property for DefaultAssemblyNumber
            /// </summary>
            public const string DefaultAssemblyNumber = "ASSDEFAULT";

            /// <summary>
            /// Property for NextAssemblyNumber
            /// </summary>
            public const string NextAssemblyNumber = "ASSVALUE";

            /// <summary>
            /// Property for DefaultDisassemblyNumber
            /// </summary>
            public const string DefaultDisassemblyNumber = "DASDEFAULT";

            /// <summary>
            /// Property for NextDisassemblyNumber
            /// </summary>
            public const string NextDisassemblyNumber = "DASVALUE";

            /// <summary>
            /// Property for DefaultTransferNumber
            /// </summary>
            public const string DefaultTransferNumber = "TRFDEFAULT";

            /// <summary>
            /// Property for NextTransferNumber
            /// </summary>
            public const string NextTransferNumber = "TRFVALUE";

            /// <summary>
            /// Property for DefaultAdjustmentNumber
            /// </summary>
            public const string DefaultAdjustmentNumber = "ADJDEFAULT";

            /// <summary>
            /// Property for NextAdjustmentValue
            /// </summary>
            public const string NextAdjustmentValue = "ADJVALUE";

            /// <summary>
            /// Property for DefaultShipmentNumber
            /// </summary>
            public const string DefaultShipmentNumber = "SHPDEFAULT";

            /// <summary>
            /// Property for NextShipmentNumber
            /// </summary>
            public const string NextShipmentNumber = "SHPVALUE";

            /// <summary>
            /// Property for DefaultShipmentReturnNumber
            /// </summary>
            public const string DefaultShipmentReturnNumber = "SRTDEFAULT";

            /// <summary>
            /// Property for NextShipmentReturnNumber
            /// </summary>
            public const string NextShipmentReturnNumber = "SRTVALUE";

            /// <summary>
            /// Property for DefaultReceiptNumber
            /// </summary>
            public const string DefaultReceiptNumber = "RCPDEFAULT";

            /// <summary>
            /// Property for NextReceiptNumber
            /// </summary>
            public const string NextReceiptNumber = "RCPVALUE";

            /// <summary>
            /// Property for DefaultTransitReceiptNumber
            /// </summary>
            public const string DefaultTransitReceiptNumber = "TRCDEFAULT";

            /// <summary>
            /// Property for NextTransitReceiptNumber
            /// </summary>
            public const string NextTransitReceiptNumber = "TRCVALUE";

            /// <summary>
            /// Property for DefaultGoodsInTransitLocatio
            /// </summary>
            public const string DefaultGoodsInTransitLocatio = "GITLOC";

            /// <summary>
            /// Property for TransitLocationDescription
            /// </summary>
            public const string TransitLocationDescription = "GITLOCDESC";

            /// <summary>
            /// Property for OnlyUseDefinedUOM
            /// </summary>
            public const string OnlyUseDefinedUOM = "DEFUOM";

            /// <summary>
            /// Property for AgingPeriod1
            /// </summary>
            public const string AgingPeriod1 = "AGING1";

            /// <summary>
            /// Property for AgingPeriod2
            /// </summary>
            public const string AgingPeriod2 = "AGING2";

            /// <summary>
            /// Property for AgingPeriod3
            /// </summary>
            public const string AgingPeriod3 = "AGING3";

            /// <summary>
            /// Property for CreateSubledgerAuditDuring
            /// </summary>
            public const string CreateSubledgerAuditDuring = "SLAUDURING";

            /// <summary>
            /// Property for NextInternalUsageEntrySequence
            /// </summary>
            public const string NextInternalUsageEntrySequence = "ICSENSEQ";

            /// <summary>
            /// Property for InternalUsageNumberLength
            /// </summary>
            public const string InternalUsageNumberLength = "ICSNUMBERL";

            /// <summary>
            /// Property for InternalUsageNumberPrefix
            /// </summary>
            public const string InternalUsageNumberPrefix = "ICSPREFIXD";

            /// <summary>
            /// Property for NextInternalUsageNumberDescription
            /// </summary>
            public const string NextInternalUsageNumberDescription = "ICSBODYD";

            /// <summary>
            /// Property for DefaultInternalUsageNumber
            /// </summary>
            public const string DefaultInternalUsageNumber = "ICSDEFAULT";

            /// <summary>
            /// Property for NextInternalUsageNumber
            /// </summary>
            public const string NextInternalUsageNumber = "ICSVALUE";

            /// <summary>
            /// Property for TransactionPostDepCost
            /// </summary>
            public const string TransactionPostDepCost = "TPOSTACTN";

            /// <summary>
            /// Property for ICReceipts
            /// </summary>
            public const string ICReceipts = "SRCTYPERC";

            /// <summary>
            /// Property for ICReceiptReturns
            /// </summary>
            public const string ICReceiptReturns = "SRCTYPERR";

            /// <summary>
            /// Property for ICReceiptAdjustments
            /// </summary>
            public const string ICReceiptAdjustments = "SRCTYPERA";

            /// <summary>
            /// Property for ICShipments
            /// </summary>
            public const string ICShipments = "SRCTYPESH";

            /// <summary>
            /// Property for ICShipmentReturns
            /// </summary>
            public const string ICShipmentReturns = "SRCTYPESR";

            /// <summary>
            /// Property for ICTransfers
            /// </summary>
            public const string ICTransfers = "SRCTYPETF";

            /// <summary>
            /// Property for ICAssemblies
            /// </summary>
            public const string ICAssemblies = "SRCTYPEAS";

            /// <summary>
            /// Property for ICAdjustments
            /// </summary>
            public const string ICAdjustments = "SRCTYPEAD";

            /// <summary>
            /// Property for ICConsolidatedEntry
            /// </summary>
            public const string ICConsolidatedEntry = "SRCTYPECO";

            /// <summary>
            /// Property for ICDisassemblies
            /// </summary>
            public const string ICDisassemblies = "SRCTYPEDA";

            /// <summary>
            /// Property for ICInternalUsage
            /// </summary>
            public const string ICInternalUsage = "SRCTYPEIN";

            /// <summary>
            /// Property for DefaultPostingDate
            /// </summary>
            public const string DefaultPostingDate = "DATEBUSDFT";

            /// <summary>
            /// Property for SerialNumberMask
            /// </summary>
            public const string SerialNumberMask = "SERIALMASK";

            /// <summary>
            /// Property for UseSerialsDaysToExpire
            /// </summary>
            public const string UseSerialsDaysToExpire = "SUSEEXPDAY";

            /// <summary>
            /// Property for SerialsDaysToExpire
            /// </summary>
            public const string SerialsDaysToExpire = "SEXPDAYS";

            /// <summary>
            /// Property for AllowDifferentSerialQty
            /// </summary>
            public const string AllowDifferentSerialQty = "SDIFQTYOK";

            /// <summary>
            /// Property for AllowSerialAllocOnQtyOrdered
            /// </summary>
            public const string AllowSerialAllocOnQtyOrdered = "SALCQTYORD";

            /// <summary>
            /// Property for SortSerialsBy
            /// </summary>
            public const string SortSerialsBy = "SSORTBY";

            /// <summary>
            /// Property for SortSerialsFirstBy
            /// </summary>
            public const string SortSerialsFirstBy = "SFIRST";

            /// <summary>
            /// Property for StopAllocationOfExpiredSeria
            /// </summary>
            public const string StopAllocationOfExpiredSeria = "SEXPLEVEL";

            /// <summary>
            /// Property for SerialsHyphenAsSeparator
            /// </summary>
            public const string SerialsHyphenAsSeparator = "SHYPHEN";

            /// <summary>
            /// Property for SerialsFwdSlashAsSeparator
            /// </summary>
            public const string SerialsFwdSlashAsSeparator = "SFWDSLASH";

            /// <summary>
            /// Property for SerialsBackSlashAsSeparator
            /// </summary>
            public const string SerialsBackSlashAsSeparator = "SBCKSLASH";

            /// <summary>
            /// Property for SerialsAsteriskAsSeparator
            /// </summary>
            public const string SerialsAsteriskAsSeparator = "SASTERISK";

            /// <summary>
            /// Property for SerialsPeriodAsSeparator
            /// </summary>
            public const string SerialsPeriodAsSeparator = "SPERIOD";

            /// <summary>
            /// Property for SerialsLeftParenthesisAsSep
            /// </summary>
            public const string SerialsLeftParenthesisAsSep = "SLFPARENS";

            /// <summary>
            /// Property for SerialsRightParenthesisAsSep
            /// </summary>
            public const string SerialsRightParenthesisAsSep = "SRGTPARENS";

            /// <summary>
            /// Property for SerialsPoundSignAsSeparator
            /// </summary>
            public const string SerialsPoundSignAsSeparator = "SPOUNDSIGN";

            /// <summary>
            /// Property for SerialsLeftBracketAsSep
            /// </summary>
            public const string SerialsLeftBracketAsSep = "SLFBRACKT";

            /// <summary>
            /// Property for SerialsRightBracketAsSep
            /// </summary>
            public const string SerialsRightBracketAsSep = "SRGTBRACKT";

            /// <summary>
            /// Property for SerialsLeftBraceAsSep
            /// </summary>
            public const string SerialsLeftBraceAsSep = "SLFBRACE";

            /// <summary>
            /// Property for SerialsRightBraceAsSep
            /// </summary>
            public const string SerialsRightBraceAsSep = "SRGTBRACE";

            /// <summary>
            /// Property for LotNumberMask
            /// </summary>
            public const string LotNumberMask = "LOTMASK";

            /// <summary>
            /// Property for UseLotsDaysToExpire
            /// </summary>
            public const string UseLotsDaysToExpire = "LUSEEXPDAY";

            /// <summary>
            /// Property for LotsDaysToExpire
            /// </summary>
            public const string LotsDaysToExpire = "LEXPDAYS";

            /// <summary>
            /// Property for UseLotsDaysOnQuarantine
            /// </summary>
            public const string UseLotsDaysOnQuarantine = "LUSEQRNDAY";

            /// <summary>
            /// Property for LotsDaysOnQuarantine
            /// </summary>
            public const string LotsDaysOnQuarantine = "LQRNDAYS";

            /// <summary>
            /// Property for AllowDifferentLotQty
            /// </summary>
            public const string AllowDifferentLotQty = "LDIFQTYOK";

            /// <summary>
            /// Property for AllowLotAllocOnQtyOrdered
            /// </summary>
            public const string AllowLotAllocOnQtyOrdered = "LALCQTYORD";

            /// <summary>
            /// Property for SortLotsBy
            /// </summary>
            public const string SortLotsBy = "LSORTBY";

            /// <summary>
            /// Property for SortLotsFirstBy
            /// </summary>
            public const string SortLotsFirstBy = "LFIRST";

            /// <summary>
            /// Property for StopAllocationOfExpiredLots
            /// </summary>
            public const string StopAllocationOfExpiredLots = "LEXPLEVEL";

            /// <summary>
            /// Property for LotsHyphenAsSeparator
            /// </summary>
            public const string LotsHyphenAsSeparator = "LHYPHEN";

            /// <summary>
            /// Property for LotsFwdSlashAsSeparator
            /// </summary>
            public const string LotsFwdSlashAsSeparator = "LFWDSLASH";

            /// <summary>
            /// Property for LotsBackSlashAsSeparator
            /// </summary>
            public const string LotsBackSlashAsSeparator = "LBCKSLASH";

            /// <summary>
            /// Property for LotsAsteriskAsSeparator
            /// </summary>
            public const string LotsAsteriskAsSeparator = "LASTERISK";

            /// <summary>
            /// Property for LotsPeriodAsSeparator
            /// </summary>
            public const string LotsPeriodAsSeparator = "LPERIOD";

            /// <summary>
            /// Property for LotsLeftParenthesisAsSepNextRecallNumber
            /// </summary>
            public const string LotsLeftParenthesisAsSep = "LLFPARENS";

            /// <summary>
            /// Property for LotsRightParenthesisAsSep
            /// </summary>
            public const string LotsRightParenthesisAsSep = "LRGTPARENS";

            /// <summary>
            /// Property for LotsPoundSignAsSeparator
            /// </summary>
            public const string LotsPoundSignAsSeparator = "LPOUNDSIGN";

            /// <summary>
            /// Property for LotsLeftBracketAsSeparator
            /// </summary>
            public const string LotsLeftBracketAsSeparator = "LLFBRACKT";

            /// <summary>
            /// Property for LotsRightBracketAsSeparator
            /// </summary>
            public const string LotsRightBracketAsSeparator = "LRGTBRACKT";

            /// <summary>
            /// Property for LotsLeftBraceAsSeparator
            /// </summary>
            public const string LotsLeftBraceAsSeparator = "LLFBRACE";

            /// <summary>
            /// Property for LotsRightBraceAsSeparator
            /// </summary>
            public const string LotsRightBraceAsSeparator = "LRGTBRACE";

            /// <summary>
            /// Property for RecallReleaseSequenceNumber
            /// </summary>
            public const string RecallReleaseSequenceNumber = "RECALENSEQ";

            /// <summary>
            /// Property for RecallNumberLength
            /// </summary>
            public const string RecallNumberLength = "RECNUMBERL";

            /// <summary>
            /// Property for RecallNumberPrefix
            /// </summary>
            public const string RecallNumberPrefix = "RECPREFIXD";

            /// <summary>
            /// Property for NextRecallNumberDescription
            /// </summary>
            public const string NextRecallNumberDescription = "RECBODYD";

            /// <summary>
            /// Property for DefaultRecallNumber
            /// </summary>
            public const string DefaultRecallNumber = "RECDEFAULT";

            /// <summary>
            /// Property for NextRecallNumber
            /// </summary>
            public const string NextRecallNumber = "RECVALUE";

            /// <summary>
            /// Property for ReleaseNumberLength
            /// </summary>
            public const string ReleaseNumberLength = "RELNUMBERL";

            /// <summary>
            /// Property for ReleaseNumberPrefix
            /// </summary>
            public const string ReleaseNumberPrefix = "RELPREFIXD";

            /// <summary>
            /// Property for NextReleaseNumberDescription
            /// </summary>
            public const string NextReleaseNumberDescription = "RELBODYD";

            /// <summary>
            /// Property for DefaultReleaseNumber
            /// </summary>
            public const string DefaultReleaseNumber = "RELDEFAULT";

            /// <summary>
            /// Property for NextReleaseNumber
            /// </summary>
            public const string NextReleaseNumber = "RELVALUE";

            /// <summary>
            /// Property for CombineSplitSequenceNumber
            /// </summary>
            public const string CombineSplitSequenceNumber = "COMENSEQ";

            /// <summary>
            /// Property for CombineNumberLength
            /// </summary>
            public const string CombineNumberLength = "COMNUMBERL";

            /// <summary>
            /// Property for CombineNumberPrefix
            /// </summary>
            public const string CombineNumberPrefix = "COMPREFIXD";

            /// <summary>
            /// Property for NextCombineNumberDescription
            /// </summary>
            public const string NextCombineNumberDescription = "COMBODYD";

            /// <summary>
            /// Property for DefaultCombineNumber
            /// </summary>
            public const string DefaultCombineNumber = "COMDEFAULT";

            /// <summary>
            /// Property for NextCombineNumber
            /// </summary>
            public const string NextCombineNumber = "COMVALUE";

            /// <summary>
            /// Property for SplitNumberLength
            /// </summary>
            public const string SplitNumberLength = "SPLNUMBERL";

            /// <summary>
            /// Property for SplitNumberPrefix
            /// </summary>
            public const string SplitNumberPrefix = "SPLPREFIXD";

            /// <summary>
            /// Property for NextSplitNumberDescription
            /// </summary>
            public const string NextSplitNumberDescription = "SPLBODYD";

            /// <summary>
            /// Property for DefaultSplitNumber
            /// </summary>
            public const string DefaultSplitNumber = "SPLDEFAULT";

            /// <summary>
            /// Property for NextSplitNumber
            /// </summary>
            public const string NextSplitNumber = "SPLVALUE";

            /// <summary>
            /// Property for ReconciliationSequenceNumber
            /// </summary>
            public const string ReconciliationSequenceNumber = "RCNENSEQ";

            /// <summary>
            /// Property for ReconciliationNumberLength
            /// </summary>
            public const string ReconciliationNumberLength = "RCNNUMBERL";

            /// <summary>
            /// Property for ReconciliationNumberPrefix
            /// </summary>
            public const string ReconciliationNumberPrefix = "RCNPREFIXD";

            /// <summary>
            /// Property for NextReconciliationNumberDescription
            /// </summary>
            public const string NextReconciliationNumberDescription = "RCNBODYD";

            /// <summary>
            /// Property for DefaultReconciliationNumber
            /// </summary>
            public const string DefaultReconciliationNumber = "RCNDEFAULT";

            /// <summary>
            /// Property for NextReconciliationNumber
            /// </summary>
            public const string NextReconciliationNumber = "RCNVALUE";

            /// <summary>
            /// Property for SeparatorLeftBracket
            /// </summary>
            public const string SeparatorLeftBracket = "SPLBRACKET";

            /// <summary>
            /// Property for SeparatorRightBracket
            /// </summary>
            public const string SeparatorRightBracket = "SPRBRACKET";

            /// <summary>
            /// Property for SeparatorLeftBrace
            /// </summary>
            public const string SeparatorLeftBrace = "SPLBRACE";

            /// <summary>
            /// Property for SeparatorRightBrace
            /// </summary>
            public const string SeparatorRightBrace = "SPRBRACE";

            /// <summary>
            /// Property for AllowDuplicateSerials
            /// </summary>
            public const string AllowDuplicateSerials = "DUPSERIALS";

            /// <summary>
            /// Property for SalesStatsPeriodsToUse
            /// </summary>
            public const string SalesStatsPeriodsToUse = "SALESPERDS";

            /// <summary>
            /// Property for UpdateLocationDetailsMinQty
            /// </summary>
            public const string UpdateLocationDetailsMinQty = "UPDTMINREQ";

            /// <summary>
            /// Property for MinimumQuantityMarginFactor
            /// </summary>
            public const string MinimumQuantityMarginFactor = "MINFACTOR";

            /// <summary>
            /// Property for MaximumQuantityMarginFactor
            /// </summary>
            public const string MaximumQuantityMarginFactor = "MAXFACTOR";

            /// <summary>
            /// Property for HighlightSalesVarianceAbove
            /// </summary>
            public const string HighlightSalesVarianceAbove = "SALESHL";

            /// <summary>
            /// Property for HighlightTrendVarianceAbove
            /// </summary>
            public const string HighlightTrendVarianceAbove = "TRENDHL";

            /// <summary>
            /// Property for HighlightMinMaxVarianceAbove
            /// </summary>
            public const string HighlightMinMaxVarianceAbove = "MINMAXHL";

            /// <summary>
            /// Property for DefaultNumberDaysForExpiry
            /// </summary>
            public const string DefaultNumberDaysForExpiry = "CMNTDAYS";

            /// <summary>
            /// Property for DefaultNumberDaysForFollowUp
            /// </summary>
            public const string DefaultNumberDaysForFollowUp = "FLUPDAYS";

            /// <summary>
            /// Property for DefaultCommentType
            /// </summary>
            public const string DefaultCommentType = "CMNTTYPE";

            /// <summary>
            /// Property for AllowBlankCommentType
            /// </summary>
            public const string AllowBlankCommentType = "SWCMNTTYPE";

            /// <summary>
            /// Property for UTCDateLastDayEnd
            /// </summary>
            public const string UTCDateLastDayEnd = "DLASTDEP";

            /// <summary>
            /// Property for UTCTimeLastDayEnd
            /// </summary>
            public const string UTCTimeLastDayEnd = "TLASTDEP";

            /// <summary>
            /// Property for LocalDateLastDayEnd
            /// </summary>
            public const string LocalDateLastDayEnd = "LODLASTDEP";

            /// <summary>
            /// Property for LocalTimeLastDayEnd
            /// </summary>
            public const string LocalTimeLastDayEnd = "LOTLASTDEP";
        }

        #endregion
        #region Properties

        /// <summary>
        /// Contains list of ICOptions Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for DummyField
            /// </summary>
            public const int DummyField = 1;

            /// <summary>
            /// Property Indexer for ContactName
            /// </summary>
            public const int ContactName = 2;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 3;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 4;

            /// <summary>
            /// Property Indexer for FractionalQuantities
            /// </summary>
            public const int FractionalQuantities = 5;

            /// <summary>
            /// Property Indexer for AllowNegativeQuantities
            /// </summary>
            public const int AllowNegativeQuantities = 6;

            /// <summary>
            /// Property Indexer for KeepTransactionHistory
            /// </summary>
            public const int KeepTransactionHistory = 7;

            /// <summary>
            /// Property Indexer for InterfaceWithJobCost
            /// </summary>
            public const int InterfaceWithJobCost = 8;

            /// <summary>
            /// Property Indexer for GLReferenceField
            /// </summary>
            public const int GLReferenceField = 9;

            /// <summary>
            /// Property Indexer for GLDescriptionField
            /// </summary>
            public const int GLDescriptionField = 10;

            /// <summary>
            /// Property Indexer for DefaultWeightUnitOfMeasure
            /// </summary>
            public const int DefaultWeightUnitOfMeasure = 11;

            /// <summary>
            /// Property Indexer for Cost1Name
            /// </summary>
            public const int Cost1Name = 12;

            /// <summary>
            /// Property Indexer for Cost2Name
            /// </summary>
            public const int Cost2Name = 13;

            /// <summary>
            /// Property Indexer for DayEndTransactionsOutstanding
            /// </summary>
            public const int DayEndTransactionsOutstanding = 14;

            /// <summary>
            /// Property Indexer for NextTransactionNumber
            /// </summary>
            public const int NextTransactionNumber = 15;

            /// <summary>
            /// Property Indexer for NextAlternateItemSetNumber
            /// </summary>
            public const int NextAlternateItemSetNumber = 16;

            /// <summary>
            /// Property Indexer for GLTransCreatedThruDayEnd
            /// </summary>
            public const int GLTransCreatedThruDayEnd = 17;

            /// <summary>
            /// Property Indexer for NextAdjustmentEntrySequence
            /// </summary>
            public const int NextAdjustmentEntrySequence = 18;

            /// <summary>
            /// Property Indexer for NextAssemblyEntrySequence
            /// </summary>
            public const int NextAssemblyEntrySequence = 19;

            /// <summary>
            /// Property Indexer for NextReceiptEntrySequence
            /// </summary>
            public const int NextReceiptEntrySequence = 20;

            /// <summary>
            /// Property Indexer for NextShipmentEntrySequence
            /// </summary>
            public const int NextShipmentEntrySequence = 21;

            /// <summary>
            /// Property Indexer for NextTransferEntrySequence
            /// </summary>
            public const int NextTransferEntrySequence = 22;

            /// <summary>
            /// Property Indexer for NextHistoryEntrySequence
            /// </summary>
            public const int NextHistoryEntrySequence = 23;

            /// <summary>
            /// Property Indexer for NextDayEndPostingSequence
            /// </summary>
            public const int NextDayEndPostingSequence = 24;

            /// <summary>
            /// Property Indexer for Multicurrency
            /// </summary>
            public const int Multicurrency = 25;

            /// <summary>
            /// Property Indexer for DeferredGLPosting
            /// </summary>
            public const int DeferredGLPosting = 26;

            /// <summary>
            /// Property Indexer for AppendToGLBatch
            /// </summary>
            public const int AppendToGLBatch = 27;

            /// <summary>
            /// Property Indexer for ConsolidateGLBatch
            /// </summary>
            public const int ConsolidateGLBatch = 28;

            /// <summary>
            /// Property Indexer for StatisticsCalendar
            /// </summary>
            public const int StatisticsCalendar = 29;

            /// <summary>
            /// Property Indexer for StatisticsPeriod
            /// </summary>
            public const int StatisticsPeriod = 30;

            /// <summary>
            /// Property Indexer for EditStatistics
            /// </summary>
            public const int EditStatistics = 31;

            /// <summary>
            /// Property Indexer for AllowItemsAtAllLocations
            /// </summary>
            public const int AllowItemsAtAllLocations = 54;

            /// <summary>
            /// Property Indexer for AdditionalCostOnReceiptReturns
            /// </summary>
            public const int AdditionalCostOnReceiptReturns = 55;

            /// <summary>
            /// Property Indexer for DefaultRateType
            /// </summary>
            public const int DefaultRateType = 56;

            /// <summary>
            /// Property Indexer for DefaultItemStructure
            /// </summary>
            public const int DefaultItemStructure = 57;

            /// <summary>
            /// Property Indexer for AccumulateItemStatistics
            /// </summary>
            public const int AccumulateItemStatistics = 58;

            /// <summary>
            /// Property Indexer for PostToClosedFiscalPeriods
            /// </summary>
            public const int PostToClosedFiscalPeriods = 59;

            /// <summary>
            /// Property Indexer for PeriodType
            /// </summary>
            public const int PeriodType = 60;

            /// <summary>
            /// Property Indexer for PeriodLength
            /// </summary>
            public const int PeriodLength = 61;

            /// <summary>
            /// Property Indexer for FractionalQuantityDecimals
            /// </summary>
            public const int FractionalQuantityDecimals = 62;

            /// <summary>
            /// Property Indexer for ConversionFactorDecimals
            /// </summary>
            public const int ConversionFactorDecimals = 63;

            /// <summary>
            /// Property Indexer for StatisticalPeriods
            /// </summary>
            public const int StatisticalPeriods = 64;

            /// <summary>
            /// Property Indexer for UseHyhenAsItemSeparator
            /// </summary>
            public const int UseHyhenAsItemSeparator = 65;

            /// <summary>
            /// Property Indexer for UseForwardSlashAsItemSepara
            /// </summary>
            public const int UseForwardSlashAsItemSepara = 66;

            /// <summary>
            /// Property Indexer for UseBackSlashAsItemSeparator
            /// </summary>
            public const int UseBackSlashAsItemSeparator = 67;

            /// <summary>
            /// Property Indexer for UseAsteriskAsItemSeparator
            /// </summary>
            public const int UseAsteriskAsItemSeparator = 68;

            /// <summary>
            /// Property Indexer for UsePeriodAsItemSeparator
            /// </summary>
            public const int UsePeriodAsItemSeparator = 69;

            /// <summary>
            /// Property Indexer for UseLeftParenthesisAsItemSep
            /// </summary>
            public const int UseLeftParenthesisAsItemSep = 70;

            /// <summary>
            /// Property Indexer for UseRightParenthesisAsItemSe
            /// </summary>
            public const int UseRightParenthesisAsItemSe = 71;

            /// <summary>
            /// Property Indexer for UsePoundSignAsItemSeparator
            /// </summary>
            public const int UsePoundSignAsItemSeparator = 72;

            /// <summary>
            /// Property Indexer for AllowReceiptOfNonStockItems
            /// </summary>
            public const int AllowReceiptOfNonStockItems = 73;

            /// <summary>
            /// Property Indexer for PromptToDeleteDuringPosting
            /// </summary>
            public const int PromptToDeleteDuringPosting = 74;

            /// <summary>
            /// Property Indexer for CostDuring
            /// </summary>
            public const int CostDuring = 75;

            /// <summary>
            /// Property Indexer for AssemblyNumberLength
            /// </summary>
            public const int AssemblyNumberLength = 76;

            /// <summary>
            /// Property Indexer for AssemblyNumberPrefix
            /// </summary>
            public const int AssemblyNumberPrefix = 77;

            /// <summary>
            /// Property Indexer for NextAssemblyNumberDescription
            /// </summary>
            public const int NextAssemblyNumberDescription = 78;

            /// <summary>
            /// Property Indexer for DisassemblyNumberLength
            /// </summary>
            public const int DisassemblyNumberLength = 79;

            /// <summary>
            /// Property Indexer for DisassemblyNumberPrefix
            /// </summary>
            public const int DisassemblyNumberPrefix = 80;

            /// <summary>
            /// Property Indexer for NextDisassemblyNumberDescription
            /// </summary>
            public const int NextDisassemblyNumberDescription = 81;

            /// <summary>
            /// Property Indexer for TransferNumberLength
            /// </summary>
            public const int TransferNumberLength = 82;

            /// <summary>
            /// Property Indexer for TransferNumberPrefix
            /// </summary>
            public const int TransferNumberPrefix = 83;

            /// <summary>
            /// Property Indexer for NextTransferNumberDescription
            /// </summary>
            public const int NextTransferNumberDescription = 84;

            /// <summary>
            /// Property Indexer for AdjustmentNumberLength
            /// </summary>
            public const int AdjustmentNumberLength = 85;

            /// <summary>
            /// Property Indexer for AdjustmentNumberPrefix
            /// </summary>
            public const int AdjustmentNumberPrefix = 86;

            /// <summary>
            /// Property Indexer for NextAdjustmentNumberDescription
            /// </summary>
            public const int NextAdjustmentNumberDescription = 87;

            /// <summary>
            /// Property Indexer for ShipmentNumberLength
            /// </summary>
            public const int ShipmentNumberLength = 88;

            /// <summary>
            /// Property Indexer for ShipmentNumberPrefix
            /// </summary>
            public const int ShipmentNumberPrefix = 89;

            /// <summary>
            /// Property Indexer for NextShipmentNumberDescription
            /// </summary>
            public const int NextShipmentNumberDescription = 90;

            /// <summary>
            /// Property Indexer for ShipmentReturnNumberLength
            /// </summary>
            public const int ShipmentReturnNumberLength = 91;

            /// <summary>
            /// Property Indexer for ShipmentReturnNumberPrefix
            /// </summary>
            public const int ShipmentReturnNumberPrefix = 92;

            /// <summary>
            /// Property Indexer for NextShipmentReturnNumberDescription
            /// </summary>
            public const int NextShipmentReturnNumberDescription = 93;

            /// <summary>
            /// Property Indexer for ReceiptNumberLength
            /// </summary>
            public const int ReceiptNumberLength = 94;

            /// <summary>
            /// Property Indexer for ReceiptNumberPrefix
            /// </summary>
            public const int ReceiptNumberPrefix = 95;

            /// <summary>
            /// Property Indexer for NextReceiptNumberDescription
            /// </summary>
            public const int NextReceiptNumberDescription = 96;

            /// <summary>
            /// Property Indexer for TransitReceiptNumberLength
            /// </summary>
            public const int TransitReceiptNumberLength = 97;

            /// <summary>
            /// Property Indexer for TransitReceiptNumberPrefix
            /// </summary>
            public const int TransitReceiptNumberPrefix = 98;

            /// <summary>
            /// Property Indexer for NextTransitReceiptNumberDescription
            /// </summary>
            public const int NextTransitReceiptNumberDescription = 99;

            /// <summary>
            /// Property Indexer for NextNonCostedReceiptDayEnd
            /// </summary>
            public const int NextNonCostedReceiptDayEnd = 100;

            /// <summary>
            /// Property Indexer for SeparatorHyhen
            /// </summary>
            public const int SeparatorHyhen = 106;

            /// <summary>
            /// Property Indexer for SeparatorForwardSlash
            /// </summary>
            public const int SeparatorForwardSlash = 107;

            /// <summary>
            /// Property Indexer for SeparatorBackSlash
            /// </summary>
            public const int SeparatorBackSlash = 108;

            /// <summary>
            /// Property Indexer for SeparatorAsterisk
            /// </summary>
            public const int SeparatorAsterisk = 109;

            /// <summary>
            /// Property Indexer for SeparatorPeriod
            /// </summary>
            public const int SeparatorPeriod = 110;

            /// <summary>
            /// Property Indexer for SeparatorLeftParenthesis
            /// </summary>
            public const int SeparatorLeftParenthesis = 111;

            /// <summary>
            /// Property Indexer for SeparatorRightParenthesis
            /// </summary>
            public const int SeparatorRightParenthesis = 112;

            /// <summary>
            /// Property Indexer for SeparatorNumberSign
            /// </summary>
            public const int SeparatorNumberSign = 113;

            /// <summary>
            /// Property Indexer for HomeCurrency
            /// </summary>
            public const int HomeCurrency = 114;

            /// <summary>
            /// Property Indexer for DefaultAssemblyNumber
            /// </summary>
            public const int DefaultAssemblyNumber = 115;

            /// <summary>
            /// Property Indexer for NextAssemblyNumber
            /// </summary>
            public const int NextAssemblyNumber = 116;

            /// <summary>
            /// Property Indexer for DefaultDisassemblyNumber
            /// </summary>
            public const int DefaultDisassemblyNumber = 117;

            /// <summary>
            /// Property Indexer for NextDisassemblyNumber
            /// </summary>
            public const int NextDisassemblyNumber = 118;

            /// <summary>
            /// Property Indexer for DefaultTransferNumber
            /// </summary>
            public const int DefaultTransferNumber = 119;

            /// <summary>
            /// Property Indexer for NextTransferNumber
            /// </summary>
            public const int NextTransferNumber = 120;

            /// <summary>
            /// Property Indexer for DefaultAdjustmentNumber
            /// </summary>
            public const int DefaultAdjustmentNumber = 121;

            /// <summary>
            /// Property Indexer for NextAdjustmentNumber
            /// </summary>
            public const int NextAdjustmentNumber = 122;

            /// <summary>
            /// Property Indexer for DefaultShipmentNumber
            /// </summary>
            public const int DefaultShipmentNumber = 123;

            /// <summary>
            /// Property Indexer for NextShipmentNumber
            /// </summary>
            public const int NextShipmentNumber = 124;

            /// <summary>
            /// Property Indexer for DefaultShipmentReturnNumber
            /// </summary>
            public const int DefaultShipmentReturnNumber = 125;

            /// <summary>
            /// Property Indexer for NextShipmentReturnNumber
            /// </summary>
            public const int NextShipmentReturnNumber = 126;

            /// <summary>
            /// Property Indexer for DefaultReceiptNumber
            /// </summary>
            public const int DefaultReceiptNumber = 127;

            /// <summary>
            /// Property Indexer for NextReceiptNumber
            /// </summary>
            public const int NextReceiptNumber = 128;

            /// <summary>
            /// Property Indexer for DefaultTransitReceiptNumber
            /// </summary>
            public const int DefaultTransitReceiptNumber = 129;

            /// <summary>
            /// Property Indexer for NextTransitReceiptNumber
            /// </summary>
            public const int NextTransitReceiptNumber = 130;

            /// <summary>
            /// Property Indexer for DefaultGoodsInTransitLocatio
            /// </summary>
            public const int DefaultGoodsInTransitLocatio = 131;

            /// <summary>
            /// Property Indexer for TransitLocationDescription
            /// </summary>
            public const int TransitLocationDescription = 132;

            /// <summary>
            /// Property Indexer for OnlyUseDefinedUOM
            /// </summary>
            public const int OnlyUseDefinedUOM = 133;

            /// <summary>
            /// Property Indexer for AgingPeriod1
            /// </summary>
            public const int AgingPeriod1 = 134;

            /// <summary>
            /// Property Indexer for AgingPeriod2
            /// </summary>
            public const int AgingPeriod2 = 135;

            /// <summary>
            /// Property Indexer for AgingPeriod3
            /// </summary>
            public const int AgingPeriod3 = 136;

            /// <summary>
            /// Property Indexer for CreateSubledgerAuditDuring
            /// </summary>
            public const int CreateSubledgerAuditDuring = 137;

            /// <summary>
            /// Property Indexer for NextInternalUsageEntrySequence
            /// </summary>
            public const int NextInternalUsageEntrySequence = 138;

            /// <summary>
            /// Property Indexer for InternalUsageNumberLength
            /// </summary>
            public const int InternalUsageNumberLength = 139;

            /// <summary>
            /// Property Indexer for InternalUsageNumberPrefix
            /// </summary>
            public const int InternalUsageNumberPrefix = 140;

            /// <summary>
            /// Property Indexer for NextInternalUsageNumberDescription
            /// </summary>
            public const int NextInternalUsageNumberDescription = 141;

            /// <summary>
            /// Property Indexer for DefaultInternalUsageNumber
            /// </summary>
            public const int DefaultInternalUsageNumber = 142;

            /// <summary>
            /// Property Indexer for NextInternalUsageNumber
            /// </summary>
            public const int NextInternalUsageNumber = 143;

            /// <summary>
            /// Property Indexer for TransactionPostDepCost
            /// </summary>
            public const int TransactionPostDepCost = 144;

            /// <summary>
            /// Property Indexer for ICReceipts
            /// </summary>
            public const int ICReceipts = 145;

            /// <summary>
            /// Property Indexer for ICReceiptReturns
            /// </summary>
            public const int ICReceiptReturns = 146;

            /// <summary>
            /// Property Indexer for ICReceiptAdjustments
            /// </summary>
            public const int ICReceiptAdjustments = 147;

            /// <summary>
            /// Property Indexer for ICShipments
            /// </summary>
            public const int ICShipments = 148;

            /// <summary>
            /// Property Indexer for ICShipmentReturns
            /// </summary>
            public const int ICShipmentReturns = 149;

            /// <summary>
            /// Property Indexer for ICTransfers
            /// </summary>
            public const int ICTransfers = 150;

            /// <summary>
            /// Property Indexer for ICAssemblies
            /// </summary>
            public const int ICAssemblies = 151;

            /// <summary>
            /// Property Indexer for ICAdjustments
            /// </summary>
            public const int ICAdjustments = 152;

            /// <summary>
            /// Property Indexer for ICConsolidatedEntry
            /// </summary>
            public const int ICConsolidatedEntry = 153;

            /// <summary>
            /// Property Indexer for ICDisassemblies
            /// </summary>
            public const int ICDisassemblies = 154;

            /// <summary>
            /// Property Indexer for ICInternalUsage
            /// </summary>
            public const int ICInternalUsage = 155;

            /// <summary>
            /// Property Indexer for DefaultPostingDate
            /// </summary>
            public const int DefaultPostingDate = 156;

            /// <summary>
            /// Property Indexer for SerialNumberMask
            /// </summary>
            public const int SerialNumberMask = 157;

            /// <summary>
            /// Property Indexer for UseSerialsDaysToExpire
            /// </summary>
            public const int UseSerialsDaysToExpire = 158;

            /// <summary>
            /// Property Indexer for SerialsDaysToExpire
            /// </summary>
            public const int SerialsDaysToExpire = 159;

            /// <summary>
            /// Property Indexer for AllowDifferentSerialQty
            /// </summary>
            public const int AllowDifferentSerialQty = 160;

            /// <summary>
            /// Property Indexer for AllowSerialAllocOnQtyOrdered
            /// </summary>
            public const int AllowSerialAllocOnQtyOrdered = 161;

            /// <summary>
            /// Property Indexer for SortSerialsBy
            /// </summary>
            public const int SortSerialsBy = 162;

            /// <summary>
            /// Property Indexer for SortSerialsFirstBy
            /// </summary>
            public const int SortSerialsFirstBy = 163;

            /// <summary>
            /// Property Indexer for StopAllocationOfExpiredSeria
            /// </summary>
            public const int StopAllocationOfExpiredSeria = 164;

            /// <summary>
            /// Property Indexer for SerialsHyphenAsSeparator
            /// </summary>
            public const int SerialsHyphenAsSeparator = 165;

            /// <summary>
            /// Property Indexer for SerialsFwdSlashAsSeparator
            /// </summary>
            public const int SerialsFwdSlashAsSeparator = 166;

            /// <summary>
            /// Property Indexer for SerialsBackSlashAsSeparator
            /// </summary>
            public const int SerialsBackSlashAsSeparator = 167;

            /// <summary>
            /// Property Indexer for SerialsAsteriskAsSeparator
            /// </summary>
            public const int SerialsAsteriskAsSeparator = 168;

            /// <summary>
            /// Property Indexer for SerialsPeriodAsSeparator
            /// </summary>
            public const int SerialsPeriodAsSeparator = 169;

            /// <summary>
            /// Property Indexer for SerialsLeftParenthesisAsSep
            /// </summary>
            public const int SerialsLeftParenthesisAsSep = 170;

            /// <summary>
            /// Property Indexer for SerialsRightParenthesisAsSep
            /// </summary>
            public const int SerialsRightParenthesisAsSep = 171;

            /// <summary>
            /// Property Indexer for SerialsPoundSignAsSeparator
            /// </summary>
            public const int SerialsPoundSignAsSeparator = 172;

            /// <summary>
            /// Property Indexer for SerialsLeftBracketAsSep
            /// </summary>
            public const int SerialsLeftBracketAsSep = 173;

            /// <summary>
            /// Property Indexer for SerialsRightBracketAsSep
            /// </summary>
            public const int SerialsRightBracketAsSep = 174;

            /// <summary>
            /// Property Indexer for SerialsLeftBraceAsSep
            /// </summary>
            public const int SerialsLeftBraceAsSep = 175;

            /// <summary>
            /// Property Indexer for SerialsRightBraceAsSep
            /// </summary>
            public const int SerialsRightBraceAsSep = 176;

            /// <summary>
            /// Property Indexer for LotNumberMask
            /// </summary>
            public const int LotNumberMask = 177;

            /// <summary>
            /// Property Indexer for UseLotsDaysToExpire
            /// </summary>
            public const int UseLotsDaysToExpire = 178;

            /// <summary>
            /// Property Indexer for LotsDaysToExpire
            /// </summary>
            public const int LotsDaysToExpire = 179;

            /// <summary>
            /// Property Indexer for UseLotsDaysOnQuarantine
            /// </summary>
            public const int UseLotsDaysOnQuarantine = 180;

            /// <summary>
            /// Property Indexer for LotsDaysOnQuarantine
            /// </summary>
            public const int LotsDaysOnQuarantine = 181;

            /// <summary>
            /// Property Indexer for AllowDifferentLotQty
            /// </summary>
            public const int AllowDifferentLotQty = 182;

            /// <summary>
            /// Property Indexer for AllowLotAllocOnQtyOrdered
            /// </summary>
            public const int AllowLotAllocOnQtyOrdered = 183;

            /// <summary>
            /// Property Indexer for SortLotsBy
            /// </summary>
            public const int SortLotsBy = 184;

            /// <summary>
            /// Property Indexer for SortLotsFirstBy
            /// </summary>
            public const int SortLotsFirstBy = 185;

            /// <summary>
            /// Property Indexer for StopAllocationOfExpiredLots
            /// </summary>
            public const int StopAllocationOfExpiredLots = 186;

            /// <summary>
            /// Property Indexer for LotsHyphenAsSeparator
            /// </summary>
            public const int LotsHyphenAsSeparator = 187;

            /// <summary>
            /// Property Indexer for LotsFwdSlashAsSeparator
            /// </summary>
            public const int LotsFwdSlashAsSeparator = 188;

            /// <summary>
            /// Property Indexer for LotsBackSlashAsSeparator
            /// </summary>
            public const int LotsBackSlashAsSeparator = 189;

            /// <summary>
            /// Property Indexer for LotsAsteriskAsSeparator
            /// </summary>
            public const int LotsAsteriskAsSeparator = 190;

            /// <summary>
            /// Property Indexer for LotsPeriodAsSeparator
            /// </summary>
            public const int LotsPeriodAsSeparator = 191;

            /// <summary>
            /// Property Indexer for LotsLeftParenthesisAsSep
            /// </summary>
            public const int LotsLeftParenthesisAsSep = 192;

            /// <summary>
            /// Property Indexer for LotsRightParenthesisAsSep
            /// </summary>
            public const int LotsRightParenthesisAsSep = 193;

            /// <summary>
            /// Property Indexer for LotsPoundSignAsSeparator
            /// </summary>
            public const int LotsPoundSignAsSeparator = 194;

            /// <summary>
            /// Property Indexer for LotsLeftBracketAsSeparator
            /// </summary>
            public const int LotsLeftBracketAsSeparator = 195;

            /// <summary>
            /// Property Indexer for LotsRightBracketAsSeparator
            /// </summary>
            public const int LotsRightBracketAsSeparator = 196;

            /// <summary>
            /// Property Indexer for LotsLeftBraceAsSeparator
            /// </summary>
            public const int LotsLeftBraceAsSeparator = 197;

            /// <summary>
            /// Property Indexer for LotsRightBraceAsSeparator
            /// </summary>
            public const int LotsRightBraceAsSeparator = 198;

            /// <summary>
            /// Property Indexer for RecallReleaseSequenceNumber
            /// </summary>
            public const int RecallReleaseSequenceNumber = 199;

            /// <summary>
            /// Property Indexer for RecallNumberLength
            /// </summary>
            public const int RecallNumberLength = 200;

            /// <summary>
            /// Property Indexer for RecallNumberPrefix
            /// </summary>
            public const int RecallNumberPrefix = 201;

            /// <summary>
            /// Property Indexer for NextRecallNumberDescription
            /// </summary>
            public const int NextRecallNumberDescription = 202;

            /// <summary>
            /// Property Indexer for DefaultRecallNumber
            /// </summary>
            public const int DefaultRecallNumber = 203;

            /// <summary>
            /// Property Indexer for NextRecallNumber
            /// </summary>
            public const int NextRecallNumber = 204;

            /// <summary>
            /// Property Indexer for ReleaseNumberLength
            /// </summary>
            public const int ReleaseNumberLength = 205;

            /// <summary>
            /// Property Indexer for ReleaseNumberPrefix
            /// </summary>
            public const int ReleaseNumberPrefix = 206;

            /// <summary>
            /// Property Indexer for NextReleaseNumberDescription
            /// </summary>
            public const int NextReleaseNumberDescription = 207;

            /// <summary>
            /// Property Indexer for DefaultReleaseNumber
            /// </summary>
            public const int DefaultReleaseNumber = 208;

            /// <summary>
            /// Property Indexer for NextReleaseNumber
            /// </summary>
            public const int NextReleaseNumber = 209;

            /// <summary>
            /// Property Indexer for CombineSplitSequenceNumber
            /// </summary>
            public const int CombineSplitSequenceNumber = 210;

            /// <summary>
            /// Property Indexer for CombineNumberLength
            /// </summary>
            public const int CombineNumberLength = 211;

            /// <summary>
            /// Property Indexer for CombineNumberPrefix
            /// </summary>
            public const int CombineNumberPrefix = 212;

            /// <summary>
            /// Property Indexer for NextCombineNumberDescription
            /// </summary>
            public const int NextCombineNumberDescription = 213;

            /// <summary>
            /// Property Indexer for DefaultCombineNumber
            /// </summary>
            public const int DefaultCombineNumber = 214;

            /// <summary>
            /// Property Indexer for NextCombineNumber
            /// </summary>
            public const int NextCombineNumber = 215;

            /// <summary>
            /// Property Indexer for SplitNumberLength
            /// </summary>
            public const int SplitNumberLength = 216;

            /// <summary>
            /// Property Indexer for SplitNumberPrefix
            /// </summary>
            public const int SplitNumberPrefix = 217;

            /// <summary>
            /// Property Indexer for NextSplitNumberDescription
            /// </summary>
            public const int NextSplitNumberDescription = 218;

            /// <summary>
            /// Property Indexer for DefaultSplitNumber
            /// </summary>
            public const int DefaultSplitNumber = 219;

            /// <summary>
            /// Property Indexer for NextSplitNumber
            /// </summary>
            public const int NextSplitNumber = 220;

            /// <summary>
            /// Property Indexer for ReconciliationSequenceNumber
            /// </summary>
            public const int ReconciliationSequenceNumber = 221;

            /// <summary>
            /// Property Indexer for ReconciliationNumberLength
            /// </summary>
            public const int ReconciliationNumberLength = 222;

            /// <summary>
            /// Property Indexer for ReconciliationNumberPrefix
            /// </summary>
            public const int ReconciliationNumberPrefix = 223;

            /// <summary>
            /// Property Indexer for NextReconciliationNumberDescription
            /// </summary>
            public const int NextReconciliationNumberDescription = 224;

            /// <summary>
            /// Property Indexer for DefaultReconciliationNumber
            /// </summary>
            public const int DefaultReconciliationNumber = 225;

            /// <summary>
            /// Property Indexer for NextReconciliationNumber
            /// </summary>
            public const int NextReconciliationNumber = 226;

            /// <summary>
            /// Property Indexer for SeparatorLeftBracket
            /// </summary>
            public const int SeparatorLeftBracket = 227;

            /// <summary>
            /// Property Indexer for SeparatorRightBracket
            /// </summary>
            public const int SeparatorRightBracket = 228;

            /// <summary>
            /// Property Indexer for SeparatorLeftBrace
            /// </summary>
            public const int SeparatorLeftBrace = 229;

            /// <summary>
            /// Property Indexer for SeparatorRightBrace
            /// </summary>
            public const int SeparatorRightBrace = 230;

            /// <summary>
            /// Property Indexer for AllowDuplicateSerials
            /// </summary>
            public const int AllowDuplicateSerials = 231;

            /// <summary>
            /// Property Indexer for SalesStatsPeriodsToUse
            /// </summary>
            public const int SalesStatsPeriodsToUse = 232;

            /// <summary>
            /// Property Indexer for UpdateLocationDetailsMinQty
            /// </summary>
            public const int UpdateLocationDetailsMinQty = 233;

            /// <summary>
            /// Property Indexer for MinimumQuantityMarginFactor
            /// </summary>
            public const int MinimumQuantityMarginFactor = 234;

            /// <summary>
            /// Property Indexer for MaximumQuantityMarginFactor
            /// </summary>
            public const int MaximumQuantityMarginFactor = 235;

            /// <summary>
            /// Property Indexer for HighlightSalesVarianceAbove
            /// </summary>
            public const int HighlightSalesVarianceAbove = 236;

            /// <summary>
            /// Property Indexer for HighlightTrendVarianceAbove
            /// </summary>
            public const int HighlightTrendVarianceAbove = 237;

            /// <summary>
            /// Property Indexer for HighlightMinMaxVarianceAbove
            /// </summary>
            public const int HighlightMinMaxVarianceAbove = 238;

            /// <summary>
            /// Property Indexer for DefaultNumberDaysForExpiry
            /// </summary>
            public const int DefaultNumberDaysForExpiry = 239;

            /// <summary>
            /// Property Indexer for DefaultNumberDaysForFollowUp
            /// </summary>
            public const int DefaultNumberDaysForFollowUp = 240;

            /// <summary>
            /// Property Indexer for DefaultCommentType
            /// </summary>
            public const int DefaultCommentType = 241;

            /// <summary>
            /// Property Indexer for AllowBlankCommentType
            /// </summary>
            public const int AllowBlankCommentType = 242;

            /// <summary>
            /// Property Indexer for UTCDateLastDayEnd
            /// </summary>
            public const int UTCDateLastDayEnd = 243;

            /// <summary>
            /// Property Indexer for UTCTimeLastDayEnd
            /// </summary>
            public const int UTCTimeLastDayEnd = 244;

            /// <summary>
            /// Property Indexer for LocalDateLastDayEnd
            /// </summary>
            public const int LocalDateLastDayEnd = 245;

            /// <summary>
            /// Property Indexer for LocalTimeLastDayEnd
            /// </summary>
            public const int LocalTimeLastDayEnd = 246;
        }

        #endregion
    }
}