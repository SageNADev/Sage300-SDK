// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoicePaymentSchedule Constants
    /// </summary>
    public partial class InvoicePaymentSchedule
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0436";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"DISCBASE", "BaseForDiscount"},
					{"DISCDATE", "DiscountDate"},
					{"DISCPER", "DiscountPercentage"},
					{"DISCAMT", "DiscountAmount"},
					{"DUEBASE", "DueBase"},
					{"DUEDATE", "DueDate"},
					{"DUEPER", "PercentageDue"},
					{"DUEAMT", "AmountDue"},
					{"PAYMENT", "Payment"}
				};
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of InvoicePaymentSchedule Constants
        /// </summary>
        public class Fields : BaseFields
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoicePaymentSchedule Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for PaymentNumber
            /// </summary>
            public const int PaymentNumber = 2;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 3;

            /// <summary>
            /// Property Indexer for BaseForDiscount
            /// </summary>
            public const int BaseForDiscount = 4;

            /// <summary>
            /// Property Indexer for DiscountDate
            /// </summary>
            public const int DiscountDate = 5;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 6;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 7;

            /// <summary>
            /// Property Indexer for DueBase
            /// </summary>
            public const int DueBase = 8;

            /// <summary>
            /// Property Indexer for DueDate
            /// </summary>
            public const int DueDate = 9;

            /// <summary>
            /// Property Indexer for PercentageDue
            /// </summary>
            public const int PercentageDue = 10;

            /// <summary>
            /// Property Indexer for AmountDue
            /// </summary>
            public const int AmountDue = 11;

            /// <summary>
            /// Property Indexer for Payment
            /// </summary>
            public const int Payment = 15;
        }

        #endregion
    }
}
