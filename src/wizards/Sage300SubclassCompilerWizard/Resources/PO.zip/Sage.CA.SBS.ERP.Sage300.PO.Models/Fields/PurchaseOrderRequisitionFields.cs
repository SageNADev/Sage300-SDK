// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseOrderRequisition Constants
    /// </summary>
    public partial class PurchaseOrderRequisition
    {

        #region Public Constant

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0632";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"RQNHSEQ", "RequisitionSequenceKey"},
					{"RQNNUMBER", "RequisitionNumber"},
					{"COMPLETION", "CompletionStatus"},
					{"DTCOMPLETE", "DateOrdered"},
					{"BLNKVDCODE", "UseBlankVendors"},
					{"USEVDTYPE", "UseICVendor"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"ISCOMPLETE", "Ordered"},
					{"RQNCMPL", "RequisitionOrdered"},
					{"RQN", "Line"}
				};
            }
        }

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of PurchaseOrderRequisition Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "PORRREV";

            /// <summary>
            /// Property for RequisitionSequenceKey
            /// </summary>
            public const string RequisitionSequenceKey = "RQNHSEQ";

            /// <summary>
            /// Property for RequisitionNumber
            /// </summary>
            public const string RequisitionNumber = "RQNNUMBER";

            /// <summary>
            /// Property for CompletionStatus
            /// </summary>
            public const string CompletionStatus = "COMPLETION";

            /// <summary>
            /// Property for DateOrdered
            /// </summary>
            public const string DateOrdered = "DTCOMPLETE";

            /// <summary>
            /// Property for UseBlankVendors
            /// </summary>
            public const string UseBlankVendors = "BLNKVDCODE";

            /// <summary>
            /// Property for UseICVendor
            /// </summary>
            public const string UseICVendor = "USEVDTYPE";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for Ordered
            /// </summary>
            public const string Ordered = "ISCOMPLETE";

            /// <summary>
            /// Property for RequisitionOrdered
            /// </summary>
            public const string RequisitionOrdered = "RQNCMPL";

            /// <summary>
            /// Property for Line
            /// </summary>
            public const string Line = "RQN";

        }

        #endregion

        #region Index Properties
        /// <summary>
        /// Contains list of PurchaseOrderRequisition Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for RequisitionSequenceKey
            /// </summary>
            public const int RequisitionSequenceKey = 3;

            /// <summary>
            /// Property Indexer for RequisitionNumber
            /// </summary>
            public const int RequisitionNumber = 4;

            /// <summary>
            /// Property Indexer for CompletionStatus
            /// </summary>
            public const int CompletionStatus = 5;

            /// <summary>
            /// Property Indexer for DateOrdered
            /// </summary>
            public const int DateOrdered = 6;

            /// <summary>
            /// Property Indexer for UseBlankVendors
            /// </summary>
            public const int UseBlankVendors = 7;

            /// <summary>
            /// Property Indexer for UseICVendor
            /// </summary>
            public const int UseICVendor = 8;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 9;

            /// <summary>
            /// Property Indexer for Ordered
            /// </summary>
            public const int Ordered = 31;

            /// <summary>
            /// Property Indexer for RequisitionOrdered
            /// </summary>
            public const int RequisitionOrdered = 32;

            /// <summary>
            /// Property Indexer for Line
            /// </summary>
            public const int Line = 33;

        }
        #endregion

    }
}
