// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceReceipt Constants
    /// </summary>
    public partial class InvoiceReceipt
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0438";

        #region Properties

        /// <summary>
        /// Contains list of InvoiceReceipt Constants
        /// </summary>
        public class Fields : BaseFields
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoiceReceipt Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 3;

            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 4;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 5;

            /// <summary>
            /// Property Indexer for Line
            /// </summary>
            public const int Line = 21;
        }

        #endregion
    }
}
