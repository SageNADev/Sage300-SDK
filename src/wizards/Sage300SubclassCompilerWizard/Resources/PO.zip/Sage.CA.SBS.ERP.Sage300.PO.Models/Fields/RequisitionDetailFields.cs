// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Contains list of Requisition Constants
	/// </summary>
    public partial class RequisitionDetail
	{
		/// <summary>
        /// Entity Name
		/// </summary>
        public const string EntityName = "PO0345";

		#region Properties
		/// <summary>
		/// Contains list of Requisition Field Constants
		/// </summary>
		public class Fields
		{
			/// <summary>
            /// Property for RequisitionSequenceKey
			/// </summary>
            public const string RequisitionSequenceKey = "RQNHSEQ";

			/// <summary>
            /// Property for Vendor
			/// </summary>
            public const string Vendor = "VDCODE";

			/// <summary>
            /// Property for RequisitionLineSequence
			/// </summary>
            public const string RequisitionLineSequence = "RQNLSEQ";

			/// <summary>
            /// Property for RequisitionNumber
			/// </summary>
            public const string RequisitionNumber = "RQNNUMBER";

			/// <summary>
            /// Property for RequisitionSequenceKey1
			/// </summary>
            public const string RequisitionSequenceKey1 = "RQNHSEQ1";

			/// <summary>
			/// Property for LineNumber
			/// </summary>
			public const string LineNumber = "RQNLREV";

			/// <summary>
            /// Property for RequisitionLineSequence1
			/// </summary>
            public const string RequisitionLineSequence1 = "RQNLSEQ1";

			/// <summary>
			/// Property for LineOrdered
			/// </summary>
			public const string LineOrdered = "LINEORDER";

			/// <summary>
			/// Property for RequisitionCommentSequence
			/// </summary>
			public const string RequisitionCommentSequence = "RQNCSEQ";

			/// <summary>
			/// Property for OrderNumber
			/// </summary>
			public const string OrderNumber = "OEONUMBER";

			/// <summary>
            /// Property for VendorExists
			/// </summary>
            public const string VendorExists = "VDEXISTS";

			/// <summary>
            /// Property for Vendor1
			/// </summary>
            public const string Vendor1 = "VDCODE1";

			/// <summary>
            /// Property for Name
			/// </summary>
			public const string Name = "VDNAME";

			/// <summary>
			/// Property for StoredInDatabaseTable
			/// </summary>
			public const string StoredInDatabaseTable = "INDBTABLE";

			/// <summary>
			/// Property for CompletionStatus
			/// </summary>
			public const string CompletionStatus = "COMPLETION";

			/// <summary>
			/// Property for DateCompleted
			/// </summary>
			public const string DateCompleted = "DTCOMPLETE";

			/// <summary>
			/// Property for ItemExists
			/// </summary>
			public const string ItemExists = "ITEMEXISTS";

			/// <summary>
			/// Property for ItemNumber
			/// </summary>
			public const string ItemNumber = "ITEMNO";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for ItemDescription
			/// </summary>
			public const string ItemDescription = "ITEMDESC";

			/// <summary>
			/// Property for ExpectedArrivalDate
			/// </summary>
			public const string ExpectedArrivalDate = "EXPARRIVAL";

			/// <summary>
			/// Property for VendorItemNumber
			/// </summary>
			public const string VendorItemNumber = "VENDITEMNO";

			/// <summary>
			/// Property for CommentsInstructions
			/// </summary>
			public const string CommentsInstructions = "HASCOMMENT";

			/// <summary>
			/// Property for UnitOfMeasure
			/// </summary>
			public const string UnitOfMeasure = "ORDERUNIT";

			/// <summary>
			/// Property for OrderUnitConversion
			/// </summary>
			public const string OrderUnitConversion = "ORDERCONV";

			/// <summary>
			/// Property for OrderUnitDecimals
			/// </summary>
			public const string OrderUnitDecimals = "ORDERDECML";

			/// <summary>
			/// Property for StockUnitDecimals
			/// </summary>
			public const string StockUnitDecimals = "STOCKDECML";

			/// <summary>
            /// Property for QuantityOrdered
			/// </summary>
            public const string QuantityOrdered = "OQORDERED";

			/// <summary>
			/// Property for DropShip
			/// </summary>
			public const string DropShip = "HASDROPSHI";

			/// <summary>
			/// Property for DropShipType
			/// </summary>
			public const string DropShipType = "DROPTYPE";

			/// <summary>
			/// Property for DropShipCustomer
			/// </summary>
			public const string DropShipCustomer = "IDCUST";

			/// <summary>
			/// Property for CustomerShipToAddress
			/// </summary>
			public const string CustomerShipToAddress = "IDCUSTSHPT";

			/// <summary>
			/// Property for DropShipLocation
			/// </summary>
			public const string DropShipLocation = "DLOCATION";

			/// <summary>
			/// Property for DropShipDescription
			/// </summary>
			public const string DropShipDescription = "DESC";

			/// <summary>
			/// Property for DropShipAddress1
			/// </summary>
			public const string DropShipAddress1 = "ADDRESS1";

			/// <summary>
			/// Property for DropShipAddress2
			/// </summary>
			public const string DropShipAddress2 = "ADDRESS2";

			/// <summary>
			/// Property for DropShipAddress3
			/// </summary>
			public const string DropShipAddress3 = "ADDRESS3";

			/// <summary>
			/// Property for DropShipAddress4
			/// </summary>
			public const string DropShipAddress4 = "ADDRESS4";

			/// <summary>
			/// Property for DropShipCity
			/// </summary>
			public const string DropShipCity = "CITY";

			/// <summary>
			/// Property for DropShipStateProvince
			/// </summary>
			public const string DropShipStateProvince = "STATE";

			/// <summary>
			/// Property for DropShipZipPostalCode
			/// </summary>
			public const string DropShipZipPostalCode = "ZIP";

			/// <summary>
			/// Property for DropShipCountry
			/// </summary>
			public const string DropShipCountry = "COUNTRY";

			/// <summary>
			/// Property for DropShipPhoneNumber
			/// </summary>
			public const string DropShipPhoneNumber = "PHONE";

			/// <summary>
			/// Property for DropShipFaxNumber
			/// </summary>
			public const string DropShipFaxNumber = "FAX";

			/// <summary>
			/// Property for DropShipContact
			/// </summary>
			public const string DropShipContact = "CONTACT";

			/// <summary>
			/// Property for StockItem
			/// </summary>
			public const string StockItem = "STOCKITEM";

			/// <summary>
			/// Property for DropShipEmail
			/// </summary>
			public const string DropShipEmail = "EMAIL";

			/// <summary>
			/// Property for DropShipContactPhone
			/// </summary>
			public const string DropShipContactPhone = "PHONEC";

			/// <summary>
			/// Property for DropShipContactFax
			/// </summary>
			public const string DropShipContactFax = "FAXC";

			/// <summary>
			/// Property for DropShipContactEmail
			/// </summary>
			public const string DropShipContactEmail = "EMAILC";

			/// <summary>
			/// Property for ManufacturersItemNumber
			/// </summary>
			public const string ManufacturersItemNumber = "MANITEMNO";

			/// <summary>
            /// Property for OptionalFields
			/// </summary>
            public const string OptionalFields = "VALUES";

			/// <summary>
			/// Property for Contract
			/// </summary>
			public const string Contract = "CONTRACT";

			/// <summary>
			/// Property for Project
			/// </summary>
			public const string Project = "PROJECT";

			/// <summary>
			/// Property for Category
			/// </summary>
			public const string Category = "CCATEGORY";

			/// <summary>
			/// Property for CostClass
			/// </summary>
			public const string CostClass = "COSTCLASS";

			/// <summary>
			/// Property for StockingQuantityOrdered
			/// </summary>
			public const string StockingQuantityOrdered = "SQORDERED";

			/// <summary>
			/// Property for VendorOnHold
			/// </summary>
			public const string VendorOnHold = "VDONHOLD";

			/// <summary>
			/// Property for UseICVendor
			/// </summary>
			public const string UseICVendor = "USEVDTYPE";

			/// <summary>
            /// Property for ICVendor
			/// </summary>
            public const string ICVendor = "ICVDCODE";

			/// <summary>
            /// Property for Completed
			/// </summary>
            public const string Completed = "ISCOMPLETE";

			/// <summary>
            /// Property for LineComplete
			/// </summary>
			public const string LineComplete = "LINECMPL";

			/// <summary>
			/// Property for IsRecordActive
			/// </summary>
			public const string IsRecordActive = "ISACTIVE";

			/// <summary>
			/// Property for Line
			/// </summary>
			public const string Line = "LINE";

			/// <summary>
			/// Property for MapManufacturersItemNumber
			/// </summary>
			public const string MapManufacturersItemNumber = "MAPMANITEM";

			/// <summary>
            /// Property for Command
			/// </summary>
            public const string Command = "PROCESSCMD";

			/// <summary>
			/// Property for ProjectStyle
			/// </summary>
			public const string ProjectStyle = "CONTSTYLE";

			/// <summary>
			/// Property for ProjectType
			/// </summary>
			public const string ProjectType = "PROJTYPE";

			/// <summary>
			/// Property for UnformattedContractCode
			/// </summary>
			public const string UnformattedContractCode = "UFMTCONTNO";

			/// <summary>
			/// Property for UnitCost
			/// </summary>
			public const string UnitCost = "UNITCOST";

			/// <summary>
			/// Property for UnitCostIsManual
			/// </summary>
			public const string UnitCostIsManual = "UCISMANUAL";

			/// <summary>
			/// Property for CopyCostToPurchaseOrder
			/// </summary>
			public const string CopyCostToPurchaseOrder = "CPCOSTTOPO";

			/// <summary>
			/// Property for ExtendedCost
			/// </summary>
			public const string ExtendedCost = "EXTENDED";

			/// <summary>
			/// Property for FunctionalExtended
			/// </summary>
			public const string FunctionalExtended = "FCEXTENDED";

			/// <summary>
			/// Property for DiscountAmount
			/// </summary>
			public const string DiscountAmount = "DISCOUNT";

			/// <summary>
			/// Property for DiscountPercentage
			/// </summary>
			public const string DiscountPercentage = "DISCPCT";

			/// <summary>
			/// Property for UnitWeight
			/// </summary>
			public const string UnitWeight = "UNITWEIGHT";

			/// <summary>
            /// Property for ExtendedWeight
			/// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

			/// <summary>
			/// Property for WeightUnitOfMeasure
			/// </summary>
			public const string WeightUnitOfMeasure = "WEIGHTUNIT";

			/// <summary>
			/// Property for WeightConversion
			/// </summary>
			public const string WeightConversion = "WEIGHTCONV";

			/// <summary>
			/// Property for DefaultUnitWeight
			/// </summary>
			public const string DefaultUnitWeight = "DEFUWEIGHT";

			/// <summary>
			/// Property for DefaultExtendedWeight
			/// </summary>
			public const string DefaultExtendedWeight = "DEFEXTWGHT";

			/// <summary>
			/// Property for NetExtendedCost
			/// </summary>
			public const string NetExtendedCost = "NETXTENDED";

			/// <summary>
            /// Property for Lines
			/// </summary>
			public const string Lines = "LINES";

			/// <summary>
			/// Property for Currency
			/// </summary>
			public const string Currency = "CURRENCY";

			/// <summary>
			/// Property for CurrencyDescription
			/// </summary>
			public const string CurrencyDescription = "CURRENCYD";

			/// <summary>
			/// Property for ExchangeRate
			/// </summary>
			public const string ExchangeRate = "RATE";

			/// <summary>
			/// Property for ExchangeRateExists
			/// </summary>
			public const string ExchangeRateExists = "RATEEXISTS";

			/// <summary>
			/// Property for RateType
			/// </summary>
			public const string RateType = "RATETYPE";

			/// <summary>
			/// Property for RateTypeDescription
			/// </summary>
			public const string RateTypeDescription = "RATETYPED";

			/// <summary>
			/// Property for RateDate
			/// </summary>
			public const string RateDate = "RATEDATE";

			/// <summary>
			/// Property for RateOperation
			/// </summary>
			public const string RateOperation = "RATEOPER";

			/// <summary>
			/// Property for CostDateForContract
			/// </summary>
			public const string CostDateForContract = "COSTDATE";

			/// <summary>
			/// Property for DetailNumber
			/// </summary>
			public const string DetailNumber = "DETAILNUM";

			/// <summary>
            /// Property for RequisitionSequenceKey2
			/// </summary>
            public const string RequisitionSequenceKey2 = "RQNHSEQ2";

			/// <summary>
			/// Property for NextLineSequence
			/// </summary>
			public const string NextLineSequence = "NEXTLSEQ";

			/// <summary>
			/// Property for LINES
			/// </summary>
            public const string Lines1 = "LINES";

			/// <summary>
            /// Property for LinesComplete
			/// </summary>
            public const string LinesComplete = "LINESCMPL";

			/// <summary>
			/// Property for LinesOrdered
			/// </summary>
			public const string LinesOrdered = "LINESORDER";

			/// <summary>
			/// Property for Printed
			/// </summary>
			public const string Printed = "ISPRINTED";

			/// <summary>
			/// Property for Completed2
			/// </summary>
			public const string Completed2 = "ISCOMPLET2";

			/// <summary>
			/// Property for DateCompleted2
			/// </summary>
			public const string DateCompleted2 = "DTCOMPLET2";

			/// <summary>
			/// Property for LastPostingDate
			/// </summary>
			public const string LastPostingDate = "POSTDATE";

			/// <summary>
			/// Property for RequisitionDate
			/// </summary>
			public const string RequisitionDate = "DATE";

			/// <summary>
			/// Property for RequisitionNumber2
			/// </summary>
            public const string RequisitionNumber2 = "RQNNUMBER2";

			/// <summary>
            /// Property for Vendor2
			/// </summary>
            public const string Vendor2 = "VDCODE2";

			/// <summary>
			/// Property for VendorExists2
			/// </summary>
			public const string VendorExists2 = "VendorExists2";

			/// <summary>
			/// Property for Name2
			/// </summary>
			public const string Name2 = "VDNAME2";

			/// <summary>
			/// Property for OnHold
			/// </summary>
			public const string OnHold = "ONHOLD";

			/// <summary>
			/// Property for OrderDate
			/// </summary>
			public const string OrderDate = "ORDEREDON";

			/// <summary>
			/// Property for DateRequired
			/// </summary>
			public const string DateRequired = "EXPARRIVA2";

			/// <summary>
			/// Property for ExpirationDate
			/// </summary>
			public const string ExpirationDate = "EXPIRATION";

			/// <summary>
			/// Property for Description
			/// </summary>
			public const string Description = "DESCRIPTIO";

			/// <summary>
			/// Property for Reference
			/// </summary>
			public const string Reference = "REFERENCE";

			/// <summary>
			/// Property for Comment
			/// </summary>
			public const string Comment = "COMMENT";

			/// <summary>
			/// Property for QuantityOrdered2
			/// </summary>
			public const string QuantityOrdered2 = "OQORDERED2";

			/// <summary>
			/// Property for Requestedby
			/// </summary>
			public const string Requestedby = "REQUESTBY";

			/// <summary>
			/// Property for DocumentSource
			/// </summary>
			public const string DocumentSource = "DOCSOURCE";

			/// <summary>
			/// Property for OptionalFields2
			/// </summary>
			public const string OptionalFields2 = "VALUES2";

			/// <summary>
			/// Property for JobRelatedLines
			/// </summary>
			public const string JobRelatedLines = "JOBLINES";

			/// <summary>
			/// Property for ShipToLocation
			/// </summary>
            public const string ShipToLocation = "STCODE";

			/// <summary>
			/// Property for LocationDescription
			/// </summary>
			public const string LocationDescription = "STDESC";

			/// <summary>
			/// Property for ApprovalStatus
			/// </summary>
			public const string ApprovalStatus = "APPROVED";

			/// <summary>
			/// Property for ApproverID
			/// </summary>
			public const string ApproverID = "APPROVER";

			/// <summary>
			/// Property for EnteredBy
			/// </summary>
			public const string EnteredBy = "ENTEREDBY";

			/// <summary>
            /// Property for ExtendedWeight
			/// </summary>
            public const string ExtendedWeight1 = "EXTWEIGHT";

			/// <summary>
			/// Property for FuncExtendedAmount
			/// </summary>
			public const string FuncExtendedAmount = "FCEXTENDED";

			/// <summary>
			/// Property for VendorOnHold2
			/// </summary>
			public const string VendorOnHold2 = "VDONHOLD2";

			/// <summary>
			/// Property for DocumentLocked
			/// </summary>
			public const string DocumentLocked = "LOCKED";

			/// <summary>
			/// Property for RequisitionHasExpired
			/// </summary>
			public const string RequisitionHasExpired = "EXPIRED";

			/// <summary>
			/// Property for IsDocumentDeletable
			/// </summary>
			public const string IsDocumentDeletable = "CANDELETE";

			/// <summary>
			/// Property for IsRecordActive2
			/// </summary>
			public const string IsRecordActive2 = "ISACTIVE2";

			/// <summary>
			/// Property for HasDetails
			/// </summary>
			public const string HasDetails = "HASDETAILS";

			/// <summary>
			/// Property for IsCanadianPayrollActive
			/// </summary>
			public const string IsCanadianPayrollActive = "CPACTIVE";

			/// <summary>
			/// Property for IsUSPayrollActive
			/// </summary>
            public const string IsUsPayrollActive = "UPACTIVE";

			/// <summary>
			/// Property for Command2
			/// </summary>
			public const string Command2 = "PRCESSCMD2";

			/// <summary>
			/// Property for JobRelated
			/// </summary>
			public const string JobRelated = "HASJOB";

			/// <summary>
			/// Property for ApproverName
			/// </summary>
			public const string ApproverName = "APPNAME";

			/// <summary>
			/// Property for FunctionalCurrency
			/// </summary>
			public const string FunctionalCurrency = "FCCURRENCY";

			/// <summary>
			/// Property for NextDetailNumber
			/// </summary>
			public const string NextDetailNumber = "DETAILNEXT";
		}
		#endregion

		#region Properties
		/// <summary>
		/// Contains list of Requisition Index Constants
		/// </summary>
		public class Index
		{
			/// <summary>
            /// Property Indexer for RequisitionSequenceKey
			/// </summary>
            public const int RequisitionSequenceKey = 1;

			/// <summary>
            /// Property Indexer for Vendor
			/// </summary>
            public const int Vendor = 2;

			/// <summary>
			/// Property Indexer for RQNLSEQ
			/// </summary>
            public const int RequisitionLineSequence = 3;

			/// <summary>
			/// Property Indexer for RequisitionNumber
			/// </summary>
			public const int RequisitionNumber = 4;

			/// <summary>
            /// Property Indexer for RequisitionSequenceKey1
			/// </summary>
            public const int RequisitionSequenceKey1 = 1001;

			/// <summary>
			/// Property Indexer for LineNumber
			/// </summary>
			public const int LineNumber = 1002;

			/// <summary>
			/// Property Indexer for RQNLSEQ1
			/// </summary>
            public const int RequisitionLineSequence1 = 1003;

			/// <summary>
			/// Property Indexer for LineOrdered
			/// </summary>
			public const int LineOrdered = 1004;

			/// <summary>
			/// Property Indexer for RequisitionCommentSequence
			/// </summary>
			public const int RequisitionCommentSequence = 1005;

			/// <summary>
			/// Property Indexer for OrderNumber
			/// </summary>
			public const int OrderNumber = 1006;

			/// <summary>
			/// Property Indexer for VendorExists
			/// </summary>
			public const int VendorExists = 1007;

			/// <summary>
			/// Property Indexer for Vendor1
			/// </summary>
			public const int Vendor1 = 1008;

			/// <summary>
			/// Property Indexer for Name
			/// </summary>
			public const int Name = 1009;

			/// <summary>
			/// Property Indexer for StoredInDatabaseTable
			/// </summary>
			public const int StoredInDatabaseTable = 1010;

			/// <summary>
			/// Property Indexer for CompletionStatus
			/// </summary>
			public const int CompletionStatus = 1011;

			/// <summary>
			/// Property Indexer for DateCompleted
			/// </summary>
			public const int DateCompleted = 1012;

			/// <summary>
			/// Property Indexer for ItemExists
			/// </summary>
			public const int ItemExists = 1013;

			/// <summary>
			/// Property Indexer for ItemNumber
			/// </summary>
			public const int ItemNumber = 1014;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 1015;

			/// <summary>
			/// Property Indexer for ItemDescription
			/// </summary>
			public const int ItemDescription = 1016;

			/// <summary>
			/// Property Indexer for ExpectedArrivalDate
			/// </summary>
			public const int ExpectedArrivalDate = 1017;

			/// <summary>
			/// Property Indexer for VendorItemNumber
			/// </summary>
			public const int VendorItemNumber = 1018;

			/// <summary>
			/// Property Indexer for CommentsInstructions
			/// </summary>
			public const int CommentsInstructions = 1019;

			/// <summary>
			/// Property Indexer for UnitOfMeasure
			/// </summary>
			public const int UnitOfMeasure = 1020;

			/// <summary>
			/// Property Indexer for OrderUnitConversion
			/// </summary>
			public const int OrderUnitConversion = 1021;

			/// <summary>
			/// Property Indexer for OrderUnitDecimals
			/// </summary>
			public const int OrderUnitDecimals = 1022;

			/// <summary>
			/// Property Indexer for StockUnitDecimals
			/// </summary>
			public const int StockUnitDecimals = 1023;

			/// <summary>
			/// Property Indexer for QuantityOrdered
			/// </summary>
			public const int QuantityOrdered = 1024;

			/// <summary>
			/// Property Indexer for DropShip
			/// </summary>
			public const int DropShip = 1025;

			/// <summary>
			/// Property Indexer for DropShipType
			/// </summary>
			public const int DropShipType = 1026;

			/// <summary>
			/// Property Indexer for DropShipCustomer
			/// </summary>
			public const int DropShipCustomer = 1027;

			/// <summary>
			/// Property Indexer for CustomerShipToAddress
			/// </summary>
			public const int CustomerShipToAddress = 1028;

			/// <summary>
			/// Property Indexer for DropShipLocation
			/// </summary>
			public const int DropShipLocation = 1029;

			/// <summary>
			/// Property Indexer for DropShipDescription
			/// </summary>
			public const int DropShipDescription = 1030;

			/// <summary>
			/// Property Indexer for DropShipAddress1
			/// </summary>
			public const int DropShipAddress1 = 1031;

			/// <summary>
			/// Property Indexer for DropShipAddress2
			/// </summary>
			public const int DropShipAddress2 = 1032;

			/// <summary>
			/// Property Indexer for DropShipAddress3
			/// </summary>
			public const int DropShipAddress3 = 1033;

			/// <summary>
			/// Property Indexer for DropShipAddress4
			/// </summary>
			public const int DropShipAddress4 = 1034;

			/// <summary>
			/// Property Indexer for DropShipCity
			/// </summary>
			public const int DropShipCity = 1035;

			/// <summary>
			/// Property Indexer for DropShipStateProvince
			/// </summary>
			public const int DropShipStateProvince = 1036;

			/// <summary>
			/// Property Indexer for DropShipZipPostalCode
			/// </summary>
			public const int DropShipZipPostalCode = 1037;

			/// <summary>
			/// Property Indexer for DropShipCountry
			/// </summary>
			public const int DropShipCountry = 1038;

			/// <summary>
			/// Property Indexer for DropShipPhoneNumber
			/// </summary>
			public const int DropShipPhoneNumber = 1039;

			/// <summary>
			/// Property Indexer for DropShipFaxNumber
			/// </summary>
			public const int DropShipFaxNumber = 1040;

			/// <summary>
			/// Property Indexer for DropShipContact
			/// </summary>
			public const int DropShipContact = 1041;

			/// <summary>
			/// Property Indexer for StockItem
			/// </summary>
			public const int StockItem = 1042;

			/// <summary>
			/// Property Indexer for DropShipEmail
			/// </summary>
			public const int DropShipEmail = 1043;

			/// <summary>
			/// Property Indexer for DropShipContactPhone
			/// </summary>
			public const int DropShipContactPhone = 1044;

			/// <summary>
			/// Property Indexer for DropShipContactFax
			/// </summary>
			public const int DropShipContactFax = 1045;

			/// <summary>
			/// Property Indexer for DropShipContactEmail
			/// </summary>
			public const int DropShipContactEmail = 1046;

			/// <summary>
			/// Property Indexer for ManufacturersItemNumber
			/// </summary>
			public const int ManufacturersItemNumber = 1047;

			/// <summary>
			/// Property Indexer for OptionalFields
			/// </summary>
			public const int OptionalFields = 1048;

			/// <summary>
			/// Property Indexer for Contract
			/// </summary>
			public const int Contract = 1049;

			/// <summary>
			/// Property Indexer for Project
			/// </summary>
			public const int Project = 1050;

			/// <summary>
			/// Property Indexer for Category
			/// </summary>
			public const int Category = 1051;

			/// <summary>
			/// Property Indexer for CostClass
			/// </summary>
			public const int CostClass = 1052;

			/// <summary>
			/// Property Indexer for StockingQuantityOrdered
			/// </summary>
			public const int StockingQuantityOrdered = 1101;

			/// <summary>
			/// Property Indexer for VendorOnHold
			/// </summary>
			public const int VendorOnHold = 1102;

			/// <summary>
			/// Property Indexer for UseICVendor
			/// </summary>
			public const int UseICVendor = 1103;

			/// <summary>
			/// Property Indexer for ICVendor
			/// </summary>
			public const int ICVendor = 1104;

			/// <summary>
            /// Property Indexer for Completed
			/// </summary>
            public const int Completed = 1105;

			/// <summary>
			/// Property Indexer for LineComplete
			/// </summary>
			public const int LineComplete = 1106;

			/// <summary>
			/// Property Indexer for IsRecordActive
			/// </summary>
			public const int IsRecordActive = 1107;

			/// <summary>
			/// Property Indexer for Line
			/// </summary>
			public const int Line = 1108;

			/// <summary>
			/// Property Indexer for MapManufacturersItemNumber
			/// </summary>
			public const int MapManufacturersItemNumber = 1109;

			/// <summary>
            /// Property Indexer for Command
			/// </summary>
            public const int Command = 1110;

			/// <summary>
			/// Property Indexer for ProjectStyle
			/// </summary>
			public const int ProjectStyle = 1111;

			/// <summary>
			/// Property Indexer for ProjectType
			/// </summary>
			public const int ProjectType = 1112;

			/// <summary>
			/// Property Indexer for UnformattedContractCode
			/// </summary>
			public const int UnformattedContractCode = 1113;

			/// <summary>
			/// Property Indexer for UnitCost
			/// </summary>
			public const int UnitCost = 1201;

			/// <summary>
			/// Property Indexer for UnitCostIsManual
			/// </summary>
			public const int UnitCostIsManual = 1202;

			/// <summary>
			/// Property Indexer for CopyCostToPurchaseOrder
			/// </summary>
			public const int CopyCostToPurchaseOrder = 1203;

			/// <summary>
			/// Property Indexer for ExtendedCost
			/// </summary>
			public const int ExtendedCost = 1204;

			/// <summary>
			/// Property Indexer for FunctionalExtended
			/// </summary>
			public const int FunctionalExtended = 1205;

			/// <summary>
			/// Property Indexer for DiscountAmount
			/// </summary>
			public const int DiscountAmount = 1206;

			/// <summary>
			/// Property Indexer for DiscountPercentage
			/// </summary>
			public const int DiscountPercentage = 1207;

			/// <summary>
			/// Property Indexer for UnitWeight
			/// </summary>
			public const int UnitWeight = 1208;

			/// <summary>
			/// Property Indexer for EXTWEIGHT
			/// </summary>
            public const int ExtendedWeight = 1209;

			/// <summary>
			/// Property Indexer for WeightUnitOfMeasure
			/// </summary>
			public const int WeightUnitOfMeasure = 1210;

			/// <summary>
			/// Property Indexer for WeightConversion
			/// </summary>
			public const int WeightConversion = 1211;

			/// <summary>
			/// Property Indexer for DefaultUnitWeight
			/// </summary>
			public const int DefaultUnitWeight = 1212;

			/// <summary>
			/// Property Indexer for DefaultExtendedWeight
			/// </summary>
			public const int DefaultExtendedWeight = 1213;

			/// <summary>
			/// Property Indexer for NetExtendedCost
			/// </summary>
			public const int NetExtendedCost = 1214;

			/// <summary>
			/// Property Indexer for LINES
			/// </summary>
            public const int Lines = 1215;

			/// <summary>
			/// Property Indexer for Currency
			/// </summary>
			public const int Currency = 1216;

			/// <summary>
			/// Property Indexer for CurrencyDescription
			/// </summary>
			public const int CurrencyDescription = 1217;

			/// <summary>
			/// Property Indexer for ExchangeRate
			/// </summary>
			public const int ExchangeRate = 1218;

			/// <summary>
			/// Property Indexer for ExchangeRateExists
			/// </summary>
			public const int ExchangeRateExists = 1219;

			/// <summary>
			/// Property Indexer for RateType
			/// </summary>
			public const int RateType = 1220;

			/// <summary>
			/// Property Indexer for RateTypeDescription
			/// </summary>
			public const int RateTypeDescription = 1221;

			/// <summary>
			/// Property Indexer for RateDate
			/// </summary>
			public const int RateDate = 1222;

			/// <summary>
			/// Property Indexer for RateOperation
			/// </summary>
			public const int RateOperation = 1223;

			/// <summary>
			/// Property Indexer for CostDateForContract
			/// </summary>
			public const int CostDateForContract = 1224;

			/// <summary>
			/// Property Indexer for DetailNumber
			/// </summary>
			public const int DetailNumber = 1225;

			/// <summary>
            /// Property Indexer for RequisitionSequenceKey2
			/// </summary>
            public const int RequisitionSequenceKey2 = 2001;

			/// <summary>
			/// Property Indexer for NextLineSequence
			/// </summary>
			public const int NextLineSequence = 2002;

			/// <summary>
			/// Property Indexer for LINES
			/// </summary>
            public const int Lines1 = 2003;

			/// <summary>
            /// Property Indexer for LinesComplete
			/// </summary>
            public const int LinesComplete = 2004;

			/// <summary>
			/// Property Indexer for LinesOrdered
			/// </summary>
			public const int LinesOrdered = 2005;

			/// <summary>
			/// Property Indexer for Printed
			/// </summary>
			public const int Printed = 2006;

			/// <summary>
			/// Property Indexer for Completed2
			/// </summary>
			public const int Completed2 = 2007;

			/// <summary>
			/// Property Indexer for DateCompleted2
			/// </summary>
			public const int DateCompleted2 = 2008;

			/// <summary>
			/// Property Indexer for LastPostingDate
			/// </summary>
			public const int LastPostingDate = 2009;

			/// <summary>
			/// Property Indexer for RequisitionDate
			/// </summary>
			public const int RequisitionDate = 2010;

			/// <summary>
			/// Property Indexer for RequisitionNumber2
			/// </summary>
			public const int RequisitionNumber2 = 2011;

			/// <summary>
			/// Property Indexer for Vendor2
			/// </summary>
			public const int Vendor2 = 2012;

			/// <summary>
			/// Property Indexer for VendorExists2
			/// </summary>
			public const int VendorExists2 = 2013;

			/// <summary>
			/// Property Indexer for Name2
			/// </summary>
			public const int Name2 = 2014;

			/// <summary>
			/// Property Indexer for OnHold
			/// </summary>
			public const int OnHold = 2015;

			/// <summary>
			/// Property Indexer for OrderDate
			/// </summary>
			public const int OrderDate = 2016;

			/// <summary>
			/// Property Indexer for DateRequired
			/// </summary>
			public const int DateRequired = 2017;

			/// <summary>
			/// Property Indexer for ExpirationDate
			/// </summary>
			public const int ExpirationDate = 2018;

			/// <summary>
			/// Property Indexer for Description
			/// </summary>
			public const int Description = 2019;

			/// <summary>
			/// Property Indexer for Reference
			/// </summary>
			public const int Reference = 2020;

			/// <summary>
			/// Property Indexer for Comment
			/// </summary>
			public const int Comment = 2021;

			/// <summary>
			/// Property Indexer for QuantityOrdered2
			/// </summary>
			public const int QuantityOrdered2 = 2029;

			/// <summary>
			/// Property Indexer for Requestedby
			/// </summary>
			public const int Requestedby = 2030;

			/// <summary>
			/// Property Indexer for DocumentSource
			/// </summary>
			public const int DocumentSource = 2031;

			/// <summary>
			/// Property Indexer for OptionalFields2
			/// </summary>
			public const int OptionalFields2 = 2032;

			/// <summary>
			/// Property Indexer for JobRelatedLines
			/// </summary>
			public const int JobRelatedLines = 2033;

			/// <summary>
			/// Property Indexer for ShipToLocation
			/// </summary>
			public const int ShipToLocation = 2121;

			/// <summary>
			/// Property Indexer for LocationDescription
			/// </summary>
			public const int LocationDescription = 2122;

			/// <summary>
			/// Property Indexer for ApprovalStatus
			/// </summary>
			public const int ApprovalStatus = 2131;

			/// <summary>
			/// Property Indexer for ApproverID
			/// </summary>
			public const int ApproverID = 2132;

			/// <summary>
			/// Property Indexer for EnteredBy
			/// </summary>
			public const int EnteredBy = 2139;

			/// <summary>
			/// Property Indexer for EXTWEIGHT
			/// </summary>
            public const int ExtendedWeight1 = 2141;

			/// <summary>
			/// Property Indexer for FuncExtendedAmount
			/// </summary>
			public const int FuncExtendedAmount = 2142;

			/// <summary>
			/// Property Indexer for VendorOnHold2
			/// </summary>
			public const int VendorOnHold2 = 2151;

			/// <summary>
			/// Property Indexer for DocumentLocked
			/// </summary>
			public const int DocumentLocked = 2152;

			/// <summary>
			/// Property Indexer for RequisitionHasExpired
			/// </summary>
			public const int RequisitionHasExpired = 2153;

			/// <summary>
			/// Property Indexer for IsDocumentDeletable
			/// </summary>
			public const int IsDocumentDeletable = 2154;

			/// <summary>
			/// Property Indexer for IsRecordActive2
			/// </summary>
			public const int IsRecordActive2 = 2155;

			/// <summary>
			/// Property Indexer for HasDetails
			/// </summary>
			public const int HasDetails = 2156;

			/// <summary>
			/// Property Indexer for IsCanadianPayrollActive
			/// </summary>
			public const int IsCanadianPayrollActive = 2157;

			/// <summary>
            /// Property Indexer for IsUsPayrollActive
			/// </summary>
            public const int IsUsPayrollActive = 2158;

			/// <summary>
			/// Property Indexer for Command2
			/// </summary>
			public const int Command2 = 2159;

			/// <summary>
			/// Property Indexer for JobRelated
			/// </summary>
			public const int JobRelated = 2160;

			/// <summary>
			/// Property Indexer for ApproverName
			/// </summary>
			public const int ApproverName = 2161;

			/// <summary>
			/// Property Indexer for FunctionalCurrency
			/// </summary>
			public const int FunctionalCurrency = 2162;

			/// <summary>
			/// Property Indexer for NextDetailNumber
			/// </summary>
			public const int NextDetailNumber = 2163;
		}
		#endregion
	}
}