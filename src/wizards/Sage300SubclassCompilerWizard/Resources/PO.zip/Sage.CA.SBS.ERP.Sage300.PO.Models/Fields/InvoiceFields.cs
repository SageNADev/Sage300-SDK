// Copyright (c) 1994-2017 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of Invoice Constants
    /// </summary>
    public partial class Invoice
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0420";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"INVNUMBER", "InvoiceNumber"},
					{"VDCODE", "Vendor"},
					{"VDNAME", "Name"},
					{"RCPNUMBER", "ReceiptNumber"},
					{"RCPDATE", "ReceiptDate"},
					{"MULTIRCP", "MultipleReceipts"},
					{"ONHOLD", "OnHold"},
					{"DATE", "InvoiceDate"},
					{"DATEBUS", "PostingDate"},
					{"INVTOTAL", "InvoiceTotal"},
					{"RTCODE", "RemitToLocation"},
					{"BTCODE", "BillToLocation"},
					{"BTDESC", "BillToLocationDescription"},
					{"VDACCTSET", "VendorAccountSet"},
					{"VDACCTDESC", "VendorAccountSetDescription"},
					{"DESCRIPTIO", "Description"},
					{"REFERENCE", "Reference"},
					{"RATETYPE", "RateType"},
					{"RATEDATE", "RateDate"},
					{"RATE", "ExchangeRate"},
					{"RATETYPERC", "TaxReportingRateType"},
					{"RATEDATERC", "TaxReportingRateDate"},
					{"RATERC", "TaxReportingExchangeRate"},
					{"IDN", "ImportDeclarationNumber"},
					{"TAXGROUP", "TaxGroup"},
					{"TERMSCODE", "TermsCode"},
					{"COMMENT", "Comment"},
					{"DISCPCT", "DiscountPercentage"},
					{"DISCOUNT", "DiscountAmount"},
					{"DTPYMTASOF", "PaymentAsOfDate"},
                    {"BTADDRESS1", "BillToAddress1"},
					{"BTADDRESS2", "BillToAddress2"},
					{"BTADDRESS3", "BillToAddress3"},
					{"BTADDRESS4", "BillToAddress4"},
					{"BTCITY", "BillToCity"},
					{"BTSTATE", "BillToStateProvince"},
					{"BTZIP", "BillToZipPostalCode"},
					{"BTCOUNTRY", "BillToCountry"},
					{"BTPHONE", "BillToPhoneNumber"},
					{"BTFAX", "BillToFaxNumber"},
					{"BTCONTACT", "BillToContact"},
                    {"BTEMAIL", "BillToEmail"},
					{"BTPHONEC", "BillToContactPhone"},
					{"BTFAXC", "BillToContactFax"},
					{"BTEMAILC", "BillToContactEmail"},
                    {"VDADDRESS1", "Address1"},
					{"VDADDRESS2", "Address2"},
					{"VDADDRESS3", "Address3"},
					{"VDADDRESS4", "Address4"},
					{"VDCITY", "City"},
					{"VDSTATE", "StateProvince"},
					{"VDZIP", "ZipPostalCode"},
					{"VDCOUNTRY", "Country"},
					{"VDPHONE", "PhoneNumber"},
					{"VDFAX", "FaxNumber"},
					{"VDCONTACT", "Contact"},
					{"VDEMAIL", "Email"},
					{"F1099CLASS", "Num1099CPRSClass"},
					{"F1099AMT", "The1099CPRSAmount"},
                    {"HASRTG", "HasRetainage" },
                    {"RTGRATE", "RetainageExchangeRate"},
                    {"RTGTERMS", "RetainageTermsCode"},
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of Invoice Constants
        /// </summary>
        public class Fields : BaseFields
        { }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of Invoice Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for NextLineSequence
            /// </summary>
            public const int NextLineSequence = 2;

            /// <summary>
            /// Property Indexer for Lines
            /// </summary>
            public const int Lines = 3;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 4;

            /// <summary>
            /// Property Indexer for Costs
            /// </summary>
            public const int Costs = 5;

            /// <summary>
            /// Property Indexer for CostsComplete
            /// </summary>
            public const int CostsComplete = 6;

            /// <summary>
            /// Property Indexer for Payments
            /// </summary>
            public const int Payments = 7;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 8;

            /// <summary>
            /// Property Indexer for Autotaxcalculationonsave
            /// </summary>
            public const int Autotaxcalculationonsave = 9;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 10;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 11;

            /// <summary>
            /// Property Indexer for LastPostingDate
            /// </summary>
            public const int LastPostingDate = 12;

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 13;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 14;

            /// <summary>
            /// Property Indexer for InvoiceDate
            /// </summary>
            public const int InvoiceDate = 15;

            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 16;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 17;

            /// <summary>
            /// Property Indexer for InvoiceNumber
            /// </summary>
            public const int InvoiceNumber = 18;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 19;

            /// <summary>
            /// Property Indexer for VendorExists
            /// </summary>
            public const int VendorExists = 20;

            /// <summary>
            /// Property Indexer for Name
            /// </summary>
            public const int Name = 21;

            /// <summary>
            /// Property Indexer for Address1
            /// </summary>
            public const int Address1 = 22;

            /// <summary>
            /// Property Indexer for Address2
            /// </summary>
            public const int Address2 = 23;

            /// <summary>
            /// Property Indexer for Address3
            /// </summary>
            public const int Address3 = 24;

            /// <summary>
            /// Property Indexer for Address4
            /// </summary>
            public const int Address4 = 25;

            /// <summary>
            /// Property Indexer for City
            /// </summary>
            public const int City = 26;

            /// <summary>
            /// Property Indexer for StateProvince
            /// </summary>
            public const int StateProvince = 27;

            /// <summary>
            /// Property Indexer for ZipPostalCode
            /// </summary>
            public const int ZipPostalCode = 28;

            /// <summary>
            /// Property Indexer for Country
            /// </summary>
            public const int Country = 29;

            /// <summary>
            /// Property Indexer for PhoneNumber
            /// </summary>
            public const int PhoneNumber = 30;

            /// <summary>
            /// Property Indexer for FaxNumber
            /// </summary>
            public const int FaxNumber = 31;

            /// <summary>
            /// Property Indexer for Contact
            /// </summary>
            public const int Contact = 32;

            /// <summary>
            /// Property Indexer for TermsCode
            /// </summary>
            public const int TermsCode = 33;

            /// <summary>
            /// Property Indexer for FromDocument
            /// </summary>
            public const int FromDocument = 34;

            /// <summary>
            /// Property Indexer for PrimaryVendor
            /// </summary>
            public const int PrimaryVendor = 35;

            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 36;

            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 37;

            /// <summary>
            /// Property Indexer for ReceiptDate
            /// </summary>
            public const int ReceiptDate = 38;

            /// <summary>
            /// Property Indexer for ReturnSequenceKey
            /// </summary>
            public const int ReturnSequenceKey = 39;

            /// <summary>
            /// Property Indexer for ReturnNumber
            /// </summary>
            public const int ReturnNumber = 40;

            /// <summary>
            /// Property Indexer for ReturnDate
            /// </summary>
            public const int ReturnDate = 41;

            /// <summary>
            /// Property Indexer for Description
            /// </summary>
            public const int Description = 42;

            /// <summary>
            /// Property Indexer for Reference
            /// </summary>
            public const int Reference = 43;

            /// <summary>
            /// Property Indexer for Comment
            /// </summary>
            public const int Comment = 44;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 53;

            /// <summary>
            /// Property Indexer for ExchangeRate
            /// </summary>
            public const int ExchangeRate = 54;

            /// <summary>
            /// Property Indexer for RateSpread
            /// </summary>
            public const int RateSpread = 55;

            /// <summary>
            /// Property Indexer for RateType
            /// </summary>
            public const int RateType = 56;

            /// <summary>
            /// Property Indexer for RateMatchType
            /// </summary>
            public const int RateMatchType = 57;

            /// <summary>
            /// Property Indexer for RateDate
            /// </summary>
            public const int RateDate = 58;

            /// <summary>
            /// Property Indexer for RateOperation
            /// </summary>
            public const int RateOperation = 59;

            /// <summary>
            /// Property Indexer for RateOverridden
            /// </summary>
            public const int RateOverridden = 60;

            /// <summary>
            /// Property Indexer for DecimalPlaces
            /// </summary>
            public const int DecimalPlaces = 61;

            /// <summary>
            /// Property Indexer for PaymentAsOfDate
            /// </summary>
            public const int PaymentAsOfDate = 62;

            /// <summary>
            /// Property Indexer for TotalTermsAmountDue
            /// </summary>
            public const int TotalTermsAmountDue = 63;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 64;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 65;

            /// <summary>
            /// Property Indexer for Total
            /// </summary>
            public const int Total = 66;

            /// <summary>
            /// Property Indexer for AdditionalCosts
            /// </summary>
            public const int AdditionalCosts = 67;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 68;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 69;

            /// <summary>
            /// Property Indexer for TaxAuthority1
            /// </summary>
            public const int TaxAuthority1 = 70;

            /// <summary>
            /// Property Indexer for TaxAuthority2
            /// </summary>
            public const int TaxAuthority2 = 71;

            /// <summary>
            /// Property Indexer for TaxAuthority3
            /// </summary>
            public const int TaxAuthority3 = 72;

            /// <summary>
            /// Property Indexer for TaxAuthority4
            /// </summary>
            public const int TaxAuthority4 = 73;

            /// <summary>
            /// Property Indexer for TaxAuthority5
            /// </summary>
            public const int TaxAuthority5 = 74;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 75;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 76;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 77;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 78;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 79;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 80;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 81;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 82;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 83;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 84;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 85;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 86;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 87;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 88;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 89;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 90;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 91;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 92;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 93;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 94;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 95;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 96;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 97;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 98;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 99;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 100;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 101;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 102;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 103;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 104;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 105;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 106;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 107;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 108;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 109;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 110;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 111;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 112;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 113;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 114;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 115;

            /// <summary>
            /// Property Indexer for TotalsTaxIncluded
            /// </summary>
            public const int TotalsTaxIncluded = 116;

            /// <summary>
            /// Property Indexer for TotalsTaxExcluded
            /// </summary>
            public const int TotalsTaxExcluded = 117;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 118;

            /// <summary>
            /// Property Indexer for TotalTaxRecoverable
            /// </summary>
            public const int TotalTaxRecoverable = 119;

            /// <summary>
            /// Property Indexer for TotalTaxExpensed
            /// </summary>
            public const int TotalTaxExpensed = 120;

            /// <summary>
            /// Property Indexer for TaxAllocattedAmount
            /// </summary>
            public const int TaxAllocattedAmount = 121;

            /// <summary>
            /// Property Indexer for Num1099CPRSClass
            /// </summary>
            public const int Num1099CPRSClass = 122;

            /// <summary>
            /// Property Indexer for The1099CPRSAmount
            /// </summary>
            public const int The1099CPRSAmount = 123;

            /// <summary>
            /// Property Indexer for ManualProrationTotal
            /// </summary>
            public const int ManualProrationTotal = 124;

            /// <summary>
            /// Property Indexer for ManualToProrate
            /// </summary>
            public const int ManualToProrate = 125;

            /// <summary>
            /// Property Indexer for ManualProrationExpensed
            /// </summary>
            public const int ManualProrationExpensed = 126;

            /// <summary>
            /// Property Indexer for ConversionSourceAmount
            /// </summary>
            public const int ConversionSourceAmount = 127;

            /// <summary>
            /// Property Indexer for ConversionFunctionalAmount
            /// </summary>
            public const int ConversionFunctionalAmount = 128;

            /// <summary>
            /// Property Indexer for MultipleReceipts
            /// </summary>
            public const int MultipleReceipts = 129;

            /// <summary>
            /// Property Indexer for Receipts
            /// </summary>
            public const int Receipts = 130;

            /// <summary>
            /// Property Indexer for BillToLocation
            /// </summary>
            public const int BillToLocation = 131;

            /// <summary>
            /// Property Indexer for BillToLocationDescription
            /// </summary>
            public const int BillToLocationDescription = 132;

            /// <summary>
            /// Property Indexer for BillToAddress1
            /// </summary>
            public const int BillToAddress1 = 133;

            /// <summary>
            /// Property Indexer for BillToAddress2
            /// </summary>
            public const int BillToAddress2 = 134;

            /// <summary>
            /// Property Indexer for BillToAddress3
            /// </summary>
            public const int BillToAddress3 = 135;

            /// <summary>
            /// Property Indexer for BillToAddress4
            /// </summary>
            public const int BillToAddress4 = 136;

            /// <summary>
            /// Property Indexer for BillToCity
            /// </summary>
            public const int BillToCity = 137;

            /// <summary>
            /// Property Indexer for BillToStateProvince
            /// </summary>
            public const int BillToStateProvince = 138;

            /// <summary>
            /// Property Indexer for BillToZipPostalCode
            /// </summary>
            public const int BillToZipPostalCode = 139;

            /// <summary>
            /// Property Indexer for BillToCountry
            /// </summary>
            public const int BillToCountry = 140;

            /// <summary>
            /// Property Indexer for BillToPhoneNumber
            /// </summary>
            public const int BillToPhoneNumber = 141;

            /// <summary>
            /// Property Indexer for BillToFaxNumber
            /// </summary>
            public const int BillToFaxNumber = 142;

            /// <summary>
            /// Property Indexer for BillToContact
            /// </summary>
            public const int BillToContact = 143;

            /// <summary>
            /// Property Indexer for ShipToLocation
            /// </summary>
            public const int ShipToLocation = 144;

            /// <summary>
            /// Property Indexer for ShipToLocationDescription
            /// </summary>
            public const int ShipToLocationDescription = 145;

            /// <summary>
            /// Property Indexer for ShipToAddress1
            /// </summary>
            public const int ShipToAddress1 = 146;

            /// <summary>
            /// Property Indexer for ShipToAddress2
            /// </summary>
            public const int ShipToAddress2 = 147;

            /// <summary>
            /// Property Indexer for ShipToAddress3
            /// </summary>
            public const int ShipToAddress3 = 148;

            /// <summary>
            /// Property Indexer for ShipToAddress4
            /// </summary>
            public const int ShipToAddress4 = 149;

            /// <summary>
            /// Property Indexer for ShipToCity
            /// </summary>
            public const int ShipToCity = 150;

            /// <summary>
            /// Property Indexer for ShipToStateProvince
            /// </summary>
            public const int ShipToStateProvince = 151;

            /// <summary>
            /// Property Indexer for ShipToZipPostalCode
            /// </summary>
            public const int ShipToZipPostalCode = 152;

            /// <summary>
            /// Property Indexer for ShipToCountry
            /// </summary>
            public const int ShipToCountry = 153;

            /// <summary>
            /// Property Indexer for ShipToPhoneNumber
            /// </summary>
            public const int ShipToPhoneNumber = 154;

            /// <summary>
            /// Property Indexer for ShipToFaxNumber
            /// </summary>
            public const int ShipToFaxNumber = 155;

            /// <summary>
            /// Property Indexer for ShipToContact
            /// </summary>
            public const int ShipToContact = 156;

            /// <summary>
            /// Property Indexer for RemitToLocation
            /// </summary>
            public const int RemitToLocation = 157;

            /// <summary>
            /// Property Indexer for RemitToLocationDescription
            /// </summary>
            public const int RemitToLocationDescription = 158;

            /// <summary>
            /// Property Indexer for RemitToAddress1
            /// </summary>
            public const int RemitToAddress1 = 159;

            /// <summary>
            /// Property Indexer for RemitToAddress2
            /// </summary>
            public const int RemitToAddress2 = 160;

            /// <summary>
            /// Property Indexer for RemitToAddress3
            /// </summary>
            public const int RemitToAddress3 = 161;

            /// <summary>
            /// Property Indexer for RemitToAddress4
            /// </summary>
            public const int RemitToAddress4 = 162;

            /// <summary>
            /// Property Indexer for RemitToCity
            /// </summary>
            public const int RemitToCity = 163;

            /// <summary>
            /// Property Indexer for RemitToStateProvince
            /// </summary>
            public const int RemitToStateProvince = 164;

            /// <summary>
            /// Property Indexer for RemitToZipPostalCode
            /// </summary>
            public const int RemitToZipPostalCode = 165;

            /// <summary>
            /// Property Indexer for RemitToCountry
            /// </summary>
            public const int RemitToCountry = 166;

            /// <summary>
            /// Property Indexer for RemitToPhoneNumber
            /// </summary>
            public const int RemitToPhoneNumber = 167;

            /// <summary>
            /// Property Indexer for RemitToFaxNumber
            /// </summary>
            public const int RemitToFaxNumber = 168;

            /// <summary>
            /// Property Indexer for RemitToContact
            /// </summary>
            public const int RemitToContact = 169;

            /// <summary>
            /// Property Indexer for PredecessorsExchangeRate
            /// </summary>
            public const int PredecessorsExchangeRate = 170;

            /// <summary>
            /// Property Indexer for PredecessorsRateType
            /// </summary>
            public const int PredecessorsRateType = 171;

            /// <summary>
            /// Property Indexer for PredecessorsRateDate
            /// </summary>
            public const int PredecessorsRateDate = 172;

            /// <summary>
            /// Property Indexer for PredecessorsRateOperation
            /// </summary>
            public const int PredecessorsRateOperation = 173;

            /// <summary>
            /// Property Indexer for PredecessorsRateOverridden
            /// </summary>
            public const int PredecessorsRateOverridden = 174;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 181;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 182;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 183;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 184;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 185;

            /// <summary>
            /// Property Indexer for TaxAuthority1Description
            /// </summary>
            public const int TaxAuthority1Description = 186;

            /// <summary>
            /// Property Indexer for TaxAuthority2Description
            /// </summary>
            public const int TaxAuthority2Description = 187;

            /// <summary>
            /// Property Indexer for TaxAuthority3Description
            /// </summary>
            public const int TaxAuthority3Description = 188;

            /// <summary>
            /// Property Indexer for TaxAuthority4Description
            /// </summary>
            public const int TaxAuthority4Description = 189;

            /// <summary>
            /// Property Indexer for TaxAuthority5Description
            /// </summary>
            public const int TaxAuthority5Description = 190;

            /// <summary>
            /// Property Indexer for CurrencyDescription
            /// </summary>
            public const int CurrencyDescription = 191;

            /// <summary>
            /// Property Indexer for RateTypeDescription
            /// </summary>
            public const int RateTypeDescription = 192;

            /// <summary>
            /// Property Indexer for LastReceiptNumber
            /// </summary>
            public const int LastReceiptNumber = 193;

            /// <summary>
            /// Property Indexer for NumberOfPostedReceipts
            /// </summary>
            public const int NumberOfPostedReceipts = 194;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 195;

            /// <summary>
            /// Property Indexer for TermsCodeDescription
            /// </summary>
            public const int TermsCodeDescription = 196;

            /// <summary>
            /// Property Indexer for PredecessorsRateTypeDescript
            /// </summary>
            public const int PredecessorsRateTypeDescript = 197;

            /// <summary>
            /// Property Indexer for NetOfTaxSum
            /// </summary>
            public const int NetOfTaxSum = 198;

            /// <summary>
            /// Property Indexer for TaxIncluded1Sum
            /// </summary>
            public const int TaxIncluded1Sum = 199;

            /// <summary>
            /// Property Indexer for TaxIncluded2Sum
            /// </summary>
            public const int TaxIncluded2Sum = 200;

            /// <summary>
            /// Property Indexer for TaxIncluded3Sum
            /// </summary>
            public const int TaxIncluded3Sum = 201;

            /// <summary>
            /// Property Indexer for TaxIncluded4Sum
            /// </summary>
            public const int TaxIncluded4Sum = 202;

            /// <summary>
            /// Property Indexer for TaxIncluded5Sum
            /// </summary>
            public const int TaxIncluded5Sum = 203;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1Sum
            /// </summary>
            public const int TaxAllocatedAmount1Sum = 204;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2Sum
            /// </summary>
            public const int TaxAllocatedAmount2Sum = 205;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3Sum
            /// </summary>
            public const int TaxAllocatedAmount3Sum = 206;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4Sum
            /// </summary>
            public const int TaxAllocatedAmount4Sum = 207;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5Sum
            /// </summary>
            public const int TaxAllocatedAmount5Sum = 208;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1Sum
            /// </summary>
            public const int TaxRecoverableAmount1Sum = 209;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2Sum
            /// </summary>
            public const int TaxRecoverableAmount2Sum = 210;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3Sum
            /// </summary>
            public const int TaxRecoverableAmount3Sum = 211;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4Sum
            /// </summary>
            public const int TaxRecoverableAmount4Sum = 212;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5Sum
            /// </summary>
            public const int TaxRecoverableAmount5Sum = 213;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1Sum
            /// </summary>
            public const int TaxExpenseAmount1Sum = 214;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2Sum
            /// </summary>
            public const int TaxExpenseAmount2Sum = 215;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3Sum
            /// </summary>
            public const int TaxExpenseAmount3Sum = 216;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4Sum
            /// </summary>
            public const int TaxExpenseAmount4Sum = 217;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5Sum
            /// </summary>
            public const int TaxExpenseAmount5Sum = 218;

            /// <summary>
            /// Property Indexer for TaxCalcAllocatedAmount
            /// </summary>
            public const int TaxCalcAllocatedAmount = 219;

            /// <summary>
            /// Property Indexer for TaxCalcIncuded
            /// </summary>
            public const int TaxCalcIncuded = 220;

            /// <summary>
            /// Property Indexer for TaxCalcExcluded
            /// </summary>
            public const int TaxCalcExcluded = 221;

            /// <summary>
            /// Property Indexer for TotalUnbalancedTax
            /// </summary>
            public const int TotalUnbalancedTax = 222;

            /// <summary>
            /// Property Indexer for TotalUnbalancedAllocatedTax
            /// </summary>
            public const int TotalUnbalancedAllocatedTax = 223;

            /// <summary>
            /// Property Indexer for UnbalancedManualProrationAmou
            /// </summary>
            public const int UnbalancedManualProrationAmou = 224;

            /// <summary>
            /// Property Indexer for InvoiceTotal
            /// </summary>
            public const int InvoiceTotal = 225;

            /// <summary>
            /// Property Indexer for Subtotal
            /// </summary>
            public const int Subtotal = 226;

            /// <summary>
            /// Property Indexer for TaxcalculationIspending
            /// </summary>
            public const int TaxcalculationIspending = 227;

            /// <summary>
            /// Property Indexer for SubjectTo1099CPRSReporting
            /// </summary>
            public const int SubjectTo1099CPRSReporting = 228;

            /// <summary>
            /// Property Indexer for DocumentLocked
            /// </summary>
            public const int DocumentLocked = 229;

            /// <summary>
            /// Property Indexer for IsDocumentDeletable
            /// </summary>
            public const int IsDocumentDeletable = 230;

            /// <summary>
            /// Property Indexer for ExchangeRateExists
            /// </summary>
            public const int ExchangeRateExists = 231;

            /// <summary>
            /// Property Indexer for HasDetails
            /// </summary>
            public const int HasDetails = 232;

            /// <summary>
            /// Property Indexer for NumberOfCostGroups
            /// </summary>
            public const int NumberOfCostGroups = 233;

            /// <summary>
            /// Property Indexer for Email
            /// </summary>
            public const int Email = 234;

            /// <summary>
            /// Property Indexer for ContactPhone
            /// </summary>
            public const int ContactPhone = 235;

            /// <summary>
            /// Property Indexer for ContactFax
            /// </summary>
            public const int ContactFax = 236;

            /// <summary>
            /// Property Indexer for ContactEmail
            /// </summary>
            public const int ContactEmail = 237;

            /// <summary>
            /// Property Indexer for BillToEmail
            /// </summary>
            public const int BillToEmail = 238;

            /// <summary>
            /// Property Indexer for BillToContactPhone
            /// </summary>
            public const int BillToContactPhone = 239;

            /// <summary>
            /// Property Indexer for BillToContactFax
            /// </summary>
            public const int BillToContactFax = 240;

            /// <summary>
            /// Property Indexer for BillToContactEmail
            /// </summary>
            public const int BillToContactEmail = 241;

            /// <summary>
            /// Property Indexer for ShipToEmail
            /// </summary>
            public const int ShipToEmail = 242;

            /// <summary>
            /// Property Indexer for ShipToContactPhone
            /// </summary>
            public const int ShipToContactPhone = 243;

            /// <summary>
            /// Property Indexer for ShipToContactFax
            /// </summary>
            public const int ShipToContactFax = 244;

            /// <summary>
            /// Property Indexer for ShipToContactEmail
            /// </summary>
            public const int ShipToContactEmail = 245;

            /// <summary>
            /// Property Indexer for RemitToEmail
            /// </summary>
            public const int RemitToEmail = 246;

            /// <summary>
            /// Property Indexer for RemitToContactPhone
            /// </summary>
            public const int RemitToContactPhone = 247;

            /// <summary>
            /// Property Indexer for RemitToContactFax
            /// </summary>
            public const int RemitToContactFax = 248;

            /// <summary>
            /// Property Indexer for RemitToContactEmail
            /// </summary>
            public const int RemitToContactEmail = 249;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 250;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 251;

            /// <summary>
            /// Property Indexer for DiscountAmountSum
            /// </summary>
            public const int DiscountAmountSum = 252;

            /// <summary>
            /// Property Indexer for NetExtendedCost
            /// </summary>
            public const int NetExtendedCost = 253;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 254;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 255;

            /// <summary>
            /// Property Indexer for OnHold
            /// </summary>
            public const int OnHold = 256;

            /// <summary>
            /// Property Indexer for PaymentDiscountBaseWithTax
            /// </summary>
            public const int PaymentDiscountBaseWithTax = 257;

            /// <summary>
            /// Property Indexer for PaymentDiscountBaseWithoutTa
            /// </summary>
            public const int PaymentDiscountBaseWithoutTa = 258;

            /// <summary>
            /// Property Indexer for ProrationVersion
            /// </summary>
            public const int ProrationVersion = 259;

            /// <summary>
            /// Property Indexer for HasRetainage
            /// </summary>
            public const int HasRetainage = 260;

            /// <summary>
            /// Property Indexer for RetainageExchangeRate
            /// </summary>
            public const int RetainageExchangeRate = 261;

            /// <summary>
            /// Property Indexer for RetainageBase
            /// </summary>
            public const int RetainageBase = 262;

            /// <summary>
            /// Property Indexer for RetainageTermsCode
            /// </summary>
            public const int RetainageTermsCode = 263;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 264;

            /// <summary>
            /// Property Indexer for JobRelatedLines
            /// </summary>
            public const int JobRelatedLines = 265;

            /// <summary>
            /// Property Indexer for JobRelatedCosts
            /// </summary>
            public const int JobRelatedCosts = 266;

            /// <summary>
            /// Property Indexer for RetainageTermsCodeDescription
            /// </summary>
            public const int RetainageTermsCodeDescription = 267;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 268;

            /// <summary>
            /// Property Indexer for UnretainedTotal
            /// </summary>
            public const int UnretainedTotal = 269;

            /// <summary>
            /// Property Indexer for TaxReportingCurrency
            /// </summary>
            public const int TaxReportingCurrency = 270;

            /// <summary>
            /// Property Indexer for TaxReportingExchangeRate
            /// </summary>
            public const int TaxReportingExchangeRate = 271;

            /// <summary>
            /// Property Indexer for TaxReportingRateSpread
            /// </summary>
            public const int TaxReportingRateSpread = 272;

            /// <summary>
            /// Property Indexer for TaxReportingRateType
            /// </summary>
            public const int TaxReportingRateType = 273;

            /// <summary>
            /// Property Indexer for TaxReportingRateMatchType
            /// </summary>
            public const int TaxReportingRateMatchType = 274;

            /// <summary>
            /// Property Indexer for TaxReportingRateDate
            /// </summary>
            public const int TaxReportingRateDate = 275;

            /// <summary>
            /// Property Indexer for TaxReportingRateOperation
            /// </summary>
            public const int TaxReportingRateOperation = 276;

            /// <summary>
            /// Property Indexer for TaxReportingRateOverridden
            /// </summary>
            public const int TaxReportingRateOverridden = 277;

            /// <summary>
            /// Property Indexer for TaxReportingDecimalPlaces
            /// </summary>
            public const int TaxReportingDecimalPlaces = 278;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 279;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 280;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 281;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 282;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 283;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 284;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 285;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 286;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 287;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 288;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 289;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 290;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 291;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 292;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 293;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 294;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 295;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 296;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 297;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 298;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 299;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 300;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 301;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 302;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 303;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 304;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 305;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 306;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 307;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 308;

            /// <summary>
            /// Property Indexer for PredTaxReportingExchRate
            /// </summary>
            public const int PredTaxReportingExchRate = 309;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateType
            /// </summary>
            public const int PredTaxReportingRateType = 310;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateDate
            /// </summary>
            public const int PredTaxReportingRateDate = 311;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateOper
            /// </summary>
            public const int PredTaxReportingRateOper = 312;

            /// <summary>
            /// Property Indexer for PredTaxReportingRateOverrd
            /// </summary>
            public const int PredTaxReportingRateOverrd = 313;

            /// <summary>
            /// Property Indexer for TaxReportingExchRateExists
            /// </summary>
            public const int TaxReportingExchRateExists = 314;

            /// <summary>
            /// Property Indexer for DerivedTaxReportingExchRate
            /// </summary>
            public const int DerivedTaxReportingExchRate = 315;

            /// <summary>
            /// Property Indexer for TaxReportingCurrencyDesc
            /// </summary>
            public const int TaxReportingCurrencyDesc = 316;

            /// <summary>
            /// Property Indexer for TaxReportingRateTypeDesc
            /// </summary>
            public const int TaxReportingRateTypeDesc = 317;

            /// <summary>
            /// Property Indexer for PredTaxRepRateTypeDesc
            /// </summary>
            public const int PredTaxRepRateTypeDesc = 318;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 319;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 320;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 321;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 322;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 323;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 324;

            /// <summary>
            /// Property Indexer for TaxBase1Sum
            /// </summary>
            public const int TaxBase1Sum = 325;

            /// <summary>
            /// Property Indexer for TaxBase2Sum
            /// </summary>
            public const int TaxBase2Sum = 326;

            /// <summary>
            /// Property Indexer for TaxBase3Sum
            /// </summary>
            public const int TaxBase3Sum = 327;

            /// <summary>
            /// Property Indexer for TaxBase4Sum
            /// </summary>
            public const int TaxBase4Sum = 328;

            /// <summary>
            /// Property Indexer for TaxBase5Sum
            /// </summary>
            public const int TaxBase5Sum = 329;

            /// <summary>
            /// Property Indexer for TaxAmount1Sum
            /// </summary>
            public const int TaxAmount1Sum = 330;

            /// <summary>
            /// Property Indexer for TaxAmount2Sum
            /// </summary>
            public const int TaxAmount2Sum = 331;

            /// <summary>
            /// Property Indexer for TaxAmount3Sum
            /// </summary>
            public const int TaxAmount3Sum = 332;

            /// <summary>
            /// Property Indexer for TaxAmount4Sum
            /// </summary>
            public const int TaxAmount4Sum = 333;

            /// <summary>
            /// Property Indexer for TaxAmount5Sum
            /// </summary>
            public const int TaxAmount5Sum = 334;

            /// <summary>
            /// Property Indexer for TaxExcluded1Sum
            /// </summary>
            public const int TaxExcluded1Sum = 335;

            /// <summary>
            /// Property Indexer for TaxExcluded2Sum
            /// </summary>
            public const int TaxExcluded2Sum = 336;

            /// <summary>
            /// Property Indexer for TaxExcluded3Sum
            /// </summary>
            public const int TaxExcluded3Sum = 337;

            /// <summary>
            /// Property Indexer for TaxExcluded4Sum
            /// </summary>
            public const int TaxExcluded4Sum = 338;

            /// <summary>
            /// Property Indexer for TaxExcluded5Sum
            /// </summary>
            public const int TaxExcluded5Sum = 339;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1Sum
            /// </summary>
            public const int TaxReportingAmount1Sum = 340;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2Sum
            /// </summary>
            public const int TaxReportingAmount2Sum = 341;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3Sum
            /// </summary>
            public const int TaxReportingAmount3Sum = 342;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4Sum
            /// </summary>
            public const int TaxReportingAmount4Sum = 343;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5Sum
            /// </summary>
            public const int TaxReportingAmount5Sum = 344;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded1Sum
            /// </summary>
            public const int TaxReportingIncluded1Sum = 345;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded2Sum
            /// </summary>
            public const int TaxReportingIncluded2Sum = 346;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded3Sum
            /// </summary>
            public const int TaxReportingIncluded3Sum = 347;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded4Sum
            /// </summary>
            public const int TaxReportingIncluded4Sum = 348;

            /// <summary>
            /// Property Indexer for TaxReportingIncluded5Sum
            /// </summary>
            public const int TaxReportingIncluded5Sum = 349;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded1Sum
            /// </summary>
            public const int TaxReportingExcluded1Sum = 350;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded2Sum
            /// </summary>
            public const int TaxReportingExcluded2Sum = 351;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded3Sum
            /// </summary>
            public const int TaxReportingExcluded3Sum = 352;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded4Sum
            /// </summary>
            public const int TaxReportingExcluded4Sum = 353;

            /// <summary>
            /// Property Indexer for TaxReportingExcluded5Sum
            /// </summary>
            public const int TaxReportingExcluded5Sum = 354;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount1Sum
            /// </summary>
            public const int TaxRepAllocatedAmount1Sum = 355;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount2Sum
            /// </summary>
            public const int TaxRepAllocatedAmount2Sum = 356;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount3Sum
            /// </summary>
            public const int TaxRepAllocatedAmount3Sum = 357;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount4Sum
            /// </summary>
            public const int TaxRepAllocatedAmount4Sum = 358;

            /// <summary>
            /// Property Indexer for TaxRepAllocatedAmount5Sum
            /// </summary>
            public const int TaxRepAllocatedAmount5Sum = 359;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt1Sum
            /// </summary>
            public const int TaxRepRecoverableAmt1Sum = 360;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt2Sum
            /// </summary>
            public const int TaxRepRecoverableAmt2Sum = 361;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt3Sum
            /// </summary>
            public const int TaxRepRecoverableAmt3Sum = 362;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt4Sum
            /// </summary>
            public const int TaxRepRecoverableAmt4Sum = 363;

            /// <summary>
            /// Property Indexer for TaxRepRecoverableAmt5Sum
            /// </summary>
            public const int TaxRepRecoverableAmt5Sum = 364;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount1Sum
            /// </summary>
            public const int TaxRepExpenseAmount1Sum = 365;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount2Sum
            /// </summary>
            public const int TaxRepExpenseAmount2Sum = 366;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount3Sum
            /// </summary>
            public const int TaxRepExpenseAmount3Sum = 367;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount4Sum
            /// </summary>
            public const int TaxRepExpenseAmount4Sum = 368;

            /// <summary>
            /// Property Indexer for TaxRepExpenseAmount5Sum
            /// </summary>
            public const int TaxRepExpenseAmount5Sum = 369;

            /// <summary>
            /// Property Indexer for ReportRetainageTax
            /// </summary>
            public const int ReportRetainageTax = 370;

            /// <summary>
            /// Property Indexer for TaxStateVersion
            /// </summary>
            public const int TaxStateVersion = 371;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 372;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 373;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 374;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 375;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 376;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 377;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 378;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 379;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 380;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 381;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt1
            /// </summary>
            public const int RetainageTaxRecoverableAmt1 = 382;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt2
            /// </summary>
            public const int RetainageTaxRecoverableAmt2 = 383;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt3
            /// </summary>
            public const int RetainageTaxRecoverableAmt3 = 384;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt4
            /// </summary>
            public const int RetainageTaxRecoverableAmt4 = 385;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt5
            /// </summary>
            public const int RetainageTaxRecoverableAmt5 = 386;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount1
            /// </summary>
            public const int RetainageTaxExpenseAmount1 = 387;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount2
            /// </summary>
            public const int RetainageTaxExpenseAmount2 = 388;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount3
            /// </summary>
            public const int RetainageTaxExpenseAmount3 = 389;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount4
            /// </summary>
            public const int RetainageTaxExpenseAmount4 = 390;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount5
            /// </summary>
            public const int RetainageTaxExpenseAmount5 = 391;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount1
            /// </summary>
            public const int RetainageTaxAllocatedAmount1 = 392;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount2
            /// </summary>
            public const int RetainageTaxAllocatedAmount2 = 393;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount3
            /// </summary>
            public const int RetainageTaxAllocatedAmount3 = 394;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount4
            /// </summary>
            public const int RetainageTaxAllocatedAmount4 = 395;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount5
            /// </summary>
            public const int RetainageTaxAllocatedAmount5 = 396;

            /// <summary>
            /// Property Indexer for WarnOnRetainageTaxShift
            /// </summary>
            public const int WarnOnRetainageTaxShift = 397;

            /// <summary>
            /// Property Indexer for RetainageTaxTotalAmount
            /// </summary>
            public const int RetainageTaxTotalAmount = 398;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt1 = 399;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt2 = 400;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt3 = 401;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt4 = 402;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt5 = 403;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1Sum
            /// </summary>
            public const int RetainageTaxBase1Sum = 404;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2Sum
            /// </summary>
            public const int RetainageTaxBase2Sum = 405;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3Sum
            /// </summary>
            public const int RetainageTaxBase3Sum = 406;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4Sum
            /// </summary>
            public const int RetainageTaxBase4Sum = 407;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5Sum
            /// </summary>
            public const int RetainageTaxBase5Sum = 408;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1Sum
            /// </summary>
            public const int RetainageTaxAmount1Sum = 409;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2Sum
            /// </summary>
            public const int RetainageTaxAmount2Sum = 410;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3Sum
            /// </summary>
            public const int RetainageTaxAmount3Sum = 411;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4Sum
            /// </summary>
            public const int RetainageTaxAmount4Sum = 412;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5Sum
            /// </summary>
            public const int RetainageTaxAmount5Sum = 413;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt1Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt1Sum = 414;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt2Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt2Sum = 415;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt3Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt3Sum = 416;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt4Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt4Sum = 417;

            /// <summary>
            /// Property Indexer for RtgTaxRecoverableAmt5Sum
            /// </summary>
            public const int RtgTaxRecoverableAmt5Sum = 418;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount1Sum
            /// </summary>
            public const int RtgTaxExpenseAmount1Sum = 419;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount2Sum
            /// </summary>
            public const int RtgTaxExpenseAmount2Sum = 420;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount3Sum
            /// </summary>
            public const int RtgTaxExpenseAmount3Sum = 421;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount4Sum
            /// </summary>
            public const int RtgTaxExpenseAmount4Sum = 422;

            /// <summary>
            /// Property Indexer for RtgTaxExpenseAmount5Sum
            /// </summary>
            public const int RtgTaxExpenseAmount5Sum = 423;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount1Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount1Sum = 424;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount2Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount2Sum = 425;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount3Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount3Sum = 426;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount4Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount4Sum = 427;

            /// <summary>
            /// Property Indexer for RtgTaxAllocatedAmount5Sum
            /// </summary>
            public const int RtgTaxAllocatedAmount5Sum = 428;

            /// <summary>
            /// Property Indexer for VendorAccountSet
            /// </summary>
            public const int VendorAccountSet = 429;

            /// <summary>
            /// Property Indexer for VendorAccountSetDescription
            /// </summary>
            public const int VendorAccountSetDescription = 430;

            /// <summary>
            /// Property Indexer for PostingDate
            /// </summary>
            public const int PostingDate = 431;

            /// <summary>
            /// Property Indexer for EnteredBy
            /// </summary>
            public const int EnteredBy = 432;

            /// <summary>
            /// Property Indexer for NextDetailNumber
            /// </summary>
            public const int NextDetailNumber = 433;

            /// <summary>
            /// Property Indexer for ImportDeclarationNumber
            /// </summary>
            public const int ImportDeclarationNumber = 434;

            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 435;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 436;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 437;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 438;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 439;
            /// <summary>
            /// Property Indexer for customer detail tax amount 1
            /// </summary>
            public const int CustomerDetailTaxAmount1 = 440;
            /// <summary>
            /// Property Indexer for customer detail tax amount 2
            /// </summary>
            public const int CustomerDetailTaxAmount2 = 441;
            /// <summary>
            /// Property Indexer for customer detail tax amount 3
            /// </summary>
            public const int CustomerDetailTaxAmount3 = 442;
            /// <summary>
            /// Property Indexer for customer detail tax amount 4
            /// </summary>
            public const int CustomerDetailTaxAmount4 = 443;
            /// <summary>
            /// Property Indexer for customer detail tax amount 5
            /// </summary>
            public const int CustomerDetailTaxAmount5 = 444;

            /// <summary>
            /// Property Indexer for customer tax amount 1
            /// </summary>
            public const int CustomerTaxAmount1 = 450;
            /// <summary>
            /// Property Indexer for customer tax amount 2
            /// </summary>
            public const int CustomerTaxAmount2 = 451;
            /// <summary>
            /// Property Indexer for customer tax amount 3
            /// </summary>
            public const int CustomerTaxAmount3 = 452;
            /// <summary>
            /// Property Indexer for customer tax amount 4
            /// </summary>
            public const int CustomerTaxAmount4 = 453;
            /// <summary>
            /// Property Indexer for customer tax amount 5
            /// </summary>
            public const int CustomerTaxAmount5 = 454;
            /// <summary>
            /// Property Indexer for customer tax amount
            /// </summary>
            public const int CustomerTaxAmount = 455;
            /// <summary>
            /// Property Indexer for Excluded Tax Less Reverse Charge
            /// </summary>
            public const int ExcludedTaxLessReverseCharge = 456;

        }

        #endregion

        #region Keys

        /// <summary>
        /// Adjustment Keys
        /// </summary>
        public class Keys
        {
            /// <summary>
            /// Adjustment Number Key
            /// </summary>
            public const int InvoiceSequenceKey = 1;
        }

        #endregion
    }
}
