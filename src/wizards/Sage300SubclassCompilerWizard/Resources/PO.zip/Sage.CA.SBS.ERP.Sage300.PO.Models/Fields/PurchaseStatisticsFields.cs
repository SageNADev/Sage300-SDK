// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of Statistic Constants
    /// </summary>
    public partial class PurchaseStatistics
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0800";

        #region Properties
        /// <summary>
        /// Contains list of Statistic Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for FiscalYear
            /// </summary>
            public const string FiscalYear = "FISCYEAR";

            /// <summary>
            /// Property for FiscalPeriod
            /// </summary>
            public const string FiscalPeriod = "PERIOD";

            /// <summary>
            /// Property for Currency
            /// </summary>
            public const string Currency = "CURRENCY";

            /// <summary>
            /// Property for NumberOfPurchaseOrders
            /// </summary>
            public const string NumberOfPurchaseOrders = "POCOUNT";

            /// <summary>
            /// Property for NumberOfReceipts
            /// </summary>
            public const string NumberOfReceipts = "RECPCOUNT";

            /// <summary>
            /// Property for NetQuantityPurchased
            /// </summary>
            public const string NetQuantityPurchased = "QTYPURCH";

            /// <summary>
            /// Property for FuncNetPurchaseAmount
            /// </summary>
            public const string FuncNetPurchaseAmount = "PURCHAMTF";

            /// <summary>
            /// Property for SrceNetPurchaseAmount
            /// </summary>
            public const string SrceNetPurchaseAmount = "PURCHAMTS";

            /// <summary>
            /// Property for FuncInvoiceAmount
            /// </summary>
            public const string FuncInvoiceAmount = "INVAMTF";

            /// <summary>
            /// Property for SrceInvoiceAmount
            /// </summary>
            public const string SrceInvoiceAmount = "INVAMTS";

            /// <summary>
            /// Property for NumberOfInvoices
            /// </summary>
            public const string NumberOfInvoices = "INVCOUNT";

            /// <summary>
            /// Property for FuncAverageInvoice
            /// </summary>
            public const string FuncAverageInvoice = "AVGINVF";

            /// <summary>
            /// Property for SrceAverageInvoice
            /// </summary>
            public const string SrceAverageInvoice = "AVGINVS";

            /// <summary>
            /// Property for FuncLargestInvoice
            /// </summary>
            public const string FuncLargestInvoice = "LARGSTINF";

            /// <summary>
            /// Property for SrceLargestInvoice
            /// </summary>
            public const string SrceLargestInvoice = "LARGSTINS";

            /// <summary>
            /// Property for LargestInvoiceVendor
            /// </summary>
            public const string LargestInvoiceVendor = "LINVVEND";

            /// <summary>
            /// Property for FuncSmallestInvoice
            /// </summary>
            public const string FuncSmallestInvoice = "SMALSTINF";

            /// <summary>
            /// Property for SrceSmallestInvoice
            /// </summary>
            public const string SrceSmallestInvoice = "SMALSTINS";

            /// <summary>
            /// Property for SmallestInvoiceVendor
            /// </summary>
            public const string SmallestInvoiceVendor = "SINVVEND";

            /// <summary>
            /// Property for FuncCreditNoteAmount
            /// </summary>
            public const string FuncCreditNoteAmount = "CNAMTF";

            /// <summary>
            /// Property for SrceCreditNoteAmount
            /// </summary>
            public const string SrceCreditNoteAmount = "CNAMTS";

            /// <summary>
            /// Property for NumberOfCreditNotes
            /// </summary>
            public const string NumberOfCreditNotes = "CNCOUNT";

            /// <summary>
            /// Property for FuncAverageCreditNote
            /// </summary>
            public const string FuncAverageCreditNote = "AVGCNF";

            /// <summary>
            /// Property for SrceAverageCreditNote
            /// </summary>
            public const string SrceAverageCreditNote = "AVGCNS";

            /// <summary>
            /// Property for FuncLargestCreditNote
            /// </summary>
            public const string FuncLargestCreditNote = "LARGSTCNF";

            /// <summary>
            /// Property for SrceLargestCreditNote
            /// </summary>
            public const string SrceLargestCreditNote = "LARGSTCNS";

            /// <summary>
            /// Property for LargestCreditNoteVendor
            /// </summary>
            public const string LargestCreditNoteVendor = "LCNVEND";

            /// <summary>
            /// Property for FuncSmallestCreditNote
            /// </summary>
            public const string FuncSmallestCreditNote = "SMALSTCNF";

            /// <summary>
            /// Property for SrceSmallestCreditNote
            /// </summary>
            public const string SrceSmallestCreditNote = "SMALSTCNS";

            /// <summary>
            /// Property for SmallestCreditNoteVendor
            /// </summary>
            public const string SmallestCreditNoteVendor = "SCNVEND";

            /// <summary>
            /// Property for FuncDebitNoteAmount
            /// </summary>
            public const string FuncDebitNoteAmount = "DNAMTF";

            /// <summary>
            /// Property for SrceDebitNoteAmount
            /// </summary>
            public const string SrceDebitNoteAmount = "DNAMTS";

            /// <summary>
            /// Property for NumberOfDebitNotes
            /// </summary>
            public const string NumberOfDebitNotes = "DNCOUNT";

            /// <summary>
            /// Property for FuncAverageDebitNote
            /// </summary>
            public const string FuncAverageDebitNote = "AVGDNF";

            /// <summary>
            /// Property for SrceAverageDebitNote
            /// </summary>
            public const string SrceAverageDebitNote = "AVGDNS";

            /// <summary>
            /// Property for FuncLargestDebitNote
            /// </summary>
            public const string FuncLargestDebitNote = "LARGSTDNF";

            /// <summary>
            /// Property for SrceLargestDebitNote
            /// </summary>
            public const string SrceLargestDebitNote = "LARGSTDNS";

            /// <summary>
            /// Property for LargestDebitNoteVendor
            /// </summary>
            public const string LargestDebitNoteVendor = "LDNVEND";

            /// <summary>
            /// Property for FuncSmallestDebitNote
            /// </summary>
            public const string FuncSmallestDebitNote = "SMALSTDNF";

            /// <summary>
            /// Property for SrceSmallestDebitNote
            /// </summary>
            public const string SrceSmallestDebitNote = "SMALSTDNS";

            /// <summary>
            /// Property for SmallestDebitNoteVendor
            /// </summary>
            public const string SmallestDebitNoteVendor = "SDNVEND";
        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of Statistic Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FiscalYear
            /// </summary>
            public const int FiscalYear = 1;

            /// <summary>
            /// Property Indexer for FiscalPeriod
            /// </summary>
            public const int FiscalPeriod = 2;

            /// <summary>
            /// Property Indexer for Currency
            /// </summary>
            public const int Currency = 3;

            /// <summary>
            /// Property Indexer for NumberOfPurchaseOrders
            /// </summary>
            public const int NumberOfPurchaseOrders = 4;

            /// <summary>
            /// Property Indexer for NumberOfReceipts
            /// </summary>
            public const int NumberOfReceipts = 5;

            /// <summary>
            /// Property Indexer for NetQuantityPurchased
            /// </summary>
            public const int NetQuantityPurchased = 6;

            /// <summary>
            /// Property Indexer for FuncNetPurchaseAmount
            /// </summary>
            public const int FuncNetPurchaseAmount = 7;

            /// <summary>
            /// Property Indexer for SrceNetPurchaseAmount
            /// </summary>
            public const int SrceNetPurchaseAmount = 8;

            /// <summary>
            /// Property Indexer for FuncInvoiceAmount
            /// </summary>
            public const int FuncInvoiceAmount = 9;

            /// <summary>
            /// Property Indexer for SrceInvoiceAmount
            /// </summary>
            public const int SrceInvoiceAmount = 10;

            /// <summary>
            /// Property Indexer for NumberOfInvoices
            /// </summary>
            public const int NumberOfInvoices = 11;

            /// <summary>
            /// Property Indexer for FuncAverageInvoice
            /// </summary>
            public const int FuncAverageInvoice = 12;

            /// <summary>
            /// Property Indexer for SrceAverageInvoice
            /// </summary>
            public const int SrceAverageInvoice = 13;

            /// <summary>
            /// Property Indexer for FuncLargestInvoice
            /// </summary>
            public const int FuncLargestInvoice = 14;

            /// <summary>
            /// Property Indexer for SrceLargestInvoice
            /// </summary>
            public const int SrceLargestInvoice = 15;

            /// <summary>
            /// Property Indexer for LargestInvoiceVendor
            /// </summary>
            public const int LargestInvoiceVendor = 16;

            /// <summary>
            /// Property Indexer for FuncSmallestInvoice
            /// </summary>
            public const int FuncSmallestInvoice = 17;

            /// <summary>
            /// Property Indexer for SrceSmallestInvoice
            /// </summary>
            public const int SrceSmallestInvoice = 18;

            /// <summary>
            /// Property Indexer for SmallestInvoiceVendor
            /// </summary>
            public const int SmallestInvoiceVendor = 19;

            /// <summary>
            /// Property Indexer for FuncCreditNoteAmount
            /// </summary>
            public const int FuncCreditNoteAmount = 20;

            /// <summary>
            /// Property Indexer for SrceCreditNoteAmount
            /// </summary>
            public const int SrceCreditNoteAmount = 21;

            /// <summary>
            /// Property Indexer for NumberOfCreditNotes
            /// </summary>
            public const int NumberOfCreditNotes = 22;

            /// <summary>
            /// Property Indexer for FuncAverageCreditNote
            /// </summary>
            public const int FuncAverageCreditNote = 23;

            /// <summary>
            /// Property Indexer for SrceAverageCreditNote
            /// </summary>
            public const int SrceAverageCreditNote = 24;

            /// <summary>
            /// Property Indexer for FuncLargestCreditNote
            /// </summary>
            public const int FuncLargestCreditNote = 25;

            /// <summary>
            /// Property Indexer for SrceLargestCreditNote
            /// </summary>
            public const int SrceLargestCreditNote = 26;

            /// <summary>
            /// Property Indexer for LargestCreditNoteVendor
            /// </summary>
            public const int LargestCreditNoteVendor = 27;

            /// <summary>
            /// Property Indexer for FuncSmallestCreditNote
            /// </summary>
            public const int FuncSmallestCreditNote = 28;

            /// <summary>
            /// Property Indexer for SrceSmallestCreditNote
            /// </summary>
            public const int SrceSmallestCreditNote = 29;

            /// <summary>
            /// Property Indexer for SmallestCreditNoteVendor
            /// </summary>
            public const int SmallestCreditNoteVendor = 30;

            /// <summary>
            /// Property Indexer for FuncDebitNoteAmount
            /// </summary>
            public const int FuncDebitNoteAmount = 31;

            /// <summary>
            /// Property Indexer for SrceDebitNoteAmount
            /// </summary>
            public const int SrceDebitNoteAmount = 32;

            /// <summary>
            /// Property Indexer for NumberOfDebitNotes
            /// </summary>
            public const int NumberOfDebitNotes = 33;

            /// <summary>
            /// Property Indexer for FuncAverageDebitNote
            /// </summary>
            public const int FuncAverageDebitNote = 34;

            /// <summary>
            /// Property Indexer for SrceAverageDebitNote
            /// </summary>
            public const int SrceAverageDebitNote = 35;

            /// <summary>
            /// Property Indexer for FuncLargestDebitNote
            /// </summary>
            public const int FuncLargestDebitNote = 36;

            /// <summary>
            /// Property Indexer for SrceLargestDebitNote
            /// </summary>
            public const int SrceLargestDebitNote = 37;

            /// <summary>
            /// Property Indexer for LargestDebitNoteVendor
            /// </summary>
            public const int LargestDebitNoteVendor = 38;

            /// <summary>
            /// Property Indexer for FuncSmallestDebitNote
            /// </summary>
            public const int FuncSmallestDebitNote = 39;

            /// <summary>
            /// Property Indexer for SrceSmallestDebitNote
            /// </summary>
            public const int SrceSmallestDebitNote = 40;

            /// <summary>
            /// Property Indexer for SmallestDebitNoteVendor
            /// </summary>
            public const int SmallestDebitNoteVendor = 41;
        }
        #endregion
    }
}
