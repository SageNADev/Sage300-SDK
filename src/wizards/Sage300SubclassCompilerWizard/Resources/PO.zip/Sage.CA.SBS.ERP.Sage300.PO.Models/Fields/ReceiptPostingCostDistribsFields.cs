// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptPostingCostDistribs Constants
    /// </summary>
    public partial class ReceiptPostingCostDistribs
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0697";

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of ReceiptPostingCostDistribs. Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for HeaderSequence
            /// </summary>
            public const string HeaderSequence = "RCPISEQ";

            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for ReceiptCostSequence
            /// </summary>
            public const string ReceiptCostSequence = "RCPSSEQ";

            /// <summary>
            /// Property for LineSequence
            /// </summary>
            public const string LineSequence = "LSEQ";

            /// <summary>
            /// Property for OperationToPost
            /// </summary>
            public const string OperationToPost = "OPERATION";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ReceiptPostingCostDistribs. Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for HeaderSequence
            /// </summary>
            public const int HeaderSequence = 1;

            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 2;

            /// <summary>
            /// Property Indexer for ReceiptCostSequence
            /// </summary>
            public const int ReceiptCostSequence = 3;

            /// <summary>
            /// Property Indexer for LineSequence
            /// </summary>
            public const int LineSequence = 4;

            /// <summary>
            /// Property Indexer for OperationToPost
            /// </summary>
            public const int OperationToPost = 5;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 6;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 7;
        }

        #endregion
    }
}