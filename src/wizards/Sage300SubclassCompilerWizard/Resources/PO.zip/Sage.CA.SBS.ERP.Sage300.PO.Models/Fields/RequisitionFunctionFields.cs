// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of RequisitionFunction Constants
     /// </summary>
     public partial class RequisitionFunction
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0759";

         /// <summary>
         /// Dynamic Attributes contain a reverse mapping of field and property
         /// </summary>
         public static Dictionary<string, string> DynamicAttributes
         {
             get
             {
                 return new Dictionary<string, string>();
             }
         }

          #region Properties
          /// <summary>
          /// Contains list of RequisitionFunction Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for RequisitionSequenceKey
               /// </summary>
               public const string RequisitionSequenceKey = "RQNHSEQ";

               /// <summary>
               /// Property for SequenceToRetrieve
               /// </summary>
               public const string SequenceToRetrieve = "LOADSEQ";

               /// <summary>
               /// Property for Function
               /// </summary>
               public const string Function = "FUNCTION";
          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of RequisitionFunction Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for RequisitionSequenceKey
               /// </summary>
               public const int RequisitionSequenceKey = 1;

               /// <summary>
               /// Property Indexer for SequenceToRetrieve
               /// </summary>
               public const int SequenceToRetrieve = 2;

               /// <summary>
               /// Property Indexer for Function
               /// </summary>
               public const int Function = 3;
          }
          #endregion
     }
}