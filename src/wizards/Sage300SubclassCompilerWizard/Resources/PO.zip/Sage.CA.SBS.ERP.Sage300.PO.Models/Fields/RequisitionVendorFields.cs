// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of RequisitionVendor Constants
     /// </summary>
     public partial class RequisitionVendor
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0777";

         /// <summary>
         /// Dynamic Attributes contain a reverse mapping of field and property
         /// </summary>
         public static Dictionary<string, string> DynamicAttributes
         {
             get
             {
                 return new Dictionary<string, string>
				{
					{"LINES", "Lines"},
					{"LINESCMPL", "LinesComplete"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"VDEXISTS", "VendorExists"},
					{"CURRENCY", "Currency"},
					{"RATE", "ExchangeRate"},
					{"SPREAD", "RateSpread"},
					{"RATETYPE", "RateType"},
					{"RATEMATCH", "RateMatchType"},
					{"RATEDATE", "RateDate"},
					{"RATEOPER", "RateOperation"},
					{"RATEOVER", "RateOverridden"},
					{"SCURNDECML", "DecimalPlaces"},
					{"EXTENDED", "ExtendedCost"},
					{"FCEXTENDED", "FuncExtendedAmount"},
					{"ISCOMPLETE", "Completed"},
					{"DTCOMPLETE", "DateCompleted"},
					{"CURRENCYD", "CurrencyDescription"},
					{"RATETYPED", "RateTypeDescription"},
					{"VEND", "Vendors"},
					{"VENDCMPL", "VendorsCompleted"},
					{"LOCKED", "DocumentLocked"},
					{"RATEEXISTS", "ExchangeRateExists"},
					{"HASDETAILS", "HasDetails"},
					{"PROCESSCMD", "Command"}
				};
             }
         }

          #region Properties
          /// <summary>
          /// Contains list of RequisitionVendor Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for RequisitionSequenceKey
               /// </summary>
               public const string RequisitionSequenceKey = "RQNHSEQ";

               /// <summary>
               /// Property for Vendor
               /// </summary>
               public const string Vendor = "VDCODE";

               /// <summary>
               /// Property for Lines
               /// </summary>
               public const string Lines = "LINES";

               /// <summary>
               /// Property for LinesComplete
               /// </summary>
               public const string LinesComplete = "LINESCMPL";

               /// <summary>
               /// Property for StoredInDatabaseTable
               /// </summary>
               public const string StoredInDatabaseTable = "INDBTABLE";

               /// <summary>
               /// Property for VendorExists
               /// </summary>
               public const string VendorExists = "VDEXISTS";

               /// <summary>
               /// Property for Currency
               /// </summary>
               public const string Currency = "CURRENCY";

               /// <summary>
               /// Property for ExchangeRate
               /// </summary>
               public const string ExchangeRate = "RATE";

               /// <summary>
               /// Property for RateSpread
               /// </summary>
               public const string RateSpread = "SPREAD";

               /// <summary>
               /// Property for RateType
               /// </summary>
               public const string RateType = "RATETYPE";

               /// <summary>
               /// Property for RateMatchType
               /// </summary>
               public const string RateMatchType = "RATEMATCH";

               /// <summary>
               /// Property for RateDate
               /// </summary>
               public const string RateDate = "RATEDATE";

               /// <summary>
               /// Property for RateOperation
               /// </summary>
               public const string RateOperation = "RATEOPER";

               /// <summary>
               /// Property for RateOverridden
               /// </summary>
               public const string RateOverridden = "RATEOVER";

               /// <summary>
               /// Property for DecimalPlaces
               /// </summary>
               public const string DecimalPlaces = "SCURNDECML";

               /// <summary>
               /// Property for ExtendedCost
               /// </summary>
               public const string ExtendedCost = "EXTENDED";

               /// <summary>
               /// Property for FuncExtendedAmount
               /// </summary>
               public const string FuncExtendedAmount = "FCEXTENDED";

               /// <summary>
               /// Property for Completed
               /// </summary>
               public const string Completed = "ISCOMPLETE";

               /// <summary>
               /// Property for DateCompleted
               /// </summary>
               public const string DateCompleted = "DTCOMPLETE";

               /// <summary>
               /// Property for CurrencyDescription
               /// </summary>
               public const string CurrencyDescription = "CURRENCYD";

               /// <summary>
               /// Property for RateTypeDescription
               /// </summary>
               public const string RateTypeDescription = "RATETYPED";

               /// <summary>
               /// Property for Vendors
               /// </summary>
               public const string Vendors = "VEND";

               /// <summary>
               /// Property for VendorsCompleted
               /// </summary>
               public const string VendorsCompleted = "VENDCMPL";

               /// <summary>
               /// Property for DocumentLocked
               /// </summary>
               public const string DocumentLocked = "LOCKED";

               /// <summary>
               /// Property for ExchangeRateExists
               /// </summary>
               public const string ExchangeRateExists = "RATEEXISTS";

               /// <summary>
               /// Property for HasDetails
               /// </summary>
               public const string HasDetails = "HASDETAILS";

               /// <summary>
               /// Property for Command
               /// </summary>
               public const string Command = "PROCESSCMD";
          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of RequisitionVendor Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for RequisitionSequenceKey
               /// </summary>
               public const int RequisitionSequenceKey = 1;

               /// <summary>
               /// Property Indexer for Vendor
               /// </summary>
               public const int Vendor = 2;

               /// <summary>
               /// Property Indexer for Lines
               /// </summary>
               public const int Lines = 3;

               /// <summary>
               /// Property Indexer for LinesComplete
               /// </summary>
               public const int LinesComplete = 4;

               /// <summary>
               /// Property Indexer for StoredInDatabaseTable
               /// </summary>
               public const int StoredInDatabaseTable = 5;

               /// <summary>
               /// Property Indexer for VendorExists
               /// </summary>
               public const int VendorExists = 6;

               /// <summary>
               /// Property Indexer for Currency
               /// </summary>
               public const int Currency = 7;

               /// <summary>
               /// Property Indexer for ExchangeRate
               /// </summary>
               public const int ExchangeRate = 8;

               /// <summary>
               /// Property Indexer for RateSpread
               /// </summary>
               public const int RateSpread = 9;

               /// <summary>
               /// Property Indexer for RateType
               /// </summary>
               public const int RateType = 10;

               /// <summary>
               /// Property Indexer for RateMatchType
               /// </summary>
               public const int RateMatchType = 11;

               /// <summary>
               /// Property Indexer for RateDate
               /// </summary>
               public const int RateDate = 12;

               /// <summary>
               /// Property Indexer for RateOperation
               /// </summary>
               public const int RateOperation = 13;

               /// <summary>
               /// Property Indexer for RateOverridden
               /// </summary>
               public const int RateOverridden = 14;

               /// <summary>
               /// Property Indexer for DecimalPlaces
               /// </summary>
               public const int DecimalPlaces = 15;

               /// <summary>
               /// Property Indexer for ExtendedCost
               /// </summary>
               public const int ExtendedCost = 16;

               /// <summary>
               /// Property Indexer for FuncExtendedAmount
               /// </summary>
               public const int FuncExtendedAmount = 17;

               /// <summary>
               /// Property Indexer for Completed
               /// </summary>
               public const int Completed = 18;

               /// <summary>
               /// Property Indexer for DateCompleted
               /// </summary>
               public const int DateCompleted = 19;

               /// <summary>
               /// Property Indexer for CurrencyDescription
               /// </summary>
               public const int CurrencyDescription = 300;

               /// <summary>
               /// Property Indexer for RateTypeDescription
               /// </summary>
               public const int RateTypeDescription = 301;

               /// <summary>
               /// Property Indexer for Vendors
               /// </summary>
               public const int Vendors = 302;

               /// <summary>
               /// Property Indexer for VendorsCompleted
               /// </summary>
               public const int VendorsCompleted = 303;

               /// <summary>
               /// Property Indexer for DocumentLocked
               /// </summary>
               public const int DocumentLocked = 304;

               /// <summary>
               /// Property Indexer for ExchangeRateExists
               /// </summary>
               public const int ExchangeRateExists = 305;

               /// <summary>
               /// Property Indexer for HasDetails
               /// </summary>
               public const int HasDetails = 306;

               /// <summary>
               /// Property Indexer for Command
               /// </summary>
               public const int Command = 307;
          }
          #endregion
     }
}
