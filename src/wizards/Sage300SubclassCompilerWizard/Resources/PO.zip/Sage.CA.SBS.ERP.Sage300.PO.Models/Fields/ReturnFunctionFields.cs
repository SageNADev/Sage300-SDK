// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of ReturnFunction Constants
     /// </summary>
     public partial class ReturnFunction
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0730";

          #region Properties
          /// <summary>
          /// Contains list of ReturnFunction Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for ReturnSequenceKey
               /// </summary>
               public const string ReturnSequenceKey = "RETHSEQ";

               /// <summary>
               /// Property for SequenceToRetrieve
               /// </summary>
               public const string SequenceToRetrieve = "LOADSEQ";

               /// <summary>
               /// Property for ReceiptNumber
               /// </summary>
               public const string ReceiptNumber = "LOADRCPNUM";

               /// <summary>
               /// Property for TemplateCode
               /// </summary>
               public const string TemplateCode = "TEMPLATE";

               /// <summary>
               /// Property for PredecessorTimestamp
               /// </summary>
               public const string PredecessorTimestamp = "PREADTSTMP";

               /// <summary>
               /// Property for Function
               /// </summary>
               public const string Function = "FUNCTION";
          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of ReturnFunction Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for ReturnSequenceKey
               /// </summary>
               public const int ReturnSequenceKey = 1;

               /// <summary>
               /// Property Indexer for SequenceToRetrieve
               /// </summary>
               public const int SequenceToRetrieve = 2;

               /// <summary>
               /// Property Indexer for ReceiptNumber
               /// </summary>
               public const int ReceiptNumber = 3;

               /// <summary>
               /// Property Indexer for TemplateCode
               /// </summary>
               public const int TemplateCode = 4;

               /// <summary>
               /// Property Indexer for PredecessorTimestamp
               /// </summary>
               public const int PredecessorTimestamp = 5;

               /// <summary>
               /// Property Indexer for Function
               /// </summary>
               public const int Function = 6;
          }
          #endregion
     }
}