// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of Vendor Contract Cost Base Unit Constants
     /// </summary>
     public partial class VendorContractCostBaseUnit
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0191";

          #region  Field Properties
          /// <summary>
          /// Contains list of Vendor Contract Cost Base Unit Field Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Item Number
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for Vendor
               /// </summary>
               public const string Vendor = "VDCODE";

               /// <summary>
               /// Property for Unit Of Measure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for Conversion Factor To Stocking
               /// </summary>
               public const string ConversionFactorToStocking = "CONVERSION";

               /// <summary>
               /// Property for Base Amount
               /// </summary>
               public const string BaseAmount = "BAMOUNT";

               /// <summary>
               /// Property for Default Unit Of Measure
               /// </summary>
               public const string DefaultUnitOfMeasure = "DEFAULT";

          }
          #endregion

          #region Index Properties
          /// <summary>
          /// Contains list of Vendor Contract Cost Base Unit Index Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Item Number
               /// </summary>
               public const int ItemNumber = 1;

               /// <summary>
               /// Property Indexer for Vendor
               /// </summary>
               public const int Vendor = 2;

               /// <summary>
               /// Property Indexer for Unit Of Measure
               /// </summary>
               public const int UnitOfMeasure = 3;

               /// <summary>
               /// Property Indexer for Conversion Factor To Stocking
               /// </summary>
               public const int ConversionFactorToStocking = 4;

               /// <summary>
               /// Property Indexer for Base Amount
               /// </summary>
               public const int BaseAmount = 5;

               /// <summary>
               /// Property Indexer for Default Unit Of Measure
               /// </summary>
               public const int DefaultUnitOfMeasure = 11;

          }
          #endregion

     }
}
