// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of Vendor Contract Cost Sale Unit Constants
     /// </summary>
     public partial class VendorContractCostSaleUnit
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0192";

          #region Field Properties
          /// <summary>
          /// Contains list of Vendor Contract Cost Sale Unit Field Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for Item Number
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for Vendor
               /// </summary>
               public const string Vendor = "VDCODE";

               /// <summary>
               /// Property for Unit Of Measure
               /// </summary>
               public const string UnitOfMeasure = "UNIT";

               /// <summary>
               /// Property for Conversion Factor To Stocking
               /// </summary>
               public const string ConversionFactorToStocking = "CONVERSION";

               /// <summary>
               /// Property for Sale Cost Calculated Using
               /// </summary>
               public const string SaleCostCalculatedUsing = "SUSING";

               /// <summary>
               /// Property for Discount Percent
               /// </summary>
               public const string DiscountPercent = "SPERCENT";

               /// <summary>
               /// Property for Discount Amount
               /// </summary>
               public const string DiscountAmount = "SDAMOUNT";

               /// <summary>
               /// Property for Fixed Amount
               /// </summary>
               public const string FixedAmount = "SFAMOUNT";

               /// <summary>
               /// Property for Sale Start Date
               /// </summary>
               public const string SaleStartDate = "SALESTART";

               /// <summary>
               /// Property for Sale End Date
               /// </summary>
               public const string SaleEndDate = "SALEEND";

               /// <summary>
               /// Property for Sale Cost
               /// </summary>
               public const string SaleCost = "DSALECOST";

               /// <summary>
               /// Property for Default Unit Of Measure
               /// </summary>
               public const string DefaultUnitOfMeasure = "DEFAULT";

          }
          #endregion

          #region Index Properties
          /// <summary>
          /// Contains list of Vendor Contract Cost Sale Unit Index Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Item Number
               /// </summary>
               public const int ItemNumber = 1;

               /// <summary>
               /// Property Indexer for Vendor
               /// </summary>
               public const int Vendor = 2;

               /// <summary>
               /// Property Indexer for Unit Of Measure
               /// </summary>
               public const int UnitOfMeasure = 3;

               /// <summary>
               /// Property Indexer for Conversion Factor To Stocking
               /// </summary>
               public const int ConversionFactorToStocking = 4;

               /// <summary>
               /// Property Indexer for Sale Cost Calculated Using
               /// </summary>
               public const int SaleCostCalculatedUsing = 5;

               /// <summary>
               /// Property Indexer for Discount Percent
               /// </summary>
               public const int DiscountPercent = 6;

               /// <summary>
               /// Property Indexer for Discount Amount
               /// </summary>
               public const int DiscountAmount = 7;

               /// <summary>
               /// Property Indexer for Fixed Amount
               /// </summary>
               public const int FixedAmount = 8;

               /// <summary>
               /// Property Indexer for Sale Start Date
               /// </summary>
               public const int SaleStartDate = 9;

               /// <summary>
               /// Property Indexer for Sale End Date
               /// </summary>
               public const int SaleEndDate = 10;

               /// <summary>
               /// Property Indexer for Sale Cost
               /// </summary>
               public const int SaleCost = 16;

               /// <summary>
               /// Property Indexer for Default Unit Of Measure
               /// </summary>
               public const int DefaultUnitOfMeasure = 17;

          }
          #endregion

     }
}
