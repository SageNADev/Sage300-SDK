// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of CreditDebitNoteFunction Constants
     /// </summary>
     public partial class CreditDebitNoteFunction
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0310";

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteFunction Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CreditDebitNoteSequenceKey
               /// </summary>
               public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

               /// <summary>
               /// Property for SequenceToRetrieve
               /// </summary>
               public const string SequenceToRetrieve = "LOADSEQ";

               /// <summary>
               /// Property for Vendor
               /// </summary>
               public const string Vendor = "VDCODE";

               /// <summary>
               /// Property for ReturnNumber
               /// </summary>
               public const string ReturnNumber = "LOADRETNUM";

               /// <summary>
               /// Property for InvoiceNumber
               /// </summary>
               public const string InvoiceNumber = "LOADINVNUM";

               /// <summary>
               /// Property for PredecessorTimestamp
               /// </summary>
               public const string PredecessorTimestamp = "PREADTSTMP";

               /// <summary>
               /// Property for Function
               /// </summary>
               public const string Function = "FUNCTION";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteFunction Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CreditDebitNoteSequenceKey
               /// </summary>
               public const int CreditDebitNoteSequenceKey = 1;

               /// <summary>
               /// Property Indexer for SequenceToRetrieve
               /// </summary>
               public const int SequenceToRetrieve = 2;

               /// <summary>
               /// Property Indexer for Vendor
               /// </summary>
               public const int Vendor = 3;

               /// <summary>
               /// Property Indexer for ReturnNumber
               /// </summary>
               public const int ReturnNumber = 4;

               /// <summary>
               /// Property Indexer for InvoiceNumber
               /// </summary>
               public const int InvoiceNumber = 5;

               /// <summary>
               /// Property Indexer for PredecessorTimestamp
               /// </summary>
               public const int PredecessorTimestamp = 6;

               /// <summary>
               /// Property Indexer for Function
               /// </summary>
               public const int Function = 7;

          }
          #endregion

     }
}
