// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptLine Constants
    /// </summary>
    public partial class ReceiptLine
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0710";
        public const string ImportEntityName = "PO0464";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"RCPLSEQ", "ReceiptLineSequence"},
					{"RCPCSEQ", "ReceiptCommentSequence"},
					{"OEONUMBER", "OrderNumber"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"POSTEDTOIC", "PostedToIC"},
					{"COMPLETION", "CompletionStatus"},
					{"DTCOMPLETE", "DateCompleted"},
					{"PORHSEQ", "PurchaseOrderSequenceKey"},
					{"PORLSEQ", "PurchaseOrderLineSequence"},
					{"POCOMPLETE", "CompletesPO"},
					{"ITEMEXISTS", "ItemExists"},
                    {"CONTRACT", "Contract" },
                    {"PROJECT", "Project" },
                    {"CCATEGORY", "Category" },
                    {"COSTCLASS", "CostClass" },
                    {"ITEMNO", "ItemNumber"},
					{"LOCATION", "Location"},
					{"ITEMDESC", "ItemDescription"},
                    {"ORDERUNIT","UnitofMeasure"},
					{"VENDITEMNO", "VendorItemNumber"},
					{"HASCOMMENT", "Comments"},
                    {"RQRECEIVED", "QuantityReceived"},
					{"RQCANCELED", "QuantityCanceled"},
                    {"RQORDERED", "QuantityOrdered"},
					{"RQPREVRECV", "ReceivedToDate"},
                    {"UNITWEIGHT", "UnitWeight"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"UNITCOST", "UnitCost"},
					{"EXTENDED", "ExtendedCost"},
                    {"TXBASEALLO", "NetOfTax"},
					{"TXINCLUDED", "TaxIncluded"},
					{"TXEXCLUDED", "TaxExcluded"},
					{"TAXAMOUNT", "TotalTax"},
                    {"GLACEXPENS", "ExpenseAccount"},
					{"DTARRIVAL", "ArrivalDate"},
					{"LABELCOUNT", "NumberOfLabels"},
					{"MPRORATED", "ManualProration"},
					{"HASDROPSHI", "DropShip"},
                    {"DROPTYPE","DropShipType" },
					{"STOCKITEM", "StockItem"},
					{"PONUMBER", "PurchaseOrderNumber"},
                    {"TXALLOAMT", "AllocatedTax"},
                    {"MANITEMNO", "ManufacturersItemNumber"},
					{"DISCPCT", "DiscountPercentage"},
					{"DISCOUNT", "DiscountAmount"},
					{"DISCOUNTF", "FuncDiscountAmount"},
					{"NETXTENDED", "NetExtendedCost"},
                    {"VALUES", "OptionalFields"},
                    {"BILLTYPE", "BillingType"},
                    {"BILLRATE", "BillingRate"},
                    {"EXTBILLSR", "ExtendedBillingAmount"},
                    {"BILLCURR", "BillingCurrency"},
                    {"ARITEMNO", "ARItemNumber"},
                    {"ARUNIT", "ARUnitOfMeasure"},
                    {"RTGPERCENT", "RetainagePercentage"},
                    {"RTGDAYS", "RetentionPeriod"},
                    {"RTGAMOUNT", "RetainageAmount"},
                    {"RCPUNIT","ReceiptUnitofMeasure"},
                    {"LINECMPL", "LinesComplete"},
					{"LINE", "Line"},
					{"RQOUTSTAND", "QuantityOutstanding"},
					{"TXRECVAMT", "RecoverableTax"},
					{"TXEXPSAMT", "ExpensedTax"},
					
					{"TFBASEALLO", "FuncNetOfTax"},
					{"RQOUTSTPO", "QuantityOutstanding1"},
					{"RQRETURNED", "QuantityReturned"},
					{"ISCOMPLETE", "Completed"},
					{"EXTRANEOUS", "ExtraneousLineCount"},
					{"TAXLINE", "LinesTaxCalculationSees"},
					{"LINEPRORAT", "NumberOfLinesProrated"},
					{"GLNONSTKCR", "NonStockClearingAccount"},
					{"GLNONSTKCD", "NonStockClearingAccountDesc"},
					{"INVLINES", "InvoiceLines"},
					{"PORLREV", "PORLREV"},
					{"WEIGHTUNIT", "WeightUnitOfMeasure"},
					{"WEIGHTCONV", "WeightConversion"},
					{"SERIALQTY", "SerialQuantity"},
					{"LOTQTY", "LotQuantity"},
					{"SLITEM", "ItemSerializedLotted"},
					{"DETAILNUM", "DetailNumber"},
                    {"BILLCURDEC", "BillingCurrencyDecimal"}
                };
            }
        }

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of ReceiptLine Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "RCPLREV";

            /// <summary>
            /// Property for ReceiptLineSequence
            /// </summary>
            public const string ReceiptLineSequence = "RCPLSEQ";

            /// <summary>
            /// Property for ReceiptCommentSequence
            /// </summary>
            public const string ReceiptCommentSequence = "RCPCSEQ";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "OEONUMBER";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for PostedToIC
            /// </summary>
            public const string PostedToIC = "POSTEDTOIC";

            /// <summary>
            /// Property for CompletionStatus
            /// </summary>
            public const string CompletionStatus = "COMPLETION";

            /// <summary>
            /// Property for DateCompleted
            /// </summary>
            public const string DateCompleted = "DTCOMPLETE";

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for PurchaseOrderLineSequence
            /// </summary>
            public const string PurchaseOrderLineSequence = "PORLSEQ";

            /// <summary>
            /// Property for CompletesPO
            /// </summary>
            public const string CompletesPO = "POCOMPLETE";

            /// <summary>
            /// Property for ItemExists
            /// </summary>
            public const string ItemExists = "ITEMEXISTS";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for VendorItemNumber
            /// </summary>
            public const string VendorItemNumber = "VENDITEMNO";

            /// <summary>
            /// Property for Comments
            /// </summary>
            public const string Comments = "HASCOMMENT";

            /// <summary>
            /// Property for UnitofMeasure
            /// </summary>
            public const string UnitofMeasure = "ORDERUNIT";

            /// <summary>
            /// Property for OrderUnitConversion
            /// </summary>
            public const string OrderUnitConversion = "ORDERCONV";

            /// <summary>
            /// Property for OrderUnitDecimals
            /// </summary>
            public const string OrderUnitDecimals = "ORDERDECML";

            /// <summary>
            /// Property for ReceiptUnitofMeasure
            /// </summary>
            public const string ReceiptUnitofMeasure = "RCPUNIT";

            /// <summary>
            /// Property for ReceivingConversionFactor
            /// </summary>
            public const string ReceivingConversionFactor = "RCPCONV";

            /// <summary>
            /// Property for ReceivingUnitDecimals
            /// </summary>
            public const string ReceivingUnitDecimals = "RCPDECML";

            /// <summary>
            /// Property for StockUnitDecimals
            /// </summary>
            public const string StockUnitDecimals = "STOCKDECML";

            /// <summary>
            /// Property for OrderedQuantityOrdered
            /// </summary>
            public const string OrderedQuantityOrdered = "OQORDERED";

            /// <summary>
            /// Property for OrderedPreviouslyReceived
            /// </summary>
            public const string OrderedPreviouslyReceived = "OQPREVRECV";

            /// <summary>
            /// Property for OrderedOutstandingonPO
            /// </summary>
            public const string OrderedOutstandingonPO = "OQOUTSTPO";

            /// <summary>
            /// Property for QuantityReceived
            /// </summary>
            public const string QuantityReceived = "RQRECEIVED";

            /// <summary>
            /// Property for QuantityCanceled
            /// </summary>
            public const string QuantityCanceled = "RQCANCELED";

            /// <summary>
            /// Property for QuantityOutstanding
            /// </summary>
            public const string QuantityOutstanding = "RQOUTSTAND";

            /// <summary>
            /// Property for StockingQuantityOrdered
            /// </summary>
            public const string StockingQuantityOrdered = "SQORDERED";

            /// <summary>
            /// Property for StockingPreviouslyReceived
            /// </summary>
            public const string StockingPreviouslyReceived = "SQPREVRECV";

            /// <summary>
            /// Property for StockingOutstandingonPO
            /// </summary>
            public const string StockingOutstandingonPO = "SQOUTSTPO";

            /// <summary>
            /// Property for QuantityOrdered
            /// </summary>
            public const string QuantityOrdered = "RQORDERED";

            /// <summary>
            /// Property for ReceivedToDate
            /// </summary>
            public const string ReceivedToDate = "RQPREVRECV";

            /// <summary>
            /// Property for QuantityOutstanding1
            /// </summary>
            public const string QuantityOutstanding1 = "RQOUTSTPO";

            /// <summary>
            /// Property for ReceivingQtyReceivedExtra
            /// </summary>
            public const string ReceivingQtyReceivedExtra = "RQRCPEXTRA";

            /// <summary>
            /// Property for StockingQuantityReceived
            /// </summary>
            public const string StockingQuantityReceived = "SQRECEIVED";

            /// <summary>
            /// Property for StockingQuantityCanceled
            /// </summary>
            public const string StockingQuantityCanceled = "SQCANCELED";

            /// <summary>
            /// Property for StockingQuantityOutstanding
            /// </summary>
            public const string StockingQuantityOutstanding = "SQOUTSTAND";

            /// <summary>
            /// Property for StockingQuantityReceivedExtra
            /// </summary>
            public const string StockingQuantityReceivedExtra = "SQRCPEXTRA";

            /// <summary>
            /// Property for OrderedQuantityReceived
            /// </summary>
            public const string OrderedQuantityReceived = "OQRECEIVED";

            /// <summary>
            /// Property for OrderedQuantityCanceled
            /// </summary>
            public const string OrderedQuantityCanceled = "OQCANCELED";

            /// <summary>
            /// Property for OrderedQuantityOutstanding
            /// </summary>
            public const string OrderedQuantityOutstanding = "OQOUTSTAND";

            /// <summary>
            /// Property for ReceivedExtra
            /// </summary>
            public const string ReceivedExtra = "OQRCPEXTRA";

            /// <summary>
            /// Property for QuantityReturned
            /// </summary>
            public const string QuantityReturned = "RQRETURNED";

            /// <summary>
            /// Property for StockingQuantityReturned
            /// </summary>
            public const string StockingQuantityReturned = "SQRETURNED";

            /// <summary>
            /// Property for OrderedQuantityReturned
            /// </summary>
            public const string OrderedQuantityReturned = "OQRETURNED";

            /// <summary>
            /// Property for QuantityStocked
            /// </summary>
            public const string QuantityStocked = "RQSTOCKED";

            /// <summary>
            /// Property for StockingQuantityStocked
            /// </summary>
            public const string StockingQuantityStocked = "SQSTOCKED";

            /// <summary>
            /// Property for OrderedQuantityStocked
            /// </summary>
            public const string OrderedQuantityStocked = "OQSTOCKED";

            /// <summary>
            /// Property for QuantityAdjustedbyInvoice
            /// </summary>
            public const string QuantityAdjustedbyInvoice = "RQINADJUST";

            /// <summary>
            /// Property for StockingQtyAdjbyInvoice
            /// </summary>
            public const string StockingQtyAdjbyInvoice = "SQINADJUST";

            /// <summary>
            /// Property for OrderedQuantityAdjbyInvoice
            /// </summary>
            public const string OrderedQuantityAdjbyInvoice = "OQINADJUST";

            /// <summary>
            /// Property for QuantityFilledonPO
            /// </summary>
            public const string QuantityFilledonPO = "RQPOFILLED";

            /// <summary>
            /// Property for StockingQuantityFilledonPO
            /// </summary>
            public const string StockingQuantityFilledonPO = "SQPOFILLED";

            /// <summary>
            /// Property for OrderedQuantityFilledonPO
            /// </summary>
            public const string OrderedQuantityFilledonPO = "OQPOFILLED";

            /// <summary>
            /// Property for QuantitySettled
            /// </summary>
            public const string QuantitySettled = "RQSETTLED";

            /// <summary>
            /// Property for StockingQuantitySettled
            /// </summary>
            public const string StockingQuantitySettled = "SQSETTLED";

            /// <summary>
            /// Property for OrderedQuantitySettled
            /// </summary>
            public const string OrderedQuantitySettled = "OQSETTLED";

            /// <summary>
            /// Property for QuantityUnstocked
            /// </summary>
            public const string QuantityUnstocked = "RQUSTOCKED";

            /// <summary>
            /// Property for StockingQuantityUnstocked
            /// </summary>
            public const string StockingQuantityUnstocked = "SQUSTOCKED";

            /// <summary>
            /// Property for OrderedQuantityUnstocked
            /// </summary>
            public const string OrderedQuantityUnstocked = "OQUSTOCKED";

            /// <summary>
            /// Property for UnitWeight
            /// </summary>
            public const string UnitWeight = "UNITWEIGHT";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTENDED";

            /// <summary>
            /// Property for TaxBase1
            /// </summary>
            public const string TaxBase1 = "TAXBASE1";

            /// <summary>
            /// Property for TaxBase2
            /// </summary>
            public const string TaxBase2 = "TAXBASE2";

            /// <summary>
            /// Property for TaxBase3
            /// </summary>
            public const string TaxBase3 = "TAXBASE3";

            /// <summary>
            /// Property for TaxBase4
            /// </summary>
            public const string TaxBase4 = "TAXBASE4";

            /// <summary>
            /// Property for TaxBase5
            /// </summary>
            public const string TaxBase5 = "TAXBASE5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxRate1
            /// </summary>
            public const string TaxRate1 = "TAXRATE1";

            /// <summary>
            /// Property for TaxRate2
            /// </summary>
            public const string TaxRate2 = "TAXRATE2";

            /// <summary>
            /// Property for TaxRate3
            /// </summary>
            public const string TaxRate3 = "TAXRATE3";

            /// <summary>
            /// Property for TaxRate4
            /// </summary>
            public const string TaxRate4 = "TAXRATE4";

            /// <summary>
            /// Property for TaxRate5
            /// </summary>
            public const string TaxRate5 = "TAXRATE5";

            /// <summary>
            /// Property for TaxIncludable1
            /// </summary>
            public const string TaxIncludable1 = "TAXINCLUD1";

            /// <summary>
            /// Property for TaxIncludable2
            /// </summary>
            public const string TaxIncludable2 = "TAXINCLUD2";

            /// <summary>
            /// Property for TaxIncludable3
            /// </summary>
            public const string TaxIncludable3 = "TAXINCLUD3";

            /// <summary>
            /// Property for TaxIncludable4
            /// </summary>
            public const string TaxIncludable4 = "TAXINCLUD4";

            /// <summary>
            /// Property for TaxIncludable5
            /// </summary>
            public const string TaxIncludable5 = "TAXINCLUD5";

            /// <summary>
            /// Property for TaxAmount1
            /// </summary>
            public const string TaxAmount1 = "TAXAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2
            /// </summary>
            public const string TaxAmount2 = "TAXAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3
            /// </summary>
            public const string TaxAmount3 = "TAXAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4
            /// </summary>
            public const string TaxAmount4 = "TAXAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5
            /// </summary>
            public const string TaxAmount5 = "TAXAMOUNT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1
            /// </summary>
            public const string TaxRecoverableAmount1 = "TXRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2
            /// </summary>
            public const string TaxRecoverableAmount2 = "TXRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3
            /// </summary>
            public const string TaxRecoverableAmount3 = "TXRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4
            /// </summary>
            public const string TaxRecoverableAmount4 = "TXRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5
            /// </summary>
            public const string TaxRecoverableAmount5 = "TXRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1
            /// </summary>
            public const string TaxExpenseAmount1 = "TXEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2
            /// </summary>
            public const string TaxExpenseAmount2 = "TXEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3
            /// </summary>
            public const string TaxExpenseAmount3 = "TXEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4
            /// </summary>
            public const string TaxExpenseAmount4 = "TXEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5
            /// </summary>
            public const string TaxExpenseAmount5 = "TXEXPSAMT5";

            /// <summary>
            /// Property for TaxAllocatedAmount1
            /// </summary>
            public const string TaxAllocatedAmount1 = "TXALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2
            /// </summary>
            public const string TaxAllocatedAmount2 = "TXALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3
            /// </summary>
            public const string TaxAllocatedAmount3 = "TXALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4
            /// </summary>
            public const string TaxAllocatedAmount4 = "TXALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5
            /// </summary>
            public const string TaxAllocatedAmount5 = "TXALLOAMT5";

            /// <summary>
            /// Property for NetOfTax
            /// </summary>
            public const string NetOfTax = "TXBASEALLO";

            /// <summary>
            /// Property for TaxIncluded
            /// </summary>
            public const string TaxIncluded = "TXINCLUDED";

            /// <summary>
            /// Property for TaxExcluded
            /// </summary>
            public const string TaxExcluded = "TXEXCLUDED";

            /// <summary>
            /// Property for TotalTax
            /// </summary>
            public const string TotalTax = "TAXAMOUNT";

            /// <summary>
            /// Property for RecoverableTax
            /// </summary>
            public const string RecoverableTax = "TXRECVAMT";

            /// <summary>
            /// Property for ExpensedTax
            /// </summary>
            public const string ExpensedTax = "TXEXPSAMT";

            /// <summary>
            /// Property for AllocatedTax
            /// </summary>
            public const string AllocatedTax = "TXALLOAMT";

            /// <summary>
            /// Property for FuncNetOfTax
            /// </summary>
            public const string FuncNetOfTax = "TFBASEALLO";

            /// <summary>
            /// Property for FuncTaxIncludedAmount1
            /// </summary>
            public const string FuncTaxIncludedAmount1 = "TFINCLUDE1";

            /// <summary>
            /// Property for FuncTaxIncludedAmount2
            /// </summary>
            public const string FuncTaxIncludedAmount2 = "TFINCLUDE2";

            /// <summary>
            /// Property for FuncTaxIncludedAmount3
            /// </summary>
            public const string FuncTaxIncludedAmount3 = "TFINCLUDE3";

            /// <summary>
            /// Property for FuncTaxIncludedAmount4
            /// </summary>
            public const string FuncTaxIncludedAmount4 = "TFINCLUDE4";

            /// <summary>
            /// Property for FuncTaxIncludedAmount5
            /// </summary>
            public const string FuncTaxIncludedAmount5 = "TFINCLUDE5";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount1
            /// </summary>
            public const string FuncTaxAllocatedAmount1 = "TFALLOAMT1";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount2
            /// </summary>
            public const string FuncTaxAllocatedAmount2 = "TFALLOAMT2";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount3
            /// </summary>
            public const string FuncTaxAllocatedAmount3 = "TFALLOAMT3";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount4
            /// </summary>
            public const string FuncTaxAllocatedAmount4 = "TFALLOAMT4";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount5
            /// </summary>
            public const string FuncTaxAllocatedAmount5 = "TFALLOAMT5";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount1
            /// </summary>
            public const string FuncTaxRecoverableAmount1 = "TFRECVAMT1";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount2
            /// </summary>
            public const string FuncTaxRecoverableAmount2 = "TFRECVAMT2";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount3
            /// </summary>
            public const string FuncTaxRecoverableAmount3 = "TFRECVAMT3";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount4
            /// </summary>
            public const string FuncTaxRecoverableAmount4 = "TFRECVAMT4";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount5
            /// </summary>
            public const string FuncTaxRecoverableAmount5 = "TFRECVAMT5";

            /// <summary>
            /// Property for FuncTaxExpenseAmount1
            /// </summary>
            public const string FuncTaxExpenseAmount1 = "TFEXPSAMT1";

            /// <summary>
            /// Property for FuncTaxExpenseAmount2
            /// </summary>
            public const string FuncTaxExpenseAmount2 = "TFEXPSAMT2";

            /// <summary>
            /// Property for FuncTaxExpenseAmount3
            /// </summary>
            public const string FuncTaxExpenseAmount3 = "TFEXPSAMT3";

            /// <summary>
            /// Property for FuncTaxExpenseAmount4
            /// </summary>
            public const string FuncTaxExpenseAmount4 = "TFEXPSAMT4";

            /// <summary>
            /// Property for FuncTaxExpenseAmount5
            /// </summary>
            public const string FuncTaxExpenseAmount5 = "TFEXPSAMT5";

            /// <summary>
            /// Property for ExpenseAccount
            /// </summary>
            public const string ExpenseAccount = "GLACEXPENS";

            /// <summary>
            /// Property for ArrivalDate
            /// </summary>
            public const string ArrivalDate = "DTARRIVAL";

            /// <summary>
            /// Property for NumberOfLabels
            /// </summary>
            public const string NumberOfLabels = "LABELCOUNT";

            /// <summary>
            /// Property for ManualProration
            /// </summary>
            public const string ManualProration = "MPRORATED";

            /// <summary>
            /// Property for DropShip
            /// </summary>
            public const string DropShip = "HASDROPSHI";

            /// <summary>
            /// Property for DropShipType
            /// </summary>
            public const string DropShipType = "DROPTYPE";

            /// <summary>
            /// Property for DropShipCustomer
            /// </summary>
            public const string DropShipCustomer = "IDCUST";

            /// <summary>
            /// Property for CustomerShipToAddress
            /// </summary>
            public const string CustomerShipToAddress = "IDCUSTSHPT";

            /// <summary>
            /// Property for DropShipLocation
            /// </summary>
            public const string DropShipLocation = "DLOCATION";

            /// <summary>
            /// Property for DropShipDescription
            /// </summary>
            public const string DropShipDescription = "DESC";

            /// <summary>
            /// Property for DropShipAddress1
            /// </summary>
            public const string DropShipAddress1 = "ADDRESS1";

            /// <summary>
            /// Property for DropShipAddress2
            /// </summary>
            public const string DropShipAddress2 = "ADDRESS2";

            /// <summary>
            /// Property for DropShipAddress3
            /// </summary>
            public const string DropShipAddress3 = "ADDRESS3";

            /// <summary>
            /// Property for DropShipAddress4
            /// </summary>
            public const string DropShipAddress4 = "ADDRESS4";

            /// <summary>
            /// Property for DropShipCity
            /// </summary>
            public const string DropShipCity = "CITY";

            /// <summary>
            /// Property for DropShipStateProvince
            /// </summary>
            public const string DropShipStateProvince = "STATE";

            /// <summary>
            /// Property for DropShipZipPostalCode
            /// </summary>
            public const string DropShipZipPostalCode = "ZIP";

            /// <summary>
            /// Property for DropShipCountry
            /// </summary>
            public const string DropShipCountry = "COUNTRY";

            /// <summary>
            /// Property for DropShipPhoneNumber
            /// </summary>
            public const string DropShipPhoneNumber = "PHONE";

            /// <summary>
            /// Property for DropShipFaxNumber
            /// </summary>
            public const string DropShipFaxNumber = "FAX";

            /// <summary>
            /// Property for DropShipContact
            /// </summary>
            public const string DropShipContact = "CONTACT";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for TaxClass1Description
            /// </summary>
            public const string TaxClass1Description = "TAXCLASS1D";

            /// <summary>
            /// Property for TaxClass2Description
            /// </summary>
            public const string TaxClass2Description = "TAXCLASS2D";

            /// <summary>
            /// Property for TaxClass3Description
            /// </summary>
            public const string TaxClass3Description = "TAXCLASS3D";

            /// <summary>
            /// Property for TaxClass4Description
            /// </summary>
            public const string TaxClass4Description = "TAXCLASS4D";

            /// <summary>
            /// Property for TaxClass5Description
            /// </summary>
            public const string TaxClass5Description = "TAXCLASS5D";

            /// <summary>
            /// Property for ExpenseAccountDescription
            /// </summary>
            public const string ExpenseAccountDescription = "GLACEXPNSD";

            /// <summary>
            /// Property for IncludedTaxAmount1
            /// </summary>
            public const string IncludedTaxAmount1 = "TXINCLUDE1";

            /// <summary>
            /// Property for IncludedTaxAmount2
            /// </summary>
            public const string IncludedTaxAmount2 = "TXINCLUDE2";

            /// <summary>
            /// Property for IncludedTaxAmount3
            /// </summary>
            public const string IncludedTaxAmount3 = "TXINCLUDE3";

            /// <summary>
            /// Property for IncludedTaxAmount4
            /// </summary>
            public const string IncludedTaxAmount4 = "TXINCLUDE4";

            /// <summary>
            /// Property for IncludedTaxAmount5
            /// </summary>
            public const string IncludedTaxAmount5 = "TXINCLUDE5";

            /// <summary>
            /// Property for ExcludedTaxAmount1
            /// </summary>
            public const string ExcludedTaxAmount1 = "TXEXCLUDE1";

            /// <summary>
            /// Property for ExcludedTaxAmount2
            /// </summary>
            public const string ExcludedTaxAmount2 = "TXEXCLUDE2";

            /// <summary>
            /// Property for ExcludedTaxAmount3
            /// </summary>
            public const string ExcludedTaxAmount3 = "TXEXCLUDE3";

            /// <summary>
            /// Property for ExcludedTaxAmount4
            /// </summary>
            public const string ExcludedTaxAmount4 = "TXEXCLUDE4";

            /// <summary>
            /// Property for ExcludedTaxAmount5
            /// </summary>
            public const string ExcludedTaxAmount5 = "TXEXCLUDE5";

            /// <summary>
            /// Property for Completed
            /// </summary>
            public const string Completed = "ISCOMPLETE";

            /// <summary>
            /// Property for ExtraneousLineCount
            /// </summary>
            public const string ExtraneousLineCount = "EXTRANEOUS";

            /// <summary>
            /// Property for LinesTaxCalculationSees
            /// </summary>
            public const string LinesTaxCalculationSees = "TAXLINE";

            /// <summary>
            /// Property for NumberOfLinesProrated
            /// </summary>
            public const string NumberOfLinesProrated = "LINEPRORAT";

            /// <summary>
            /// Property for LinesComplete
            /// </summary>
            public const string LinesComplete = "LINECMPL";

            /// <summary>
            /// Property for Line
            /// </summary>
            public const string Line = "LINE";

            /// <summary>
            /// Property for ExtendedStdCostInSrcCurr
            /// </summary>
            public const string ExtendedStdCostInSrcCurr = "EXSTDCOST";

            /// <summary>
            /// Property for ExtendedMRCostInSrcCurr
            /// </summary>
            public const string ExtendedMRCostInSrcCurr = "EXMRCOST";

            /// <summary>
            /// Property for ExtendedCost1InSrcCurr
            /// </summary>
            public const string ExtendedCost1InSrcCurr = "EXALT1COST";

            /// <summary>
            /// Property for ExtendedCost2InSrcCurr
            /// </summary>
            public const string ExtendedCost2InSrcCurr = "EXALT2COST";

            /// <summary>
            /// Property for DropShipEmail
            /// </summary>
            public const string DropShipEmail = "EMAIL";

            /// <summary>
            /// Property for DropShipContactPhone
            /// </summary>
            public const string DropShipContactPhone = "PHONEC";

            /// <summary>
            /// Property for DropShipContactFax
            /// </summary>
            public const string DropShipContactFax = "FAXC";

            /// <summary>
            /// Property for DropShipContactEmail
            /// </summary>
            public const string DropShipContactEmail = "EMAILC";

            /// <summary>
            /// Property for NonStockClearingAccount
            /// </summary>
            public const string NonStockClearingAccount = "GLNONSTKCR";

            /// <summary>
            /// Property for NonStockClearingAccountDesc
            /// </summary>
            public const string NonStockClearingAccountDesc = "GLNONSTKCD";

            /// <summary>
            /// Property for InterprocessCommID
            /// </summary>
            public const string InterprocessCommID = "IPCID";

            /// <summary>
            /// Property for ForcePopupSN
            /// </summary>
            public const string ForcePopupSN = "FORCEPOPSN";

            /// <summary>
            /// Property for PopupSN
            /// </summary>
            public const string PopupSN = "POPUPSN";

            /// <summary>
            /// Property for CloseSN
            /// </summary>
            public const string CloseSN = "CLOSESN";

            /// <summary>
            /// Property for LTSetID
            /// </summary>
            public const string LTSetID = "LTSETID";

            /// <summary>
            /// Property for ForcePopupLT
            /// </summary>
            public const string ForcePopupLT = "FORCEPOPLT";

            /// <summary>
            /// Property for PopupLT
            /// </summary>
            public const string PopupLT = "POPUPLT";

            /// <summary>
            /// Property for CloseLT
            /// </summary>
            public const string CloseLT = "CLOSELT";

            /// <summary>
            /// Property for ManufacturersItemNumber
            /// </summary>
            public const string ManufacturersItemNumber = "MANITEMNO";

            /// <summary>
            /// Property for MapManufacturersItemNumber
            /// </summary>
            public const string MapManufacturersItemNumber = "MAPMANITEM";

            /// <summary>
            /// Property for DiscountPercentage
            /// </summary>
            public const string DiscountPercentage = "DISCPCT";

            /// <summary>
            /// Property for DiscountAmount
            /// </summary>
            public const string DiscountAmount = "DISCOUNT";

            /// <summary>
            /// Property for FuncDiscountAmount
            /// </summary>
            public const string FuncDiscountAmount = "DISCOUNTF";

            /// <summary>
            /// Property for NetExtendedCost
            /// </summary>
            public const string NetExtendedCost = "NETXTENDED";

            /// <summary>
            /// Property for PartInvPvQtyInvoiced
            /// </summary>
            public const string PartInvPvQtyInvcd = "XIRQRECEVD";

            /// <summary>
            /// Property for PartInvPvExtWgtInvcd
            /// </summary>
            public const string PartInvPvExtWgtInvcd = "XIEXTWGHT";

            /// <summary>
            /// Property for PartInvPvNetCostInvoiced
            /// </summary>
            public const string PartInvPvNetCostInvoiced = "XINETXTEND";

            /// <summary>
            /// Property for InvoiceLines
            /// </summary>
            public const string InvoiceLines = "INVLINES";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for LineNumber1
            /// </summary>
            public const string LineNumber1 = "PORLREV";

            /// <summary>
            /// Property for Command
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CCATEGORY";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCURR";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEMNO";

            /// <summary>
            /// Property for ARUnitOfMeasure
            /// </summary>
            public const string ARUnitOfMeasure = "ARUNIT";

            /// <summary>
            /// Property for RetainagePercentage
            /// </summary>
            public const string RetainagePercentage = "RTGPERCENT";

            /// <summary>
            /// Property for RetentionPeriod
            /// </summary>
            public const string RetentionPeriod = "RTGDAYS";

            /// <summary>
            /// Property for RetainageAmount
            /// </summary>
            public const string RetainageAmount = "RTGAMOUNT";

            /// <summary>
            /// Property for RetainageAmountOverridden
            /// </summary>
            public const string RetainageAmountOverridden = "RTGAMTOVER";

            /// <summary>
            /// Property for BillableLine
            /// </summary>
            public const string BillableLine = "BILLLINE";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for UnformattedContractCode
            /// </summary>
            public const string UnformattedContractCode = "UFMTCONTNO";

            /// <summary>
            /// Property for TaxReportingAmount1
            /// </summary>
            public const string TaxReportingAmount1 = "TARAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2
            /// </summary>
            public const string TaxReportingAmount2 = "TARAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3
            /// </summary>
            public const string TaxReportingAmount3 = "TARAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4
            /// </summary>
            public const string TaxReportingAmount4 = "TARAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5
            /// </summary>
            public const string TaxReportingAmount5 = "TARAMOUNT5";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount1
            /// </summary>
            public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount2
            /// </summary>
            public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount3
            /// </summary>
            public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount4
            /// </summary>
            public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount5
            /// </summary>
            public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt1
            /// </summary>
            public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt2
            /// </summary>
            public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt3
            /// </summary>
            public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt4
            /// </summary>
            public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt5
            /// </summary>
            public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

            /// <summary>
            /// Property for TaxReportingExpenseAmount1
            /// </summary>
            public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

            /// <summary>
            /// Property for TaxReportingExpenseAmount2
            /// </summary>
            public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

            /// <summary>
            /// Property for TaxReportingExpenseAmount3
            /// </summary>
            public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

            /// <summary>
            /// Property for TaxReportingExpenseAmount4
            /// </summary>
            public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

            /// <summary>
            /// Property for TaxReportingExpenseAmount5
            /// </summary>
            public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

            /// <summary>
            /// Property for TaxReportingIncludedAmount1
            /// </summary>
            public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncludedAmount2
            /// </summary>
            public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncludedAmount3
            /// </summary>
            public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncludedAmount4
            /// </summary>
            public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncludedAmount5
            /// </summary>
            public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcludedAmount1
            /// </summary>
            public const string TaxReportingExcludedAmount1 = "TREXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcludedAmount2
            /// </summary>
            public const string TaxReportingExcludedAmount2 = "TREXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcludedAmount3
            /// </summary>
            public const string TaxReportingExcludedAmount3 = "TREXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcludedAmount4
            /// </summary>
            public const string TaxReportingExcludedAmount4 = "TREXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcludedAmount5
            /// </summary>
            public const string TaxReportingExcludedAmount5 = "TREXCLUDE5";

            /// <summary>
            /// Property for TaxReportingTotalAmount
            /// </summary>
            public const string TaxReportingTotalAmount = "TARAMOUNT";

            /// <summary>
            /// Property for TaxReportingIncludedAmount
            /// </summary>
            public const string TaxReportingIncludedAmount = "TRINCLUDED";

            /// <summary>
            /// Property for TaxReportingExcludedAmount
            /// </summary>
            public const string TaxReportingExcludedAmount = "TREXCLUDED";

            /// <summary>
            /// Property for TaxReportingRecoverableAmount
            /// </summary>
            public const string TaxReportingRecoverableAmount = "TRRECVAMT";

            /// <summary>
            /// Property for TaxReportingExpensedAmount
            /// </summary>
            public const string TaxReportingExpensedAmount = "TREXPSAMT";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount
            /// </summary>
            public const string TaxReportingAllocatedAmount = "TRALLOAMT";

            /// <summary>
            /// Property for RetainageTaxBase1
            /// </summary>
            public const string RetainageTaxBase1 = "RAXBASE1";

            /// <summary>
            /// Property for RetainageTaxBase2
            /// </summary>
            public const string RetainageTaxBase2 = "RAXBASE2";

            /// <summary>
            /// Property for RetainageTaxBase3
            /// </summary>
            public const string RetainageTaxBase3 = "RAXBASE3";

            /// <summary>
            /// Property for RetainageTaxBase4
            /// </summary>
            public const string RetainageTaxBase4 = "RAXBASE4";

            /// <summary>
            /// Property for RetainageTaxBase5
            /// </summary>
            public const string RetainageTaxBase5 = "RAXBASE5";

            /// <summary>
            /// Property for RetainageTaxAmount1
            /// </summary>
            public const string RetainageTaxAmount1 = "RAXAMOUNT1";

            /// <summary>
            /// Property for RetainageTaxAmount2
            /// </summary>
            public const string RetainageTaxAmount2 = "RAXAMOUNT2";

            /// <summary>
            /// Property for RetainageTaxAmount3
            /// </summary>
            public const string RetainageTaxAmount3 = "RAXAMOUNT3";

            /// <summary>
            /// Property for RetainageTaxAmount4
            /// </summary>
            public const string RetainageTaxAmount4 = "RAXAMOUNT4";

            /// <summary>
            /// Property for RetainageTaxAmount5
            /// </summary>
            public const string RetainageTaxAmount5 = "RAXAMOUNT5";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt1
            /// </summary>
            public const string RetainageTaxRecoverableAmt1 = "RXRECVAMT1";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt2
            /// </summary>
            public const string RetainageTaxRecoverableAmt2 = "RXRECVAMT2";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt3
            /// </summary>
            public const string RetainageTaxRecoverableAmt3 = "RXRECVAMT3";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt4
            /// </summary>
            public const string RetainageTaxRecoverableAmt4 = "RXRECVAMT4";

            /// <summary>
            /// Property for RetainageTaxRecoverableAmt5
            /// </summary>
            public const string RetainageTaxRecoverableAmt5 = "RXRECVAMT5";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount1
            /// </summary>
            public const string RetainageTaxExpenseAmount1 = "RXEXPSAMT1";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount2
            /// </summary>
            public const string RetainageTaxExpenseAmount2 = "RXEXPSAMT2";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount3
            /// </summary>
            public const string RetainageTaxExpenseAmount3 = "RXEXPSAMT3";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount4
            /// </summary>
            public const string RetainageTaxExpenseAmount4 = "RXEXPSAMT4";

            /// <summary>
            /// Property for RetainageTaxExpenseAmount5
            /// </summary>
            public const string RetainageTaxExpenseAmount5 = "RXEXPSAMT5";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount1
            /// </summary>
            public const string RetainageTaxAllocatedAmount1 = "RXALLOAMT1";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount2
            /// </summary>
            public const string RetainageTaxAllocatedAmount2 = "RXALLOAMT2";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount3
            /// </summary>
            public const string RetainageTaxAllocatedAmount3 = "RXALLOAMT3";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount4
            /// </summary>
            public const string RetainageTaxAllocatedAmount4 = "RXALLOAMT4";

            /// <summary>
            /// Property for RetainageTaxAllocatedAmount5
            /// </summary>
            public const string RetainageTaxAllocatedAmount5 = "RXALLOAMT5";

            /// <summary>
            /// Property for RetainageTaxTotalAmount
            /// </summary>
            public const string RetainageTaxTotalAmount = "RAXAMOUNT";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt1 = "TXRXAMT1";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt2 = "TXRXAMT2";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt3 = "TXRXAMT3";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt4 = "TXRXAMT4";

            /// <summary>
            /// Property for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const string TaxAmountPlusRtgTaxAmt5 = "TXRXAMT5";

            /// <summary>
            /// Property for UnitCostIsManual
            /// </summary>
            public const string UnitCostIsManual = "UCISMANUAL";

            /// <summary>
            /// Property for WeightUnitOfMeasure
            /// </summary>
            public const string WeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for WeightConversion
            /// </summary>
            public const string WeightConversion = "WEIGHTCONV";

            /// <summary>
            /// Property for DefaultUnitWeight
            /// </summary>
            public const string DefaultUnitWeight = "DEFUWEIGHT";

            /// <summary>
            /// Property for DefaultExtendedWeight
            /// </summary>
            public const string DefaultExtendedWeight = "DEFEXTWGHT";

            /// <summary>
            /// Property for PartInvPvDefExtWInv
            /// </summary>
            public const string PartInvPvDefExtWInv = "XIDEFEXTWT";

            /// <summary>
            /// Property for BillingRateConversionFactor
            /// </summary>
            public const string BillingRateConversionFactor = "BILLRATECV";

            /// <summary>
            /// Property for UnitBillingAmount
            /// </summary>
            public const string UnitBillingAmount = "UNITBILLSR";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "EXTBILLSR";

            /// <summary>
            /// Property for FixedAsset
            /// </summary>
            public const string FixedAsset = "FASDETAIL";

            /// <summary>
            /// Property for AssetCreated
            /// </summary>
            public const string AssetCreated = "FASCREATED";

            /// <summary>
            /// Property for SageFixedAssetsDatabase
            /// </summary>
            public const string SageFADatabase = "FASDB";

            /// <summary>
            /// Property for SageFixedAssetsCompanyOrg
            /// </summary>
            public const string SageFACompanyOrg = "FASCMP";

            /// <summary>
            /// Property for SageFixedAssetsTemplate
            /// </summary>
            public const string SageFATemplate = "FASTMPL";

            /// <summary>
            /// Property for SageFixedAssetsAssetDescription
            /// </summary>
            public const string SageFAAssetDesc = "TEXTDESC";

            /// <summary>
            /// Property for SeparateAssets
            /// </summary>
            public const string SeparateAssets = "SEPQTY";

            /// <summary>
            /// Property for SageFixedAssetsQuantity
            /// </summary>
            public const string SageFAQuantity = "FASQTY";

            /// <summary>
            /// Property for SageFixedAssetsUnitOfMeasure
            /// </summary>
            public const string SageFAUnitOfMeasure = "UOM";

            /// <summary>
            /// Property for SageFixedAssetsAssetValue
            /// </summary>
            public const string SageFAAssetValue = "AMTSC";

            /// <summary>
            /// Property for SerialQuantity
            /// </summary>
            public const string SerialQuantity = "SERIALQTY";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "LOTQTY";

            /// <summary>
            /// Property for ItemSerializedLotted
            /// </summary>
            public const string ItemSerializedLotted = "SLITEM";

            /// <summary>
            /// Property for SerialLotQuantityToProcess
            /// </summary>
            public const string SerialLotQuantityToProcess = "XGENALCQTY";

            /// <summary>
            /// Property for NumberOfLotsToGenerate
            /// </summary>
            public const string NumberOfLotsToGenerate = "XLOTMAKQTY";

            /// <summary>
            /// Property for QuantityperLot
            /// </summary>
            public const string QuantityperLot = "XPERLOTQTY";

            /// <summary>
            /// Property for AllocateFromSerial
            /// </summary>
            public const string AllocateFromSerial = "SALLOCFROM";

            /// <summary>
            /// Property for AllocateFromLot
            /// </summary>
            public const string AllocateFromLot = "LALLOCFROM";

            /// <summary>
            /// Property for SerialLotWindowHandle
            /// </summary>
            public const string SerialLotWindowHandle = "METERHWND";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for Billing Currency Number of Decimals
            /// </summary>
            public const string BillingCurrencyDecimal = "BILLCURDEC";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ReceiptLine Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for ReceiptLineSequence
            /// </summary>
            public const int ReceiptLineSequence = 3;

            /// <summary>
            /// Property Indexer for ReceiptCommentSequence
            /// </summary>
            public const int ReceiptCommentSequence = 4;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 5;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 6;

            /// <summary>
            /// Property Indexer for PostedToIC
            /// </summary>
            public const int PostedToIC = 7;

            /// <summary>
            /// Property Indexer for CompletionStatus
            /// </summary>
            public const int CompletionStatus = 8;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 9;

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 10;

            /// <summary>
            /// Property Indexer for PurchaseOrderLineSequence
            /// </summary>
            public const int PurchaseOrderLineSequence = 11;

            /// <summary>
            /// Property Indexer for CompletesPO
            /// </summary>
            public const int CompletesPO = 12;

            /// <summary>
            /// Property Indexer for ItemExists
            /// </summary>
            public const int ItemExists = 13;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 14;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 15;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 16;

            /// <summary>
            /// Property Indexer for VendorItemNumber
            /// </summary>
            public const int VendorItemNumber = 17;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 18;

            /// <summary>
            /// Property Indexer for UnitofMeasure
            /// </summary>
            public const int UnitofMeasure = 19;

            /// <summary>
            /// Property Indexer for OrderUnitConversion
            /// </summary>
            public const int OrderUnitConversion = 20;

            /// <summary>
            /// Property Indexer for OrderUnitDecimals
            /// </summary>
            public const int OrderUnitDecimals = 21;

            /// <summary>
            /// Property Indexer for ReceiptUnitofMeasure
            /// </summary>
            public const int ReceiptUnitofMeasure = 22;

            /// <summary>
            /// Property Indexer for ReceivingConversionFactor
            /// </summary>
            public const int ReceivingConversionFactor = 23;

            /// <summary>
            /// Property Indexer for ReceivingUnitDecimals
            /// </summary>
            public const int ReceivingUnitDecimals = 24;

            /// <summary>
            /// Property Indexer for StockUnitDecimals
            /// </summary>
            public const int StockUnitDecimals = 25;

            /// <summary>
            /// Property Indexer for OrderedQuantityOrdered
            /// </summary>
            public const int OrderedQuantityOrdered = 26;

            /// <summary>
            /// Property Indexer for OrderedPreviouslyReceived
            /// </summary>
            public const int OrderedPreviouslyReceived = 27;

            /// <summary>
            /// Property Indexer for OrderedOutstandingonPO
            /// </summary>
            public const int OrderedOutstandingonPO = 28;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 29;

            /// <summary>
            /// Property Indexer for QuantityCanceled
            /// </summary>
            public const int QuantityCanceled = 30;

            /// <summary>
            /// Property Indexer for QuantityOutstanding
            /// </summary>
            public const int QuantityOutstanding = 31;

            /// <summary>
            /// Property Indexer for StockingQuantityOrdered
            /// </summary>
            public const int StockingQuantityOrdered = 32;

            /// <summary>
            /// Property Indexer for StockingPreviouslyReceived
            /// </summary>
            public const int StockingPreviouslyReceived = 33;

            /// <summary>
            /// Property Indexer for StockingOutstandingonPO
            /// </summary>
            public const int StockingOutstandingonPO = 34;

            /// <summary>
            /// Property Indexer for QuantityOrdered
            /// </summary>
            public const int QuantityOrdered = 35;

            /// <summary>
            /// Property Indexer for ReceivedToDate
            /// </summary>
            public const int ReceivedToDate = 36;

            /// <summary>
            /// Property Indexer for QuantityOutstanding1
            /// </summary>
            public const int QuantityOutstanding1 = 37;

            /// <summary>
            /// Property Indexer for ReceivingQtyReceivedExtra
            /// </summary>
            public const int ReceivingQtyReceivedExtra = 38;

            /// <summary>
            /// Property Indexer for StockingQuantityReceived
            /// </summary>
            public const int StockingQuantityReceived = 39;

            /// <summary>
            /// Property Indexer for StockingQuantityCanceled
            /// </summary>
            public const int StockingQuantityCanceled = 40;

            /// <summary>
            /// Property Indexer for StockingQuantityOutstanding
            /// </summary>
            public const int StockingQuantityOutstanding = 41;

            /// <summary>
            /// Property Indexer for StockingQuantityReceivedExtra
            /// </summary>
            public const int StockingQuantityReceivedExtra = 42;

            /// <summary>
            /// Property Indexer for OrderedQuantityReceived
            /// </summary>
            public const int OrderedQuantityReceived = 43;

            /// <summary>
            /// Property Indexer for OrderedQuantityCanceled
            /// </summary>
            public const int OrderedQuantityCanceled = 44;

            /// <summary>
            /// Property Indexer for OrderedQuantityOutstanding
            /// </summary>
            public const int OrderedQuantityOutstanding = 45;

            /// <summary>
            /// Property Indexer for ReceivedExtra
            /// </summary>
            public const int ReceivedExtra = 46;

            /// <summary>
            /// Property Indexer for QuantityReturned
            /// </summary>
            public const int QuantityReturned = 47;

            /// <summary>
            /// Property Indexer for StockingQuantityReturned
            /// </summary>
            public const int StockingQuantityReturned = 48;

            /// <summary>
            /// Property Indexer for OrderedQuantityReturned
            /// </summary>
            public const int OrderedQuantityReturned = 49;

            /// <summary>
            /// Property Indexer for QuantityStocked
            /// </summary>
            public const int QuantityStocked = 50;

            /// <summary>
            /// Property Indexer for StockingQuantityStocked
            /// </summary>
            public const int StockingQuantityStocked = 51;

            /// <summary>
            /// Property Indexer for OrderedQuantityStocked
            /// </summary>
            public const int OrderedQuantityStocked = 52;

            /// <summary>
            /// Property Indexer for QuantityAdjustedbyInvoice
            /// </summary>
            public const int QuantityAdjustedbyInvoice = 53;

            /// <summary>
            /// Property Indexer for StockingQtyAdjbyInvoice
            /// </summary>
            public const int StockingQtyAdjbyInvoice = 54;

            /// <summary>
            /// Property Indexer for OrderedQuantityAdjbyInvoice
            /// </summary>
            public const int OrderedQuantityAdjbyInvoice = 55;

            /// <summary>
            /// Property Indexer for QuantityFilledonPO
            /// </summary>
            public const int QuantityFilledonPO = 56;

            /// <summary>
            /// Property Indexer for StockingQuantityFilledonPO
            /// </summary>
            public const int StockingQuantityFilledonPO = 57;

            /// <summary>
            /// Property Indexer for OrderedQuantityFilledonPO
            /// </summary>
            public const int OrderedQuantityFilledonPO = 58;

            /// <summary>
            /// Property Indexer for QuantitySettled
            /// </summary>
            public const int QuantitySettled = 59;

            /// <summary>
            /// Property Indexer for StockingQuantitySettled
            /// </summary>
            public const int StockingQuantitySettled = 60;

            /// <summary>
            /// Property Indexer for OrderedQuantitySettled
            /// </summary>
            public const int OrderedQuantitySettled = 61;

            /// <summary>
            /// Property Indexer for QuantityUnstocked
            /// </summary>
            public const int QuantityUnstocked = 62;

            /// <summary>
            /// Property Indexer for StockingQuantityUnstocked
            /// </summary>
            public const int StockingQuantityUnstocked = 63;

            /// <summary>
            /// Property Indexer for OrderedQuantityUnstocked
            /// </summary>
            public const int OrderedQuantityUnstocked = 64;

            /// <summary>
            /// Property Indexer for UnitWeight
            /// </summary>
            public const int UnitWeight = 65;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 66;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 67;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 68;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 69;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 70;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 71;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 72;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 73;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 74;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 75;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 76;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 77;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 78;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 79;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 80;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 81;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 82;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 83;

            /// <summary>
            /// Property Indexer for TaxIncludable1
            /// </summary>
            public const int TaxIncludable1 = 84;

            /// <summary>
            /// Property Indexer for TaxIncludable2
            /// </summary>
            public const int TaxIncludable2 = 85;

            /// <summary>
            /// Property Indexer for TaxIncludable3
            /// </summary>
            public const int TaxIncludable3 = 86;

            /// <summary>
            /// Property Indexer for TaxIncludable4
            /// </summary>
            public const int TaxIncludable4 = 87;

            /// <summary>
            /// Property Indexer for TaxIncludable5
            /// </summary>
            public const int TaxIncludable5 = 88;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 89;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 90;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 91;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 92;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 93;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 94;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 95;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 96;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 97;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 98;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 99;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 100;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 101;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 102;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 103;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 104;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 105;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 106;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 107;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 108;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 109;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 110;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 111;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 112;

            /// <summary>
            /// Property Indexer for RecoverableTax
            /// </summary>
            public const int RecoverableTax = 113;

            /// <summary>
            /// Property Indexer for ExpensedTax
            /// </summary>
            public const int ExpensedTax = 114;

            /// <summary>
            /// Property Indexer for AllocatedTax
            /// </summary>
            public const int AllocatedTax = 115;

            /// <summary>
            /// Property Indexer for FuncNetOfTax
            /// </summary>
            public const int FuncNetOfTax = 116;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount1
            /// </summary>
            public const int FuncTaxIncludedAmount1 = 117;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount2
            /// </summary>
            public const int FuncTaxIncludedAmount2 = 118;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount3
            /// </summary>
            public const int FuncTaxIncludedAmount3 = 119;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount4
            /// </summary>
            public const int FuncTaxIncludedAmount4 = 120;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount5
            /// </summary>
            public const int FuncTaxIncludedAmount5 = 121;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount1
            /// </summary>
            public const int FuncTaxAllocatedAmount1 = 122;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount2
            /// </summary>
            public const int FuncTaxAllocatedAmount2 = 123;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount3
            /// </summary>
            public const int FuncTaxAllocatedAmount3 = 124;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount4
            /// </summary>
            public const int FuncTaxAllocatedAmount4 = 125;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount5
            /// </summary>
            public const int FuncTaxAllocatedAmount5 = 126;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount1
            /// </summary>
            public const int FuncTaxRecoverableAmount1 = 127;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount2
            /// </summary>
            public const int FuncTaxRecoverableAmount2 = 128;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount3
            /// </summary>
            public const int FuncTaxRecoverableAmount3 = 129;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount4
            /// </summary>
            public const int FuncTaxRecoverableAmount4 = 130;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount5
            /// </summary>
            public const int FuncTaxRecoverableAmount5 = 131;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount1
            /// </summary>
            public const int FuncTaxExpenseAmount1 = 132;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount2
            /// </summary>
            public const int FuncTaxExpenseAmount2 = 133;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount3
            /// </summary>
            public const int FuncTaxExpenseAmount3 = 134;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount4
            /// </summary>
            public const int FuncTaxExpenseAmount4 = 135;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount5
            /// </summary>
            public const int FuncTaxExpenseAmount5 = 136;

            /// <summary>
            /// Property Indexer for ExpenseAccount
            /// </summary>
            public const int ExpenseAccount = 137;

            /// <summary>
            /// Property Indexer for ArrivalDate
            /// </summary>
            public const int ArrivalDate = 138;

            /// <summary>
            /// Property Indexer for NumberOfLabels
            /// </summary>
            public const int NumberOfLabels = 139;

            /// <summary>
            /// Property Indexer for ManualProration
            /// </summary>
            public const int ManualProration = 140;

            /// <summary>
            /// Property Indexer for DropShip
            /// </summary>
            public const int DropShip = 141;

            /// <summary>
            /// Property Indexer for DropShipType
            /// </summary>
            public const int DropShipType = 142;

            /// <summary>
            /// Property Indexer for DropShipCustomer
            /// </summary>
            public const int DropShipCustomer = 143;

            /// <summary>
            /// Property Indexer for CustomerShipToAddress
            /// </summary>
            public const int CustomerShipToAddress = 144;

            /// <summary>
            /// Property Indexer for DropShipLocation
            /// </summary>
            public const int DropShipLocation = 145;

            /// <summary>
            /// Property Indexer for DropShipDescription
            /// </summary>
            public const int DropShipDescription = 146;

            /// <summary>
            /// Property Indexer for DropShipAddress1
            /// </summary>
            public const int DropShipAddress1 = 147;

            /// <summary>
            /// Property Indexer for DropShipAddress2
            /// </summary>
            public const int DropShipAddress2 = 148;

            /// <summary>
            /// Property Indexer for DropShipAddress3
            /// </summary>
            public const int DropShipAddress3 = 149;

            /// <summary>
            /// Property Indexer for DropShipAddress4
            /// </summary>
            public const int DropShipAddress4 = 150;

            /// <summary>
            /// Property Indexer for DropShipCity
            /// </summary>
            public const int DropShipCity = 151;

            /// <summary>
            /// Property Indexer for DropShipStateProvince
            /// </summary>
            public const int DropShipStateProvince = 152;

            /// <summary>
            /// Property Indexer for DropShipZipPostalCode
            /// </summary>
            public const int DropShipZipPostalCode = 153;

            /// <summary>
            /// Property Indexer for DropShipCountry
            /// </summary>
            public const int DropShipCountry = 154;

            /// <summary>
            /// Property Indexer for DropShipPhoneNumber
            /// </summary>
            public const int DropShipPhoneNumber = 155;

            /// <summary>
            /// Property Indexer for DropShipFaxNumber
            /// </summary>
            public const int DropShipFaxNumber = 156;

            /// <summary>
            /// Property Indexer for DropShipContact
            /// </summary>
            public const int DropShipContact = 157;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 158;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 159;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 161;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 162;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 163;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 164;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 165;

            /// <summary>
            /// Property Indexer for ExpenseAccountDescription
            /// </summary>
            public const int ExpenseAccountDescription = 166;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 167;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 168;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 169;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 170;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 171;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 172;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 173;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 174;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 175;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 176;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 177;

            /// <summary>
            /// Property Indexer for ExtraneousLineCount
            /// </summary>
            public const int ExtraneousLineCount = 178;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 179;

            /// <summary>
            /// Property Indexer for NumberOfLinesProrated
            /// </summary>
            public const int NumberOfLinesProrated = 180;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 181;

            /// <summary>
            /// Property Indexer for Line
            /// </summary>
            public const int Line = 182;

            /// <summary>
            /// Property Indexer for ExtendedStdCostInSrcCurr
            /// </summary>
            public const int ExtendedStdCostInSrcCurr = 183;

            /// <summary>
            /// Property Indexer for ExtendedMRCostInSrcCurr
            /// </summary>
            public const int ExtendedMRCostInSrcCurr = 184;

            /// <summary>
            /// Property Indexer for ExtendedCost1InSrcCurr
            /// </summary>
            public const int ExtendedCost1InSrcCurr = 185;

            /// <summary>
            /// Property Indexer for ExtendedCost2InSrcCurr
            /// </summary>
            public const int ExtendedCost2InSrcCurr = 186;

            /// <summary>
            /// Property Indexer for DropShipEmail
            /// </summary>
            public const int DropShipEmail = 187;

            /// <summary>
            /// Property Indexer for DropShipContactPhone
            /// </summary>
            public const int DropShipContactPhone = 188;

            /// <summary>
            /// Property Indexer for DropShipContactFax
            /// </summary>
            public const int DropShipContactFax = 189;

            /// <summary>
            /// Property Indexer for DropShipContactEmail
            /// </summary>
            public const int DropShipContactEmail = 190;

            /// <summary>
            /// Property Indexer for NonStockClearingAccount
            /// </summary>
            public const int NonStockClearingAccount = 191;

            /// <summary>
            /// Property Indexer for NonStockClearingAccountDesc
            /// </summary>
            public const int NonStockClearingAccountDesc = 192;

            /// <summary>
            /// Property Indexer for InterprocessCommID
            /// </summary>
            public const int InterprocessCommID = 193;

            /// <summary>
            /// Property Indexer for ForcePopupSN
            /// </summary>
            public const int ForcePopupSN = 194;

            /// <summary>
            /// Property Indexer for PopupSN
            /// </summary>
            public const int PopupSN = 195;

            /// <summary>
            /// Property Indexer for CloseSN
            /// </summary>
            public const int CloseSN = 196;

            /// <summary>
            /// Property Indexer for LTSetID
            /// </summary>
            public const int LTSetID = 197;

            /// <summary>
            /// Property Indexer for ForcePopupLT
            /// </summary>
            public const int ForcePopupLT = 198;

            /// <summary>
            /// Property Indexer for PopupLT
            /// </summary>
            public const int PopupLT = 199;

            /// <summary>
            /// Property Indexer for CloseLT
            /// </summary>
            public const int CloseLT = 200;

            /// <summary>
            /// Property Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 201;

            /// <summary>
            /// Property Indexer for MapManufacturersItemNumber
            /// </summary>
            public const int MapManufacturersItemNumber = 202;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 203;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 204;

            /// <summary>
            /// Property Indexer for FuncDiscountAmount
            /// </summary>
            public const int FuncDiscountAmount = 205;

            /// <summary>
            /// Property Indexer for NetExtendedCost
            /// </summary>
            public const int NetExtendedCost = 206;

            /// <summary>
            /// Property Indexer for PartInvPvQtyInvoiced
            /// </summary>
            public const int PartInvPvQtyInvcd = 207;

            /// <summary>
            /// Property Indexer for PartInvPvExtWgtInvcd
            /// </summary>
            public const int PartInvPvExtWgtInvcd = 208;

            /// <summary>
            /// Property Indexer for PartInvPvNetCostInvoiced
            /// </summary>
            public const int PartInvPvNetCostInvoiced = 209;

            /// <summary>
            /// Property Indexer for InvoiceLines
            /// </summary>
            public const int InvoiceLines = 210;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 211;

            /// <summary>
            /// Property Indexer for LineNumber1
            /// </summary>
            public const int LineNumber1 = 212;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 213;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 214;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 215;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 216;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 217;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 218;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 219;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 220;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 221;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 222;

            /// <summary>
            /// Property Indexer for RetainagePercentage
            /// </summary>
            public const int RetainagePercentage = 223;

            /// <summary>
            /// Property Indexer for RetentionPeriod
            /// </summary>
            public const int RetentionPeriod = 224;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 225;

            /// <summary>
            /// Property Indexer for RetainageAmountOverridden
            /// </summary>
            public const int RetainageAmountOverridden = 226;

            /// <summary>
            /// Property Indexer for BillableLine
            /// </summary>
            public const int BillableLine = 227;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 228;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 229;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 230;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 231;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 232;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 233;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 234;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 235;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 236;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 237;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 238;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 239;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 240;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 241;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 242;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 243;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 244;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 245;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 246;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 247;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 248;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 249;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 250;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 251;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 252;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 253;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 254;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 255;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 256;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 257;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 258;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 259;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 260;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 261;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 262;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 263;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 264;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 265;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 266;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 267;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 268;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 269;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 270;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 271;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 272;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 273;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 274;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 275;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 276;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 277;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt1
            /// </summary>
            public const int RetainageTaxRecoverableAmt1 = 278;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt2
            /// </summary>
            public const int RetainageTaxRecoverableAmt2 = 279;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt3
            /// </summary>
            public const int RetainageTaxRecoverableAmt3 = 280;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt4
            /// </summary>
            public const int RetainageTaxRecoverableAmt4 = 281;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt5
            /// </summary>
            public const int RetainageTaxRecoverableAmt5 = 282;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount1
            /// </summary>
            public const int RetainageTaxExpenseAmount1 = 283;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount2
            /// </summary>
            public const int RetainageTaxExpenseAmount2 = 284;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount3
            /// </summary>
            public const int RetainageTaxExpenseAmount3 = 285;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount4
            /// </summary>
            public const int RetainageTaxExpenseAmount4 = 286;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount5
            /// </summary>
            public const int RetainageTaxExpenseAmount5 = 287;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount1
            /// </summary>
            public const int RetainageTaxAllocatedAmount1 = 288;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount2
            /// </summary>
            public const int RetainageTaxAllocatedAmount2 = 289;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount3
            /// </summary>
            public const int RetainageTaxAllocatedAmount3 = 290;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount4
            /// </summary>
            public const int RetainageTaxAllocatedAmount4 = 291;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount5
            /// </summary>
            public const int RetainageTaxAllocatedAmount5 = 292;

            /// <summary>
            /// Property Indexer for RetainageTaxTotalAmount
            /// </summary>
            public const int RetainageTaxTotalAmount = 293;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt1 = 294;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt2 = 295;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt3 = 296;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt4 = 297;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt5 = 298;

            /// <summary>
            /// Property Indexer for UnitCostIsManual
            /// </summary>
            public const int UnitCostIsManual = 299;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure
            /// </summary>
            public const int WeightUnitOfMeasure = 300;

            /// <summary>
            /// Property Indexer for WeightConversion
            /// </summary>
            public const int WeightConversion = 301;

            /// <summary>
            /// Property Indexer for DefaultUnitWeight
            /// </summary>
            public const int DefaultUnitWeight = 302;

            /// <summary>
            /// Property Indexer for DefaultExtendedWeight
            /// </summary>
            public const int DefaultExtendedWeight = 303;

            /// <summary>
            /// Property Indexer for PartInvPvDefExtWInv
            /// </summary>
            public const int PartInvPvDefExtWInv = 304;

            /// <summary>
            /// Property Indexer for BillingRateConversionFactor
            /// </summary>
            public const int BillingRateConversionFactor = 305;

            /// <summary>
            /// Property Indexer for UnitBillingAmount
            /// </summary>
            public const int UnitBillingAmount = 306;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 307;

            /// <summary>
            /// Property Indexer for FixedAsset
            /// </summary>
            public const int FixedAsset = 308;

            /// <summary>
            /// Property Indexer for AssetCreated
            /// </summary>
            public const int AssetCreated = 309;

            /// <summary>
            /// Property Indexer for SageFixedAssetsDatabase
            /// </summary>
            public const int SageFADatabase = 310;

            /// <summary>
            /// Property Indexer for SageFixedAssetsCompanyOrg
            /// </summary>
            public const int SageFACompanyOrg = 311;

            /// <summary>
            /// Property Indexer for SageFixedAssetsTemplate
            /// </summary>
            public const int SageFATemplate = 312;

            /// <summary>
            /// Property Indexer for SageFixedAssetsAssetDescription
            /// </summary>
            public const int SageFAAssetDesc = 313;

            /// <summary>
            /// Property Indexer for SeparateAssets
            /// </summary>
            public const int SeparateAssets = 314;

            /// <summary>
            /// Property Indexer for SageFixedAssetsQuantity
            /// </summary>
            public const int SageFAQuantity = 315;

            /// <summary>
            /// Property Indexer for Sage Fixed Assets Unit Of Measure
            /// </summary>
            public const int SageFAUnitOfMeasure = 316;

            /// <summary>
            /// Property Indexer for SageFixedAssetsAssetValue
            /// </summary>
            public const int SageFAAssetValue = 317;

            /// <summary>
            /// Property Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 318;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 319;

            /// <summary>
            /// Property Indexer for ItemSerializedLotted
            /// </summary>
            public const int ItemSerializedLotted = 320;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 321;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 322;

            /// <summary>
            /// Property Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 323;

            /// <summary>
            /// Property Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 324;

            /// <summary>
            /// Property Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 325;

            /// <summary>
            /// Property Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 326;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 327;

            /// <summary>
            /// Property Indexer for ReverseChargeable1
            /// </summary>
            public const int ReverseChargeable1 = 328;
            /// <summary>
            /// Property Indexer for ReverseChargeable2
            /// </summary>
            public const int ReverseChargeable2 = 329;
            /// <summary>
            /// Property Indexer for ReverseChargeable3
            /// </summary>
            public const int ReverseChargeable3 = 330;
            /// <summary>
            /// Property Indexer for ReverseChargeable4
            /// </summary>
            public const int ReverseChargeable4 = 331;
            /// <summary>
            /// Property Indexer for ReverseChargeable5
            /// </summary>
            public const int ReverseChargeable5 = 332;

            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 333;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 334;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 335;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 336;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 337;
            /// <summary>
            /// Property Indexer for customer detail tax amount 1
            /// </summary>
            public const int CustomerDetailTaxAmount1 = 338;
            /// <summary>
            /// Property Indexer for customer detail tax amount 2
            /// </summary>
            public const int CustomerDetailTaxAmount2 = 339;
            /// <summary>
            /// Property Indexer for customer detail tax amount 3
            /// </summary>
            public const int CustomerDetailTaxAmount3 = 340;
            /// <summary>
            /// Property Indexer for customer detail tax amount 4
            /// </summary>
            public const int CustomerDetailTaxAmount4 = 341;
            /// <summary>
            /// Property Indexer for customer detail tax amount 5
            /// </summary>
            public const int CustomerDetailTaxAmount5 = 342;
            /// <summary>
            /// Property Indexer for Billing Currency Number of Decimals
            /// </summary>
            public const int BillingCurrencyDecimal = 343;
        }

        #endregion
    }
}