// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptLineLot Constants
    /// </summary>
    public partial class ReceiptLineLot
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0789";
        public const string ImportEntityName = "PO0463";

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of ReceiptLineLot Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "RCPLREV";

            /// <summary>
            /// Property for LotNumber
            /// </summary>
            public const string LotNumber = "LOTNUMF";

            /// <summary>
            /// Property for ReceiptLineSequence
            /// </summary>
            public const string ReceiptLineSequence = "RCPLSEQ";

            /// <summary>
            /// Property for ExpiryDate
            /// </summary>
            public const string ExpiryDate = "EXPIRYDATE";

            /// <summary>
            /// Property for LotQuantity
            /// </summary>
            public const string LotQuantity = "QTY";

            /// <summary>
            /// Property for LotStockQuantity
            /// </summary>
            public const string LotStockQuantity = "QTYSQ";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ReceiptLineLot Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for LotNumber
            /// </summary>
            public const int LotNumber = 3;

            /// <summary>
            /// Property Indexer for ReceiptLineSequence
            /// </summary>
            public const int ReceiptLineSequence = 4;

            /// <summary>
            /// Property Indexer for ExpiryDate
            /// </summary>
            public const int ExpiryDate = 5;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 6;

            /// <summary>
            /// Property Indexer for LotStockQuantity
            /// </summary>
            public const int LotStockQuantity = 7;
        }

        #endregion
    }
}