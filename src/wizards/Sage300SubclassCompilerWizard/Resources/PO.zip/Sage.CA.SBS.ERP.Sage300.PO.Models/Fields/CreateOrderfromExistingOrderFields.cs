﻿// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of CreateOrderfromExistingOrder Constants
    /// </summary>
    public partial class CreateOrderfromExistingOrder
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0294";

        #region Properties

        /// <summary>
        /// Contains list of CreateOrderfromExistingOrder Field Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for FromVendorNumber
            /// </summary>
            public const string FromVendorNumber = "FRVEND";

            /// <summary>
            /// Property for ToVendorNumber
            /// </summary>
            public const string ToVendorNumber = "TOVEND";

            /// <summary>
            /// Property for FromPONumber
            /// </summary>
            public const string FromPONumber = "FRPONUM";

            /// <summary>
            /// Property for ToPONumber
            /// </summary>
            public const string ToPONumber = "TOPONUM";

            /// <summary>
            /// Property for ActionPerformed
            /// </summary>
            public const string ActionPerformed = "ACTION";

            /// <summary>
            /// Property for TaxGroup
            /// </summary>
            public const string TaxGroup = "TAXGROUP";

            /// <summary>
            /// Property for TaxGroupDescription
            /// </summary>
            public const string TaxGroupDescription = "TXGRPDESC";

            /// <summary>
            /// Property for TaxGroupCurrency
            /// </summary>
            public const string TaxGroupCurrency = "TXGRPCURR";

            /// <summary>
            /// Property for FromVendorCurrency
            /// </summary>
            public const string FromVendorCurrency = "FRVENDCURR";

            /// <summary>
            /// Property for ToVendorCurrency
            /// </summary>
            public const string ToVendorCurrency = "TOVENDCURR";

            /// <summary>
            /// Property for FromVendorName
            /// </summary>
            public const string FromVendorName = "FRVENDNAME";

            /// <summary>
            /// Property for ToVendorName
            /// </summary>
            public const string ToVendorName = "TOVENDNAME";

            /// <summary>
            /// Property for JobRelated
            /// </summary>
            public const string JobRelated = "HASJOB";

            /// <summary>
            /// Property for UsePOCost
            /// </summary>
            public const string UsePOCost = "USEPOCOST";

            /// <summary>
            /// Property for POType
            /// </summary>
            public const string POType = "ORDTYPE";

        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of CreateOrderfromExistingOrder Index Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for FromVendorNumber
            /// </summary>
            public const int FromVendorNumber = 1;

            /// <summary>
            /// Property Indexer for ToVendorNumber
            /// </summary>
            public const int ToVendorNumber = 2;

            /// <summary>
            /// Property Indexer for FromPONumber
            /// </summary>
            public const int FromPONumber = 3;

            /// <summary>
            /// Property Indexer for ToPONumber
            /// </summary>
            public const int ToPONumber = 4;

            /// <summary>
            /// Property Indexer for ActionPerformed
            /// </summary>
            public const int ActionPerformed = 5;

            /// <summary>
            /// Property Indexer for TaxGroup
            /// </summary>
            public const int TaxGroup = 6;

            /// <summary>
            /// Property Indexer for TaxGroupDescription
            /// </summary>
            public const int TaxGroupDescription = 7;

            /// <summary>
            /// Property Indexer for TaxGroupCurrency
            /// </summary>
            public const int TaxGroupCurrency = 8;

            /// <summary>
            /// Property Indexer for FromVendorCurrency
            /// </summary>
            public const int FromVendorCurrency = 9;

            /// <summary>
            /// Property Indexer for ToVendorCurrency
            /// </summary>
            public const int ToVendorCurrency = 10;

            /// <summary>
            /// Property Indexer for FromVendorName
            /// </summary>
            public const int FromVendorName = 11;

            /// <summary>
            /// Property Indexer for ToVendorName
            /// </summary>
            public const int ToVendorName = 12;

            /// <summary>
            /// Property Indexer for JobRelated
            /// </summary>
            public const int JobRelated = 13;

            /// <summary>
            /// Property Indexer for UsePOCost
            /// </summary>
            public const int UsePOCost = 14;

            /// <summary>
            /// Property Indexer for POType
            /// </summary>
            public const int POType = 15;

        }

        #endregion

    }
}
