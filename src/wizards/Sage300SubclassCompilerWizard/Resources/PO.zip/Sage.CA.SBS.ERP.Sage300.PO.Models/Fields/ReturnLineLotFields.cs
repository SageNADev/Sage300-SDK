// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of Return Line Lot Constants
     /// </summary>
     public partial class ReturnLineLot
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0799";

          #region Properties
          /// <summary>
          /// Contains list of ReturnLineLot Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for ReturnSequenceKey
               /// </summary>
               public const string ReturnSequenceKey = "RETHSEQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "RETLREV";

               /// <summary>
               /// Property for LotNumber
               /// </summary>
               public const string LotNumber = "LOTNUMF";

               /// <summary>
               /// Property for ReturnLineSequence
               /// </summary>
               public const string ReturnLineSequence = "RETLSEQ";

               /// <summary>
               /// Property for ExpiryDate
               /// </summary>
               public const string ExpiryDate = "EXPIRYDATE";

               /// <summary>
               /// Property for LotQuantity
               /// </summary>
               public const string LotQuantity = "QTY";

               /// <summary>
               /// Property for LotStockQuantity
               /// </summary>
               public const string LotStockQuantity = "QTYSQ";

               /// <summary>
               /// Property for Returned
               /// </summary>
               public const string Returned = "QTYMOVED";

               /// <summary>
               /// Property for ReturnedStock
               /// </summary>
               public const string ReturnedStock = "QTYMOVEDSQ";
          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of ReturnLineLot Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for ReturnSequenceKey
               /// </summary>
               public const int ReturnSequenceKey = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for LotNumber
               /// </summary>
               public const int LotNumber = 3;

               /// <summary>
               /// Property Indexer for ReturnLineSequence
               /// </summary>
               public const int ReturnLineSequence = 4;

               /// <summary>
               /// Property Indexer for ExpiryDate
               /// </summary>
               public const int ExpiryDate = 5;

               /// <summary>
               /// Property Indexer for LotQuantity
               /// </summary>
               public const int LotQuantity = 6;

               /// <summary>
               /// Property Indexer for LotStockQuantity
               /// </summary>
               public const int LotStockQuantity = 7;

               /// <summary>
               /// Property Indexer for Returned
               /// </summary>
               public const int Returned = 8;

               /// <summary>
               /// Property Indexer for ReturnedStock
               /// </summary>
               public const int ReturnedStock = 9;
          }
          #endregion
     }
}