// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Reports
// ReSharper restore CheckNamespace
{
	/// <summary>
	/// Contains list of Receiving Slip Report Constants
	/// </summary>
    public partial class ReceivingSlipReport
    {
        #region Constants
        /// <summary>
		/// View Name
		/// </summary>
        public const string ViewName = "C52AA3F8-64F4-458F-9583-0794AB4D7B85";
        
        #endregion

        #region Fields

        /// <summary>
		/// Contains list of Receiving Slip Report Field Constants
		/// </summary>
		public class Fields
        {
            #region Properties
            /// <summary>
            /// Property for From Requisition
			/// </summary>
            public const string FromReceiptNumber = "RCPFROM";

			/// <summary>
            /// Property for To Requisition
			/// </summary>
            public const string ToReceiptNumber = "RCPTO";

			/// <summary>
			/// Property for Printed
			/// </summary>
			public const string Printed = "PRINTED";

			/// <summary>
            /// Property for Quantity Decimal
			/// </summary>
            public const string QuantityDecimal = "QTYDEC";

            /// <summary>
            /// Property for Print Serial/Lot Numbers
            /// </summary>
            public const string PrintSerialLot = "SERIALLOTNUMBERS";
            #endregion
        }

		#endregion

        #region Index

        /// <summary>
		/// Contains list of Receiving Slip Report Index Constants
		/// </summary>
		public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for From Requisition
			/// </summary>
            public const int FromRequisition = 2;

			/// <summary>
            /// Property Indexer for To Requisition
			/// </summary>
            public const int ToRequisition = 3;

			/// <summary>
			/// Property Indexer for Printed
			/// </summary>
			public const int Printed = 4;

			/// <summary>
            /// Property Indexer for Quantity Decimal
			/// </summary>
            public const int QuantityDecimal = 5;

			/// <summary>
			/// Property Indexer for Home decimal
			/// </summary>
			public const int Homedecimal = 6;

            /// <summary>
            /// Property Indexer for Show Cost
            /// </summary>
            public const int ShowCost = 7;

            #endregion
        }

		#endregion

	}
}
