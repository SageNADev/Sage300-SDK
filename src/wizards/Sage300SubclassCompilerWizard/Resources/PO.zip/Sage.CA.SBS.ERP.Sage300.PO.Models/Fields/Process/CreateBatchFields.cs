// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Process
{
     /// <summary>
     /// Class for Create Batch Constants
     /// </summary>
     public partial class CreateBatch
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0353";

          #region Fields
          /// <summary>
          /// Contains list of CreateBatch Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for DayEndNumber
               /// </summary>
               public const string DayEndNumber = "SEQEND";

               /// <summary>
               /// Property for TransactionsCreated
               /// </summary>
               public const string TransactionsCreated = "TRANSCREAT";

               /// <summary>
               /// Property for PostGorLBatch
               /// </summary>
               public const string PostGorLBatch = "POSTGLBTCH";

               /// <summary>
               /// Property for PostAorPBatch
               /// </summary>
               public const string PostAorPBatch = "POSTAPBTCH";

          }
          #endregion

          #region Index
          /// <summary>
          /// Contains list of CreateBatch Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for DayEndNumber
               /// </summary>
               public const int DayEndNumber = 1;

               /// <summary>
               /// Property Indexer for TransactionsCreated
               /// </summary>
               public const int TransactionsCreated = 2;

               /// <summary>
               /// Property Indexer for PostGorLBatch
               /// </summary>
               public const int PostGorLBatch = 3;

               /// <summary>
               /// Property Indexer for PostAorPBatch
               /// </summary>
               public const int PostAorPBatch = 4;

          }

          #endregion
     }
}
