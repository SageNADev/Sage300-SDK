// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Process
{
     /// <summary>
    /// Contains list of ClearHistory Constants
     /// </summary>
    public partial class ClearHistory
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0302";

          #region Properties Fields
          /// <summary>
          /// Contains list of POClearHistorySuperview Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for ClearTransactionHistory
               /// </summary>
               public const string ClearTransactionHistory = "POTRNHIST";

               /// <summary>
               /// Property for ThroughTransactionHistoryDate
               /// </summary>
               public const string ThroughTransactionHistoryDate = "POTRNDATE";

               /// <summary>
               /// Property for ClearPurchaseHistory
               /// </summary>
               public const string ClearPurchaseHistory = "PURHIST";

               /// <summary>
               /// Property for PurchaseHistoryYear
               /// </summary>
               public const string PurchaseHistoryYear = "PHYR";

               /// <summary>
               /// Property for PurchaseHistoryPeriod
               /// </summary>
               public const string PurchaseHistoryPeriod = "PHPR";

               /// <summary>
               /// Property for ByVendororItem
               /// </summary>
               public const string ByVendororItem = "BYVEND";

               /// <summary>
               /// Property for FromVendor
               /// </summary>
               public const string FromVendor = "FRVEND";

               /// <summary>
               /// Property for ToVendor
               /// </summary>
               public const string ToVendor = "TOVEND";

               /// <summary>
               /// Property for FromItem
               /// </summary>
               public const string FromItem = "FRITEM";

               /// <summary>
               /// Property for ToItem
               /// </summary>
               public const string ToItem = "TOITEM";

               /// <summary>
               /// Property for ClearPurchaseStatistics
               /// </summary>
               public const string ClearPurchaseStatistics = "STATS";

               /// <summary>
               /// Property for PurchaseStatisticsYear
               /// </summary>
               public const string PurchaseStatisticsYear = "STATYR";

               /// <summary>
               /// Property for PurchaseStatisticsPeriod
               /// </summary>
               public const string PurchaseStatisticsPeriod = "STATPR";

               /// <summary>
               /// Property for ClearPrintedPostingJournals
               /// </summary>
               public const string ClearPrintedPostingJournals = "POSTJ";

               /// <summary>
               /// Property for ThroughDayEndNo
               /// </summary>
               public const string ThroughDayEndNo = "DAYENDNUM";

               /// <summary>
               /// Property for Receipts
               /// </summary>
               public const string Receipts = "RCPTS";

               /// <summary>
               /// Property for Invoices
               /// </summary>
               public const string Invoices = "INV";

               /// <summary>
               /// Property for CreditDebitNotes
               /// </summary>
               public const string CreditDebitNotes = "CRN";

               /// <summary>
               /// Property for Returns
               /// </summary>
               public const string Returns = "RTNS";

               /// <summary>
               /// Property for ExpiredRejectedRequisitions
               /// </summary>
               public const string ExpiredRejectedRequisitions = "EXPRQN";

               /// <summary>
               /// Property for SuppressMessages
               /// </summary>
               public const string SuppressMessages = "SUPPRESS";

               /// <summary>
               /// Property for ClearPayablesClearingAudit
               /// </summary>
               public const string ClearPayablesClearingAudit = "APCLEAR";

               /// <summary>
               /// Property for PayablesClearingYear
               /// </summary>
               public const string PayablesClearingYear = "APCLEARYR";

               /// <summary>
               /// Property for PayablesClearingPeriod
               /// </summary>
               public const string PayablesClearingPeriod = "APCLEARPR";

               /// <summary>
               /// Property for FromAccountSet
               /// </summary>
               public const string FromAccountSet = "FRACCT";

               /// <summary>
               /// Property for ToAccountSet
               /// </summary>
               public const string ToAccountSet = "TOACCT";

               /// <summary>
               /// Property for ClearItemTransactionHistory
               /// </summary>
               public const string ClearItemTransactionHistory = "CLRTHIST";

               /// <summary>
               /// Property for ThroughYear
               /// </summary>
               public const string ThroughYear = "UPTOHTYR";

               /// <summary>
               /// Property for ThroughPeriod
               /// </summary>
               public const string ThroughPeriod = "UPTOHTPD";

               /// <summary>
               /// Property for ClearCommittedCostsAudit
               /// </summary>
               public const string ClearCommittedCostsAudit = "CLRCOCA";

               /// <summary>
               /// Property for FromContract
               /// </summary>
               public const string FromContract = "FRCTRACT";

               /// <summary>
               /// Property for ToContract
               /// </summary>
               public const string ToContract = "TOCTRACT";

               /// <summary>
               /// Property for FromProject
               /// </summary>
               public const string FromProject = "FRPROJECT";

               /// <summary>
               /// Property for ToProject
               /// </summary>
               public const string ToProject = "TOPROJECT";

               /// <summary>
               /// Property for FromCategory
               /// </summary>
               public const string FromCategory = "FRCCATG";

               /// <summary>
               /// Property for ToCategory
               /// </summary>
               public const string ToCategory = "TOCCATG";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of POClearHistorySuperview Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for ClearTransactionHistory
               /// </summary>
               public const int ClearTransactionHistory = 1;

               /// <summary>
               /// Property Indexer for ThroughTransactionHistoryDate
               /// </summary>
               public const int ThroughTransactionHistoryDate = 2;

               /// <summary>
               /// Property Indexer for ClearPurchaseHistory
               /// </summary>
               public const int ClearPurchaseHistory = 3;

               /// <summary>
               /// Property Indexer for PurchaseHistoryYear
               /// </summary>
               public const int PurchaseHistoryYear = 4;

               /// <summary>
               /// Property Indexer for PurchaseHistoryPeriod
               /// </summary>
               public const int PurchaseHistoryPeriod = 5;

               /// <summary>
               /// Property Indexer for ByVendororItem
               /// </summary>
               public const int ByVendororItem = 6;

               /// <summary>
               /// Property Indexer for FromVendor
               /// </summary>
               public const int FromVendor = 7;

               /// <summary>
               /// Property Indexer for ToVendor
               /// </summary>
               public const int ToVendor = 8;

               /// <summary>
               /// Property Indexer for FromItem
               /// </summary>
               public const int FromItem = 9;

               /// <summary>
               /// Property Indexer for ToItem
               /// </summary>
               public const int ToItem = 10;

               /// <summary>
               /// Property Indexer for ClearPurchaseStatistics
               /// </summary>
               public const int ClearPurchaseStatistics = 11;

               /// <summary>
               /// Property Indexer for PurchaseStatisticsYear
               /// </summary>
               public const int PurchaseStatisticsYear = 12;

               /// <summary>
               /// Property Indexer for PurchaseStatisticsPeriod
               /// </summary>
               public const int PurchaseStatisticsPeriod = 13;

               /// <summary>
               /// Property Indexer for ClearPrintedPostingJournals
               /// </summary>
               public const int ClearPrintedPostingJournals = 14;

               /// <summary>
               /// Property Indexer for ThroughDayEndNo
               /// </summary>
               public const int ThroughDayEndNo = 15;

               /// <summary>
               /// Property Indexer for Receipts
               /// </summary>
               public const int Receipts = 16;

               /// <summary>
               /// Property Indexer for Invoices
               /// </summary>
               public const int Invoices = 17;

               /// <summary>
               /// Property Indexer for CreditDebitNotes
               /// </summary>
               public const int CreditDebitNotes = 18;

               /// <summary>
               /// Property Indexer for Returns
               /// </summary>
               public const int Returns = 19;

               /// <summary>
               /// Property Indexer for ExpiredRejectedRequisitions
               /// </summary>
               public const int ExpiredRejectedRequisitions = 20;

               /// <summary>
               /// Property Indexer for SuppressMessages
               /// </summary>
               public const int SuppressMessages = 21;

               /// <summary>
               /// Property Indexer for ClearPayablesClearingAudit
               /// </summary>
               public const int ClearPayablesClearingAudit = 22;

               /// <summary>
               /// Property Indexer for PayablesClearingYear
               /// </summary>
               public const int PayablesClearingYear = 23;

               /// <summary>
               /// Property Indexer for PayablesClearingPeriod
               /// </summary>
               public const int PayablesClearingPeriod = 24;

               /// <summary>
               /// Property Indexer for FromAccountSet
               /// </summary>
               public const int FromAccountSet = 25;

               /// <summary>
               /// Property Indexer for ToAccountSet
               /// </summary>
               public const int ToAccountSet = 26;

               /// <summary>
               /// Property Indexer for ClearItemTransactionHistory
               /// </summary>
               public const int ClearItemTransactionHistory = 27;

               /// <summary>
               /// Property Indexer for ThroughYear
               /// </summary>
               public const int ThroughYear = 28;

               /// <summary>
               /// Property Indexer for ThroughPeriod
               /// </summary>
               public const int ThroughPeriod = 29;

               /// <summary>
               /// Property Indexer for ClearCommittedCostsAudit
               /// </summary>
               public const int ClearCommittedCostsAudit = 30;

               /// <summary>
               /// Property Indexer for FromContract
               /// </summary>
               public const int FromContract = 31;

               /// <summary>
               /// Property Indexer for ToContract
               /// </summary>
               public const int ToContract = 32;

               /// <summary>
               /// Property Indexer for FromProject
               /// </summary>
               public const int FromProject = 33;

               /// <summary>
               /// Property Indexer for ToProject
               /// </summary>
               public const int ToProject = 34;

               /// <summary>
               /// Property Indexer for FromCategory
               /// </summary>
               public const int FromCategory = 35;

               /// <summary>
               /// Property Indexer for ToCategory
               /// </summary>
               public const int ToCategory = 36;

          }
          #endregion

     }
}
