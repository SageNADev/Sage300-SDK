// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Process.CreatePurchaseOrders
{
     /// <summary>
     /// Contains list of CreatePOsDetail Constants
     /// </summary>
     public partial class CreatePOsDetail
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0608";

          #region Properties
          /// <summary>
          /// Contains list of CreatePOsDetail Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for HeaderSequence
               /// </summary>
               public const string HeaderSequence = "HEADSEQ";

               /// <summary>
               /// Property for LineSequence
               /// </summary>
               public const string LineSequence = "LINESEQ";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for Command
               /// </summary>
               public const string Command = "PROCESSCMD";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreatePOsDetail Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for HeaderSequence
               /// </summary>
               public const int HeaderSequence = 1;

               /// <summary>
               /// Property Indexer for LineSequence
               /// </summary>
               public const int LineSequence = 2;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 3;

               /// <summary>
               /// Property Indexer for Command
               /// </summary>
               public const int Command = 20;

          }
          #endregion

     }
}
