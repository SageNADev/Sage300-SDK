// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.
// ReSharper disable CheckNamespace

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Process
{
	/// <summary>
	/// Contains list of Mailing Label Constants
	/// </summary>
	public partial class MailingLabel
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string ViewName = "PO0500";

		#region Properties

		/// <summary>
		/// Contains list of Mailing Label Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for Select Item
			/// </summary>
			public const string SelectItem = "SELECT";

			/// <summary>
			/// Property for From Item
			/// </summary>
			public const string FromItem = "TOPPO";

			/// <summary>
			/// Property for To Item
			/// </summary>
			public const string ToItem = "ENDPO";

			/// <summary>
			/// Property for Include Printed
			/// </summary>
			public const string IncludePrinted = "PRINTED";

			/// <summary>
			/// Property for Required Option
			/// </summary>
			public const string RequiredOption = "REQUIRED";

			/// <summary>
			/// Property for Operation
			/// </summary>
			public const string Operation = "FUNCTION";

			/// <summary>
			/// Property for Output File
			/// </summary>
			public const string OutputFile = "FILENAME";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of Mailing Label Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for Select Item
			/// </summary>
			public const int SelectItem = 1;

			/// <summary>
			/// Property Indexer for From Item
			/// </summary>
			public const int FromItem = 2;

			/// <summary>
			/// Property Indexer for To Item
			/// </summary>
			public const int ToItem = 3;

			/// <summary>
			/// Property Indexer for Include Printed
			/// </summary>
			public const int IncludePrinted = 4;

			/// <summary>
			/// Property Indexer for Required Option
			/// </summary>
			public const int RequiredOption = 5;

			/// <summary>
			/// Property Indexer for Operation
			/// </summary>
			public const int Operation = 6;

			/// <summary>
			/// Property Indexer for Output File
			/// </summary>
			public const int OutputFile = 7;

		}

		#endregion

	}
}
