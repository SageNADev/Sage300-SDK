// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Process
// ReSharper restore CheckNamespace
{
     /// <summary>
     /// Contains list of Mark Document Printed Constants
     /// </summary>
     public partial class MarkDocumentPrinted
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string ViewName = "PO0640";

          #region Properties
          /// <summary>
          /// Contains list of Mark Document Printed Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for Document Type
               /// </summary>
               public const string DocumentType = "DOCTYPE";

               /// <summary>
               /// Property for From Requisition Number
               /// </summary>
               public const string FromRequisitionNumber = "FROMRQN";

               /// <summary>
               /// Property for To Requisition Number
               /// </summary>
               public const string ToRequisitionNumber = "TORQN";

               /// <summary>
               /// Property for From Purchase Order Number
               /// </summary>
               public const string FromPurchaseOrderNumber = "FROMPO";

               /// <summary>
               /// Property for To Purchase Order Number
               /// </summary>
               public const string ToPurchaseOrderNumber = "TOPO";

               /// <summary>
               /// Property for From Receipt Number
               /// </summary>
               public const string FromReceiptNumber = "FROMRCP";

               /// <summary>
               /// Property for To Receipt Number
               /// </summary>
               public const string ToReceiptNumber = "TORCP";

               /// <summary>
               /// Property for From Return Number
               /// </summary>
               public const string FromReturnNumber = "FROMRET";

               /// <summary>
               /// Property for To Return Number
               /// </summary>
               public const string ToReturnNumber = "TORET";

               /// <summary>
               /// Property for Reprint Headers
               /// </summary>
               public const string ReprintHeaders = "REPRINTH";

               /// <summary>
               /// Property for Reprint Details
               /// </summary>
               public const string ReprintDetails = "REPRINTD";

               /// <summary>
               /// Property for Reprint Labels
               /// </summary>
               public const string ReprintLabels = "REPRINTL";

               /// <summary>
               /// Property for Requires Labels
               /// </summary>
               public const string RequiresLabels = "REQLABEL";

          }
          #endregion

          #region Properties

          /// <summary>
          /// Contains list of Mark Document Printed Index
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Document Type
               /// </summary>
               public const int DocumentType = 1;

               /// <summary>
               /// Property Indexer for From Requisition Number
               /// </summary>
               public const int FromRequisitionNumber = 2;

               /// <summary>
               /// Property Indexer for To Requisition Number
               /// </summary>
               public const int ToRequisitionNumber = 3;

               /// <summary>
               /// Property Indexer for From Purchase Order Number
               /// </summary>
               public const int FromPurchaseOrderNumber = 4;

               /// <summary>
               /// Property Indexer for To Purchase Order Number
               /// </summary>
               public const int ToPurchaseOrderNumber = 5;

               /// <summary>
               /// Property Indexer for From Receipt Number
               /// </summary>
               public const int FromReceiptNumber = 6;

               /// <summary>
               /// Property Indexer for To Receipt Number
               /// </summary>
               public const int ToReceiptNumber = 7;

               /// <summary>
               /// Property Indexer for From Return Number
               /// </summary>
               public const int FromReturnNumber = 8;

               /// <summary>
               /// Property Indexer for To Return Number
               /// </summary>
               public const int ToReturnNumber = 9;

               /// <summary>
               /// Property Indexer for Reprint Headers
               /// </summary>
               public const int ReprintHeaders = 10;

               /// <summary>
               /// Property Indexer for Reprint Details
               /// </summary>
               public const int ReprintDetails = 11;

               /// <summary>
               /// Property Indexer for Reprint Labels
               /// </summary>
               public const int ReprintLabels = 12;

               /// <summary>
               /// Property Indexer for Requires Labels
               /// </summary>
               public const int RequiresLabels = 13;

          }
          #endregion

     }
}
