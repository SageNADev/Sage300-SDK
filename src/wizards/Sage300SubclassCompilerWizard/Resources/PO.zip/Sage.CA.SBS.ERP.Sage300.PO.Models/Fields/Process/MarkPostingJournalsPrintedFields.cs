// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models.Process
{
    /// <summary>
    /// Contains list of MarkPostingJournalsPrinted Constants
    /// </summary>
    public partial class MarkPostingJournalsPrinted
    {
        #region Constant

        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "PO0340";

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of MarkPostingJournalsPrinted Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for FromDayEndNumber
            /// </summary>
            public const string FromDayEndNumber = "FROMDAYEND";

            /// <summary>
            /// Property for ToDayEndNumber
            /// </summary>
            public const string ToDayEndNumber = "TODAYEND";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "AUDTYPE";

        }

        #endregion

        #region Index

        /// <summary>
        /// Contains list of MarkPostingJournalsPrinted Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for FromDayEndNumber
            /// </summary>
            public const int FromDayEndNumber = 1;

            /// <summary>
            /// Property Indexer for ToDayEndNumber
            /// </summary>
            public const int ToDayEndNumber = 2;

            /// <summary>
            /// Property Indexer for TransactionType
            /// </summary>
            public const int TransactionType = 3;

        }
        #endregion
    }
}
