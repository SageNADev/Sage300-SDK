// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceCostDistribution Constants
    /// </summary>
    public partial class InvoiceCostDistribution
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0415";

        #region Properties
        /// <summary>
        /// Contains list of InvoiceCostDistribution Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for InvoiceSequenceKey
            /// </summary>
            public const string InvoiceSequenceKey = "INVHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "INVSREV";

            /// <summary>
            /// Property for LineSequence
            /// </summary>
            public const string LineSequence = "LSEQ";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for FromPredecessor
            /// </summary>
            public const string FromPredecessor = "FROMPRED";

            /// <summary>
            /// Property for ManualCostDistribution
            /// </summary>
            public const string ManualCostDistribution = "MANDIST";

            /// <summary>
            /// Property for ExtraneousCostDistribution
            /// </summary>
            public const string ExtraneousCostDistribution = "EXTDIST";

            /// <summary>
            /// Property for CostDistribution
            /// </summary>
            public const string CostDistribution = "COSTDIST";

        }
        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoiceCostDistribution Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for LineSequence
            /// </summary>
            public const int LineSequence = 3;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 4;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 5;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 6;

            /// <summary>
            /// Property Indexer for FromPredecessor
            /// </summary>
            public const int FromPredecessor = 7;

            /// <summary>
            /// Property Indexer for ManualCostDistribution
            /// </summary>
            public const int ManualCostDistribution = 101;

            /// <summary>
            /// Property Indexer for ExtraneousCostDistribution
            /// </summary>
            public const int ExtraneousCostDistribution = 102;

            /// <summary>
            /// Property Indexer for CostDistribution
            /// </summary>
            public const int CostDistribution = 103;
        }

        #endregion
    }
}
