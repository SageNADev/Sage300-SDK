// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Contains list of PendingReceiptDetail Constants
	/// </summary>
    public partial class PendingReceiptsInquiryDetail
	{
		/// <summary>
		/// View Name
		/// </summary>
        public const string EntityName = "PO0723";

		#region Properties

		/// <summary>
		/// Contains list of PendingReceiptDetail Field Constants
		/// </summary>
		public class Fields
		{

			/// <summary>
			/// Property for PurchaseOrderSequenceKey
			/// </summary>
			public const string PurchaseOrderSequenceKey = "PORHSEQ";

			/// <summary>
			/// Property for PurchaseOrderLineSequence
			/// </summary>
			public const string PurchaseOrderLineSequence = "PORLSEQ";

			/// <summary>
			/// Property for ReceiptSequenceKey
			/// </summary>
			public const string ReceiptSequenceKey = "RCPHSEQ";

			/// <summary>
			/// Property for ReceiptLineSequence
			/// </summary>
			public const string ReceiptLineSequence = "RCPLSEQ";

			/// <summary>
			/// Property for ReceiptNumber
			/// </summary>
			public const string ReceiptNumber = "RCPNUMBER";

			/// <summary>
			/// Property for Contract
			/// </summary>
			public const string Contract = "CONTRACT";

			/// <summary>
			/// Property for Project
			/// </summary>
			public const string Project = "PROJECT";

			/// <summary>
			/// Property for Category
			/// </summary>
			public const string Category = "CCATEGORY";

			/// <summary>
			/// Property for QuantityOrdered
			/// </summary>
			public const string QuantityOrdered = "OQORDERED";

			/// <summary>
			/// Property for POUnitOfMeasure
			/// </summary>
			public const string POUnitOfMeasure = "POUOM";

			/// <summary>
			/// Property for HasJob
			/// </summary>
			public const string HasJob = "HASJOB";

			/// <summary>
			/// Property for ExpectedArrivalDate
			/// </summary>
			public const string ExpectedArrivalDate = "EXPARRIVAL";

			/// <summary>
			/// Property for DateReceived
			/// </summary>
			public const string DateReceived = "DATERCVD";

			/// <summary>
			/// Property for DaysLate
			/// </summary>
			public const string DaysLate = "DAYSLATE";

			/// <summary>
			/// Property for QuantityReceived
			/// </summary>
			public const string QuantityReceived = "QTYRCVD";

			/// <summary>
			/// Property for Location
			/// </summary>
			public const string Location = "LOCATION";

			/// <summary>
			/// Property for IsComplete
			/// </summary>
			public const string IsComplete = "ISCOMPLETE";

			/// <summary>
			/// Property for ReceiptUnits
			/// </summary>
			public const string ReceiptUnits = "RCPUNIT";

		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of PendingReceiptDetail Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for PurchaseOrderSequenceKey
			/// </summary>
			public const int PurchaseOrderSequenceKey = 1;

			/// <summary>
			/// Property Indexer for PurchaseOrderLineSequence
			/// </summary>
			public const int PurchaseOrderLineSequence = 2;

			/// <summary>
			/// Property Indexer for ReceiptSequenceKey
			/// </summary>
			public const int ReceiptSequenceKey = 3;

			/// <summary>
			/// Property Indexer for ReceiptLineSequence
			/// </summary>
			public const int ReceiptLineSequence = 4;

			/// <summary>
			/// Property Indexer for ReceiptNumber
			/// </summary>
			public const int ReceiptNumber = 5;

			/// <summary>
			/// Property Indexer for Contract
			/// </summary>
			public const int Contract = 6;

			/// <summary>
			/// Property Indexer for Project
			/// </summary>
			public const int Project = 7;

			/// <summary>
			/// Property Indexer for Category
			/// </summary>
			public const int Category = 8;

			/// <summary>
			/// Property Indexer for QuantityOrdered
			/// </summary>
			public const int QuantityOrdered = 9;

			/// <summary>
			/// Property Indexer for POUnitOfMeasure
			/// </summary>
			public const int POUnitOfMeasure = 10;

			/// <summary>
			/// Property Indexer for HasJob
			/// </summary>
			public const int HasJob = 11;

			/// <summary>
			/// Property Indexer for ExpectedArrivalDate
			/// </summary>
			public const int ExpectedArrivalDate = 12;

			/// <summary>
			/// Property Indexer for DateReceived
			/// </summary>
			public const int DateReceived = 13;

			/// <summary>
			/// Property Indexer for DaysLate
			/// </summary>
			public const int DaysLate = 14;

			/// <summary>
			/// Property Indexer for QuantityReceived
			/// </summary>
			public const int QuantityReceived = 15;

			/// <summary>
			/// Property Indexer for Location
			/// </summary>
			public const int Location = 16;

			/// <summary>
			/// Property Indexer for IsComplete
			/// </summary>
			public const int IsComplete = 17;

			/// <summary>
			/// Property Indexer for ReceiptUnits
			/// </summary>
			public const int ReceiptUnits = 18;

		}

		#endregion

	}
}
