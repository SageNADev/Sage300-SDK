// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceFunction Constants
    /// </summary>
    public partial class InvoiceFunction
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0419";

        #region Properties

        /// <summary>
        /// Contains list of InvoiceFunction Constants
        /// </summary>
        public class Fields : BaseFields
        {
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoiceFunction Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for SequenceToRetrieve
            /// </summary>
            public const int SequenceToRetrieve = 2;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 3;

            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 4;

            /// <summary>
            /// Property Indexer for ReturnNumber
            /// </summary>
            public const int ReturnNumber = 5;

            /// <summary>
            /// Property Indexer for NewTermsCodeEntered
            /// </summary>
            public const int NewTermsCodeEntered = 6;

            /// <summary>
            /// Property Indexer for ScheduleCalculationMethod
            /// </summary>
            public const int ScheduleCalculationMethod = 7;

            /// <summary>
            /// Property Indexer for PredecessorTimestamp
            /// </summary>
            public const int PredecessorTimestamp = 8;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 9;
        }

        #endregion
    }
}
