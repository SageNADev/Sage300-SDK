// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceOptionalField Constants
    /// </summary>
    public partial class InvoiceOptionalField
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0423";

        #region Properties

        /// <summary>
        /// Contains list of InvoiceOptionalField Constants
        /// </summary>
        public class Fields : BaseFields { }

        #endregion

        #region Properties
        /// <summary>
        /// Contains list of InvoiceOptionalField Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for OptionalField
            /// </summary>
            public const int OptionalField = 2;

            /// <summary>
            /// Property Indexer for Value
            /// </summary>
            public const int Value = 3;

            /// <summary>
            /// Property Indexer for Type
            /// </summary>
            public const int Type = 4;

            /// <summary>
            /// Property Indexer for Length
            /// </summary>
            public const int Length = 5;

            /// <summary>
            /// Property Indexer for Decimals
            /// </summary>
            public const int Decimals = 6;

            /// <summary>
            /// Property Indexer for AllowBlank
            /// </summary>
            public const int AllowBlank = 7;

            /// <summary>
            /// Property Indexer for Validate
            /// </summary>
            public const int Validate = 8;

            /// <summary>
            /// Property Indexer for ValueSet
            /// </summary>
            public const int ValueSet = 9;

            /// <summary>
            /// Property Indexer for TypedValueFieldIndex
            /// </summary>
            public const int TypedValueFieldIndex = 20;

            /// <summary>
            /// Property Indexer for TextValue
            /// </summary>
            public const int TextValue = 21;

            /// <summary>
            /// Property Indexer for AmountValue
            /// </summary>
            public const int AmountValue = 22;

            /// <summary>
            /// Property Indexer for NumberValue
            /// </summary>
            public const int NumberValue = 23;

            /// <summary>
            /// Property Indexer for IntegerValue
            /// </summary>
            public const int IntegerValue = 24;

            /// <summary>
            /// Property Indexer for YesNoValue
            /// </summary>
            public const int YesOrNoValue = 25;

            /// <summary>
            /// Property Indexer for DateValue
            /// </summary>
            public const int DateValue = 26;

            /// <summary>
            /// Property Indexer for TimeValue
            /// </summary>
            public const int TimeValue = 27;

            /// <summary>
            /// Property Indexer for OptionalFieldDescription
            /// </summary>
            public const int OptionalFieldDescription = 28;

            /// <summary>
            /// Property Indexer for DefaultValueDescription
            /// </summary>
            public const int DefaultValueDescription = 29;
        }

        #endregion
    }
}
