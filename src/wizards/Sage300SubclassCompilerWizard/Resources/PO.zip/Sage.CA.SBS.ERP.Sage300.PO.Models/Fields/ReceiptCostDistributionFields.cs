// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptCostDistribution Constants
    /// </summary>
    public partial class ReceiptCostDistribution
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0696";
        public const string ImportEntityName = "PO0461";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"AMOUNT", "Amount"},
					{"BILLRATE", "BillingRate"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"MANDIST", "ManualCostDistribution"},
					{"EXTDIST", "ExtraneousCostDistribution"},
					{"COSTDIST", "CostDistribution"}
				};
            }
        }

        #endregion

        #region Fields Properties

        /// <summary>
        /// Contains list of ReceiptCostDistribution Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for Vendor
            /// </summary>
            public const string Vendor = "VDCODE";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "RCPSREV";

            /// <summary>
            /// Property for LineSequence
            /// </summary>
            public const string LineSequence = "LSEQ";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for ManualCostDistribution
            /// </summary>
            public const string ManualCostDistribution = "MANDIST";

            /// <summary>
            /// Property for ExtraneousCostDistribution
            /// </summary>
            public const string ExtraneousCostDistribution = "EXTDIST";

            /// <summary>
            /// Property for CostDistribution
            /// </summary>
            public const string CostDistribution = "COSTDIST";
        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of ReceiptCostDistribution Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for Vendor
            /// </summary>
            public const int Vendor = 2;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 3;

            /// <summary>
            /// Property Indexer for LineSequence
            /// </summary>
            public const int LineSequence = 4;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 5;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 6;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 7;

            /// <summary>
            /// Property Indexer for ManualCostDistribution
            /// </summary>
            public const int ManualCostDistribution = 101;

            /// <summary>
            /// Property Indexer for ExtraneousCostDistribution
            /// </summary>
            public const int ExtraneousCostDistribution = 102;

            /// <summary>
            /// Property Indexer for CostDistribution
            /// </summary>
            public const int CostDistribution = 103;
        }

        #endregion
    }
}