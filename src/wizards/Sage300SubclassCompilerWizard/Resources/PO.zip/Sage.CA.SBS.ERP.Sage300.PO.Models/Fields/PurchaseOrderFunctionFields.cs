// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseOrderFunction Constants
    /// </summary>
    public partial class PurchaseOrderFunction
    {
        #region Public Constant

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0619";

        #endregion

        #region Fields Properties
        /// <summary>
        /// Contains list of PurchaseOrderFunction Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for SequenceToRetrieve
            /// </summary>
            public const string SequenceToRetrieve = "LOADSEQ";

            /// <summary>
            /// Property for RequisitionNumber
            /// </summary>
            public const string RequisitionNumber = "LOADRQNNUM";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "LOADPORNUM";

            /// <summary>
            /// Property for TemplateCode
            /// </summary>
            public const string TemplateCode = "TEMPLATE";

            /// <summary>
            /// Property for Function
            /// </summary>
            public const string Function = "FUNCTION";

            /// <summary>
            /// Property for UseBlankVendors
            /// </summary>
            public const string UseBlankVendors = "BLNKVDCODE";

            /// <summary>
            /// Property for UseICVendor
            /// </summary>
            public const string UseICVendor = "USEVDTYPE";

            /// <summary>
            /// Property for HeaderSequence
            /// </summary>
            public const string HeaderSequence = "HEADSEQ";

            /// <summary>
            /// Property for LineSequence
            /// </summary>
            public const string LineSequence = "LINESEQ";

        }

        #endregion

        #region Index Properties
        /// <summary>
        /// Contains list of PurchaseOrderFunction Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 1;

            /// <summary>
            /// Property Indexer for SequenceToRetrieve
            /// </summary>
            public const int SequenceToRetrieve = 2;

            /// <summary>
            /// Property Indexer for RequisitionNumber
            /// </summary>
            public const int RequisitionNumber = 3;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 4;

            /// <summary>
            /// Property Indexer for TemplateCode
            /// </summary>
            public const int TemplateCode = 5;

            /// <summary>
            /// Property Indexer for Function
            /// </summary>
            public const int Function = 6;

            /// <summary>
            /// Property Indexer for UseBlankVendors
            /// </summary>
            public const int UseBlankVendors = 7;

            /// <summary>
            /// Property Indexer for UseICVendor
            /// </summary>
            public const int UseICVendor = 8;

            /// <summary>
            /// Property Indexer for HeaderSequence
            /// </summary>
            public const int HeaderSequence = 9;

            /// <summary>
            /// Property Indexer for LineSequence
            /// </summary>
            public const int LineSequence = 10;

        }
        #endregion

    }
}
