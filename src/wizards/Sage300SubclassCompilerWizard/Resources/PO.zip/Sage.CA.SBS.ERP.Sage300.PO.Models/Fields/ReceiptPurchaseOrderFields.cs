// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of ReceiptPurchaseOrder Constants
    /// </summary>
    public partial class ReceiptPurchaseOrder
    {
        #region Entity

        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "PO0705";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"PORHSEQ", "PurchaseOrderSequenceKey"},
					{"PONUMBER", "PurchaseOrderNumber"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"POR", "Line"}
				};
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ReceiptPurchaseOrder Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for ReceiptSequenceKey
            /// </summary>
            public const string ReceiptSequenceKey = "RCPHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "RCPRREV";

            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for PurchaseOrderNumber
            /// </summary>
            public const string PurchaseOrderNumber = "PONUMBER";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for Line
            /// </summary>
            public const string Line = "POR";
        }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of ReceiptPurchaseOrder Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 3;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 4;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 5;

            /// <summary>
            /// Property Indexer for Line
            /// </summary>
            public const int Line = 21;
        }

        #endregion

    }
}