// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of CRDRNotePostingCostDists Constants
    /// </summary>
    public partial class CrdrNotePostingCostDists
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0327";

        #region Properties
        /// <summary>
        /// Contains list of CRDRNotePostingCostDists Constants
        /// </summary>
        public class Fields
        {

            /// <summary>
            /// Property for HeaderSequence
            /// </summary>
            public const string HeaderSequence = "CRNISEQ";

            /// <summary>
            /// Property for CreditDebitNoteSequenceKey
            /// </summary>
            public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

            /// <summary>
            /// Property for CreditDebitNoteCostSequence
            /// </summary>
            public const string CreditDebitNoteCostSequence = "CRNSSEQ";

            /// <summary>
            /// Property for LineSequence
            /// </summary>
            public const string LineSequence = "LSEQ";

            /// <summary>
            /// Property for OperationToPost
            /// </summary>
            public const string OperationToPost = "OPERATION";

            /// <summary>
            /// Property for Amount
            /// </summary>
            public const string Amount = "AMOUNT";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

        }
        #endregion

        #region Properties
        /// <summary>
        /// Contains list of CRDRNotePostingCostDists Constants
        /// </summary>
        public class Index
        {

            /// <summary>
            /// Property Indexer for HeaderSequence
            /// </summary>
            public const int HeaderSequence = 1;

            /// <summary>
            /// Property Indexer for CreditDebitNoteSequenceKey
            /// </summary>
            public const int CreditDebitNoteSequenceKey = 2;

            /// <summary>
            /// Property Indexer for CreditDebitNoteCostSequence
            /// </summary>
            public const int CreditDebitNoteCostSequence = 3;

            /// <summary>
            /// Property Indexer for LineSequence
            /// </summary>
            public const int LineSequence = 4;

            /// <summary>
            /// Property Indexer for OperationToPost
            /// </summary>
            public const int OperationToPost = 5;

            /// <summary>
            /// Property Indexer for Amount
            /// </summary>
            public const int Amount = 6;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 7;

        }
        #endregion

    }
}
