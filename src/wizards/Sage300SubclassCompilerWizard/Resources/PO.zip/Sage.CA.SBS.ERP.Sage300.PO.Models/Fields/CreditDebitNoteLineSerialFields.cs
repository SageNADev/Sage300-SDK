// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of CreditDebitNoteLineSerial Constants
     /// </summary>
     public partial class CreditDebitNoteLineSerial
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0820";

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteLineSerial Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for CreditDebitNoteSequenceKey
               /// </summary>
               public const string CreditDebitNoteSequenceKey = "CRNHSEQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "CRNLREV";

               /// <summary>
               /// Property for SerialNumber
               /// </summary>
               public const string SerialNumber = "SERIALNUMF";

               /// <summary>
               /// Property for CreditDebitNoteLineSequence
               /// </summary>
               public const string CreditDebitNoteLineSequence = "CRNLSEQ";

               /// <summary>
               /// Property for SerialCount
               /// </summary>
               public const string SerialCount = "SCOUNT";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CreditDebitNoteLineSerial Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for CreditDebitNoteSequenceKey
               /// </summary>
               public const int CreditDebitNoteSequenceKey = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for SerialNumber
               /// </summary>
               public const int SerialNumber = 3;

               /// <summary>
               /// Property Indexer for CreditDebitNoteLineSequence
               /// </summary>
               public const int CreditDebitNoteLineSequence = 4;

               /// <summary>
               /// Property Indexer for SerialCount
               /// </summary>
               public const int SerialCount = 50;

          }
          #endregion

     }
}
