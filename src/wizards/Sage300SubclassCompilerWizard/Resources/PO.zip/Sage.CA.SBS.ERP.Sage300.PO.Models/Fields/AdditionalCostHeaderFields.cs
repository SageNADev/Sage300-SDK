// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.
// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of Additional Cost Header Constants
     /// </summary>
     public partial class AdditionalCostHeader
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0300";

          #region Field Properties
          /// <summary>
          /// Contains list of Additional Cost Header Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for Additional Cost
               /// </summary>
               public const string AdditionalCost = "ADDCOST";

               /// <summary>
               /// Property for Description
               /// </summary>
               public const string Description = "DESC";

               /// <summary>
               /// Property for Expense Account
               /// </summary>
               public const string ExpenseAccount = "GLEXPACCT";

               /// <summary>
               /// Property for Amount
               /// </summary>
               public const string Amount = "AMOUNT";

               /// <summary>
               /// Property for Date Last Maintained
               /// </summary>
               public const string DateLastMaintained = "DATELASTMN";

               /// <summary>
               /// Property for Status
               /// </summary>
               public const string Status = "INACTIVE";

               /// <summary>
               /// Property for Date Inactive
               /// </summary>
               public const string DateInactive = "DATEINACTV";

               /// <summary>
               /// Property for Vendor Exists
               /// </summary>
               public const string VendorExists = "VDEXISTS";

               /// <summary>
               /// Property for Vendor
               /// </summary>
               public const string Vendor = "VDCODE";

               /// <summary>
               /// Property for Currency
               /// </summary>
               public const string Currency = "CURRENCY";

               /// <summary>
               /// Property for Proration Method
               /// </summary>
               public const string ProrationMethod = "PRORMETHOD";

               /// <summary>
               /// Property for Reproration Method
               /// </summary>
               public const string ReprorationMethod = "REPRORATE";

               /// <summary>
               /// Property for Return Account
               /// </summary>
               public const string ReturnAccount = "GLRETACCT";

               /// <summary>
               /// Property for Lines
               /// </summary>
               public const string Lines = "LINES";

               /// <summary>
               /// Property for Optional Fields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for Expense Account Description
               /// </summary>
               public const string ExpenseAccountDescription = "GLEXPACCTD";

               /// <summary>
               /// Property for Return Expense Account Description
               /// </summary>
               public const string ReturnExpenseAccountDesc = "GLRETACCTD";

               /// <summary>
               /// Property for Name
               /// </summary>
               public const string Name = "VDNAME";

               /// <summary>
               /// Property for Vendor On Hold
               /// </summary>
               public const string VendorOnHold = "VDONHOLD";

               /// <summary>
               /// Property for Currency Description
               /// </summary>
               public const string CurrencyDescription = "CURRENCYD";

               /// <summary>
               /// Property for Command
               /// </summary>
               public const string Command = "PROCESSCMD";

          }
          #endregion

          #region Index Properties
          /// <summary>
          /// Contains list of Additional Cost Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for Additional Cost
               /// </summary>
              public const int AdditionalCost = 1;

               /// <summary>
               /// Property Indexer for Description
               /// </summary>
               public const int Description = 2;

               /// <summary>
               /// Property Indexer for Expense Account
               /// </summary>
               public const int ExpenseAccount = 3;

               /// <summary>
               /// Property Indexer for Amount
               /// </summary>
               public const int Amount = 4;

               /// <summary>
               /// Property Indexer for Date Last Maintained
               /// </summary>
               public const int DateLastMaintained = 5;

               /// <summary>
               /// Property Indexer for Status
               /// </summary>
               public const int Status = 6;

               /// <summary>
               /// Property Indexer for Date Inactive
               /// </summary>
               public const int DateInactive = 7;

               /// <summary>
               /// Property Indexer for Vendor Exists
               /// </summary>
               public const int VendorExists = 8;

               /// <summary>
               /// Property Indexer for Vendor
               /// </summary>
               public const int Vendor = 9;

               /// <summary>
               /// Property Indexer for Currency
               /// </summary>
               public const int Currency = 10;

               /// <summary>
               /// Property Indexer for Proration Method
               /// </summary>
               public const int ProrationMethod = 11;

               /// <summary>
               /// Property Indexer for Reproration Method
               /// </summary>
               public const int ReprorationMethod = 12;

               /// <summary>
               /// Property Indexer for Return Account
               /// </summary>
               public const int ReturnAccount = 13;

               /// <summary>
               /// Property Indexer for Lines
               /// </summary>
               public const int Lines = 14;

               /// <summary>
               /// Property Indexer for Optional Fields
               /// </summary>
               public const int OptionalFields = 15;

               /// <summary>
               /// Property Indexer for Expense Account Description
               /// </summary>
               public const int ExpenseAccountDescription = 26;

               /// <summary>
               /// Property Indexer for Return Expense Account Description
               /// </summary>
               public const int ReturnExpenseAccountDesc = 27;

               /// <summary>
               /// Property Indexer for Name
               /// </summary>
               public const int Name = 28;

               /// <summary>
               /// Property Indexer for Vendor On Hold
               /// </summary>
               public const int VendorOnHold = 29;

               /// <summary>
               /// Property Indexer for Currency Description
               /// </summary>
               public const int CurrencyDescription = 30;

               /// <summary>
               /// Property Indexer for Command
               /// </summary>
               public const int Command = 31;
          }
          #endregion
     }
}
