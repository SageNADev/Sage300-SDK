// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

#region Namespace

using System.Collections.Generic;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of PurchaseOrderLine Fields,Index and  DynamicAttributes
    /// </summary>
    public partial class PurchaseOrderLine
    {
        #region Public Constant

        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0630";

        #endregion

        #region DynamicAttributes

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
                    {"OEONUMBER", "OrderNumber"},
                    {"CONTRACT", "Contract" },
                    {"PROJECT", "Project" },
                    {"CCATEGORY", "Category" },
                    {"COSTCLASS", "CostClass" },
                    {"ITEMNO", "ItemNumber"},
					{"LOCATION", "Location"},
					{"ITEMDESC", "ItemDescription"},
					{"EXPARRIVAL", "ExpectedArrivalDate"},
					{"VENDITEMNO", "VendorItemNumber"},
					{"HASCOMMENT", "CommentsInstructions"},
					{"ORDERUNIT", "UnitOfMeasure"},
					{"OQORDERED", "QuantityOrdered"},
					{"OQRECEIVED", "QuantityReceived"},
					{"OQOUTSTAND", "QuantityOutstanding"},
					{"UNITWEIGHT", "UnitWeight"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"UNITCOST", "UnitCost"},
					{"EXTENDED", "ExtendedCost"},
                    {"TXBASEALLO", "NetOfTax"},
					{"TXINCLUDED", "TaxIncluded"},
					{"TXALLOAMT", "AllocatedTax"},
					{"GLACEXPENS", "ExpenseAccount"},
					{"HASDROPSHI", "DropShip"},
                    {"DROPTYPE", "DropShipType"},
                    {"GLNONSTKCR", "NonStockClearingAccount"},
					{"MANITEMNO", "ManufacturersItemNumber"},
					{"DISCPCT", "DiscountPercentage"},
					{"DISCOUNT", "DiscountAmount"},
					{"VALUES", "OptionalFields"},
                    {"BILLTYPE", "BillingType"},
                    {"BILLRATE", "BillingRate"},
                    {"EXTBILLSR", "ExtendedBillingAmount"},
                    {"BILLCURR", "BillingCurrency"},
                    {"ARITEMNO", "ARItemNumber"},
                    {"ARUNIT", "ARUnitOfMeasure"},
                    {"ISCOMPLETE", "Completed"},
					{"NETXTENDED", "NetExtendedCost"},
					{"WEIGHTUNIT", "WeightUnitOfMeasure"},
				};
            }
        }

        #endregion

        #region Fields Properties
        /// <summary>
        /// Contains list of PurchaseOrderLine Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for PurchaseOrderSequenceKey
            /// </summary>
            public const string PurchaseOrderSequenceKey = "PORHSEQ";

            /// <summary>
            /// Property for LineNumber
            /// </summary>
            public const string LineNumber = "PORLREV";

            /// <summary>
            /// Property for PurchaseOrderLineSequence
            /// </summary>
            public const string PurchaseOrderLineSequence = "PORLSEQ";

            /// <summary>
            /// Property for PurchaseOrderCommentSequence
            /// </summary>
            public const string PurchaseOrderCommentSequence = "PORCSEQ";

            /// <summary>
            /// Property for StoredInDatabaseTable
            /// </summary>
            public const string StoredInDatabaseTable = "INDBTABLE";

            /// <summary>
            /// Property for ConsolidatedToline
            /// </summary>
            public const string ConsolidatedToline = "CONSOLSEQ";

            /// <summary>
            /// Property for RequisitionSequenceKey
            /// </summary>
            public const string RequisitionSequenceKey = "RQNHSEQ";

            /// <summary>
            /// Property for RequisitionLineSequence
            /// </summary>
            public const string RequisitionLineSequence = "RQNLSEQ";

            /// <summary>
            /// Property for OrderNumber
            /// </summary>
            public const string OrderNumber = "OEONUMBER";

            /// <summary>
            /// Property for PostedToIC
            /// </summary>
            public const string PostedToIC = "POSTEDTOIC";

            /// <summary>
            /// Property for ToPostToIC
            /// </summary>
            public const string ToPostToIC = "TOPOSTTOIC";

            /// <summary>
            /// Property for PrintStatus
            /// </summary>
            public const string PrintStatus = "STPRINT";

            /// <summary>
            /// Property for CompletionStatus
            /// </summary>
            public const string CompletionStatus = "COMPLETION";

            /// <summary>
            /// Property for DateCompleted
            /// </summary>
            public const string DateCompleted = "DTCOMPLETE";

            /// <summary>
            /// Property for ItemExists
            /// </summary>
            public const string ItemExists = "ITEMEXISTS";

            /// <summary>
            /// Property for ItemNumber
            /// </summary>
            public const string ItemNumber = "ITEMNO";

            /// <summary>
            /// Property for Location
            /// </summary>
            public const string Location = "LOCATION";

            /// <summary>
            /// Property for ItemDescription
            /// </summary>
            public const string ItemDescription = "ITEMDESC";

            /// <summary>
            /// Property for ExpectedArrivalDate
            /// </summary>
            public const string ExpectedArrivalDate = "EXPARRIVAL";

            /// <summary>
            /// Property for VendorItemNumber
            /// </summary>
            public const string VendorItemNumber = "VENDITEMNO";

            /// <summary>
            /// Property for CommentsInstructions
            /// </summary>
            public const string CommentsInstructions = "HASCOMMENT";

            /// <summary>
            /// Property for UnitOfMeasure
            /// </summary>
            public const string UnitOfMeasure = "ORDERUNIT";

            /// <summary>
            /// Property for OrderUnitConversion
            /// </summary>
            public const string OrderUnitConversion = "ORDERCONV";

            /// <summary>
            /// Property for OrderUnitDecimals
            /// </summary>
            public const string OrderUnitDecimals = "ORDERDECML";

            /// <summary>
            /// Property for StockUnitDecimals
            /// </summary>
            public const string StockUnitDecimals = "STOCKDECML";

            /// <summary>
            /// Property for QuantityOrdered
            /// </summary>
            public const string QuantityOrdered = "OQORDERED";

            /// <summary>
            /// Property for QuantityReceived
            /// </summary>
            public const string QuantityReceived = "OQRECEIVED";

            /// <summary>
            /// Property for QuantityCanceled
            /// </summary>
            public const string QuantityCanceled = "OQCANCELED";

            /// <summary>
            /// Property for ReceivedExtra
            /// </summary>
            public const string ReceivedExtra = "OQRCPEXTRA";

            /// <summary>
            /// Property for QuantityOutstanding
            /// </summary>
            public const string QuantityOutstanding = "OQOUTSTAND";

            /// <summary>
            /// Property for StockingQuantityOrdered
            /// </summary>
            public const string StockingQuantityOrdered = "SQORDERED";

            /// <summary>
            /// Property for StockingQuantityReceived
            /// </summary>
            public const string StockingQuantityReceived = "SQRECEIVED";

            /// <summary>
            /// Property for StockingQuantityCanceled
            /// </summary>
            public const string StockingQuantityCanceled = "SQCANCELED";

            /// <summary>
            /// Property for StockingQuantityReceivedExtra
            /// </summary>
            public const string StockingQuantityReceivedExtra = "SQRCPEXTRA";

            /// <summary>
            /// Property for StockingQuantitySettled
            /// </summary>
            public const string StockingQuantitySettled = "SQSETTLED";

            /// <summary>
            /// Property for StockingQuantityOutstanding
            /// </summary>
            public const string StockingQuantityOutstanding = "SQOUTSTAND";

            /// <summary>
            /// Property for UnitWeight
            /// </summary>
            public const string UnitWeight = "UNITWEIGHT";

            /// <summary>
            /// Property for ExtendedWeight
            /// </summary>
            public const string ExtendedWeight = "EXTWEIGHT";

            /// <summary>
            /// Property for DaysQuantityReceived
            /// </summary>
            public const string DaysQuantityReceived = "OQRCPDAYS";

            /// <summary>
            /// Property for ExtendedReceivedAmount
            /// </summary>
            public const string ExtendedReceivedAmount = "EXTRECEIVE";

            /// <summary>
            /// Property for ExtendedCanceledAmount
            /// </summary>
            public const string ExtendedCanceledAmount = "EXTCANCEL";

            /// <summary>
            /// Property for AmountReceivedToDate
            /// </summary>
            public const string AmountReceivedToDate = "SRRECEIVED";

            /// <summary>
            /// Property for UnitCost
            /// </summary>
            public const string UnitCost = "UNITCOST";

            /// <summary>
            /// Property for ExtendedCost
            /// </summary>
            public const string ExtendedCost = "EXTENDED";

            /// <summary>
            /// Property for TaxBase1
            /// </summary>
            public const string TaxBase1 = "TAXBASE1";

            /// <summary>
            /// Property for TaxBase2
            /// </summary>
            public const string TaxBase2 = "TAXBASE2";

            /// <summary>
            /// Property for TaxBase3
            /// </summary>
            public const string TaxBase3 = "TAXBASE3";

            /// <summary>
            /// Property for TaxBase4
            /// </summary>
            public const string TaxBase4 = "TAXBASE4";

            /// <summary>
            /// Property for TaxBase5
            /// </summary>
            public const string TaxBase5 = "TAXBASE5";

            /// <summary>
            /// Property for TaxClass1
            /// </summary>
            public const string TaxClass1 = "TAXCLASS1";

            /// <summary>
            /// Property for TaxClass2
            /// </summary>
            public const string TaxClass2 = "TAXCLASS2";

            /// <summary>
            /// Property for TaxClass3
            /// </summary>
            public const string TaxClass3 = "TAXCLASS3";

            /// <summary>
            /// Property for TaxClass4
            /// </summary>
            public const string TaxClass4 = "TAXCLASS4";

            /// <summary>
            /// Property for TaxClass5
            /// </summary>
            public const string TaxClass5 = "TAXCLASS5";

            /// <summary>
            /// Property for TaxRate1
            /// </summary>
            public const string TaxRate1 = "TAXRATE1";

            /// <summary>
            /// Property for TaxRate2
            /// </summary>
            public const string TaxRate2 = "TAXRATE2";

            /// <summary>
            /// Property for TaxRate3
            /// </summary>
            public const string TaxRate3 = "TAXRATE3";

            /// <summary>
            /// Property for TaxRate4
            /// </summary>
            public const string TaxRate4 = "TAXRATE4";

            /// <summary>
            /// Property for TaxRate5
            /// </summary>
            public const string TaxRate5 = "TAXRATE5";

            /// <summary>
            /// Property for TaxIncludable1
            /// </summary>
            public const string TaxIncludable1 = "TAXINCLUD1";

            /// <summary>
            /// Property for TaxIncludable2
            /// </summary>
            public const string TaxIncludable2 = "TAXINCLUD2";

            /// <summary>
            /// Property for TaxIncludable3
            /// </summary>
            public const string TaxIncludable3 = "TAXINCLUD3";

            /// <summary>
            /// Property for TaxIncludable4
            /// </summary>
            public const string TaxIncludable4 = "TAXINCLUD4";

            /// <summary>
            /// Property for TaxIncludable5
            /// </summary>
            public const string TaxIncludable5 = "TAXINCLUD5";

            /// <summary>
            /// Property for TaxAmount1
            /// </summary>
            public const string TaxAmount1 = "TAXAMOUNT1";

            /// <summary>
            /// Property for TaxAmount2
            /// </summary>
            public const string TaxAmount2 = "TAXAMOUNT2";

            /// <summary>
            /// Property for TaxAmount3
            /// </summary>
            public const string TaxAmount3 = "TAXAMOUNT3";

            /// <summary>
            /// Property for TaxAmount4
            /// </summary>
            public const string TaxAmount4 = "TAXAMOUNT4";

            /// <summary>
            /// Property for TaxAmount5
            /// </summary>
            public const string TaxAmount5 = "TAXAMOUNT5";

            /// <summary>
            /// Property for TaxAllocatedAmount1
            /// </summary>
            public const string TaxAllocatedAmount1 = "TXALLOAMT1";

            /// <summary>
            /// Property for TaxAllocatedAmount2
            /// </summary>
            public const string TaxAllocatedAmount2 = "TXALLOAMT2";

            /// <summary>
            /// Property for TaxAllocatedAmount3
            /// </summary>
            public const string TaxAllocatedAmount3 = "TXALLOAMT3";

            /// <summary>
            /// Property for TaxAllocatedAmount4
            /// </summary>
            public const string TaxAllocatedAmount4 = "TXALLOAMT4";

            /// <summary>
            /// Property for TaxAllocatedAmount5
            /// </summary>
            public const string TaxAllocatedAmount5 = "TXALLOAMT5";

            /// <summary>
            /// Property for TaxRecoverableAmount1
            /// </summary>
            public const string TaxRecoverableAmount1 = "TXRECVAMT1";

            /// <summary>
            /// Property for TaxRecoverableAmount2
            /// </summary>
            public const string TaxRecoverableAmount2 = "TXRECVAMT2";

            /// <summary>
            /// Property for TaxRecoverableAmount3
            /// </summary>
            public const string TaxRecoverableAmount3 = "TXRECVAMT3";

            /// <summary>
            /// Property for TaxRecoverableAmount4
            /// </summary>
            public const string TaxRecoverableAmount4 = "TXRECVAMT4";

            /// <summary>
            /// Property for TaxRecoverableAmount5
            /// </summary>
            public const string TaxRecoverableAmount5 = "TXRECVAMT5";

            /// <summary>
            /// Property for TaxExpenseAmount1
            /// </summary>
            public const string TaxExpenseAmount1 = "TXEXPSAMT1";

            /// <summary>
            /// Property for TaxExpenseAmount2
            /// </summary>
            public const string TaxExpenseAmount2 = "TXEXPSAMT2";

            /// <summary>
            /// Property for TaxExpenseAmount3
            /// </summary>
            public const string TaxExpenseAmount3 = "TXEXPSAMT3";

            /// <summary>
            /// Property for TaxExpenseAmount4
            /// </summary>
            public const string TaxExpenseAmount4 = "TXEXPSAMT4";

            /// <summary>
            /// Property for TaxExpenseAmount5
            /// </summary>
            public const string TaxExpenseAmount5 = "TXEXPSAMT5";

            /// <summary>
            /// Property for NetOfTax
            /// </summary>
            public const string NetOfTax = "TXBASEALLO";

            /// <summary>
            /// Property for TaxIncluded
            /// </summary>
            public const string TaxIncluded = "TXINCLUDED";

            /// <summary>
            /// Property for TaxExcluded
            /// </summary>
            public const string TaxExcluded = "TXEXCLUDED";

            /// <summary>
            /// Property for TotalTax
            /// </summary>
            public const string TotalTax = "TAXAMOUNT";

            /// <summary>
            /// Property for RecoverableTax
            /// </summary>
            public const string RecoverableTax = "TXRECVAMT";

            /// <summary>
            /// Property for ExpensedTax
            /// </summary>
            public const string ExpensedTax = "TXEXPSAMT";

            /// <summary>
            /// Property for AllocatedTax
            /// </summary>
            public const string AllocatedTax = "TXALLOAMT";

            /// <summary>
            /// Property for RcpExtAmt
            /// </summary>
            public const string RcpExtAmt = "FCEXTENDED";

            /// <summary>
            /// Property for ExpenseAccount
            /// </summary>
            public const string ExpenseAccount = "GLACEXPENS";

            /// <summary>
            /// Property for DropShip
            /// </summary>
            public const string DropShip = "HASDROPSHI";

            /// <summary>
            /// Property for DropShipType
            /// </summary>
            public const string DropShipType = "DROPTYPE";

            /// <summary>
            /// Property for DropShipCustomer
            /// </summary>
            public const string DropShipCustomer = "IDCUST";

            /// <summary>
            /// Property for CustomerShipToAddress
            /// </summary>
            public const string CustomerShipToAddress = "IDCUSTSHPT";

            /// <summary>
            /// Property for DropShipLocation
            /// </summary>
            public const string DropShipLocation = "DLOCATION";

            /// <summary>
            /// Property for DropShipDescription
            /// </summary>
            public const string DropShipDescription = "DESC";

            /// <summary>
            /// Property for DropShipAddress1
            /// </summary>
            public const string DropShipAddress1 = "ADDRESS1";

            /// <summary>
            /// Property for DropShipAddress2
            /// </summary>
            public const string DropShipAddress2 = "ADDRESS2";

            /// <summary>
            /// Property for DropShipAddress3
            /// </summary>
            public const string DropShipAddress3 = "ADDRESS3";

            /// <summary>
            /// Property for DropShipAddress4
            /// </summary>
            public const string DropShipAddress4 = "ADDRESS4";

            /// <summary>
            /// Property for DropShipCity
            /// </summary>
            public const string DropShipCity = "CITY";

            /// <summary>
            /// Property for DropShipStateProvince
            /// </summary>
            public const string DropShipStateProvince = "STATE";

            /// <summary>
            /// Property for DropShipZipPostalCode
            /// </summary>
            public const string DropShipZipPostalCode = "ZIP";

            /// <summary>
            /// Property for DropShipCountry
            /// </summary>
            public const string DropShipCountry = "COUNTRY";

            /// <summary>
            /// Property for DropShipPhoneNumber
            /// </summary>
            public const string DropShipPhoneNumber = "PHONE";

            /// <summary>
            /// Property for DropShipFaxNumber
            /// </summary>
            public const string DropShipFaxNumber = "FAX";

            /// <summary>
            /// Property for DropShipContact
            /// </summary>
            public const string DropShipContact = "CONTACT";

            /// <summary>
            /// Property for DropShipEmail
            /// </summary>
            public const string DropShipEmail = "EMAIL";

            /// <summary>
            /// Property for DropShipContactPhone
            /// </summary>
            public const string DropShipContactPhone = "PHONEC";

            /// <summary>
            /// Property for DropShipContactFax
            /// </summary>
            public const string DropShipContactFax = "FAXC";

            /// <summary>
            /// Property for DropShipContactEmail
            /// </summary>
            public const string DropShipContactEmail = "EMAILC";

            /// <summary>
            /// Property for StockItem
            /// </summary>
            public const string StockItem = "STOCKITEM";

            /// <summary>
            /// Property for NonStockClearingAccount
            /// </summary>
            public const string NonStockClearingAccount = "GLNONSTKCR";

            /// <summary>
            /// Property for ManufacturersItemNumber
            /// </summary>
            public const string ManufacturersItemNumber = "MANITEMNO";

            /// <summary>
            /// Property for DiscountPercentage
            /// </summary>
            public const string DiscountPercentage = "DISCPCT";

            /// <summary>
            /// Property for DiscountAmount
            /// </summary>
            public const string DiscountAmount = "DISCOUNT";

            /// <summary>
            /// Property for OptionalFields
            /// </summary>
            public const string OptionalFields = "VALUES";

            /// <summary>
            /// Property for FuncDiscountAmount
            /// </summary>
            public const string FuncDiscountAmount = "DISCOUNTF";

            /// <summary>
            /// Property for Received
            /// </summary>
            public const string Received = "ISRECEIVED";

            /// <summary>
            /// Property for AgentLineSequence
            /// </summary>
            public const string AgentLineSequence = "AGENTLSEQ";

            /// <summary>
            /// Property for Contract
            /// </summary>
            public const string Contract = "CONTRACT";

            /// <summary>
            /// Property for Project
            /// </summary>
            public const string Project = "PROJECT";

            /// <summary>
            /// Property for Category
            /// </summary>
            public const string Category = "CCATEGORY";

            /// <summary>
            /// Property for CostClass
            /// </summary>
            public const string CostClass = "COSTCLASS";

            /// <summary>
            /// Property for BillingType
            /// </summary>
            public const string BillingType = "BILLTYPE";

            /// <summary>
            /// Property for BillingRate
            /// </summary>
            public const string BillingRate = "BILLRATE";

            /// <summary>
            /// Property for BillingCurrency
            /// </summary>
            public const string BillingCurrency = "BILLCURR";

            /// <summary>
            /// Property for ARItemNumber
            /// </summary>
            public const string ARItemNumber = "ARITEMNO";

            /// <summary>
            /// Property for ARUnitOfMeasure
            /// </summary>
            public const string ARUnitOfMeasure = "ARUNIT";

            /// <summary>
            /// Property for TaxClass1Description
            /// </summary>
            public const string TaxClass1Description = "TAXCLASS1D";

            /// <summary>
            /// Property for TaxClass2Description
            /// </summary>
            public const string TaxClass2Description = "TAXCLASS2D";

            /// <summary>
            /// Property for TaxClass3Description
            /// </summary>
            public const string TaxClass3Description = "TAXCLASS3D";

            /// <summary>
            /// Property for TaxClass4Description
            /// </summary>
            public const string TaxClass4Description = "TAXCLASS4D";

            /// <summary>
            /// Property for TaxClass5Description
            /// </summary>
            public const string TaxClass5Description = "TAXCLASS5D";

            /// <summary>
            /// Property for ExpenseAccountDescription
            /// </summary>
            public const string ExpenseAccountDescription = "GLACEXPNSD";

            /// <summary>
            /// Property for IncludedTaxAmount1
            /// </summary>
            public const string IncludedTaxAmount1 = "TXINCLUDE1";

            /// <summary>
            /// Property for IncludedTaxAmount2
            /// </summary>
            public const string IncludedTaxAmount2 = "TXINCLUDE2";

            /// <summary>
            /// Property for IncludedTaxAmount3
            /// </summary>
            public const string IncludedTaxAmount3 = "TXINCLUDE3";

            /// <summary>
            /// Property for IncludedTaxAmount4
            /// </summary>
            public const string IncludedTaxAmount4 = "TXINCLUDE4";

            /// <summary>
            /// Property for IncludedTaxAmount5
            /// </summary>
            public const string IncludedTaxAmount5 = "TXINCLUDE5";

            /// <summary>
            /// Property for ExcludedTaxAmount1
            /// </summary>
            public const string ExcludedTaxAmount1 = "TXEXCLUDE1";

            /// <summary>
            /// Property for ExcludedTaxAmount2
            /// </summary>
            public const string ExcludedTaxAmount2 = "TXEXCLUDE2";

            /// <summary>
            /// Property for ExcludedTaxAmount3
            /// </summary>
            public const string ExcludedTaxAmount3 = "TXEXCLUDE3";

            /// <summary>
            /// Property for ExcludedTaxAmount4
            /// </summary>
            public const string ExcludedTaxAmount4 = "TXEXCLUDE4";

            /// <summary>
            /// Property for ExcludedTaxAmount5
            /// </summary>
            public const string ExcludedTaxAmount5 = "TXEXCLUDE5";

            /// <summary>
            /// Property for ExtendedOrderAmount
            /// </summary>
            public const string ExtendedOrderAmount = "SREXTORDER";

            /// <summary>
            /// Property for Completed
            /// </summary>
            public const string Completed = "ISCOMPLETE";

            /// <summary>
            /// Property for IsRecordActive
            /// </summary>
            public const string IsRecordActive = "ISACTIVE";

            /// <summary>
            /// Property for LinesTaxCalculationSees
            /// </summary>
            public const string LinesTaxCalculationSees = "TAXLINE";

            /// <summary>
            /// Property for LinesComplete
            /// </summary>
            public const string LinesComplete = "LINECMPL";

            /// <summary>
            /// Property for Line
            /// </summary>
            public const string Line = "LINE";

            /// <summary>
            /// Property for ExtendedStdCostInSrcCurr
            /// </summary>
            public const string ExtendedStdCostInSrcCurr = "EXSTDCOST";

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property for ExtendedMRCostInSrcCurr
            /// </summary>
            public const string ExtendedMRCostInSrcCurr = "EXMRCOST";

            /// <summary>
            /// Property for ExtendedCost1InSrcCurr
            /// </summary>
            public const string ExtendedCost1InSrcCurr = "EXALT1COST";

            /// <summary>
            /// Property for ExtendedCost2InSrcCurr
            /// </summary>
            public const string ExtendedCost2InSrcCurr = "EXALT2COST";

            /// <summary>
            /// Property for NonStockClearingAccountDesc
            /// </summary>
            public const string NonStockClearingAccountDesc = "GLNONSTKCD";

            /// <summary>
            /// Property for MapManufacturersItemNumber
            /// </summary>
            public const string MapManufacturersItemNumber = "MAPMANITEM";

            /// <summary>
            /// Property for NetExtendedCost
            /// </summary>
            public const string NetExtendedCost = "NETXTENDED";

            /// <summary>
            /// Property for ProcessCommandSequenceNumber
            /// </summary>
            public const string ProcessCommandSequenceNumber = "OOVERSEQ";

            /// <summary>
            /// Property for ProcessCommandLineSequence
            /// </summary>
            public const string ProcessCommandLineSequence = "OOVERLSEQ";

            /// <summary>
            /// Property for RequisitionLineNumber
            /// </summary>
            public const string RequisitionLineNumber = "RQNLREV";

            /// <summary>
            /// Property for Command
            /// </summary>
            public const string Command = "PROCESSCMD";

            /// <summary>
            /// Property for FuncNetOfTax
            /// </summary>
            public const string FuncNetOfTax = "TFBASEALLO";

            /// <summary>
            /// Property for FuncTaxIncludedAmount1
            /// </summary>
            public const string FuncTaxIncludedAmount1 = "TFINCLUDE1";

            /// <summary>
            /// Property for FuncTaxIncludedAmount2
            /// </summary>
            public const string FuncTaxIncludedAmount2 = "TFINCLUDE2";

            /// <summary>
            /// Property for FuncTaxIncludedAmount3
            /// </summary>
            public const string FuncTaxIncludedAmount3 = "TFINCLUDE3";

            /// <summary>
            /// Property for FuncTaxIncludedAmount4
            /// </summary>
            public const string FuncTaxIncludedAmount4 = "TFINCLUDE4";

            /// <summary>
            /// Property for FuncTaxIncludedAmount5
            /// </summary>
            public const string FuncTaxIncludedAmount5 = "TFINCLUDE5";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount1
            /// </summary>
            public const string FuncTaxAllocatedAmount1 = "TFALLOAMT1";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount2
            /// </summary>
            public const string FuncTaxAllocatedAmount2 = "TFALLOAMT2";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount3
            /// </summary>
            public const string FuncTaxAllocatedAmount3 = "TFALLOAMT3";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount4
            /// </summary>
            public const string FuncTaxAllocatedAmount4 = "TFALLOAMT4";

            /// <summary>
            /// Property for FuncTaxAllocatedAmount5
            /// </summary>
            public const string FuncTaxAllocatedAmount5 = "TFALLOAMT5";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount1
            /// </summary>
            public const string FuncTaxRecoverableAmount1 = "TFRECVAMT1";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount2
            /// </summary>
            public const string FuncTaxRecoverableAmount2 = "TFRECVAMT2";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount3
            /// </summary>
            public const string FuncTaxRecoverableAmount3 = "TFRECVAMT3";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount4
            /// </summary>
            public const string FuncTaxRecoverableAmount4 = "TFRECVAMT4";

            /// <summary>
            /// Property for FuncTaxRecoverableAmount5
            /// </summary>
            public const string FuncTaxRecoverableAmount5 = "TFRECVAMT5";

            /// <summary>
            /// Property for FuncTaxExpenseAmount1
            /// </summary>
            public const string FuncTaxExpenseAmount1 = "TFEXPSAMT1";

            /// <summary>
            /// Property for FuncTaxExpenseAmount2
            /// </summary>
            public const string FuncTaxExpenseAmount2 = "TFEXPSAMT2";

            /// <summary>
            /// Property for FuncTaxExpenseAmount3
            /// </summary>
            public const string FuncTaxExpenseAmount3 = "TFEXPSAMT3";

            /// <summary>
            /// Property for FuncTaxExpenseAmount4
            /// </summary>
            public const string FuncTaxExpenseAmount4 = "TFEXPSAMT4";

            /// <summary>
            /// Property for FuncTaxExpenseAmount5
            /// </summary>
            public const string FuncTaxExpenseAmount5 = "TFEXPSAMT5";

            /// <summary>
            /// Property for ProjectStyle
            /// </summary>
            public const string ProjectStyle = "CONTSTYLE";

            /// <summary>
            /// Property for ProjectType
            /// </summary>
            public const string ProjectType = "PROJTYPE";

            /// <summary>
            /// Property for AccountingMethod
            /// </summary>
            public const string AccountingMethod = "REVREC";

            /// <summary>
            /// Property for UnformattedContractCode
            /// </summary>
            public const string UnformattedContractCode = "UFMTCONTNO";

            /// <summary>
            /// Property for TaxReportingAmount1
            /// </summary>
            public const string TaxReportingAmount1 = "TARAMOUNT1";

            /// <summary>
            /// Property for TaxReportingAmount2
            /// </summary>
            public const string TaxReportingAmount2 = "TARAMOUNT2";

            /// <summary>
            /// Property for TaxReportingAmount3
            /// </summary>
            public const string TaxReportingAmount3 = "TARAMOUNT3";

            /// <summary>
            /// Property for TaxReportingAmount4
            /// </summary>
            public const string TaxReportingAmount4 = "TARAMOUNT4";

            /// <summary>
            /// Property for TaxReportingAmount5
            /// </summary>
            public const string TaxReportingAmount5 = "TARAMOUNT5";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount1
            /// </summary>
            public const string TaxReportingAllocatedAmount1 = "TRALLOAMT1";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount2
            /// </summary>
            public const string TaxReportingAllocatedAmount2 = "TRALLOAMT2";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount3
            /// </summary>
            public const string TaxReportingAllocatedAmount3 = "TRALLOAMT3";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount4
            /// </summary>
            public const string TaxReportingAllocatedAmount4 = "TRALLOAMT4";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount5
            /// </summary>
            public const string TaxReportingAllocatedAmount5 = "TRALLOAMT5";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt1
            /// </summary>
            public const string TaxReportingRecoverableAmt1 = "TRRECVAMT1";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt2
            /// </summary>
            public const string TaxReportingRecoverableAmt2 = "TRRECVAMT2";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt3
            /// </summary>
            public const string TaxReportingRecoverableAmt3 = "TRRECVAMT3";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt4
            /// </summary>
            public const string TaxReportingRecoverableAmt4 = "TRRECVAMT4";

            /// <summary>
            /// Property for TaxReportingRecoverableAmt5
            /// </summary>
            public const string TaxReportingRecoverableAmt5 = "TRRECVAMT5";

            /// <summary>
            /// Property for TaxReportingExpenseAmount1
            /// </summary>
            public const string TaxReportingExpenseAmount1 = "TREXPSAMT1";

            /// <summary>
            /// Property for TaxReportingExpenseAmount2
            /// </summary>
            public const string TaxReportingExpenseAmount2 = "TREXPSAMT2";

            /// <summary>
            /// Property for TaxReportingExpenseAmount3
            /// </summary>
            public const string TaxReportingExpenseAmount3 = "TREXPSAMT3";

            /// <summary>
            /// Property for TaxReportingExpenseAmount4
            /// </summary>
            public const string TaxReportingExpenseAmount4 = "TREXPSAMT4";

            /// <summary>
            /// Property for TaxReportingExpenseAmount5
            /// </summary>
            public const string TaxReportingExpenseAmount5 = "TREXPSAMT5";

            /// <summary>
            /// Property for TaxReportingIncludedAmount1
            /// </summary>
            public const string TaxReportingIncludedAmount1 = "TRINCLUDE1";

            /// <summary>
            /// Property for TaxReportingIncludedAmount2
            /// </summary>
            public const string TaxReportingIncludedAmount2 = "TRINCLUDE2";

            /// <summary>
            /// Property for TaxReportingIncludedAmount3
            /// </summary>
            public const string TaxReportingIncludedAmount3 = "TRINCLUDE3";

            /// <summary>
            /// Property for TaxReportingIncludedAmount4
            /// </summary>
            public const string TaxReportingIncludedAmount4 = "TRINCLUDE4";

            /// <summary>
            /// Property for TaxReportingIncludedAmount5
            /// </summary>
            public const string TaxReportingIncludedAmount5 = "TRINCLUDE5";

            /// <summary>
            /// Property for TaxReportingExcludedAmount1
            /// </summary>
            public const string TaxReportingExcludedAmount1 = "TREXCLUDE1";

            /// <summary>
            /// Property for TaxReportingExcludedAmount2
            /// </summary>
            public const string TaxReportingExcludedAmount2 = "TREXCLUDE2";

            /// <summary>
            /// Property for TaxReportingExcludedAmount3
            /// </summary>
            public const string TaxReportingExcludedAmount3 = "TREXCLUDE3";

            /// <summary>
            /// Property for TaxReportingExcludedAmount4
            /// </summary>
            public const string TaxReportingExcludedAmount4 = "TREXCLUDE4";

            /// <summary>
            /// Property for TaxReportingExcludedAmount5
            /// </summary>
            public const string TaxReportingExcludedAmount5 = "TREXCLUDE5";

            /// <summary>
            /// Property for TaxReportingTotalAmount
            /// </summary>
            public const string TaxReportingTotalAmount = "TARAMOUNT";

            /// <summary>
            /// Property for TaxReportingIncludedAmount
            /// </summary>
            public const string TaxReportingIncludedAmount = "TRINCLUDED";

            /// <summary>
            /// Property for TaxReportingExcludedAmount
            /// </summary>
            public const string TaxReportingExcludedAmount = "TREXCLUDED";

            /// <summary>
            /// Property for TaxReportingRecoverableAmount
            /// </summary>
            public const string TaxReportingRecoverableAmount = "TRRECVAMT";

            /// <summary>
            /// Property for TaxReportingExpensedAmount
            /// </summary>
            public const string TaxReportingExpensedAmount = "TREXPSAMT";

            /// <summary>
            /// Property for TaxReportingAllocatedAmount
            /// </summary>
            public const string TaxReportingAllocatedAmount = "TRALLOAMT";

            /// <summary>
            /// Property for UnitCostIsManual
            /// </summary>
            public const string UnitCostIsManual = "UCISMANUAL";

            /// <summary>
            /// Property for WeightUnitOfMeasure
            /// </summary>
            public const string WeightUnitOfMeasure = "WEIGHTUNIT";

            /// <summary>
            /// Property for WeightConversion
            /// </summary>
            public const string WeightConversion = "WEIGHTCONV";

            /// <summary>
            /// Property for DefaultUnitWeight
            /// </summary>
            public const string DefaultUnitWeight = "DEFUWEIGHT";

            /// <summary>
            /// Property for DefaultExtendedWeight
            /// </summary>
            public const string DefaultExtendedWeight = "DEFEXTWGHT";

            /// <summary>
            /// Property for BillingRateConversionFactor
            /// </summary>
            public const string BillingRateConversionFactor = "BILLRATECV";

            /// <summary>
            /// Property for UnitBillingAmount
            /// </summary>
            public const string UnitBillingAmount = "UNITBILLSR";

            /// <summary>
            /// Property for ExtendedBillingAmount
            /// </summary>
            public const string ExtendedBillingAmount = "EXTBILLSR";

            /// <summary>
            /// Property for CopyThisDetailLine
            /// </summary>
            public const string CopyThisDetailLine = "COPYDETAIL";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string DetailNumber = "DETAILNUM";

            /// <summary>
            /// Property for DetailNumber
            /// </summary>
            public const string BillingCurrencyDecimal = "BILLCURDEC";

        }

        #endregion

        #region Index Properties

        /// <summary>
        /// Contains list of PurchaseOrderLine Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 1;

            /// <summary>
            /// Property Indexer for LineNumber
            /// </summary>
            public const int LineNumber = 2;

            /// <summary>
            /// Property Indexer for PurchaseOrderLineSequence
            /// </summary>
            public const int PurchaseOrderLineSequence = 3;

            /// <summary>
            /// Property Indexer for PurchaseOrderCommentSequence
            /// </summary>
            public const int PurchaseOrderCommentSequence = 4;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 5;

            /// <summary>
            /// Property Indexer for ConsolidatedToline
            /// </summary>
            public const int ConsolidatedToline = 6;

            /// <summary>
            /// Property Indexer for RequisitionSequenceKey
            /// </summary>
            public const int RequisitionSequenceKey = 7;

            /// <summary>
            /// Property Indexer for RequisitionLineSequence
            /// </summary>
            public const int RequisitionLineSequence = 8;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 9;

            /// <summary>
            /// Property Indexer for PostedToIC
            /// </summary>
            public const int PostedToIC = 10;

            /// <summary>
            /// Property Indexer for ToPostToIC
            /// </summary>
            public const int ToPostToIC = 11;

            /// <summary>
            /// Property Indexer for PrintStatus
            /// </summary>
            public const int PrintStatus = 12;

            /// <summary>
            /// Property Indexer for CompletionStatus
            /// </summary>
            public const int CompletionStatus = 13;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 14;

            /// <summary>
            /// Property Indexer for ItemExists
            /// </summary>
            public const int ItemExists = 15;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 16;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 17;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 18;

            /// <summary>
            /// Property Indexer for ExpectedArrivalDate
            /// </summary>
            public const int ExpectedArrivalDate = 19;

            /// <summary>
            /// Property Indexer for VendorItemNumber
            /// </summary>
            public const int VendorItemNumber = 20;

            /// <summary>
            /// Property Indexer for CommentsInstructions
            /// </summary>
            public const int CommentsInstructions = 21;

            /// <summary>
            /// Property Indexer for UnitOfMeasure
            /// </summary>
            public const int UnitOfMeasure = 22;

            /// <summary>
            /// Property Indexer for OrderUnitConversion
            /// </summary>
            public const int OrderUnitConversion = 23;

            /// <summary>
            /// Property Indexer for OrderUnitDecimals
            /// </summary>
            public const int OrderUnitDecimals = 24;

            /// <summary>
            /// Property Indexer for StockUnitDecimals
            /// </summary>
            public const int StockUnitDecimals = 25;

            /// <summary>
            /// Property Indexer for QuantityOrdered
            /// </summary>
            public const int QuantityOrdered = 26;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 27;

            /// <summary>
            /// Property Indexer for QuantityCanceled
            /// </summary>
            public const int QuantityCanceled = 28;

            /// <summary>
            /// Property Indexer for ReceivedExtra
            /// </summary>
            public const int ReceivedExtra = 29;

            /// <summary>
            /// Property Indexer for QuantityOutstanding
            /// </summary>
            public const int QuantityOutstanding = 30;

            /// <summary>
            /// Property Indexer for StockingQuantityOrdered
            /// </summary>
            public const int StockingQuantityOrdered = 31;

            /// <summary>
            /// Property Indexer for StockingQuantityReceived
            /// </summary>
            public const int StockingQuantityReceived = 32;

            /// <summary>
            /// Property Indexer for StockingQuantityCanceled
            /// </summary>
            public const int StockingQuantityCanceled = 33;

            /// <summary>
            /// Property Indexer for StockingQuantityReceivedExtra
            /// </summary>
            public const int StockingQuantityReceivedExtra = 34;

            /// <summary>
            /// Property Indexer for StockingQuantitySettled
            /// </summary>
            public const int StockingQuantitySettled = 35;

            /// <summary>
            /// Property Indexer for StockingQuantityOutstanding
            /// </summary>
            public const int StockingQuantityOutstanding = 36;

            /// <summary>
            /// Property Indexer for UnitWeight
            /// </summary>
            public const int UnitWeight = 37;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 38;

            /// <summary>
            /// Property Indexer for DaysQuantityReceived
            /// </summary>
            public const int DaysQuantityReceived = 39;

            /// <summary>
            /// Property Indexer for ExtendedReceivedAmount
            /// </summary>
            public const int ExtendedReceivedAmount = 40;

            /// <summary>
            /// Property Indexer for ExtendedCanceledAmount
            /// </summary>
            public const int ExtendedCanceledAmount = 41;

            /// <summary>
            /// Property Indexer for AmountReceivedToDate
            /// </summary>
            public const int AmountReceivedToDate = 42;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 43;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 44;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 45;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 46;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 47;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 48;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 49;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 50;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 51;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 52;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 53;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 54;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 55;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 56;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 57;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 58;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 59;

            /// <summary>
            /// Property Indexer for TaxIncludable1
            /// </summary>
            public const int TaxIncludable1 = 60;

            /// <summary>
            /// Property Indexer for TaxIncludable2
            /// </summary>
            public const int TaxIncludable2 = 61;

            /// <summary>
            /// Property Indexer for TaxIncludable3
            /// </summary>
            public const int TaxIncludable3 = 62;

            /// <summary>
            /// Property Indexer for TaxIncludable4
            /// </summary>
            public const int TaxIncludable4 = 63;

            /// <summary>
            /// Property Indexer for TaxIncludable5
            /// </summary>
            public const int TaxIncludable5 = 64;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 65;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 66;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 67;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 68;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 69;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 70;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 71;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 72;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 73;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 74;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 75;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 76;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 77;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 78;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 79;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 80;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 81;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 82;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 83;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 84;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 85;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 86;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 87;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 88;

            /// <summary>
            /// Property Indexer for RecoverableTax
            /// </summary>
            public const int RecoverableTax = 89;

            /// <summary>
            /// Property Indexer for ExpensedTax
            /// </summary>
            public const int ExpensedTax = 90;

            /// <summary>
            /// Property Indexer for AllocatedTax
            /// </summary>
            public const int AllocatedTax = 91;

            /// <summary>
            /// Property Indexer for RcpExtAmt
            /// </summary>
            public const int RcpExtAmt = 92;

            /// <summary>
            /// Property Indexer for ExpenseAccount
            /// </summary>
            public const int ExpenseAccount = 93;

            /// <summary>
            /// Property Indexer for DropShip
            /// </summary>
            public const int DropShip = 94;

            /// <summary>
            /// Property Indexer for DropShipType
            /// </summary>
            public const int DropShipType = 95;

            /// <summary>
            /// Property Indexer for DropShipCustomer
            /// </summary>
            public const int DropShipCustomer = 96;

            /// <summary>
            /// Property Indexer for CustomerShipToAddress
            /// </summary>
            public const int CustomerShipToAddress = 97;

            /// <summary>
            /// Property Indexer for DropShipLocation
            /// </summary>
            public const int DropShipLocation = 98;

            /// <summary>
            /// Property Indexer for DropShipDescription
            /// </summary>
            public const int DropShipDescription = 99;

            /// <summary>
            /// Property Indexer for DropShipAddress1
            /// </summary>
            public const int DropShipAddress1 = 100;

            /// <summary>
            /// Property Indexer for DropShipAddress2
            /// </summary>
            public const int DropShipAddress2 = 101;

            /// <summary>
            /// Property Indexer for DropShipAddress3
            /// </summary>
            public const int DropShipAddress3 = 102;

            /// <summary>
            /// Property Indexer for DropShipAddress4
            /// </summary>
            public const int DropShipAddress4 = 103;

            /// <summary>
            /// Property Indexer for DropShipCity
            /// </summary>
            public const int DropShipCity = 104;

            /// <summary>
            /// Property Indexer for DropShipStateProvince
            /// </summary>
            public const int DropShipStateProvince = 105;

            /// <summary>
            /// Property Indexer for DropShipZipPostalCode
            /// </summary>
            public const int DropShipZipPostalCode = 106;

            /// <summary>
            /// Property Indexer for DropShipCountry
            /// </summary>
            public const int DropShipCountry = 107;

            /// <summary>
            /// Property Indexer for DropShipPhoneNumber
            /// </summary>
            public const int DropShipPhoneNumber = 108;

            /// <summary>
            /// Property Indexer for DropShipFaxNumber
            /// </summary>
            public const int DropShipFaxNumber = 109;

            /// <summary>
            /// Property Indexer for DropShipContact
            /// </summary>
            public const int DropShipContact = 110;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 111;

            /// <summary>
            /// Property Indexer for DropShipEmail
            /// </summary>
            public const int DropShipEmail = 112;

            /// <summary>
            /// Property Indexer for DropShipContactPhone
            /// </summary>
            public const int DropShipContactPhone = 113;

            /// <summary>
            /// Property Indexer for DropShipContactFax
            /// </summary>
            public const int DropShipContactFax = 114;

            /// <summary>
            /// Property Indexer for DropShipContactEmail
            /// </summary>
            public const int DropShipContactEmail = 115;

            /// <summary>
            /// Property Indexer for NonStockClearingAccount
            /// </summary>
            public const int NonStockClearingAccount = 116;

            /// <summary>
            /// Property Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 117;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 118;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 119;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 120;

            /// <summary>
            /// Property Indexer for FuncDiscountAmount
            /// </summary>
            public const int FuncDiscountAmount = 121;

            /// <summary>
            /// Property Indexer for Received
            /// </summary>
            public const int Received = 122;

            /// <summary>
            /// Property Indexer for AgentLineSequence
            /// </summary>
            public const int AgentLineSequence = 123;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 124;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 125;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 126;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 127;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 128;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 129;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 130;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 131;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 132;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 141;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 142;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 143;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 144;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 145;

            /// <summary>
            /// Property Indexer for ExpenseAccountDescription
            /// </summary>
            public const int ExpenseAccountDescription = 146;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 147;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 148;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 149;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 150;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 151;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 152;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 153;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 154;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 155;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 156;

            /// <summary>
            /// Property Indexer for ExtendedOrderAmount
            /// </summary>
            public const int ExtendedOrderAmount = 157;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 158;

            /// <summary>
            /// Property Indexer for IsRecordActive
            /// </summary>
            public const int IsRecordActive = 159;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 160;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 161;

            /// <summary>
            /// Property Indexer for Line
            /// </summary>
            public const int Line = 162;

            /// <summary>
            /// Property Indexer for ExtendedStdCostInSrcCurr
            /// </summary>
            public const int ExtendedStdCostInSrcCurr = 163;

            // TODO: The naming convention of this property has to be manually evaluated
            /// <summary>
            /// Property Indexer for ExtendedMRCostInSrcCurr
            /// </summary>
            public const int ExtendedMRCostInSrcCurr = 164;

            /// <summary>
            /// Property Indexer for ExtendedCost1InSrcCurr
            /// </summary>
            public const int ExtendedCost1InSrcCurr = 165;

            /// <summary>
            /// Property Indexer for ExtendedCost2InSrcCurr
            /// </summary>
            public const int ExtendedCost2InSrcCurr = 166;

            /// <summary>
            /// Property Indexer for NonStockClearingAccountDesc
            /// </summary>
            public const int NonStockClearingAccountDesc = 167;

            /// <summary>
            /// Property Indexer for MapManufacturersItemNumber
            /// </summary>
            public const int MapManufacturersItemNumber = 168;

            /// <summary>
            /// Property Indexer for NetExtendedCost
            /// </summary>
            public const int NetExtendedCost = 169;

            /// <summary>
            /// Property Indexer for ProcessCommandSequenceNumber
            /// </summary>
            public const int ProcessCommandSequenceNumber = 170;

            /// <summary>
            /// Property Indexer for ProcessCommandLineSequence
            /// </summary>
            public const int ProcessCommandLineSequence = 171;

            /// <summary>
            /// Property Indexer for RequisitionLineNumber
            /// </summary>
            public const int RequisitionLineNumber = 172;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 173;

            /// <summary>
            /// Property Indexer for FuncNetOfTax
            /// </summary>
            public const int FuncNetOfTax = 174;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount1
            /// </summary>
            public const int FuncTaxIncludedAmount1 = 175;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount2
            /// </summary>
            public const int FuncTaxIncludedAmount2 = 176;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount3
            /// </summary>
            public const int FuncTaxIncludedAmount3 = 177;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount4
            /// </summary>
            public const int FuncTaxIncludedAmount4 = 178;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount5
            /// </summary>
            public const int FuncTaxIncludedAmount5 = 179;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount1
            /// </summary>
            public const int FuncTaxAllocatedAmount1 = 180;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount2
            /// </summary>
            public const int FuncTaxAllocatedAmount2 = 181;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount3
            /// </summary>
            public const int FuncTaxAllocatedAmount3 = 182;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount4
            /// </summary>
            public const int FuncTaxAllocatedAmount4 = 183;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount5
            /// </summary>
            public const int FuncTaxAllocatedAmount5 = 184;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount1
            /// </summary>
            public const int FuncTaxRecoverableAmount1 = 185;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount2
            /// </summary>
            public const int FuncTaxRecoverableAmount2 = 186;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount3
            /// </summary>
            public const int FuncTaxRecoverableAmount3 = 187;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount4
            /// </summary>
            public const int FuncTaxRecoverableAmount4 = 188;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount5
            /// </summary>
            public const int FuncTaxRecoverableAmount5 = 189;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount1
            /// </summary>
            public const int FuncTaxExpenseAmount1 = 190;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount2
            /// </summary>
            public const int FuncTaxExpenseAmount2 = 191;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount3
            /// </summary>
            public const int FuncTaxExpenseAmount3 = 192;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount4
            /// </summary>
            public const int FuncTaxExpenseAmount4 = 193;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount5
            /// </summary>
            public const int FuncTaxExpenseAmount5 = 194;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 195;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 196;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 197;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 198;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 199;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 200;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 201;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 202;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 203;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 204;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 205;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 206;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 207;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 208;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 209;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 210;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 211;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 212;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 213;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 214;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 215;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 216;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 217;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 218;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 219;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 220;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 221;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 222;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 223;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 224;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 225;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 226;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 227;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 228;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 229;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 230;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 231;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 232;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 233;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 234;

            /// <summary>
            /// Property Indexer for UnitCostIsManual
            /// </summary>
            public const int UnitCostIsManual = 235;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure
            /// </summary>
            public const int WeightUnitOfMeasure = 236;

            /// <summary>
            /// Property Indexer for WeightConversion
            /// </summary>
            public const int WeightConversion = 237;

            /// <summary>
            /// Property Indexer for DefaultUnitWeight
            /// </summary>
            public const int DefaultUnitWeight = 238;

            /// <summary>
            /// Property Indexer for DefaultExtendedWeight
            /// </summary>
            public const int DefaultExtendedWeight = 239;

            /// <summary>
            /// Property Indexer for BillingRateConversionFactor
            /// </summary>
            public const int BillingRateConversionFactor = 240;

            /// <summary>
            /// Property Indexer for UnitBillingAmount
            /// </summary>
            public const int UnitBillingAmount = 241;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 242;

            /// <summary>
            /// Property Indexer for CopyThisDetailLine
            /// </summary>
            public const int CopyThisDetailLine = 243;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 244;
            /// <summary>
            /// Property Indexer for ReverseChargeable1
            /// </summary>
            public const int ReverseChargeable1 = 245;
            /// <summary>
            /// Property Indexer for ReverseChargeable2
            /// </summary>
            public const int ReverseChargeable2 = 246;
            /// <summary>
            /// Property Indexer for ReverseChargeable3
            /// </summary>
            public const int ReverseChargeable3 = 247;
            /// <summary>
            /// Property Indexer for ReverseChargeable4
            /// </summary>
            public const int ReverseChargeable4 = 248;
            /// <summary>
            /// Property Indexer for ReverseChargeable5
            /// </summary>
            public const int ReverseChargeable5 = 249;

            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 250;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 251;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 252;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 253;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 254;
            /// <summary>
            /// Property Indexer for customer detail tax amount 1
            /// </summary>
            public const int CustomerDetailTaxAmount1 = 255;
            /// <summary>
            /// Property Indexer for customer detail tax amount 2
            /// </summary>
            public const int CustomerDetailTaxAmount2 = 256;
            /// <summary>
            /// Property Indexer for customer detail tax amount 3
            /// </summary>
            public const int CustomerDetailTaxAmount3 = 257;
            /// <summary>
            /// Property Indexer for customer detail tax amount 4
            /// </summary>
            public const int CustomerDetailTaxAmount4 = 258;
            /// <summary>
            /// Property Indexer for customer detail tax amount 5
            /// </summary>
            public const int CustomerDetailTaxAmount5 = 259;
            /// <summary>
            /// Property Indexer for customer detail tax amount 5
            /// </summary>
            public const int BillingCurrencyDecimal = 260;
        }

        #endregion

    }
}
