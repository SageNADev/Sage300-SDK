// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
	/// <summary>
	/// Contains list of DuplicateInvoice Constants
	/// </summary>
	public partial class DuplicateInvoice
	{
		/// <summary>
		/// View Name
		/// </summary>
		public const string EntityName = "PO0414";

		#region Properties

		/// <summary>
		/// Contains list of DuplicateInvoice Field Constants
		/// </summary>
        public class Fields : BaseFields
		{   			
		}

		#endregion

		#region Properties

		/// <summary>
		/// Contains list of DuplicateInvoice Index Constants
		/// </summary>
		public class Index
		{

			/// <summary>
			/// Property Indexer for InvoiceSequenceKey
			/// </summary>
			public const int InvoiceSequenceKey = 1;

			/// <summary>
			/// Property Indexer for InvoiceNumber
			/// </summary>
			public const int InvoiceNumber = 2;

			/// <summary>
			/// Property Indexer for RequireNewEntry
			/// </summary>
			public const int RequireNewEntry = 3;

			/// <summary>
			/// Property Indexer for Vendor
			/// </summary>
			public const int Vendor = 4;

			/// <summary>
			/// Property Indexer for Date
			/// </summary>
			public const int Date = 5;

			/// <summary>
			/// Property Indexer for Total
			/// </summary>
			public const int Total = 6;

			/// <summary>
			/// Property Indexer for NumberOfDuplicates
			/// </summary>
			public const int NumberOfDuplicates = 7;

			/// <summary>
			/// Property Indexer for Function
			/// </summary>
			public const int Function = 8;

		}

		#endregion

	}
}
