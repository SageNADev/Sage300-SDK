// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using System.Collections.Generic;
#endregion

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of RequisitionLine Constants
     /// </summary>
     public partial class RequisitionLine
     {
          /// <summary>
          /// View Name
          /// </summary>
         public const string EntityName = "PO0770";

         /// <summary>
         /// Dynamic Attributes contain a reverse mapping of field and property
         /// </summary>
         public static Dictionary<string, string> DynamicAttributes
         {
             get
             {
                 return new Dictionary<string, string>
				{
					{"RQNLSEQ", "RequisitionLineSequence"},
					{"LINEORDER", "LineOrdered"},
					{"RQNCSEQ", "RequisitionCommentSequence"},
					{"OEONUMBER", "OrderNumber"},
					{"VDEXISTS", "VendorExists"},
					{"VDCODE", "VDCODE"},
					{"VDNAME", "Name"},
					{"INDBTABLE", "StoredInDatabaseTable"},
					{"COMPLETION", "CompletionStatus"},
					{"DTCOMPLETE", "DateCompleted"},
					{"ITEMEXISTS", "ItemExists"},
					{"ITEMNO", "ItemNumber"},
					{"LOCATION", "Location"},
					{"ITEMDESC", "ItemDescription"},
					{"EXPARRIVAL", "ExpectedArrivalDate"},
					{"VENDITEMNO", "VendorItemNumber"},
					{"HASCOMMENT", "CommentsInstructions"},
					{"ORDERUNIT", "UnitOfMeasure"},
					{"ORDERCONV", "OrderUnitConversion"},
					{"ORDERDECML", "OrderUnitDecimals"},
					{"STOCKDECML", "StockUnitDecimals"},
					{"OQORDERED", "QuantityOrdered"},
					{"HASDROPSHI", "DropShip"},
					{"DROPTYPE", "DropShipType"},
					{"IDCUST", "DropShipCustomer"},
					{"IDCUSTSHPT", "CustomerShipToAddress"},
					{"DLOCATION", "DropShipLocation"},
					{"DESC", "DropShipDescription"},
					{"ADDRESS1", "DropShipAddress1"},
					{"ADDRESS2", "DropShipAddress2"},
					{"ADDRESS3", "DropShipAddress3"},
					{"ADDRESS4", "DropShipAddress4"},
					{"CITY", "DropShipCity"},
					{"STATE", "DropShipStateProvince"},
					{"ZIP", "DropShipZipPostalCode"},
					{"COUNTRY", "DropShipCountry"},
					{"PHONE", "DropShipPhoneNumber"},
					{"FAX", "DropShipFaxNumber"},
					{"CONTACT", "DropShipContact"},
					{"STOCKITEM", "StockItem"},
					{"EMAIL", "DropShipEmail"},
					{"PHONEC", "DropShipContactPhone"},
					{"FAXC", "DropShipContactFax"},
					{"EMAILC", "DropShipContactEmail"},
					{"MANITEMNO", "ManufacturersItemNumber"},
					{"VALUES", "OptionalFields"},
					{"CONTRACT", "Contract"},
					{"PROJECT", "Project"},
					{"CCATEGORY", "Category"},
					{"COSTCLASS", "CostClass"},
					{"SQORDERED", "StockingQuantityOrdered"},
					{"VDONHOLD", "VendorOnHold"},
					{"USEVDTYPE", "UseICVendor"},
					{"ICVDCODE", "ICVDCODE"},
					{"ISCOMPLETE", "Completed"},
					{"LINECMPL", "LinesComplete"},
					{"ISACTIVE", "IsRecordActive"},
					{"LINE", "Line"},
					{"PROCESSCMD", "Command"},
					{"CONTSTYLE", "ProjectStyle"},
					{"PROJTYPE", "ProjectType"},
					{"UFMTCONTNO", "UnformattedContractCode"},
					{"UNITCOST", "UnitCost"},
					{"UCISMANUAL", "UnitCostIsManual"},
					{"CPCOSTTOPO", "CopyCostToPurchaseOrder"},
					{"EXTENDED", "ExtendedCost"},
					{"FCEXTENDED", "FunctionalExtended"},
					{"DISCOUNT", "DiscountAmount"},
					{"DISCPCT", "DiscountPercentage"},
					{"UNITWEIGHT", "UnitWeight"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"WEIGHTUNIT", "WeightUnitOfMeasure"},
					{"WEIGHTCONV", "WeightConversion"},
					{"DEFUWEIGHT", "DefaultUnitWeight"},
					{"DEFEXTWGHT", "DefaultExtendedWeight"},
					{"NETXTENDED", "NetExtendedCost"},
					{"LINES", "Lines"},
					{"CURRENCY", "Currency"},
					{"CURRENCYD", "CurrencyDescription"},
					{"RATE", "ExchangeRate"},
					{"RATEEXISTS", "ExchangeRateExists"},
					{"RATETYPE", "RateType"},
					{"RATETYPED", "RateTypeDescription"},
					{"RATEDATE", "RateDate"},
					{"RATEOPER", "RateOperation"},
					{"COSTDATE", "CostDateForContract"},
					{"DETAILNUM", "DetailNumber"}
				};
             }
         }

          #region Properties
          /// <summary>
          /// Contains list of RequisitionLine Constants
          /// </summary>
          public class Fields
          {
               /// <summary>
               /// Property for RequisitionSequenceKey
               /// </summary>
               public const string RequisitionSequenceKey = "RQNHSEQ";

               /// <summary>
               /// Property for LineNumber
               /// </summary>
               public const string LineNumber = "RQNLREV";

               /// <summary>
               /// Property for RequisitionLineSequence
               /// </summary>
               public const string RequisitionLineSequence = "RQNLSEQ";

               /// <summary>
               /// Property for LineOrdered
               /// </summary>
               public const string LineOrdered = "LINEORDER";

               /// <summary>
               /// Property for RequisitionCommentSequence
               /// </summary>
               public const string RequisitionCommentSequence = "RQNCSEQ";

               /// <summary>
               /// Property for OrderNumber
               /// </summary>
               public const string OrderNumber = "OEONUMBER";

               /// <summary>
               /// Property for VendorExists
               /// </summary>
               public const string VendorExists = "VDEXISTS";

               /// <summary>
               /// Property for VDCODE
               /// </summary>               
               // ReSharper disable once UnusedMember.Global              
               // ReSharper disable once InconsistentNaming
              public const string VDCODE = "VDCODE";

               /// <summary>
               /// Property for Name
               /// </summary>
               public const string Name = "VDNAME";

               /// <summary>
               /// Property for StoredInDatabaseTable
               /// </summary>
               public const string StoredInDatabaseTable = "INDBTABLE";

               /// <summary>
               /// Property for CompletionStatus
               /// </summary>
               public const string CompletionStatus = "COMPLETION";

               /// <summary>
               /// Property for DateCompleted
               /// </summary>
               public const string DateCompleted = "DTCOMPLETE";

               /// <summary>
               /// Property for ItemExists
               /// </summary>
               public const string ItemExists = "ITEMEXISTS";

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for Location
               /// </summary>
               public const string Location = "LOCATION";

               /// <summary>
               /// Property for ItemDescription
               /// </summary>
               public const string ItemDescription = "ITEMDESC";

               /// <summary>
               /// Property for ExpectedArrivalDate
               /// </summary>
               public const string ExpectedArrivalDate = "EXPARRIVAL";

               /// <summary>
               /// Property for VendorItemNumber
               /// </summary>
               public const string VendorItemNumber = "VENDITEMNO";

               /// <summary>
               /// Property for CommentsInstructions
               /// </summary>
               public const string CommentsInstructions = "HASCOMMENT";

               /// <summary>
               /// Property for UnitOfMeasure
               /// </summary>
               public const string UnitOfMeasure = "ORDERUNIT";

               /// <summary>
               /// Property for OrderUnitConversion
               /// </summary>
               public const string OrderUnitConversion = "ORDERCONV";

               /// <summary>
               /// Property for OrderUnitDecimals
               /// </summary>
               public const string OrderUnitDecimals = "ORDERDECML";

               /// <summary>
               /// Property for StockUnitDecimals
               /// </summary>
               public const string StockUnitDecimals = "STOCKDECML";

               /// <summary>
               /// Property for QuantityOrdered
               /// </summary>
               public const string QuantityOrdered = "OQORDERED";

               /// <summary>
               /// Property for DropShip
               /// </summary>
               public const string DropShip = "HASDROPSHI";

               /// <summary>
               /// Property for DropShipType
               /// </summary>
               public const string DropShipType = "DROPTYPE";

               /// <summary>
               /// Property for DropShipCustomer
               /// </summary>
               public const string DropShipCustomer = "IDCUST";

               /// <summary>
               /// Property for CustomerShipToAddress
               /// </summary>
               public const string CustomerShipToAddress = "IDCUSTSHPT";

               /// <summary>
               /// Property for DropShipLocation
               /// </summary>
               public const string DropShipLocation = "DLOCATION";

               /// <summary>
               /// Property for DropShipDescription
               /// </summary>
               public const string DropShipDescription = "DESC";

               /// <summary>
               /// Property for DropShipAddress1
               /// </summary>
               public const string DropShipAddress1 = "ADDRESS1";

               /// <summary>
               /// Property for DropShipAddress2
               /// </summary>
               public const string DropShipAddress2 = "ADDRESS2";

               /// <summary>
               /// Property for DropShipAddress3
               /// </summary>
               public const string DropShipAddress3 = "ADDRESS3";

               /// <summary>
               /// Property for DropShipAddress4
               /// </summary>
               public const string DropShipAddress4 = "ADDRESS4";

               /// <summary>
               /// Property for DropShipCity
               /// </summary>
               public const string DropShipCity = "CITY";

               /// <summary>
               /// Property for DropShipStateProvince
               /// </summary>
               public const string DropShipStateProvince = "STATE";

               /// <summary>
               /// Property for DropShipZipPostalCode
               /// </summary>
               public const string DropShipZipPostalCode = "ZIP";

               /// <summary>
               /// Property for DropShipCountry
               /// </summary>
               public const string DropShipCountry = "COUNTRY";

               /// <summary>
               /// Property for DropShipPhoneNumber
               /// </summary>
               public const string DropShipPhoneNumber = "PHONE";

               /// <summary>
               /// Property for DropShipFaxNumber
               /// </summary>
               public const string DropShipFaxNumber = "FAX";

               /// <summary>
               /// Property for DropShipContact
               /// </summary>
               public const string DropShipContact = "CONTACT";

               /// <summary>
               /// Property for StockItem
               /// </summary>
               public const string StockItem = "STOCKITEM";

               /// <summary>
               /// Property for DropShipEmail
               /// </summary>
               public const string DropShipEmail = "EMAIL";

               /// <summary>
               /// Property for DropShipContactPhone
               /// </summary>
               public const string DropShipContactPhone = "PHONEC";

               /// <summary>
               /// Property for DropShipContactFax
               /// </summary>
               public const string DropShipContactFax = "FAXC";

               /// <summary>
               /// Property for DropShipContactEmail
               /// </summary>
               public const string DropShipContactEmail = "EMAILC";

               /// <summary>
               /// Property for ManufacturersItemNumber
               /// </summary>
               public const string ManufacturersItemNumber = "MANITEMNO";

               /// <summary>
               /// Property for OptionalFields
               /// </summary>
               public const string OptionalFields = "VALUES";

               /// <summary>
               /// Property for Contract
               /// </summary>
               public const string Contract = "CONTRACT";

               /// <summary>
               /// Property for Project
               /// </summary>
               public const string Project = "PROJECT";

               /// <summary>
               /// Property for Category
               /// </summary>
               public const string Category = "CCATEGORY";

               /// <summary>
               /// Property for CostClass
               /// </summary>
               public const string CostClass = "COSTCLASS";

               /// <summary>
               /// Property for StockingQuantityOrdered
               /// </summary>
               public const string StockingQuantityOrdered = "SQORDERED";

               /// <summary>
               /// Property for VendorOnHold
               /// </summary>
               public const string VendorOnHold = "VDONHOLD";

               /// <summary>
               /// Property for UseICVendor
               /// </summary>
               public const string UseICVendor = "USEVDTYPE";

               /// <summary>
               /// Property for ICVDCODE
               /// </summary>               
               // ReSharper disable once UnusedMember.Global              
               // ReSharper disable once InconsistentNaming
              public const string ICVDCODE = "ICVDCODE";

               /// <summary>
               /// Property for Completed
               /// </summary>
               public const string Completed = "ISCOMPLETE";

               /// <summary>
               /// Property for LinesComplete
               /// </summary>
               public const string LinesComplete = "LINECMPL";

               /// <summary>
               /// Property for IsRecordActive
               /// </summary>
               public const string IsRecordActive = "ISACTIVE";

               /// <summary>
               /// Property for Line
               /// </summary>
               public const string Line = "LINE";

               /// <summary>
               /// Property for MapManufacturersItemNumber
               /// </summary>
               public const string MapManufacturersItemNumber = "MAPMANITEM";

               /// <summary>
               /// Property for Command
               /// </summary>
               public const string Command = "PROCESSCMD";

               /// <summary>
               /// Property for ProjectStyle
               /// </summary>
               public const string ProjectStyle = "CONTSTYLE";

               /// <summary>
               /// Property for ProjectType
               /// </summary>
               public const string ProjectType = "PROJTYPE";

               /// <summary>
               /// Property for UnformattedContractCode
               /// </summary>
               public const string UnformattedContractCode = "UFMTCONTNO";

               /// <summary>
               /// Property for UnitCost
               /// </summary>
               public const string UnitCost = "UNITCOST";

               /// <summary>
               /// Property for UnitCostIsManual
               /// </summary>
               public const string UnitCostIsManual = "UCISMANUAL";

               /// <summary>
               /// Property for CopyCostToPurchaseOrder
               /// </summary>
               public const string CopyCostToPurchaseOrder = "CPCOSTTOPO";

               /// <summary>
               /// Property for ExtendedCost
               /// </summary>
               public const string ExtendedCost = "EXTENDED";

               /// <summary>
               /// Property for FunctionalExtended
               /// </summary>
               public const string FunctionalExtended = "FCEXTENDED";

               /// <summary>
               /// Property for DiscountAmount
               /// </summary>
               public const string DiscountAmount = "DISCOUNT";

               /// <summary>
               /// Property for DiscountPercentage
               /// </summary>
               public const string DiscountPercentage = "DISCPCT";

               /// <summary>
               /// Property for UnitWeight
               /// </summary>
               public const string UnitWeight = "UNITWEIGHT";

               /// <summary>
               /// Property for ExtendedWeight
               /// </summary>
               public const string ExtendedWeight = "EXTWEIGHT";

               /// <summary>
               /// Property for WeightUnitOfMeasure
               /// </summary>
               public const string WeightUnitOfMeasure = "WEIGHTUNIT";

               /// <summary>
               /// Property for WeightConversion
               /// </summary>
               public const string WeightConversion = "WEIGHTCONV";

               /// <summary>
               /// Property for DefaultUnitWeight
               /// </summary>
               public const string DefaultUnitWeight = "DEFUWEIGHT";

               /// <summary>
               /// Property for DefaultExtendedWeight
               /// </summary>
               public const string DefaultExtendedWeight = "DEFEXTWGHT";

               /// <summary>
               /// Property for NetExtendedCost
               /// </summary>
               public const string NetExtendedCost = "NETXTENDED";

               /// <summary>
               /// Property for Lines
               /// </summary>
               public const string Lines = "LINES";

               /// <summary>
               /// Property for Currency
               /// </summary>
               public const string Currency = "CURRENCY";

               /// <summary>
               /// Property for CurrencyDescription
               /// </summary>
               public const string CurrencyDescription = "CURRENCYD";

               /// <summary>
               /// Property for ExchangeRate
               /// </summary>
               public const string ExchangeRate = "RATE";

               /// <summary>
               /// Property for ExchangeRateExists
               /// </summary>
               public const string ExchangeRateExists = "RATEEXISTS";

               /// <summary>
               /// Property for RateType
               /// </summary>
               public const string RateType = "RATETYPE";

               /// <summary>
               /// Property for RateTypeDescription
               /// </summary>
               public const string RateTypeDescription = "RATETYPED";

               /// <summary>
               /// Property for RateDate
               /// </summary>
               public const string RateDate = "RATEDATE";

               /// <summary>
               /// Property for RateOperation
               /// </summary>
               public const string RateOperation = "RATEOPER";

               /// <summary>
               /// Property for CostDateForContract
               /// </summary>
               public const string CostDateForContract = "COSTDATE";

               /// <summary>
               /// Property for DetailNumber
               /// </summary>
               public const string DetailNumber = "DETAILNUM";
          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of RequisitionLine Constants
          /// </summary>
          public class Index
          {
               /// <summary>
               /// Property Indexer for RequisitionSequenceKey
               /// </summary>
               public const int RequisitionSequenceKey = 1;

               /// <summary>
               /// Property Indexer for LineNumber
               /// </summary>
               public const int LineNumber = 2;

               /// <summary>
               /// Property Indexer for RequisitionLineSequence
               /// </summary>
               public const int RequisitionLineSequence = 3;

               /// <summary>
               /// Property Indexer for LineOrdered
               /// </summary>
               public const int LineOrdered = 4;

               /// <summary>
               /// Property Indexer for RequisitionCommentSequence
               /// </summary>
               public const int RequisitionCommentSequence = 5;

               /// <summary>
               /// Property Indexer for OrderNumber
               /// </summary>
               public const int OrderNumber = 6;

               /// <summary>
               /// Property Indexer for VendorExists
               /// </summary>
               public const int VendorExists = 7;

               /// <summary>
               /// Property Indexer for VDCODE
               /// </summary>               
               // ReSharper disable once InconsistentNaming
              public const int VDCODE = 8;

               /// <summary>
               /// Property Indexer for Name
               /// </summary>
               public const int Name = 9;

               /// <summary>
               /// Property Indexer for StoredInDatabaseTable
               /// </summary>
               public const int StoredInDatabaseTable = 10;

               /// <summary>
               /// Property Indexer for CompletionStatus
               /// </summary>
               public const int CompletionStatus = 11;

               /// <summary>
               /// Property Indexer for DateCompleted
               /// </summary>
               public const int DateCompleted = 12;

               /// <summary>
               /// Property Indexer for ItemExists
               /// </summary>
               public const int ItemExists = 13;

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 14;

               /// <summary>
               /// Property Indexer for Location
               /// </summary>
               public const int Location = 15;

               /// <summary>
               /// Property Indexer for ItemDescription
               /// </summary>
               public const int ItemDescription = 16;

               /// <summary>
               /// Property Indexer for ExpectedArrivalDate
               /// </summary>
               public const int ExpectedArrivalDate = 17;

               /// <summary>
               /// Property Indexer for VendorItemNumber
               /// </summary>
               public const int VendorItemNumber = 18;

               /// <summary>
               /// Property Indexer for CommentsInstructions
               /// </summary>
               public const int CommentsInstructions = 19;

               /// <summary>
               /// Property Indexer for UnitOfMeasure
               /// </summary>
               public const int UnitOfMeasure = 20;

               /// <summary>
               /// Property Indexer for OrderUnitConversion
               /// </summary>
               public const int OrderUnitConversion = 21;

               /// <summary>
               /// Property Indexer for OrderUnitDecimals
               /// </summary>
               public const int OrderUnitDecimals = 22;

               /// <summary>
               /// Property Indexer for StockUnitDecimals
               /// </summary>
               public const int StockUnitDecimals = 23;

               /// <summary>
               /// Property Indexer for QuantityOrdered
               /// </summary>
               public const int QuantityOrdered = 24;

               /// <summary>
               /// Property Indexer for DropShip
               /// </summary>
               public const int DropShip = 25;

               /// <summary>
               /// Property Indexer for DropShipType
               /// </summary>
               public const int DropShipType = 26;

               /// <summary>
               /// Property Indexer for DropShipCustomer
               /// </summary>
               public const int DropShipCustomer = 27;

               /// <summary>
               /// Property Indexer for CustomerShipToAddress
               /// </summary>
               public const int CustomerShipToAddress = 28;

               /// <summary>
               /// Property Indexer for DropShipLocation
               /// </summary>
               public const int DropShipLocation = 29;

               /// <summary>
               /// Property Indexer for DropShipDescription
               /// </summary>
               public const int DropShipDescription = 30;

               /// <summary>
               /// Property Indexer for DropShipAddress1
               /// </summary>
               public const int DropShipAddress1 = 31;

               /// <summary>
               /// Property Indexer for DropShipAddress2
               /// </summary>
               public const int DropShipAddress2 = 32;

               /// <summary>
               /// Property Indexer for DropShipAddress3
               /// </summary>
               public const int DropShipAddress3 = 33;

               /// <summary>
               /// Property Indexer for DropShipAddress4
               /// </summary>
               public const int DropShipAddress4 = 34;

               /// <summary>
               /// Property Indexer for DropShipCity
               /// </summary>
               public const int DropShipCity = 35;

               /// <summary>
               /// Property Indexer for DropShipStateProvince
               /// </summary>
               public const int DropShipStateProvince = 36;

               /// <summary>
               /// Property Indexer for DropShipZipPostalCode
               /// </summary>
               public const int DropShipZipPostalCode = 37;

               /// <summary>
               /// Property Indexer for DropShipCountry
               /// </summary>
               public const int DropShipCountry = 38;

               /// <summary>
               /// Property Indexer for DropShipPhoneNumber
               /// </summary>
               public const int DropShipPhoneNumber = 39;

               /// <summary>
               /// Property Indexer for DropShipFaxNumber
               /// </summary>
               public const int DropShipFaxNumber = 40;

               /// <summary>
               /// Property Indexer for DropShipContact
               /// </summary>
               public const int DropShipContact = 41;

               /// <summary>
               /// Property Indexer for StockItem
               /// </summary>
               public const int StockItem = 42;

               /// <summary>
               /// Property Indexer for DropShipEmail
               /// </summary>
               public const int DropShipEmail = 43;

               /// <summary>
               /// Property Indexer for DropShipContactPhone
               /// </summary>
               public const int DropShipContactPhone = 44;

               /// <summary>
               /// Property Indexer for DropShipContactFax
               /// </summary>
               public const int DropShipContactFax = 45;

               /// <summary>
               /// Property Indexer for DropShipContactEmail
               /// </summary>
               public const int DropShipContactEmail = 46;

               /// <summary>
               /// Property Indexer for ManufacturersItemNumber
               /// </summary>
               public const int ManufacturersItemNumber = 47;

               /// <summary>
               /// Property Indexer for OptionalFields
               /// </summary>
               public const int OptionalFields = 48;

               /// <summary>
               /// Property Indexer for Contract
               /// </summary>
               public const int Contract = 49;

               /// <summary>
               /// Property Indexer for Project
               /// </summary>
               public const int Project = 50;

               /// <summary>
               /// Property Indexer for Category
               /// </summary>
               public const int Category = 51;

               /// <summary>
               /// Property Indexer for CostClass
               /// </summary>
               public const int CostClass = 52;

               /// <summary>
               /// Property Indexer for StockingQuantityOrdered
               /// </summary>
               public const int StockingQuantityOrdered = 101;

               /// <summary>
               /// Property Indexer for VendorOnHold
               /// </summary>
               public const int VendorOnHold = 102;

               /// <summary>
               /// Property Indexer for UseICVendor
               /// </summary>
               public const int UseICVendor = 103;

               /// <summary>
               /// Property Indexer for ICVDCODE
               /// </summary>               
               // ReSharper disable once UnusedMember.Global              
               // ReSharper disable once InconsistentNaming
              public const int ICVDCODE = 104;

               /// <summary>
               /// Property Indexer for Completed
               /// </summary>
               public const int Completed = 105;

               /// <summary>
               /// Property Indexer for LinesComplete
               /// </summary>
               public const int LinesComplete = 106;

               /// <summary>
               /// Property Indexer for IsRecordActive
               /// </summary>
               public const int IsRecordActive = 107;

               /// <summary>
               /// Property Indexer for Line
               /// </summary>
               public const int Line = 108;

               /// <summary>
               /// Property Indexer for MapManufacturersItemNumber
               /// </summary>
               public const int MapManufacturersItemNumber = 109;

               /// <summary>
               /// Property Indexer for Command
               /// </summary>
               public const int Command = 110;

               /// <summary>
               /// Property Indexer for ProjectStyle
               /// </summary>
               public const int ProjectStyle = 111;

               /// <summary>
               /// Property Indexer for ProjectType
               /// </summary>
               public const int ProjectType = 112;

               /// <summary>
               /// Property Indexer for UnformattedContractCode
               /// </summary>
               public const int UnformattedContractCode = 113;

               /// <summary>
               /// Property Indexer for UnitCost
               /// </summary>
               public const int UnitCost = 201;

               /// <summary>
               /// Property Indexer for UnitCostIsManual
               /// </summary>
               public const int UnitCostIsManual = 202;

               /// <summary>
               /// Property Indexer for CopyCostToPurchaseOrder
               /// </summary>
               public const int CopyCostToPurchaseOrder = 203;

               /// <summary>
               /// Property Indexer for ExtendedCost
               /// </summary>
               public const int ExtendedCost = 204;

               /// <summary>
               /// Property Indexer for FunctionalExtended
               /// </summary>
               public const int FunctionalExtended = 205;

               /// <summary>
               /// Property Indexer for DiscountAmount
               /// </summary>
               public const int DiscountAmount = 206;

               /// <summary>
               /// Property Indexer for DiscountPercentage
               /// </summary>
               public const int DiscountPercentage = 207;

               /// <summary>
               /// Property Indexer for UnitWeight
               /// </summary>
               public const int UnitWeight = 208;

               /// <summary>
               /// Property Indexer for ExtendedWeight
               /// </summary>
               public const int ExtendedWeight = 209;

               /// <summary>
               /// Property Indexer for WeightUnitOfMeasure
               /// </summary>
               public const int WeightUnitOfMeasure = 210;

               /// <summary>
               /// Property Indexer for WeightConversion
               /// </summary>
               public const int WeightConversion = 211;

               /// <summary>
               /// Property Indexer for DefaultUnitWeight
               /// </summary>
               public const int DefaultUnitWeight = 212;

               /// <summary>
               /// Property Indexer for DefaultExtendedWeight
               /// </summary>
               public const int DefaultExtendedWeight = 213;

               /// <summary>
               /// Property Indexer for NetExtendedCost
               /// </summary>
               public const int NetExtendedCost = 214;

               /// <summary>
               /// Property Indexer for Lines
               /// </summary>
               public const int Lines = 215;

               /// <summary>
               /// Property Indexer for Currency
               /// </summary>
               public const int Currency = 216;

               /// <summary>
               /// Property Indexer for CurrencyDescription
               /// </summary>
               public const int CurrencyDescription = 217;

               /// <summary>
               /// Property Indexer for ExchangeRate
               /// </summary>
               public const int ExchangeRate = 218;

               /// <summary>
               /// Property Indexer for ExchangeRateExists
               /// </summary>
               public const int ExchangeRateExists = 219;

               /// <summary>
               /// Property Indexer for RateType
               /// </summary>
               public const int RateType = 220;

               /// <summary>
               /// Property Indexer for RateTypeDescription
               /// </summary>
               public const int RateTypeDescription = 221;

               /// <summary>
               /// Property Indexer for RateDate
               /// </summary>
               public const int RateDate = 222;

               /// <summary>
               /// Property Indexer for RateOperation
               /// </summary>
               public const int RateOperation = 223;

               /// <summary>
               /// Property Indexer for CostDateForContract
               /// </summary>
               public const int CostDateForContract = 224;

               /// <summary>
               /// Property Indexer for DetailNumber
               /// </summary>
               public const int DetailNumber = 225;
          }
          #endregion

     }
}
