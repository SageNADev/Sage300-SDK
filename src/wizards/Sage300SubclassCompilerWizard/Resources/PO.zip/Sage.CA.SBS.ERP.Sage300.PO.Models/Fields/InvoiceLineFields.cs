// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using System.Collections.Generic;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of InvoiceLine Constants
    /// </summary>
    public partial class InvoiceLine
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string EntityName = "PO0430";

        /// <summary>
        /// Dynamic Attributes contain a reverse mapping of field and property
        /// </summary>
        [IgnoreExportImport]
        public static Dictionary<string, string> DynamicAttributes
        {
            get
            {
                return new Dictionary<string, string>
				{
					{"FULLYINV", "FullyInvoiced"},
					{"ITEMNO", "ItemNumber"},
					{"ITEMDESC", "ItemDescription"},
					{"LOCATION", "Location"},
					{"RQRECEIVED", "QuantityReceived"},
					{"RCPUNIT", "ReceiptUOM"},
					{"EXTENDED", "ExtendedCost"},
					{"DISCPCT", "DiscountPercentage"},
					{"DISCOUNT", "DiscountAmount"},
					{"NETXTENDED", "NetExtendedCost"},
					{"TXINCLUDED", "TaxIncluded"},
					{"TXBASEALLO", "NetOfTax"},
					{"TXALLOAMT", "AllocatedTax"},
					{"WEIGHTUNIT", "WeightUnitOfMeasure"},
					{"UNITWEIGHT", "UnitWeight"},
					{"EXTWEIGHT", "ExtendedWeight"},
					{"VENDITEMNO", "VendorItemNumber"},
					{"GLACEXPENS", "ExpenseAccount"},
					{"GLNONSTKCR", "NonStockClearingAccount"},
					{"RCPNUMBER", "ReceiptNumber"},
					{"HASCOMMENT", "Comments"},
					{"MANITEMNO", "ManufacturersItemNumber"},
					{"VALUES", "OptionalFields"},
					{"TERMDISCBL", "PaymentDiscountable"},
					{"UNITCOST", "UnitCost"},
					{"OEONUMBER", "OrderNumber"},
                    {"BILLCURDEC", "BillingCurrencyDecimal"},
                    {"BILLRATE", "BillingRate"},
                    {"RTGPERCENT", "RetainagePercentage"},
                    {"RTGDAYS", "RetentionPeriod"},
                    {"RTGAMOUNT", "RetainageAmount"},
                    {"RTGDATEDUE", "RetainageDueDate"}
                };
            }
        }

        #region Properties

        /// <summary>
        /// Contains list of InvoiceLine Constants
        /// </summary>
        public class Fields : BaseFields { }

        #endregion

        #region Properties

        /// <summary>
        /// Contains list of InvoiceLine Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for InvoiceSequenceKey
            /// </summary>
            public const int InvoiceSequenceKey = 1;

            /// <summary>
            /// Property Indexer for DetailLineNumber
            /// </summary>
            public const int DetailLineNumber = 2;

            /// <summary>
            /// Property Indexer for InvoiceLineSequence
            /// </summary>
            public const int InvoiceLineSequence = 3;

            /// <summary>
            /// Property Indexer for InvoiceCommentSequence
            /// </summary>
            public const int InvoiceCommentSequence = 4;

            /// <summary>
            /// Property Indexer for OrderNumber
            /// </summary>
            public const int OrderNumber = 5;

            /// <summary>
            /// Property Indexer for StoredInDatabaseTable
            /// </summary>
            public const int StoredInDatabaseTable = 6;

            /// <summary>
            /// Property Indexer for PostedToIC
            /// </summary>
            public const int PostedToIC = 7;

            /// <summary>
            /// Property Indexer for CompletionStatus
            /// </summary>
            public const int CompletionStatus = 8;

            /// <summary>
            /// Property Indexer for DateCompleted
            /// </summary>
            public const int DateCompleted = 9;

            /// <summary>
            /// Property Indexer for ReceiptSequenceKey
            /// </summary>
            public const int ReceiptSequenceKey = 10;

            /// <summary>
            /// Property Indexer for ReceiptLineSequence
            /// </summary>
            public const int ReceiptLineSequence = 11;

            /// <summary>
            /// Property Indexer for ItemExists
            /// </summary>
            public const int ItemExists = 12;

            /// <summary>
            /// Property Indexer for ItemNumber
            /// </summary>
            public const int ItemNumber = 13;

            /// <summary>
            /// Property Indexer for Location
            /// </summary>
            public const int Location = 14;

            /// <summary>
            /// Property Indexer for ItemDescription
            /// </summary>
            public const int ItemDescription = 15;

            /// <summary>
            /// Property Indexer for VendorItemNumber
            /// </summary>
            public const int VendorItemNumber = 16;

            /// <summary>
            /// Property Indexer for Comments
            /// </summary>
            public const int Comments = 17;

            /// <summary>
            /// Property Indexer for ORDERUNIT
            /// </summary>
            public const int OrderUnit = 18;

            /// <summary>
            /// Property Indexer for OrderUnitConversion
            /// </summary>
            public const int OrderUnitConversion = 19;

            /// <summary>
            /// Property Indexer for OrderUnitDecimals
            /// </summary>
            public const int OrderUnitDecimals = 20;

            /// <summary>
            /// Property Indexer for ReceiptUOM
            /// </summary>
            public const int ReceiptUOM = 21;

            /// <summary>
            /// Property Indexer for ReceivingConversionFactor
            /// </summary>
            public const int ReceivingConversionFactor = 22;

            /// <summary>
            /// Property Indexer for ReceivingUnitDecimals
            /// </summary>
            public const int ReceivingUnitDecimals = 23;

            /// <summary>
            /// Property Indexer for StockUnitDecimals
            /// </summary>
            public const int StockUnitDecimals = 24;

            /// <summary>
            /// Property Indexer for QuantityReceived
            /// </summary>
            public const int QuantityReceived = 25;

            /// <summary>
            /// Property Indexer for StockingQuantityReceived
            /// </summary>
            public const int StockingQuantityReceived = 26;

            /// <summary>
            /// Property Indexer for OrderedQuantityReceived
            /// </summary>
            public const int OrderedQuantityReceived = 27;

            /// <summary>
            /// Property Indexer for UnitWeight
            /// </summary>
            public const int UnitWeight = 28;

            /// <summary>
            /// Property Indexer for ExtendedWeight
            /// </summary>
            public const int ExtendedWeight = 29;

            /// <summary>
            /// Property Indexer for UnitCost
            /// </summary>
            public const int UnitCost = 30;

            /// <summary>
            /// Property Indexer for ExtendedCost
            /// </summary>
            public const int ExtendedCost = 31;

            /// <summary>
            /// Property Indexer for TaxBase1
            /// </summary>
            public const int TaxBase1 = 32;

            /// <summary>
            /// Property Indexer for TaxBase2
            /// </summary>
            public const int TaxBase2 = 33;

            /// <summary>
            /// Property Indexer for TaxBase3
            /// </summary>
            public const int TaxBase3 = 34;

            /// <summary>
            /// Property Indexer for TaxBase4
            /// </summary>
            public const int TaxBase4 = 35;

            /// <summary>
            /// Property Indexer for TaxBase5
            /// </summary>
            public const int TaxBase5 = 36;

            /// <summary>
            /// Property Indexer for TaxClass1
            /// </summary>
            public const int TaxClass1 = 37;

            /// <summary>
            /// Property Indexer for TaxClass2
            /// </summary>
            public const int TaxClass2 = 38;

            /// <summary>
            /// Property Indexer for TaxClass3
            /// </summary>
            public const int TaxClass3 = 39;

            /// <summary>
            /// Property Indexer for TaxClass4
            /// </summary>
            public const int TaxClass4 = 40;

            /// <summary>
            /// Property Indexer for TaxClass5
            /// </summary>
            public const int TaxClass5 = 41;

            /// <summary>
            /// Property Indexer for TaxRate1
            /// </summary>
            public const int TaxRate1 = 42;

            /// <summary>
            /// Property Indexer for TaxRate2
            /// </summary>
            public const int TaxRate2 = 43;

            /// <summary>
            /// Property Indexer for TaxRate3
            /// </summary>
            public const int TaxRate3 = 44;

            /// <summary>
            /// Property Indexer for TaxRate4
            /// </summary>
            public const int TaxRate4 = 45;

            /// <summary>
            /// Property Indexer for TaxRate5
            /// </summary>
            public const int TaxRate5 = 46;

            /// <summary>
            /// Property Indexer for TaxIncludable1
            /// </summary>
            public const int TaxIncludable1 = 47;

            /// <summary>
            /// Property Indexer for TaxIncludable2
            /// </summary>
            public const int TaxIncludable2 = 48;

            /// <summary>
            /// Property Indexer for TaxIncludable3
            /// </summary>
            public const int TaxIncludable3 = 49;

            /// <summary>
            /// Property Indexer for TaxIncludable4
            /// </summary>
            public const int TaxIncludable4 = 50;

            /// <summary>
            /// Property Indexer for TaxIncludable5
            /// </summary>
            public const int TaxIncludable5 = 51;

            /// <summary>
            /// Property Indexer for TaxAmount1
            /// </summary>
            public const int TaxAmount1 = 52;

            /// <summary>
            /// Property Indexer for TaxAmount2
            /// </summary>
            public const int TaxAmount2 = 53;

            /// <summary>
            /// Property Indexer for TaxAmount3
            /// </summary>
            public const int TaxAmount3 = 54;

            /// <summary>
            /// Property Indexer for TaxAmount4
            /// </summary>
            public const int TaxAmount4 = 55;

            /// <summary>
            /// Property Indexer for TaxAmount5
            /// </summary>
            public const int TaxAmount5 = 56;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount1
            /// </summary>
            public const int TaxRecoverableAmount1 = 57;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount2
            /// </summary>
            public const int TaxRecoverableAmount2 = 58;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount3
            /// </summary>
            public const int TaxRecoverableAmount3 = 59;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount4
            /// </summary>
            public const int TaxRecoverableAmount4 = 60;

            /// <summary>
            /// Property Indexer for TaxRecoverableAmount5
            /// </summary>
            public const int TaxRecoverableAmount5 = 61;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount1
            /// </summary>
            public const int TaxExpenseAmount1 = 62;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount2
            /// </summary>
            public const int TaxExpenseAmount2 = 63;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount3
            /// </summary>
            public const int TaxExpenseAmount3 = 64;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount4
            /// </summary>
            public const int TaxExpenseAmount4 = 65;

            /// <summary>
            /// Property Indexer for TaxExpenseAmount5
            /// </summary>
            public const int TaxExpenseAmount5 = 66;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount1
            /// </summary>
            public const int TaxAllocatedAmount1 = 67;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount2
            /// </summary>
            public const int TaxAllocatedAmount2 = 68;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount3
            /// </summary>
            public const int TaxAllocatedAmount3 = 69;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount4
            /// </summary>
            public const int TaxAllocatedAmount4 = 70;

            /// <summary>
            /// Property Indexer for TaxAllocatedAmount5
            /// </summary>
            public const int TaxAllocatedAmount5 = 71;

            /// <summary>
            /// Property Indexer for NetOfTax
            /// </summary>
            public const int NetOfTax = 72;

            /// <summary>
            /// Property Indexer for TaxIncluded
            /// </summary>
            public const int TaxIncluded = 73;

            /// <summary>
            /// Property Indexer for TaxExcluded
            /// </summary>
            public const int TaxExcluded = 74;

            /// <summary>
            /// Property Indexer for TotalTax
            /// </summary>
            public const int TotalTax = 75;

            /// <summary>
            /// Property Indexer for RecoverableTax
            /// </summary>
            public const int RecoverableTax = 76;

            /// <summary>
            /// Property Indexer for ExpensedTax
            /// </summary>
            public const int ExpensedTax = 77;

            /// <summary>
            /// Property Indexer for AllocatedTax
            /// </summary>
            public const int AllocatedTax = 78;

            /// <summary>
            /// Property Indexer for FuncNetOfTax
            /// </summary>
            public const int FuncNetOfTax = 79;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount1
            /// </summary>
            public const int FuncTaxIncludedAmount1 = 80;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount2
            /// </summary>
            public const int FuncTaxIncludedAmount2 = 81;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount3
            /// </summary>
            public const int FuncTaxIncludedAmount3 = 82;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount4
            /// </summary>
            public const int FuncTaxIncludedAmount4 = 83;

            /// <summary>
            /// Property Indexer for FuncTaxIncludedAmount5
            /// </summary>
            public const int FuncTaxIncludedAmount5 = 84;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount1
            /// </summary>
            public const int FuncTaxRecoverableAmount1 = 85;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount2
            /// </summary>
            public const int FuncTaxRecoverableAmount2 = 86;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount3
            /// </summary>
            public const int FuncTaxRecoverableAmount3 = 87;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount4
            /// </summary>
            public const int FuncTaxRecoverableAmount4 = 88;

            /// <summary>
            /// Property Indexer for FuncTaxRecoverableAmount5
            /// </summary>
            public const int FuncTaxRecoverableAmount5 = 89;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount1
            /// </summary>
            public const int FuncTaxExpenseAmount1 = 90;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount2
            /// </summary>
            public const int FuncTaxExpenseAmount2 = 91;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount3
            /// </summary>
            public const int FuncTaxExpenseAmount3 = 92;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount4
            /// </summary>
            public const int FuncTaxExpenseAmount4 = 93;

            /// <summary>
            /// Property Indexer for FuncTaxExpenseAmount5
            /// </summary>
            public const int FuncTaxExpenseAmount5 = 94;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount1
            /// </summary>
            public const int FuncTaxAllocatedAmount1 = 95;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount2
            /// </summary>
            public const int FuncTaxAllocatedAmount2 = 96;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount3
            /// </summary>
            public const int FuncTaxAllocatedAmount3 = 97;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount4
            /// </summary>
            public const int FuncTaxAllocatedAmount4 = 98;

            /// <summary>
            /// Property Indexer for FuncTaxAllocatedAmount5
            /// </summary>
            public const int FuncTaxAllocatedAmount5 = 99;

            /// <summary>
            /// Property Indexer for FuncExtendedAmount
            /// </summary>
            public const int FuncExtendedAmount = 100;

            /// <summary>
            /// Property Indexer for ExpenseAccount
            /// </summary>
            public const int ExpenseAccount = 101;

            /// <summary>
            /// Property Indexer for ManualProration
            /// </summary>
            public const int ManualProration = 102;

            /// <summary>
            /// Property Indexer for StockItem
            /// </summary>
            public const int StockItem = 103;

            /// <summary>
            /// Property Indexer for ReceiptNumber
            /// </summary>
            public const int ReceiptNumber = 104;

            /// <summary>
            /// Property Indexer for PurchaseOrderSequenceKey
            /// </summary>
            public const int PurchaseOrderSequenceKey = 105;

            /// <summary>
            /// Property Indexer for PurchaseOrderLineSequence
            /// </summary>
            public const int PurchaseOrderLineSequence = 106;

            /// <summary>
            /// Property Indexer for PurchaseOrderNumber
            /// </summary>
            public const int PurchaseOrderNumber = 107;

            /// <summary>
            /// Property Indexer for NonStockClearingAccount
            /// </summary>
            public const int NonStockClearingAccount = 108;

            /// <summary>
            /// Property Indexer for ManufacturersItemNumber
            /// </summary>
            public const int ManufacturersItemNumber = 109;

            /// <summary>
            /// Property Indexer for DiscountPercentage
            /// </summary>
            public const int DiscountPercentage = 110;

            /// <summary>
            /// Property Indexer for DiscountAmount
            /// </summary>
            public const int DiscountAmount = 111;

            /// <summary>
            /// Property Indexer for FuncDiscountAmount
            /// </summary>
            public const int FuncDiscountAmount = 112;

            /// <summary>
            /// Property Indexer for PartInvOrigQtyReceived
            /// </summary>
            public const int PartInvOrigQtyReceived = 113;

            /// <summary>
            /// Property Indexer for PartInvPvQtyInvoicied
            /// </summary>
            public const int PartInvPvQtyInvoicied = 114;

            /// <summary>
            /// Property Indexer for PreviousInvoiceLines
            /// </summary>
            public const int PreviousInvoiceLines = 115;

            /// <summary>
            /// Property Indexer for FullyInvoiced
            /// </summary>
            public const int FullyInvoiced = 116;

            /// <summary>
            /// Property Indexer for OptionalFields
            /// </summary>
            public const int OptionalFields = 117;

            /// <summary>
            /// Property Indexer for PaymentDiscountable
            /// </summary>
            public const int PaymentDiscountable = 118;

            /// <summary>
            /// Property Indexer for Contract
            /// </summary>
            public const int Contract = 119;

            /// <summary>
            /// Property Indexer for Project
            /// </summary>
            public const int Project = 120;

            /// <summary>
            /// Property Indexer for Category
            /// </summary>
            public const int Category = 121;

            /// <summary>
            /// Property Indexer for CostClass
            /// </summary>
            public const int CostClass = 122;

            /// <summary>
            /// Property Indexer for BillingType
            /// </summary>
            public const int BillingType = 123;

            /// <summary>
            /// Property Indexer for BillingRate
            /// </summary>
            public const int BillingRate = 124;

            /// <summary>
            /// Property Indexer for BillingCurrency
            /// </summary>
            public const int BillingCurrency = 125;

            /// <summary>
            /// Property Indexer for ARItemNumber
            /// </summary>
            public const int ARItemNumber = 126;

            /// <summary>
            /// Property Indexer for ARUnitOfMeasure
            /// </summary>
            public const int ARUnitOfMeasure = 127;

            /// <summary>
            /// Property Indexer for RetainagePercentage
            /// </summary>
            public const int RetainagePercentage = 128;

            /// <summary>
            /// Property Indexer for RetentionPeriod
            /// </summary>
            public const int RetentionPeriod = 129;

            /// <summary>
            /// Property Indexer for RetainageAmount
            /// </summary>
            public const int RetainageAmount = 130;

            /// <summary>
            /// Property Indexer for RetainageDueDate
            /// </summary>
            public const int RetainageDueDate = 131;

            /// <summary>
            /// Property Indexer for RetainageAmountOverridden
            /// </summary>
            public const int RetainageAmountOverridden = 132;

            /// <summary>
            /// Property Indexer for RetainageDueDateOverridden
            /// </summary>
            public const int RetainageDueDateOverridden = 133;

            /// <summary>
            /// Property Indexer for TaxReportingAmount1
            /// </summary>
            public const int TaxReportingAmount1 = 134;

            /// <summary>
            /// Property Indexer for TaxReportingAmount2
            /// </summary>
            public const int TaxReportingAmount2 = 135;

            /// <summary>
            /// Property Indexer for TaxReportingAmount3
            /// </summary>
            public const int TaxReportingAmount3 = 136;

            /// <summary>
            /// Property Indexer for TaxReportingAmount4
            /// </summary>
            public const int TaxReportingAmount4 = 137;

            /// <summary>
            /// Property Indexer for TaxReportingAmount5
            /// </summary>
            public const int TaxReportingAmount5 = 138;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount1
            /// </summary>
            public const int TaxReportingAllocatedAmount1 = 139;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount2
            /// </summary>
            public const int TaxReportingAllocatedAmount2 = 140;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount3
            /// </summary>
            public const int TaxReportingAllocatedAmount3 = 141;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount4
            /// </summary>
            public const int TaxReportingAllocatedAmount4 = 142;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount5
            /// </summary>
            public const int TaxReportingAllocatedAmount5 = 143;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt1
            /// </summary>
            public const int TaxReportingRecoverableAmt1 = 144;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt2
            /// </summary>
            public const int TaxReportingRecoverableAmt2 = 145;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt3
            /// </summary>
            public const int TaxReportingRecoverableAmt3 = 146;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt4
            /// </summary>
            public const int TaxReportingRecoverableAmt4 = 147;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmt5
            /// </summary>
            public const int TaxReportingRecoverableAmt5 = 148;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount1
            /// </summary>
            public const int TaxReportingExpenseAmount1 = 149;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount2
            /// </summary>
            public const int TaxReportingExpenseAmount2 = 150;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount3
            /// </summary>
            public const int TaxReportingExpenseAmount3 = 151;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount4
            /// </summary>
            public const int TaxReportingExpenseAmount4 = 152;

            /// <summary>
            /// Property Indexer for TaxReportingExpenseAmount5
            /// </summary>
            public const int TaxReportingExpenseAmount5 = 153;

            /// <summary>
            /// Property Indexer for first
            /// </summary>
            public const int First = 161;

            /// <summary>
            /// Property Indexer for TaxClass1Description
            /// </summary>
            public const int TaxClass1Description = 162;

            /// <summary>
            /// Property Indexer for TaxClass2Description
            /// </summary>
            public const int TaxClass2Description = 163;

            /// <summary>
            /// Property Indexer for TaxClass3Description
            /// </summary>
            public const int TaxClass3Description = 164;

            /// <summary>
            /// Property Indexer for TaxClass4Description
            /// </summary>
            public const int TaxClass4Description = 165;

            /// <summary>
            /// Property Indexer for TaxClass5Description
            /// </summary>
            public const int TaxClass5Description = 166;

            /// <summary>
            /// Property Indexer for ExpenseAccountDescription
            /// </summary>
            public const int ExpenseAccountDescription = 167;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount1
            /// </summary>
            public const int IncludedTaxAmount1 = 168;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount2
            /// </summary>
            public const int IncludedTaxAmount2 = 169;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount3
            /// </summary>
            public const int IncludedTaxAmount3 = 170;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount4
            /// </summary>
            public const int IncludedTaxAmount4 = 171;

            /// <summary>
            /// Property Indexer for IncludedTaxAmount5
            /// </summary>
            public const int IncludedTaxAmount5 = 172;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount1
            /// </summary>
            public const int ExcludedTaxAmount1 = 173;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount2
            /// </summary>
            public const int ExcludedTaxAmount2 = 174;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount3
            /// </summary>
            public const int ExcludedTaxAmount3 = 175;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount4
            /// </summary>
            public const int ExcludedTaxAmount4 = 176;

            /// <summary>
            /// Property Indexer for ExcludedTaxAmount5
            /// </summary>
            public const int ExcludedTaxAmount5 = 177;

            /// <summary>
            /// Property Indexer for Completed
            /// </summary>
            public const int Completed = 178;

            /// <summary>
            /// Property Indexer for LinesTaxCalculationSees
            /// </summary>
            public const int LinesTaxCalculationSees = 179;

            /// <summary>
            /// Property Indexer for LinesComplete
            /// </summary>
            public const int LinesComplete = 180;

            /// <summary>
            /// Property Indexer for Line
            /// </summary>
            public const int Line = 181;

            /// <summary>
            /// Property Indexer for ExtendedStdCostInSrcCurr
            /// </summary>
            public const int ExtendedStdCostInSrcCurr = 182;

            /// <summary>
            /// Property Indexer for ExtendedMRCostInSrcCurr
            /// </summary>
            public const int ExtendedMrCostInSrcCurr = 183;

            /// <summary>
            /// Property Indexer for ExtendedCost1InSrcCurr
            /// </summary>
            public const int ExtendedCost1InSrcCurr = 184;

            /// <summary>
            /// Property Indexer for ExtendedCost2InSrcCurr
            /// </summary>
            public const int ExtendedCost2InSrcCurr = 185;

            /// <summary>
            /// Property Indexer for NonStockClearingAccountDesc
            /// </summary>
            public const int NonStockClearingAccountDesc = 186;

            /// <summary>
            /// Property Indexer for NetExtendedCost
            /// </summary>
            public const int NetExtendedCost = 187;

            /// <summary>
            /// Property Indexer for PartInvOrigStkgQtyRec
            /// </summary>
            public const int PartInvOrigStkgQtyRec = 188;

            /// <summary>
            /// Property Indexer for PartInvStkgPvQtyInv
            /// </summary>
            public const int PartInvStkgPvQtyInv = 189;

            /// <summary>
            /// Property Indexer for PartInvOrdPvQtyInv
            /// </summary>
            public const int PartInvOrdPvQtyInv = 190;

            /// <summary>
            /// Property Indexer for PartInvStkgICQtyAdj
            /// </summary>
            public const int PartInvStkgICQtyAdj = 191;

            /// <summary>
            /// Property Indexer for RCPLREV
            /// </summary>
            public const int RcpLrev = 192;

            /// <summary>
            /// Property Indexer for Command
            /// </summary>
            public const int Command = 193;

            /// <summary>
            /// Property Indexer for PaymentDiscountBaseWithTax
            /// </summary>
            public const int PaymentDiscountBaseWithTax = 194;

            /// <summary>
            /// Property Indexer for PaymentDiscountBaseWithoutTa
            /// </summary>
            public const int PaymentDiscountBaseWithoutTa = 195;

            /// <summary>
            /// Property Indexer for ProjectStyle
            /// </summary>
            public const int ProjectStyle = 196;

            /// <summary>
            /// Property Indexer for ProjectType
            /// </summary>
            public const int ProjectType = 197;

            /// <summary>
            /// Property Indexer for AccountingMethod
            /// </summary>
            public const int AccountingMethod = 198;

            /// <summary>
            /// Property Indexer for UnformattedContractCode
            /// </summary>
            public const int UnformattedContractCode = 199;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount1
            /// </summary>
            public const int TaxReportingIncludedAmount1 = 200;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount2
            /// </summary>
            public const int TaxReportingIncludedAmount2 = 201;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount3
            /// </summary>
            public const int TaxReportingIncludedAmount3 = 202;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount4
            /// </summary>
            public const int TaxReportingIncludedAmount4 = 203;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount5
            /// </summary>
            public const int TaxReportingIncludedAmount5 = 204;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount1
            /// </summary>
            public const int TaxReportingExcludedAmount1 = 205;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount2
            /// </summary>
            public const int TaxReportingExcludedAmount2 = 206;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount3
            /// </summary>
            public const int TaxReportingExcludedAmount3 = 207;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount4
            /// </summary>
            public const int TaxReportingExcludedAmount4 = 208;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount5
            /// </summary>
            public const int TaxReportingExcludedAmount5 = 209;

            /// <summary>
            /// Property Indexer for TaxReportingTotalAmount
            /// </summary>
            public const int TaxReportingTotalAmount = 210;

            /// <summary>
            /// Property Indexer for TaxReportingIncludedAmount
            /// </summary>
            public const int TaxReportingIncludedAmount = 211;

            /// <summary>
            /// Property Indexer for TaxReportingExcludedAmount
            /// </summary>
            public const int TaxReportingExcludedAmount = 212;

            /// <summary>
            /// Property Indexer for TaxReportingRecoverableAmount
            /// </summary>
            public const int TaxReportingRecoverableAmount = 213;

            /// <summary>
            /// Property Indexer for TaxReportingExpensedAmount
            /// </summary>
            public const int TaxReportingExpensedAmount = 214;

            /// <summary>
            /// Property Indexer for TaxReportingAllocatedAmount
            /// </summary>
            public const int TaxReportingAllocatedAmount = 215;

            /// <summary>
            /// Property Indexer for RetainageTaxBase1
            /// </summary>
            public const int RetainageTaxBase1 = 216;

            /// <summary>
            /// Property Indexer for RetainageTaxBase2
            /// </summary>
            public const int RetainageTaxBase2 = 217;

            /// <summary>
            /// Property Indexer for RetainageTaxBase3
            /// </summary>
            public const int RetainageTaxBase3 = 218;

            /// <summary>
            /// Property Indexer for RetainageTaxBase4
            /// </summary>
            public const int RetainageTaxBase4 = 219;

            /// <summary>
            /// Property Indexer for RetainageTaxBase5
            /// </summary>
            public const int RetainageTaxBase5 = 220;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount1
            /// </summary>
            public const int RetainageTaxAmount1 = 221;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount2
            /// </summary>
            public const int RetainageTaxAmount2 = 222;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount3
            /// </summary>
            public const int RetainageTaxAmount3 = 223;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount4
            /// </summary>
            public const int RetainageTaxAmount4 = 224;

            /// <summary>
            /// Property Indexer for RetainageTaxAmount5
            /// </summary>
            public const int RetainageTaxAmount5 = 225;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt1
            /// </summary>
            public const int RetainageTaxRecoverableAmt1 = 226;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt2
            /// </summary>
            public const int RetainageTaxRecoverableAmt2 = 227;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt3
            /// </summary>
            public const int RetainageTaxRecoverableAmt3 = 228;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt4
            /// </summary>
            public const int RetainageTaxRecoverableAmt4 = 229;

            /// <summary>
            /// Property Indexer for RetainageTaxRecoverableAmt5
            /// </summary>
            public const int RetainageTaxRecoverableAmt5 = 230;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount1
            /// </summary>
            public const int RetainageTaxExpenseAmount1 = 231;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount2
            /// </summary>
            public const int RetainageTaxExpenseAmount2 = 232;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount3
            /// </summary>
            public const int RetainageTaxExpenseAmount3 = 233;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount4
            /// </summary>
            public const int RetainageTaxExpenseAmount4 = 234;

            /// <summary>
            /// Property Indexer for RetainageTaxExpenseAmount5
            /// </summary>
            public const int RetainageTaxExpenseAmount5 = 235;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount1
            /// </summary>
            public const int RetainageTaxAllocatedAmount1 = 236;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount2
            /// </summary>
            public const int RetainageTaxAllocatedAmount2 = 237;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount3
            /// </summary>
            public const int RetainageTaxAllocatedAmount3 = 238;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount4
            /// </summary>
            public const int RetainageTaxAllocatedAmount4 = 239;

            /// <summary>
            /// Property Indexer for RetainageTaxAllocatedAmount5
            /// </summary>
            public const int RetainageTaxAllocatedAmount5 = 240;

            /// <summary>
            /// Property Indexer for RetainageTaxTotalAmount
            /// </summary>
            public const int RetainageTaxTotalAmount = 241;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt1
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt1 = 242;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt2
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt2 = 243;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt3
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt3 = 244;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt4
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt4 = 245;

            /// <summary>
            /// Property Indexer for TaxAmountPlusRtgTaxAmt5
            /// </summary>
            public const int TaxAmountPlusRtgTaxAmt5 = 246;

            /// <summary>
            /// Property Indexer for UnitCostIsManual
            /// </summary>
            public const int UnitCostIsManual = 247;

            /// <summary>
            /// Property Indexer for WeightUnitOfMeasure
            /// </summary>
            public const int WeightUnitOfMeasure = 248;

            /// <summary>
            /// Property Indexer for WeightConversion
            /// </summary>
            public const int WeightConversion = 249;

            /// <summary>
            /// Property Indexer for DefaultUnitWeight
            /// </summary>
            public const int DefaultUnitWeight = 250;

            /// <summary>
            /// Property Indexer for DefaultExtendedWeight
            /// </summary>
            public const int DefaultExtendedWeight = 251;

            /// <summary>
            /// Property Indexer for BillingRateConversionFactor
            /// </summary>
            public const int BillingRateConversionFactor = 252;

            /// <summary>
            /// Property Indexer for UnitBillingAmount
            /// </summary>
            public const int UnitBillingAmount = 253;

            /// <summary>
            /// Property Indexer for ExtendedBillingAmount
            /// </summary>
            public const int ExtendedBillingAmount = 254;

            /// <summary>
            /// Property Indexer for SerialLotQuantityToProcess
            /// </summary>
            public const int SerialLotQuantityToProcess = 255;

            /// <summary>
            /// Property Indexer for NumberOfLotsToGenerate
            /// </summary>
            public const int NumberOfLotsToGenerate = 256;

            /// <summary>
            /// Property Indexer for QuantityperLot
            /// </summary>
            public const int QuantityperLot = 257;

            /// <summary>
            /// Property Indexer for AllocateFromSerial
            /// </summary>
            public const int AllocateFromSerial = 258;

            /// <summary>
            /// Property Indexer for AllocateFromLot
            /// </summary>
            public const int AllocateFromLot = 259;

            /// <summary>
            /// Property Indexer for SerialLotWindowHandle
            /// </summary>
            public const int SerialLotWindowHandle = 260;

            /// <summary>
            /// Property Indexer for SerialQuantity
            /// </summary>
            public const int SerialQuantity = 261;

            /// <summary>
            /// Property Indexer for LotQuantity
            /// </summary>
            public const int LotQuantity = 262;

            /// <summary>
            /// Property Indexer for ItemSerializedLotted
            /// </summary>
            public const int ItemSerializedLotted = 263;

            /// <summary>
            /// Property Indexer for DetailNumber
            /// </summary>
            public const int DetailNumber = 264;
            /// <summary>
            /// Property Indexer for ReverseChargeable1
            /// </summary>
            public const int ReverseChargeable1 = 265;
            /// <summary>
            /// Property Indexer for ReverseChargeable2
            /// </summary>
            public const int ReverseChargeable2 = 266;

            /// <summary>
            /// Property Indexer for ReverseChargeable3
            /// </summary>
            public const int ReverseChargeable3 = 267;

            /// <summary>
            /// Property Indexer for ReverseChargeable4
            /// </summary>
            public const int ReverseChargeable4 = 268;

            /// <summary>
            /// Property Indexer for ReverseChargeable5
            /// </summary>
            public const int ReverseChargeable5 = 269;

            /// <summary>
            /// Property Indexer for customer tax base 1
            /// </summary>
            public const int CustomerTaxBase1 = 270;
            /// <summary>
            /// Property Indexer for customer tax base 2
            /// </summary>
            public const int CustomerTaxBase2 = 271;
            /// <summary>
            /// Property Indexer for customer tax base 3
            /// </summary>
            public const int CustomerTaxBase3 = 272;
            /// <summary>
            /// Property Indexer for customer tax base 4
            /// </summary>
            public const int CustomerTaxBase4 = 273;
            /// <summary>
            /// Property Indexer for customer tax base 5
            /// </summary>
            public const int CustomerTaxBase5 = 274;
             /// <summary>
            /// Property Indexer for customer tax amount 1
            /// </summary>
            public const int CustomerTaxAmount1 = 275;
            /// <summary>
            /// Property Indexer for customer tax amount 2
            /// </summary>
            public const int CustomerTaxAmount2 = 276;
            /// <summary>
            /// Property Indexer for customer tax amount 3
            /// </summary>
            public const int CustomerTaxAmount3 = 277;
            /// <summary>
            /// Property Indexer for customer tax amount 4
            /// </summary>
            public const int CustomerTaxAmount4 = 278;
            /// <summary>
            /// Property Indexer for customer tax amount 5
            /// </summary>
            public const int CustomerTaxAmount5 = 279;

            /// <summary>
            /// Property Indexer for Billing Currency Number of Decimals
            /// </summary>
            public const int BillingCurrencyDecimal = 280;

        }
        #endregion
    }
}
