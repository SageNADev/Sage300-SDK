// Copyright (c) 1994-2023 The Sage Group plc or its licensors.  All rights reserved.

// ReSharper disable once CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Contains list of CRDRNoteDistributeProration Constants
     /// </summary>
     public partial class CrdrNoteDistributeProration
     {
          /// <summary>
          /// View Name
          /// </summary>
          public const string EntityName = "PO0319";

          #region Properties
          /// <summary>
          /// Contains list of CRDRNoteDistributeProration Constants
          /// </summary>
          public class Fields
          {

               /// <summary>
               /// Property for LineRevision
               /// </summary>
               public const string LineRevision = "LREV";

               /// <summary>
               /// Property for Contract
               /// </summary>
               public const string Contract = "CONTRACT";

               /// <summary>
               /// Property for Project
               /// </summary>
               public const string Project = "PROJECT";

               /// <summary>
               /// Property for Category
               /// </summary>
               public const string Category = "CCATEGORY";

               /// <summary>
               /// Property for CostClass
               /// </summary>
               public const string CostClass = "COSTCLASS";

               /// <summary>
               /// Property for ItemNumber
               /// </summary>
               public const string ItemNumber = "ITEMNO";

               /// <summary>
               /// Property for ItemDescription
               /// </summary>
               public const string ItemDescription = "ITEMDESC";

               /// <summary>
               /// Property for Amount
               /// </summary>
               public const string Amount = "AMOUNT";

               /// <summary>
               /// Property for BillingType
               /// </summary>
               public const string BillingType = "BILLTYPE";

               /// <summary>
               /// Property for BillingRate
               /// </summary>
               public const string BillingRate = "BILLRATE";

               /// <summary>
               /// Property for BillingCurrency
               /// </summary>
               public const string BillingCurrency = "BILLCURR";

               /// <summary>
               /// Property for ARItemNumber
               /// </summary>
               public const string ARItemNumber = "ARITEMNO";

               /// <summary>
               /// Property for ARUnitOfMeasure
               /// </summary>
               public const string ARUnitOfMeasure = "ARUNIT";

               /// <summary>
               /// Property for ProjectType
               /// </summary>
               public const string ProjectType = "PROJTYPE";

               /// <summary>
               /// Property for AccountingMethod
               /// </summary>
               public const string AccountingMethod = "REVREC";

          }
          #endregion

          #region Properties
          /// <summary>
          /// Contains list of CRDRNoteDistributeProration Constants
          /// </summary>
          public class Index
          {

               /// <summary>
               /// Property Indexer for LineRevision
               /// </summary>
               public const int LineRevision = 1;

               /// <summary>
               /// Property Indexer for Contract
               /// </summary>
               public const int Contract = 2;

               /// <summary>
               /// Property Indexer for Project
               /// </summary>
               public const int Project = 3;

               /// <summary>
               /// Property Indexer for Category
               /// </summary>
               public const int Category = 4;

               /// <summary>
               /// Property Indexer for CostClass
               /// </summary>
               public const int CostClass = 5;

               /// <summary>
               /// Property Indexer for ItemNumber
               /// </summary>
               public const int ItemNumber = 6;

               /// <summary>
               /// Property Indexer for ItemDescription
               /// </summary>
               public const int ItemDescription = 7;

               /// <summary>
               /// Property Indexer for Amount
               /// </summary>
               public const int Amount = 8;

               /// <summary>
               /// Property Indexer for BillingType
               /// </summary>
               public const int BillingType = 9;

               /// <summary>
               /// Property Indexer for BillingRate
               /// </summary>
               public const int BillingRate = 10;

               /// <summary>
               /// Property Indexer for BillingCurrency
               /// </summary>
               public const int BillingCurrency = 11;

               /// <summary>
               /// Property Indexer for ARItemNumber
               /// </summary>
               public const int ARItemNumber = 12;

               /// <summary>
               /// Property Indexer for ARUnitOfMeasure
               /// </summary>
               public const int ARUnitOfMeasure = 13;

               /// <summary>
               /// Property Indexer for ProjectType
               /// </summary>
               public const int ProjectType = 14;

               /// <summary>
               /// Property Indexer for AccountingMethod
               /// </summary>
               public const int AccountingMethod = 15;

          }
          #endregion

     }
}
