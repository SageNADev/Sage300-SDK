// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
     /// <summary>
     /// Partial class for CreditDebitNoteLineLot
     /// </summary>
     public partial class CreditDebitNoteLineLot : ModelBase
     {
          /// <summary>
          /// Gets or sets CreditDebitNoteSequenceKey
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.CreditDebitNoteSequenceKey, Id = Index.CreditDebitNoteSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CreditDebitNoteSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal LineNumber {get; set;}

          /// <summary>
          /// Gets or sets LotNumber
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [StringLength(40, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LotNumber, Id = Index.LotNumber, FieldType = EntityFieldType.Char, Size = 40)]
          public string LotNumber {get; set;}

          /// <summary>
          /// Gets or sets CreditDebitNoteLineSequence
          /// </summary>
          [ViewField(Name = Fields.CreditDebitNoteLineSequence, Id = Index.CreditDebitNoteLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal CreditDebitNoteLineSequence {get; set;}

          /// <summary>
          /// Gets or sets ExpiryDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.ExpiryDate, Id = Index.ExpiryDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime ExpiryDate {get; set;}

          /// <summary>
          /// Gets or sets LotQuantity
          /// </summary>
          [ViewField(Name = Fields.LotQuantity, Id = Index.LotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal LotQuantity {get; set;}

          /// <summary>
          /// Gets or sets StockLotQuantity
          /// </summary>
          [ViewField(Name = Fields.StockLotQuantity, Id = Index.StockLotQuantity, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
          public decimal StockLotQuantity {get; set;}

     }
}
