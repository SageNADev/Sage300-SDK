// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of properties for ReceiptLineSerial
    /// </summary>
    public partial class ReceiptLineSerial : ModelBase
    {
        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(40, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SerialNumber", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.Char, Size = 40)]
        public string SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets ReceiptLineSequence
        /// </summary>
        [Display(Name = "ReceiptLineSequence", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptLineSequence, Id = Index.ReceiptLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptLineSequence { get; set; }

        /// <summary>
        /// Gets or sets SerialCount
        /// </summary>
        [Display(Name = "SerialCount", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.SerialCount, Id = Index.SerialCount, FieldType = EntityFieldType.Long, Size = 4)]
        public long SerialCount { get; set; }
    }
}
