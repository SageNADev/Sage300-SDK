// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Contains list of properties for ReceiptCostDistribution
    /// </summary>
    public partial class ReceiptCostDistribution : ModelBase
    {
        /// <summary>
        /// Gets or sets ReceiptSequenceKey
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptSequenceKey", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.ReceiptSequenceKey, Id = Index.ReceiptSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal ReceiptSequenceKey { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets LineNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineNumber { get; set; }

        /// <summary>
        /// Gets or sets LineSequence
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LineSequence", ResourceType = typeof(ReceiptEntryResx))]
        [ViewField(Name = Fields.LineSequence, Id = Index.LineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal LineSequence { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets BillingRate
        /// </summary>
        [Display(Name = "BillingRate", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.BillingRate, Id = Index.BillingRate, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
        public decimal BillingRate { get; set; }

        /// <summary>
        /// Gets or sets StoredInDatabaseTable
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
        public StoredInDatabaseTable StoredInDatabaseTable { get; set; }

        /// <summary>
        /// Gets or sets ManualCostDistribution
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ManualCostDistribution, Id = Index.ManualCostDistribution, FieldType = EntityFieldType.Long, Size = 4)]
        public long ManualCostDistribution { get; set; }

        /// <summary>
        /// Gets or sets ExtraneousCostDistribution
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExtraneousCostDistribution, Id = Index.ExtraneousCostDistribution, FieldType = EntityFieldType.Long, Size = 4)]
        public long ExtraneousCostDistribution { get; set; }

        /// <summary>
        /// Gets or sets CostDistribution
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.CostDistribution, Id = Index.CostDistribution, FieldType = EntityFieldType.Long, Size = 4)]
        public long CostDistribution { get; set; }
    }
}
