// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using Command = Sage.CA.SBS.ERP.Sage300.PO.Models.Enums.Command;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Additional Cost Header
    /// </summary>
    public partial class AdditionalCostHeader : ModelBase
    {
        /// <summary>
        /// This constructor initializes EnumerableResponses/Lists to be empty.
        /// This avoids the problem of serializing null collections.
        /// </summary>
        public AdditionalCostHeader()
        {
            AdditionalCostDetails = new EnumerableResponse<AdditionalCostDetails>();
            AdditionalCostOptionalField = new EnumerableResponse<AdditionalCostOptionalField>();
        }
        /// <summary>
        /// Gets or sets Additional Cost
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AdditionalCost", ResourceType = typeof(AdditionalCostsResx))]
        [ViewField(Name = Fields.AdditionalCost, Id = Index.AdditionalCost, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string AdditionalCost { get; set; }

        /// <summary>
        /// Gets or sets Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Expense Account
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpenseAccount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExpenseAccount, Id = Index.ExpenseAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ExpenseAccount { get; set; }

        /// <summary>
        /// Gets or sets Amount
        /// </summary>
        [Display(Name = "Amount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets Date Last Maintained
        /// </summary>
        [Display(Name = "DateLastMaintained", ResourceType = typeof(AdditionalCostsResx))]
        [ViewField(Name = Fields.DateLastMaintained, Id = Index.DateLastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateLastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets Date Inactive
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateInactive", ResourceType = typeof(AdditionalCostsResx))]
        [ViewField(Name = Fields.DateInactive, Id = Index.DateInactive, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateInactive { get; set; }

        /// <summary>
        /// Gets or sets Vendor Exists
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

        /// <summary>
        /// Gets or sets Vendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets Proration Method
        /// </summary>
        [Display(Name = "ProrationMethod", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ProrationMethod, Id = Index.ProrationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public ProrationMethod ProrationMethod { get; set; }

        /// <summary>
        /// Gets or sets Reproration Method
        /// </summary>
        [Display(Name = "ReprorationMethod", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReprorationMethod, Id = Index.ReprorationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public ReprorationMethod ReprorationMethod { get; set; }

        /// <summary>
        /// Gets or sets Return Account
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReturnAccount", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ReturnAccount, Id = Index.ReturnAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ReturnAccount { get; set; }

        /// <summary>
        /// Gets or sets Lines
        /// </summary>
         [IgnoreExportImport]
        [ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines { get; set; }

        /// <summary>
        /// Gets or sets Optional Fields
        /// </summary>
        [Display(Name = "OptionalField", ResourceType = typeof(AdditionalCostsResx))]
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

        /// <summary>
        /// Gets or sets ExpenseAccountDescription
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ExpenseAccountDescription, Id = Index.ExpenseAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ExpenseAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets Return Expense Account Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.ReturnExpenseAccountDesc, Id = Index.ReturnExpenseAccountDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReturnExpenseAccountDesc { get; set; }
        /// <summary>
        /// Gets or sets Vendor Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        public string VendorDescription { get; set; }

        /// <summary>
        /// Gets or sets Name
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Vendor On Hold
        /// </summary>
         [IgnoreExportImport]
        [ViewField(Name = Fields.VendorOnHold, Id = Index.VendorOnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorOnHold VendorOnHold { get; set; }

        /// <summary>
        /// Gets or sets Currency Description
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CurrencyDescription { get; set; }

        /// <summary>
        /// Gets or sets Command
        /// </summary>
        [Display(Name = "Command", ResourceType = typeof(AdditionalCostsResx))]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets List of Additional Cost Details
        /// </summary>
        /// <value>The Additional Cost Details</value>
        [IgnoreExportImport]
        public EnumerableResponse<AdditionalCostDetails> AdditionalCostDetails { get; set; }

        /// <summary>
        /// Gets or sets Additional Cost Optional Field
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<AdditionalCostOptionalField> AdditionalCostOptionalField { get; set; }

        /// <summary>
        /// Optional field loaded flag
        /// </summary>
        public bool IsOptinalFieldLoaded { get; set; }

        /// <summary>
        /// Gets or sets Is New Record
        /// </summary>
        public bool IsNewRecord { get; set; }

        /// <summary>
        /// Gets or sets the Status string
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(CommonResx))]
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets the Vendor Exists String
        /// </summary>
        [Display(Name = "VendorExists", ResourceType = typeof(AdditionalCostsResx))]
        public string VendorExistsString
        {
            get { return EnumUtility.GetStringValue(VendorExists); }
        }

        /// <summary>
        /// Gets or sets the Proration String
        /// </summary>
        [Display(Name = "Proration", ResourceType = typeof(AdditionalCostsResx))]
        public string ProrationString
        {
            get { return EnumUtility.GetStringValue(ProrationMethod); }
        }

        /// <summary>
        /// Gets or sets the Reproration String
        /// </summary>

        [Display(Name = "ReturnProration", ResourceType = typeof(AdditionalCostsResx))]
        public string ReprorationString
        {
            get { return EnumUtility.GetStringValue(ReprorationMethod); }
        }

        /// <summary>
        /// Gets or sets the Vendor On Hold String
        /// </summary>
        [Display(Name = "VendorOnHold", ResourceType = typeof(AdditionalCostsResx))]
        public string VendorOnHoldString
        {
            get { return EnumUtility.GetStringValue(VendorOnHold); }
        }

        /// <summary>
        /// Gets or sets the Command string
        /// </summary>
        [Display(Name = "Command", ResourceType = typeof(AdditionalCostsResx))]
        public string CommandString
        {
            get { return EnumUtility.GetStringValue(Command); }
        }
    }
}
