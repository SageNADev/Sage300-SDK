// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
	/// Partial class for Requisition
	/// </summary>
    public partial class RequisitionDetail : ModelBase
	{
        public RequisitionDetail()
        {
            RequisitionHeaderOptionalField = new EnumerableResponse<RequisitionHeaderOptionalField>();
        }

	    /// <summary>
        /// Gets or sets RequisitionSequenceKey
	    /// </summary>
        [Key]
	    [Display(Name = "RequisitionSequenceKey", ResourceType = typeof(PurchaseOrderEntryResx))]
	    [ViewField(Name = Fields.RequisitionSequenceKey, Id = Index.RequisitionSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
	    public decimal RequisitionSequenceKey { get; set; }

		/// <summary>
        /// Gets or sets Vendor
		/// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorAccountSet", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.Vendor, Id = Index.Vendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor { get; set; }

		/// <summary>
        /// Gets or sets RequisitionLineSequence
		/// </summary>
        [Display(Name = "RequisitionLineSequence", ResourceType = typeof(RequisitionEntryResx))]
        [ViewField(Name = Fields.RequisitionLineSequence, Id = Index.RequisitionLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionLineSequence { get; set; }

		/// <summary>
        /// Gets or sets RequisitionNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RequisitionNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RequisitionNumber, Id = Index.RequisitionNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string RequisitionNumber { get; set; }

		/// <summary>
        /// Gets or sets RequisitionSequenceKey1
		/// </summary>
		[Display(Name = "RequisitionSequenceKey", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.RequisitionSequenceKey1, Id = Index.RequisitionSequenceKey1, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionSequenceKey1 { get; set; }

		/// <summary>
		/// Gets or sets LineNumber
		/// </summary>
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal LineNumber { get; set; }

		/// <summary>
        /// Gets or sets RequisitionLineSequence1
		/// </summary>
        [ViewField(Name = Fields.RequisitionLineSequence1, Id = Index.RequisitionLineSequence1, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionLineSequence1 { get; set; }

		/// <summary>
		/// Gets or sets LineOrdered
		/// </summary>
		[ViewField(Name = Fields.LineOrdered, Id = Index.LineOrdered, FieldType = EntityFieldType.Long, Size = 4)]
		public long LineOrdered { get; set; }

		/// <summary>
		/// Gets or sets RequisitionCommentSequence
		/// </summary>
        [Display(Name = "RequisitionCommentSequence", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.RequisitionCommentSequence, Id = Index.RequisitionCommentSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal RequisitionCommentSequence { get; set; }

		/// <summary>
		/// Gets or sets OrderNumber
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderNumber", ResourceType = typeof (POCommonResx))]
		[ViewField(Name = Fields.OrderNumber, Id = Index.OrderNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
		public string OrderNumber { get; set; }

		/// <summary>
        /// Gets or sets VendorExists
		/// </summary>
		[Display(Name = "VendorExists", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.VendorExists, Id = Index.VendorExists, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists { get; set; }

		/// <summary>
        /// Gets or sets Vendor1
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor1, Id = Index.Vendor1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor1 { get; set; }

		/// <summary>
        /// Gets or sets Name
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof (POCommonResx))]
        [ViewField(Name = Fields.Name, Id = Index.Name, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name { get; set; }

		/// <summary>
		/// Gets or sets StoredInDatabaseTable
		/// </summary>
		[ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
		public StoredInDatabaseTable StoredInDatabaseTable { get; set; }

		/// <summary>
		/// Gets or sets CompletionStatus
		/// </summary>
        //[Display(Name = "CompletionStatus", ResourceType = typeof (POCommonResx))]
		[ViewField(Name = Fields.CompletionStatus, Id = Index.CompletionStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public CompletionStatus CompletionStatus { get; set; }

		/// <summary>
        /// Gets or sets DateCompleted
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCompleted", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.DateCompleted, Id = Index.DateCompleted, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted { get; set; }

		/// <summary>
		/// Gets or sets ItemExists
		/// </summary>
		[ViewField(Name = Fields.ItemExists, Id = Index.ItemExists, FieldType = EntityFieldType.Bool, Size = 2)]
		public ItemExists ItemExists { get; set; }

		/// <summary>
		/// Gets or sets ItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemNumber", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.ItemNumber, Id = Index.ItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ItemNumber { get; set; }

		/// <summary>
        /// Gets or sets Location
		/// </summary>
	    [Key]
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Location, Id = Index.Location, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string Location { get; set; }

		/// <summary>
		/// Gets or sets ItemDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemDescription", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.ItemDescription, Id = Index.ItemDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string ItemDescription { get; set; }

		/// <summary>
		/// Gets or sets ExpectedArrivalDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpectedArrivalDate", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.ExpectedArrivalDate, Id = Index.ExpectedArrivalDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ExpectedArrivalDate { get; set; }

		/// <summary>
		/// Gets or sets VendorItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorItemNumber", ResourceType = typeof (POCommonResx))]
		[ViewField(Name = Fields.VendorItemNumber, Id = Index.VendorItemNumber, FieldType = EntityFieldType.Char, Size = 24)]
		public string VendorItemNumber { get; set; }

		/// <summary>
		/// Gets or sets CommentsInstructions
		/// </summary>
        [Display(Name = "CommentsInstructions", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.CommentsInstructions, Id = Index.CommentsInstructions, FieldType = EntityFieldType.Bool, Size = 2)]
		public CommentsInstructions CommentsInstructions { get; set; }

		/// <summary>
		/// Gets or sets UnitOfMeasure
		/// </summary>
		[Key]
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UnitOfMeasure", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.UnitOfMeasure, Id = Index.UnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10, Mask = "%-10c")]
		public string UnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets OrderUnitConversion
		/// </summary>
		[ViewField(Name = Fields.OrderUnitConversion, Id = Index.OrderUnitConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal OrderUnitConversion { get; set; }

		/// <summary>
		/// Gets or sets OrderUnitDecimals
		/// </summary>
		[ViewField(Name = Fields.OrderUnitDecimals, Id = Index.OrderUnitDecimals, FieldType = EntityFieldType.Int, Size = 2)]
		public int OrderUnitDecimals { get; set; }

		/// <summary>
		/// Gets or sets StockUnitDecimals
		/// </summary>
        //[Display(Name = "StockUnitDecimals", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.StockUnitDecimals, Id = Index.StockUnitDecimals, FieldType = EntityFieldType.Int, Size = 2)]
		public int StockUnitDecimals { get; set; }

		/// <summary>
        /// Gets or sets QuantityOrdered
		/// </summary>
        [Display(Name = "QuantityOrdered", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityOrdered, Id = Index.QuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered { get; set; }

		/// <summary>
		/// Gets or sets DropShip
		/// </summary>
        [Display(Name = "DropShip", ResourceType = typeof (PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.DropShip, Id = Index.DropShip, FieldType = EntityFieldType.Bool, Size = 2)]
		public DropShip DropShip { get; set; }

		/// <summary>
		/// Gets or sets DropShipType
		/// </summary>
        [ViewField(Name = Fields.DropShipType, Id = Index.DropShipType, FieldType = EntityFieldType.Int, Size = 2)]
        public DropShipType DropShipType { get; set; }

		/// <summary>
		/// Gets or sets DropShipCustomer
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipCustomer, Id = Index.DropShipCustomer, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
		public string DropShipCustomer { get; set; }

		/// <summary>
		/// Gets or sets CustomerShipToAddress
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CustomerShipToAddress, Id = Index.CustomerShipToAddress, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
		public string CustomerShipToAddress { get; set; }

		/// <summary>
		/// Gets or sets DropShipLocation
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Location", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.DropShipLocation, Id = Index.DropShipLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
		public string DropShipLocation { get; set; }

		/// <summary>
		/// Gets or sets DropShipDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipDescription, Id = Index.DropShipDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string DropShipDescription { get; set; }

		/// <summary>
		/// Gets or sets DropShipAddress1
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipAddress1, Id = Index.DropShipAddress1, FieldType = EntityFieldType.Char, Size = 60)]
		public string DropShipAddress1 { get; set; }

		/// <summary>
		/// Gets or sets DropShipAddress2
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipAddress2, Id = Index.DropShipAddress2, FieldType = EntityFieldType.Char, Size = 60)]
		public string DropShipAddress2 { get; set; }

		/// <summary>
		/// Gets or sets DropShipAddress3
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipAddress3, Id = Index.DropShipAddress3, FieldType = EntityFieldType.Char, Size = 60)]
		public string DropShipAddress3 { get; set; }

		/// <summary>
		/// Gets or sets DropShipAddress4
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipAddress4, Id = Index.DropShipAddress4, FieldType = EntityFieldType.Char, Size = 60)]
		public string DropShipAddress4 { get; set; }

		/// <summary>
		/// Gets or sets DropShipCity
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipCity, Id = Index.DropShipCity, FieldType = EntityFieldType.Char, Size = 30)]
		public string DropShipCity { get; set; }

		/// <summary>
		/// Gets or sets DropShipStateProvince
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipStateProvince, Id = Index.DropShipStateProvince, FieldType = EntityFieldType.Char, Size = 30)]
		public string DropShipStateProvince { get; set; }

		/// <summary>
		/// Gets or sets DropShipZipPostalCode
		/// </summary>
		[StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipZipPostalCode, Id = Index.DropShipZipPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
		public string DropShipZipPostalCode { get; set; }

		/// <summary>
		/// Gets or sets DropShipCountry
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipCountry, Id = Index.DropShipCountry, FieldType = EntityFieldType.Char, Size = 30)]
		public string DropShipCountry { get; set; }

		/// <summary>
		/// Gets or sets DropShipPhoneNumber
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipPhoneNumber, Id = Index.DropShipPhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string DropShipPhoneNumber { get; set; }

		/// <summary>
		/// Gets or sets DropShipFaxNumber
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipFaxNumber, Id = Index.DropShipFaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string DropShipFaxNumber { get; set; }

		/// <summary>
		/// Gets or sets DropShipContact
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipContact, Id = Index.DropShipContact, FieldType = EntityFieldType.Char, Size = 60)]
		public string DropShipContact { get; set; }

		/// <summary>
		/// Gets or sets StockItem
		/// </summary>
		[ViewField(Name = Fields.StockItem, Id = Index.StockItem, FieldType = EntityFieldType.Bool, Size = 2)]
		public StockItem StockItem { get; set; }

		/// <summary>
		/// Gets or sets DropShipEmail
		/// </summary>
		[StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipEmail, Id = Index.DropShipEmail, FieldType = EntityFieldType.Char, Size = 50)]
		public string DropShipEmail { get; set; }

		/// <summary>
		/// Gets or sets DropShipContactPhone
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipContactPhone, Id = Index.DropShipContactPhone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string DropShipContactPhone { get; set; }

		/// <summary>
		/// Gets or sets DropShipContactFax
		/// </summary>
		[StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipContactFax, Id = Index.DropShipContactFax, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
		public string DropShipContactFax { get; set; }

		/// <summary>
		/// Gets or sets DropShipContactEmail
		/// </summary>
		[StringLength(50, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DropShipContactEmail, Id = Index.DropShipContactEmail, FieldType = EntityFieldType.Char, Size = 50)]
		public string DropShipContactEmail { get; set; }

		/// <summary>
		/// Gets or sets ManufacturersItemNumber
		/// </summary>
		[StringLength(24, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ManufacturersItemNumber, Id = Index.ManufacturersItemNumber, FieldType = EntityFieldType.Char, Size = 24, Mask = "%-24C")]
		public string ManufacturersItemNumber { get; set; }

		/// <summary>
        /// Gets or sets OptionalFields
		/// </summary>
        [ViewField(Name = Fields.OptionalFields, Id = Index.OptionalFields, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields { get; set; }

		/// <summary>
		/// Gets or sets Contract
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Contract, Id = Index.Contract, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
		public string Contract { get; set; }

		/// <summary>
		/// Gets or sets Project
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Project, Id = Index.Project, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
		public string Project { get; set; }

		/// <summary>
		/// Gets or sets Category
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Category, Id = Index.Category, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16N")]
		public string Category { get; set; }

		/// <summary>
		/// Gets or sets CostClass
		/// </summary>
		[ViewField(Name = Fields.CostClass, Id = Index.CostClass, FieldType = EntityFieldType.Int, Size = 2)]
		public CostClass CostClass { get; set; }

		/// <summary>
		/// Gets or sets StockingQuantityOrdered
		/// </summary>
		[ViewField(Name = Fields.StockingQuantityOrdered, Id = Index.StockingQuantityOrdered, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal StockingQuantityOrdered { get; set; }

		/// <summary>
        /// Gets or sets VendorOnHold
		/// </summary>
        [ViewField(Name = Fields.VendorOnHold, Id = Index.VendorOnHold, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorOnHold VendorOnHold { get; set; }

		/// <summary>
		/// Gets or sets UseICVendor
		/// </summary>
		[ViewField(Name = Fields.UseICVendor, Id = Index.UseICVendor, FieldType = EntityFieldType.Int, Size = 2)]
		public UseICVendor UseICVendor { get; set; }

		/// <summary>
        /// Gets or sets ICVendor
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ICVendor, Id = Index.ICVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string ICVendor { get; set; }

		/// <summary>
        /// Gets or sets Completed
		/// </summary>
        [ViewField(Name = Fields.Completed, Id = Index.Completed, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed { get; set; }

		/// <summary>
        /// Gets or sets LineComplete
		/// </summary>
        [ViewField(Name = Fields.LineComplete, Id = Index.LineComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineComplete { get; set; }

		/// <summary>
        /// Gets or sets IsRecordActive
		/// </summary>
        [Display(Name = "IsRecordActive", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.IsRecordActive, Id = Index.IsRecordActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsRecordActive IsRecordActive { get; set; }

		/// <summary>
		/// Gets or sets Line
		/// </summary>
		[ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
		public long Line { get; set; }

		/// <summary>
		/// Gets or sets MapManufacturersItemNumber
		/// </summary>
		[ViewField(Name = Fields.MapManufacturersItemNumber, Id = Index.MapManufacturersItemNumber, FieldType = EntityFieldType.Bool, Size = 2)]
		public MapManufacturersItemNumber MapManufacturersItemNumber { get; set; }

		/// <summary>
        /// Gets or sets Command
		/// </summary>
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

		/// <summary>
		/// Gets or sets ProjectStyle
		/// </summary>
		[ViewField(Name = Fields.ProjectStyle, Id = Index.ProjectStyle, FieldType = EntityFieldType.Int, Size = 2)]
		public ProjectStyle ProjectStyle { get; set; }

		/// <summary>
		/// Gets or sets ProjectType
		/// </summary>
		[ViewField(Name = Fields.ProjectType, Id = Index.ProjectType, FieldType = EntityFieldType.Int, Size = 2)]
		public ProjectType ProjectType { get; set; }

		/// <summary>
		/// Gets or sets UnformattedContractCode
		/// </summary>
		[StringLength(16, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.UnformattedContractCode, Id = Index.UnformattedContractCode, FieldType = EntityFieldType.Char, Size = 16, Mask = "%-16C")]
		public string UnformattedContractCode { get; set; }

		/// <summary>
		/// Gets or sets UnitCost
		/// </summary>
        [Key]
		[ViewField(Name = Fields.UnitCost, Id = Index.UnitCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal UnitCost { get; set; }

		/// <summary>
		/// Gets or sets UnitCostIsManual
		/// </summary>
		[ViewField(Name = Fields.UnitCostIsManual, Id = Index.UnitCostIsManual, FieldType = EntityFieldType.Bool, Size = 2)]
		public UnitCostIsManual UnitCostIsManual { get; set; }

		/// <summary>
		/// Gets or sets CopyCostToPurchaseOrder
		/// </summary>
		[ViewField(Name = Fields.CopyCostToPurchaseOrder, Id = Index.CopyCostToPurchaseOrder, FieldType = EntityFieldType.Bool, Size = 2)]
		public CopyCostToPurchaseOrder CopyCostToPurchaseOrder { get; set; }

		/// <summary>
		/// Gets or sets ExtendedCost
		/// </summary>
		[ViewField(Name = Fields.ExtendedCost, Id = Index.ExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal ExtendedCost { get; set; }

		/// <summary>
		/// Gets or sets FunctionalExtended
		/// </summary>
		[ViewField(Name = Fields.FunctionalExtended, Id = Index.FunctionalExtended, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal FunctionalExtended { get; set; }

		/// <summary>
		/// Gets or sets DiscountAmount
		/// </summary>
		[ViewField(Name = Fields.DiscountAmount, Id = Index.DiscountAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal DiscountAmount { get; set; }

		/// <summary>
		/// Gets or sets DiscountPercentage
		/// </summary>
		[ViewField(Name = Fields.DiscountPercentage, Id = Index.DiscountPercentage, FieldType = EntityFieldType.Decimal, Size = 5, Precision = 5)]
		public decimal DiscountPercentage { get; set; }

		/// <summary>
		/// Gets or sets UnitWeight
		/// </summary>
		[ViewField(Name = Fields.UnitWeight, Id = Index.UnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal UnitWeight { get; set; }

		/// <summary>
		/// Gets or sets EXTWEIGHT
		/// </summary>
        [ViewField(Name = Fields.ExtendedWeight, Id = Index.ExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight { get; set; }

		/// <summary>
		/// Gets or sets WeightUnitOfMeasure
		/// </summary>
		[StringLength(10, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.WeightUnitOfMeasure, Id = Index.WeightUnitOfMeasure, FieldType = EntityFieldType.Char, Size = 10)]
		public string WeightUnitOfMeasure { get; set; }

		/// <summary>
		/// Gets or sets WeightConversion
		/// </summary>
		[ViewField(Name = Fields.WeightConversion, Id = Index.WeightConversion, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 6)]
		public decimal WeightConversion { get; set; }

		/// <summary>
		/// Gets or sets DefaultUnitWeight
		/// </summary>
		[ViewField(Name = Fields.DefaultUnitWeight, Id = Index.DefaultUnitWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal DefaultUnitWeight { get; set; }

		/// <summary>
		/// Gets or sets DefaultExtendedWeight
		/// </summary>
		[ViewField(Name = Fields.DefaultExtendedWeight, Id = Index.DefaultExtendedWeight, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
		public decimal DefaultExtendedWeight { get; set; }

		/// <summary>
		/// Gets or sets NetExtendedCost
		/// </summary>
		[ViewField(Name = Fields.NetExtendedCost, Id = Index.NetExtendedCost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal NetExtendedCost { get; set; }

		/// <summary>
        /// Gets or sets Lines
		/// </summary>
        [Display(Name = "Lines", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.Lines, Id = Index.Lines, FieldType = EntityFieldType.Long, Size = 4)]
		public long Lines { get; set; }

		/// <summary>
		/// Gets or sets Currency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3)]
		public string Currency { get; set; }

		/// <summary>
		/// Gets or sets CurrencyDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyDescription", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.CurrencyDescription, Id = Index.CurrencyDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string CurrencyDescription { get; set; }

		/// <summary>
		/// Gets or sets ExchangeRate
		/// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
		public decimal ExchangeRate { get; set; }

		/// <summary>
		/// Gets or sets ExchangeRateExists
		/// </summary>
        [Display(Name = "ExchangeRateExists", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.ExchangeRateExists, Id = Index.ExchangeRateExists, FieldType = EntityFieldType.Bool, Size = 2)]
		public ExchangeRateExists ExchangeRateExists { get; set; }

		/// <summary>
		/// Gets or sets RateType
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateType", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2)]
		public string RateType { get; set; }

		/// <summary>
		/// Gets or sets RateTypeDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Generated", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.RateTypeDescription, Id = Index.RateTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string RateTypeDescription { get; set; }

		/// <summary>
		/// Gets or sets RateDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime RateDate { get; set; }

		/// <summary>
		/// Gets or sets RateOperation
		/// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
		public RateOperation RateOperation { get; set; }

		/// <summary>
		/// Gets or sets CostDateForContract
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.CostDateForContract, Id = Index.CostDateForContract, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime CostDateForContract { get; set; }

		/// <summary>
		/// Gets or sets DetailNumber
		/// </summary>
		[ViewField(Name = Fields.DetailNumber, Id = Index.DetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int DetailNumber { get; set; }

		/// <summary>
        /// Gets or sets RequisitionSequenceKey2
		/// </summary>
        [Display(Name = "RequisitionSequenceKey", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.RequisitionSequenceKey2, Id = Index.RequisitionSequenceKey2, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal RequisitionSequenceKey2 { get; set; }

		/// <summary>
		/// Gets or sets NextLineSequence
		/// </summary>
        [Display(Name = "NextLineSequence", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.NextLineSequence, Id = Index.NextLineSequence, FieldType = EntityFieldType.Decimal, Size = 10)]
		public decimal NextLineSequence { get; set; }

		/// <summary>
        /// Gets or sets Lines1
		/// </summary>
        [Display(Name = "Lines", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.Lines1, Id = Index.Lines1, FieldType = EntityFieldType.Long, Size = 4)]
        public long Lines1 { get; set; }

		/// <summary>
        /// Gets or sets LinesComplete
		/// </summary>
        [Display(Name = "LinesComplete", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.LinesComplete, Id = Index.LinesComplete, FieldType = EntityFieldType.Long, Size = 4)]
        public long LinesComplete { get; set; }

		/// <summary>
		/// Gets or sets LinesOrdered
		/// </summary>
		[ViewField(Name = Fields.LinesOrdered, Id = Index.LinesOrdered, FieldType = EntityFieldType.Long, Size = 4)]
		public long LinesOrdered { get; set; }

		/// <summary>
		/// Gets or sets Printed
		/// </summary>
		[ViewField(Name = Fields.Printed, Id = Index.Printed, FieldType = EntityFieldType.Bool, Size = 2)]
		public Printed Printed { get; set; }

		/// <summary>
        /// Gets or sets Completed2
		/// </summary>
        [Display(Name = "Completed", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Completed2, Id = Index.Completed2, FieldType = EntityFieldType.Bool, Size = 2)]
        public Completed Completed2 { get; set; }

		/// <summary>
        /// Gets or sets DateCompleted2
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateCompleted", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.DateCompleted2, Id = Index.DateCompleted2, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateCompleted2 { get; set; }

		/// <summary>
		/// Gets or sets LastPostingDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LastPostingDate", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.LastPostingDate, Id = Index.LastPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime LastPostingDate { get; set; }

		/// <summary>
		/// Gets or sets RequisitionDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.RequisitionDate, Id = Index.RequisitionDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime RequisitionDate { get; set; }

		/// <summary>
        /// Gets or sets RequisitionNumber2
		/// </summary>
		[StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RequisitionNumber", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.RequisitionNumber2, Id = Index.RequisitionNumber2, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string RequisitionNumber2 { get; set; }

		/// <summary>
        /// Gets or sets Vendor2
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Vendor", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Vendor2, Id = Index.Vendor2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string Vendor2 { get; set; }

		/// <summary>
		/// Gets or sets VDEXISTS2
		/// </summary>
        [Display(Name = "VendorExists", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.VendorExists2, Id = Index.VendorExists2, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorExists VendorExists2 { get; set; }

		/// <summary>
        /// Gets or sets Name2
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[Display(Name = "VendorName", ResourceType = typeof (POCommonResx))]
        [ViewField(Name = Fields.Name2, Id = Index.Name2, FieldType = EntityFieldType.Char, Size = 60)]
        public string Name2 { get; set; }

		/// <summary>
		/// Gets or sets OnHold
		/// </summary>
        [Display(Name = "OnHold", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.OnHold, Id = Index.OnHold, FieldType = EntityFieldType.Bool, Size = 2)]
		public OnHold OnHold { get; set; }

		/// <summary>
		/// Gets or sets OrderDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OrderDate", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.OrderDate, Id = Index.OrderDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime OrderDate { get; set; }

		/// <summary>
		/// Gets or sets DateRequired
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.DateRequired, Id = Index.DateRequired, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime DateRequired { get; set; }

		/// <summary>
		/// Gets or sets ExpirationDate
		/// </summary>
		[ValidateDateFormat(ErrorMessageResourceName="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExpirationDate", ResourceType = typeof(CommonResx))]
		[ViewField(Name = Fields.ExpirationDate, Id = Index.ExpirationDate, FieldType = EntityFieldType.Date, Size = 5)]
		public DateTime ExpirationDate { get; set; }

		/// <summary>
		/// Gets or sets Description
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RequisitionDescription", ResourceType = typeof(RequisitionEntryResx))]
		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
		public string Description { get; set; }

		/// <summary>
		/// Gets or sets Reference
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Reference", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
		public string Reference { get; set; }

		/// <summary>
		/// Gets or sets Comment
		/// </summary>
		[StringLength(250, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Comment", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.Comment, Id = Index.Comment, FieldType = EntityFieldType.Char, Size = 250)]
		public string Comment { get; set; }

		/// <summary>
        /// Gets or sets QuantityOrdered2
		/// </summary>
        [Display(Name = "QuantityOrdered", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.QuantityOrdered2, Id = Index.QuantityOrdered2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal QuantityOrdered2 { get; set; }

		/// <summary>
		/// Gets or sets Requestedby
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.Requestedby, Id = Index.Requestedby, FieldType = EntityFieldType.Char, Size = 60)]
		public string Requestedby { get; set; }

		/// <summary>
		/// Gets or sets DocumentSource
		/// </summary>
        [Display(Name = "DocumentSource", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.DocumentSource, Id = Index.DocumentSource, FieldType = EntityFieldType.Int, Size = 2)]
		public DocumentSource DocumentSource { get; set; }

		/// <summary>
		/// Gets or sets VALUES2
		/// </summary>
        [Display(Name = "OptionalFields", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.OptionalFields2, Id = Index.OptionalFields2, FieldType = EntityFieldType.Long, Size = 4)]
        public long OptionalFields2 { get; set; }

		/// <summary>
		/// Gets or sets JobRelatedLines
		/// </summary>
        [Display(Name = "JobRelatedLines", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.JobRelatedLines, Id = Index.JobRelatedLines, FieldType = EntityFieldType.Long, Size = 4)]
		public long JobRelatedLines { get; set; }

		/// <summary>
        /// Gets or sets ShipToLocation
		/// </summary>
		[StringLength(6, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ShipToLocation", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ShipToLocation, Id = Index.ShipToLocation, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ShipToLocation { get; set; }

		/// <summary>
		/// Gets or sets LocationDescription
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.LocationDescription, Id = Index.LocationDescription, FieldType = EntityFieldType.Char, Size = 60)]
		public string LocationDescription { get; set; }

		/// <summary>
		/// Gets or sets ApprovalStatus
		/// </summary>
		[ViewField(Name = Fields.ApprovalStatus, Id = Index.ApprovalStatus, FieldType = EntityFieldType.Int, Size = 2)]
		public ApprovalStatus ApprovalStatus { get; set; }

		/// <summary>
		/// Gets or sets ApproverID
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ApproverID, Id = Index.ApproverID, FieldType = EntityFieldType.Char, Size = 8)]
		public string ApproverID { get; set; }

		/// <summary>
		/// Gets or sets EnteredBy
		/// </summary>
		[StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EnteredBy", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.EnteredBy, Id = Index.EnteredBy, FieldType = EntityFieldType.Char, Size = 8)]
		public string EnteredBy { get; set; }

		/// <summary>
		/// Gets or sets EXTWEIGHT
		/// </summary>
        [Display(Name = "ExtendedWeight", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.ExtendedWeight1, Id = Index.ExtendedWeight1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal ExtendedWeight1 { get; set; }

		/// <summary>
		/// Gets or sets FuncExtendedAmount
		/// </summary>
		[ViewField(Name = Fields.FuncExtendedAmount, Id = Index.FuncExtendedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
		public decimal FuncExtendedAmount { get; set; }

		/// <summary>
        /// Gets or sets VendorOnHold2
		/// </summary>
        [Display(Name = "VendorOnHold", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.VendorOnHold2, Id = Index.VendorOnHold2, FieldType = EntityFieldType.Bool, Size = 2)]
        public VendorOnHold VendorOnHold2 { get; set; }

		/// <summary>
		/// Gets or sets DocumentLocked
		/// </summary>
        [Display(Name = "DocumentLocked", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.DocumentLocked, Id = Index.DocumentLocked, FieldType = EntityFieldType.Bool, Size = 2)]
		public DocumentLocked DocumentLocked { get; set; }

		/// <summary>
		/// Gets or sets RequisitionHasExpired
		/// </summary>
		[ViewField(Name = Fields.RequisitionHasExpired, Id = Index.RequisitionHasExpired, FieldType = EntityFieldType.Bool, Size = 2)]
		public RequisitionHasExpired RequisitionHasExpired { get; set; }

		/// <summary>
		/// Gets or sets IsDocumentDeletable
		/// </summary>
        [Display(Name = "IsDocumentDeletable", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.IsDocumentDeletable, Id = Index.IsDocumentDeletable, FieldType = EntityFieldType.Bool, Size = 2)]
		public IsDocumentDeletable IsDocumentDeletable { get; set; }

		/// <summary>
        /// Gets or sets IsRecordActive2
		/// </summary>
        [Display(Name = "IsRecordActive", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.IsRecordActive2, Id = Index.IsRecordActive2, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsRecordActive IsRecordActive2 { get; set; }

		/// <summary>
		/// Gets or sets HasDetails
		/// </summary>
        [Display(Name = "HasDetails", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.HasDetails, Id = Index.HasDetails, FieldType = EntityFieldType.Bool, Size = 2)]
		public HasDetails HasDetails { get; set; }

		/// <summary>
		/// Gets or sets IsCanadianPayrollActive
		/// </summary>
		[ViewField(Name = Fields.IsCanadianPayrollActive, Id = Index.IsCanadianPayrollActive, FieldType = EntityFieldType.Bool, Size = 2)]
		public IsCanadianPayrollActive IsCanadianPayrollActive { get; set; }

		/// <summary>
		/// Gets or sets IsUSPayrollActive
		/// </summary>
        [ViewField(Name = Fields.IsUsPayrollActive, Id = Index.IsUsPayrollActive, FieldType = EntityFieldType.Bool, Size = 2)]
        public IsUSPayrollActive IsUsPayrollActive { get; set; }

		/// <summary>
        /// Gets or sets Command2
		/// </summary>
        [Display(Name = "Command", ResourceType = typeof(PurchaseOrderEntryResx))]
        [ViewField(Name = Fields.Command2, Id = Index.Command2, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command2 { get; set; }

		/// <summary>
		/// Gets or sets JobRelated
		/// </summary>
        [Display(Name = "JobRelated", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.JobRelated, Id = Index.JobRelated, FieldType = EntityFieldType.Bool, Size = 2)]
		public JobRelated JobRelated { get; set; }

		/// <summary>
		/// Gets or sets ApproverName
		/// </summary>
		[StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		[ViewField(Name = Fields.ApproverName, Id = Index.ApproverName, FieldType = EntityFieldType.Char, Size = 60)]
		public string ApproverName { get; set; }

		/// <summary>
		/// Gets or sets FunctionalCurrency
		/// </summary>
		[StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(POCommonResx))]
		[ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
		public string FunctionalCurrency { get; set; }

		/// <summary>
		/// Gets or sets NextDetailNumber
		/// </summary>
        [Display(Name = "NextDetailNumber", ResourceType = typeof(PurchaseOrderEntryResx))]
		[ViewField(Name = Fields.NextDetailNumber, Id = Index.NextDetailNumber, FieldType = EntityFieldType.Int, Size = 2)]
		public int NextDetailNumber { get; set; }

		#region UI Strings
        /// <summary>
        ///  Gets or sets Header Optional Field
        /// </summary>       
        public EnumerableResponse<RequisitionHeaderOptionalField> RequisitionHeaderOptionalField { get; set; }

		/// <summary>
        /// Gets VendorExists string value
		/// </summary>
        public string VendorExistsString
		{
			get { return EnumUtility.GetStringValue(VendorExists); }
		}

		/// <summary>
		/// Gets StoredInDatabaseTable string value
		/// </summary>
		public string StoredInDatabaseTableString
		{
			get { return EnumUtility.GetStringValue(StoredInDatabaseTable); }
		}

		/// <summary>
		/// Gets CompletionStatus string value
		/// </summary>
		public string CompletionStatusString
		{
			get { return EnumUtility.GetStringValue(CompletionStatus); }
		}

		/// <summary>
		/// Gets ItemExists string value
		/// </summary>
		public string ItemExistsString
		{
			get { return EnumUtility.GetStringValue(ItemExists); }
		}

		/// <summary>
		/// Gets CommentsInstructions string value
		/// </summary>
		public string CommentsInstructionsString
		{
			get { return EnumUtility.GetStringValue(CommentsInstructions); }
		}

		/// <summary>
		/// Gets DropShip string value
		/// </summary>
		public string DropShipString
		{
			get { return EnumUtility.GetStringValue(DropShip); }
		}

		/// <summary>
		/// Gets DropShipType string value
		/// </summary>
		public string DropShipTypeString
		{
			get { return EnumUtility.GetStringValue(DropShipType); }
		}

		/// <summary>
		/// Gets StockItem string value
		/// </summary>
		public string StockItemString
		{
			get { return EnumUtility.GetStringValue(StockItem); }
		}

		/// <summary>
		/// Gets CostClass string value
		/// </summary>
		public string CostClassString
		{
			get { return EnumUtility.GetStringValue(CostClass); }
		}

		/// <summary>
        /// Gets VendorOnHold string value
		/// </summary>
        public string VendorOnHoldString
		{
			get { return EnumUtility.GetStringValue(VendorOnHold); }
		}

		/// <summary>
		/// Gets UseICVendor string value
		/// </summary>
		public string UseICVendorString
		{
			get { return EnumUtility.GetStringValue(UseICVendor); }
		}

		/// <summary>
        /// Gets Completed string value
		/// </summary>
        public string CompletedString
		{
			get { return EnumUtility.GetStringValue(Completed); }
		}

		/// <summary>
        /// Gets IsRecordActive string value
		/// </summary>
        public string IsRecordActiveString
		{
			get { return EnumUtility.GetStringValue(IsRecordActive); }
		}

		/// <summary>
		/// Gets MapManufacturersItemNumber string value
		/// </summary>
		public string MapManufacturersItemNumberString
		{
			get { return EnumUtility.GetStringValue(MapManufacturersItemNumber); }
		}

		/// <summary>
        /// Gets Command string value
		/// </summary>
        public string CommandString
		{
			get { return EnumUtility.GetStringValue(Command); }
		}

		/// <summary>
		/// Gets ProjectStyle string value
		/// </summary>
		public string ProjectStyleString
		{
			get { return EnumUtility.GetStringValue(ProjectStyle); }
		}

		/// <summary>
		/// Gets ProjectType string value
		/// </summary>
		public string ProjectTypeString
		{
			get { return EnumUtility.GetStringValue(ProjectType); }
		}

		/// <summary>
		/// Gets UnitCostIsManual string value
		/// </summary>
		public string UnitCostIsManualString
		{
			get { return EnumUtility.GetStringValue(UnitCostIsManual); }
		}

		/// <summary>
		/// Gets CopyCostToPurchaseOrder string value
		/// </summary>
		public string CopyCostToPurchaseOrderString
		{
			get { return EnumUtility.GetStringValue(CopyCostToPurchaseOrder); }
		}

		/// <summary>
		/// Gets ExchangeRateExists string value
		/// </summary>
		public string ExchangeRateExistsString
		{
			get { return EnumUtility.GetStringValue(ExchangeRateExists); }
		}

		/// <summary>
		/// Gets RateOperation string value
		/// </summary>
		public string RateOperationString
		{
			get { return EnumUtility.GetStringValue(RateOperation); }
		}

		/// <summary>
		/// Gets Printed string value
		/// </summary>
		public string PrintedString
		{
			get { return EnumUtility.GetStringValue(Printed); }
		}

		/// <summary>
        /// Gets Completed22 string value
		/// </summary>
        public string Completed2String
		{
			get { return EnumUtility.GetStringValue(Completed2); }
		}

		/// <summary>
        /// Gets VendorExists22 string value
		/// </summary>
        public string VendorExists22String
		{
			get { return EnumUtility.GetStringValue(VendorExists2); }
		}

		/// <summary>
		/// Gets OnHold string value
		/// </summary>
		public string OnHoldString
		{
			get { return EnumUtility.GetStringValue(OnHold); }
		}

		/// <summary>
		/// Gets DocumentSource string value
		/// </summary>
		public string DocumentSourceString
		{
			get { return EnumUtility.GetStringValue(DocumentSource); }
		}

		/// <summary>
		/// Gets ApprovalStatus string value
		/// </summary>
		public string ApprovalStatusString
		{
			get { return EnumUtility.GetStringValue(ApprovalStatus); }
		}

		/// <summary>
        /// Gets VendorOnHold2 string value
		/// </summary>
        public string VendorOnHold2String
		{
			get { return EnumUtility.GetStringValue(VendorOnHold2); }
		}

		/// <summary>
		/// Gets DocumentLocked string value
		/// </summary>
		public string DocumentLockedString
		{
			get { return EnumUtility.GetStringValue(DocumentLocked); }
		}

		/// <summary>
		/// Gets RequisitionHasExpired string value
		/// </summary>
		public string RequisitionHasExpiredString
		{
			get { return EnumUtility.GetStringValue(RequisitionHasExpired); }
		}

		/// <summary>
		/// Gets IsDocumentDeletable string value
		/// </summary>
		public string IsDocumentDeletableString
		{
			get { return EnumUtility.GetStringValue(IsDocumentDeletable); }
		}

		/// <summary>
        /// Gets IsRecordActive2 string value
		/// </summary>
        public string IsRecordActive2String
		{
			get { return EnumUtility.GetStringValue(IsRecordActive2); }
		}

		/// <summary>
		/// Gets HasDetails string value
		/// </summary>
		public string HasDetailsString
		{
			get { return EnumUtility.GetStringValue(HasDetails); }
		}

		/// <summary>
		/// Gets IsCanadianPayrollActive string value
		/// </summary>
		public string IsCanadianPayrollActiveString
		{
			get { return EnumUtility.GetStringValue(IsCanadianPayrollActive); }
		}

		/// <summary>
		/// Gets IsUSPayrollActive string value
		/// </summary>
		public string IsUsPayrollActiveString
		{
            get { return EnumUtility.GetStringValue(IsUsPayrollActive); }
		}

		/// <summary>
        /// Gets Command2 string value
		/// </summary>
        public string Command2String
		{
			get { return EnumUtility.GetStringValue(Command2); }
		}

		/// <summary>
		/// Gets JobRelated string value
		/// </summary>
		public string JobRelatedString
		{
			get { return EnumUtility.GetStringValue(JobRelated); }
		}
		#endregion
	}
}
