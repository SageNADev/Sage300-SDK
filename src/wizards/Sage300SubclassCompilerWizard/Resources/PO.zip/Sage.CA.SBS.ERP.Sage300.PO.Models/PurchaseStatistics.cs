// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;
using System.ComponentModel.DataAnnotations;
using APResx = Sage.CA.SBS.ERP.Sage300.AP.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
    /// Partial class for Statistic
    /// </summary>
    public partial class PurchaseStatistics : ModelBase
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public PurchaseStatistics()
        {
            PurchaseList = new EnumerableResponse<Purchase>();
            InvoicesAndCreditDebitNotesList = new EnumerableResponse<InvoicesAndCreditDebitNotes>();
        }

        /// <summary>
        /// Gets or sets FiscalYear
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Year", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Period", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Currency
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Currency", ResourceType = typeof(POCommonResx))]
        [ViewField(Name = Fields.Currency, Id = Index.Currency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string Currency { get; set; }

        /// <summary>
        /// Gets or sets NumberOfPurchaseOrders
        /// </summary>
        [Display(Name = "RowtitleNumberOfPOs", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.NumberOfPurchaseOrders, Id = Index.NumberOfPurchaseOrders, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfPurchaseOrders { get; set; }

        /// <summary>
        /// Gets or sets NumberOfReceipts
        /// </summary>
        [Display(Name = "NumberOfReceipts", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.NumberOfReceipts, Id = Index.NumberOfReceipts, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfReceipts { get; set; }

        /// <summary>
        /// Gets or sets NetQuantityPurchased
        /// </summary>
        [Display(Name = "RowtitleNetQtyPurchased", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.NetQuantityPurchased, Id = Index.NetQuantityPurchased, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 4)]
        public decimal NetQuantityPurchased { get; set; }

        /// <summary>
        /// Gets or sets FuncNetPurchaseAmount
        /// </summary>
        [Display(Name = "FuncNetPurchaseAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncNetPurchaseAmount, Id = Index.FuncNetPurchaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncNetPurchaseAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceNetPurchaseAmount
        /// </summary>
        [Display(Name = "SrceNetPurchaseAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceNetPurchaseAmount, Id = Index.SrceNetPurchaseAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceNetPurchaseAmount { get; set; }

        /// <summary>
        /// Gets or sets FuncInvoiceAmount
        /// </summary>
        [Display(Name = "FuncInvoiceAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncInvoiceAmount, Id = Index.FuncInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceInvoiceAmount
        /// </summary>
        [Display(Name = "SrceInvoiceAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceInvoiceAmount, Id = Index.SrceInvoiceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceInvoiceAmount { get; set; }

        /// <summary>
        /// Gets or sets NumberOfInvoices
        /// </summary>
        [Display(Name = "NumberofInvoices", ResourceType = typeof(APResx.APCommonResx))]
        [ViewField(Name = Fields.NumberOfInvoices, Id = Index.NumberOfInvoices, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfInvoices { get; set; }

        /// <summary>
        /// Gets or sets FuncAverageInvoice
        /// </summary>
        [Display(Name = "FuncAverageInvoice", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncAverageInvoice, Id = Index.FuncAverageInvoice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAverageInvoice { get; set; }

        /// <summary>
        /// Gets or sets SrceAverageInvoice
        /// </summary>
        [Display(Name = "SrceAverageInvoice", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceAverageInvoice, Id = Index.SrceAverageInvoice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceAverageInvoice { get; set; }

        /// <summary>
        /// Gets or sets FuncLargestInvoice
        /// </summary>
        [Display(Name = "FuncLargestInvoice", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncLargestInvoice, Id = Index.FuncLargestInvoice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets SrceLargestInvoice
        /// </summary>
        [Display(Name = "SrceLargestInvoice", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceLargestInvoice, Id = Index.SrceLargestInvoice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceLargestInvoice { get; set; }

        /// <summary>
        /// Gets or sets LargestInvoiceVendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LargestInvoiceVendor", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.LargestInvoiceVendor, Id = Index.LargestInvoiceVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string LargestInvoiceVendor { get; set; }

        /// <summary>
        /// Gets or sets FuncSmallestInvoice
        /// </summary>
        [Display(Name = "FuncSmallestInvoice", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncSmallestInvoice, Id = Index.FuncSmallestInvoice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncSmallestInvoice { get; set; }

        /// <summary>
        /// Gets or sets SrceSmallestInvoice
        /// </summary>
        [Display(Name = "SrceSmallestInvoice", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceSmallestInvoice, Id = Index.SrceSmallestInvoice, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceSmallestInvoice { get; set; }

        /// <summary>
        /// Gets or sets SmallestInvoiceVendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SmallestInvoiceVendor", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SmallestInvoiceVendor, Id = Index.SmallestInvoiceVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string SmallestInvoiceVendor { get; set; }

        /// <summary>
        /// Gets or sets FuncCreditNoteAmount
        /// </summary>
        [Display(Name = "FuncCreditNoteAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncCreditNoteAmount, Id = Index.FuncCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceCreditNoteAmount
        /// </summary>
        [Display(Name = "SrceCreditNoteAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceCreditNoteAmount, Id = Index.SrceCreditNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceCreditNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets NumberOfCreditNotes
        /// </summary>
        [Display(Name = "NumberofCreditNotes", ResourceType = typeof(APResx.APCommonResx))]
        [ViewField(Name = Fields.NumberOfCreditNotes, Id = Index.NumberOfCreditNotes, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfCreditNotes { get; set; }

        /// <summary>
        /// Gets or sets FuncAverageCreditNote
        /// </summary>
        [Display(Name = "FuncAverageCreditNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncAverageCreditNote, Id = Index.FuncAverageCreditNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAverageCreditNote { get; set; }

        /// <summary>
        /// Gets or sets SrceAverageCreditNote
        /// </summary>
        [Display(Name = "SrceAverageCreditNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceAverageCreditNote, Id = Index.SrceAverageCreditNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceAverageCreditNote { get; set; }

        /// <summary>
        /// Gets or sets FuncLargestCreditNote
        /// </summary>
        [Display(Name = "FuncLargestCreditNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncLargestCreditNote, Id = Index.FuncLargestCreditNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncLargestCreditNote { get; set; }

        /// <summary>
        /// Gets or sets SrceLargestCreditNote
        /// </summary>
        [Display(Name = "SrceLargestCreditNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceLargestCreditNote, Id = Index.SrceLargestCreditNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceLargestCreditNote { get; set; }

        /// <summary>
        /// Gets or sets LargestCreditNoteVendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LargestCreditNoteVendor", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.LargestCreditNoteVendor, Id = Index.LargestCreditNoteVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string LargestCreditNoteVendor { get; set; }

        /// <summary>
        /// Gets or sets FuncSmallestCreditNote
        /// </summary>
        [Display(Name = "FuncSmallestCreditNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncSmallestCreditNote, Id = Index.FuncSmallestCreditNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncSmallestCreditNote { get; set; }

        /// <summary>
        /// Gets or sets SrceSmallestCreditNote
        /// </summary>
        [Display(Name = "SrceSmallestCreditNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceSmallestCreditNote, Id = Index.SrceSmallestCreditNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceSmallestCreditNote { get; set; }

        /// <summary>
        /// Gets or sets SmallestCreditNoteVendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SmallestCreditNoteVendor", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SmallestCreditNoteVendor, Id = Index.SmallestCreditNoteVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string SmallestCreditNoteVendor { get; set; }

        /// <summary>
        /// Gets or sets FuncDebitNoteAmount
        /// </summary>
        [Display(Name = "FuncDebitNoteAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncDebitNoteAmount, Id = Index.FuncDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets SrceDebitNoteAmount
        /// </summary>
        [Display(Name = "SrceDebitNoteAmount", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceDebitNoteAmount, Id = Index.SrceDebitNoteAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceDebitNoteAmount { get; set; }

        /// <summary>
        /// Gets or sets NumberOfDebitNotes
        /// </summary>
        [Display(Name = "NumberofDebitNotes", ResourceType = typeof(APResx.APCommonResx))]
        [ViewField(Name = Fields.NumberOfDebitNotes, Id = Index.NumberOfDebitNotes, FieldType = EntityFieldType.Long, Size = 4)]
        public long NumberOfDebitNotes { get; set; }

        /// <summary>
        /// Gets or sets FuncAverageDebitNote
        /// </summary>
        [Display(Name = "FuncAverageDebitNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncAverageDebitNote, Id = Index.FuncAverageDebitNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncAverageDebitNote { get; set; }

        /// <summary>
        /// Gets or sets SrceAverageDebitNote
        /// </summary>
        [Display(Name = "SrceAverageDebitNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceAverageDebitNote, Id = Index.SrceAverageDebitNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceAverageDebitNote { get; set; }

        /// <summary>
        /// Gets or sets FuncLargestDebitNote
        /// </summary>
        [Display(Name = "FuncLargestDebitNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncLargestDebitNote, Id = Index.FuncLargestDebitNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncLargestDebitNote { get; set; }

        /// <summary>
        /// Gets or sets SrceLargestDebitNote
        /// </summary>
        [Display(Name = "SrceLargestDebitNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceLargestDebitNote, Id = Index.SrceLargestDebitNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceLargestDebitNote { get; set; }

        /// <summary>
        /// Gets or sets LargestDebitNoteVendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "LargestDebitNoteVendor", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.LargestDebitNoteVendor, Id = Index.LargestDebitNoteVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string LargestDebitNoteVendor { get; set; }

        /// <summary>
        /// Gets or sets FuncSmallestDebitNote
        /// </summary>
        [Display(Name = "FuncSmallestDebitNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.FuncSmallestDebitNote, Id = Index.FuncSmallestDebitNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FuncSmallestDebitNote { get; set; }

        /// <summary>
        /// Gets or sets SrceSmallestDebitNote
        /// </summary>
        [Display(Name = "SrceSmallestDebitNote", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SrceSmallestDebitNote, Id = Index.SrceSmallestDebitNote, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SrceSmallestDebitNote { get; set; }

        /// <summary>
        /// Gets or sets SmallestDebitNoteVendor
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SmallestDebitNoteVendor", ResourceType = typeof(PurchaseStatisticsResx))]
        [ViewField(Name = Fields.SmallestDebitNoteVendor, Id = Index.SmallestDebitNoteVendor, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string SmallestDebitNoteVendor { get; set; }

        /// <summary>
        /// Purchases List
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<Purchase> PurchaseList { get; set; }

        /// <summary>
        /// InvoicesAndCreditDebitNotesList
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<InvoicesAndCreditDebitNotes> InvoicesAndCreditDebitNotesList { get; set; }

        /// <summary>
        /// Is New Mode
        /// </summary>
        [IgnoreExportImport]
        public bool IsNewMode { get; set; }

        /// <summary>
        /// Fiscal Period Start  year
        /// </summary>
        [IgnoreExportImport]
        public string StartYear { get; set; }

        /// <summary>
        /// Fiscal Period End year
        /// </summary>
        [IgnoreExportImport]
        public string EndYear { get; set; }

        /// <summary>
        /// Gets or Sets IsMulticurrency.
        /// </summary>
        [IgnoreExportImport]
        public bool IsMulticurrency { get; set; }
    }


    /// <summary>
    /// Class for Purchases Grid
    /// </summary>
    public class Purchase : ModelBase
    {
        /// <summary>
        /// Purchase Grid Header
        /// </summary>
        public string PurchaseHeader { get; set; }

        /// <summary>
        /// Vendor Currency 
        /// </summary>
        [Display(Name = "VendorCurrency", ResourceType = typeof(POCommonResx))]
        public string VendorCurrencyAmount { get; set; }

        /// <summary>
        /// Functional Currency Amount
        /// </summary>
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(CommonResx))]
        public string FunctionalCurrencyAmount { get; set; }
    }

    /// <summary>
    /// Class for InvoicesAndCreditDebitNotes Grid
    /// </summary>
    public class InvoicesAndCreditDebitNotes : ModelBase
    {
        /// <summary>
        /// Purchase Grid Header
        /// </summary>
        public string InvoicesHeader { get; set; }

        /// <summary>
        /// Vendor Currency 
        /// </summary>
        [Display(Name = "ColtitleInvoiceVendorCurr", ResourceType = typeof(PurchaseStatisticsResx))]
        public string InvoiceVendorCurrencyAmount { get; set; }

        /// <summary>
        /// Vendor Currency 
        /// </summary>
        [Display(Name = "ColtitleInvoiceFunctioalCurr", ResourceType = typeof(PurchaseStatisticsResx))]
        public string InvoiceFunctionalCurrencyAmount { get; set; }

        /// <summary>
        /// Vendor Currency 
        /// </summary>
        [Display(Name = "ColtitleCrNotesVendorCurr", ResourceType = typeof(PurchaseStatisticsResx))]
        public string CreditNotesVendorCurrencyAmount { get; set; }

        /// <summary>
        /// Vendor Currency 
        /// </summary>
        [Display(Name = "ColtitleCrNotesFunctionalCurr", ResourceType = typeof(PurchaseStatisticsResx))]
        public string CreditNotesFunctionalCurrencyAmount { get; set; }

        /// <summary>
        /// Vendor Currency 
        /// </summary>
        [Display(Name = "ColtitleDbNotesVendorCurr", ResourceType = typeof(PurchaseStatisticsResx))]
        public string DebitNotesVendorCurrencyAmount { get; set; }

        /// <summary>
        /// Vendor Currency 
        /// </summary>
        [Display(Name = "ColtitelDbNotesFunctionalCurr", ResourceType = typeof(PurchaseStatisticsResx))]
        public string DebitNotesFunctionalCurrencyAmount { get; set; }
    }
}
