// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.PO.Resources;
using Sage.CA.SBS.ERP.Sage300.PO.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.PO.Models
{
    /// <summary>
     /// Partial class for PurchaseOrderRequisition
     /// </summary>
     public partial class PurchaseOrderRequisition : ModelBase
     {
          /// <summary>
          /// Gets or sets PurchaseOrderSequenceKey
          /// </summary>
          [Key]
          [Display(Name = "PurchaseOrderSequenceKey", ResourceType = typeof(PurchaseOrderEntryResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.PurchaseOrderSequenceKey, Id = Index.PurchaseOrderSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal PurchaseOrderSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets LineNumber
          /// </summary>
          [Key]
          [Display(Name = "LineNumber", ResourceType = typeof(POCommonResx))]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal LineNumber {get; set;}

          /// <summary>
          /// Gets or sets RequisitionSequenceKey
          /// </summary>
          [IgnoreExportImport]
          [ViewField(Name = Fields.RequisitionSequenceKey, Id = Index.RequisitionSequenceKey, FieldType = EntityFieldType.Decimal, Size = 10)]
          public decimal RequisitionSequenceKey {get; set;}

          /// <summary>
          /// Gets or sets RequisitionNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "RequisitionNumber", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.RequisitionNumber, Id = Index.RequisitionNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
          public string RequisitionNumber {get; set;}

          /// <summary>
          /// Gets or sets CompletionStatus
          /// </summary>
          [IgnoreExportImport] 
          [ViewField(Name = Fields.CompletionStatus, Id = Index.CompletionStatus, FieldType = EntityFieldType.Int, Size = 2)]
          public CompletionStatus CompletionStatus {get; set;}

          /// <summary>
          /// Gets or sets DateOrdered
          /// </summary>
          [IgnoreExportImport]
          [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [Display(Name = "DateOrdered", ResourceType = typeof(PurchaseOrderEntryResx))]
          [ViewField(Name = Fields.DateOrdered, Id = Index.DateOrdered, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime DateOrdered { get; set; }

          /// <summary>
          /// Gets or sets UseBlankVendors
          /// </summary>
          [Display(Name = "UseBlankVendors", ResourceType = typeof(PurchaseOrderEntryResx))]
          [ViewField(Name = Fields.UseBlankVendors, Id = Index.UseBlankVendors, FieldType = EntityFieldType.Bool, Size = 2)]
          public UseBlankVendors UseBlankVendors { get; set; }

          /// <summary>
          /// Gets or sets UseICVendor
          /// </summary>
          [Display(Name = "UseVendorType", ResourceType = typeof(PurchaseOrderEntryResx))]
          [ViewField(Name = Fields.UseICVendor, Id = Index.UseICVendor, FieldType = EntityFieldType.Int, Size = 2)]
          public UseICVendor UseICVendor { get; set; }

          /// <summary>
          /// Gets or sets StoredInDatabaseTable
          /// </summary>
          [IgnoreExportImport] 
          [ViewField(Name = Fields.StoredInDatabaseTable, Id = Index.StoredInDatabaseTable, FieldType = EntityFieldType.Bool, Size = 2)]
          public StoredInDatabaseTable StoredInDatabaseTable {get; set;}

          /// <summary>
          /// Gets or sets Ordered
          /// </summary>
          [IgnoreExportImport] 
          [Display(Name = "Ordered", ResourceType = typeof(POCommonResx))]
          [ViewField(Name = Fields.Ordered, Id = Index.Ordered, FieldType = EntityFieldType.Bool, Size = 2)]
          public Ordered Ordered { get; set; }

          /// <summary>
          /// Gets or sets RequisitionOrdered
          /// </summary>
          [IgnoreExportImport] 
          [ViewField(Name = Fields.RequisitionOrdered, Id = Index.RequisitionOrdered, FieldType = EntityFieldType.Long, Size = 4)]
          public long RequisitionOrdered {get; set;}

          /// <summary>
          /// Gets or sets Line
          /// </summary>
          [IgnoreExportImport] 
          [ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
          public long Line {get; set;}


          #region UI

          /// <summary>
          /// Get Vendor list
          /// </summary>
          [IgnoreExportImport]
          public IEnumerable<CustomSelectList> UseICVendorList
          {
              get { return EnumUtility.GetItemsList<UseICVendor>(); }
          }

          /// <summary>
          /// Get Use Blank Vendors list
          /// </summary>
          [IgnoreExportImport]  
          public IEnumerable<CustomSelectList> UseBlankVendorsList
          {
              get { return EnumUtility.GetItemsList<UseBlankVendors>(); }
          }

          /// <summary>
          ///  Gets or sets Attributes
          /// </summary>
          [IgnoreExportImport]
          public IDictionary<string, object> Attributes { get; set; }

          #endregion
     }
}
