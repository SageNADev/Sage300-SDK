// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Model class for Bank Journal Transaction Detail
    /// </summary>
    public partial class BankJournalTransactionDetail : ModelBase
    {

        /// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionHeaderSerial 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.TransactionHeaderSerial, Id = Index.TransactionHeaderSerial, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long TransactionHeaderSerial { get; set; }

        /// <summary>
        /// Gets or sets TransactionDetailLine 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.TransactionDetailLine, Id = Index.TransactionDetailLine, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionDetailLine { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets TransactionDetailStatus 
        /// </summary>

        [ViewField(Name = Fields.TransactionDetailStatus, Id = Index.TransactionDetailStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionDetailStatus TransactionDetailStatus { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets DetailTransactionType 
        /// </summary>
        [ViewField(Name = Fields.DetailTransactionType, Id = Index.DetailTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DetailTransactionType DetailTransactionType { get; set; }

        /// <summary>
        /// Gets or sets RemittanceID 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.RemittanceID, Id = Index.RemittanceID, FieldType = EntityFieldType.Char, Size = 24)]
        public string RemittanceID { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNumber 
        /// </summary>
        [ViewField(Name = Fields.PostingSequenceNumber, Id = Index.PostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TransactionReference, Id = Index.TransactionReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionReference { get; set; }

        /// <summary>
        /// Gets or sets TransactionDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.TransactionDescription, Id = Index.TransactionDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionDescription { get; set; }

        /// <summary>
        /// Gets or sets PayerCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PayerCode, Id = Index.PayerCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PayerCode { get; set; }

        /// <summary>
        /// Gets or sets PayeeName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PayeeName, Id = Index.PayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PayeeName { get; set; }

        /// <summary>
        /// Gets or sets VendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets SourceTransactionAmount 
        /// </summary>
        [ViewField(Name = Fields.SourceTransactionAmount, Id = Index.SourceTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTransactionAmount 
        /// </summary>
        [ViewField(Name = Fields.FunctionalTransactionAmount, Id = Index.FunctionalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeRateType, Id = Index.ExchangeRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ExchangeRateType { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReceiptCurrency, Id = Index.ReceiptCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ReceiptCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExchangeRateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread 
        /// </summary>
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        //[ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets GLAccountOverride 
        /// </summary>
        [ViewField(Name = Fields.GLAccountOverride, Id = Index.GLAccountOverride, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool GLAccountOverride { get; set; }

        /// <summary>
        /// Gets or sets DrilldownType 
        /// </summary>
        [ViewField(Name = Fields.DrilldownType, Id = Index.DrilldownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrilldownType { get; set; }

        /// <summary>
        /// Gets or sets DrilldownLink 
        /// </summary>
        [ViewField(Name = Fields.DrilldownLink, Id = Index.DrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrilldownLink { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationStatus 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationStatus, Id = Index.ReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionDetailStatus ReconciliationStatus { get; set; }

        /// <summary>
        /// Gets or sets StatusChangeDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.StatusChangeDate, Id = Index.StatusChangeDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StatusChangeDate { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReconciliationDescription, Id = Index.ReconciliationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReconciliationDescription { get; set; }

        /// <summary>
        /// Gets or sets ClearedAmount 
        /// </summary>
        [ViewField(Name = Fields.ClearedAmount, Id = Index.ClearedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClearedAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.ReconciliationPostingDate, Id = Index.ReconciliationPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReconciliationPostingDate { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ReconciliationPostingYear, Id = Index.ReconciliationPostingYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ReconciliationPostingYear { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingPeriod 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationPostingPeriod, Id = Index.ReconciliationPostingPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationPostingPeriod { get; set; }

        /// <summary>
        /// Gets or sets Reconciled 
        /// </summary>
        [ViewField(Name = Fields.Reconciled, Id = Index.Reconciled, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Reconciled { get; set; }

        /// <summary>
        /// Gets or sets RemainingInTransitAmount 
        /// </summary>

        [ViewField(Name = Fields.RemainingInTransitAmount, Id = Index.RemainingInTransitAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingInTransitAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationError 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationError, Id = Index.ReconciliationError, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationError { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationErrorPending 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationErrorPending, Id = Index.ReconciliationErrorPending, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationErrorPending { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeGain 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationExchangeGain, Id = Index.ReconciliationExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeLoss 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationExchangeLoss, Id = Index.ReconciliationExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationSuggestion 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationSuggestion, Id = Index.ReconciliationSuggestion, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionDetailStatus ReconciliationSuggestion { get; set; }

        /// <summary>
        /// Gets or sets TransactionAmount 
        /// </summary>
        [ViewField(Name = Fields.TransactionAmount, Id = Index.TransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets OutstandingAmount 
        /// </summary>
        [ViewField(Name = Fields.OutstandingAmount, Id = Index.OutstandingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OutstandingAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationTarget 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationTarget, Id = Index.ReconciliationTarget, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationTarget { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationCreditCardCharg 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationCreditCardCharg, Id = Index.ReconciliationCreditCardCharg, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationCreditCardCharg { get; set; }

        /// <summary>
        /// Gets or sets WriteOffAmount 
        /// </summary>
        [ViewField(Name = Fields.WriteOffAmount, Id = Index.WriteOffAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WriteOffAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets SummatedTransactionAmount 
        /// </summary>
        [ViewField(Name = Fields.SummatedTransactionAmount, Id = Index.SummatedTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SummatedTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationSpread 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationSpread, Id = Index.ReconciliationSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationSpread { get; set; }

        /// <summary>
        /// Gets or sets FiscalTransactionRemainingIn 
        /// </summary>
        [ViewField(Name = Fields.FiscalTransactionRemainingIn, Id = Index.FiscalTransactionRemainingIn, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalTransactionRemainingIn { get; set; }

        /// <summary>
        /// Gets or sets FiscalOutstandingAmount 
        /// </summary>
        [ViewField(Name = Fields.FiscalOutstandingAmount, Id = Index.FiscalOutstandingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalOutstandingAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalWriteOffs 
        /// </summary>
        [ViewField(Name = Fields.FiscalWriteOffs, Id = Index.FiscalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets FiscalBankErrors 
        /// </summary>
        [ViewField(Name = Fields.FiscalBankErrors, Id = Index.FiscalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalBankErrors { get; set; }

        /// <summary>
        /// Gets or sets FiscalExchangeGain 
        /// </summary>
        [ViewField(Name = Fields.FiscalExchangeGain, Id = Index.FiscalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets FiscalExchangeLoss 
        /// </summary>
        [ViewField(Name = Fields.FiscalExchangeLoss, Id = Index.FiscalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets FiscalCreditCardCharge 
        /// </summary>
        [ViewField(Name = Fields.FiscalCreditCardCharge, Id = Index.FiscalCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalCreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets FiscalCleared 
        /// </summary>
        [ViewField(Name = Fields.FiscalCleared, Id = Index.FiscalCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalCleared { get; set; }

        /// <summary>
        /// Gets or sets FiscalFunctionalAmount 
        /// </summary>
        [ViewField(Name = Fields.FiscalFunctionalAmount, Id = Index.FiscalFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalOriginalTransactionAmou 
        /// </summary>
        [ViewField(Name = Fields.FiscalOriginalTransactionAmou, Id = Index.FiscalOriginalTransactionAmou, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalOriginalTransactionAmou { get; set; }

        /// <summary>
        /// Gets or sets TotalBookAmount 
        /// </summary>
        [ViewField(Name = Fields.TotalBookAmount, Id = Index.TotalBookAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalBookAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalBookAmount 
        /// </summary>
        [ViewField(Name = Fields.FiscalBookAmount, Id = Index.FiscalBookAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalBookAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalRemainingAmount 
        /// </summary>
        [ViewField(Name = Fields.TotalRemainingAmount, Id = Index.TotalRemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalRemainingAmount 
        /// </summary>
        [ViewField(Name = Fields.FiscalRemainingAmount, Id = Index.FiscalRemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalRemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalWriteOffToThisPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalWriteOffToThisPeriod, Id = Index.FiscalWriteOffToThisPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWriteOffToThisPeriod { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToFuture 
        /// </summary>
        [ViewField(Name = Fields.FiscalClearedToFuture, Id = Index.FiscalClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToCurrent 
        /// </summary>
        [ViewField(Name = Fields.FiscalClearedToCurrent, Id = Index.FiscalClearedToCurrent, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToCurrent { get; set; }

        /// <summary>
        /// Gets or sets CurrentPeriodsWriteOff 
        /// </summary>
        [ViewField(Name = Fields.CurrentPeriodsWriteOff, Id = Index.CurrentPeriodsWriteOff, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentPeriodsWriteOff { get; set; }

        /// <summary>
        /// Gets or sets PostedFiscalClearedToFuture 
        /// </summary>
        [ViewField(Name = Fields.PostedFiscalClearedToFuture, Id = Index.PostedFiscalClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PostedFiscalClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets CheckStockCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.CheckStockCode, Id = Index.CheckStockCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CheckStockCode { get; set; }

        /// <summary>
        /// Gets or sets OFXTransactionID 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.OFXTransactionID, Id = Index.OFXTransactionID, FieldType = EntityFieldType.Char, Size = 50)]
        public string OFXTransactionID { get; set; }

        /// <summary>
        /// Gets or sets FutureReconciliationDelta 
        /// </summary>
        [ViewField(Name = Fields.FutureReconciliationDelta, Id = Index.FutureReconciliationDelta, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FutureReconciliationDelta { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReversalOrReturnDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.ReversalOrReturnDate, Id = Index.ReversalOrReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReversalOrReturnDate { get; set; }

        /// <summary>
        /// Gets or sets SourceDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.SourceDocumentNumber, Id = Index.SourceDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string SourceDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CanReverseInvoice 
        /// </summary>
        [ViewField(Name = Fields.CanReverseInvoice, Id = Index.CanReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency CanReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets ReverseInvoice 
        /// </summary>
        [ViewField(Name = Fields.ReverseInvoice, Id = Index.ReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public Multicurrency ReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets ReconciledandJournaledTransac 
        /// </summary>
        [ViewField(Name = Fields.ReconciledandJournaledTransac, Id = Index.ReconciledandJournaledTransac, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciledandJournaledTransac ReconciledandJournaledTransac { get; set; }

        /// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public int EntryType { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationAmountDelta 
        /// </summary>
        [ViewField(Name = Fields.ReconciliationAmountDelta, Id = Index.ReconciliationAmountDelta, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationAmountDelta { get; set; }

        /// <summary>
        /// Gets or sets DocumentPostedDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.DocumentPostedDate, Id = Index.DocumentPostedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentPostedDate { get; set; }

        /// <summary>
        /// Gets or sets ReconciledBy 
        /// </summary>
        [ViewField(Name = Fields.ReconciledBy, Id = Index.ReconciledBy, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciledBy ReconciledBy { get; set; }
    }
}
