// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class Post Reconciliation
    /// </summary>
    public partial class PostReconciliation : ModelBase
    {
        /// <summary>
        /// Gets or sets Posting Operation 
        /// </summary>
        [ViewField(Name = Fields.PostingOperation, Id = Index.PostingOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public PostingOperation PostingOperation { get; set; }

        /// <summary>
        /// Gets or sets Beginning Bank Code 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.BeginningBankCode, Id = Index.BeginningBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BeginningBankCode { get; set; }

        /// <summary>
        /// Gets or sets Ending Bank Code 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.EndingBankCode, Id = Index.EndingBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EndingBankCode { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Through Date 
        /// </summary>
        [ValidateDateFormat(ErrorMessage = @"DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThroughDate, Id = Index.ThroughDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ThroughDate { get; set; }

        /// <summary>
        /// Gets or sets Post Bank
        /// </summary>
        public PostBank PostBank { get; set; }
    }
}
