﻿
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.ExportImport;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// ImportOFXStatement Request 
    /// </summary>
    public class ImportOFXRequest : ModelBase
    {
        /// <summary>
        /// Property for From Bank Code 
        /// </summary>
        public string FromBankCode { get; set; }

        /// <summary>
        /// Property for To Bank Code 
        /// </summary>
        public string ToBankCode { get; set; }

        /// <summary>
        /// Property for To Request
        /// </summary>
        public ImportRequest Request { get; set; }
    }
}
