// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

# region references

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using FiscalPeriod = Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.FiscalPeriod;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Model class for BankTransactionDetails
    /// </summary>
    public partial class BankTransactionDetail : ModelBase
    {
        # region properties

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "BankCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets TransactionHeaderSerial 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "TransactionHeaderSerial", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionHeaderSerial, Id = Index.TransactionHeaderSerial, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long TransactionHeaderSerial { get; set; }

        /// <summary>
        /// Gets or sets TransactionDetailLine 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "TransactionDetailLine", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionDetailLine, Id = Index.TransactionDetailLine, FieldType = EntityFieldType.Long, Size = 4)]
        public long TransactionDetailLine { get; set; }

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets TransactionDetailStatus 
        /// </summary>
        [Display(Name = "TransactionDetailStatus", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionDetailStatus, Id = Index.TransactionDetailStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionDetailStatus TransactionDetailStatus { get; set; }

        /// <summary>
        /// Gets TransactionDetailStatus  value
        /// </summary>
        [IgnoreExportImport]
        public string TransactionDetailStatusString
        {
            get { return EnumUtility.GetStringValue(TransactionDetailStatus); }

        }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public OFXTransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        [IgnoreExportImport]
        public string TransactionTypeString
        {
            get { return EnumUtility.GetStringValue(TransactionType); }
        }

        /// <summary>
        /// Gets or sets DetailTransactionType 
        /// </summary>
        [Display(Name = "DetailTransactionType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DetailTransactionType, Id = Index.DetailTransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public DetailTransactionType DetailTransactionType { get; set; }

        /// <summary>
        /// Gets DetailTransactionType string value
        /// </summary>
        [IgnoreExportImport]
        public string DetailTransactionTypeString
        {
            get { return EnumUtility.GetStringValue(DetailTransactionType); }
        }

        /// <summary>
        /// Gets or sets RemittanceID 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemittanceID", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.RemittanceID, Id = Index.RemittanceID, FieldType = EntityFieldType.Char, Size = 24)]
        public string RemittanceID { get; set; }

        /// <summary>
        /// Gets or sets TransactionDate 
        /// </summary>
        // [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
        [Display(Name = "TransactionDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionDate, Id = Index.TransactionDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime TransactionDate { get; set; }

        /// <summary>
        /// Gets or sets BatchNumber 
        /// </summary>
        [Display(Name = "BatchNumber", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.BatchNumber, Id = Index.BatchNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BatchNumber { get; set; }

        /// <summary>
        /// Gets or sets EntryNumber 
        /// </summary>
        [Display(Name = "EntryNumber", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.EntryNumber, Id = Index.EntryNumber, FieldType = EntityFieldType.Decimal, Size = 4)]
        public decimal EntryNumber { get; set; }

        /// <summary>
        /// Gets or sets PostingSequenceNumber 
        /// </summary>
        [Display(Name = "PostingSequenceNumber", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PostingSequenceNumber, Id = Index.PostingSequenceNumber, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets TransactionReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionReference", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionReference, Id = Index.TransactionReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionReference { get; set; }

        /// <summary>
        /// Gets or sets TransactionDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TransactionDescription", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionDescription, Id = Index.TransactionDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransactionDescription { get; set; }

        /// <summary>
        /// Gets or sets PayerCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayerCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PayerCode, Id = Index.PayerCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PayerCode { get; set; }

        /// <summary>
        /// Gets or sets PayeeName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayeeName", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PayeeName, Id = Index.PayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PayeeName { get; set; }

        /// <summary>
        /// Gets or sets VendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorName", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets SourceTransactionAmount 
        /// </summary>
        [Display(Name = "SourceTransactionAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SourceTransactionAmount, Id = Index.SourceTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTransactionAmount 
        /// </summary>
        [Display(Name = "FunctionalTransactionAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FunctionalTransactionAmount, Id = Index.FunctionalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ExchangeRateType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ExchangeRateType, Id = Index.ExchangeRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ExchangeRateType { get; set; }

        /// <summary>
        /// Gets or sets ReceiptCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReceiptCurrency", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReceiptCurrency, Id = Index.ReceiptCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ReceiptCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        // [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
        [Display(Name = "ExchangeRateDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExchangeRateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [Display(Name = "ExchangeRate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread 
        /// </summary>
        [Display(Name = "RateSpread", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        [Display(Name = "RateOperation", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets TransactionType string value
        /// </summary>
        [IgnoreExportImport]
        public string RateOperationString
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets GLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets DrilldownType 
        /// </summary>
        [Display(Name = "DrilldownType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DrilldownType, Id = Index.DrilldownType, FieldType = EntityFieldType.Int, Size = 2)]
        public string DrilldownType { get; set; }

        /// <summary>
        /// Gets or sets DrilldownLink 
        /// </summary>
        [Display(Name = "DrilldownLink", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DrilldownLink, Id = Index.DrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public string DrilldownLink { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationStatus 
        /// </summary>
        [Display(Name = "ReconciliationStatus", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationStatus, Id = Index.ReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciliationStatus ReconciliationStatus { get; set; }

        /// <summary>
        /// Finder Grid property Transaction Slip Printed Dropdown.
        /// </summary>
        [IgnoreExportImport]
        public string ReconciliationStatusString
        {
            get { return EnumUtility.GetStringValue(ReconciliationStatus); }
        }

        /// <summary>
        /// Gets or sets StatusChangeDate 
        /// </summary>
        // [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]	
        [Display(Name = "StatusChangeDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.StatusChangeDate, Id = Index.StatusChangeDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime StatusChangeDate { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReconciliationDescription", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationDescription, Id = Index.ReconciliationDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ReconciliationDescription { get; set; }

        /// <summary>
        /// Gets or sets ClearedAmount 
        /// </summary>
        [Display(Name = "ClearedAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ClearedAmount, Id = Index.ClearedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ClearedAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingDate 
        /// </summary>
        // [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]	
        [Display(Name = "ReconciliationPostingDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationPostingDate, Id = Index.ReconciliationPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReconciliationPostingDate { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReconciliationPostingYear", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationPostingYear, Id = Index.ReconciliationPostingYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ReconciliationPostingYear { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPostingPeriod 
        /// </summary>
        [Display(Name = "ReconciliationpostingPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationPostingPeriod, Id = Index.ReconciliationPostingPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciliationPostingPeriod ReconciliationPostingPeriod { get; set; }

        /// <summary>
        /// Gets ReconciliationPostingPeriod string value
        /// </summary>
        [IgnoreExportImport]
        public string ReconciliationPostingPeriodString
        {
            get { return EnumUtility.GetStringValue(ReconciliationPostingPeriod); }
        }

        /// <summary>
        /// Gets or sets Reconciled 
        /// </summary>
        [Display(Name = "Reconciled", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.Reconciled, Id = Index.Reconciled, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Reconciled { get; set; }

        /// <summary>
        /// Gets or sets RemainingInTransitAmount 
        /// </summary>
        [Display(Name = "RemainingInTransitAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.RemainingInTransitAmount, Id = Index.RemainingInTransitAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal RemainingInTransitAmount { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PaymentCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets CheckStockCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckStockCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.CheckStockCode, Id = Index.CheckStockCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CheckStockCode { get; set; }

        /// <summary>
        /// Gets or sets OFXTransactionID 
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OFXTransactionID", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.OFXTransactionID, Id = Index.OFXTransactionID, FieldType = EntityFieldType.Char, Size = 50)]
        public string OFXTransactionID { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [Display(Name = "FiscalPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReversalOrReturnDate 
        /// </summary>
        [Display(Name = "ReversalOrReturnDate", ResourceType = typeof(BankTransactionDetailResx))]	
        [ViewField(Name = Fields.ReversalOrReturnDate, Id = Index.ReversalOrReturnDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ReversalOrReturnDate { get; set; }

        /// <summary>
        /// Gets or sets SourceDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceDocumentNumber", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SourceDocumentNumber, Id = Index.SourceDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string SourceDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CanReverseInvoice 
        /// </summary>
        [Display(Name = "CanReverseInvoice", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.CanReverseInvoice, Id = Index.CanReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSlipPrinted CanReverseInvoice { get; set; }

        /// <summary>
        /// Gets CanReverseInvoice string value
        /// </summary>
        [IgnoreExportImport]
        public string CanReverseInvoiceString
        {
            get { return EnumUtility.GetStringValue(CanReverseInvoice); }
        }

        /// <summary>
        /// Gets or sets ReverseInvoice 
        /// </summary>
        [Display(Name = "ReverseInvoice", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReverseInvoice, Id = Index.ReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionSlipPrinted ReverseInvoice { get; set; }

        /// <summary>
        /// Gets ReverseInvoice string value
        /// </summary>
        [IgnoreExportImport]
        public string ReverseInvoiceString
        {
            get { return EnumUtility.GetStringValue(ReverseInvoice); }
        }

        /// <summary>
        /// Gets or sets ReconciledandJournaledTransac 
        /// </summary>
        [Display(Name = "ReconciledandJournaledTransaction", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciledandJournaledTransaction, Id = Index.ReconciledandJournaledTransaction, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciledandJournaledTransac ReconciledandJournaledTransaction { get; set; }

        /// <summary>
        /// Gets ReconciledandJournaledTransaction string value
        /// </summary>
        [IgnoreExportImport]
        public string ReconciledandJournaledTransactionString
        {
            get { return EnumUtility.GetStringValue(ReconciledandJournaledTransaction); }
        }

        /// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        [Display(Name = "PostingSequence", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal PostingSequence { get; set; }

        /// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public int EntryType { get; set; }

        /// <summary>
        /// Gets or sets DocumentPostedDate 
        /// </summary>
        // [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
        [Display(Name = "DocumentPostedDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DocumentPostedDate, Id = Index.DocumentPostedDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DocumentPostedDate { get; set; }

        /// <summary>
        /// Gets or sets LastReconciliationStatus 
        /// </summary>
        [Display(Name = "LastReconciliationStatus", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LastReconciliationStatus, Id = Index.LastReconciliationStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public int LastReconciliationStatus { get; set; }

        /// <summary>
        /// Gets or sets ReconciledBy 
        /// </summary>
        [Display(Name = "ReconciledBy", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciledBy, Id = Index.ReconciledBy, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciledBy ReconciledBy { get; set; }

        /// <summary>
        /// Gets ReconciledBy string value
        /// </summary>
        [IgnoreExportImport]
        public string ReconciledByString
        {
            get { return EnumUtility.GetStringValue(ReconciledBy); }
        }

        /// <summary>
        /// Gets or sets ReconciliationError 
        /// </summary>
        [Display(Name = "ReconciliationError", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationError, Id = Index.ReconciliationError, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationError { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationErrorPending 
        /// </summary>
        [Display(Name = "ReconciliationErrorPending", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationErrorPending, Id = Index.ReconciliationErrorPending, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationErrorPending { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeGain 
        /// </summary>
        [Display(Name = "ReconciliationExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationExchangeGain, Id = Index.ReconciliationExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationExchangeLoss 
        /// </summary>
        [Display(Name = "ReconciliationExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationExchangeLoss, Id = Index.ReconciliationExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationSuggestion 
        /// </summary>
        [Display(Name = "ReconciliationSuggestion", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationSuggestion, Id = Index.ReconciliationSuggestion, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciliationSuggestion ReconciliationSuggestion { get; set; }

        /// <summary>
        /// Gets ReconciliationSuggestion string value
        /// </summary>
        [IgnoreExportImport]
        public string ReconciliationSuggestionString
        {
            get { return EnumUtility.GetStringValue(ReconciliationSuggestion); }
        }

        /// <summary>
        /// Gets or sets TransactionAmount 
        /// </summary>
        [Display(Name = "TransactionAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TransactionAmount, Id = Index.TransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets OutstandingAmount 
        /// </summary>
        [Display(Name = "OutstandingAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.OutstandingAmount, Id = Index.OutstandingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OutstandingAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationTarget 
        /// </summary>
        [Display(Name = "ReconciliationTarget", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationTarget, Id = Index.ReconciliationTarget, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconciliationTarget ReconciliationTarget { get; set; }

        /// <summary>
        /// Gets ReconciliationTarget string value
        /// </summary>
        [IgnoreExportImport]
        public string ReconciliationTargetString
        {
            get { return EnumUtility.GetStringValue(ReconciliationTarget); }
        }

        /// <summary>
        /// Gets or sets DistributionCodeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DistributionCodeDescription", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DistributionCodeDescription, Id = Index.DistributionCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DistributionCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets GLAccountDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccountDescription", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.GLAccountDescription, Id = Index.GLAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationAmountDelta 
        /// </summary>
        [Display(Name = "ReconciliationAmountDelta", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationAmountDelta, Id = Index.ReconciliationAmountDelta, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationAmountDelta { get; set; }

        /// <summary>
        /// Gets or sets Line 
        /// </summary>
        [Display(Name = "Line", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
        public long Line { get; set; }

        /// <summary>
        /// Gets or sets LineOutstanding 
        /// </summary>
        [Display(Name = "LineOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LineOutstanding, Id = Index.LineOutstanding, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineOutstanding { get; set; }

        /// <summary>
        /// Gets or sets LineReconciled 
        /// </summary>
        [Display(Name = "LineReconciled", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LineReconciled, Id = Index.LineReconciled, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineReconciled { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationCreditCardCharg 
        /// </summary>
        [Display(Name = "ReconciliationCreditCardCharges", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationCreditCardCharges, Id = Index.ReconciliationCreditCardCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationCreditCardCharges { get; set; }

        /// <summary>
        /// Gets or sets WriteOffAmount 
        /// </summary>
        [Display(Name = "WriteOffAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.WriteOffAmount, Id = Index.WriteOffAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WriteOffAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "StatementCurrency", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets SummatedTransactionAmount 
        /// </summary>
        [Display(Name = "SummatedTransactionAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SummatedTransactionAmount, Id = Index.SummatedTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SummatedTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationSpread 
        /// </summary>
        [Display(Name = "ReconciliationSpread", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationSpread, Id = Index.ReconciliationSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconciliationSpread { get; set; }

        /// <summary>
        /// Gets or sets FiscalTransactionRemainingIn 
        /// </summary>
        [Display(Name = "FiscalTransactionRemainingIn", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalTransactionRemainingIn, Id = Index.FiscalTransactionRemainingIn, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalTransactionRemainingIn { get; set; }

        /// <summary>
        /// Gets or sets FiscalOutstandingAmount 
        /// </summary>
        [Display(Name = "FiscalOutstandingAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalOutstandingAmount, Id = Index.FiscalOutstandingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalOutstandingAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalWriteOffs 
        /// </summary>
        [Display(Name = "FiscalWriteOffs", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWriteOffs, Id = Index.FiscalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets FiscalBankErrors 
        /// </summary>
        [Display(Name = "FiscalBankErrors", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalBankErrors, Id = Index.FiscalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalBankErrors { get; set; }

        /// <summary>
        /// Gets or sets FiscalExchangeGain 
        /// </summary>
        [Display(Name = "FiscalExchangeGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalExchangeGain, Id = Index.FiscalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets FiscalExchangeLoss 
        /// </summary>
        [Display(Name = "FiscalExchangeLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalExchangeLoss, Id = Index.FiscalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets FiscalCreditCardCharge 
        /// </summary>
        [Display(Name = "FiscalCreditCardCharge", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalCreditCardCharge, Id = Index.FiscalCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalCreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets FiscalCleared 
        /// </summary>
        [Display(Name = "FiscalCleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalCleared, Id = Index.FiscalCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalCleared { get; set; }

        /// <summary>
        /// Gets or sets FiscalFunctionalAmount 
        /// </summary>
        [Display(Name = "FiscalFunctionalAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalFunctionalAmount, Id = Index.FiscalFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalOriginalTransactionAmount 
        /// </summary>
        [Display(Name = "FiscalOriginalTransactionAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalOriginalTransactionAmount, Id = Index.FiscalOriginalTransactionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalOriginalTransactionAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalBookAmount 
        /// </summary>
        [Display(Name = "TotalBookAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalBookAmount, Id = Index.TotalBookAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalBookAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalBookAmount 
        /// </summary>
        [Display(Name = "FiscalBookAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalBookAmount, Id = Index.FiscalBookAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalBookAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalRemainingAmount 
        /// </summary>
        [Display(Name = "TotalRemainingAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalRemainingAmount, Id = Index.TotalRemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalRemainingAmount 
        /// </summary>
        [Display(Name = "FiscalRemainingAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalRemainingAmount, Id = Index.FiscalRemainingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalRemainingAmount { get; set; }

        /// <summary>
        /// Gets or sets FiscalWriteOffToThisPeriod 
        /// </summary>
        [Display(Name = "FiscalWriteOffToThisPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWriteOffToThisPeriod, Id = Index.FiscalWriteOffToThisPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWriteOffToThisPeriod { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToFuture 
        /// </summary>
        [Display(Name = "FiscalClearedToFuture", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalClearedToFuture, Id = Index.FiscalClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets FiscalClearedToCurrent 
        /// </summary>
        [Display(Name = "FiscalClearedToCurrent", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalClearedToCurrent, Id = Index.FiscalClearedToCurrent, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalClearedToCurrent { get; set; }

        /// <summary>
        /// Gets or sets CurrentPeriodsWriteOff 
        /// </summary>
        [Display(Name = "CurrentPeriodsWriteOff", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.CurrentPeriodsWriteOff, Id = Index.CurrentPeriodsWriteOff, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentPeriodsWriteOff { get; set; }

        /// <summary>
        /// Gets or sets PostedFiscalClearedToFuture 
        /// </summary>
        [Display(Name = "PostedFiscalClearedToFuture", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.PostedFiscalClearedToFuture, Id = Index.PostedFiscalClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal PostedFiscalClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets NoOfDaysSinceReconciled 
        /// </summary>
        [Display(Name = "NoOfDaysSinceReconciled", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.NoOfDaysSinceReconciled, Id = Index.NoOfDaysSinceReconciled, FieldType = EntityFieldType.Int, Size = 2)]
        public int NoOfDaysSinceReconciled { get; set; }

        /// <summary>
        /// Gets or sets StatementAmount 
        /// </summary>
        [Display(Name = "StatementAmount", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.StatementAmount, Id = Index.StatementAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StatementAmount { get; set; }

        /// <summary>
        /// Gets or sets LineCreditCard 
        /// </summary>
        [Display(Name = "LineCreditCard", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LineCreditCard, Id = Index.LineCreditCard, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineCreditCard { get; set; }

        /// <summary>
        /// Gets or sets LineExchangeDifference 
        /// </summary>
        [Display(Name = "LineExchangeDifference", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LineExchangeDifference, Id = Index.LineExchangeDifference, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineExchangeDifference { get; set; }

        /// <summary>
        /// Gets or sets LineCanReverseInvoice 
        /// </summary>
        [Display(Name = "LineExchangeDifference", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.LineCanReverseInvoice, Id = Index.LineCanReverseInvoice, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineCanReverseInvoice { get; set; }

        /// <summary>
        /// Gets or sets BankStatementType 
        /// </summary>
        [Display(Name = "BankStatementType", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.BankStatementType, Id = Index.BankStatementType, FieldType = EntityFieldType.Int, Size = 2)]
        public int BankStatementType { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ReconciliationYear", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationYear, Id = Index.ReconciliationYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string ReconciliationYear { get; set; }

        /// <summary>
        /// Gets or sets ReconciliationPeriod 
        /// </summary>
        [Display(Name = "ReconciliationPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconciliationPeriod, Id = Index.ReconciliationPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int ReconciliationPeriod { get; set; }

        /// <summary>
        /// Gets or sets ReconcileByDetailReconciled 
        /// </summary>
        [Display(Name = "ReconcilebyDetailReconciled", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconcileByDetailReconciled, Id = Index.ReconcileByDetailReconciled, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconcileByDetailReconciled { get; set; }

        /// <summary>
        /// Gets or sets ReconcileByDetailOutstanding 
        /// </summary>
        [Display(Name = "ReconcilebyDetailOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ReconcileByDetailOutstanding, Id = Index.ReconcileByDetailOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ReconcileByDetailOutstanding { get; set; }

        /// <summary>
        /// Get Functional amount Decimal places
        /// </summary>
        public string FunctionalAmountDecimals { get; set; }

        /// <summary>
        /// Get Source amount Decimal places
        /// </summary>
        public string SourceAmountDecimals { get; set; }

        #endregion


        /// <summary>
        /// To get auto increment number for UI
        /// </summary>
        /// <value>The serial number.</value>
        [IgnoreExportImport]
        public long SerialNumber { get; set; }


        /// <summary>
        /// To Get or Set Event type of EnumerableResponse Items
        /// </summary>
        /// <value>Event Type.</value>
        [IgnoreExportImport]
        public int EventTypeID { get; set; }
    }
}
