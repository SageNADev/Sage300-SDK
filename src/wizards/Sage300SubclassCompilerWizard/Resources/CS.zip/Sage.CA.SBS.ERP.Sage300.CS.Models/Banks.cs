/* Copyright (c) 1994-2020 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Banks Model
    /// </summary>
    public partial class Banks : ModelBase
    {
        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "BankCode", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BankCodeDesc", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine3 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "AddressLine4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
        public string AddressLine4 { get; set; }

        /// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "City", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets StateOrProvince 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StateProvince", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.StateOrProvince, Id = Index.StateOrProvince, FieldType = EntityFieldType.Char, Size = 30)]
        public string StateOrProvince { get; set; }

        /// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Country", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
        public string Country { get; set; }

        /// <summary>
        /// Gets or sets ZipOrPostalCode 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "ZIPPostal", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
        public string ZipOrPostalCode { get; set; }

        /// <summary>
        /// Gets or sets Contact 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Contact", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
        public string Contact { get; set; }

        /// <summary>
        /// Gets or sets PhoneNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Phone", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string PhoneNumber { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Fax", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets TransitNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TransitNumber", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.TransitNumber, Id = Index.TransitNumber, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12D")]
        public string TransitNumber { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency 
        /// </summary>
        [Display(Name = "Multicurrency", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.Multicurrency, Id = Index.Multicurrency, FieldType = EntityFieldType.Bool, Size = 2)]
        public Multicurrency Multicurrency { get; set; }

        /// <summary>
        /// Control Account Allowed for UI
        /// </summary>
        /// 
        public bool IsMulticurrency
        {
            get
            {
                return Multicurrency == Multicurrency.Yes;
            }
            set { Multicurrency = value == false ? Multicurrency.No : Multicurrency.Yes; }
        }

        /// <summary>
        /// Gets Multicurrency string value
        /// </summary>
        public string MulticurrencyString
        {
            get { return EnumUtility.GetStringValue(Multicurrency); }
        }

        /// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CurstmtFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string StatementCurrency { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public Enums.Status Status { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "InactiveDate", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets or sets BankAccountNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BankAccountNumber", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankAccountNumber, Id = Index.BankAccountNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string BankAccountNumber { get; set; }

        /// <summary>
        /// Gets or sets BankAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BankAccount", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.BankAccount, Id = Index.BankAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string BankAccount { get; set; }

        /// <summary>
        /// Gets or sets WriteOffAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "WriteOffAccount", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.WriteOffAccount, Id = Index.WriteOffAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string WriteOffAccount { get; set; }

        /// <summary>
        /// Gets or sets ErrorSpread 
        /// </summary>
        [Display(Name = "ErrorSpread", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.ErrorSpread, Id = Index.ErrorSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ErrorSpread { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LastMaintained", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FscperiodFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [Display(Name = "FiscalYearOrPeriod", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public CS.Models.Enums.FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets LastReconciliationYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LastReconciliationYear", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.LastReconciliationYear, Id = Index.LastReconciliationYear, FieldType = EntityFieldType.Char, Size = 4)]
        public string LastReconciliationYear { get; set; }

        /// <summary>
        /// Gets or sets LastReconciliationPeriod 
        /// </summary>
        [Display(Name = "LastReconciliationPeriod", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.LastReconciliationPeriod, Id = Index.LastReconciliationPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int LastReconciliationPeriod { get; set; }

        /// <summary>
        /// Gets or sets RECLSTDATE 
        /// </summary>
       //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LastReconciliationDate", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.RECLSTDATE, Id = Index.RECLSTDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RECLSTDATE { get; set; }

        /// <summary>
        /// Gets or sets LastClosingStatementBalance 
        /// </summary>
        [Display(Name = "LastClosingStatementBalance", ResourceType = typeof(BankResx))]
        [ViewField(Name = Fields.LastClosingStatementBalance, Id = Index.LastClosingStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastClosingStatementBalance { get; set; }

        /// <summary>
        /// Gets or sets RECDATE 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "RecdateFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.RECDATE, Id = Index.RECDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RECDATE { get; set; }

        /// <summary>
        /// Gets or sets StatementDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "StatementDate", ResourceType = typeof(BankReconcileStatementResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.StatementDate, Id = Index.StatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? StatementDate { get; set; }

        /// <summary>
        /// Gets or sets StatementBalance 
        /// </summary>
        [Display(Name = "StatementBal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.StatementBalance, Id = Index.StatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StatementBalance { get; set; }

        /// <summary>
        /// Gets or sets DepositsinTransit 
        /// </summary>
        [Display(Name = "DepositsinTransit", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DepositsinTransit, Id = Index.DepositsinTransit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositsinTransit { get; set; }

        /// <summary>
        /// Gets or sets ChecksOutstanding 
        /// </summary>
        [Display(Name = "ChecksOutstanding", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ChecksOutstanding, Id = Index.ChecksOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChecksOutstanding { get; set; }

        /// <summary>
        /// Gets or sets BankErrors 
        /// </summary>
        [Display(Name = "BankErrors", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankErrors, Id = Index.BankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BankErrors { get; set; }

        /// <summary>
        /// Gets or sets TotalNotPostedBankEntries 
        /// </summary>
        [Display(Name = "TotalNotPostedBankEntries", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalNotPostedBankEntries, Id = Index.TotalNotPostedBankEntries, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalNotPostedBankEntries { get; set; }

        /// <summary>
        /// Gets or sets WriteOffs 
        /// </summary>
        [Display(Name = "WriteOffs", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.WriteOffs, Id = Index.WriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WriteOffs { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGain 
        /// </summary>
        [Display(Name = "ExchangeGain", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ExchangeGain, Id = Index.ExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLoss 
        /// </summary>
        [Display(Name = "ExchangeLoss", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ExchangeLoss, Id = Index.ExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets TotalDeposits 
        /// </summary>
        [Display(Name = "TotalDeposits", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalDeposits, Id = Index.TotalDeposits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDeposits { get; set; }

        /// <summary>
        /// Gets or sets TotalChecks 
        /// </summary>
        [Display(Name = "TotalChecks", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalChecks, Id = Index.TotalChecks, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalChecks { get; set; }

        /// <summary>
        /// Gets or sets DepositsToFiscalPeriod 
        /// </summary>
        [Display(Name = "DepositsToFiscalPeriod", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DepositsToFiscalPeriod, Id = Index.DepositsToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositsToFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ChecksToFiscalPeriod 
        /// </summary>
        [Display(Name = "ChecksToFiscalPeriod", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ChecksToFiscalPeriod, Id = Index.ChecksToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChecksToFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets DepositsInTransitToFiscPer 
        /// </summary>
        [Display(Name = "DepositOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositsInTransitToFiscPer, Id = Index.DepositsInTransitToFiscPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositsInTransitToFiscPer { get; set; }

        /// <summary>
        /// Gets or sets ChecksOutstandingToFiscPer 
        /// </summary>
        [Display(Name = "WithdrawalOutstanding", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ChecksOutstandingToFiscPer, Id = Index.ChecksOutstandingToFiscPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChecksOutstandingToFiscPer { get; set; }

        /// <summary>
        /// Gets or sets CalculateFiscalPeriodData 
        /// </summary>
        [Display(Name = "CalculateFiscalPeriodData", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CalculateFiscalPeriodData, Id = Index.CalculateFiscalPeriodData, FieldType = EntityFieldType.Bool, Size = 2)]
        public CalculateFiscalPeriodData CalculateFiscalPeriodData { get; set; }

        /// <summary>
        /// Gets CalculateFiscalPeriodData  value
        /// </summary>
        public string CalculateFiscalPeriodDataString
        {
            get { return EnumUtility.GetStringValue(CalculateFiscalPeriodData); }
        }

        /// <summary>
        /// Gets or sets LastStatementDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LastStatementDate", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastStatementDate { get; set; }

        /// <summary>
        /// Gets or sets DifferenceofBankEntriesToFi 
        /// </summary>
        [Display(Name = "BankEntriesNotPosted", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DifferenceofBankEntriesToFi, Id = Index.DifferenceofBankEntriesToFi, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DifferenceofBankEntriesToFi { get; set; }

        /// <summary>
        /// Gets or sets ExchangeGainToFiscalPeriod 
        /// </summary>
        [Display(Name = "ExchangeRateGain", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ExchangeGainToFiscalPeriod, Id = Index.ExchangeGainToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExchangeGainToFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ExchangeLossToFiscalPeriod 
        /// </summary>
        [Display(Name = "ExchangeRateLoss", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.ExchangeLossToFiscalPeriod, Id = Index.ExchangeLossToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExchangeLossToFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets BankErrorPendingToFiscalPer 
        /// </summary>
        [Display(Name = "BankErrorPendingToFiscalPer", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankErrorPendingToFiscalPer, Id = Index.BankErrorPendingToFiscalPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BankErrorPendingToFiscalPer { get; set; }

        /// <summary>
        /// Gets or sets BankErrorToFiscalPeriod 
        /// </summary>
        [Display(Name = "BankErrorToFiscalPeriod", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankErrorToFiscalPeriod, Id = Index.BankErrorToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BankErrorToFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TotalNotPostedBankEntriesTo 
        /// </summary>
        [Display(Name = "TotalNotPostedBankEntriesTo", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalNotPostedBankEntriesTo, Id = Index.TotalNotPostedBankEntriesTo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalNotPostedBankEntriesTo { get; set; }

        /// <summary>
        /// Gets or sets CreditCardChargesAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CreditCardChargesAccount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CreditCardChargesAccount, Id = Index.CreditCardChargesAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string CreditCardChargesAccount { get; set; }

        /// <summary>
        /// Gets or sets CreditCardChargeSpread 
        /// </summary>
        [Display(Name = "CreditCardChargeSpread", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CreditCardChargeSpread, Id = Index.CreditCardChargeSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CreditCardChargeSpread { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDifferenceSpread 
        /// </summary>
        [Display(Name = "ExchangeRateDifferenceSpread", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ExchangeRateDifferenceSpread, Id = Index.ExchangeRateDifferenceSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ExchangeRateDifferenceSpread { get; set; }

        /// <summary>
        /// Gets or sets AdjustedBookBalance 
        /// </summary>
        [Display(Name = "AdjustedBookBal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.AdjustedBookBalance, Id = Index.AdjustedBookBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustedBookBalance { get; set; }

        /// <summary>
        /// Gets or sets AdjustedStatementBalance 
        /// </summary>
        [Display(Name = "AdjustedStatementBal", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.AdjustedStatementBalance, Id = Index.AdjustedStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal AdjustedStatementBalance { get; set; }

        /// <summary>
        /// Gets or sets BankReconciliationBalanced 
        /// </summary>
        [Display(Name = "BankReconciliationBalanced", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankReconciliationBalanced, Id = Index.BankReconciliationBalanced, FieldType = EntityFieldType.Bool, Size = 2)]
        public BooleanType BankReconciliationBalanced { get; set; }

        /// <summary>
        /// Gets BankReconciliationBalanced string value
        /// </summary>
        public string BankReconciliationBalancedString
        {
            get { return EnumUtility.GetStringValue(BankReconciliationBalanced); }
        }
        

        /// <summary>
        /// Gets or sets OutOfBalanceBy 
        /// </summary>
        [Display(Name = "OutOfBalanceBy", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.OutOfBalanceBy, Id = Index.OutOfBalanceBy, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal OutOfBalanceBy { get; set; }

        /// <summary>
        /// Gets or sets NextCheckSerialNumber 
        /// </summary>
        [Display(Name = "NextCheckSerialNumber", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.NextCheckSerialNumber, Id = Index.NextCheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long NextCheckSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets NextDepositSlipNumber 
        /// </summary>
        [Display(Name = "NextDepositSlipNumber", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.NextDepositSlipNumber, Id = Index.NextDepositSlipNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal NextDepositSlipNumber { get; set; }

        /// <summary>
        /// Gets or sets NextDepositUniquifier 
        /// </summary>
        [Display(Name = "NextDepositUniquifier", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.NextDepositUniquifier, Id = Index.NextDepositUniquifier, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long NextDepositUniquifier { get; set; }

        /// <summary>
        /// Gets or sets CurrentBalance 
        /// </summary>
        [Display(Name = "CurrentBalance", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CurrentBalance, Id = Index.CurrentBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CurrentBalance { get; set; }

        /// <summary>
        /// Gets or sets BookBalance 
        /// </summary>
        [Display(Name = "BookBalance", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.BookBalance, Id = Index.BookBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal BookBalance { get; set; }

        /// <summary>
        /// Gets or sets GL Balance
        /// </summary>
        [Display(Name = "GLBalanceAsOf", ResourceType = typeof(BankReconcileStatementResx))]
        [IgnoreExportImport]
        [IgnorePreferences]
        public decimal? GLBalanceAsOf { get; set; }

        /// <summary>
        /// Gets or sets BankStatementType 
        /// </summary>
        [Display(Name = "BankStatementType", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.BankStatementType, Id = Index.BankStatementType, FieldType = EntityFieldType.Int, Size = 2)]
        public BankStatementType BankStatementType { get; set; }

        /// <summary>
        /// Gets or sets TotalWriteOffs 
        /// </summary>
        [Display(Name = "TotalWriteOffs", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalWriteOffs, Id = Index.TotalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets TotalCreditCardCharges 
        /// </summary>
        [Display(Name = "TotalCreditCardCharges", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalCreditCardCharges, Id = Index.TotalCreditCardCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalCreditCardCharges { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriodWriteOff 
        /// </summary>
        [Display(Name = "WriteOff", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalPeriodWriteOff, Id = Index.FiscalPeriodWriteOff, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalPeriodWriteOff { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriodCreditCardCharge 
        /// </summary>
        [Display(Name = "CreditCardCharge", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalPeriodCreditCardCharge, Id = Index.FiscalPeriodCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalPeriodCreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets SumofWithdrawalTotalWriteOf 
        /// </summary>
        [Display(Name = "Clearedwithwriteoff", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.SumofWithdrawalTotalWriteOf, Id = Index.SumofWithdrawalTotalWriteOf, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SumofWithdrawalTotalWriteOf { get; set; }

        /// <summary>
        /// Gets or sets SumofDepositTotalWriteOffs 
        /// </summary>
        [Display(Name = "SumofDepositTotalWriteOffs", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.SumofDepositTotalWriteOffs, Id = Index.SumofDepositTotalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SumofDepositTotalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets SumofWithdrawalFiscalWriteO 
        /// </summary>
        [Display(Name = "SumofWithdrawalFiscalWriteO", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.SumofWithdrawalFiscalWriteO, Id = Index.SumofWithdrawalFiscalWriteO, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SumofWithdrawalFiscalWriteO { get; set; }

        /// <summary>
        /// Gets or sets SumofDepositFiscalWriteOffs 
        /// </summary>
        [Display(Name = "SumofDepositFiscalWriteOffs", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.SumofDepositFiscalWriteOffs, Id = Index.SumofDepositFiscalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SumofDepositFiscalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "FunctionalCurrency", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets TotalRemainingOutStanding 
        /// </summary>
        [Display(Name = "TotalRemainingOutStanding", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalRemainingOutStanding, Id = Index.TotalRemainingOutStanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRemainingOutStanding { get; set; }

        /// <summary>
        /// Gets or sets FiscalRemainingOutStanding 
        /// </summary>
        [Display(Name = "FiscalRemainingOutStanding", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalRemainingOutStanding, Id = Index.FiscalRemainingOutStanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalRemainingOutStanding { get; set; }

        /// <summary>
        /// Gets or sets TotalRemainingInTransit 
        /// </summary>
        [Display(Name = "TotalRemainingInTransit", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalRemainingInTransit, Id = Index.TotalRemainingInTransit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalRemainingInTransit { get; set; }

        /// <summary>
        /// Gets or sets FiscalRemainingInTransit 
        /// </summary>
        [Display(Name = "FiscalRemainingInTransit", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalRemainingInTransit, Id = Index.FiscalRemainingInTransit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalRemainingInTransit { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalClearedToCur 
        /// </summary>
        [Display(Name = "FiscalWithdrawalClearedToCur", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalClearedToCur, Id = Index.FiscalWithdrawalClearedToCur, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalClearedToCur { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositClearedToCurren 
        /// </summary>
        [Display(Name = "FiscalDepositClearedToCurren", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositClearedToCurren, Id = Index.FiscalDepositClearedToCurren, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositClearedToCurren { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorizationDescription1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorizationDescription1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorizationDescription1, Id = Index.TaxAuthorizationDescription1, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorizationDescription1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorizationDescription2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorizationDescription2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorizationDescription2, Id = Index.TaxAuthorizationDescription2, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorizationDescription2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorizationDescription3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorizationDescription3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorizationDescription3, Id = Index.TaxAuthorizationDescription3, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorizationDescription3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorizationDescription4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorizationDescription4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorizationDescription4, Id = Index.TaxAuthorizationDescription4, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorizationDescription4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorizationDescription5 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorizationDescription5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorizationDescription5, Id = Index.TaxAuthorizationDescription5, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorizationDescription5 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription1, Id = Index.VendorTaxClassDescription1, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription1 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription2, Id = Index.VendorTaxClassDescription2, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription2 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription3, Id = Index.VendorTaxClassDescription3, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription3 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription4, Id = Index.VendorTaxClassDescription4, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription4 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription5 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription5, Id = Index.VendorTaxClassDescription5, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription5 { get; set; }

        /// <summary>
        /// Gets or sets NextSerialNumber 
        /// </summary>
        [Display(Name = "NextSerialNumber", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.NextSerialNumber, Id = Index.NextSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long NextSerialNumber { get; set; }

        /// <summary>
        /// Gets or sets DepositClearedwithExchangeRa 
        /// </summary>
        [Display(Name = "Clearedwithexchangeratedifference", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.DepositClearedwithExchangeRa, Id = Index.DepositClearedwithExchangeRa, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositClearedwithExchangeRa { get; set; }

        /// <summary>
        /// Gets or sets WithdrawalsClearedwithExchR 
        /// </summary>
        [Display(Name = "Clearedwithexchangeratedifference", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.WithdrawalsClearedwithExchR, Id = Index.WithdrawalsClearedwithExchR, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WithdrawalsClearedwithExchR { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalBankErrors 
        /// </summary>
        [Display(Name = "Clearedwithbankerror", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalWithdrawalBankErrors, Id = Index.TotalWithdrawalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalBankErrors { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalWriteOffs 
        /// </summary>
        [Display(Name = "TotalWithdrawalWriteOffs", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalWithdrawalWriteOffs, Id = Index.TotalWithdrawalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalExchangeGain 
        /// </summary>
        [Display(Name = "TotalWithdrawalExchangeGain", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalWithdrawalExchangeGain, Id = Index.TotalWithdrawalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalExchangeLoss 
        /// </summary>
        [Display(Name = "TotalWithdrawalExchangeLoss", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalWithdrawalExchangeLoss, Id = Index.TotalWithdrawalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalCreditCardCha 
        /// </summary>
        [Display(Name = "TotalWithdrawalCreditCardChange", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalWithdrawalCreditCardCha, Id = Index.TotalWithdrawalCreditCardCha, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalCreditCardCha { get; set; }

        /// <summary>
        /// Gets or sets TotalWithdrawalCleared 
        /// </summary>
        [Display(Name = "Cleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalWithdrawalCleared, Id = Index.TotalWithdrawalCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalWithdrawalCleared { get; set; }

        /// <summary>
        /// Gets or sets WithdrawalTotal 
        /// </summary>
        [Display(Name = "WithdrawalTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.WithdrawalTotal, Id = Index.WithdrawalTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WithdrawalTotal { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalBankErrors 
        /// </summary>
        [Display(Name = "WithdrawalBankError", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalBankErrors, Id = Index.FiscalWithdrawalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalBankErrors { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalWriteOffs 
        /// </summary>
        [Display(Name = "FiscalWithdrawalWriteOffs", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalWriteOffs, Id = Index.FiscalWithdrawalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalExchangeGain 
        /// </summary>
        [Display(Name = "FiscalWithdrawalExchangeGain", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalExchangeGain, Id = Index.FiscalWithdrawalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalExchangeLoss 
        /// </summary>
        [Display(Name = "FiscalWithdrawalExchangeLoss", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalExchangeLoss, Id = Index.FiscalWithdrawalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalCreditCardCh 
        /// </summary>
        [Display(Name = "FiscalWithdrawalCreditCardChange", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalCreditCardCh, Id = Index.FiscalWithdrawalCreditCardCh, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalCreditCardCh { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalCleared 
        /// </summary>
        [Display(Name = "Withdrawals", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalWithdrawalCleared, Id = Index.FiscalWithdrawalCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalCleared { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalTotal 
        /// </summary>
        [Display(Name = "FiscalWithdrawalTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalTotal, Id = Index.FiscalWithdrawalTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalTotal { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositBankErrors 
        /// </summary>
        [Display(Name = "Clearedwithbankerror", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositBankErrors, Id = Index.TotalDepositBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositBankErrors { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositWriteOffs 
        /// </summary>
        [Display(Name = "Clearedwithwriteoff", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositWriteOffs, Id = Index.TotalDepositWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositExchangeGain 
        /// </summary>
        [Display(Name = "TotalDepositExchangeGain", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalDepositExchangeGain, Id = Index.TotalDepositExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositExchangeLoss 
        /// </summary>
        [Display(Name = "TotalDepositExchangeLoss", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalDepositExchangeLoss, Id = Index.TotalDepositExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositCreditCardCharge 
        /// </summary>
        [Display(Name = "Clearedwithcreditcardcharge", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositCreditCardCharge, Id = Index.TotalDepositCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositCreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets TotalDepositCleared 
        /// </summary>
        [Display(Name = "Cleared", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.TotalDepositCleared, Id = Index.TotalDepositCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalDepositCleared { get; set; }

        /// <summary>
        /// Gets or sets DepositTotal 
        /// </summary>
        [Display(Name = "DepositTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DepositTotal, Id = Index.DepositTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositTotal { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositBankErrors 
        /// </summary>
        [Display(Name = "DepositBankError", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositBankErrors, Id = Index.FiscalDepositBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositBankErrors { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositWriteOffs 
        /// </summary>
        [Display(Name = "FiscalDepositWriteOffs", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositWriteOffs, Id = Index.FiscalDepositWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositWriteOffs { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositExchangeGain 
        /// </summary>
        [Display(Name = "FiscalDepositExchangeGain", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositExchangeGain, Id = Index.FiscalDepositExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositExchangeGain { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositExchangeLoss 
        /// </summary>
        [Display(Name = "FiscalDepositExchangeLoss", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositExchangeLoss, Id = Index.FiscalDepositExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositExchangeLoss { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositCreditCardCharg 
        /// </summary>
        [Display(Name = "FiscalDepositCreditCardCharge", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositCreditCardCharg, Id = Index.FiscalDepositCreditCardCharg, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositCreditCardCharg { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositCleared 
        /// </summary>
        [Display(Name = "Deposits", ResourceType = typeof(BankReconcileStatementResx))]
        [ViewField(Name = Fields.FiscalDepositCleared, Id = Index.FiscalDepositCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositCleared { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositTotal 
        /// </summary>
        [Display(Name = "FiscalDepositTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositTotal, Id = Index.FiscalDepositTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositTotal { get; set; }










        /// <summary>
        /// Gets or sets FiscalWithdrawalClearedToFut 
        /// </summary>
        [Display(Name = "RecfclrFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalClearedToFut, Id = Index.FiscalWithdrawalClearedToFut, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalClearedToFut { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositClearedToFuture 
        /// </summary>
        [Display(Name = "RecfclrFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositClearedToFuture, Id = Index.FiscalDepositClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositClearedToFuture { get; set; }

        /// <summary>
        /// Gets or sets WithdrawalFunctionalTotal 
        /// </summary>
        [Display(Name = "WithdrawalFunctionalTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.WithdrawalFunctionalTotal, Id = Index.WithdrawalFunctionalTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal WithdrawalFunctionalTotal { get; set; }

        /// <summary>
        /// Gets or sets FiscalWithdrawalFunctionalTot 
        /// </summary>
        [Display(Name = "FiscalWithdrawalFunctionalTot", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalWithdrawalFunctionalTot, Id = Index.FiscalWithdrawalFunctionalTot, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalWithdrawalFunctionalTot { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalTotal 
        /// </summary>
        [Display(Name = "DepositFunctionalTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DepositFunctionalTotal, Id = Index.DepositFunctionalTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DepositFunctionalTotal { get; set; }

        /// <summary>
        /// Gets or sets FiscalDepositFunctionalTotal 
        /// </summary>
        [Display(Name = "FiscalDepositFunctionalTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FiscalDepositFunctionalTotal, Id = Index.FiscalDepositFunctionalTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FiscalDepositFunctionalTotal { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxGroupCode", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxGroupCode, Id = Index.TaxGroupCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroupCode { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorization1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorization1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorization1, Id = Index.TaxAuthorization1, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthorization1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorization2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorization2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorization2, Id = Index.TaxAuthorization2, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthorization2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorization3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorization3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorization3, Id = Index.TaxAuthorization3, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthorization3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorization4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorization4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorization4, Id = Index.TaxAuthorization4, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthorization4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorization5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxAuthorization5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorization5, Id = Index.TaxAuthorization5, FieldType = EntityFieldType.Char, Size = 12)]
        public string TaxAuthorization5 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClass1 
        /// </summary>
        [Display(Name = "VendorTaxClass1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClass1, Id = Index.VendorTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorTaxClass1 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClass2 
        /// </summary>
        [Display(Name = "VendorTaxClass2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClass2, Id = Index.VendorTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorTaxClass2 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClass3 
        /// </summary>
        [Display(Name = "VendorTaxClass3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClass3, Id = Index.VendorTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorTaxClass3 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClass4 
        /// </summary>
        [Display(Name = "VendorTaxClass4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClass4, Id = Index.VendorTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorTaxClass4 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClass5 
        /// </summary>
        [Display(Name = "VendorTaxClass5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClass5, Id = Index.VendorTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int VendorTaxClass5 { get; set; }

        /// <summary>
        /// Gets or sets DaysBeforeEligibleforClearin 
        /// </summary>
        [Display(Name = "DaysBeforeEligibleForClearing", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DaysBeforeEligibleforClearin, Id = Index.DaysBeforeEligibleforClearin, FieldType = EntityFieldType.Int, Size = 2)]
        public int DaysBeforeEligibleforClearin { get; set; }

        /// <summary>
        /// Gets or sets POSTDATE 
        /// </summary>
        [Display(Name = "RecdateFLD", ResourceType = typeof(BKCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.POSTDATE, Id = Index.POSTDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? POSTDATE { get; set; }

        /// <summary>
        /// Gets or sets LSTPOSTDAT 
        /// </summary>
       // [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LastPostedDate", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.LSTPOSTDAT, Id = Index.LSTPOSTDAT, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LSTPOSTDAT { get; set; }

        /// <summary>
        /// Gets or sets LastAvailableStatementBalance 
        /// </summary>
        [Display(Name = "LastAvailableStatementBalance", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.LastAvailableStatementBalance, Id = Index.LastAvailableStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal LastAvailableStatementBalance { get; set; }

        /// <summary>
        /// Gets or sets DefaultReconciliationDescripti 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "LblReccommentCap", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DefaultReconciliationDescripti, Id = Index.DefaultReconciliationDescripti, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultReconciliationDescripti { get; set; }

        /// <summary>
        /// Gets or sets the Account for Banking Cloud 
        /// </summary>
        [ViewField(Name = Fields.BankingCloudAccount, Id = Index.BankingCloudAccount, FieldType = EntityFieldType.Byte, Size = 32)]
        public byte[] BankingCloudAccount { get; set; }

        /// <summary>
        /// Gets or sets the boolean describing if a bank is connected or not
        /// </summary>
        [ViewField(Name = Fields.BankingCloudConnected, Id = Index.BankingCloudConnected, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BankingCloudConnected { get; set; }

        /// <summary>
        /// Gets or sets BankingCloudLastIndex 
        /// </summary>
        [ViewField(Name = Fields.BankingCloudLastIndex, Id = Index.BankingCloudLastIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long BankingCloudLastIndex { get; set; }

        /// <summary>
        /// Gets or sets the Stock Codes
        /// </summary>
        public EnumerableResponse<CheckStock> CheckStockCodes { get; set; }

        /// <summary>
        /// Gets or sets the Currency Codes
        /// </summary>
        public EnumerableResponse<BankCurrency> CurrencyCodes { get; set; }

        /// <summary>
        /// Gets BankStatementType string value
        /// </summary>
        public string BankStatementTypeString
        {
            get { return EnumUtility.GetStringValue(BankStatementType); }
        }

        /// <summary>
        /// Gets sets Bank Transaction Header
        /// </summary>
        public EnumerableResponse<BankTransactionHeader> BankTransactionHeaders { get; set; }

        /// <summary>
        /// Get and Set from Bank Options Screen
        /// </summary>
        public ClearinFuturePeriodlist ClearinFuturePeriodsModel { get; set; }

        /// <summary>
        /// Gets or sets PostSequence
        /// </summary>
        public string PostSequence { get; set; }
    }
}
