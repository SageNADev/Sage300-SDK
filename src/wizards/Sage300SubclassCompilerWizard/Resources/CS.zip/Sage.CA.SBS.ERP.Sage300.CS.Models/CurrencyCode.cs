// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of properties of CurrencyCode
    /// </summary>
    public partial class CurrencyCode : ModelBase
    {
        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "CurrencyCode", ResourceType = typeof(CurrencyCodesResx))]
        [Key]
        [ViewField(Name = Fields.CurrencyCodeId, Id = Index.CurrencyCodeId, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string CurrencyCodeId { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Description", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Symbol 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Symbol", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.Symbol, Id = Index.Symbol, FieldType = EntityFieldType.Char, Size = 4)]
        public string Symbol { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlaces 
        /// </summary>
        [Display(Name = "DecimalPlaces", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.DecimalPlaces, Id = Index.DecimalPlaces, FieldType = EntityFieldType.Int, Size = 2)]
        public DecimalPlaces DecimalPlaces { get; set; }

        /// <summary>
        /// To get the string of DecimalPlaces property
        /// </summary>
        [IgnoreExportImport]
        public string DecimalPlacesString
        {
            get { return EnumUtility.GetStringValue(DecimalPlaces); }
        }

        /// <summary>
        /// Gets or sets SymbolPosition 
        /// </summary>
        [Display(Name = "SymbolPosition", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.SymbolPosition, Id = Index.SymbolPosition, FieldType = EntityFieldType.Int, Size = 2)]
        public SymbolPosition SymbolPosition { get; set; }        

        /// <summary>
        /// Gets or sets ThousandsSeparator 
        /// </summary>      
        [Display(Name = "ThousandsSeparator", ResourceType = typeof(CurrencyCodesResx))]  
        [ViewField(Name = Fields.ThousandsSeparator, Id = Index.ThousandsSeparator, FieldType = EntityFieldType.Char, Size = 1)]
        public ThousandsSeparator ThousandsSeparator { get; set; }
       
        /// <summary>
        /// Gets or sets DecimalSeparator 
        /// </summary>
        [Display(Name = "DecimalSeparator", ResourceType = typeof(CurrencyCodesResx))]  
        [ViewField(Name = Fields.DecimalSeparator, Id = Index.DecimalSeparator, FieldType = EntityFieldType.Char, Size = 1)]
        public DecimalSeparator DecimalSeparator { get; set; }
        
        /// <summary>
        /// Gets or sets NegativeDisplay 
        /// </summary>
        [Display(Name = "NegativeDisplay", ResourceType = typeof(CurrencyCodesResx))]  
        [ViewField(Name = Fields.NegativeDisplay, Id = Index.NegativeDisplay, FieldType = EntityFieldType.Int, Size = 2)]
        public NegativeDisplay NegativeDisplay { get; set; }

        /// <summary>
        /// Finder Grid property to Set the string of SymbolPosition property.
        /// </summary>
        [IgnoreExportImport]
        public string SymbolPositionString
        {
            get { return EnumUtility.GetStringValue(SymbolPosition); }
        }

        /// <summary>
        /// Finder Grid property to get the string of ThousandsSeparator property
        /// </summary>
        [IgnoreExportImport]
        public string ThousandsSeparatorString
        {
            get { return EnumUtility.GetStringValue(ThousandsSeparator); }
        }

        /// <summary>
        /// Finder Grid property to get the string of DecimalSeparator property
        /// </summary>
        [IgnoreExportImport]
        public string DecimalSeparatorString
        {
            get { return EnumUtility.GetStringValue(DecimalSeparator); }
        }

        /// <summary>
        /// Finder Grid property to get the string of NegativeDisplay property
        /// </summary>
        [IgnoreExportImport]
        public string NegativeDisplayString
        {
            get { return EnumUtility.GetStringValue(NegativeDisplay); }
        }
    }
}
