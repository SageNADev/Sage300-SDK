/* Copyright (c) 1994-2026 The Sage Group plc or its licensors. All rights reserved. */

// Portions co-modified with OpenAI Codex
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>Email audit record (CS0025).</summary>
    public partial class EmailAudit : ModelBase
    {
        [Key]
        [Display(Name = "EmailId", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.EmailId, Id = Index.EmailId, FieldType = EntityFieldType.Long, Size = 4)]
        public long EmailId { get; set; }

        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceApplication", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2)]
        public string SourceApplication { get; set; }

        [Display(Name = "SourceType", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.SourceType, Id = Index.SourceType, FieldType = EntityFieldType.Int, Size = 2)]
        public int SourceType { get; set; }

        [IgnoreExportImport]
        public string SourceTypeText { get; set; }

        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SourceLabel", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.SourceLabel, Id = Index.SourceLabel, FieldType = EntityFieldType.Char, Size = 50)]
        public string SourceLabel { get; set; }

        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Subject", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.Subject, Id = Index.Subject, FieldType = EntityFieldType.Char, Size = 255)]
        public string Subject { get; set; }

        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToEmail", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.ToEmail, Id = Index.ToEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string ToEmail { get; set; }

        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CcEmail", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.CcEmail, Id = Index.CcEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string CcEmail { get; set; }

        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BccEmail", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.BccEmail, Id = Index.BccEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string BccEmail { get; set; }

        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromEmail", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.FromEmail, Id = Index.FromEmail, FieldType = EntityFieldType.Char, Size = 50)]
        public string FromEmail { get; set; }

        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CreatedBy", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.CreatedBy, Id = Index.CreatedBy, FieldType = EntityFieldType.Char, Size = 8)]
        public string CreatedBy { get; set; }

        [Display(Name = "CreateDate", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.CreateDate, Id = Index.CreateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime CreateDate { get; set; }

        [Display(Name = "CreateTime", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.CreateTime, Id = Index.CreateTime, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime CreateTime { get; set; }

        [Display(Name = "SentDate", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.SentDate, Id = Index.SentDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime SentDate { get; set; }

        [Display(Name = "SentTime", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.SentTime, Id = Index.SentTime, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime SentTime { get; set; }

        [Display(Name = "Status", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Int, Size = 2)]
        public int Status { get; set; }

        [IgnoreExportImport]
        public string StatusText { get; set; }

        [Display(Name = "Attempts", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.Attempts, Id = Index.Attempts, FieldType = EntityFieldType.Int, Size = 2)]
        public int Attempts { get; set; }

        [Display(Name = "ErrorCode", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.ErrorCode, Id = Index.ErrorCode, FieldType = EntityFieldType.Int, Size = 2)]
        public int ErrorCode { get; set; }

        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ErrorMessage", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.ErrorMessage, Id = Index.ErrorMessage, FieldType = EntityFieldType.Char, Size = 255)]
        public string ErrorMessage { get; set; }

        [Display(Name = "NumberOfAttachments", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.NumberOfAttachments, Id = Index.NumberOfAttachments, FieldType = EntityFieldType.Int, Size = 2)]
        public int NumberOfAttachments { get; set; }

        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "AttachmentFileName", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.AttachmentFileName, Id = Index.AttachmentFileName, FieldType = EntityFieldType.Char, Size = 255)]
        public string AttachmentFileName { get; set; }

        [StringLength(255, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ErrorMessage", ResourceType = typeof(EmailHistoryResx))]
        [ViewField(Name = Fields.DisplayedErrorMessage, Id = Index.DisplayedErrorMessage, FieldType = EntityFieldType.Char, Size = 255)]
        public string DisplayedErrorMessage { get; set; }
    }
}
