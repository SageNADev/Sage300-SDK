
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms; 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for TransferRateOperator 
    /// </summary>
	public enum TransferRateOperator 
	{

        /// <summary>
        /// Gets or sets No 
        /// </summary>	
        [EnumValue("Multiply", typeof(BKCommonResx))]
        Multiply = 1,

        /// <summary>
        /// Gets or sets Yes 
        /// </summary>	
        [EnumValue("Divide", typeof(BKCommonResx))]
        Divide = 2,
	}
}
