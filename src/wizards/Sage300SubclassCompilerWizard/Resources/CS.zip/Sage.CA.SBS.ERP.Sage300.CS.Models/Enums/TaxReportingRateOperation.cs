// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for TaxReportingRateOperation 
    /// </summary>
    public enum TaxReportingRateOperation
    {
        /// <summary>
        /// Gets or sets Multiply 
        /// </summary>	
        [EnumValue("Multiply", typeof(EnumerationsResx))]
        Multiply = 1,

        /// <summary>
        /// Gets or sets Divide 
        /// </summary>	
        [EnumValue("Divide", typeof(EnumerationsResx))]
        Divide = 2,

        /// <summary>
        /// Gets or sets NotSpecified 
        /// </summary>	
        [EnumValue("NotSpecified", typeof(EnumerationsResx))]
        NotSpecified = 0,
    }
}
