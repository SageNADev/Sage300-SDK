﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ConsolidateGOrLBatches 
    /// </summary>
    public enum ConsolidateGorLBatches
    {
        /// <summary>
        /// Gets or sets Postalldetails 
        /// </summary>	
        [EnumValue("PostAllDetails", typeof(EnumerationsResx))]
        Postalldetails = 1,
        /// <summary>
        /// Gets or sets AccountOrFiscalPeriodOrSourceCode 
        /// </summary>	
        [EnumValue("AccountFiscalPeriodSourceCode", typeof(EnumerationsResx))]
        AccountOrFiscalPeriodOrSourceCode = 2,
        /// <summary>
        /// Gets or sets AccountOrFiscalPeriod 
        /// </summary>	
       [EnumValue("AccountFiscalPeriod", typeof(EnumerationsResx))]
        AccountOrFiscalPeriod = 3,
    }
}