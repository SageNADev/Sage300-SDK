﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for TypeofRecordtoClear 
    /// </summary>
    public enum TypeofRecordtoClear
    {
        /// <summary>
        /// Gets or sets Sales 
        /// </summary>	
        [EnumValue("Sales", typeof(EnumerationsResx))]
        Sales = 1,

        /// <summary>
        /// Gets or sets Purchases 
        /// </summary>	
        [EnumValue("Purchases", typeof(EnumerationsResx))]
        Purchases = 2,
    }
}
