// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for CompletedStatus 
    /// </summary>
    public enum CompletedStatus
    {
        /// <summary>
        /// Gets or sets NotCompleted 
        /// </summary>	
        [EnumValue("NotCompleted", typeof(EnumerationsResx))]
        NotCompleted = 0,
        /// <summary>
        /// Gets or sets Completed 
        /// </summary>	
        [EnumValue("Completed", typeof(EnumerationsResx))]
        Completed = 10,
    }
}
