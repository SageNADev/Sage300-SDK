// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for IncludedSegment1 
    /// </summary>
	public enum IncludedSegment1 
	{
	    /// <summary>
		/// Gets or sets None 
		/// </summary>	
        [EnumValue("None", typeof(CommonResx), 1)]
        None = 0,

		/// <summary>
		/// Gets or sets PostingSequence 
		/// </summary>	
        [EnumValue("PostingSequence", typeof(Resources.EnumerationsResx), 2)]
        PostingSequence = 1,

		/// <summary>
		/// Gets or sets Reference 
		/// </summary>
        [EnumValue("Reference", typeof(Resources.EnumerationsResx), 3)]	
        Reference = 2,

		/// <summary>
		/// Gets or sets Description 
		/// </summary>
        [EnumValue("Description", typeof(Resources.EnumerationsResx), 4)]		
        Description = 3,

		/// <summary>
		/// Gets or sets Comment 
		/// </summary>
        [EnumValue("Description", typeof(Resources.EnumerationsResx), 5)]		
        Comment = 4,

		/// <summary>
		/// Gets or sets WithdrawalNumber 
		/// </summary>
        [EnumValue("WithdrawalNumber", typeof(Resources.EnumerationsResx), 6)]		
        WithdrawalNumber = 5,

		/// <summary>
		/// Gets or sets PayeeID 
		/// </summary>
        [EnumValue("PayeeID", typeof(Resources.EnumerationsResx), 7)]
        PayeeID = 6,

		/// <summary>
		/// Gets or sets PayeeName 
		/// </summary>
        [EnumValue("PayeeName", typeof(Resources.EnumerationsResx), 8)]	
        PayeeName = 7,

		/// <summary>
		/// Gets or sets BatchNumber 
		/// </summary>
       [EnumValue("BatchNumber", typeof(Resources.EnumerationsResx), 9)]	
        BatchNumber = 8,

		/// <summary>
		/// Gets or sets DepositNumber 
		/// </summary>
        [EnumValue("DepositNumber", typeof(Resources.EnumerationsResx), 10)]
        DepositNumber = 9,

		/// <summary>
		/// Gets or sets TransferNumber 
		/// </summary>
        [EnumValue("TransferNumber", typeof(Resources.EnumerationsResx), 11)]	
        TransferNumber = 10,

		/// <summary>
		/// Gets or sets FromBank 
		/// </summary>	
       [EnumValue("FromBank", typeof(Resources.EnumerationsResx), 12)]
        FromBank = 11,

		/// <summary>
		/// Gets or sets ToBank 
		/// </summary>
        [EnumValue("ToBank", typeof(Resources.EnumerationsResx), 13)]
        ToBank = 12,

		/// <summary>
		/// Gets or sets BankCode 
		/// </summary>
        [EnumValue("BankCode", typeof(Resources.EnumerationsResx), 14)]
        BankCode = 13,

		/// <summary>
		/// Gets or sets DistributionCode 
		/// </summary>
        [EnumValue("DistributionCode", typeof(Resources.EnumerationsResx), 15)]
        DistributionCode = 14,

		/// <summary>
		/// Gets or sets EntryNumber 
		/// </summary>
        [EnumValue("EntryNumber", typeof(Resources.EnumerationsResx), 16)]
        EntryNumber = 15,

		/// <summary>
		/// Gets or sets EntryDescription 
		/// </summary>	
        [EnumValue("EntryDescription", typeof(Resources.EnumerationsResx), 17)]
        EntryDescription = 16,

		/// <summary>
		/// Gets or sets BankEntryType 
		/// </summary>	
        [EnumValue("BankEntryType", typeof(Resources.EnumerationsResx), 18)]
        BankEntryType = 17,

		/// <summary>
		/// Gets or sets ReconciliationDescription 
		/// </summary>	
        [EnumValue("ReconciliationDescription", typeof(Resources.EnumerationsResx), 19)]
        ReconciliationDescription = 18,

		/// <summary>
		/// Gets or sets ReconciliationStatus 
		/// </summary>	
        [EnumValue("ReconciliationStatus", typeof(Resources.EnumerationsResx), 20)]
        ReconciliationStatus = 19,

		/// <summary>
		/// Gets or sets FromBankAccount 
		/// </summary>
        [EnumValue("FromBankAccount", typeof(Resources.EnumerationsResx), 21)]	
        FromBankAccount = 20,

		/// <summary>
		/// Gets or sets ToBankAccount 
		/// </summary>
        [EnumValue("ToBankAccount", typeof(Resources.EnumerationsResx), 22)]	
        ToBankAccount = 21,
	}
}
