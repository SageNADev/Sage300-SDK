﻿
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    
        /// <summary>
        /// Enum class for allow Blank NA
        /// </summary>
        public enum AllowBlankNa
        {
            /// <summary>
            /// Gets or sets No 
            /// </summary>	
            [EnumValue("NA", typeof(EnumerationsResx))]
            No = 0,

            /// <summary>
            /// Gets or sets Yes 
            /// </summary>	
            [EnumValue("Yes", typeof(EnumerationsResx))]
            Yes = 1,
        }
}
