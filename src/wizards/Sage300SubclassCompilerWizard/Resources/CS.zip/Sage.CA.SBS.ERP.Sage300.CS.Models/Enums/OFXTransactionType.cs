﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for OFXTransactionType 
    /// </summary>
    public enum OFXTransactionType
    {
        /// <summary>
        /// Gets or sets Withdrawal
        /// </summary>	
        [EnumValue("Withdrawal", typeof(ReconcileOFXStatementResx))]	
        Withdrawal = 1,

        /// <summary>
        /// Gets or sets Deposit
        /// </summary>	
        [EnumValue("Deposit", typeof(BKCommonResx))]	
        Deposit = 2,
    }
}