 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for TransactionRecordedinSummary 
    /// </summary>
	public enum TransactionRecordedinSummary 
	{
			/// <summary>
		/// Gets or sets Detail 
		/// </summary>	
        [EnumValue("Detail", typeof(EnumerationsResx))]
        Detail = 0,
		/// <summary>
		/// Gets or sets Summary 
		/// </summary>	
        [EnumValue("Summary", typeof(EnumerationsResx))]
        Summary = 1,
		/// <summary>
		/// Gets or sets Transfer 
		/// </summary>	
        [EnumValue("Transfer", typeof(BKCommonResx))]
        Transfer = 2,
		/// <summary>
		/// Gets or sets BankError 
		/// </summary>	
        [EnumValue("Bankerror", typeof(EnumerationsResx))]
        BankError = 3,
	}
}
