 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for ReconciliationPostingPeriod 
    /// </summary>
	public enum ReconciliationPostingPeriod 
	{
        /// <summary>
        /// Gets or sets PostingPeriod 
        /// </summary>	
        PostingPeriod = 0,

        /// <summary>
        /// Gets or sets Num1 
        /// </summary>	
        Num1 = 1,

        /// <summary>
        /// Gets or sets Num2 
        /// </summary>	
        Num2 = 2,

        /// <summary>
        /// Gets or sets Num3 
        /// </summary>	
        Num3 = 3,

        /// <summary>
        /// Gets or sets Num4 
        /// </summary>	
        Num4 = 4,

        /// <summary>
        /// Gets or sets Num5 
        /// </summary>
        Num5 = 5,

        /// <summary>
        /// Gets or sets Num6 
        /// </summary>	
        Num6 = 6,

        /// <summary>
        /// Gets or sets Num7 
        /// </summary>	
        Num7 = 7,

        /// <summary>
        /// Gets or sets Num8 
        /// </summary>
        Num8 = 8,

        /// <summary>
        /// Gets or sets Num9 
        /// </summary>	
        Num9 = 9,

        /// <summary>
        /// Gets or sets Num10 
        /// </summary>	
        Num10 = 10,

        /// <summary>
        /// Gets or sets Num11 
        /// </summary>	
        Num11 = 11,

        /// <summary>
        /// Gets or sets Num12 
        /// </summary>	
        Num12 = 12
	}
}
