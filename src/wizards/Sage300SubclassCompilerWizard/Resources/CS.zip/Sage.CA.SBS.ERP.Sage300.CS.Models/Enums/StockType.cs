/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for StockType 
    /// </summary>
	public enum StockType 
	{
			/// <summary>
		/// Gets or sets CombinedCheckandAdvice 
		/// </summary>	
        [EnumValue("StockType_CombinedCheckandAdvice", typeof(EnumerationsResx))]
        CombinedCheckandAdvice = 1,
        
        /// <summary>
        /// Gets or sets CheckThenAdvice 
        /// </summary>
        [EnumValue("StockType_ChecksThenAdvices", typeof(EnumerationsResx))]
        CheckThenAdvice = 2,

		/// <summary>
		/// Gets or sets ChecksOnly 
		/// </summary>	
        [EnumValue("StockType_ChecksOnly", typeof(EnumerationsResx))]

        ChecksOnly = 3,
		/// <summary>
		/// Gets or sets AdvicesOnly 
		/// </summary>	
        [EnumValue("StockType_AdvicesOnly", typeof(EnumerationsResx))]
        AdvicesOnly = 4,
	}
}
