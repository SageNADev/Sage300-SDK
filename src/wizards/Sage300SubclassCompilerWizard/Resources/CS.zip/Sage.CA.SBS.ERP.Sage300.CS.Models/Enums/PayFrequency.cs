// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for PayFrequency
    /// </summary>
    public enum PayFrequency
    {
        /// <summary>
        /// Gets or sets Daily
        /// </summary>
        [EnumValue("Daily", typeof(PayslipResx))]
        Daily = 2,
        /// <summary>
        /// Gets or sets Weekly
        /// </summary>
        [EnumValue("Weekly", typeof(PayslipResx))]
        Weekly = 3,
        /// <summary>
        /// Gets or sets Biweekly
        /// </summary>
        [EnumValue("Biweekly", typeof(PayslipResx))]
        Biweekly = 4,
        /// <summary>
        /// Gets or sets Semimonthly
        /// </summary>
        [EnumValue("Semimonthly", typeof(PayslipResx))]
        Semimonthly = 5,
        /// <summary>
        /// Gets or sets Monthly
        /// </summary>
        [EnumValue("Monthly", typeof(PayslipResx))]
        Monthly = 6,
        /// <summary>
        /// Gets or sets Quarterly
        /// </summary>
        [EnumValue("Quarterly", typeof(PayslipResx))]
        Quarterly = 7,
        /// <summary>
        /// Gets or sets TenPerYear
        /// </summary>
        [EnumValue("TenPerYear", typeof(PayslipResx))]
        TenPerYear = 8,
        /// <summary>
        /// Gets or sets ThirteenPerYear
        /// </summary>
        [EnumValue("ThirteenPerYear", typeof(PayslipResx))]
        ThirteenPerYear = 9,
        /// <summary>
        /// Gets or sets TwentyTwoPerYear
        /// </summary>
        [EnumValue("TwentyTwoPerYear", typeof(PayslipResx))]
        TwentyTwoPerYear = 10
    }
}