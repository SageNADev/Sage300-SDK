﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetActivitySwitch
    /// </summary>
    public enum FiscalSetActivitySwitch
    {
        /// <summary>
        /// The inactive
        /// </summary>
        [EnumValue("Inactive", typeof(EnumerationsResx))]
        Inactive = 0,

        /// <summary>
        /// The periods active
        /// </summary>
        [EnumValue("PeriodsActive", typeof(EnumerationsResx))]
        PeriodsActive = 1,

        /// <summary>
        /// The balance forward active
        /// </summary>
        [EnumValue("BalanceForwardActive", typeof(EnumerationsResx))]
        BalanceForwardActive = 2,
    }
}