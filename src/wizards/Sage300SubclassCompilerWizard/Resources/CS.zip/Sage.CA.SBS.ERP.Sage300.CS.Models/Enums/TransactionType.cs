/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for TransactionType 
    /// </summary>
	public enum TransactionType 
	{
			/// <summary>
		/// Gets or sets Sales 
		/// </summary>	
         [EnumValue("Sales", typeof(TaxRatesResx))]
        Sales = 1,
		/// <summary>
		/// Gets or sets Purchases 
		/// </summary>	
         [EnumValue("Purchases", typeof(TaxRatesResx))]
        Purchases = 2,
	}
}
