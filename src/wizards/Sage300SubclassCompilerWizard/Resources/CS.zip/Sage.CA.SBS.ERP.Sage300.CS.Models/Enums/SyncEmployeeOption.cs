﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;


namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    public enum SyncEmployeeOption
    {
        /// <summary>
        /// Gets or sets Automatically
        /// </summary>
        [EnumValue("Automatically", typeof(SageHRResx))]
        Automatically = 0,

        /// <summary>
        /// Gets or sets Manually
        /// </summary>
        [EnumValue("Manually", typeof(SageHRResx))]
        Manually = 1,
    }
}
