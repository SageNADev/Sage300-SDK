// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process
{
    /// <summary>
    /// Enum for TypeOfRecordToClear
    /// </summary>
    public enum TypeOfRecordToClear
    {
        /// <summary>
        /// Gets or sets Sales
        /// </summary>
        [EnumValue("Sales", typeof(TaxClearHistoryResx))]
        Sales = 1,

        /// <summary>
        /// Gets or sets Purchases
        /// </summary>
        [EnumValue("Purchases", typeof(TaxClearHistoryResx))]
        Purchases = 2

    }
}