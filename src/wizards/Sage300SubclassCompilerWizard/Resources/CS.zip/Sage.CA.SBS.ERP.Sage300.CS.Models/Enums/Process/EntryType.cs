// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process
{
    /// <summary>
    /// Enum for EntryType
    /// </summary>
    public enum EntryType
    {
        /// <summary>
        /// Gets or sets BankEntered
        /// </summary>
        [EnumValue("BankEntered", typeof(EnumerationsResx))]
        BankEntered = 1,

        /// <summary>
        /// Gets or sets Subledger
        /// </summary>
        [EnumValue("Subledger", typeof(EnumerationsResx))]
        Subledger = 3,

        /// <summary>
        /// Gets or sets Transfer
        /// </summary>
        [EnumValue("Transfer", typeof(BKCommonResx))]
        Transfer = 4,

        /// <summary>
        /// Gets or sets ReturnedCustomerCheck
        /// </summary>
        [EnumValue("ReturnedCustomerCheck", typeof(EnumerationsResx))]
        ReturnedCustomerCheck = 5,
    }
}