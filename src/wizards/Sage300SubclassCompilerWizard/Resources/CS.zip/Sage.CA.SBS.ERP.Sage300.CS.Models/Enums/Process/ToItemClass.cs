// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process
{
    /// <summary>
    /// Enum for ToItemClass
    /// </summary>
    public enum ToItemClass
    {
        /// <summary>
        /// Gets or sets Num1
        /// </summary>
        [EnumValue("Num1", typeof(TaxClearHistoryResx))]
        Num1 = 1,

        /// <summary>
        /// Gets or sets Num2
        /// </summary>
        [EnumValue("Num2", typeof(TaxClearHistoryResx))]
        Num2 = 2,

        /// <summary>
        /// Gets or sets Num3
        /// </summary>
        [EnumValue("Num3", typeof(TaxClearHistoryResx))]
        Num3 = 3,

        /// <summary>
        /// Gets or sets Num4
        /// </summary>
        [EnumValue("Num4", typeof(TaxClearHistoryResx))]
        Num4 = 4,

        /// <summary>
        /// Gets or sets Num5
        /// </summary>
        [EnumValue("Num5", typeof(TaxClearHistoryResx))]
        Num5 = 5,

        /// <summary>
        /// Gets or sets Num6
        /// </summary>
        [EnumValue("Num6", typeof(TaxClearHistoryResx))]
        Num6 = 6,

        /// <summary>
        /// Gets or sets Num7
        /// </summary>
        [EnumValue("Num7", typeof(TaxClearHistoryResx))]
        Num7 = 7,

        /// <summary>
        /// Gets or sets Num8
        /// </summary>
        [EnumValue("Num8", typeof(TaxClearHistoryResx))]
        Num8 = 8,

        /// <summary>
        /// Gets or sets Num9
        /// </summary>
        [EnumValue("Num9", typeof(TaxClearHistoryResx))]
        Num9 = 9,

        /// <summary>
        /// Gets or sets Num10
        /// </summary>
        [EnumValue("Num10", typeof(TaxClearHistoryResx))]
        Num10 = 10

    }
}