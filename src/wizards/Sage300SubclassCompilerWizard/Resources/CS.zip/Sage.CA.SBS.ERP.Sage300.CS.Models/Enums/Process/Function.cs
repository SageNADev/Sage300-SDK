// Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process
{
	/// <summary>
	/// Enum for Function
	/// </summary>
	public enum Function
	{
		/// <summary>
		/// Gets or sets Markprinteddeposits
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Markprinteddeposits = 1,

		/// <summary>
		/// Gets or sets Markunprinteddeposits
		/// </summary>
		// TODO: Replace 'Generated' with resx string once created and 'CommonResx' with correct resx reference
		// TODO: Delete TODO statements when complete
		[EnumValue("Generated", typeof(CommonResx))]
		Markunprinteddeposits = 2
	}
}
