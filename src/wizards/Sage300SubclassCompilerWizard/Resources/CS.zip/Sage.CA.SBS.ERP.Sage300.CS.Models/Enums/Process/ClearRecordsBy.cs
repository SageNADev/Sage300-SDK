// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process
{
    /// <summary>
    /// Enum for ClearRecordsBy
    /// </summary>
    public enum ClearRecordsBy
    {
        /// <summary>
        /// Gets or sets ClearbyPeriod
        /// </summary>
        [EnumValue("ClearbyPeriod", typeof(TaxClearHistoryResx))]
        ClearbyPeriod = 1,

        /// <summary>
        /// Gets or sets ClearbyDate
        /// </summary>
        [EnumValue("ClearbyDate", typeof(TaxClearHistoryResx))]
        ClearbyDate = 0

    }
}