// Copyright © 2016 Sage Software, Inc

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Process;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.Process
{
    /// <summary>
    /// Enum for MethodOfClearingClasses
    /// </summary>
    public enum MethodOfClearingClasses
    {
        /// <summary>
        /// Gets or sets Allitemclasses
        /// </summary>
        [EnumValue("Allitemclasses", typeof(TaxClearHistoryResx))]
        Allitemclasses = 1,

        /// <summary>
        /// Gets or sets SpecifiedrangeOfitemclasses
        /// </summary>
        [EnumValue("SpecifiedrangeOfitemclasses", typeof(TaxClearHistoryResx))]
        SpecifiedrangeOfitemclasses = 2,

        /// <summary>
        /// Gets or sets SpecifiedrangeAndsummaryitemclasses
        /// </summary>
        [EnumValue("SpecifiedrangeAndsummaryitemclasses", typeof(TaxClearHistoryResx))]
        SpecifiedrangeAndsummaryitemclasses = 3

    }
}