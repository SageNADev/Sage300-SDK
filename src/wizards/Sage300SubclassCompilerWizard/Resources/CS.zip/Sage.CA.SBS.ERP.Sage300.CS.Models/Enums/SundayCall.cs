// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum SundayCall
    /// </summary>
    public enum SundayCall
    {
        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("SundayCall_No", typeof (EnumerationsResx))] No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("SundayCall_Yes", typeof (EnumerationsResx))] Yes = 1,
    }
}