 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for ReconciledandJournaledTransac 
    /// </summary>
	public enum ReconciledandJournaledTransac 
	{
			/// <summary>
		/// Gets or sets NotCompleted 
		/// </summary>	
        [EnumValue("NotCompleted", typeof(EnumerationsResx))]
        NotCompleted = 0,
		/// <summary>
		/// Gets or sets Completed 
		/// </summary>	
        [EnumValue("Completed", typeof(EnumerationsResx))]
        Completed = 10,
	}
}
