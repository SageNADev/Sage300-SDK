﻿
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// ProcessCommandCodeReverse Transactions
    /// </summary>
    public enum ProcessCommandCodeReverseTransactions
    {
        LoadSelections = 1,
        SelectAllSelections = 2,
        ClearSelections = 3,
        PostReversalSelections = 4
    }
}
