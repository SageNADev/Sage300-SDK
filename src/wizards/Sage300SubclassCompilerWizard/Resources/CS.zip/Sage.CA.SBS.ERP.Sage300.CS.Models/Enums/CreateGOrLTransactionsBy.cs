﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for CreateGorLTransactionsBy 
    /// </summary>
    public enum CreateGorLTransactionsBy
    {
        /// <summary>
        /// Gets or sets AddingtoanExistingBatch 
        /// </summary>	
        [EnumValue("AddingtoanExistingBatch", typeof(EnumerationsResx))]
        AddingtoanExistingBatch = 1,
        /// <summary>
        /// Gets or sets CreatingaNewBatch 
        /// </summary>	
        [EnumValue("CreatingaNewBatch", typeof(EnumerationsResx))]
        CreatingaNewBatch = 0,
        /// <summary>
        /// Gets or sets CreatingandPostingaNewBatch 
        /// </summary>	
        [EnumValue("CreatingandPostingaNewBatch", typeof(EnumerationsResx))]
        CreatingandPostingaNewBatch = 2,
    }
}