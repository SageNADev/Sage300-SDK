 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for ReconciliationTarget 
    /// </summary>
	public enum ReconciliationTarget 
	{
			/// <summary>
		/// Gets or sets NoTarget 
		/// </summary>	
        NoTarget = 0,
		/// <summary>
		/// Gets or sets BankError 
		/// </summary>	
        BankError = 1,
		/// <summary>
		/// Gets or sets BankPendingError 
		/// </summary>	
        BankPendingError = 2,
		/// <summary>
		/// Gets or sets ExchangeGain 
		/// </summary>	
        ExchangeGain = 3,
		/// <summary>
		/// Gets or sets ExchangeLoss 
		/// </summary>	
        ExchangeLoss = 4,
		/// <summary>
		/// Gets or sets CreditCardCharge 
		/// </summary>	
        CreditCardCharge = 5,
	}
}
