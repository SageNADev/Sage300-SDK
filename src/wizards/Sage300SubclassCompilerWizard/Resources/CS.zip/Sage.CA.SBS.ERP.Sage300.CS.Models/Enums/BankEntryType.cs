// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for BankEntryType 
    /// </summary>
    public enum BankEntryType
    {
        /// <summary>
        /// Gets or sets Withdrawals 
        /// </summary>	
        [EnumValue("Withdrawals", typeof(BKCommonResx))]	
        Withdrawals = 1,
        /// <summary>
        /// Gets or sets Deposits 
        /// </summary>	
         [EnumValue("Deposits", typeof(BKCommonResx))]	
        Deposits = 2,
    }
}
