﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// NumberofFiscalPeriods
    /// </summary>
    public enum NumberofFiscalPeriods
    {
        /// <summary>
        /// NumberOfFiscalPeriod12
        /// </summary>
        [EnumValue("NumberOfFiscalPeriod12", typeof (EnumerationsResx))] Num12 = 12,

        /// <summary>
        /// NumberOfFiscalPeriod13
        /// </summary>
        [EnumValue("NumberOfFiscalPeriod13", typeof (EnumerationsResx))] Num13 = 13,
    }
}