// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Interval
    /// </summary>
    public enum Interval
    {
        /// <summary>
        /// The daily
        /// </summary>
        [EnumValue("Interval_Daily", typeof (EnumerationsResx))] Daily = 1,

        /// <summary>
        /// The weekly
        /// </summary>
        [EnumValue("Interval_Weekly", typeof (EnumerationsResx))] Weekly = 2,

        /// <summary>
        /// The semimonthly
        /// </summary>
        [EnumValue("Interval_Semimonthly", typeof (EnumerationsResx))] Semimonthly = 3,

        /// <summary>
        /// The monthly
        /// </summary>
        [EnumValue("Interval_Monthly", typeof (EnumerationsResx))] Monthly = 4,

        /// <summary>
        /// The annual
        /// </summary>
        [EnumValue("Interval_Annual", typeof (EnumerationsResx))] Annual = 5,

        /// <summary>
        /// The once
        /// </summary>
        [EnumValue("Interval_Once", typeof (EnumerationsResx))] Once = 11,
    }
}