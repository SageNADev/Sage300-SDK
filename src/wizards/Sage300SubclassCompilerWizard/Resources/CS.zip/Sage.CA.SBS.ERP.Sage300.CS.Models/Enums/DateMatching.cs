// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for DateMatching 
    /// </summary>
    public enum DateMatching
    {
        /// <summary>
        /// Gets or sets Exact 
        /// </summary>	
        [EnumValue("Exact", typeof(CSCommonResx))]
        Exact = 1,
        /// <summary>
        /// Gets or sets Later 
        /// </summary>	
        [EnumValue("Later", typeof(CSCommonResx))]
        Later = 2,
        /// <summary>
        /// Gets or sets Earlier 
        /// </summary>	
        [EnumValue("Earlier", typeof(CSCommonResx))]
        Earlier = 3,
    }
}
