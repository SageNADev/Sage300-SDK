// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for PostStatus 
    /// </summary>
    public enum PostStatus
    {
        /// <summary>
        /// Gets or sets Notposted 
        /// </summary>
        [EnumValue("PostStatus_Notposted", typeof(EnumerationsResx))]	
        Notposted = 0,
        /// <summary>
        /// Gets or sets Posted 
        /// </summary>	
         [EnumValue("PostStatus_Posted", typeof(EnumerationsResx))]	
        Posted = 1,
        /// <summary>
        /// Gets or sets Reversed 
        /// </summary>	
        [EnumValue("PostStatus_Reversed", typeof(EnumerationsResx))]	
        Reversed = 2,
        /// <summary>
        /// Gets or sets Cleared 
        /// </summary>	
        [EnumValue("PostStatus_Cleared", typeof(EnumerationsResx))]	
        Cleared = 3,
    }
}
