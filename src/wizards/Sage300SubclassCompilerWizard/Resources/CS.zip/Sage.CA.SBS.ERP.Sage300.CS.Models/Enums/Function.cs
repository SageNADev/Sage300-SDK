 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for Function 
    /// </summary>
	public enum Function 
	{
			/// <summary>
        /// Gets or sets AnyMatchingCriteriaInSubRun? 
		/// </summary>	
        AnyMatchingCriteriaInSubRun = 1,
		/// <summary>
        /// Gets or sets PrepareCheckSubRun (9 digit)
		/// </summary>	
        PrepareCheckSubRun = 2,
        /// <summary>
        /// Gets or sets PrepareCheckSubRun (15 digit)
		/// </summary>	
        PrepareCheckSubRunWithLongerNumber = 12,
        /// <summary>
        /// Gets or sets MarkRangeInCheckregisterForSubRun 
        /// </summary>	
        MarkRangeInCheckregisterForSubRun = 3,
		/// <summary>
        /// Gets or sets MarkEntireCheckRegisterForSubRun 
		/// </summary>	
        MarkEntireCheckRegisterForSubRun = 4,
		/// <summary>
        /// Gets or sets PostAllChecksForSubRun (9 digit)
		/// </summary>	
        PostAllChecksForSubRun = 5,
        /// <summary>
        /// Gets or sets PostAllChecksForSubRun (15 digit)
		/// </summary>	
        PostAllChecksForSubRunWithLongerNumber = 13,
        /// <summary>
        /// Gets or sets PostAlignmentChecksForSubRun 
        /// </summary>	
        PostAlignmentChecksForSubRun = 6,
		/// <summary>
        /// Gets or sets PostVoidChecksForSubRun 
		/// </summary>	
        PostVoidChecksForSubRun = 7,
		/// <summary>
        /// Gets or sets CancelCheckRun 
		/// </summary>	
        CancelCheckRun = 8,
		/// <summary>
        /// Gets or sets CheckRunAllPreparedAndMarkedPrinted? 
		/// </summary>	
        CheckRunAllPreparedAndMarkedPrinted = 9,
		/// <summary>
        /// Gets or sets PostCheckRun 
		/// </summary>	
        PostCheckRun = 10,
		/// <summary>
        /// Gets or sets PrepareAlignmentSubRun 
		/// </summary>	
        PrepareAlignmentSubRun = 11,

        /// <summary>
        /// Gets or sets Shipment Detail Save 
        /// </summary>	
        ShipmentDetailSave = 100,
	}
}
