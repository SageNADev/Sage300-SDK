﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for MethodofClearingClasses 
    /// </summary>
    public enum MethodofClearingClasses
    {
        /// <summary>
        /// Gets or sets Allitemclasses 
        /// </summary>	
        Allitemclasses = 1,
        /// <summary>
        /// Gets or sets Specifiedrangeofitemclasses 
        /// </summary>	
        Specifiedrangeofitemclasses = 2,
        /// <summary>
        /// Gets or sets Specifiedrangeandsummaryitemclasses 
        /// </summary>	
        Specifiedrangeandsummaryitemclasses = 3,
    }
}
