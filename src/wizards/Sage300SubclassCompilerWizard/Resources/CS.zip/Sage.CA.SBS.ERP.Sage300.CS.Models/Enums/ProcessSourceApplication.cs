//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
	/// Enum for ProcessSourceApplication 
	/// </summary>
	public enum ProcessSourceApplication 
	{

        /// <summary>
        /// Gets or sets AccountsPayable 
        /// </summary>	
        [EnumValue("AccountsPayable", typeof(ReverseTransactionsResx))]
        AccountsPayable = 116,

        /// <summary>
        /// Gets or sets AccountsReceivable 
        /// </summary>	
        [EnumValue("AccountsReceivable", typeof(ReverseTransactionsResx))]
        AccountsReceivable = 118,

        /// <summary>
        /// Gets or sets BankServices 
        /// </summary>	
        [EnumValue("BankServices", typeof(ReverseTransactionsResx))]
        BankServices = 211

	}
}
