// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for PublishSetting
    /// </summary>
    public enum PublishSetting
    {
        /// <summary>
        /// Gets or sets Immediately
        /// </summary>
        [EnumValue("Immediately", typeof(PayslipResx))]
        Immediately = 0,
        /// <summary>
        /// Gets or sets OnCheckDate
        /// </summary>
        [EnumValue("OnCheckDate", typeof(PayslipResx))]
        OnCheckDate = 1
    }
}