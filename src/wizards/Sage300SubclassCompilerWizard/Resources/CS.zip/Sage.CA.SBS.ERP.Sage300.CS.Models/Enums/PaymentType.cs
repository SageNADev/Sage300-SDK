// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for PaymentType 
    /// </summary>
    public enum PaymentType
    {
        /// <summary>
        /// Gets or sets Check 
        /// </summary>	
        [EnumValue("Check", typeof(EnumerationsResx))]
        Check = 1,
        /// <summary>
        /// Gets or sets CreditCard 
        /// </summary>	
        [EnumValue("CreditCard", typeof(EnumerationsResx))]
        CreditCard = 5,
        /// <summary>
        /// Gets or sets Cash 
        /// </summary>	
        [EnumValue("Cash", typeof(EnumerationsResx))]
        Cash = 6,
        /// <summary>
        /// Gets or sets Other 
        /// </summary>	
        [EnumValue("Other", typeof(EnumerationsResx))]
        Other = 7,
    }
}
