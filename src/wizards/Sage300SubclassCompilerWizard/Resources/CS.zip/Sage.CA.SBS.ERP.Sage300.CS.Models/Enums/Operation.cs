//  Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Operation
    /// </summary>
    public enum Operation
    {
        /// <summary>
        /// The get next scheduled run
        /// </summary>
        [EnumValue("Operation_GetNextScheduledRun", typeof (EnumerationsResx))] GetNextScheduledRun = 101,

        /// <summary>
        /// Gets or sets GetReconciliationPostingSequenceRange 
        /// </summary>	
        GetReconciliationPostingSequenceRange = 1,
        /// <summary>
        /// Gets or sets MarkReconciliationsasPrinted 
        /// </summary>	
        MarkReconciliationsasPrinted = 2,
        /// <summary>
        /// Gets or sets PurgePrintedReconciliations 
        /// </summary>	
        PurgePrintedReconciliations = 3,
        /// <summary>
        /// Gets or sets CreateGOrLBatch 
        /// </summary>	
        CreateGOrLBatch = 4,
        /// <summary>
        /// Gets or sets GetDeferredGOrLPostingSequenceRange 
        /// </summary>	
        GetDeferredGOrLPostingSequenceRange = 5,
        /// <summary>
        /// Gets or sets RestartInterruptedGOrLBatchCreation 
        /// </summary>	
        RestartInterruptedGOrLBatchCreation = 6,
        /// <summary>
        /// Gets or sets GetTransferPostingSequenceRange 
        /// </summary>	
        GetTransferPostingSequenceRange = 7,
        /// <summary>
        /// Gets or sets MarkTransfersasPrinted 
        /// </summary>	
        MarkTransfersasPrinted = 8,
        /// <summary>
        /// Gets or sets PurgePrintedTransfers 
        /// </summary>	
        PurgePrintedTransfers = 9,
        /// <summary>
        /// Gets or sets CreateReportTempFile 
        /// </summary>	
        CreateReportTempFile = 10,
        /// <summary>
        /// Gets or sets DeleteReportTempFile 
        /// </summary>	
        DeleteReportTempFile = 11,
        /// <summary>
        /// Gets or sets WithinActivePostBanksRange 
        /// </summary>	
        WithinActivePostBanksRange = 12,
        /// <summary>
        /// Gets or sets PurgeBankTransactions 
        /// </summary>	
        PurgeBankTransactions = 13,
        /// <summary>
        /// Gets or sets GetBankEntrySequenceRange 
        /// </summary>	
        GetBankEntrySequenceRange = 14,
        /// <summary>
        /// Gets or sets PurgeBankEntries 
        /// </summary>	
        PurgeBankEntries = 15,
        /// <summary>
        /// Gets or sets GetBankEntryPostingSequenceRange 
        /// </summary>	
        GetBankEntryPostingSequenceRange = 16,
        /// <summary>
        /// Gets or sets MarkBankEntryPostingJournalsasPrinted 
        /// </summary>	
        MarkBankEntryPostingJournalsasPrinted = 17,
        /// <summary>
        /// Gets or sets PurgePrintedBankEntryPostingJournals 
        /// </summary>	
        PurgePrintedBankEntryPostingJournals = 18,
    }
}