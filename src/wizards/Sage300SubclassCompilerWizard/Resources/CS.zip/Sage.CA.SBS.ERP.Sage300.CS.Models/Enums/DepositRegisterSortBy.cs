﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum ReportByType
    /// </summary>
    public enum DepositRegisterSortBy
    {
        /// <summary>
        /// The Fiscal Period
        /// </summary>
        [EnumValue("LblTransNumCap", typeof(BKCommonResx))]
        TransactionNumber = 0,

        /// <summary>
        /// The Fiscal Period
        /// </summary>
        [EnumValue("DateremitFLD", typeof(BKCommonResx))]
        TransactionDate = 1,

        /// <summary>
        /// The Document Date
        /// </summary>
        [EnumValue("CustomerName", typeof(DepositRegisterReportResx))]
        DescriptionOrCustomerName = 2,
    }
}
