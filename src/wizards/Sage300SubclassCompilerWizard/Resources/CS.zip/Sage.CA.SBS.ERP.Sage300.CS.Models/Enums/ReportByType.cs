﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum ReportByType
    /// </summary>
    public enum ReportByType
    {
        /// <summary>
        /// The Fiscal Period
        /// </summary>
        [EnumValue("FiscalPeriod", typeof(CommonResx))]
        FiscalPeriod = 0,

        /// <summary>
        /// The Document Date
        /// </summary>
        //[EnumValue("FunctionalCurrency", typeof(CommonResx))]
        DocumentDate = 1,
    }
}
