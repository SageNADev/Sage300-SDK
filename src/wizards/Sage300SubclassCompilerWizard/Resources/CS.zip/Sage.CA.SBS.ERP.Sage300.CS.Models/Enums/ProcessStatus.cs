// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ProcessStatus 
    /// </summary>
    public enum ProcessStatus
    {
        /// <summary>
        /// Gets or sets Executing 
        /// </summary>	
        Executing = 0,

        /// <summary>
        /// Gets or sets ExecutionComplete 
        /// </summary>	
        ExecutionComplete = 1,
    }
}