// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for AdjustmentPeriodStatus.
    /// </summary>
    public enum AdjustmentPeriodStatus
    {
        /// <summary>
        /// Gets or sets Unlocked.
        /// </summary>	
        [EnumValue("Unlocked", typeof(FiscalCalendarResx))]
        Unlocked = 1,

        /// <summary>
        /// Gets or sets Locked.
        /// </summary>	
        [EnumValue("Locked", typeof(FiscalCalendarResx))]
        Locked = 0
    }
}