/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetDesignator
    /// </summary>
    public enum FiscalSetDesignator
    {
        /// <summary>
        /// The actuals
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Actuals", typeof(EnumerationsResx))]
        Actuals = 0,

        /// <summary>
        /// The quantity
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Quantity", typeof(EnumerationsResx))]
        Quantity = 1,

        /// <summary>
        /// The reporting
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Reporting", typeof(EnumerationsResx))]
        Reporting = 2,

        /// <summary>
        /// The provisional actuals
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("ProvisionalActuals", typeof(EnumerationsResx))]
        ProvisionalActuals = 3,

        /// <summary>
        /// The provisional quantity
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("ProvisionalQuantity", typeof(EnumerationsResx))]
        ProvisionalQuantity = 4,

        /// <summary>
        /// The provisional reporting
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("ProvisionalReporting", typeof(EnumerationsResx))]
        ProvisionalReporting = 5,

        /// <summary>
        /// The budget1
        /// </summary>
        [EnumValue("Budget1", typeof(EnumerationsResx))]
        Budget1 = 6,

        /// <summary>
        /// The budget2
        /// </summary>
        [EnumValue("Budget2", typeof(EnumerationsResx))]
        Budget2 = 7,

        /// <summary>
        /// The budget3
        /// </summary>
        [EnumValue("Budget3", typeof(EnumerationsResx))]
        Budget3 = 8,

        /// <summary>
        /// The budget4
        /// </summary>
        [EnumValue("Budget4", typeof(EnumerationsResx))]
        Budget4 = 9,

        /// <summary>
        /// The budget5
        /// </summary>
        [EnumValue("Budget5", typeof(EnumerationsResx))]
        Budget5 = 10,
    }
}