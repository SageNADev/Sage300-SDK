/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetProcessasytdbalancesSwitch
    /// </summary>
    public enum FiscalSetProcessasytdbalancesSwitch
    {
        /// <summary>
        /// The balances
        /// </summary>
        [EnumValue("Balances", typeof(EnumerationsResx))]
        Balances = 0,

        /// <summary>
        /// The net changes
        /// </summary>
        [EnumValue("NetChanges", typeof(EnumerationsResx))]
        NetChanges = 1,
    }
}