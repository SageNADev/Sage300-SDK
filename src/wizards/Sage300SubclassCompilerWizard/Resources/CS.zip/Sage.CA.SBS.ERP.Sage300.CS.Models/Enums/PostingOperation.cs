// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Posting Operation
    /// </summary>
    public enum PostingOperation
    {
        /// <summary>
        /// Gets or sets Post 
        /// </summary>	
        Post = 1,

        /// <summary>
        /// Gets or sets Restart Active Post 
        /// </summary>	
        RestartActivePost = 2,

        /// <summary>
        /// Gets or sets Rangeof Active Post Banks 
        /// </summary>	
        RangeofActivePostBanks = 3,

        /// <summary>
        /// Gets or sets Within Active Post Banks Range 
        /// </summary>	
        WithinActivePostBanksRange = 4,

        /// <summary>
        /// Gets or sets Intersect With Active Post Banks 
        /// </summary>	
        IntersectWithActivePostBanks = 5,

        /// <summary>
        /// Gets or sets Post Entries 
        /// </summary>	
        PostEntries = 6,

        /// <summary>
        /// Gets or sets Restart Active Post Entries 
        /// </summary>	
        RestartActivePostEntries = 7,

        /// <summary>
        /// Gets or sets Range In Bank
        /// </summary>
        RangeInBank = 9
    }
}