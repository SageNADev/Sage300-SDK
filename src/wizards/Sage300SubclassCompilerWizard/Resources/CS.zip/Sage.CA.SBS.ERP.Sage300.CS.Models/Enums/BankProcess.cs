// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for BankProcess 
    /// </summary>
    public enum BankProcess
    {
        /// <summary>
        /// Gets or sets AddingOrModifyingChecksOrDeposits 
        /// </summary>	
        AddingOrModifyingChecksOrDeposits = 0,

        /// <summary>
        /// Gets or sets PrintingChecks 
        /// </summary>	
        PrintingChecks = 1,

        /// <summary>
        /// Gets or sets MaintainingBanks 
        /// </summary>	
        MaintainingBanks = 2,

        /// <summary>
        /// Gets or sets ReconcilingBanks 
        /// </summary>	
        ReconcilingBanks = 3,

        /// <summary>
        /// Gets or sets PostingReconciliations 
        /// </summary>	
        PostingReconciliations = 4,

        /// <summary>
        /// Gets or sets CreatingGOrLBatch 
        /// </summary>	
        CreatingGOrLBatch = 5,

        /// <summary>
        /// Gets or sets PrintingGOrLTransactions 
        /// </summary>	
        PrintingGOrLTransactions = 6,

        /// <summary>
        /// Gets or sets ReconcilingOFXStatements 
        /// </summary>	
        ReconcilingOFXStatements = 7,

        /// <summary>
        /// Gets or sets ReversingPayments 
        /// </summary>	
        ReversingPayments = 8,

        /// <summary>
        /// Gets or sets ReturningCustomerChecks 
        /// </summary>	
        ReturningCustomerChecks = 9,

        /// <summary>
        /// Gets or sets ReversingTransactions 
        /// </summary>	
        ReversingTransactions = 10,

        /// <summary>
        /// Gets or sets EntryPosting
        /// </summary>
        EntryPosting = 11
    }
}