﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Quarterwith4Periods
    /// </summary>
    public enum Quarterwith4Periods
    {
        /// <summary>
        /// Num1
        /// </summary>
        [EnumValue("Num1", typeof (EnumerationsResx))] Num1 = 1,

        /// <summary>
        /// Num2
        /// </summary>
        [EnumValue("Num2", typeof (EnumerationsResx))] Num2 = 2,

        /// <summary>
        /// Num3
        /// </summary>
        [EnumValue("Num3", typeof (EnumerationsResx))] Num3 = 3,

        /// <summary>
        /// Num4
        /// </summary>
        [EnumValue("Num4", typeof (EnumerationsResx))] Num4 = 4
    }
}