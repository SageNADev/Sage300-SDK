﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{

    public enum ProcessCmdEmployeeSelection
    {
        /// <summary>
        LoadEmployeeSelections = 0,

        /// <summary>
        /// Gets or sets SyncSelectedToSageHR
        /// </summary>
        SyncSelectedToSageHR = 1,

        /// <summary>
        /// Gets or sets SelectDeselectAll
        /// </summary>
        SelectDeselectAll = 2
    }
}
