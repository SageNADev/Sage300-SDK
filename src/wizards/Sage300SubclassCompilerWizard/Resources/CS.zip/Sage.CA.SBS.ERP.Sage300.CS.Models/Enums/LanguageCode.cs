 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for LanguageCode 
    /// </summary>
	public enum LanguageCode 
	{
			/// <summary>
		/// Gets or sets Showchecksinalllanguages 
		/// </summary>	
        Showchecksinalllanguages = -1,
		/// <summary>
		/// Gets or sets English 
		/// </summary>	
        English = 5658,
		/// <summary>
		/// Gets or sets French 
		/// </summary>	
        French = 7092,
		/// <summary>
		/// Gets or sets Spanish 
		/// </summary>	
        Spanish = 5845,
		/// <summary>
		/// Gets or sets Australian 
		/// </summary>	
        Australian = 738,
		/// <summary>
		/// Gets or sets Mexican 
		/// </summary>	
        Mexican = 15719,
		/// <summary>
		/// Gets or sets ChineseSimplified 
		/// </summary>	
        ChineseSimplified = 2857,
		/// <summary>
		/// Gets or sets ChineseTraditional 
		/// </summary>	
        ChineseTraditional = 2863,
	}
}
