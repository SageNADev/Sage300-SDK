// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for EntryType 
    /// </summary>
    public enum EntryType
    {
        #region enums

        /// <summary>
        /// Gets or sets Userentered 
        /// </summary>	
        [EnumValue("UserEntered", typeof(EnumerationsResx))]
        Userentered = 0,

        /// <summary>
        /// Gets or sets BankEntered 
        /// </summary>	
        [EnumValue("BankEntered", typeof(EnumerationsResx))]
        BankEntered = 1,

        /// <summary>
        /// Gets or sets Miscellaneous 
        /// </summary>	
        [EnumValue("Miscellaneous", typeof(EnumerationsResx))]
        Miscellaneous = 2,

        /// <summary>
        /// Gets or sets Subledger 
        /// </summary>	
        [EnumValue("Subledger", typeof(EnumerationsResx))]
        Subledger = 3,

        /// <summary>
        /// Gets or sets Transfer 
        /// </summary>        
        [EnumValue("Transfer", typeof(BKCommonResx))]
        Transfer = 4,

        /// <summary>
        /// Gets or sets ReturnedCustomerCheck 
        /// </summary>	
        [EnumValue("ReturnedCustomerCheck", typeof(EnumerationsResx))]
        ReturnedCustomerCheck = 5,

        /// <summary>
        /// Gets or sets Alignment 
        /// </summary>	
        [EnumValue("Alignment", typeof(BKCommonResx))]
        Alignment = 6,

        /// <summary>
        /// Gets or sets NonNegotiable 
        /// </summary>	
        [EnumValue("NonNegotiable", typeof(BKCommonResx))]
        NonNegotiable = 7,

        /// <summary>
        /// Gets or sets UnmatchedOFX 
        /// </summary>	
        [EnumValue("UnmatchedOFX", typeof(EnumerationsResx))]
        UnmatchedOFX = 10,

        /// <summary>
        /// Gets or sets UnmatchedOFXcorrection 
        /// </summary>	
        [EnumValue("UnmatchedOFXCorrection", typeof(EnumerationsResx))]
        UnmatchedOFXcorrection = 19,

        /// <summary>
        /// Gets or sets UnmatchedOFXerror 
        /// </summary>	
        [EnumValue("UnmatchedOFXError", typeof(EnumerationsResx))]
        UnmatchedOFXerror = 20,

        #endregion
    }
}
