﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Print
    /// </summary>
    public enum Print
    {
        /// <summary>
        /// Details and Summary
        /// </summary>
        [EnumValue("DetailsAndSummary", typeof(EnumerationsResx))]
        DetailsAndSummary = 0,

        /// <summary>
        /// Details
        /// </summary>
        [EnumValue("Details", typeof(EnumerationsResx))]
        Details = 1,

        /// <summary>
        /// Summary
        /// </summary>
        [EnumValue("Summary", typeof(EnumerationsResx))]
        Summary = 2

    }
}
