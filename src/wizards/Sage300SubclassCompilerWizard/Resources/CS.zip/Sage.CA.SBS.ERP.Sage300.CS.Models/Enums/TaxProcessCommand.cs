 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for TaxProcessCommand 
    /// </summary>
	public enum TaxProcessCommand 
	{
			/// <summary>
		/// Gets or sets CalculateTaxes 
		/// </summary>	
        CalculateTaxes = 0,
		/// <summary>
		/// Gets or sets DeriveTaxReportingExchRate 
		/// </summary>	
        DeriveTaxReportingExchRate = 1,
	}
}
