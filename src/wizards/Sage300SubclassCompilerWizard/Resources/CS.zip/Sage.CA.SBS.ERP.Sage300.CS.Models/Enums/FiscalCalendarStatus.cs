﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for FiscalStatus 
    /// </summary>
    public enum FiscalCalendarStatus
    {
          /// <summary>
        /// Gets or sets Active 
        /// </summary>	
          [EnumValue("Status_Active", typeof(CSCommonResx))]
           Active = 1,
        /// <summary>
        /// Gets or sets Inactive 
        /// </summary>
         [EnumValue("Status_Inactive", typeof(CSCommonResx))]
        Inactive = 0,
    }
}
