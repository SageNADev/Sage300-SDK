﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum DecimalPlaces
    /// </summary>
    public enum DecimalPlaces
    {
        /// <summary>
        /// The num0
        /// </summary>
        [EnumValue("DecimalPlaces_Num0", typeof (EnumerationsResx))] Num0 = 0,

        /// <summary>
        /// The num1
        /// </summary>
        [EnumValue("DecimalPlaces_Num1", typeof (EnumerationsResx))] Num1 = 1,

        /// <summary>
        /// The num2
        /// </summary>
        [EnumValue("DecimalPlaces_Num2", typeof (EnumerationsResx))] Num2 = 2,

        /// <summary>
        /// The num3
        /// </summary>
        [EnumValue("DecimalPlaces_Num3", typeof (EnumerationsResx))] Num3 = 3
    }
}