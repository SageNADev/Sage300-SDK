
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for TransactionDetailStatus 
    /// </summary>
	public enum TransactionDetailStatus 
	{
	    /// <summary>
		/// Gets or sets NotPosted 
		/// </summary>	
        [EnumValue("NotPosted", typeof(BKCommonResx))]
        NotPosted = 1,
        /// <summary>
        /// Gets or sets Void 
        /// </summary>
        [EnumValue("Void", typeof(BKCommonResx))]
        Void = 2,

        /// <summary>
        /// Gets or sets Outstanding 
        /// </summary>	
        [EnumValue("Outstanding", typeof(BKCommonResx))]
        Outstanding = 3,

        /// <summary>
        /// Gets or sets Reversed 
        /// </summary>	
        [EnumValue("Reversed", typeof(EnumerationsResx))]
        Reversed = 4,
        /// <summary>
        /// Gets or sets Cleared 
        /// </summary>	
        [EnumValue("Cleared", typeof(BankReconcileStatementResx))]
        Cleared = 5,
        /// <summary>
        /// Gets or sets Clearedwithbankerror 
        /// </summary>	
        [EnumValue("Clearedwithbankerror", typeof(BankReconcileStatementResx))]
        Clearedwithbankerror = 6,

        /// <summary>
        /// Gets or sets Nonnegotiable 
        /// </summary>	
        [EnumValue("NonNegotiable", typeof(BKCommonResx))]
        Nonnegotiable = 7,

        /// <summary>
        /// Gets or sets Continuation 
        /// </summary>	
        [EnumValue("Continuation", typeof(BKCommonResx))]
        Continuation = 8,

        /// <summary>
        /// Gets or sets Printed 
        /// </summary>	
        [EnumValue("Printed", typeof(BKCommonResx))]
        Printed = 9,

        /// <summary>
        /// Gets or sets Clearedwithwriteoff 
        /// </summary>	
        [EnumValue("Clearedwithwriteoff", typeof(BankReconcileStatementResx))]
        Clearedwithwriteoff = 10,

        /// <summary>
        /// Gets or sets Clearedwithexchangeratedifference 
        /// </summary>	
        [EnumValue("Clearedwithexchangeratedifference", typeof(BankReconcileStatementResx))]
        Clearedwithexchangeratedifference = 11,
        /// <summary>
        /// Gets or sets Clearedwithcreditcardcharge 
        /// </summary>	
        [EnumValue("Clearedwithcreditcardcharge", typeof(BankReconcileStatementResx))]
        Clearedwithcreditcardcharge = 12,

	}
}
