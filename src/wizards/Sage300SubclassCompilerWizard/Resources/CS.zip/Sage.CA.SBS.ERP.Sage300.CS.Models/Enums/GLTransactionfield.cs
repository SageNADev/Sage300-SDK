// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for GLTransactionfield 
    /// </summary>
	public enum GLTransactionField 
	{
	    /// <summary>
		/// Gets or sets GLEntryDescription 
		/// </summary>
        [EnumValue("COLEntryDesc", typeof(BankGLIntegrationResx), 1)]
        GLEntryDescription = 1,
		/// <summary>
		/// Gets or sets GLDetailReference 
		/// </summary>
		[EnumValue("COLDtlReference", typeof(BankGLIntegrationResx), 2)]	
        GLDetailReference = 2,
		/// <summary>
		/// Gets or sets GLDetailDescription 
		/// </summary>	
		[EnumValue("COLDtlDesc", typeof(BankGLIntegrationResx), 3)]	
        GLDetailDescription = 3,
		/// <summary>
		/// Gets or sets GLDetailComment 
		/// </summary>
        [EnumValue("GLDetailComment", typeof(GLIntegrationResx), 4)]	
        GLDetailComment = 4,
	}
}
