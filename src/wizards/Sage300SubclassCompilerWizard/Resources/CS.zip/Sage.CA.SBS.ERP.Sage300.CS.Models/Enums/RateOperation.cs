﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.
# region namespaces

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for RateOperation 
    /// </summary>
    public enum RateOperation
    {
        # region enums

        //TODO: Reconcilation Statements may need this. If not needed to be removed
        ///// <summary>
        ///// Gets or sets NotSpecified 
        ///// </summary>	
        //NotSpecified = 0,

        /// <summary>
        /// Gets or sets Multiply 
        /// </summary>	
        [EnumValue("Multiply", typeof(CSCommonResx))]
        Multiply = 1,

        /// <summary>
        /// Gets or sets Divide 
        /// </summary>	
        [EnumValue("Divide", typeof(CSCommonResx))]
        Divide = 2,
        
        #endregion
    }
}
