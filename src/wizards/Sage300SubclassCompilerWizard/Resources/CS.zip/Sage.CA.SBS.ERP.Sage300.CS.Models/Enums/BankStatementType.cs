// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for BankStatementType 
    /// </summary>
    public enum BankStatementType
    {
        /// <summary>
        /// Gets or sets Invalid 
        /// </summary>
        [EnumValue("Invalid", typeof(CommonResx))]
        Invalid = 0,

        /// <summary>
        /// Gets or sets Single 
        /// </summary>	
        [EnumValue("Single", typeof(CommonResx))]
        Single = 1,

        /// <summary>
        /// Gets or sets Multiple 
        /// </summary>	
        [EnumValue("Multiple", typeof(CommonResx))]
        Multiple = 2,

        /// <summary>
        /// Gets or sets Foreign 
        /// </summary>	
        [EnumValue("Foreign", typeof(CommonResx))]
        Foreign = 3,
    }
}