// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for DefaultReconcileDetailSortBy 
    /// </summary>
    public enum DefaultReconcileDetailSortBy
    {
        /// <summary>
        /// Gets or sets Date 
        /// </summary>	
        [EnumValue("Date", typeof (CommonResx), 0)] Date = 0,

        /// <summary>
        /// Gets or sets ReceiptNo 
        /// </summary>	
        [EnumValue("ReceiptNo", typeof (BankOptionsResx), 1)] ReceiptNo = 1
    }
}