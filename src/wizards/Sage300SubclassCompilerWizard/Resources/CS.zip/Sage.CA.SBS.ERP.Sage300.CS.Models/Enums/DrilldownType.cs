/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for DrilldownType 
    /// </summary>
    public enum DrilldownType
    {
        # region enums

        /// <summary>
        /// Gets or sets NoDrilldownInfo 
        /// </summary>	
        NoDrilldownInfo = 0,

        /// <summary>
        /// Gets or sets WindowOpen 
        /// </summary>	
        WindowOpen = 1,

        /// <summary>
        /// Gets or sets WindowClose 
        /// </summary>	
        WindowClose = 2,

        /// <summary>
        /// Gets or sets NotAllowed 
        /// </summary>	
        NotAllowed = 3,

        #endregion
    }
}
