﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for TaxDetails 
    /// </summary>
    public enum TaxDetails
    {
        /// <summary>
        /// Gets or sets TaxAuthorityNotFound 
        /// </summary>
        TaxAuthorityNotFound = 2,

        /// <summary>
        /// Gets or sets TaxClassNotFound 
        /// </summary>
        TaxClassNotFound = 1,

        /// <summary>
        /// 
        /// </summary>
        BothFound = 0,
    }
}