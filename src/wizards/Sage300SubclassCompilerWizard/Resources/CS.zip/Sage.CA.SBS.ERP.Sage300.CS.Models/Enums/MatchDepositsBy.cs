
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for MatchDepositsBy 
    /// </summary>
    public enum MatchDepositsBy
    {
        /// <summary>
        /// Gets or sets DepositSlip 
        /// </summary>	
        DepositSlip = 0,
        /// <summary>
        /// Gets or sets Transaction 
        /// </summary>	
        Transaction = 1,
    }
}
