// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Create GL Batches 
    /// </summary>
    public enum CreateGLBatches
    {
        /// <summary>
        /// Gets or sets DuringPosting 
        /// </summary>	
        DuringPosting = 1,

        /// <summary>
        /// Gets or sets OnRequestUsingCreateGOrLBatchIcon 
        /// </summary>	
        OnRequestUsingCreateGOrLBatchIcon = 0,
    }
}