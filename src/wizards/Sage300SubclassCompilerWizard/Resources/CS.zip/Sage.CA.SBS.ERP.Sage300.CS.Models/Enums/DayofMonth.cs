﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum DayofMonth
    /// </summary>
    public enum DayofMonth
    {
        /// <summary>
        /// The num1st
        /// </summary>
        [EnumValue("DayofMonth_Num1st", typeof (EnumerationsResx))] Num1st = 1,

        /// <summary>
        /// The num2nd
        /// </summary>
        [EnumValue("DayofMonth_Num2nd", typeof (EnumerationsResx))] Num2nd = 2,

        /// <summary>
        /// The num3rd
        /// </summary>
        [EnumValue("DayofMonth_Num3rd", typeof (EnumerationsResx))] Num3rd = 3,

        /// <summary>
        /// The num4th
        /// </summary>
        [EnumValue("DayofMonth_Num4th", typeof (EnumerationsResx))] Num4th = 4,

        /// <summary>
        /// The num5th
        /// </summary>
        [EnumValue("DayofMonth_Num5th", typeof (EnumerationsResx))] Num5th = 5,

        /// <summary>
        /// The num6th
        /// </summary>
        [EnumValue("DayofMonth_Num6th", typeof (EnumerationsResx))] Num6th = 6,

        /// <summary>
        /// The num7th
        /// </summary>
        [EnumValue("DayofMonth_Num7th", typeof (EnumerationsResx))] Num7th = 7,

        /// <summary>
        /// The num8th
        /// </summary>
        [EnumValue("DayofMonth_Num8th", typeof (EnumerationsResx))] Num8th = 8,

        /// <summary>
        /// The num9th
        /// </summary>
        [EnumValue("DayofMonth_Num9th", typeof (EnumerationsResx))] Num9th = 9,

        /// <summary>
        /// The num10th
        /// </summary>
        [EnumValue("DayofMonth_Num10th", typeof (EnumerationsResx))] Num10th = 10,

        /// <summary>
        /// The num11th
        /// </summary>
        [EnumValue("DayofMonth_Num11th", typeof (EnumerationsResx))] Num11th = 11,

        /// <summary>
        /// The num12th
        /// </summary>
        [EnumValue("DayofMonth_Num12th", typeof (EnumerationsResx))] Num12th = 12,

        /// <summary>
        /// The num13th
        /// </summary>
        [EnumValue("DayofMonth_Num13th", typeof (EnumerationsResx))] Num13th = 13,

        /// <summary>
        /// The num14th
        /// </summary>
        [EnumValue("DayofMonth_Num14th", typeof (EnumerationsResx))] Num14th = 14,

        /// <summary>
        /// The num15th
        /// </summary>
        [EnumValue("DayofMonth_Num15th", typeof (EnumerationsResx))] Num15th = 15,

        /// <summary>
        /// The num16th
        /// </summary>
        [EnumValue("DayofMonth_Num16th", typeof (EnumerationsResx))] Num16th = 16,

        /// <summary>
        /// The num17th
        /// </summary>
        [EnumValue("DayofMonth_Num17th", typeof (EnumerationsResx))] Num17th = 17,

        /// <summary>
        /// The num18th
        /// </summary>
        [EnumValue("DayofMonth_Num18th", typeof (EnumerationsResx))] Num18th = 18,

        /// <summary>
        /// The num19th
        /// </summary>
        [EnumValue("DayofMonth_Num19th", typeof (EnumerationsResx))] Num19th = 19,

        /// <summary>
        /// The num20th
        /// </summary>
        [EnumValue("DayofMonth_Num20th", typeof (EnumerationsResx))] Num20th = 20,

        /// <summary>
        /// The num21st
        /// </summary>
        [EnumValue("DayofMonth_Num21st", typeof (EnumerationsResx))] Num21st = 21,

        /// <summary>
        /// The num22nd
        /// </summary>
        [EnumValue("DayofMonth_Num22nd", typeof (EnumerationsResx))] Num22nd = 22,

        /// <summary>
        /// The num23rd
        /// </summary>
        [EnumValue("DayofMonth_Num23rd", typeof (EnumerationsResx))] Num23rd = 23,

        /// <summary>
        /// The num24th
        /// </summary>
        [EnumValue("DayofMonth_Num24th", typeof (EnumerationsResx))] Num24th = 24,

        /// <summary>
        /// The num25th
        /// </summary>
        [EnumValue("DayofMonth_Num25th", typeof (EnumerationsResx))] Num25th = 25,

        /// <summary>
        /// The num26th
        /// </summary>
        [EnumValue("DayofMonth_Num26th", typeof (EnumerationsResx))] Num26th = 26,

        /// <summary>
        /// The num27th
        /// </summary>
        [EnumValue("DayofMonth_Num27th", typeof (EnumerationsResx))] Num27th = 27,

        /// <summary>
        /// The num28th
        /// </summary>
        [EnumValue("DayofMonth_Num28th", typeof (EnumerationsResx))] Num28th = 28,

        /// <summary>
        /// The num29th
        /// </summary>
        [EnumValue("DayofMonth_Num29th", typeof (EnumerationsResx))] Num29th = 29,

        /// <summary>
        /// The num30th
        /// </summary>
        [EnumValue("DayofMonth_Num30th", typeof (EnumerationsResx))] Num30th = 30,

        /// <summary>
        /// The num31st
        /// </summary>
        [EnumValue("DayofMonth_Num31st", typeof (EnumerationsResx))] Num31st = 31,

        /// <summary>
        /// The last
        /// </summary>
        [EnumValue("DayofMonth_Last", typeof (EnumerationsResx))] Last = 99,
    }
}