/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ClassType 
    /// </summary>
    public enum ClassType
    {
        /// <summary>
        /// Gets or sets Customers 
        /// </summary>	
        [EnumValue("Customers", typeof(TaxClassesResx))]
        Customers = 1,
        /// <summary>
        /// Gets or sets Items 
        /// </summary>	

        [EnumValue("Items", typeof(TaxClassesResx))]
        Items = 2,
    }
}