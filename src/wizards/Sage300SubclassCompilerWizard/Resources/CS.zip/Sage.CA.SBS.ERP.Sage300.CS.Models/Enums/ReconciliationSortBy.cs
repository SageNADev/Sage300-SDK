﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Reconciliation Sort By
    /// </summary>
    public enum ReconciliationSortBy
    { 
        /// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>	
        [EnumValue("Date", typeof(CommonResx))]
        DocumentDate = 0,

        /// <summary>
        /// Gets or sets Number
        /// </summary>	
        [EnumValue("LblNumberCap", typeof(BKCommonResx))]
        Number = 1,
         
    }

}
