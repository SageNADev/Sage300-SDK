 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for ReportTaxonRetainageDocument 
    /// </summary>
	public enum ReportTaxonRetainageDocument 
	{
			/// <summary>
		/// Gets or sets NoReporting 
		/// </summary>	
        [EnumValue("Noreporting", typeof(EnumerationsResx))]
        NoReporting = 0,
		/// <summary>
		/// Gets or sets AtTimeofRetainageDocument 
		/// </summary>	
        [EnumValue("AtTimeofRetainageDocument", typeof(EnumerationsResx))]
        AtTimeofRetainageDocument = 1,
		/// <summary>
		/// Gets or sets AtTimeofOriginalDocument 
		/// </summary>	
        [EnumValue("AtTimeofOriginalDocument", typeof(EnumerationsResx))]
        AtTimeofOriginalDocument = 2,
	}
}
