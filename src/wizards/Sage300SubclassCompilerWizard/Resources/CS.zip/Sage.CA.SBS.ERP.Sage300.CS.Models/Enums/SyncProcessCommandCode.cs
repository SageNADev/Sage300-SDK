// Copyright (c)   All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
	/// Enum for ProcessCommandCode
	/// </summary>
	public enum SyncProcessCommandCode
	{
		/// <summary>
		/// Gets or sets InvokeSageHRSyncEngine
		/// </summary>
		InvokeSageHRSyncEngine = 0,

		/// <summary>
		/// Gets or sets EmployeeUpdateNotification
		/// </summary>
		EmployeeUpdateNotification = 1,

		/// <summary>
		/// Gets or sets EmployeeDeleteNotification
		/// </summary>
		EmployeeDeleteNotification = 2
	}
}
