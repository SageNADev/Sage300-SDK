﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Display Reconciliation 
    /// </summary>
    public enum DisplayReconciliation
    {
        /// <summary>
        /// Gets or sets All 
        /// </summary>	
        [EnumValue("All", typeof(CommonResx))]
        All = 0,

        /// <summary>
        /// Gets or sets Outstanding 
        /// </summary>	
        [EnumValue("Outstanding", typeof(BKCommonResx))]
        Outstanding = 1,
        
        /// <summary>
        /// Gets or sets Reconciled 
        /// </summary>	
        [EnumValue("ReconciledFLD", typeof(BKCommonResx))]
        Reconciled = 2,

    }

}
