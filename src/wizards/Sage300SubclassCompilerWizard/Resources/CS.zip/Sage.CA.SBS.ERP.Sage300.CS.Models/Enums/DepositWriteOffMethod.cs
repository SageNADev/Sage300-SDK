// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for DepositWriteOffMethod 
    /// </summary>
    public enum DepositWriteOffMethod
    {
        /// <summary>
        /// Gets or sets None 
        /// </summary>	
        None = 0,

        /// <summary>
        /// Gets or sets Prorate 
        /// </summary>	
        Prorate = 1,

        /// <summary>
        /// Gets or sets TopDown 
        /// </summary>	
        TopDown = 2,
    }
}