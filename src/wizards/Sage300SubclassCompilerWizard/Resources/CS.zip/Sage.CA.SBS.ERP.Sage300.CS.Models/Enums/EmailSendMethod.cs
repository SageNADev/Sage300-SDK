﻿// Copyright (c) 2022 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    public enum EmailSendMethod
    {
        /// <summary>
        /// Gets or sets Basic Authentication SMTP
        /// </summary>
        [EnumValue("BasicAuthentication", typeof(CompanyProfileResx))]
        BasicAuthentication = 0,

        /// <summary>
        /// Gets or sets Microsoft Graph 
        /// </summary>	
        [EnumValue("MicrosoftGraph", typeof(CompanyProfileResx))]
        MicrosoftGraph = 1
    }
}
