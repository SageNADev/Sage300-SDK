﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for SyncStatus
    /// </summary>
    public enum SyncStatus
    {
        /// <summary>
        /// Gets or sets NotSynced
        /// </summary>
        NotSynced = 0,

        /// <summary>
        /// Gets or sets Synced
        /// </summary>
        Synced = 1,

        /// <summary>
        /// Gets or sets UploadPending
        /// </summary>
        UploadPending = 2,

        /// <summary>
        /// Gets or sets UpdatePending
        /// </summary>
        UpdatePending = 3,

        /// <summary>
        /// Gets or sets DeletePending
        /// </summary>
        DeletePending = 4
    }
}

