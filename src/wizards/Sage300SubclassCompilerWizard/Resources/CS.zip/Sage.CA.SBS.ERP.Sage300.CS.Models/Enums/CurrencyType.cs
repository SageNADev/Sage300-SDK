﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum TypeOfCurrency
    /// </summary>
    public enum CurrencyType
    {
        /// <summary>
        /// The Source Currency
        /// </summary>
        [EnumValue("SourceCurrency", typeof(TaxTrackingReportResx))]
        SourceCurrency = 0,

        /// <summary>
        /// The Functional Currency
        /// </summary>
        [EnumValue("FunctionalCurrency", typeof(CommonResx))]
        FunctionalCurrency= 1,

        /// <summary>
        /// The Tax Reporting Currency
        /// </summary>
        [EnumValue("TaxReportingCurrency", typeof(TaxTrackingReportResx))]
        TaxReportingCurrency = 2,
    }
}
