// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// PeriodStatus Enum
    /// </summary>
    public enum PeriodStatus
    {
        /// <summary>
        /// Unlocked
        /// </summary>
        [EnumValue("Unlocked", typeof(FiscalCalendarResx))]
        Unlocked = 1,

        /// <summary>
        /// Locked
        /// </summary>
        [EnumValue("Locked", typeof(FiscalCalendarResx))]
        Locked = 0
    }
}