
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for Operation 
    /// </summary>
	public enum OperationType 
	{
		/// <summary>
		/// Gets or sets None 
		/// </summary>	
        //[EnumValue("None", typeof(ReconcileOFXStatementResx))]
        None = 0,
		/// <summary>
		/// Gets or sets MatchBank 
		/// </summary>	
        MatchBank = 1,
		/// <summary>
		/// Gets or sets MatchAllTransactions 
		/// </summary>	
        MatchAllTransactions = 2,
		/// <summary>
		/// Gets or sets ClearAllMatchedTransactions 
		/// </summary>	
        ClearAllMatchedTransactions = 3,
		/// <summary>
		/// Gets or sets ClearaTransaction 
		/// </summary>	
        ClearaTransaction = 4,
		/// <summary>
		/// Gets or sets RemoveAllMatchedTransactions 
		/// </summary>	
        RemoveAllMatchedTransactions = 5,
		/// <summary>
		/// Gets or sets RemoveaTransaction 
		/// </summary>	
        RemoveaTransaction = 6,
	}
}
