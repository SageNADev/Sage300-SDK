﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum ThousandsSeparator
    /// </summary>
    public enum ThousandsSeparator
    {
        /// <summary>
        /// The period
        /// </summary>        
        [StoredAsChar]
        [EnumValue("ThousandsSeparator_Period", typeof (EnumerationsResx), 1)] Period = '.',

        /// <summary>
        /// The comma
        /// </summary> 
        [StoredAsChar]
        [EnumValue("ThousandsSeparator_Comma", typeof(EnumerationsResx), 2)]
        Comma = ',',

        /// <summary>
        /// The space
        /// </summary>
        [StoredAsChar]
        [EnumValue("ThousandsSeparator_Space", typeof(EnumerationsResx), 3)]
        Space = ' '
    }
}