 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for DetailTransactionType 
    /// </summary>
	public enum DetailTransactionType 
	{
			/// <summary>
		/// Gets or sets Check 
		/// </summary>	
        Check = 1,
		/// <summary>
		/// Gets or sets EFT 
		/// </summary>	
        EFT = 2,
		/// <summary>
		/// Gets or sets Transfer 
		/// </summary>	
        Transfer = 3,
		/// <summary>
		/// Gets or sets ServiceCharge 
		/// </summary>	
        ServiceCharge = 4,
		/// <summary>
		/// Gets or sets CreditCard 
		/// </summary>	
        CreditCard = 5,
		/// <summary>
		/// Gets or sets Cash 
		/// </summary>	
        Cash = 6,
		/// <summary>
		/// Gets or sets Other 
		/// </summary>	
        Other = 7,
	}
}
