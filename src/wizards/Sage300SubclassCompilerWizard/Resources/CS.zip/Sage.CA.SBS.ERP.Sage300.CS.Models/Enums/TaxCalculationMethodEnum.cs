
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// This class for Tax Calculation Method enum values
    /// </summary>
    public enum TaxCalculationMethodEnum
    {
        /// <summary>
        /// Calculate tax by summary
        /// </summary>
        [EnumValue("Calculatetaxbysummary", typeof(TaxGroupsResx))]
        Calculatetaxbysummary = 1,

        /// <summary>
        /// Calculate tax by detail
        /// </summary>
        [EnumValue("Calculatetaxbydetail", typeof(TaxGroupsResx))]
        Calculatetaxbydetail = 2,
    }
}
