﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    public enum DocumentType
    {
        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("RECEIPTS", typeof(TransactionHistoryInquiryResx))]
        Receipts =2,

        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("PAYMENTS", typeof(TransactionHistoryInquiryResx))]
        Payments = 1,

    }
}
