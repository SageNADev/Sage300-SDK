//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
	/// Enum for ReverseTransactionType 
	/// </summary>
	public enum ReverseTransactionType 
	{

        /// <summary>
        /// Gets or sets AccountsPayable 
        /// </summary>	
        [EnumValue("Payments", typeof(ReverseTransactionsResx))]
        Payments = 1,

        /// <summary>
        /// Gets or sets AccountsReceivable 
        /// </summary>	
        [EnumValue("Receipts", typeof(ReverseTransactionsResx))]
        Receipts = 2

	}
}
