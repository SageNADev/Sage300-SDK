﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum GLAccountType
    {
        /// <summary>
        /// DefaultGLAccount
        /// </summary>
        DefaultGLAccount = 1,

        /// <summary>
        /// TransferAdjGLAccount
        /// </summary>
        TransferAdjGLAccount = 2,
    }
}