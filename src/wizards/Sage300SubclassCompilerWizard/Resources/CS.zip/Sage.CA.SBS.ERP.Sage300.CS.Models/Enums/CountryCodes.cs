﻿// Copyright (c) 2020 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for CountryCodes
    /// Note: The translations are coming from the Presentation List of
    /// <see cref="CompanyProfile.Fields.PaymentsAcceptanceCountry"/>
    /// It needs to be the same with the list in cscom1.c
    /// </summary>
    public enum CountryCodes
    {
        /// <summary>
        /// Gets or sets None
        /// </summary>
        None = 0,

        /// <summary>
        /// Gets or sets Australia
        /// </summary>
        Australia = 1,

        /// <summary>
        /// Gets or sets Bahrain
        /// </summary>
        Bahrain = 2,

        /// <summary>
        /// Gets or sets Botswana
        /// </summary>
        Botswana = 3,

        /// <summary>
        /// Gets or sets Canada
        /// </summary>
        Canada = 4,

        /// <summary>
        /// Gets or sets CaymanIslands
        /// </summary>
        CaymanIslands = 5,

        /// <summary>
        /// Gets or sets China
        /// </summary>
        China = 6,

        /// <summary>
        /// Gets or sets Colombia
        /// </summary>
        Colombia = 7,

        /// <summary>
        /// Gets or sets CostaRica
        /// </summary>
        CostaRica = 8,

        /// <summary>
        /// Gets or sets DominicanRepublic
        /// </summary>
        DominicanRepublic = 9,

        /// <summary>
        /// Gets or sets ElSalvador
        /// </summary>
        ElSalvador = 10,

        /// <summary>
        /// Gets or sets GuadeloupeAnddependencies
        /// </summary>
        GuadeloupeAnddependencies = 11,

        /// <summary>
        /// Gets or sets Guatemala
        /// </summary>
        Guatemala = 12,

        /// <summary>
        /// Gets or sets Honduras
        /// </summary>
        Honduras = 13,

        /// <summary>
        /// Gets or sets HongKong
        /// </summary>
        HongKong = 14,

        /// <summary>
        /// Gets or sets India
        /// </summary>
        India = 15,

        /// <summary>
        /// Gets or sets Indonesia
        /// </summary>
        Indonesia = 16,

        /// <summary>
        /// Gets or sets Jamaica
        /// </summary>
        Jamaica = 17,

        /// <summary>
        /// Gets or sets Jordan
        /// </summary>
        Jordan = 18,

        /// <summary>
        /// Gets or sets Kenya
        /// </summary>
        Kenya = 19,

        /// <summary>
        /// Gets or sets Kuwait
        /// </summary>
        Kuwait = 20,

        /// <summary>
        /// Gets or sets Malaysia
        /// </summary>
        Malaysia = 21,

        /// <summary>
        /// Gets or sets Martinique
        /// </summary>
        Martinique = 22,

        /// <summary>
        /// Gets or sets Mauritius
        /// </summary>
        Mauritius = 23,

        /// <summary>
        /// Gets or sets Mexico
        /// </summary>
        Mexico = 24,

        /// <summary>
        /// Gets or sets Mozambique
        /// </summary>
        Mozambique = 25,

        /// <summary>
        /// Gets or sets NewZealand
        /// </summary>
        NewZealand = 26,

        /// <summary>
        /// Gets or sets Nicaragua
        /// </summary>
        Nicaragua = 27,

        /// <summary>
        /// Gets or sets Oman
        /// </summary>
        Oman = 28,

        /// <summary>
        /// Gets or sets Panama
        /// </summary>
        Panama = 29,

        /// <summary>
        /// Gets or sets Philippines
        /// </summary>
        Philippines = 30,

        /// <summary>
        /// Gets or sets Qatar
        /// </summary>
        Qatar = 31,

        /// <summary>
        /// Gets or sets SaudiArabia
        /// </summary>
        SaudiArabia = 32,

        /// <summary>
        /// Gets or sets Senegal
        /// </summary>
        Senegal = 33,

        /// <summary>
        /// Gets or sets Singapore
        /// </summary>
        Singapore = 34,

        /// <summary>
        /// Gets or sets SouthAfrica
        /// </summary>
        SouthAfrica = 35,

        /// <summary>
        /// Gets or sets SouthKorea
        /// </summary>
        SouthKorea = 36,

        /// <summary>
        /// Gets or sets Thailand
        /// </summary>
        Thailand = 37,

        /// <summary>
        /// Gets or sets TheBahamas
        /// </summary>
        TheBahamas = 38,

        /// <summary>
        /// Gets or sets UAE
        /// </summary>
        UAE = 39,

        /// <summary>
        /// Gets or sets UnitedStatesOfAmerica
        /// </summary>
        UnitedStatesOfAmerica = 40
    }
}
