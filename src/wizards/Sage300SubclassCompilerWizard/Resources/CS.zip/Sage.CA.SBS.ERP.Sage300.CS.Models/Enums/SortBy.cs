﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum SortBy
    /// </summary>
    public enum SortBy
    {
        /// <summary>
        /// Payment Number
        /// </summary>
        [EnumValue("PaymentNumber", typeof(EnumerationsResx))]
        PaymentNumber = 0,

        /// <summary>
        /// Payment Date
        /// </summary>
        [EnumValue("PaymentDate", typeof(EnumerationsResx))]
        PaymentDate = 1,

        /// <summary>
        /// Vendor or Payee Code
        /// </summary>
        [EnumValue("VendorOrPayeeCode", typeof(EnumerationsResx))]
        VendorPayeeCode = 2
    }
}
