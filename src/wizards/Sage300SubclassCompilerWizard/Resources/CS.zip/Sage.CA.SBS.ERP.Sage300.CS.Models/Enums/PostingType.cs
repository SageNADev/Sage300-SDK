﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for PostingType 
    /// </summary>
    public enum PostingType
    {
        /// <summary>
        /// Gets or sets Reconciliation 
        /// </summary>
        [EnumValue("Reconcile", typeof(BKCommonResx))]
        Reconciliation = 1,
        /// <summary>
        /// Gets or sets Transfer 
        /// </summary>	
        [EnumValue("Transfer", typeof(BKCommonResx))]
        Transfer = 2,
        /// <summary>
        /// Gets or sets BankEntries 
        /// </summary>	
        [EnumValue("BankDocumentType_Entry", typeof(EnumerationsResx))]
        BankEntries = 3,
    }
}