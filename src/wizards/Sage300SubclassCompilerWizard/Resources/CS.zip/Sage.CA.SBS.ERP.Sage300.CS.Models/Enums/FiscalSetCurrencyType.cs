/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetCurrencyType
    /// </summary>
    public enum FiscalSetCurrencyType
    {
        /// <summary>
        /// The source
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Source", typeof(EnumerationsResx))]
        Source = 0,

        /// <summary>
        /// The equivalent
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Equivalent", typeof(EnumerationsResx))]
        Equivalent = 1,

        /// <summary>
        /// The functional
        /// </summary>
        [StoredAsChar(true)]
        [EnumValue("Functional", typeof(EnumerationsResx))]
        Functional = 2,

        /// <summary>
        /// The reporting
        /// </summary>
        [EnumValue("Reporting", typeof(EnumerationsResx))]
        Reporting = 3
    }
}