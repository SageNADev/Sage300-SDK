// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using EnumerationsResx = Sage.CA.SBS.ERP.Sage300.CS.Resources.EnumerationsResx;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Consolidate GL Batches 
    /// </summary>
    public enum ConsolidateGLBatches
    {
        /// <summary>
        /// Gets or sets DoNotConsolidate 
        /// </summary>	
        [EnumValue("DoNotConsolidate", typeof (GLIntegrationResx),1)] 
        DoNotConsolidate = 1,

        /// <summary>
        /// Gets or sets ConsolidatebyAccountandFiscalPeriod 
        /// </summary>
        [EnumValue("ConsolidateByAccFisc", typeof (EnumerationsResx),2)] 
        ConsolidatebyAccountandFiscalPeriod = 3,

        /// <summary>
        /// Gets or sets ConsolidatebyAccount,FiscalPeriod,andSource 
        /// </summary>
        [EnumValue("ConsolidateByAccFiscSource", typeof (EnumerationsResx),3)] 
        ConsolidatebyAccountFiscalPeriodandSource = 2,
    }
}