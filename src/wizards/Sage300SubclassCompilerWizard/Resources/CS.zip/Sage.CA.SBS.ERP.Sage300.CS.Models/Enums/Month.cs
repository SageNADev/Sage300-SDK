// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Month
    /// </summary>
    public enum Month
    {
        /// <summary>
        /// The january
        /// </summary>
        [EnumValue("Month_January", typeof (EnumerationsResx))] January = 1,

        /// <summary>
        /// The february
        /// </summary>
        [EnumValue("Month_February", typeof (EnumerationsResx))] February = 2,

        /// <summary>
        /// The march
        /// </summary>
        [EnumValue("Month_March", typeof (EnumerationsResx))] March = 3,

        /// <summary>
        /// The april
        /// </summary>
        [EnumValue("Month_April", typeof (EnumerationsResx))] April = 4,

        /// <summary>
        /// The may
        /// </summary>
        [EnumValue("Month_May", typeof (EnumerationsResx))] May = 5,

        /// <summary>
        /// The june
        /// </summary>
        [EnumValue("Month_June", typeof (EnumerationsResx))] June = 6,

        /// <summary>
        /// The july
        /// </summary>
        [EnumValue("Month_July", typeof (EnumerationsResx))] July = 7,

        /// <summary>
        /// The august
        /// </summary>
        [EnumValue("Month_August", typeof (EnumerationsResx))] August = 8,

        /// <summary>
        /// The september
        /// </summary>
        [EnumValue("Month_September", typeof (EnumerationsResx))] September = 9,

        /// <summary>
        /// The october
        /// </summary>
        [EnumValue("Month_October", typeof (EnumerationsResx))] October = 10,

        /// <summary>
        /// The november
        /// </summary>
        [EnumValue("Month_November", typeof (EnumerationsResx))] November = 11,

        /// <summary>
        /// The december
        /// </summary>
        [EnumValue("Month_December", typeof (EnumerationsResx))] December = 12,
    }
}