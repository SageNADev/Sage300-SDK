// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for TaxBase 
    /// </summary>
    public enum TaxBase
    {
        /// <summary>
        /// Gets or sets Sellingprice 
        /// </summary>	
        [EnumValue("Sellingprice", typeof(EnumerationsResx))]
        Sellingprice = 1,

        /// <summary>
        /// Gets or sets Standardcost 
        /// </summary>	
        [EnumValue("Standardcost", typeof(EnumerationsResx))]
        Standardcost = 2,

        /// <summary>
        /// Gets or sets Mostrecentcost 
        /// </summary>	
        [EnumValue("Mostrecentcost", typeof(EnumerationsResx))]
        Mostrecentcost = 3,

        /// <summary>
        /// Gets or sets Alternateamount1 
        /// </summary>	
        [EnumValue("Alternateamount1", typeof(EnumerationsResx))]
        Alternateamount1 = 4,

        /// <summary>
        /// Gets or sets Alternateamount2 
        /// </summary>	
        [EnumValue("Alternateamount2", typeof(EnumerationsResx))]
        Alternateamount2 = 5,
    }
}