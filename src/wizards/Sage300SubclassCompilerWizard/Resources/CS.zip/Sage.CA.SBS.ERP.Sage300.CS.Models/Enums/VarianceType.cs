//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for VarianceType 
    /// </summary>
	public enum VarianceType
    {
        #region enums

        /// <summary>
		/// Gets or sets None 
		/// </summary>	
        [EnumValue("FiscalPeriodNone", typeof(EnumerationsResx))]
        None = 0,

        /// <summary>
        /// Gets or sets Outstandingamount 
        /// </summary>	
        [EnumValue("OutstdAmt", typeof(BKCommonResx))]
        Outstandingamount = 1,

        /// <summary>
        /// Gets or sets Amounttowriteoff 
        /// </summary>	
        [EnumValue("Amounttowriteoff", typeof(EnumerationsResx))]
        Amounttowriteoff = 2,

        /// <summary>
        /// Gets or sets Bankerror 
        /// </summary>	
        [EnumValue("Bankerror", typeof(EnumerationsResx))]
        Bankerror = 3,

        /// <summary>
        /// Gets or sets Exchangeratedifference 
        /// </summary>	
        [EnumValue("Exchangeratedifference", typeof(EnumerationsResx))]
        Exchangeratedifference = 4,

        /// <summary>
        /// Gets or sets Creditcardcharge 
        /// </summary>	
        [EnumValue("LblRecpcccCap", typeof(BKCommonResx))]
        Creditcardcharge = 5,

        #endregion
    }
}
