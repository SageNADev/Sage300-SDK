// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum WeekinMonth
    /// </summary>
    public enum WeekinMonth
    {
        /// <summary>
        /// The first
        /// </summary>
        [EnumValue("WeekinMonth_First", typeof (EnumerationsResx))] First = 1,

        /// <summary>
        /// The second
        /// </summary>
        [EnumValue("WeekinMonth_Second", typeof (EnumerationsResx))] Second = 2,

        /// <summary>
        /// The third
        /// </summary>
        [EnumValue("WeekinMonth_Third", typeof (EnumerationsResx))] Third = 3,

        /// <summary>
        /// The fourth
        /// </summary>
        [EnumValue("WeekinMonth_Fourth", typeof (EnumerationsResx))] Fourth = 4,

        /// <summary>
        /// The last
        /// </summary>
        [EnumValue("WeekinMonth_Last", typeof (EnumerationsResx))] Last = 99,
    }
}