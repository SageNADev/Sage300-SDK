// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region NameSpace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Status 
    /// </summary>
    public enum BankEntryStatus
    {
        /// <summary>
        /// Gets or sets Notposted 
        /// </summary>	
        [EnumValue("NotPosted", typeof(BKCommonResx))]
        Notposted = 0,

        /// <summary>
        /// Gets or sets Posted 
        /// </summary>	
        [EnumValue("Posted", typeof(CommonResx))]
        Posted = 1,

        /// <summary>
        /// Gets or sets Reversed 
        /// </summary>	
        [EnumValue("Reverse", typeof(BKCommonResx))]
        Reversed = 2,

        /// <summary>
        /// Gets or sets Cleared 
        /// </summary>	
        [EnumValue("Cleared", typeof(BKCommonResx))]
        Cleared = 3,
    }
}
