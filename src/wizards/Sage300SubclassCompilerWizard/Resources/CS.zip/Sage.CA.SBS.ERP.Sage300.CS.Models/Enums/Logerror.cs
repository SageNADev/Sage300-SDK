// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Logerror 
    /// </summary>
    public enum Logerror
    {
        /// <summary>
        /// Gets or sets Dontlogresult 
        /// </summary>	
        Dontlogresult = 1,

        /// <summary>
        /// Gets or sets Logresulttofile 
        /// </summary>	
        Logresulttofile = 0
    }
}