﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    public enum SelectDocumentType
    {
        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("DEPOSITS", typeof(TransactionHistoryInquiryResx))]
        Deposits = 2,

        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("WITHDRAWALS", typeof(TransactionHistoryInquiryResx))]
        Withdrawals = 1,

    }
}
