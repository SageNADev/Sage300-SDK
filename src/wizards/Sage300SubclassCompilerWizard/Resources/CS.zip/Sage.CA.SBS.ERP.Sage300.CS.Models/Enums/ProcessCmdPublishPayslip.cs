﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    public enum ProcessCmdPublishPayslip
    {
        /// <summary>
        /// Gets or sets SelectDeselectAll
        /// </summary>
        [EnumValue("SelectDeselectAll", typeof(PayslipDayResx))]
        SelectDeselectAll = 0,
        /// <summary>
        /// Gets or sets PublishSelectedImmediately
        /// </summary>
        [EnumValue("PublishSelectedImmediately", typeof(PayslipDayResx))]
        PublishSelectedImmediately = 1,
        /// <summary>
        /// Gets or sets PublishSelectedOnCheckDate
        /// </summary>
        [EnumValue("PublishSelectedOnCheckDate", typeof(PayslipDayResx))]
        PublishSelectedOnCheckDate = 2
    }
}
