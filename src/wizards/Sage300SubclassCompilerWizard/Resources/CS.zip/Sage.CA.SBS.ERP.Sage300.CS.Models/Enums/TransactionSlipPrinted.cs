
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for TransactionSlipPrinted 
    /// </summary>
	public enum TransactionSlipPrinted 
	{
			/// <summary>
		/// Gets or sets No 
		/// </summary>	
        [EnumValue("SundayCall_No", typeof(EnumerationsResx))]
        No = 0,
		/// <summary>
		/// Gets or sets Yes 
		/// </summary>	
        [EnumValue("SundayCall_Yes", typeof(EnumerationsResx))]
        Yes = 1,
	}
}
