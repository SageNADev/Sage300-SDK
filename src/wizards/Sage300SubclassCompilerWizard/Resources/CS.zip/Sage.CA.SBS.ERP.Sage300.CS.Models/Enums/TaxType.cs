// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for TaxType 
    /// </summary>
    public enum TaxType
    {
        /// <summary>
        /// Gets or sets FederalTax 
        /// </summary>	
        [EnumValue("FederalTax", typeof(CommonResx))]
        FederalTax = 10,
        /// <summary>
        /// Gets or sets StateTax 
        /// </summary>	
       [EnumValue("StateTax", typeof(CommonResx))]
        StateTax = 20,
        /// <summary>
        /// Gets or sets CountyTax 
        /// </summary>	
        [EnumValue("CountyTax", typeof(CommonResx))]
        CountyTax = 30,
        /// <summary>
        /// Gets or sets CityTax 
        /// </summary>	
        [EnumValue("CityTax", typeof(CommonResx))]
        CityTax = 40,
        /// <summary>
        /// Gets or sets Other 
        /// </summary>	
        [EnumValue("Other", typeof(CommonResx))]
        Other = 0,
        /// <summary>
        /// Gets or sets GST 
        /// </summary>	
        [EnumValue("GST", typeof(CommonResx))]
        GST = 60,
        /// <summary>
        /// Gets or sets PST 
        /// </summary>	
        [EnumValue("PST", typeof(CommonResx))]
        PST = 70,
        /// <summary>
        /// Gets or sets HST 
        /// </summary>	
        [EnumValue("HST", typeof(CommonResx))]
        HST = 80,

        /// <summary>
        /// Gets or sets VAT 
        /// </summary>	
        [EnumValue("VAT", typeof(CommonResx))]
        VAT = 90,
    }
}