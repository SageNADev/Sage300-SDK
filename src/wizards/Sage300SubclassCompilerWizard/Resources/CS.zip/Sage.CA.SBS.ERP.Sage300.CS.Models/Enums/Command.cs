// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Command.
    /// </summary>
    public enum Command
    {
        /// <summary>
        /// Gets or sets Nocommand.
        /// </summary>	
        [EnumValue("Nocommand", typeof(FiscalCalendarResx))]
        Nocommand = 0,

        /// <summary>
        /// Gets or sets GetApplication.
        /// </summary>	
        [EnumValue("GetApplication", typeof(FiscalCalendarResx))]
        GetApplication = 1,

        /// <summary>
        /// Gets or sets SetDirty.
        /// </summary>	
        [EnumValue("SetDirty", typeof(FiscalCalendarResx))]
        SetDirty = 2
    }
}