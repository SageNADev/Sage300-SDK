﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for CreateGorLBatches 
    /// </summary>
    public enum CreateGorLBatches
    {
        /// <summary>
        /// Gets or sets DuringPosting 
        /// </summary>	
        [EnumValue("DuringPosting", typeof(EnumerationsResx))]
        DuringPosting = 0,
        /// <summary>
        /// Gets or sets OnRequestUsingCreateGOrLBatchIcon 
        /// </summary>	
       [EnumValue("OnRequestUsingCreateGLBatchIcon", typeof(EnumerationsResx))]
        OnRequestUsingCreateGOrLBatchIcon = 1,
    }
}