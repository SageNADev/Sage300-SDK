// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ReconcileList 
    /// </summary>
    public enum ReconcileList
    {
        /// <summary>
        /// Gets or sets BankServicesBalance 
        /// </summary>	
        BankServicesBalance = 0,

        /// <summary>
        /// Gets or sets GeneralLedgerBalance 
        /// </summary>	
        GeneralLedgerBalance = 1,
    }
}