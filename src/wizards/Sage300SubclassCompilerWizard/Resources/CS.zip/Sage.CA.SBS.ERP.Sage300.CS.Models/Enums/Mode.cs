
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Mode 
    /// </summary>
    public enum Mode
    {
        /// <summary>
        /// Gets or sets Withdrawal 
        /// </summary>	
        Withdrawal = 1,
        /// <summary>
        /// Gets or sets Deposit 
        /// </summary>	
        Deposit = 2,
    }
}
