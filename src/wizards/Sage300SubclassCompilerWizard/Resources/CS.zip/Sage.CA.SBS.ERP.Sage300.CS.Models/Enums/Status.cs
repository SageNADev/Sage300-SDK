// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Status 
    /// </summary>
    public enum Status
    {
        /// <summary>
        /// Gets or sets Active 
        /// </summary>	
        [EnumValue("Status_Active", typeof (CSCommonResx))] Active = 0,

        /// <summary>
        /// Gets or sets Inactive 
        /// </summary>
        [EnumValue("Status_Inactive", typeof (CSCommonResx))] Inactive = 1,
    }
}