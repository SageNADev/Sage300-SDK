 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for Command 
    /// </summary>
	public enum CurrencyRateCommand 
	{
			/// <summary>
		/// Gets or sets PropagateDateRange 
        /// </summary>	
        [EnumValue("PropagateDateRange", typeof(CurrencyRatesResx))]
        PropagateDateRange = 0,
	}
}
