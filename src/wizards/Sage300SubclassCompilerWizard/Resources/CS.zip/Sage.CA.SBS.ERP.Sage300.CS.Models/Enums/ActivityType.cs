﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Active Type 
    /// </summary>
    public enum ActiveType
    {
        /// <summary>
        /// Gets or sets Inactive 
        /// </summary>
        [EnumValue("Inactive", typeof(FiscalCalendarResx))]
        Inactive = 0,

        /// <summary>
        /// Gets or sets Active 
        /// </summary>	
        [EnumValue("Active", typeof(FiscalCalendarResx))]
        Active = 1
    }
}