
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for ReconciliationSuggestion 
    /// </summary>
	public enum ReconciliationSuggestion 
	{
		/// <summary>
		/// Gets or sets NotPosted 
		/// </summary>	
        [EnumValue("NotPosted", typeof(BankReconcileStatementResx))]
        NotPosted = 1,
		/// <summary>
		/// Gets or sets Void 
		/// </summary>	
        [EnumValue("Void", typeof(BankReconcileStatementResx))]
        Void = 2,
		/// <summary>
		/// Gets or sets Outstanding 
		/// </summary>	
        [EnumValue("Outstanding", typeof(BankReconcileStatementResx))]
        Outstanding = 3,
		/// <summary>
		/// Gets or sets Reversed 
		/// </summary>	
        [EnumValue("Reversed", typeof(EnumerationsResx))]
        Reversed = 4,
		/// <summary>
		/// Gets or sets Cleared 
		/// </summary>	
        [EnumValue("Cleared", typeof(BankReconcileStatementResx))]
        Cleared = 5,
		/// <summary>
		/// Gets or sets Clearedwithbankerror 
		/// </summary>	
        [EnumValue("Clearedwithbankerror", typeof(BankReconcileStatementResx))]
        Clearedwithbankerror = 6,
		/// <summary>
		/// Gets or sets Nonnegotiable 
		/// </summary>	
        [EnumValue("Nonnegotiable", typeof(BankReconcileStatementResx))]
        Nonnegotiable = 7,
		/// <summary>
		/// Gets or sets Continuation 
		/// </summary>	
        [EnumValue("Continuation", typeof(BankReconcileStatementResx))]
        Continuation = 8,
		/// <summary>
		/// Gets or sets Printed 
		/// </summary>	
        [EnumValue("Printed", typeof(BankReconcileStatementResx))]
        Printed = 9,
		/// <summary>
		/// Gets or sets Clearedwithwriteoff 
		/// </summary>	
        [EnumValue("Clearedwithwriteoff", typeof(BankReconcileStatementResx))]
        Clearedwithwriteoff = 10,
		/// <summary>
		/// Gets or sets Clearedwithexchangeratedifference 
		/// </summary>	
        [EnumValue("Clearedwithexchangeratedifference", typeof(BankReconcileStatementResx))]
        Clearedwithexchangeratedifference = 11,
		/// <summary>
		/// Gets or sets Clearedwithcreditcardcharge 
		/// </summary>	
        [EnumValue("Clearedwithcreditcardcharge", typeof(BankReconcileStatementResx))]
        Clearedwithcreditcardcharge = 12,

        /// <summary>
        /// Gets or sets ReconcileByDepositDetail
        /// </summary>
        [EnumValue("ReconcileByDepositDetail", typeof(BankReconcileStatementResx))]
        ReconcileByDepositDetail = 14 
	}
}
