﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for RateOperator 
    /// </summary>
    public enum RateOperator
    {
        /// <summary>
        /// Gets or sets Not Specified
        /// </summary>	
        NotSpecified = 0,

        /// <summary>
        /// Gets or sets Multiply 
        /// </summary>	
        Multiply = 1,

        /// <summary>
        /// Gets or sets Divide 
        /// </summary>	
        Divide = 2,
    }
}