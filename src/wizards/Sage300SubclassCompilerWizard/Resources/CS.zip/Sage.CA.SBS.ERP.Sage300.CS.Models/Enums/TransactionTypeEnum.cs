
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// This Class used for drop down in Tax Group
    /// </summary>
	public enum TransactionTypeEnum 
	{
        /// <summary>
        /// Sales
        /// </summary>
        [EnumValue("Sales", typeof(TaxRatesResx))]
		Sales = 1,

        /// <summary>
        /// Purchases
        /// </summary>
        [EnumValue("Purchases", typeof(TaxRatesResx))]
        Purchases = 2,
	}
}
