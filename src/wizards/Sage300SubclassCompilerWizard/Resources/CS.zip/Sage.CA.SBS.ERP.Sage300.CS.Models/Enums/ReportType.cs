﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ReportType 
    /// </summary>
    /// 
    public enum ReportType
    {
        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("ReporttypeReport", typeof(TransactionListingReportResx), 1)]
        Report = 1,

        /// <summary>
        /// Work Sheet
        /// </summary>
        [EnumValue("ReporttypeWorksheet", typeof(TransactionListingReportResx), 2)]
        WorkSheet = 2,
    }
}

