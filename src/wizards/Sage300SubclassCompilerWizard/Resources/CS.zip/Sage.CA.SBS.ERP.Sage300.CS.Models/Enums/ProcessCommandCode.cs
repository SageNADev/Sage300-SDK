// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode
    /// </summary>
    public enum ProcessCommandCode
    {
        /// <summary>
        /// Gets or sets SumDetails 
        /// </summary>	
        [EnumValue("SumDetails", typeof(EnumerationsResx))]
        SumDetails = 0,
        /// <summary>
        /// Gets or sets ApplyDetailsCleared 
        /// </summary>	
        [EnumValue("ApplyDetailsCleared", typeof(EnumerationsResx))]
        ApplyDetailsCleared = 1,
        /// <summary>
        /// Gets or sets ApplyDetailsOutstanding 
        /// </summary>	
        [EnumValue("ApplyDetailsOutstanding", typeof(EnumerationsResx))]
        ApplyDetailsOutstanding = 2,
    }
}