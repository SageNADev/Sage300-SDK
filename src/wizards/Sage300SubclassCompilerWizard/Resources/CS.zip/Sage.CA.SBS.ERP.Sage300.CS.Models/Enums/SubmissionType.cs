﻿
// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for SubmissionType 
    /// </summary>
    public enum SubmissionType
    {
        #region enums

        /// <summary>
        /// Gets or sets Userentered 
        /// </summary>	
        [EnumValue("UserEntered", typeof(EnumerationsResx))]
        Userentered = 0,

        /// <summary>
        /// Gets or sets UnmatchedOFX 
        /// </summary>	
        [EnumValue("UnmatchedOFX", typeof(EnumerationsResx))]
        UnmatchedOFX = 10,

        /// <summary>
        /// Gets or sets UnmatchedOFXcorrection 
        /// </summary>	
        [EnumValue("UnmatchedOFXCorrection", typeof(EnumerationsResx))]
        UnmatchedOFXcorrection = 19,

        /// <summary>
        /// Gets or sets UnmatchedOFXerror 
        /// </summary>	
        [EnumValue("UnmatchedOFXError", typeof(EnumerationsResx))]
        UnmatchedOFXerror = 20,

        #endregion
    }
}