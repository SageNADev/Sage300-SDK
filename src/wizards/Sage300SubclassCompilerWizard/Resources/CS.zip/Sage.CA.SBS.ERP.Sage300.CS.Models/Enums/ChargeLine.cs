﻿
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ChargeLine 
    /// </summary>
    public enum ChargeLine
    {
        /// <summary>
        /// Gets or sets OriginatingBank 
        /// </summary>	
        OriginatingBank = 0,
        /// <summary>
        /// Gets or sets DestinationBank 
        /// </summary>	
        DestinationBank = 1,
    }
}
