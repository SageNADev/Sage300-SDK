﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommandCode
    /// </summary>
    public enum ProcessCommandCodeEmployee
    {
        /// <summary>
        /// Gets or sets UnsyncSelectedFromSageHR
        /// </summary>
        UnsyncSelectedFromSageHR = 0,

        /// <summary>
        /// Gets or sets PurgeSelectedFromSageHR
        /// </summary>
        PurgeSelectedFromSageHR = 1,

        /// <summary>
        /// Gets or sets VerifySelection
        /// </summary>
        VerifySelection = 2
    }
}
