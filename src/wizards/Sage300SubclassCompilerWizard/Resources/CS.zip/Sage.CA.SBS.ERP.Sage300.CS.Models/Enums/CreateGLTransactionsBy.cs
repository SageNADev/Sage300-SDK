// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for CreateGLTransactionsBy 
    /// </summary>
    public enum CreateGLTransactionsBy
    {
        /// <summary>
        /// Gets or sets AddingtoanExistingBatch 
        /// </summary>	
        AddingtoanExistingBatch = 1,

        /// <summary>
        /// Gets or sets CreatingaNewBatch 
        /// </summary>	
        CreatingaNewBatch = 0,

        /// <summary>
        /// Gets or sets CreatingandPostingaNewBatch 
        /// </summary>	
        CreatingandPostingaNewBatch = 2,
    }
}