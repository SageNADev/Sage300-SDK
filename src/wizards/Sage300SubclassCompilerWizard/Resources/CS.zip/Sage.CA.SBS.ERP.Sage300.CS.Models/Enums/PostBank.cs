﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Post Bank
    /// </summary>
    public enum PostBank
    {
        /// <summary>
        /// Enum value for Post All Bank
        /// </summary>
        AllBank = 0,

        /// <summary>
        /// Enum value for Post By Range
        /// </summary>
        ByRange = 1
    }
}
