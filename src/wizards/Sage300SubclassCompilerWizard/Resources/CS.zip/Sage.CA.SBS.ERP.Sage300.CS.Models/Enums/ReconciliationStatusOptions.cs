﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    public enum ReconciliationStatusOptions
    {
        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("ALL", typeof(TransactionHistoryInquiryResx))]
        All = 0,

        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("RECONCILED", typeof(TransactionHistoryInquiryResx))]
        Reconciled = 1,

        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("OUTSTANDING", typeof(TransactionHistoryInquiryResx))]
        Outstanding = 2,
    }
}
