// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for DataCheck 
    /// </summary>
    public enum DataCheck
    {
        /// <summary>
        /// Gets or sets DontCheck 
        /// </summary>	
        [EnumValue("DataCheck_DontCheck", typeof(EnumerationsResx))]
        DontCheck = 0,

        /// <summary>
        /// Gets or sets Check 
        /// </summary>
        [EnumValue("DataCheck_Check", typeof(EnumerationsResx))]
        Check = 1,

        /// <summary>
        /// Gets or sets Fix 
        /// </summary>	
        [EnumValue("DataCheck_Fix", typeof(EnumerationsResx))]
        Fix = 2
    }
}