// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Weekday
    /// </summary>
    public enum Weekday
    {
        /// <summary>
        /// The sunday
        /// </summary>
        [EnumValue("Weekday_Sunday", typeof (EnumerationsResx))] Sunday = 1,

        /// <summary>
        /// The monday
        /// </summary>
        [EnumValue("Weekday_Monday", typeof (EnumerationsResx))] Monday = 2,

        /// <summary>
        /// The tuesday
        /// </summary>
        [EnumValue("Weekday_Tuesday", typeof (EnumerationsResx))] Tuesday = 3,

        /// <summary>
        /// The wednesday
        /// </summary>
        [EnumValue("Weekday_Wednesday", typeof (EnumerationsResx))] Wednesday = 4,

        /// <summary>
        /// The thursday
        /// </summary>
        [EnumValue("Weekday_Thursday", typeof (EnumerationsResx))] Thursday = 5,

        /// <summary>
        /// The friday
        /// </summary>
        [EnumValue("Weekday_Friday", typeof (EnumerationsResx))] Friday = 6,

        /// <summary>
        /// The saturday
        /// </summary>
        [EnumValue("Weekday_Saturday", typeof (EnumerationsResx))] Saturday = 7,
    }
}