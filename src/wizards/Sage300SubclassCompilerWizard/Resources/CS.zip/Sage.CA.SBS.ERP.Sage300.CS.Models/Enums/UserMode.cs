// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum UserMode
    /// </summary>
    public enum UserMode
    {
        /// <summary>
        /// The no users
        /// </summary>
        [EnumValue("UserMode_NoUsers", typeof (EnumerationsResx))] NoUsers = 1,

        /// <summary>
        /// The specific user
        /// </summary>
        [EnumValue("UserMode_SpecificUser", typeof (EnumerationsResx))] SpecificUser = 2,

        /// <summary>
        /// All users
        /// </summary>
        [EnumValue("UserMode_AllUsers", typeof (EnumerationsResx))] AllUsers = 3,
    }
}