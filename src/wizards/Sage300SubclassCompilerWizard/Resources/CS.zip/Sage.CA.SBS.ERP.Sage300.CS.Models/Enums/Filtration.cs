// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Filtration
    /// </summary>
    public enum Filtration
    {
        /// <summary>
        /// The due personal schedules
        /// </summary>
        [EnumValue("Filtration_DuePersonalSchedules", typeof (EnumerationsResx))] DuePersonalSchedules = 17,

        /// <summary>
        /// The due assigned schedules
        /// </summary>
        [EnumValue("Filtration_DueAssignedSchedules", typeof (EnumerationsResx))] DueAssignedSchedules = 25,

        /// <summary>
        /// All personal schedules
        /// </summary>
        [EnumValue("Filtration_AllPersonalSchedules", typeof (EnumerationsResx))] AllPersonalSchedules = 18,

        /// <summary>
        /// All assigned schedules
        /// </summary>
        [EnumValue("Filtration_AllAssignedSchedules", typeof (EnumerationsResx))] AllAssignedSchedules = 26,
    }
}