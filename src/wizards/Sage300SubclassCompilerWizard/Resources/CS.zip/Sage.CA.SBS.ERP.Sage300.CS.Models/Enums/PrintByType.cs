﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum PrintByType
    /// </summary>
    public enum PrintByType
    {
        /// <summary>
        /// The Tax Authority
        /// </summary>
        [EnumValue("TxAuthRecType", typeof(TaxClassesResx))]
        TaxAuthority = 0,

        /// <summary>
        /// The Item Tax Class
        /// </summary>
        [EnumValue("ItemTaxClss", typeof(BKCommonResx))]
        ItemTaxClass = 1,
    }
}
