/* Copyright (c) 1994-2018 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for WithholdingTaxBase
    /// </summary>
    public enum WithholdingTaxBase
    {
        /// <summary>
        /// Gets or sets SellingPrice
        /// </summary>
        [EnumValue("SellingPrice", typeof(WithholdingTaxRateResx))]
        SellingPrice = 1,
        /// <summary>
        /// Gets or sets TaxAmount
        /// </summary>
        [EnumValue("TaxAmount", typeof(WithholdingTaxRateResx))]
        TaxAmount = 2
    }
}