// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum Frequency
    /// </summary>
    public enum Frequency
    {
        /// <summary>
        /// The weekdays
        /// </summary>
        [EnumValue("Frequency_Weekdays", typeof (EnumerationsResx))] Weekdays = 1,

        /// <summary>
        /// The weekly
        /// </summary>
        [EnumValue("Frequency_Weekly", typeof (EnumerationsResx))] Weekly = 2,

        /// <summary>
        /// The firstand date
        /// </summary>
        [EnumValue("Frequency_FirstandDate", typeof (EnumerationsResx))] FirstandDate = 3,

        /// <summary>
        /// The dateand last
        /// </summary>
        [EnumValue("Frequency_DateandLast", typeof (EnumerationsResx))] DateandLast = 4,

        /// <summary>
        /// The every
        /// </summary>
        [EnumValue("Frequency_Every", typeof (EnumerationsResx))] Every = 5,
    }
}