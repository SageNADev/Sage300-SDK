 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for Banks 
    /// </summary>
	public enum Banks 
	{
			/// <summary>
		/// Gets or sets BANK 
		/// </summary>	
        BANK = 0,
	}
}
