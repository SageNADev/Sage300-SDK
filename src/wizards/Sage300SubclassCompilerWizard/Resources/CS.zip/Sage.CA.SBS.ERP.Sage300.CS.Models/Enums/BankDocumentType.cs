﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Type of documents
    /// </summary>
    public enum BankDocumentType
    {
        /// <summary>
        /// Bank Entry
        /// </summary>
        [EnumValue("BankDocumentType_Entry", typeof (EnumerationsResx), 0)] BankEntry = 0,

        /// <summary>
        /// Bank Transfer
        /// </summary>
        [EnumValue("BankDocumentType_Transfer", typeof (EnumerationsResx), 1)] BankTransfer = 1,
    }
}