// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for SourceTransactionType 
    /// </summary>
	public enum SourceTransactionType 
	{
		/// <summary>
		/// Gets or sets Transfers 
		/// </summary>
        [EnumValue("Transfers", typeof(EnumerationsResx), 1)]	
        Transfers = 1,
		/// <summary>
		/// Gets or sets BankEntry 
		/// </summary>	
        [EnumValue("BankEntry", typeof(EnumerationsResx), 2)]	
        BankEntry = 2,
		/// <summary>
		/// Gets or sets BankEntryDetail 
		/// </summary>	
        [EnumValue("BankEntryDetail", typeof(EnumerationsResx), 3)]	
        BankEntryDetail = 3,
		/// <summary>
		/// Gets or sets BankReconciliation 
		/// </summary>	
        [EnumValue("BankReconciliation", typeof(EnumerationsResx), 4)]	
        BankReconciliation = 4,
	}
}
