﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for FromItemClass 
    /// </summary>
    public enum FromItemClass
    {
        /// <summary>
        /// Gets or sets Num1 
        /// </summary>	
        [EnumValue("Num1", typeof(EnumerationsResx))]
        Num1 = 1,

        /// <summary>
        /// Gets or sets Num2 
        /// </summary>	
        [EnumValue("Num2", typeof(EnumerationsResx))]
        Num2 = 2,

        /// <summary>
        /// Gets or sets Num3 
        /// </summary>	
        [EnumValue("Num3", typeof(EnumerationsResx))]
        Num3 = 3,

        /// <summary>
        /// Gets or sets Num4 
        /// </summary>	
        [EnumValue("Num4", typeof(EnumerationsResx))]
        Num4 = 4,

        /// <summary>
        /// Gets or sets Num5 
        /// </summary>	
        [EnumValue("Num5", typeof(EnumerationsResx))]
        Num5 = 5,

        /// <summary>
        /// Gets or sets Num6 
        /// </summary>	
        [EnumValue("Num6", typeof(EnumerationsResx))]
        Num6 = 6,

        /// <summary>
        /// Gets or sets Num7 
        /// </summary>	
        [EnumValue("Num7", typeof(EnumerationsResx))]
        Num7 = 7,

        /// <summary>
        /// Gets or sets Num8 
        /// </summary>
        [EnumValue("Num8", typeof(EnumerationsResx))]
        Num8 = 8,

        /// <summary>
        /// Gets or sets Num9 
        /// </summary>	
        [EnumValue("Num9", typeof(EnumerationsResx))]
        Num9 = 9,

        /// <summary>
        /// Gets or sets Num10 
        /// </summary>	
        [EnumValue("Num10", typeof(EnumerationsResx))]
        Num10 = 10,
    }
}
