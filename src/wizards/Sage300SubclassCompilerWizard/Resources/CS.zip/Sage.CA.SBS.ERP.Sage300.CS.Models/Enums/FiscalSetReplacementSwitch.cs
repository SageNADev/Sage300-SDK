/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum FiscalSetReplacementSwitch
    /// </summary>
    public enum FiscalSetReplacementSwitch
    {
        /// <summary>
        /// The income statement
        /// </summary>
        [EnumValue("IncomeStatement", typeof(EnumerationsResx))]
        IncomeStatement = 0,

        /// <summary>
        /// The balance sheet
        /// </summary>
        [EnumValue("BalanceSheet", typeof(EnumerationsResx))]
        BalanceSheet = 1,
    }
}