
/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for CalculateFiscalPeriodData 
    /// </summary>
	
    public enum CalculateFiscalPeriodData
    {
        /// <summary>
        /// Gets or sets Fiscalbalancesareuptodate 
        /// </summary>	
        [EnumValue("Fiscalbalancesareuptodate", typeof(BKCommonResx))]
        Fiscalbalancesareuptodate = 0,

        /// <summary>
        /// Gets or sets Fiscalbalancesneedtoberecalculated 
        /// </summary>
         [EnumValue("Fiscalbalancesneedtoberecalculated", typeof(BKCommonResx))]	
        Fiscalbalancesneedtoberecalculated = 1,
    }
}
