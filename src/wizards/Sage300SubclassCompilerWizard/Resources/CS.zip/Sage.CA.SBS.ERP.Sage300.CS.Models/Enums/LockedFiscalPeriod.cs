﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// LockedFiscalPeriod
    /// </summary>
    public enum LockedFiscalPeriod
    {
        /// <summary>
        /// FiscalPeriodNone
        /// </summary>
        [EnumValue("FiscalPeriodNone", typeof (EnumerationsResx))] None = 0,

        /// <summary>
        /// FiscalPeriodWarning
        /// </summary>
        [EnumValue("FiscalPeriodWarning", typeof (EnumerationsResx))] Warning = 1,

        /// <summary>
        /// FiscalPeriodError
        /// </summary>
        [EnumValue("FiscalPeriodError", typeof (EnumerationsResx))] Error = 2
    }
}