 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for ReconciledBy 
    /// </summary>
	public enum ReconciledBy 
	{
			/// <summary>
		/// Gets or sets ReconciledbyHeader 
		/// </summary>	
        ReconciledbyHeader = 0,
		/// <summary>
		/// Gets or sets ReconciledbyDetail 
		/// </summary>	
        ReconciledbyDetail = 1,
	}
}
