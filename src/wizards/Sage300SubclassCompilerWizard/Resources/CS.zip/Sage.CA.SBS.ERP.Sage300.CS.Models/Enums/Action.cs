// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
     /// <summary>
     /// Enum for Action
     /// </summary>
     public enum Action
     {
          /// <summary>
          /// Gets or sets GenerateCreateVaultRequestXML
          /// </summary>
          GenerateCreateVaultRequestXML = 1,
          /// <summary>
          /// Gets or sets ParseCreateVaultResponseXML
          /// </summary>
          ParseCreateVaultResponseXML = 2,
          /// <summary>
          /// Gets or sets GenerateSALES_WITH_UIRequestXML
          /// </summary>
          GenerateSALES_WITH_UIRequestXML = 3,
          /// <summary>
          /// Gets or sets ParseSALES_WITH_UIResponseXML
          /// </summary>
          ParseSALES_WITH_UIResponseXML = 4,
          /// <summary>
          /// Gets or sets GenerateAUTHORIZATION_WITH_UIRequestXML
          /// </summary>
          GenerateAUTHORIZATION_WITH_UIRequestXML = 5,
          /// <summary>
          /// Gets or sets ParseAUTHORIZATION_WITH_UIResponseXML
          /// </summary>
          ParseAUTHORIZATION_WITH_UIResponseXML = 6,
          /// <summary>
          /// Gets or sets GenerateVOID_WITHOUT_UIRequestXML
          /// </summary>
          GenerateVOID_WITHOUT_UIRequestXML = 7,
          /// <summary>
          /// Gets or sets ParseVOID_WITHOUT_UIResponseXML
          /// </summary>
          ParseVOID_WITHOUT_UIResponseXML = 8,
          /// <summary>
          /// Gets or sets GenerateCAPTURE_WITH_UIRequestXML
          /// </summary>
          GenerateCAPTURE_WITH_UIRequestXML = 9,
          /// <summary>
          /// Gets or sets ParseCAPTURE_WITH_UIResponseXML
          /// </summary>
          ParseCAPTURE_WITH_UIResponseXML = 10,
          /// <summary>
          /// Gets or sets GenerateCREDIT_WITH_UIRequestXML
          /// </summary>
          GenerateCREDIT_WITH_UIRequestXML = 11,
          /// <summary>
          /// Gets or sets ParseCREDIT_WITH_UIResponseXML
          /// </summary>
          ParseCREDIT_WITH_UIResponseXML = 12,
          /// <summary>
          /// Gets or sets GenerateTRANSACTION_STATUS_QUERYRequestXML
          /// </summary>
          GenerateTRANSACTION_STATUS_QUERYRequestXML = 13,
          /// <summary>
          /// Gets or sets ParseTRANSACTION_STATUS_QUERYResponseXML
          /// </summary>
          ParseTRANSACTION_STATUS_QUERYResponseXML = 14,
          /// <summary>
          /// Gets or sets GenerateCREDIT_WITHOUT_UIRequestXML
          /// </summary>
          GenerateCREDIT_WITHOUT_UIRequestXML = 15,
          /// <summary>
          /// Gets or sets ParseCREDIT_WITHOUT_UIResponseXML
          /// </summary>
          ParseCREDIT_WITHOUT_UIResponseXML = 16,
          /// <summary>
          /// Gets or sets GenerateCAPTURE_WITHOUT_UIRequestXML
          /// </summary>
          GenerateCAPTURE_WITHOUT_UIRequestXML = 17,
          /// <summary>
          /// Gets or sets ParseCAPTURE_WITHOUT_UIResponseXML
          /// </summary>
          ParseCAPTURE_WITHOUT_UIResponseXML = 18,
          /// <summary>
          /// Gets or sets GenerateACCOUNTQUERYRequestXML
          /// </summary>
          GenerateACCOUNTQUERYRequestXML = 19,
          /// <summary>
          /// Gets or sets ParseACCOUNTQUERYResponseXML
          /// </summary>
          ParseACCOUNTQUERYResponseXML = 20,
          /// <summary>
          /// Gets or sets GenerateFORCE_WITHOUT_UIRequestXML
          /// </summary>
          GenerateFORCE_WITHOUT_UIRequestXML = 21,
          /// <summary>
          /// Gets or sets ParseFORCE_WITHOUT_UIResponseXML
          /// </summary>
          ParseFORCE_WITHOUT_UIResponseXML = 22,
          /// <summary>
          /// Gets or sets GenerateFORCE_WITH_UIRequestXML
          /// </summary>
          GenerateFORCE_WITH_UIRequestXML = 23,
          /// <summary>
          /// Gets or sets ParseFORCE_WITH_UIResponseXML
          /// </summary>
          ParseFORCE_WITH_UIResponseXML = 24,
     }
}
