﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// GainOrLossAccountingMethod
    /// </summary>
    public enum GainOrLossAccountingMethod
    {
        /// <summary>
        /// RealizedandUnrealizedGainOrLoss
        /// </summary>
        [EnumValue("RealizedandUnrealizedGainOrLoss", typeof (EnumerationsResx))] RealizedandUnrealizedGainOrLoss = 1,

        /// <summary>
        /// RecognizedGainOrLoss
        /// </summary>
        [EnumValue("RecognizedGainOrLoss", typeof (EnumerationsResx))] RecognizedGainOrLoss = 2
    }
}