
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Language 
    /// </summary>
    public enum Language
    {
        /// <summary>
        /// Gets or sets English 
        /// </summary>	
        [EnumValue("Language_Eng", typeof(EnumerationsResx))]
        English = 5658,
        /// <summary>
        /// Gets or sets French 
        /// </summary>	
        [EnumValue("Language_French", typeof(EnumerationsResx))]
        French = 7092,
        /// <summary>
        /// Gets or sets Spanish 
        /// </summary>	
        [EnumValue("Language_Spanish", typeof(EnumerationsResx))]
        Spanish = 5845,
        /// <summary>
        /// Gets or sets ChineseSimplified 
        /// </summary>	
        [EnumValue("Language_ChnSimple", typeof(EnumerationsResx))]
        ChineseSimplified = 2857,
        /// <summary>
        /// Gets or sets ChineseTraditional 
        /// </summary>	
        [EnumValue("Language_ChnTrad", typeof(EnumerationsResx))]
        ChineseTraditional = 2863,
        /// <summary>
        /// Gets or sets Australian 
        /// </summary>	
        [EnumValue("Language_Australian", typeof(EnumerationsResx))]
        Australian = 738,
        /// <summary>
        /// Gets or sets Australian 
        /// </summary>	
        [EnumValue("Language_Mexican", typeof(EnumerationsResx))]
        Mexican = 15719,

    }
}
