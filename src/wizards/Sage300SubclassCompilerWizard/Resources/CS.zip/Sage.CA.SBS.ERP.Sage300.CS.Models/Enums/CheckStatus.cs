/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for CheckStatus 
    /// </summary>
	public enum CheckStatus 
	{
			/// <summary>
		/// Gets or sets NotPrinted 
		/// </summary>	
        [EnumValue("CheckStatus_NotPrinted", typeof(EnumerationsResx))]
        NotPrinted = -2,
		/// <summary>
		/// Gets or sets AdviceNotPrinted 
		/// </summary>	
        [EnumValue("CheckStatus_AdviceNotPrinted", typeof(EnumerationsResx))]
        AdviceNotPrinted = -1,
		/// <summary>
		/// Gets or sets Printed 
		/// </summary>	
        [EnumValue("Printed", typeof(Common.Resources.CommonResx))]
        Printed = 9,
		/// <summary>
		/// Gets or sets Posted 
		/// </summary>	
        [EnumValue("Posted", typeof(Common.Resources.CommonResx))]
        Posted = 999,
	}
}
