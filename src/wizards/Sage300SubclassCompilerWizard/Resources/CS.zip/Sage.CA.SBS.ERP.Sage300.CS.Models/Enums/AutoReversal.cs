// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for AutoReversal 
    /// </summary>
    public enum AutoReversal
    {
        /// <summary>
        /// Gets or sets AutoReversalOff 
        /// </summary>	
        AutoReversalOff = 0,

        /// <summary>
        /// Gets or sets AutoReversalOn 
        /// </summary>	
        AutoReversalOn = 1,
    }
}