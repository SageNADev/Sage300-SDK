﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for OptionalField Type
    /// </summary>
    public enum OptionalFieldType
    {
        /// <summary>
        /// The text
        /// </summary>
        [EnumValue("OptionalFieldTypeText", typeof (EnumerationsResx),1)] Text = 1,

        /// <summary>
        /// The amount
        /// </summary>
        [EnumValue("OptionalFieldTypeAmount", typeof (EnumerationsResx),2)] Amount = 100,

        /// <summary>
        /// The number
        /// </summary>
        [EnumValue("OptionalFieldTypeNumber", typeof (EnumerationsResx),3)] Number = 6,

        /// <summary>
        /// The integer
        /// </summary>
        [EnumValue("OptionalFieldTypeInteger", typeof (EnumerationsResx),4)] Integer = 8,

        /// <summary>
        /// The yes no
        /// </summary>
        [EnumValue("OptionalFieldTypeYesNo", typeof (EnumerationsResx),5)] YesNo = 9,

        /// <summary>
        /// The date
        /// </summary>
        [EnumValue("OptionalFieldTypeDate", typeof (EnumerationsResx),6)] Date = 3,

        /// <summary>
        /// The time
        /// </summary>
        [EnumValue("OptionalFieldTypeTime", typeof (EnumerationsResx),7)] Time = 4
    }
}