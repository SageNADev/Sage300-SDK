﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Status
    /// </summary>
    public enum SyncEmployeeStatus
    {
        /// <summary>
        /// Gets or sets Active
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        Active = 1,

        /// <summary>
        /// Gets or sets Inactive
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        Inactive = 2,

        /// <summary>
        /// Gets or sets Terminated
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        Terminated = 3,

        /// <summary>
        /// Gets or sets InactiveROEPending
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        InactiveROEPending = 4,

        /// <summary>
        /// Gets or sets TerminatedROEPending
        /// </summary>
        [EnumValue("Generated", typeof(CommonResx))]
        TerminatedROEPending = 5
    }
}
