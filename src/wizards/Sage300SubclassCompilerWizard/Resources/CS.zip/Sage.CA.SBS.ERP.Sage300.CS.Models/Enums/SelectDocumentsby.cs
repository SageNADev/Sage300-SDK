 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for SelectDocumentsby 
    /// </summary>
	public enum SelectDocumentsby 
	{
			/// <summary>
		/// Gets or sets DueDate 
		/// </summary>	
        DueDate = 0,
		/// <summary>
		/// Gets or sets DiscountDate 
		/// </summary>	
        DiscountDate = 1,
		/// <summary>
		/// Gets or sets DueDateorDiscountDate 
		/// </summary>	
        DueDateorDiscountDate = 2,
	}
}
