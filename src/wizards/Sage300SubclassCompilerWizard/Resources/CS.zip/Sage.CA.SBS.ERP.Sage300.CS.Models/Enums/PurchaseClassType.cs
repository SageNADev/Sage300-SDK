﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ClassType of Purchase transactiontype
    /// </summary>
    public enum PurchaseClassType
    {
        /// <summary>
        /// Gets or sets Vendors 
        /// </summary>	
        [EnumValue("TxVendors", typeof(TaxClassesResx))]
        Vendors = 1,
        /// <summary>
        /// Gets or sets Items 
        /// </summary>	
        [EnumValue("TxItems", typeof(TaxClassesResx))]
        Items = 2,
    }
}
