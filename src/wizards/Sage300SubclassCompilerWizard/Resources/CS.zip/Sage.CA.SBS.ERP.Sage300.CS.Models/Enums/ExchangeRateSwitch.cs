// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ExchangeRateSwitch 
    /// </summary>
    public enum ExchangeRateSwitch
    {
        /// <summary>
        /// Gets or sets Userecurringentryrate 
        /// </summary>	
        Userecurringentryrate = 0,

        /// <summary>
        /// Gets or sets Usecurrentrate 
        /// </summary>	
        Usecurrentrate = 1,
    }
}