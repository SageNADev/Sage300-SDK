// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ProcessCommand 
    /// </summary>
    public enum ProcessCommand
    {
        /// <summary>
        /// Gets or sets CreateDistribution 
        /// </summary>	
        CreateDistribution = 0,
    }
}
