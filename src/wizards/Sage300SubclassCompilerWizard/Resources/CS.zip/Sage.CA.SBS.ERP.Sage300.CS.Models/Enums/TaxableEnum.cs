
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// 
    /// </summary>
    public enum TaxableEnum
    {

        /// <summary>
        /// The no
        /// </summary>
        [EnumValue("No", typeof(CommonResx))]
        No = 0,

        /// <summary>
        /// The yes
        /// </summary>
        [EnumValue("Yes", typeof(CommonResx))]
        Yes = 1,
    }
}
