// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
     /// <summary>
     /// Enum for TaxInclude4
     /// </summary>
     public enum TaxInclude4
     {
          /// <summary>
          /// Gets or sets No
          /// </summary>
          No = 0,
          /// <summary>
          /// Gets or sets Yes
          /// </summary>
          Yes = 1,
     }
}
