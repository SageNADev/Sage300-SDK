﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum SymbolPosition
    /// </summary>
    public enum SymbolPosition
    {
        /// <summary>
        /// The beforewithspace
        /// </summary>
        [EnumValue("SymbolPosition_Beforewithspace", typeof (EnumerationsResx), 0)] Beforewithspace = 1,

        /// <summary>
        /// The beforewithoutspace
        /// </summary>
        [EnumValue("SymbolPosition_Beforewithoutspace", typeof (EnumerationsResx),1)] Beforewithoutspace = 2,

        /// <summary>
        /// The afterwithspace
        /// </summary>
        [EnumValue("SymbolPosition_Afterwithspace", typeof (EnumerationsResx),2)] Afterwithspace = 3,

        /// <summary>
        /// The afterwithoutspace
        /// </summary>
        [EnumValue("SymbolPosition_Afterwithoutspace", typeof (EnumerationsResx),3)] Afterwithoutspace = 4,
    }
}