// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for CheckPDFUploadStatus
    /// </summary>
    public enum CheckPDFUploadStatus
    {
        /// <summary>
        /// Gets or sets NotPublished
        /// </summary>
        [EnumValue("NotPublished", typeof(PayslipResx))]
        NotPublished = 0,
        /// <summary>
        /// Gets or sets Publishing
        /// </summary>
        [EnumValue("Publishing", typeof(PayslipResx))]
        Publishing = 1,
        /// <summary>
        /// Gets or sets Published
        /// </summary>
        [EnumValue("Published", typeof(PayslipResx))]
        Published = 2
    }
}