// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
     /// <summary>
     /// Enum for SourceRateOperator
     /// </summary>
     public enum SourceRateOperator
     {
          /// <summary>
          /// Gets or sets Multiply
          /// </summary>
          Multiply = 1,
          /// <summary>
          /// Gets or sets Divide
          /// </summary>
          Divide = 2,
     }
}
    