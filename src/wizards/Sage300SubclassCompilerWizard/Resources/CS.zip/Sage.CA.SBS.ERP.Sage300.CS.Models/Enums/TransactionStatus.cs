 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for TransactionStatus 
    /// </summary>
	public enum TransactionStatus 
	{
			/// <summary>
		/// Gets or sets Notposted 
		/// </summary>	
        [EnumValue("NotPosted", typeof(BKCommonResx))]
        Notposted = 1,
		/// <summary>
		/// Gets or sets PartiallyOutstanding 
		/// </summary>	
        [EnumValue("PartiallyOutstanding", typeof(EnumerationsResx))]
        PartiallyOutstanding = 2,
		/// <summary>
		/// Gets or sets Outstanding 
		/// </summary>	
        [EnumValue("Outstanding", typeof(BKCommonResx))]
        Outstanding = 3,
		/// <summary>
		/// Gets or sets PartiallyReconciled 
		/// </summary>	
        [EnumValue("PartiallyReconciled", typeof(EnumerationsResx))]
        PartiallyReconciled = 4,
		/// <summary>
		/// Gets or sets Reconciled 
		/// </summary>	
        [EnumValue("ReconciledFLD", typeof(BKCommonResx))]
        Reconciled = 5,
		/// <summary>
		/// Gets or sets PendingJournal 
		/// </summary>	
        [EnumValue("PendingJournal", typeof(EnumerationsResx))]
        PendingJournal = 6,
		/// <summary>
		/// Gets or sets Posted 
		/// </summary>	
        [EnumValue("Posted", typeof(EnumerationsResx))]
        Posted = 7,
		/// <summary>
		/// Gets or sets Purged 
		/// </summary>	
        [EnumValue("Purged", typeof(EnumerationsResx))]
        Purged = 8,
	}
}
