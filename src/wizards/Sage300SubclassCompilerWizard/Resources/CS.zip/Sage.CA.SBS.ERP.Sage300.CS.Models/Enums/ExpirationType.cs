// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ExpirationType 
    /// </summary>
    public enum ExpirationType
    {
        /// <summary>
        /// Gets or sets NoExpirationDate 
        /// </summary>	
        NoExpirationDate = 0,

        /// <summary>
        /// Gets or sets SpecificDate 
        /// </summary>	
        SpecificDate = 1,
    }
}