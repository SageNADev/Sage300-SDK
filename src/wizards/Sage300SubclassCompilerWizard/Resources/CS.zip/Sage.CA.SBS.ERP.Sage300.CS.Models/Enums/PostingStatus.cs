﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for PostingStatus 
    /// </summary>
    public enum PostingStatus
    {
        /// <summary>
        /// Gets or sets Posting 
        /// </summary>	
         [EnumValue("Posting", typeof(CommonResx))]
        Posting = 1,
        /// <summary>
        /// Gets or sets Pendingprint 
        /// </summary>	
         [EnumValue("Pendingprint", typeof(BKCommonResx))]
        Pendingprint = 2,
        /// <summary>
        /// Gets or sets Printed 
        /// </summary>	
         [EnumValue("Printed", typeof(BKCommonResx))]
        Printed = 3,
        /// <summary>
        /// Gets or sets Pendingpurge 
        /// </summary>	
         [EnumValue("Pendingpurge", typeof(BKCommonResx))]
        Pendingpurge = 5,
        /// <summary>
        /// Gets or sets Purging 
        /// </summary>	
         [EnumValue("Purging", typeof(BKCommonResx))]
        Purging = 4,
    }
}