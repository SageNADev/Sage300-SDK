// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
     /// <summary>
     /// Enum for ResponseIslogged
     /// </summary>
     public enum ResponseIslogged
     {
          /// <summary>
          /// Gets or sets False
          /// </summary>
          False = 1,
          /// <summary>
          /// Gets or sets True
          /// </summary>
          True = 0,
     }
}
