 
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
	/// <summary>
    /// Enum for ModeofOperation 
    /// </summary>
	public enum ModeofOperation 
	{
			/// <summary>
		/// Gets or sets Selectlanguagemode 
		/// </summary>	
        Selectlanguagemode = 0,
		/// <summary>
		/// Gets or sets Byanylanguage 
		/// </summary>	
        Byanylanguage = 1,
		/// <summary>
		/// Gets or sets Byeachlanguage 
		/// </summary>	
        Byeachlanguage = 2,
	}
}
