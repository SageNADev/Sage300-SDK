﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;


namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    public enum PublishPayslipOption
    {
        /// <summary>
        /// Gets or sets Automatically During Posting 
        /// </summary>
        [EnumValue("AutomaticallyPosting", typeof(SageHRResx))]
        AutomaticallyPosting = 0,

        /// <summary>
        /// Gets or sets Automatically on Check Date 
        /// </summary>
        [EnumValue("AutomaticallyCheckDate", typeof(SageHRResx))]
        AutomaticallyCheckDate = 1,

        /// <summary>
        /// Gets or sets Automatically on Check Date 
        /// </summary>
        [EnumValue("Manually", typeof(SageHRResx))]
        Manually = 2,
    }
}
