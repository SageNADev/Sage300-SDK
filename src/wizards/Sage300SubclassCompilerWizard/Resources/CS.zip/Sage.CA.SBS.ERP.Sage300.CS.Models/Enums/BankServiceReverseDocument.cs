﻿//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{

    /// <summary>
    /// Enum for BsReverseDocument 
    /// </summary>
    public enum BankServiceReverseDocument
    {
        /// <summary>
        /// Gets or sets AccountsPayable 
        /// </summary>	
        [EnumValue("Withdrawals", typeof(ReverseTransactionsResx))]
        Withdrawals = 1,

        /// <summary>
        /// Gets or sets AccountsReceivable 
        /// </summary>	
        [EnumValue("Deposits", typeof(ReverseTransactionsResx))]
        Deposits = 2

        

    }
}
