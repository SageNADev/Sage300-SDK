﻿ /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for SourceApplicationType 
    /// </summary>
    public enum SourceApplicationType
    {
        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("ACCOUNTSPAYABLE", typeof(TransactionHistoryInquiryResx))]
        AccountsPayable = 0,

        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("ACCOUNTSRECEIVABLE", typeof(TransactionHistoryInquiryResx))]
        AccountsReceivable = 1,

        /// <summary>
        /// Report
        /// </summary>
        [EnumValue("BANKSERVICES", typeof(TransactionHistoryInquiryResx))]
        BankServices = 3,

    }
}
