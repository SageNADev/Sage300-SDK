﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for DistributionCode
    /// </summary>
    public enum DistributionCodedetails
    {
        /// <summary>
        /// Gets or sets DistributionCodeNotFound 
        /// </summary>
        DistributionCodeNotFound = 2,

        /// <summary>
        /// Gets or sets DistributionCodeInactive
        /// </summary>
        DistributionCodeInactive = 1,

        /// <summary>
        ///Gets or sets DistributionCode not found 
        /// </summary>
        DistributionCodeFound = 0,
        /// <summary>
        ///Gets or sets Inactive GL Account
        /// </summary>
       DCInactiveGLAccount=3,

    }
}
