﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region references

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for Reconciliation Transaction Type
    /// </summary>
    public enum ReconciliationTransactionType
    {
        /// <summary>
        /// Gets or sets All 
        /// </summary>	
        [EnumValue("All", typeof(CommonResx))]
        All = 0,

        /// <summary>
        /// Gets or sets Withdrawal
        /// </summary>	
        [EnumValue("Withdrawals", typeof(BKCommonResx))]
        Withdrawal = 1,

        /// <summary>
        /// Gets or sets Deposit
        /// </summary>	
        [EnumValue("Deposit", typeof(BKCommonResx))]
        Deposit = 2,
    }

}
