// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum for ReportLevel 
    /// </summary>
	public enum ReportLevel 
	{
			/// <summary>
		/// Gets or sets Atinvoicelevel 
		/// </summary>
        [EnumValue("Atinvoicelevel", typeof(EnumerationsResx))]	
        Atinvoicelevel = 0,
		/// <summary>
		/// Gets or sets Noreporting 
		/// </summary>	
        [EnumValue("Noreporting", typeof(EnumerationsResx))]
        Noreporting = 1,
	}
}