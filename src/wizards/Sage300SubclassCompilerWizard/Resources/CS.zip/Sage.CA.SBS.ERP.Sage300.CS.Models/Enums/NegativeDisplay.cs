﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Enums
{
    /// <summary>
    /// Enum NegativeDisplay
    /// </summary>
    public enum NegativeDisplay
    {
        /// <summary>
        /// The trailing
        /// </summary>
        [EnumValue("NegativeDisplay_Trailing", typeof (EnumerationsResx))] Trailing = 1,

        /// <summary>
        /// The leading
        /// </summary>
        [EnumValue("NegativeDisplay_Leading", typeof (EnumerationsResx))] Leading = 2,

        /// <summary>
        /// The brackets
        /// </summary>
        [EnumValue("NegativeDisplay_Brackets", typeof (EnumerationsResx))] Brackets = 3,
    }
}