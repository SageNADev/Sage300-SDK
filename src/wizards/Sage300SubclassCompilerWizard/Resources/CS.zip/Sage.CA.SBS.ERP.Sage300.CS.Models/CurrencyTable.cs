// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    ///  CurrencyTable Model
    /// </summary>
    public partial class CurrencyTable : ModelBase
    {
        /// <summary>
        /// Gets or sets ToCurrency 
        /// </summary>
        [Display(Name = "HOMECUR", ResourceType = typeof(CurrencyRatesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.ToCurrency, Id = Index.ToCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ToCurrency { get; set; }

        /// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [Display(Name = "PFPFromRTCap", ResourceType = typeof(CurrencyRatesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string RateType { get; set; }

        /// <summary>
        /// Gets or sets TableDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyTableDesc", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.TableDescription, Id = Index.TableDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TableDescription { get; set; }

        /// <summary>
        /// Gets or sets DateMatching 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DateMatch", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.DateMatching, Id = Index.DateMatching, FieldType = EntityFieldType.Int, Size = 2)]
        public DateMatching DateMatching { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateOperation", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets SourceofRates 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateSource", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.SourceofRates, Id = Index.SourceofRates, FieldType = EntityFieldType.Char, Size = 60)]
        public string SourceofRates { get; set; }

        /// <summary>
        /// Gets or sets PropagateChangesImmediately 
        /// </summary>
        [Display(Name = "PropagateChangesImmediately", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.PropagateChangesImmediately, Id = Index.PropagateChangesImmediately, FieldType = EntityFieldType.Bool, Size = 2)]
        public PropagateChangesImmediately PropagateChangesImmediately { get; set; }

        /// <summary>
        /// Gets or sets Command 
        /// </summary>
        [Display(Name = "Command", ResourceType = typeof(CurrencyRatesResx))]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public CurrencyRateCommand Command { get; set; }

        /// <summary>
        /// Gets or sets FromDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        public DateTime FromDate
        {
            get { return DateUtil.GetMinDate(); }
        }

        /// <summary>
        /// Gets or sets ToDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        public DateTime ToDate
        {
            get { return DateUtil.GetMinDate(); }

        }

        /// <summary>
        /// Gets or sets CurrencyRateDetails.
        /// </summary>
        public EnumerableResponse<CurrencyRate> CurrencyRateDetails { get; set; }

        /// <summary>
        /// Gets the DateMatchingstring.
        /// </summary>
        /// <value>The DateMatchingstring.</value>
        public string DateMatchingstring
        {
            get { return EnumUtility.GetStringValue(DateMatching); }
        }

        /// <summary>
        /// Gets the RateOperationstring.
        /// </summary>
        /// <value>The RateOperationstring.</value>
        public string RateOperationstring
        {
            get { return EnumUtility.GetStringValue(RateOperation); }
        }

        /// <summary>
        /// Gets the PropagateChangesImmediately.
        /// </summary>
        public string PropagateChangesImmediatelystring
        {
            get { return EnumUtility.GetStringValue(PropagateChangesImmediately); }
        }
    }
}
