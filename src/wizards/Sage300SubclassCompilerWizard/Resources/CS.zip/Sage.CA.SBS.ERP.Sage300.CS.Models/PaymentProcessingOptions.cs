﻿using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Model class for Payment Processing Option BV.
    /// </summary>
    public partial class PaymentProcessingOptions
        : ModelBase
    {
  		/// <summary>
        /// Gets or sets DummyKey
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        public int Id {get; set;}
		 
  		/// <summary>
        /// Gets or sets Phone 
        /// </summary>
        [Display(Name = "Phone", ResourceType = typeof(CommonResx))]
 		public string Phone {get; set;}
		 
  		/// <summary>
        /// Gets or sets Fax 
        /// </summary>
        [Display(Name = "Fax", ResourceType = typeof(CommonResx))]
        public string Fax { get; set; }
		 
  		/// <summary>
        /// Gets or sets ContactName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ContactName", ResourceType = typeof(CommonResx))]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets Requireinvoicingatshipping 
        /// </summary>
        public RequireInvoicingAtShipping RequireInvoicingAtShipping { get; set; }

        /// <summary>
        /// Gets or sets WarnBeforeForcingExpiredPre 
        /// </summary>
        public WarnBeforeForcingExpiredPreAuthorizations WarnBeforeForcingExpiredPreAuthorizations { get; set; }

        /// <summary>
        /// Gets or sets TermsDiscOnAutomaticPayment 
        /// </summary>
        public TermsDiscOnAutomaticPayment TermsDiscOnAutomaticPayment { get; set; }
    }
}
