// /* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class BankDistributionCode : ModelBase
    {
        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [Display(Name = "DistributionCode", ResourceType = typeof (BankDistributionCodesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [Display(Name = "DistributionCodeDesc", ResourceType = typeof (BankDistributionCodesResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets GLAccount 
        /// </summary>
        [Display(Name = "GenLedgerAcct", ResourceType = typeof (BankDistributionCodesResx))]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.GLAccount, Id = Index.GLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GLAccount { get; set; }

        /// <summary>
        /// Gets or sets GLAccount 
        /// </summary>
        [Display(Name = "GenLedgerAcctDesc", ResourceType = typeof (BankDistributionCodesResx))]
        [StringLength(100, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string GLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof (CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets Status 
        /// </summary>
        [Display(Name = "Status", ResourceType = typeof(CSCommonResx))]
        [ViewField(Name = Fields.Status, Id = Index.Status, FieldType = EntityFieldType.Bool, Size = 2)]
        public Status Status { get; set; }

        /// <summary>
        /// Gets or sets InactiveDate 
        /// </summary>
        [Display(Name = "InactiveDate", ResourceType = typeof (CSCommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof (AnnotationsResx)
            )]
        [ViewField(Name = Fields.InactiveDate, Id = Index.InactiveDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime InactiveDate { get; set; }

        /// <summary>
        /// Gets status string value
        /// </summary>
        public string StatusString
        {
            get { return EnumUtility.GetStringValue(Status); }
        }

        /// <summary>
        /// Gets or sets BankDistributionCodeTaxDetail.
        /// </summary>
        public EnumerableResponse<BankDistributionCodeTaxDetail> BankDistributionCodeDetails { get; set; }
    }
}
