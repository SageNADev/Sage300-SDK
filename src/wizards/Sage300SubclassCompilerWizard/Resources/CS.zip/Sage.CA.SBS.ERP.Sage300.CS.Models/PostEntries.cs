// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class Post Entries
    /// </summary>
    public partial class PostEntries : ModelBase
    {
        /// <summary>
        /// Gets or sets Posting Operation 
        /// </summary>
        [ViewField(Name = Fields.PostingOperation, Id = Index.PostingOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public PostingOperation PostingOperation { get; set; }

        /// <summary>
        /// Gets or sets From Sequence Number 
        /// </summary>
        [ViewField(Name = Fields.FromSequenceNumber, Id = Index.FromSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long FromSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets To Sequence Number 
        /// </summary>
        [ViewField(Name = Fields.ToSequenceNumber, Id = Index.ToSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ToSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets Bank Code 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(PostEntriesResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets To Bank Code 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankCode", ResourceType = typeof(PostEntriesResx))]
        [ViewField(Name = Fields.ToBankCode, Id = Index.ToBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string ToBankCode { get; set; }

        /// <summary>
        /// Gets or sets Bank Entry Date 
        /// </summary>
        [Display(Name = "BankEntryDate", ResourceType = typeof(PostEntriesResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankEntryDate, Id = Index.BankEntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? BankEntryDate { get; set; }

        /// <summary>
        /// Gets or sets To Bank Entry Date 
        /// </summary>
        [Display(Name = "BankEntryDate", ResourceType = typeof(PostEntriesResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToBankEntryDate, Id = Index.ToBankEntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ToBankEntryDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Year 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Bank Entry Number 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankEntryNo", ResourceType = typeof(PostEntriesResx))]
        [ViewField(Name = Fields.BankEntryNumber, Id = Index.BankEntryNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string BankEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets To Bank Entry Number 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BankEntryNo", ResourceType = typeof(PostEntriesResx))]
        [ViewField(Name = Fields.ToBankEntryNumber, Id = Index.ToBankEntryNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToBankEntryNumber { get; set; }
    }
}
