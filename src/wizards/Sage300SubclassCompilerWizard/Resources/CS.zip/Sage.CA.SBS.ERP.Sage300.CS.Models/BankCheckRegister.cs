/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// BankCheckRegister class
    /// </summary>
    public partial class BankCheckRegister : ModelBase
    {

        /// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string SourceApplication { get; set; }

        /// <summary>
        /// Gets or sets ApplicationRunNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(10, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.ApplicationRunNumber, Id = Index.ApplicationRunNumber, FieldType = EntityFieldType.Char, Size = 10)]
        public string ApplicationRunNumber { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets SortCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.SortCode, Id = Index.SortCode, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal SortCode { get; set; }

        /// <summary>
        /// Gets or sets PayeeCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "PayeeidFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.PayeeCode, Id = Index.PayeeCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12C")]
        public string PayeeCode { get; set; }

        /// <summary>
        /// Gets or sets SerialNumber 
        /// </summary>

        [ViewField(Name = Fields.SerialNumber, Id = Index.SerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
        public long SerialNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckNumber 
        /// </summary>
        [Display(Name = "CheckNumber", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CheckNumber, Id = Index.CheckNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
        public decimal CheckNumber { get; set; }

        /// <summary>
        /// Gets or sets CheckStatus 
        /// </summary>
        [Display(Name = "CheckStatus", ResourceType = typeof(CommonResx))]
        [ViewField(Name = Fields.CheckStatus, Id = Index.CheckStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public Enums.CheckStatus CheckStatus { get; set; }

        /// <summary>
        /// Gets or sets CheckType 
        /// </summary>
        [Display(Name = "CheckType", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CheckType, Id = Index.CheckType, FieldType = EntityFieldType.Int, Size = 2)]
        public CS.Models.Enums.CheckType CheckType { get; set; }

        /// <summary>
        /// Gets or sets CheckStockCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckStockCode, Id = Index.CheckStockCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string CheckStockCode { get; set; }

        /// <summary>
        /// Gets or sets PayeeName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PayeenameFLD", ResourceType = typeof(BKCommonResx) )]
        [ViewField(Name = Fields.PayeeName, Id = Index.PayeeName, FieldType = EntityFieldType.Char, Size = 60)]
        public string PayeeName { get; set; }

        /// <summary>
        /// Gets or sets VendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendornameFLD", ResourceType = typeof(BKCommonResx) )]
        [ViewField(Name = Fields.VendorName, Id = Index.VendorName, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorName { get; set; }

        /// <summary>
        /// Gets or sets CheckReference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckReference, Id = Index.CheckReference, FieldType = EntityFieldType.Char, Size = 60)]
        public string CheckReference { get; set; }

        /// <summary>
        /// Gets or sets CheckDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckDescription, Id = Index.CheckDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string CheckDescription { get; set; }

        /// <summary>
        /// Gets or sets DateCheckPrinted 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.DateCheckPrinted, Id = Index.DateCheckPrinted, FieldType = EntityFieldType.Date, Size = 5)]
        public string DateCheckPrinted { get; set; }

        /// <summary>
        /// Gets or sets CheckDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.CheckDate, Id = Index.CheckDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string CheckDate { get; set; }

        /// <summary>
        /// Gets or sets CheckAmount 
        /// </summary>
        [Display(Name = "CheckAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.CheckAmount, Id = Index.CheckAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckAmount { get; set; }

        /// <summary>
        /// Gets or sets CheckSourceAmount 
        /// </summary>

        [ViewField(Name = Fields.CheckSourceAmount, Id = Index.CheckSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal CheckSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeRateType, Id = Index.ExchangeRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ExchangeRateType { get; set; }

        /// <summary>
        /// Gets or sets PaymentCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CheckCurrency", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.PaymentCurrency, Id = Index.PaymentCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string PaymentCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string ExchangeRateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>

        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateSpread 
        /// </summary>

        [ViewField(Name = Fields.RateSpread, Id = Index.RateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RateSpread { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>

        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public CS.Models.Enums.RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets ExtraApplicationData 
        /// </summary>

        [ViewField(Name = Fields.ExtraApplicationData, Id = Index.ExtraApplicationData, FieldType = EntityFieldType.Byte, Size = 102)]
        public byte ExtraApplicationData { get; set; }

        /// <summary>
        /// Gets or sets LanguageCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LanguageCode, Id = Index.LanguageCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3C")]
        public string LanguageCode { get; set; }

        /// <summary>
        /// Gets or sets AdviceLines 
        /// </summary>

        [ViewField(Name = Fields.AdviceLines, Id = Index.AdviceLines, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal AdviceLines { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>

        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets Language 
        /// </summary>

        [ViewField(Name = Fields.Language, Id = Index.Language, FieldType = EntityFieldType.Int, Size = 2)]
        public CS.Models.Enums.Language Language { get; set; }

        /// <summary>
        /// Gets or sets SourceCurrencyDecimals 
        /// </summary>

        [ViewField(Name = Fields.SourceCurrencyDecimals, Id = Index.SourceCurrencyDecimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int SourceCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets DrilldownType 
        /// </summary>

        [ViewField(Name = Fields.DrilldownType, Id = Index.DrilldownType, FieldType = EntityFieldType.Int, Size = 2)]
        public int DrilldownType { get; set; }

        /// <summary>
        /// Gets or sets DrilldownLink 
        /// </summary>

        [ViewField(Name = Fields.DrilldownLink, Id = Index.DrilldownLink, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal DrilldownLink { get; set; }

        /// <summary>
        /// Gets or sets PaymentCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.PaymentCode, Id = Index.PaymentCode, FieldType = EntityFieldType.Char, Size = 12)]
        public string PaymentCode { get; set; }

        /// <summary>
        /// Gets or sets SourceDocumentNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.SourceDocumentNumber, Id = Index.SourceDocumentNumber, FieldType = EntityFieldType.Char, Size = 22)]
        public string SourceDocumentNumber { get; set; }

        /// <summary>
        /// Gets or sets CanReverseInvoice 
        /// </summary>

        [ViewField(Name = Fields.CanReverseInvoice, Id = Index.CanReverseInvoice, FieldType = EntityFieldType.Int, Size = 2)]
        public CS.Models.Enums.CanReverseInvoice CanReverseInvoice { get; set; }
    }
}
