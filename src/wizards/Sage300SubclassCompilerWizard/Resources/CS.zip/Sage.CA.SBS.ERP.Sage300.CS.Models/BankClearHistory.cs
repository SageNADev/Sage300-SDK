﻿// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is BankClearHistory entity
    /// </summary>
    public class BankClearHistory : ModelBase
    {
        /// <summary>
        ///   Gets or sets BankTransaction 
        /// </summary>
        public bool BankTransaction { get; set; }

        /// <summary>
        ///   Gets or sets BankEntry 
        /// </summary>
        public bool BankEntry { get; set; }

        /// <summary>
        ///   Gets or sets PrintedBankEntryPostJournal 
        /// </summary>
        public bool PrintedBankEntryPostJournal { get; set; }

        /// <summary>
        ///   Gets or sets PrintedReconciliationPostJournal
        /// </summary>
        public bool PrintedReconciliationPostJournal { get; set; }

        /// <summary>
        ///  Gets or sets PrintedTransferPostJournal
        /// </summary>
        public bool PrintedTransferPostJournal { get; set; }

        /// <summary>
        ///   Gets or sets BankTransactionEnable
        /// </summary>
        public bool BankTransactionEnable { get; set; }

        /// <summary>
        ///   Gets or sets BankEntryEnable
        /// </summary>
        public bool BankEntryEnable { get; set; }

        /// <summary>
        ///   Gets or sets PrintedBankEntryPostJournalEnable 
        /// </summary>
        public bool PrintedBankEntryPostJournalEnable { get; set; }

        /// <summary>
        ///   Gets or sets PrintedReconciliationPostJournalEnable 
        /// </summary>
        public bool PrintedReconciliationPostJournalEnable { get; set; }

        /// <summary>
        ///  Gets or sets PrintedTransferPostJournalEnable 
        /// </summary>
        public bool PrintedTransferPostJournalEnable { get; set; }

        /// <summary>
        /// Gets or sets Frombank 
        /// </summary>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBank { get; set; }

        /// <summary>
        /// Gets or sets Tobank
        /// </summary>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBank { get; set; }

        /// <summary>
        /// Gets or sets ThroughDate 
        /// </summary>
        [Display(Name = "THROUGH", ResourceType = typeof(BankClearHistoryResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ThroughDate { get; set; }

        /// <summary>
        /// Gets or sets FromEntrySequenceNumber 
        /// </summary>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public long FromBankEntrySequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ToEntrySequenceNumber 
        /// </summary>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public long ToBankEntrySequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets FromJournalEntrySequenceNumber 
        /// </summary>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal FromJournalEntrySequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ToJournalEntrySequenceNumber 
        /// </summary>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal ToJournalEntrySequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets FromReconciliationSequenceNumber 
        /// </summary>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal FromReconciliationSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ToReconciliationSequenceNumber 
        /// </summary>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal ToReconciliationSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets FromTransferSequenceNumber 
        /// </summary>
        [Display(Name = "From", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal FromTransferSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ToTransferSequenceNumber 
        /// </summary>
        [Display(Name = "To", ResourceType = typeof(CommonResx))]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public decimal ToTransferSequenceNumber { get; set; }

    }
}
