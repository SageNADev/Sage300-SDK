/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for Sync
    /// </summary>
    public partial class EmployeeSync : ModelBase
	{
		/// <summary>
		/// Gets or sets OriginalModule
		/// </summary>
		[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		public string OriginalModule { get; set; }

		/// <summary>
		/// Gets or sets EmployeeID
		/// </summary>
		[StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
		public string EmployeeID { get; set; }

		/// <summary>
		/// Gets or sets ProcessCommandCode
		/// </summary>
		public SyncProcessCommandCode ProcessCommandCode { get; set; }

	}
}
