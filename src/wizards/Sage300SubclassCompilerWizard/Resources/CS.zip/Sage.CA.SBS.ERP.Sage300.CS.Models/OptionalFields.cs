 /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class OptionalFields.
    /// </summary>
    public partial class OptionalFields : ModelBase
    {
        /// <summary>
        /// Initialize OptionalFielddetails
        /// </summary>
        public OptionalFields()
        {
            OptionalFieldDetails = new EnumerableResponse<OptionalFieldsValue>();
        }
        /// <summary>
        /// Gets or sets the optional field key.
        /// </summary>
        /// <value>The optional field key.</value>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptionalField", ResourceType = typeof(OptionalFieldsResx))]
        [Key]
        [ViewField(Name = Fields.OptionalFieldKey, Id = Index.OptionalFieldKey, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalFieldKey { get; set; }

        /// <summary>
        /// Gets or sets the description.
        /// </summary>
        /// <value>The description.</value>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OptFieldDesc", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets type
        /// </summary>
        /// <value>The type.</value>        
        [Display(Name = "Type", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldType Type { get; set; }

        /// <summary>
        /// Gets the type string.
        /// </summary>
        /// <value>The type string.</value>
        [IgnoreExportImport]
        public string TypeString
        {
            get
            {
                // var typeValue = (int) Type;
                return EnumUtility.GetStringValue(Type);
            }
        }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        /// <value>The length.</value>
        [Display(Name = "OptFieldLength", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        /// <value>The decimals.</value>
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets AllowBlank
        /// </summary>
        /// <value><c>true</c> if [allow blank]; otherwise, <c>false</c>.</value>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowBlank { get; set; }

        /// <summary>
        /// AllowBlankValue type
        /// </summary>
        public AllowBlank AllowBlankValue { get; set; }

        /// <summary>
        /// Allow Blank String
        /// </summary>
        [IgnoreExportImport]
        public string AllowBlankString
        {
            get
            {
                return EnumUtility.GetStringValue(AllowBlankValue);
            }
        }

        /// <summary>
        /// Get or Set for AllowBlank N/A
        /// </summary>
        [IgnoreExportImport]
        public AllowBlankNa AllowBlankNa { get; set; }
        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        /// <value><c>true</c> if this instance is validate; otherwise, <c>false</c>.</value>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.IsValidate, Id = Index.IsValidate, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool IsValidate { get; set; }

        /// <summary>
        /// ValidateEnum type
        /// </summary>
        public Validate IsValidateEnum { get; set; }

        /// <summary>
        /// Allow Blank String
        /// </summary>
        public string IsValidateString
        {
            get { return EnumUtility.GetStringValue(IsValidateEnum); }
        }
        /// <summary>
        /// To get integer min
        /// </summary>
        /// <value>The int minimum.</value>
        [IgnoreExportImport]
        public string IntMin
        {
            get { return "-2147483647"; }
        }

        /// <summary>
        /// To get integer max
        /// </summary>
        /// <value>The int maximum.</value>
        [IgnoreExportImport]
        public string IntMax
        {
            get { return "2147483647"; }
        }

        /// <summary>
        /// To get decimal min
        /// </summary>
        /// <value>The decimal minimum.</value>
        [IgnoreExportImport]
        public string DecimalMinAmountType
        {
            get
            {
                return CommonUtil.GetDecimalDefaultFormat('9', 15, 3, true);
            }
        }

        /// <summary>
        /// To get decimal max
        /// </summary>
        /// <value>The decimal maximum.</value>
        [IgnoreExportImport]
        public string DecimalMaxAmountType
        {
            get { return CommonUtil.GetDecimalDefaultFormat('9', 15, 3, false); }
        }

        /// <summary>
        /// To get decimal min
        /// </summary>
        /// <value>The decimal minimum.</value>
        [IgnoreExportImport]
        public string DecimalMinNumberType
        {
            get
            {
                return CommonUtil.GetDecimalDefaultFormat('9', 15, Decimals, true);
            }
        }

        /// <summary>
        /// To get decimal max
        /// </summary>
        /// <value>The decimal maximum.</value>
        [IgnoreExportImport]
        public string DecimalMaxNumberType
        {
            get { return CommonUtil.GetDecimalDefaultFormat('9', 15, Decimals, false); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        [IgnoreExportImport]
        public string IntegerRegEx
        {
            get { return CommonUtil.GetDecimalRegularExpression(10, 0); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        [IgnoreExportImport]
        public string DecimalRegExAmountType
        {
            get { return CommonUtil.GetDecimalRegularExpression(18, 3); }
        }

        /// <summary>
        /// To get decimal regular expression
        /// </summary>
        [IgnoreExportImport]
        public string DecimalRegExNumberType
        {
            get { return CommonUtil.GetDecimalRegularExpression(18, Decimals); }
        }

        /// <summary>
        /// Optional Field details list
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<OptionalFieldsValue> OptionalFieldDetails { get; set; }

        /// <summary>
        /// Values
        /// </summary>
        [Display(Name = "Values", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Values, Id = Index.Values, FieldType = EntityFieldType.Long, Size = 4)]
        public decimal Values { get; set; }
        
    }
}
