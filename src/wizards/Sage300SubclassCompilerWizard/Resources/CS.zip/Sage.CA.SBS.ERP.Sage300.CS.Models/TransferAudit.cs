// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
     /// <summary>
     /// Partial class for TransferAudit
     /// </summary>
     public partial class TransferAudit : ModelBase
     {
          /// <summary>
          /// Gets or sets PostingSequence
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
          public decimal PostingSequence {get; set;}

          /// <summary>
          /// Gets or sets KeySequence
          /// </summary>
          [Key]
          [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.KeySequence, Id = Index.KeySequence, FieldType = EntityFieldType.Decimal, Size = 5)]
          public decimal KeySequence {get; set;}

          /// <summary>
          /// Gets or sets TransferNumber
          /// </summary>
          [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferNumber, Id = Index.TransferNumber, FieldType = EntityFieldType.Char, Size = 22)]
          public string TransferNumber {get; set;}

          /// <summary>
          /// Gets or sets Date
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Date, Id = Index.Date, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime Date {get; set;}

          /// <summary>
          /// Gets or sets TransferAdjustmentGLAccount
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferAdjustmentGLAccount, Id = Index.TransferAdjustmentGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
          public string TransferAdjustmentGLAccount {get; set;}

          /// <summary>
          /// Gets or sets Description
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
          public string Description {get; set;}

          /// <summary>
          /// Gets or sets Reference
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
          public string Reference {get; set;}

          /// <summary>
          /// Gets or sets FiscalYear
          /// </summary>
          [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
          public string FiscalYear {get; set;}

          /// <summary>
          /// Gets or sets FiscalPeriod
          /// </summary>
          [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
          public int FiscalPeriod {get; set;}

          /// <summary>
          /// Gets or sets TransferBankCode
          /// </summary>
          [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferBankCode, Id = Index.TransferBankCode, FieldType = EntityFieldType.Char, Size = 8)]
          public string TransferBankCode {get; set;}

          /// <summary>
          /// Gets or sets TransferBank
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferBank, Id = Index.TransferBank, FieldType = EntityFieldType.Char, Size = 60)]
          public string TransferBank {get; set;}

          /// <summary>
          /// Gets or sets TransferBankGLAccount
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferBankGLAccount, Id = Index.TransferBankGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
          public string TransferBankGLAccount {get; set;}

          /// <summary>
          /// Gets or sets TransferSourceCurrency
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferSourceCurrency, Id = Index.TransferSourceCurrency, FieldType = EntityFieldType.Char, Size = 3)]
          public string TransferSourceCurrency {get; set;}

          /// <summary>
          /// Gets or sets TransferRateDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferRateDate, Id = Index.TransferRateDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime TransferRateDate {get; set;}

          /// <summary>
          /// Gets or sets TransferRateType
          /// </summary>
          [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferRateType, Id = Index.TransferRateType, FieldType = EntityFieldType.Char, Size = 2)]
          public string TransferRateType {get; set;}

          /// <summary>
          /// Gets or sets TransferRateFactor
          /// </summary>
          [ViewField(Name = Fields.TransferRateFactor, Id = Index.TransferRateFactor, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TransferRateFactor {get; set;}

          /// <summary>
          /// Gets or sets TransferRateSpread
          /// </summary>
          [ViewField(Name = Fields.TransferRateSpread, Id = Index.TransferRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal TransferRateSpread {get; set;}

          /// <summary>
          /// Gets or sets TransferRateOperator
          /// </summary>
          [ViewField(Name = Fields.TransferRateOperator, Id = Index.TransferRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
          public int TransferRateOperator {get; set;}

          /// <summary>
          /// Gets or sets TransferSourceAmount
          /// </summary>
          [ViewField(Name = Fields.TransferSourceAmount, Id = Index.TransferSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TransferSourceAmount {get; set;}

          /// <summary>
          /// Gets or sets TransferFunctionalAmount
          /// </summary>
          [ViewField(Name = Fields.TransferFunctionalAmount, Id = Index.TransferFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal TransferFunctionalAmount {get; set;}

          /// <summary>
          /// Gets or sets DepositBankCode
          /// </summary>
          [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositBankCode, Id = Index.DepositBankCode, FieldType = EntityFieldType.Char, Size = 8)]
          public string DepositBankCode {get; set;}

          /// <summary>
          /// Gets or sets DepositBank
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositBank, Id = Index.DepositBank, FieldType = EntityFieldType.Char, Size = 60)]
          public string DepositBank {get; set;}

          /// <summary>
          /// Gets or sets DepositBankGLAccount
          /// </summary>
          [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositBankGLAccount, Id = Index.DepositBankGLAccount, FieldType = EntityFieldType.Char, Size = 45)]
          public string DepositBankGLAccount {get; set;}

          /// <summary>
          /// Gets or sets DepositSourceCurrency
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositSourceCurrency, Id = Index.DepositSourceCurrency, FieldType = EntityFieldType.Char, Size = 3)]
          public string DepositSourceCurrency {get; set;}

          /// <summary>
          /// Gets or sets DepositRateDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositRateDate, Id = Index.DepositRateDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime DepositRateDate {get; set;}

          /// <summary>
          /// Gets or sets DepositRateType
          /// </summary>
          [StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositRateType, Id = Index.DepositRateType, FieldType = EntityFieldType.Char, Size = 2)]
          public string DepositRateType {get; set;}

          /// <summary>
          /// Gets or sets DepositRateFactor
          /// </summary>
          [ViewField(Name = Fields.DepositRateFactor, Id = Index.DepositRateFactor, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal DepositRateFactor {get; set;}

          /// <summary>
          /// Gets or sets DepositRateSpread
          /// </summary>
          [ViewField(Name = Fields.DepositRateSpread, Id = Index.DepositRateSpread, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal DepositRateSpread {get; set;}

          /// <summary>
          /// Gets or sets DepositRateOperator
          /// </summary>
          [ViewField(Name = Fields.DepositRateOperator, Id = Index.DepositRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
          public int DepositRateOperator {get; set;}

          /// <summary>
          /// Gets or sets DepositSourceAmount
          /// </summary>
          [ViewField(Name = Fields.DepositSourceAmount, Id = Index.DepositSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal DepositSourceAmount {get; set;}

          /// <summary>
          /// Gets or sets DepositFunctionalAmount
          /// </summary>
          [ViewField(Name = Fields.DepositFunctionalAmount, Id = Index.DepositFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal DepositFunctionalAmount {get; set;}

          /// <summary>
          /// Gets or sets SourceRateFactor
          /// </summary>
          [ViewField(Name = Fields.SourceRateFactor, Id = Index.SourceRateFactor, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
          public decimal SourceRateFactor {get; set;}

          /// <summary>
          /// Gets or sets SourceRateOperator
          /// </summary>
          [ViewField(Name = Fields.SourceRateOperator, Id = Index.SourceRateOperator, FieldType = EntityFieldType.Int, Size = 2)]
          public SourceRateOperator SourceRateOperator {get; set;}

          /// <summary>
          /// Gets or sets SourceSourceCurrency
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.SourceSourceCurrency, Id = Index.SourceSourceCurrency, FieldType = EntityFieldType.Char, Size = 3)]
          public string SourceSourceCurrency {get; set;}

          /// <summary>
          /// Gets or sets SourceSourceAmount
          /// </summary>
          [ViewField(Name = Fields.SourceSourceAmount, Id = Index.SourceSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal SourceSourceAmount {get; set;}

          /// <summary>
          /// Gets or sets SourceFunctionalAmount
          /// </summary>
          [ViewField(Name = Fields.SourceFunctionalAmount, Id = Index.SourceFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
          public decimal SourceFunctionalAmount {get; set;}

          /// <summary>
          /// Gets or sets TransferCurrencyStatement
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferCurrencyStatement, Id = Index.TransferCurrencyStatement, FieldType = EntityFieldType.Char, Size = 3)]
          public string TransferCurrencyStatement {get; set;}

          /// <summary>
          /// Gets or sets TransferMulticurrency
          /// </summary>
          [ViewField(Name = Fields.TransferMulticurrency, Id = Index.TransferMulticurrency, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool TransferMulticurrency {get; set;}

          /// <summary>
          /// Gets or sets DepositCurrencyStatement
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositCurrencyStatement, Id = Index.DepositCurrencyStatement, FieldType = EntityFieldType.Char, Size = 3)]
          public string DepositCurrencyStatement {get; set;}

          /// <summary>
          /// Gets or sets DepositMulticurrency
          /// </summary>
          [ViewField(Name = Fields.DepositMulticurrency, Id = Index.DepositMulticurrency, FieldType = EntityFieldType.Bool, Size = 2)]
          public bool DepositMulticurrency {get; set;}

          /// <summary>
          /// Gets or sets TransferBankCurrencyDescripti
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.TransferBankCurrencyDescripti, Id = Index.TransferBankCurrencyDescripti, FieldType = EntityFieldType.Char, Size = 60)]
          public string TransferBankCurrencyDescripti {get; set;}

          /// <summary>
          /// Gets or sets DepositBankCurrencyDescriptio
          /// </summary>
          [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.DepositBankCurrencyDescriptio, Id = Index.DepositBankCurrencyDescriptio, FieldType = EntityFieldType.Char, Size = 60)]
          public string DepositBankCurrencyDescriptio {get; set;}

          /// <summary>
          /// Gets or sets FunctionalCurrency
          /// </summary>
          [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
          public string FunctionalCurrency {get; set;}

          /// <summary>
          /// Gets or sets PostDate
          /// </summary>
          [ValidateDateFormat(ErrorMessage="DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
          [ViewField(Name = Fields.PostDate, Id = Index.PostDate, FieldType = EntityFieldType.Date, Size = 5)]
          public DateTime PostDate {get; set;}

     }
}
