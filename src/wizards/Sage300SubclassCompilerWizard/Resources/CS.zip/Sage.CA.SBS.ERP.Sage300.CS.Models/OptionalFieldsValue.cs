 /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class OptionalFieldsValue.
    /// </summary>
    public partial class OptionalFieldsValue : ModelBase
    {
        /// <summary>
        /// Gets or sets Optional Field
        /// </summary>
        /// <value>The optional field.</value>
        [Key]
        [Display(Name = "OptionalField", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.OptionalField, Id = Index.OptionalField, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string OptionalField { get; set; }

        /// <summary>
        /// Gets or sets Value
        /// </summary>
        /// <value>The value.</value>
        [Key]
        [Display(Name = "Value", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Value, Id = Index.Value, FieldType = EntityFieldType.Char, Size = 60)]
        public string Value { get; set; }

        /// <summary>
        /// Gets or sets Sorted Value
        /// </summary>
        /// <value>The sorted value.</value>
        [Display(Name = "SortedValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.SortedValue, Id = Index.SortedValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string SortedValue { get; set; }

        /// <summary>
        /// Gets or sets  Value Description
        /// </summary>
        /// <value>The value description.</value>
        [Display(Name = "ValueDescription", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ValueDescription, Id = Index.ValueDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ValueDescription { get; set; }

        /// <summary>
        /// Gets or sets Type
        /// </summary>
        /// <value>The type.</value>
        [Display(Name = "Type", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public OptionalFieldType Type { get; set; }

        /// <summary>
        /// To get the string of Type property
        /// </summary>
        /// <value>The type string.</value>
        public string TypeString
        {
            get { return EnumUtility.GetStringValue(Type); }
        }

        /// <summary>
        /// Gets or sets Length
        /// </summary>
        /// <value>The length.</value>
        [Display(Name = "OptFieldLength", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Length, Id = Index.Length, FieldType = EntityFieldType.Int, Size = 2)]
        public int Length { get; set; }

        /// <summary>
        /// Gets or sets Decimals
        /// </summary>
        /// <value>The decimals.</value>
        [Key]
        [Display(Name = "Decimals", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Decimals, Id = Index.Decimals, FieldType = EntityFieldType.Int, Size = 2)]
        public int Decimals { get; set; }

        /// <summary>
        /// Gets or sets Allow Null
        /// </summary>
        /// <value><c>true</c> if [allow blank]; otherwise, <c>false</c>.</value>
        [Display(Name = "AllowBlank", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AllowBlank, Id = Index.AllowBlank, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool AllowBlank { get; set; }

        /// <summary>
        /// AllowBlankEnum type
        /// </summary>
        [IgnoreExportImport]
        public AllowBlank AllowBlankEnum { get; set; }

        /// <summary>
        /// Allow Blank String
        /// </summary>
        [IgnoreExportImport]
        public string AllowBlankString
        {
            get
            {
                return EnumUtility.GetStringValue(AllowBlankNa);
            }
        }

        /// <summary>
        /// Get or Set for AllowBlank N/A
        /// </summary>
        [IgnoreExportImport]
        public AllowBlankNa AllowBlankNa { get; set; }

        /// <summary>
        /// Gets or sets Validate
        /// </summary>
        /// <value><c>true</c> if validate; otherwise, <c>false</c>.</value>
        [Display(Name = "Validate", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.Validate, Id = Index.Validate, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Validate { get; set; }

        /// <summary>
        /// ValidateEnum type
        /// </summary>
        public Validate ValidateEnum { get; set; }

        /// <summary>
        /// Allow Blank String
        /// </summary>
        [IgnoreExportImport]
        public string ValidateString
        {
            get { return EnumUtility.GetStringValue(ValidateEnum); }
        }

        /// <summary>
        /// Gets or sets Convert Value
        /// </summary>
        /// <value>The convert value.</value>
        [Display(Name = "ConvertValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.ConvertValue, Id = Index.ConvertValue, FieldType = EntityFieldType.Char, Size = 60)]
        public string ConvertValue { get; set; }

        /// <summary>
        /// Gets or sets Type Value Field Index
        /// </summary>
        /// <value>The index of the type value field.</value>
        [Display(Name = "TypeValueFieldIndex", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TypeValueFieldIndex, Id = Index.TypeValueFieldIndex, FieldType = EntityFieldType.Long, Size = 4)]
        public long TypeValueFieldIndex { get; set; }

        /// <summary>
        /// Gets or sets Text Value
        /// </summary>
        /// <value>The text value.</value>
        [Display(Name = "TextValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TextValue, Id = Index.TextValue, FieldType = EntityFieldType.Char, Size = 60, Mask = "%-60c")]
        public string TextValue { get; set; }

        /// <summary>
        /// Gets or sets Amount Value
        /// </summary>
        /// <value>The amount value.</value>
        [Display(Name = "AmountValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.AmountValue, Id = Index.AmountValue, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public double AmountValue { get; set; }

        /// <summary>
        /// Gets or sets Number Value
        /// </summary>
        /// <value>The number value.</value>
        [Display(Name = "NumberValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.NumberValue, Id = Index.NumberValue, FieldType = EntityFieldType.Decimal, Size = 10)]
        public double NumberValue { get; set; }

        /// <summary>
        /// Gets or sets Integer Value
        /// </summary>
        /// <value>The integer value.</value>
        [Display(Name = "IntegerValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.IntegerValue, Id = Index.IntegerValue, FieldType = EntityFieldType.Long, Size = 4)]
        public long IntegerValue { get; set; }

        /// <summary>
        /// Gets or sets Boolean Value
        /// </summary>
        /// <value><c>true</c> if [boolean value]; otherwise, <c>false</c>.</value>
        [Display(Name = "BooleanValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.BooleanValue, Id = Index.BooleanValue, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool BooleanValue { get; set; }

        /// <summary>
        /// Gets or sets Date Value
        /// </summary>
        /// <value>The date value.</value>
        [Display(Name = "DateValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.DateValue, Id = Index.DateValue, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime DateValue { get; set; }

        /// <summary>
        /// Gets or sets Time Value
        /// </summary>
        /// <value>The time value.</value>
        [Display(Name = "TimeValue", ResourceType = typeof(OptionalFieldsResx))]
        [ViewField(Name = Fields.TimeValue, Id = Index.TimeValue, FieldType = EntityFieldType.Time, Size = 5)]
        public DateTime TimeValue { get; set; }

        /// <summary>
        /// 
        /// </summary>
        public string FormattedTimeValue
        {
            get { return TimeUtil.GetFormattedTime(TimeValue.ToString("HH:mm:ss")); }
        }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        [Display(Name = "SerialNumber", ResourceType = typeof(OptionalFieldsResx))]
        public long SerialNumber { get; set; }

        /// <summary>
        ///  Gets or Sets YesorNo value
        /// </summary>
        public bool YesOrNoValue { get; set; }

        /// <summary>
        /// YesOrNoValue Enum
        /// </summary>
        public Validate YesOrNoValueEnum { get; set; }


        /// <summary>
        /// YesOrNoValue String
        /// </summary>
        public string YesOrNoValueString
        {
            get { return EnumUtility.GetStringValue(YesOrNoValueEnum); }
        }
    }
}
