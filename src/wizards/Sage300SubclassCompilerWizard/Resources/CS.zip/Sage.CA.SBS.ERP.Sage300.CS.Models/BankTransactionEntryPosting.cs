/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class BankTransactionEntryPosting : ModelBase
    {

        /// <summary>
        /// Gets or sets PostingOperation 
        /// </summary>

        [ViewField(Name = Fields.PostingOperation, Id = Index.PostingOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public PostingOperation PostingOperation { get; set; }

        /// <summary>
        /// Gets or sets FromSequenceNumber 
        /// </summary>

        [ViewField(Name = Fields.FromSequenceNumber, Id = Index.FromSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long FromSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets ToSequenceNumber 
        /// </summary>

        [ViewField(Name = Fields.ToSequenceNumber, Id = Index.ToSequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long ToSequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BankCode { get; set; }

        /// <summary>
        /// Gets or sets ToBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToBankCode, Id = Index.ToBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string ToBankCode { get; set; }

        /// <summary>
        /// Gets or sets BankEntryDate 
        /// </summary>
        [ViewField(Name = Fields.BankEntryDate, Id = Index.BankEntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime BankEntryDate { get; set; }

        /// <summary>
        /// Gets or sets ToBankEntryDate 
        /// </summary>
        [ViewField(Name = Fields.ToBankEntryDate, Id = Index.ToBankEntryDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ToBankEntryDate { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public int FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets BankEntryNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BankEntryNumber, Id = Index.BankEntryNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string BankEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets ToBankEntryNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ToBankEntryNumber, Id = Index.ToBankEntryNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string ToBankEntryNumber { get; set; }

        /// <summary>
        /// User message object
        /// </summary>
        public UserMessage UserMessage { get; set; }
    }
}
