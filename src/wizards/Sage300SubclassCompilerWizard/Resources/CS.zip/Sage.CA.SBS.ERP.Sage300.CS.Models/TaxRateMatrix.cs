/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;



// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// TaxRateMatrix
    /// </summary>
    public partial class TaxRateMatrix : ModelBase
    {

        /// <summary>
        /// Gets or sets Authority 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.Authority, Id = Index.Authority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string Authority { get; set; }

        /// <summary>
        /// Gets or sets Type 
        /// </summary>
        [Key]
        [ViewField(Name = Fields.Type, Id = Index.Type, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType Type { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public string LastMaintained { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass1 
        /// </summary>

        public decimal BuyerClass1ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass2 
        /// </summary>

        public decimal BuyerClass1ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass3 
        /// </summary>

        public decimal BuyerClass1ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass4 
        /// </summary>

        public decimal BuyerClass1ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass5 
        /// </summary>

        public decimal BuyerClass1ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass6 
        /// </summary>

        public decimal BuyerClass1ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass7 
        /// </summary>

        public decimal BuyerClass1ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass8 
        /// </summary>

        public decimal BuyerClass1ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass9 
        /// </summary>

        public decimal BuyerClass1ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass1ItemClass10 
        /// </summary>

        public decimal BuyerClass1ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass1 
        /// </summary>

        public decimal BuyerClass2ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass2 
        /// </summary>

        public decimal BuyerClass2ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass3 
        /// </summary>

        public decimal BuyerClass2ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass4 
        /// </summary>

        public decimal BuyerClass2ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass5 
        /// </summary>

        public decimal BuyerClass2ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass6 
        /// </summary>

        public decimal BuyerClass2ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass7 
        /// </summary>

        public decimal BuyerClass2ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass8 
        /// </summary>

        public decimal BuyerClass2ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass9 
        /// </summary>

        public decimal BuyerClass2ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass2ItemClass10 
        /// </summary>

        public decimal BuyerClass2ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass1 
        /// </summary>

        public decimal BuyerClass3ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass2 
        /// </summary>

        public decimal BuyerClass3ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass3 
        /// </summary>

        public decimal BuyerClass3ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass4 
        /// </summary>

        public decimal BuyerClass3ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass5 
        /// </summary>

        public decimal BuyerClass3ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass6 
        /// </summary>

        public decimal BuyerClass3ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass7 
        /// </summary>

        public decimal BuyerClass3ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass8 
        /// </summary>

        public decimal BuyerClass3ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass9 
        /// </summary>

        public decimal BuyerClass3ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass3ItemClass10 
        /// </summary>

        public decimal BuyerClass3ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass1 
        /// </summary>

        public decimal BuyerClass4ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass2 
        /// </summary>

        public decimal BuyerClass4ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass3 
        /// </summary>

        public decimal BuyerClass4ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass4 
        /// </summary>

        public decimal BuyerClass4ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass5 
        /// </summary>

        public decimal BuyerClass4ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass6 
        /// </summary>

        public decimal BuyerClass4ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass7 
        /// </summary>

        public decimal BuyerClass4ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass8 
        /// </summary>

        public decimal BuyerClass4ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass9 
        /// </summary>

        public decimal BuyerClass4ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass4ItemClass10 
        /// </summary>

        public decimal BuyerClass4ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass1 
        /// </summary>

        public decimal BuyerClass5ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass2 
        /// </summary>

        public decimal BuyerClass5ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass3 
        /// </summary>

        public decimal BuyerClass5ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass4 
        /// </summary>

        public decimal BuyerClass5ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass5 
        /// </summary>

        public decimal BuyerClass5ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass6 
        /// </summary>

        public decimal BuyerClass5ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass7 
        /// </summary>

        public decimal BuyerClass5ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass8 
        /// </summary>

        public decimal BuyerClass5ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass9 
        /// </summary>

        public decimal BuyerClass5ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass5ItemClass10 
        /// </summary>

        public decimal BuyerClass5ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass1 
        /// </summary>

        public decimal BuyerClass6ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass2 
        /// </summary>

        public decimal BuyerClass6ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass3 
        /// </summary>

        public decimal BuyerClass6ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass4 
        /// </summary>

        public decimal BuyerClass6ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass5 
        /// </summary>

        public decimal BuyerClass6ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass6 
        /// </summary>

        public decimal BuyerClass6ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass7 
        /// </summary>

        public decimal BuyerClass6ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass8 
        /// </summary>

        public decimal BuyerClass6ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass9 
        /// </summary>

        public decimal BuyerClass6ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass6ItemClass10 
        /// </summary>

        public decimal BuyerClass6ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass1 
        /// </summary>

        public decimal BuyerClass7ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass2 
        /// </summary>

        public decimal BuyerClass7ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass3 
        /// </summary>

        public decimal BuyerClass7ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass4 
        /// </summary>

        public decimal BuyerClass7ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass5 
        /// </summary>

        public decimal BuyerClass7ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass6 
        /// </summary>

        public decimal BuyerClass7ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass7 
        /// </summary>

        public decimal BuyerClass7ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass8 
        /// </summary>

        public decimal BuyerClass7ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass9 
        /// </summary>

        public decimal BuyerClass7ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass7ItemClass10 
        /// </summary>

        public decimal BuyerClass7ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass1 
        /// </summary>

        public decimal BuyerClass8ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass2 
        /// </summary>

        public decimal BuyerClass8ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass3 
        /// </summary>

        public decimal BuyerClass8ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass4 
        /// </summary>

        public decimal BuyerClass8ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass5 
        /// </summary>

        public decimal BuyerClass8ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass6 
        /// </summary>

        public decimal BuyerClass8ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass7 
        /// </summary>

        public decimal BuyerClass8ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass8 
        /// </summary>

        public decimal BuyerClass8ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass9 
        /// </summary>

        public decimal BuyerClass8ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass8ItemClass10 
        /// </summary>

        public decimal BuyerClass8ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass1 
        /// </summary>

        public decimal BuyerClass9ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass2 
        /// </summary>

        public decimal BuyerClass9ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass3 
        /// </summary>

        public decimal BuyerClass9ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass4 
        /// </summary>

        public decimal BuyerClass9ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass5 
        /// </summary>

        public decimal BuyerClass9ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass6 
        /// </summary>

        public decimal BuyerClass9ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass7 
        /// </summary>

        public decimal BuyerClass9ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass8 
        /// </summary>

        public decimal BuyerClass9ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass9 
        /// </summary>

        public decimal BuyerClass9ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass9ItemClass10 
        /// </summary>

        public decimal BuyerClass9ItemClass10 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass1 
        /// </summary>

        public decimal BuyerClass10ItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass2 
        /// </summary>

        public decimal BuyerClass10ItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass3 
        /// </summary>

        public decimal BuyerClass10ItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass4 
        /// </summary>

        public decimal BuyerClass10ItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass5 
        /// </summary>

        public decimal BuyerClass10ItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass6 
        /// </summary>

        public decimal BuyerClass10ItemClass6 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass7 
        /// </summary>

        public decimal BuyerClass10ItemClass7 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass8 
        /// </summary>

        public decimal BuyerClass10ItemClass8 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass9 
        /// </summary>

        public decimal BuyerClass10ItemClass9 { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass10ItemClass10 
        /// </summary>

        public decimal BuyerClass10ItemClass10 { get; set; }
    }
}
