/* Copyright (c) 1994-2015 Sage Software, Inc.  All rights reserved. */

#region NameSpace

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Schedule Model
    /// </summary>
    public partial class Schedule : ModelBase
    {
        #region Initializes New Schedule Details

        /// <summary>
        ///  Creates new instance of Schedule Details
        /// </summary>
        public Schedule()
        {
            ScheduleDetails = new EnumerableResponse<ScheduleApplicationLink>();
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets ScheduleCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "ScheduleCode", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.ScheduleCode, Id = Index.ScheduleCode, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string ScheduleCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ScheduleDetailDesc", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Interval 
        /// </summary>
        [Display(Name = "Interval", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Interval, Id = Index.Interval, FieldType = EntityFieldType.Int, Size = 2)]
        public Interval Interval { get; set; }

        /// <summary>
        /// To get the string of Interval property
        /// </summary>
        [IgnoreExportImport]
        public string IntervalString
        {
            get { return EnumUtility.GetStringValue(Interval); }
        }

        /// <summary>
        /// Gets or sets Frequency 
        /// </summary>
        [Display(Name = "Frequency", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Frequency, Id = Index.Frequency, FieldType = EntityFieldType.Int, Size = 2)]
        public Frequency Frequency { get; set; }

        /// <summary>
        /// To get the string of Frequency property
        /// </summary>
        [IgnoreExportImport]
        public string FrequencyString
        {
            get { return EnumUtility.GetStringValue(Frequency); }
        }

        /// <summary>
        /// Gets or sets Phase 
        /// </summary>
        [Display(Name = "Phase", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Phase, Id = Index.Phase, FieldType = EntityFieldType.Int, Size = 2)]
        public int Phase { get; set; }

        /// <summary>
        /// Gets or sets Weekday 
        /// </summary>
        [Display(Name = "Weekday", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Weekday, Id = Index.Weekday, FieldType = EntityFieldType.Int, Size = 2)]
        public Weekday Weekday { get; set; }

        /// <summary>
        /// To get the string of Weekday property
        /// </summary>
        [IgnoreExportImport]
        public string WeekdayString
        {
            get { return EnumUtility.GetStringValue(Weekday); }
        }

        /// <summary>
        /// Gets or sets DayofMonth 
        /// </summary>
        [Display(Name = "DOM", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.DayofMonth, Id = Index.DayofMonth, FieldType = EntityFieldType.Int, Size = 2)]
        public DayofMonth DayofMonth { get; set; }

        /// <summary>
        /// To get the string of DayofMonth property
        /// </summary>
        [IgnoreExportImport]
        public string DayofMonthString
        {
            get { return EnumUtility.GetStringValue(DayofMonth); }
        }

        /// <summary>
        /// Gets or sets WeekinMonth 
        /// </summary>
        [Display(Name = "WeekinMonth", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.WeekinMonth, Id = Index.WeekinMonth, FieldType = EntityFieldType.Int, Size = 2)]
        public WeekinMonth WeekinMonth { get; set; }

        /// <summary>
        /// To get the string of WeekinMonth property
        /// </summary>
        [IgnoreExportImport]
        public string WeekinMonthString
        {
            get { return EnumUtility.GetStringValue(WeekinMonth); }
        }

        /// <summary>
        /// Gets or sets Month 
        /// </summary>
        [Display(Name = "Month", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Month, Id = Index.Month, FieldType = EntityFieldType.Int, Size = 2)]
        public Month Month { get; set; }

        /// <summary>
        /// To get the string of Month property
        /// </summary>
        [IgnoreExportImport]
        public string MonthString
        {
            get { return EnumUtility.GetStringValue(Month); }
        }

        /// <summary>
        /// Gets or sets SundayCall 
        /// </summary>
        [Display(Name = "SundayCall", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.SundayCall, Id = Index.SundayCall, FieldType = EntityFieldType.Int, Size = 2)]
        public SundayCall SundayCall { get; set; }

        /// <summary>
        /// To get the string of SundayCall property
        /// </summary>
        [IgnoreExportImport]
        public string SundayCallString
        {
            get { return EnumUtility.GetStringValue(SundayCall); }
        }

        /// <summary>
        /// Gets or sets MondayCall 
        /// </summary>
        [Display(Name = "MondayCall", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.MondayCall, Id = Index.MondayCall, FieldType = EntityFieldType.Int, Size = 2)]
        public SundayCall MondayCall { get; set; }

        /// <summary>
        /// To get the string of MondayCall property
        /// </summary>
        [IgnoreExportImport]
        public string MondayCallString
        {
            get { return EnumUtility.GetStringValue(MondayCall); }
        }

        /// <summary>
        /// Gets or sets TuesdayCall 
        /// </summary>
        [Display(Name = "TuesdayCall", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.TuesdayCall, Id = Index.TuesdayCall, FieldType = EntityFieldType.Int, Size = 2)]
        public SundayCall TuesdayCall { get; set; }

        /// <summary>
        /// To get the string of TuesdayCall property
        /// </summary>
        [IgnoreExportImport]
        public string TuesdayCallString
        {
            get { return EnumUtility.GetStringValue(TuesdayCall); }
        }

        /// <summary>
        /// Gets or sets WednesdayCall 
        /// </summary>
        [Display(Name = "WednesdayCall", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.WednesdayCall, Id = Index.WednesdayCall, FieldType = EntityFieldType.Int, Size = 2)]
        public SundayCall WednesdayCall { get; set; }

        /// <summary>
        /// To get the string of WednesdayCall property
        /// </summary>
        [IgnoreExportImport]
        public string WednesdayCallString
        {
            get { return EnumUtility.GetStringValue(WednesdayCall); }
        }

        /// <summary>
        /// Gets or sets ThursdayCall 
        /// </summary>
        [Display(Name = "ThursdayCall", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.ThursdayCall, Id = Index.ThursdayCall, FieldType = EntityFieldType.Int, Size = 2)]
        public SundayCall ThursdayCall { get; set; }

        /// <summary>
        /// To get the string of ThursdayCall property
        /// </summary>
        [IgnoreExportImport]
        public string ThursdayCallString
        {
            get { return EnumUtility.GetStringValue(ThursdayCall); }
        }

        /// <summary>
        /// Gets or sets FridayCall 
        /// </summary>
        [Display(Name = "FridayCall", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.FridayCall, Id = Index.FridayCall, FieldType = EntityFieldType.Int, Size = 2)]
        public SundayCall FridayCall { get; set; }

        /// <summary>
        /// To get the string of FridayCall property
        /// </summary>
        [IgnoreExportImport]
        public string FridayCallString
        {
            get { return EnumUtility.GetStringValue(FridayCall); }
        }

        /// <summary>
        /// Gets or sets SaturdayCall 
        /// </summary>
        [Display(Name = "SaturdayCall", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.SaturdayCall, Id = Index.SaturdayCall, FieldType = EntityFieldType.Int, Size = 2)]
        public SundayCall SaturdayCall { get; set; }

        /// <summary>
        /// To get the string of SaturdayCall property
        /// </summary>
        [IgnoreExportImport]
        public string SaturdayCallString
        {
            get { return EnumUtility.GetStringValue(SaturdayCall); }
        }

        /// <summary>
        /// Gets or sets LastRunDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "LastRunDate", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.LastRunDate, Id = Index.LastRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? LastRunDate { get; set; }

        /// <summary>
        /// Gets or sets ScheduleStartDate 
        /// </summary>
        [Display(Name = "ScheduleStartDate", ResourceType = typeof(SchedulesResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [ViewField(Name = Fields.ScheduleStartDate, Id = Index.ScheduleStartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? ScheduleStartDate { get; set; }

        /// <summary>
        /// Gets or sets RemindinAdvance 
        /// </summary>
        [Display(Name = "RemindAdvance", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.RemindinAdvance, Id = Index.RemindinAdvance, FieldType = EntityFieldType.Int, Size = 2)]
        public int RemindinAdvance { get; set; }

        /// <summary>
        /// Gets or sets UserMode 
        /// </summary>
        [Display(Name = "UserMode", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.UserMode, Id = Index.UserMode, FieldType = EntityFieldType.Int, Size = 2)]
        public UserMode UserMode { get; set; }

        /// <summary>
        /// To get the string of UserMode property
        /// </summary>
        [IgnoreExportImport]
        public string UserModeString
        {
            get { return EnumUtility.GetStringValue(UserMode); }
        }

        /// <summary>
        /// Gets or sets UserID 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserID", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.UserID, Id = Index.UserID, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string UserID { get; set; }

        /// <summary>
        /// Gets or sets CurrentRun 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrentRun", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.CurrentRun, Id = Index.CurrentRun, FieldType = EntityFieldType.Date, Size = 5)]
        public string CurrentRun { get; set; }

        /// <summary>
        /// Gets or sets NextRun 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "NextRun", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.NextRun, Id = Index.NextRun, FieldType = EntityFieldType.Date, Size = 5)]
        public string NextRun { get; set; }

        /// <summary>
        /// Gets or sets NextPossibleRunDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "NextPossibleRunDate", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.NextPossibleRunDate, Id = Index.NextPossibleRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? NextPossibleRunDate { get; set; }

        /// <summary>
        /// Gets or sets RunDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "RunDate", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.RunDate, Id = Index.RunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? RunDate { get; set; }

        /// <summary>
        /// Gets or sets SuggestedRunDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "SuggestedRunDate", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.SuggestedRunDate, Id = Index.SuggestedRunDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? SuggestedRunDate { get; set; }

        /// <summary>
        /// Gets or sets UserName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "UserName", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.UserName, Id = Index.UserName, FieldType = EntityFieldType.Char, Size = 60)]
        public string UserName { get; set; }

        /// <summary>
        /// Gets or sets IsDue
        /// </summary>
        [Display(Name = "IsDue", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.IsDue, Id = Index.IsDue, FieldType = EntityFieldType.Bool, Size = 2)]
        public SundayCall IsDue { get; set; }

        /// <summary>
        /// To get the string of IsDue property
        /// </summary>
        [IgnoreExportImport]
        public string IsDueString
        {
            get { return EnumUtility.GetStringValue(IsDue); }
        }

        /// <summary>
        /// Gets or sets Processed 
        /// </summary>
        [Display(Name = "Processed", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Processed, Id = Index.Processed, FieldType = EntityFieldType.Bool, Size = 2)]
        public SundayCall Processed { get; set; }

        /// <summary>
        /// To get the string of Processed property
        /// </summary>
        [IgnoreExportImport]
        public string ProcessedString
        {
            get { return EnumUtility.GetStringValue(Processed); }
        }

        /// <summary>
        /// Gets or sets Filtration 
        /// </summary>
        [Display(Name = "Filtration", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Filtration, Id = Index.Filtration, FieldType = EntityFieldType.Int, Size = 2)]
        public Filtration Filtration { get; set; }

        /// <summary>
        /// To get the string of Filtration property
        /// </summary>
        [IgnoreExportImport]
        public string FiltrationString
        {
            get { return EnumUtility.GetStringValue(Filtration); }
        }

        /// <summary>
        /// Gets or sets FilterDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx)
            )]
        [Display(Name = "FilterDate", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.FilterDate, Id = Index.FilterDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? FilterDate { get; set; }

        /// <summary>
        /// Gets or sets Filter 
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Filter", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Filter, Id = Index.Filter, FieldType = EntityFieldType.Char, Size = 200)]
        public string Filter { get; set; }

        /// <summary>
        /// Gets or sets RemindersTo 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RemindersTo", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.RemindersTo, Id = Index.RemindersTo, FieldType = EntityFieldType.Char, Size = 60)]
        public string RemindersTo { get; set; }

        /// <summary>
        /// Gets or sets Operation 
        /// </summary>
        [Display(Name = "Operation", ResourceType = typeof(SchedulesResx))]
        [ViewField(Name = Fields.Operation, Id = Index.Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public Operation Operation { get; set; }

        /// <summary>
        /// To get the string of Operation property
        /// </summary>
        [IgnoreExportImport]
        public string OperationString
        {
            get { return EnumUtility.GetStringValue(Operation); }
        }

        /// <summary>
        /// Gets or Sets Monday Scheduled for UI
        /// </summary>
        [IgnoreExportImport]
        public bool MondayScheduled { get; set; }

        /// <summary>
        /// Gets or Sets Tuesday Scheduled for UI
        /// </summary>
        [IgnoreExportImport]
        public bool TuesdayScheduled { get; set; }

        /// <summary>
        /// Gets or Sets Wednesday Scheduled for UI
        /// </summary>
        [IgnoreExportImport]
        public bool WednesdayScheduled { get; set; }

        /// <summary>
        /// Gets or Sets Thursday Scheduled for UI
        /// </summary>
        [IgnoreExportImport]
        public bool ThursdayScheduled { get; set; }

        /// <summary>
        /// Gets or Sets Friday Scheduled for UI
        /// </summary>
        [IgnoreExportImport]
        public bool FridayScheduled { get; set; }

        /// <summary>
        /// Gets or Sets Saturday Scheduled for UI
        /// </summary>
        [IgnoreExportImport]
        public bool SaturdayScheduled { get; set; }

        /// <summary>
        /// Gets or Sets Sunday Scheduled for UI
        /// </summary>
        [IgnoreExportImport]
        public bool SundayScheduled { get; set; }

        /// <summary>
        /// Gets or Sets Schedule Exists
        /// </summary>
        [IgnoreExportImport]
        public bool IsScheduleExists { get; set; }

        /// <summary>
        /// Gets or Sets Schedule Details
        /// </summary>
        [IgnoreExportImport]
        public EnumerableResponse<ScheduleApplicationLink> ScheduleDetails { get; set; }

        #endregion
    }
}
