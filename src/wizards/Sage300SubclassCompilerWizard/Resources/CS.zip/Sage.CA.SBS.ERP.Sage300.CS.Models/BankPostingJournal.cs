// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
	public partial class BankPostingJournal : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets PostingSequence 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		[ViewField(Name = Fields.PostingSequence, Id = Index.PostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
 		public decimal PostingSequence {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))][StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		[ViewField(Name = Fields.BankCode, Id = Index.BankCode, FieldType = EntityFieldType.Char, Size = 8)]
 		public string BankCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
 		public string Description {get; set;}
		 
  		/// <summary>
        /// Gets or sets AddressLine1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.AddressLine1, Id = Index.AddressLine1, FieldType = EntityFieldType.Char, Size = 60)]
 		public string AddressLine1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets AddressLine2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.AddressLine2, Id = Index.AddressLine2, FieldType = EntityFieldType.Char, Size = 60)]
 		public string AddressLine2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets AddressLine3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.AddressLine3, Id = Index.AddressLine3, FieldType = EntityFieldType.Char, Size = 60)]
 		public string AddressLine3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets AddressLine4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.AddressLine4, Id = Index.AddressLine4, FieldType = EntityFieldType.Char, Size = 60)]
 		public string AddressLine4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets City 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.City, Id = Index.City, FieldType = EntityFieldType.Char, Size = 30)]
 		public string City {get; set;}
		 
  		/// <summary>
        /// Gets or sets State 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.State, Id = Index.State, FieldType = EntityFieldType.Char, Size = 30)]
 		public string State {get; set;}
		 
  		/// <summary>
        /// Gets or sets Country 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Country, Id = Index.Country, FieldType = EntityFieldType.Char, Size = 30)]
 		public string Country {get; set;}
		 
  		/// <summary>
        /// Gets or sets ZipOrPostalCode 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.ZipOrPostalCode, Id = Index.ZipOrPostalCode, FieldType = EntityFieldType.Char, Size = 20)]
 		public string ZipOrPostalCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets Contact 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Contact, Id = Index.Contact, FieldType = EntityFieldType.Char, Size = 60)]
 		public string Contact {get; set;}
		 
  		/// <summary>
        /// Gets or sets PhoneNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.PhoneNumber, Id = Index.PhoneNumber, FieldType = EntityFieldType.Char, Size = 30)]
 		public string PhoneNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30)]
 		public string FaxNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets TransitNumber 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TransitNumber, Id = Index.TransitNumber, FieldType = EntityFieldType.Char, Size = 12)]
 		public string TransitNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets MulticurrencySwitch 
        /// </summary>
        
 		[ViewField(Name = Fields.MulticurrencySwitch, Id = Index.MulticurrencySwitch, FieldType = EntityFieldType.Bool, Size = 2)]
 		public bool MulticurrencySwitch {get; set;}
		 
  		/// <summary>
        /// Gets or sets StatementCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.StatementCurrency, Id = Index.StatementCurrency, FieldType = EntityFieldType.Char, Size = 3)]
 		public string StatementCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets InactiveSwitch 
        /// </summary>
        
 		[ViewField(Name = Fields.InactiveSwitch, Id = Index.InactiveSwitch, FieldType = EntityFieldType.Bool, Size = 2)]
 		public bool InactiveSwitch {get; set;}
		
		/// <summary>
        /// Gets or sets DateInactived 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.DateInactived, Id = Index.DateInactived, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime DateInactived {get; set;}
	 
  		/// <summary>
        /// Gets or sets BankAccountNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.BankAccountNumber, Id = Index.BankAccountNumber, FieldType = EntityFieldType.Char, Size = 22)]
 		public string BankAccountNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankGLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankGLAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankErrorGLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string BankErrorGLAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets ErrorSpread 
        /// </summary>
        
 		[ViewField(Name = Fields.ErrorSpread, Id = Index.ErrorSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ErrorSpread {get; set;}
		
		/// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime LastMaintained {get; set;}
	 
  		/// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
 		public string FiscalYear {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
 		public int FiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets LastFiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.LastFiscalYear, Id = Index.LastFiscalYear, FieldType = EntityFieldType.Char, Size = 4)]
 		public string LastFiscalYear {get; set;}
		 
  		/// <summary>
        /// Gets or sets LastFiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.LastFiscalPeriod, Id = Index.LastFiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
 		public int LastFiscalPeriod {get; set;}
		
		/// <summary>
        /// Gets or sets LastReconciliationDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.LastReconciliationDate, Id = Index.LastReconciliationDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime LastReconciliationDate {get; set;}
	 
  		/// <summary>
        /// Gets or sets LastClosingStatementBalance 
        /// </summary>
        
 		[ViewField(Name = Fields.LastClosingStatementBalance, Id = Index.LastClosingStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal LastClosingStatementBalance {get; set;}
		
		/// <summary>
        /// Gets or sets ReconciliationDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.ReconciliationDate, Id = Index.ReconciliationDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime ReconciliationDate {get; set;}
	
		/// <summary>
        /// Gets or sets StatementDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.StatementDate, Id = Index.StatementDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime StatementDate {get; set;}
	 
  		/// <summary>
        /// Gets or sets ClosingStatementBalance 
        /// </summary>
        
 		[ViewField(Name = Fields.ClosingStatementBalance, Id = Index.ClosingStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ClosingStatementBalance {get; set;}
		 
  		/// <summary>
        /// Gets or sets DepositsinTransit 
        /// </summary>
        
 		[ViewField(Name = Fields.DepositsinTransit, Id = Index.DepositsinTransit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal DepositsinTransit {get; set;}
		 
  		/// <summary>
        /// Gets or sets ChecksOutstanding 
        /// </summary>
        
 		[ViewField(Name = Fields.ChecksOutstanding, Id = Index.ChecksOutstanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ChecksOutstanding {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankErrorPendingAmount 
        /// </summary>
        
 		[ViewField(Name = Fields.BankErrorPendingAmount, Id = Index.BankErrorPendingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal BankErrorPendingAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankEntriesAmount 
        /// </summary>
        
 		[ViewField(Name = Fields.BankEntriesAmount, Id = Index.BankEntriesAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal BankEntriesAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankErrorAmount 
        /// </summary>
        
 		[ViewField(Name = Fields.BankErrorAmount, Id = Index.BankErrorAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal BankErrorAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeAmountGained 
        /// </summary>
        
 		[ViewField(Name = Fields.ExchangeAmountGained, Id = Index.ExchangeAmountGained, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ExchangeAmountGained {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeAmountLost 
        /// </summary>
        
 		[ViewField(Name = Fields.ExchangeAmountLost, Id = Index.ExchangeAmountLost, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ExchangeAmountLost {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDeposits 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDeposits, Id = Index.TotalDeposits, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDeposits {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalChecks 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalChecks, Id = Index.TotalChecks, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalChecks {get; set;}
		 
  		/// <summary>
        /// Gets or sets DepositsToFiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.DepositsToFiscalPeriod, Id = Index.DepositsToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal DepositsToFiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets ChecksToFiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.ChecksToFiscalPeriod, Id = Index.ChecksToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ChecksToFiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets DepositsInTransitToFiscalPe 
        /// </summary>
        
 		[ViewField(Name = Fields.DepositsInTransitToFiscalPe, Id = Index.DepositsInTransitToFiscalPe, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal DepositsInTransitToFiscalPe {get; set;}
		 
  		/// <summary>
        /// Gets or sets ChecksOutstandingToFiscalPer 
        /// </summary>
        
 		[ViewField(Name = Fields.ChecksOutstandingToFiscalPer, Id = Index.ChecksOutstandingToFiscalPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ChecksOutstandingToFiscalPer {get; set;}
		 
  		/// <summary>
        /// Gets or sets RecalculateFiscalPeriodData 
        /// </summary>
        
 		[ViewField(Name = Fields.RecalculateFiscalPeriodData, Id = Index.RecalculateFiscalPeriodData, FieldType = EntityFieldType.Bool, Size = 2)]
 		public bool RecalculateFiscalPeriodData {get; set;}
		 
  		/// <summary>
        /// Gets or sets AdjustedBookBalance 
        /// </summary>
        
 		[ViewField(Name = Fields.AdjustedBookBalance, Id = Index.AdjustedBookBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal AdjustedBookBalance {get; set;}
		 
  		/// <summary>
        /// Gets or sets AdjustedStatementBalance 
        /// </summary>
        
 		[ViewField(Name = Fields.AdjustedStatementBalance, Id = Index.AdjustedStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal AdjustedStatementBalance {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankReconciliationBalanced 
        /// </summary>
        
 		[ViewField(Name = Fields.BankReconciliationBalanced, Id = Index.BankReconciliationBalanced, FieldType = EntityFieldType.Bool, Size = 2)]
 		public bool BankReconciliationBalanced {get; set;}
		 
  		/// <summary>
        /// Gets or sets AdjustedBalanceDifference 
        /// </summary>
        
 		[ViewField(Name = Fields.AdjustedBalanceDifference, Id = Index.AdjustedBalanceDifference, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal AdjustedBalanceDifference {get; set;}
		 
  		/// <summary>
        /// Gets or sets NextCheckSerialNumber 
        /// </summary>
        
 		[ViewField(Name = Fields.NextCheckSerialNumber, Id = Index.NextCheckSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
 		public long NextCheckSerialNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets NextDepositNumber 
        /// </summary>
        
 		[ViewField(Name = Fields.NextDepositNumber, Id = Index.NextDepositNumber, FieldType = EntityFieldType.Decimal, Size = 8)]
 		public decimal NextDepositNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets NextDepositSerialNumber 
        /// </summary>
        
 		[ViewField(Name = Fields.NextDepositSerialNumber, Id = Index.NextDepositSerialNumber, FieldType = EntityFieldType.LongLong, Size = 8)]
 		public long NextDepositSerialNumber {get; set;}
		 
  		/// <summary>
        /// Gets or sets CurrentBalance 
        /// </summary>
        
 		[ViewField(Name = Fields.CurrentBalance, Id = Index.CurrentBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal CurrentBalance {get; set;}
		 
  		/// <summary>
        /// Gets or sets ReconciliationBookBalance 
        /// </summary>
        
 		[ViewField(Name = Fields.ReconciliationBookBalance, Id = Index.ReconciliationBookBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ReconciliationBookBalance {get; set;}
		
		/// <summary>
        /// Gets or sets LastStatementDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.LastStatementDate, Id = Index.LastStatementDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime LastStatementDate {get; set;}
	 
  		/// <summary>
        /// Gets or sets BankEntriesToFiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.BankEntriesToFiscalPeriod, Id = Index.BankEntriesToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal BankEntriesToFiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeGainToFiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.ExchangeGainToFiscalPeriod, Id = Index.ExchangeGainToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ExchangeGainToFiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeLossToFiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.ExchangeLossToFiscalPeriod, Id = Index.ExchangeLossToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ExchangeLossToFiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankErrorPendingToFiscalPer 
        /// </summary>
        
 		[ViewField(Name = Fields.BankErrorPendingToFiscalPer, Id = Index.BankErrorPendingToFiscalPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal BankErrorPendingToFiscalPer {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankErrorToFiscalPeriod 
        /// </summary>
        
 		[ViewField(Name = Fields.BankErrorToFiscalPeriod, Id = Index.BankErrorToFiscalPeriod, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal BankErrorToFiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets ReconciledEntriesToFiscalPer 
        /// </summary>
        
 		[ViewField(Name = Fields.ReconciledEntriesToFiscalPer, Id = Index.ReconciledEntriesToFiscalPer, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ReconciledEntriesToFiscalPer {get; set;}
		 
  		/// <summary>
        /// Gets or sets CreditCardChargeGOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		public string CreditCardChargeGLAccount {get; set;}
		 
  		/// <summary>
        /// Gets or sets CreditCardChargeSpread 
        /// </summary>
        
 		[ViewField(Name = Fields.CreditCardChargeSpread, Id = Index.CreditCardChargeSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal CreditCardChargeSpread {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExchangeRateDifferenceSpread 
        /// </summary>
        
 		[ViewField(Name = Fields.ExchangeRateDifferenceSpread, Id = Index.ExchangeRateDifferenceSpread, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ExchangeRateDifferenceSpread {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWithdrawalBankErrors 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWithdrawalBankErrors, Id = Index.TotalWithdrawalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWithdrawalBankErrors {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWithdrawalWriteOffs 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWithdrawalWriteOffs, Id = Index.TotalWithdrawalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWithdrawalWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWithdrawalExchangeGain 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWithdrawalExchangeGain, Id = Index.TotalWithdrawalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWithdrawalExchangeGain {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWithdrawalExchangeLoss 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWithdrawalExchangeLoss, Id = Index.TotalWithdrawalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWithdrawalExchangeLoss {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWithdrawalCreditCardCha 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWithdrawalCreditCardCha, Id = Index.TotalWithdrawalCreditCardCha, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWithdrawalCreditCardCha {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWithdrawalCleared 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWithdrawalCleared, Id = Index.TotalWithdrawalCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWithdrawalCleared {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWithdrawalFunctionalAmou 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWithdrawalFunctionalAmou, Id = Index.TotalWithdrawalFunctionalAmou, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWithdrawalFunctionalAmou {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalWithdrawalBankErrors 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalWithdrawalBankErrors, Id = Index.FiscalWithdrawalBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalWithdrawalBankErrors {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalWithdrawalWriteOffs 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalWithdrawalWriteOffs, Id = Index.FiscalWithdrawalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalWithdrawalWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalWithdrawalExchangeGain 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalWithdrawalExchangeGain, Id = Index.FiscalWithdrawalExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalWithdrawalExchangeGain {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalWithdrawalExchangeLoss 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalWithdrawalExchangeLoss, Id = Index.FiscalWithdrawalExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalWithdrawalExchangeLoss {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalWithdrawalCreditCardCh 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalWithdrawalCreditCardCh, Id = Index.FiscalWithdrawalCreditCardCh, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalWithdrawalCreditCardCh {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalWithdrawalCleared 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalWithdrawalCleared, Id = Index.FiscalWithdrawalCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalWithdrawalCleared {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalWithdrawalFunctionalAmo 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalWithdrawalFunctionalAmo, Id = Index.FiscalWithdrawalFunctionalAmo, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalWithdrawalFunctionalAmo {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDepositBankErrors 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDepositBankErrors, Id = Index.TotalDepositBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDepositBankErrors {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDepositWriteOffs 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDepositWriteOffs, Id = Index.TotalDepositWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDepositWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDepositExchangeGain 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDepositExchangeGain, Id = Index.TotalDepositExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDepositExchangeGain {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDepositExchangeLoss 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDepositExchangeLoss, Id = Index.TotalDepositExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDepositExchangeLoss {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDepositCreditCardCharge 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDepositCreditCardCharge, Id = Index.TotalDepositCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDepositCreditCardCharge {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDepositCleared 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDepositCleared, Id = Index.TotalDepositCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDepositCleared {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalDepositFunctionalAmounts 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalDepositFunctionalAmounts, Id = Index.TotalDepositFunctionalAmounts, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalDepositFunctionalAmounts {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalDepositBankErrors 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalDepositBankErrors, Id = Index.FiscalDepositBankErrors, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalDepositBankErrors {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalDepositWriteOffs 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalDepositWriteOffs, Id = Index.FiscalDepositWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalDepositWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalDepositExchangeGain 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalDepositExchangeGain, Id = Index.FiscalDepositExchangeGain, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalDepositExchangeGain {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalDepositExchangeLoss 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalDepositExchangeLoss, Id = Index.FiscalDepositExchangeLoss, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalDepositExchangeLoss {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalDepositCreditCardCharg 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalDepositCreditCardCharg, Id = Index.FiscalDepositCreditCardCharg, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalDepositCreditCardCharg {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalDepositCleared 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalDepositCleared, Id = Index.FiscalDepositCleared, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalDepositCleared {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalDepositFunctionalAmount 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalDepositFunctionalAmount, Id = Index.FiscalDepositFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalDepositFunctionalAmount {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankStatementType 
        /// </summary>
        
 		[ViewField(Name = Fields.BankStatementType, Id = Index.BankStatementType, FieldType = EntityFieldType.Int, Size = 2)]
 		public int BankStatementType {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalWriteOffs 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalWriteOffs, Id = Index.TotalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets TotalCreditCardCharges 
        /// </summary>
        
 		[ViewField(Name = Fields.TotalCreditCardCharges, Id = Index.TotalCreditCardCharges, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal TotalCreditCardCharges {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalPeriodWriteOff 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalPeriodWriteOff, Id = Index.FiscalPeriodWriteOff, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalPeriodWriteOff {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalPeriodCreditCardCharge 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalPeriodCreditCardCharge, Id = Index.FiscalPeriodCreditCardCharge, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalPeriodCreditCardCharge {get; set;}
		 
  		/// <summary>
        /// Gets or sets SumofWithdrawalTotalWriteOf 
        /// </summary>
        
 		[ViewField(Name = Fields.SumofWithdrawalTotalWriteOf, Id = Index.SumofWithdrawalTotalWriteOf, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal SumofWithdrawalTotalWriteOf {get; set;}
		 
  		/// <summary>
        /// Gets or sets SumofDepositTotalWriteOffs 
        /// </summary>
        
 		[ViewField(Name = Fields.SumofDepositTotalWriteOffs, Id = Index.SumofDepositTotalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal SumofDepositTotalWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets SumofWithdrawalFiscalWriteO 
        /// </summary>
        
 		[ViewField(Name = Fields.SumofWithdrawalFiscalWriteO, Id = Index.SumofWithdrawalFiscalWriteO, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal SumofWithdrawalFiscalWriteO {get; set;}
		 
  		/// <summary>
        /// Gets or sets SumofDepositFiscalWriteOffs 
        /// </summary>
        
 		[ViewField(Name = Fields.SumofDepositFiscalWriteOffs, Id = Index.SumofDepositFiscalWriteOffs, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal SumofDepositFiscalWriteOffs {get; set;}
		 
  		/// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FunctionalCurrency, Id = Index.FunctionalCurrency, FieldType = EntityFieldType.Char, Size = 3)]
 		public string FunctionalCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets BankSequence 
        /// </summary>
        
 		[ViewField(Name = Fields.BankSequence, Id = Index.BankSequence, FieldType = EntityFieldType.Long, Size = 4)]
 		public long BankSequence {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxGroupCode 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxGroupCode, Id = Index.TaxGroupCode, FieldType = EntityFieldType.Char, Size = 12)]
 		public string TaxGroupCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxAuthorization1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxAuthorization1, Id = Index.TaxAuthorization1, FieldType = EntityFieldType.Char, Size = 12)]
 		public string TaxAuthorization1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxAuthorization2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxAuthorization2, Id = Index.TaxAuthorization2, FieldType = EntityFieldType.Char, Size = 12)]
 		public string TaxAuthorization2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxAuthorization3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxAuthorization3, Id = Index.TaxAuthorization3, FieldType = EntityFieldType.Char, Size = 12)]
 		public string TaxAuthorization3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxAuthorization4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxAuthorization4, Id = Index.TaxAuthorization4, FieldType = EntityFieldType.Char, Size = 12)]
 		public string TaxAuthorization4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxAuthorization5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxAuthorization5, Id = Index.TaxAuthorization5, FieldType = EntityFieldType.Char, Size = 12)]
 		public string TaxAuthorization5 {get; set;}
		 
  		/// <summary>
        /// Gets or sets VendorTaxClass1 
        /// </summary>
        
 		[ViewField(Name = Fields.VendorTaxClass1, Id = Index.VendorTaxClass1, FieldType = EntityFieldType.Int, Size = 2)]
 		public int VendorTaxClass1 {get; set;}
		 
  		/// <summary>
        /// Gets or sets VendorTaxClass2 
        /// </summary>
        
 		[ViewField(Name = Fields.VendorTaxClass2, Id = Index.VendorTaxClass2, FieldType = EntityFieldType.Int, Size = 2)]
 		public int VendorTaxClass2 {get; set;}
		 
  		/// <summary>
        /// Gets or sets VendorTaxClass3 
        /// </summary>
        
 		[ViewField(Name = Fields.VendorTaxClass3, Id = Index.VendorTaxClass3, FieldType = EntityFieldType.Int, Size = 2)]
 		public int VendorTaxClass3 {get; set;}
		 
  		/// <summary>
        /// Gets or sets VendorTaxClass4 
        /// </summary>
        
 		[ViewField(Name = Fields.VendorTaxClass4, Id = Index.VendorTaxClass4, FieldType = EntityFieldType.Int, Size = 2)]
 		public int VendorTaxClass4 {get; set;}
		 
  		/// <summary>
        /// Gets or sets VendorTaxClass5 
        /// </summary>
        
 		[ViewField(Name = Fields.VendorTaxClass5, Id = Index.VendorTaxClass5, FieldType = EntityFieldType.Int, Size = 2)]
 		public int VendorTaxClass5 {get; set;}
		 
  		/// <summary>
        /// Gets or sets WithdrawalsClearedToCurrent 
        /// </summary>
        
 		[ViewField(Name = Fields.WithdrawalsClearedToCurrent, Id = Index.WithdrawalsClearedToCurrent, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal WithdrawalsClearedToCurrent {get; set;}
		 
  		/// <summary>
        /// Gets or sets DepositsClearedToCurrent 
        /// </summary>
        
 		[ViewField(Name = Fields.DepositsClearedToCurrent, Id = Index.DepositsClearedToCurrent, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal DepositsClearedToCurrent {get; set;}
		
		/// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime PostingDate {get; set;}
	
		/// <summary>
        /// Gets or sets LastReconciliationPostingDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.LastReconciliationPostingDate, Id = Index.LastReconciliationPostingDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime LastReconciliationPostingDate {get; set;}
	 
  		/// <summary>
        /// Gets or sets DefaultReconciliationDescripti 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DefaultReconciliationDescripti, Id = Index.DefaultReconciliationDescripti, FieldType = EntityFieldType.Char, Size = 60)]
 		public string DefaultReconciliationDescripti {get; set;}
		 
  		/// <summary>
        /// Gets or sets ChecksClearedwithExchRateD 
        /// </summary>
        
 		[ViewField(Name = Fields.ChecksClearedwithExchRateD, Id = Index.ChecksClearedwithExchRateD, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal ChecksClearedwithExchRateD {get; set;}
		 
  		/// <summary>
        /// Gets or sets DepositClearedwithExchangeRa 
        /// </summary>
        
 		[ViewField(Name = Fields.DepositClearedwithExchangeRa, Id = Index.DepositClearedwithExchangeRa, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal DepositClearedwithExchangeRa {get; set;}
		 
  		/// <summary>
        /// Gets or sets LastAvailableStatementBalance 
        /// </summary>
        
 		[ViewField(Name = Fields.LastAvailableStatementBalance, Id = Index.LastAvailableStatementBalance, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal LastAvailableStatementBalance {get; set;}
		 
  		/// <summary>
        /// Gets or sets WithdrawalsClearedToFuture 
        /// </summary>
        
 		[ViewField(Name = Fields.WithdrawalsClearedToFuture, Id = Index.WithdrawalsClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal WithdrawalsClearedToFuture {get; set;}
		 
  		/// <summary>
        /// Gets or sets DepositsClearedToFuture 
        /// </summary>
        
 		[ViewField(Name = Fields.DepositsClearedToFuture, Id = Index.DepositsClearedToFuture, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal DepositsClearedToFuture {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalRemainingOutStanding 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalRemainingOutStanding, Id = Index.FiscalRemainingOutStanding, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalRemainingOutStanding {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalRemainingInTransit 
        /// </summary>
        
 		[ViewField(Name = Fields.FiscalRemainingInTransit, Id = Index.FiscalRemainingInTransit, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal FiscalRemainingInTransit {get; set;}
		    }
}
