/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using System;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class represents a Model for Bank Entry Detail
    /// </summary>
    public partial class BankEntryDetail : ModelBase
    {

        /// <summary>
        /// Gets or sets SequenceNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "SequenceNumber", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.SequenceNumber, Id = Index.SequenceNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long SequenceNumber { get; set; }

        /// <summary>
        /// Gets or sets LineNumber 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "LineNumber", ResourceType = typeof(BankDistributionSetsResx))]
        [ViewField(Name = Fields.LineNumber, Id = Index.LineNumber, FieldType = EntityFieldType.Long, Size = 4)]
        public long LineNumber { get; set; }

        /// <summary>
        /// Gets or sets Bank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "Bank", ResourceType = typeof(BKCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Bank, Id = Index.Bank, FieldType = EntityFieldType.Char, Size = 8)]
        public string Bank { get; set; }


        /// <summary>
        /// Gets or sets POSTDATE 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.POSTDATE, Id = Index.POSTDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime POSTDATE { get; set; }

        /// <summary>
        /// Gets or sets DistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DISTCODE", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.DistributionCode, Id = Index.DistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DistributionCode { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntReferenceFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Reference, Id = Index.Reference, FieldType = EntityFieldType.Char, Size = 60)]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntCommentFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Amount 
        /// </summary>
        [Display(Name = "AMOUNT", ResourceType = typeof(BankDistributionSetsResx))]   
        [ViewField(Name = Fields.Amount, Id = Index.Amount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal Amount { get; set; }

        /// <summary>
        /// Gets or sets SourceAmount 
        /// </summary>
        [Display(Name = "SourceAmount", ResourceType = typeof(ReverseTransactionsResx))]
        [ViewField(Name = Fields.SourceAmount, Id = Index.SourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal SourceAmount { get; set; }

        /// <summary>
        /// Gets or sets RATETYPE 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RATETYPE, Id = Index.RATETYPE, FieldType = EntityFieldType.Char, Size = 2)]
        public string RATETYPE { get; set; }


        /// <summary>
        /// Gets or sets SRCECURN 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.SRCECURN, Id = Index.SRCECURN, FieldType = EntityFieldType.Char, Size = 3)]
        public string SRCECURN { get; set; }

        /// <summary>
        /// Gets or sets RATEDATE 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateDate", ResourceType = typeof(BankEntryResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.RATEDATE, Id = Index.RATEDATE, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime RATEDATE { get; set; }

        /// <summary>
        /// Gets or sets RATE 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RATE, Id = Index.RATE, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RATE { get; set; }

        /// <summary>
        /// Gets or sets RATESPREAD 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RATESPREAD, Id = Index.RATESPREAD, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal RATESPREAD { get; set; }

        /// <summary>
        /// Gets or sets RATEOP 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.RATEOP, Id = Index.RATEOP, FieldType = EntityFieldType.Int, Size = 2)]
        public int RATEOP { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GlaccountFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.GOrLAccount, Id = Index.GOrLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string GOrLAccount { get; set; }

        /// <summary>
        /// Gets or sets EntryType 
        /// </summary>
        [Display(Name = "EntryType", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.EntryType, Id = Index.EntryType, FieldType = EntityFieldType.Int, Size = 2)]
        public SubmissionType EntryType { get; set; }

        /// <summary>
        /// Gets or sets Comments 
        /// </summary>
        [StringLength(250, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EntBigcommentFLD", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Comments, Id = Index.Comments, FieldType = EntityFieldType.Char, Size = 250)]
        public string Comments { get; set; }

        /// <summary>
        /// Gets or sets StatementAmount 
        /// </summary>
        [Display(Name = "StatementAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.StatementAmount, Id = Index.StatementAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal StatementAmount { get; set; }

        /// <summary>
        /// Gets or sets GrossSourceAmount 
        /// </summary>
        [Display(Name = "GrossSourceAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.GrossSourceAmount, Id = Index.GrossSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal GrossSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets GrossAmount 
        /// </summary>
        [Display(Name = "GrossAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.GrossAmount, Id = Index.GrossAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal GrossAmount { get; set; }

        /// <summary>
        /// Gets or sets DistributionCodeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "DISTCODEDESC", ResourceType = typeof(BankEntryResx))]
        [ViewField(Name = Fields.DistributionCodeDescription, Id = Index.DistributionCodeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DistributionCodeDescription { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccountDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "GLAccountDesc", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.GOrLAccountDescription, Id = Index.GOrLAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string GOrLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets Line 
        /// </summary>
        [Display(Name = "Line", ResourceType = typeof(BKCommonResx))]
        [IgnoreExportImport]
        [ViewField(Name = Fields.Line, Id = Index.Line, FieldType = EntityFieldType.Long, Size = 4)]
        public long Line { get; set; }

        /// <summary>
        /// Gets or sets SetDefaultSetupValues 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.SetDefaultSetupValues, Id = Index.SetDefaultSetupValues, FieldType = EntityFieldType.Int, Size = 2)]
        public int SetDefaultSetupValues { get; set; }

        /// <summary>
        /// Gets or sets CallforCreateDistribution 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.CallforCreateDistribution, Id = Index.CallforCreateDistribution, FieldType = EntityFieldType.Int, Size = 2)]
        public int CallforCreateDistribution { get; set; }

        /// <summary>
        /// Gets or sets Taxable 
        /// </summary>
        [Display(Name = "Taxable", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.Taxable, Id = Index.Taxable, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable Taxable { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountCalculation 
        /// </summary>
        [Display(Name = "TaxAmountCalculation", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAmountCalculation, Id = Index.TaxAmountCalculation, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxAmountCalculation { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority1 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority1", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.TaxAuthority1, Id = Index.TaxAuthority1, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority2 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority2", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.TaxAuthority2, Id = Index.TaxAuthority2, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority3 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority3", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.TaxAuthority3, Id = Index.TaxAuthority3, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority4 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority4", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.TaxAuthority4, Id = Index.TaxAuthority4, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthority5 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthority5", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.TaxAuthority5, Id = Index.TaxAuthority5, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority5 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass1 
        /// </summary>
        [Display(Name = "TaxVendorClass1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxVendorClass1, Id = Index.TaxVendorClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxVendorClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass2 
        /// </summary>
        [Display(Name = "TaxVendorClass2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxVendorClass2, Id = Index.TaxVendorClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxVendorClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass3 
        /// </summary>
        [Display(Name = "TaxVendorClass3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxVendorClass3, Id = Index.TaxVendorClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxVendorClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass4 
        /// </summary>
        [Display(Name = "TaxVendorClass4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxVendorClass4, Id = Index.TaxVendorClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxVendorClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxVendorClass5 
        /// </summary>
        [Display(Name = "TaxVendorClass5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxVendorClass5, Id = Index.TaxVendorClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxVendorClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass1 
        /// </summary>
        [Display(Name = "TaxItemClass1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxItemClass1, Id = Index.TaxItemClass1, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxItemClass1 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass2 
        /// </summary>
        [Display(Name = "TaxItemClass2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxItemClass2, Id = Index.TaxItemClass2, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxItemClass2 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass3 
        /// </summary>
        [Display(Name = "TaxItemClass3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxItemClass3, Id = Index.TaxItemClass3, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxItemClass3 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass4 
        /// </summary>
        [Display(Name = "TaxItemClass4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxItemClass4, Id = Index.TaxItemClass4, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxItemClass4 { get; set; }

        /// <summary>
        /// Gets or sets TaxItemClass5 
        /// </summary>
        [Display(Name = "TaxItemClass5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxItemClass5, Id = Index.TaxItemClass5, FieldType = EntityFieldType.Int, Size = 2)]
        public int TaxItemClass5 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclude1 
        /// </summary>
        [Display(Name = "TaxIncluded1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxInclude1, Id = Index.TaxInclude1, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxInclude1 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclude2 
        /// </summary>
        [Display(Name = "TaxIncluded2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxInclude2, Id = Index.TaxInclude2, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxInclude2 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclude3 
        /// </summary>
        [Display(Name = "TaxIncluded3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxInclude3, Id = Index.TaxInclude3, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxInclude3 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclude4 
        /// </summary>
        [Display(Name = "TaxIncluded4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxInclude4, Id = Index.TaxInclude4, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxInclude4 { get; set; }

        /// <summary>
        /// Gets or sets TaxInclude5 
        /// </summary>
        [Display(Name = "TaxIncluded5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxInclude5, Id = Index.TaxInclude5, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxInclude5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount1 
        /// </summary>
        [Display(Name = "TaxBaseAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxBaseAmount1, Id = Index.TaxBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount2 
        /// </summary>
        [Display(Name = "TaxBaseAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxBaseAmount2, Id = Index.TaxBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount3 
        /// </summary>
        [Display(Name = "TaxBaseAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxBaseAmount3, Id = Index.TaxBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount4 
        /// </summary>
        [Display(Name = "TaxBaseAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxBaseAmount4, Id = Index.TaxBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseAmount5 
        /// </summary>
        [Display(Name = "TaxBaseAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxBaseAmount5, Id = Index.TaxBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseCalculationMethod 
        /// </summary>
        [Display(Name = "TaxBaseCalculationMethod", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxBaseCalculationMethod, Id = Index.TaxBaseCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxBaseCalculationMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount1 
        /// </summary>
        [Display(Name = "TaxAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAmount1, Id = Index.TaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount2 
        /// </summary>
        [Display(Name = "TaxAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAmount2, Id = Index.TaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount3 
        /// </summary>
        [Display(Name = "TaxAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAmount3, Id = Index.TaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount4 
        /// </summary>
        [Display(Name = "TaxAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAmount4, Id = Index.TaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAmount5 
        /// </summary>
        [Display(Name = "TaxAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAmount5, Id = Index.TaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxableAMount 
        /// </summary>
        [Display(Name = "TaxableAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxableAMount, Id = Index.TaxableAMount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxableAMount { get; set; }

        /// <summary>
        /// Gets or sets NonTaxableAmount 
        /// </summary>
        [Display(Name = "NonTaxableAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.NonTaxableAmount, Id = Index.NonTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NonTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TaxTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DocumentTotalBeforeTax 
        /// </summary>
        [Display(Name = "DocumentTotalBeforeTax", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DocumentTotalBeforeTax, Id = Index.DocumentTotalBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentTotalBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets DocumentTotalIncludingTax 
        /// </summary>
        [Display(Name = "DocumentTotalIncludingTax", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.DocumentTotalIncludingTax, Id = Index.DocumentTotalIncludingTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentTotalIncludingTax { get; set; }

        /// <summary>
        /// Gets or sets TaxDistributionamount 
        /// </summary>
        [Display(Name = "TaxDistributionAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxDistributionamount, Id = Index.TaxDistributionamount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxDistributionamount { get; set; }

        /// <summary>
        /// Gets or sets TotalIncludedAmount 
        /// </summary>
        [Display(Name = "TotalIncludedAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalIncludedAmount, Id = Index.TotalIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxNetDistributionAmount 
        /// </summary>
        [Display(Name = "TaxNetDistributionAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxNetDistributionAmount, Id = Index.TaxNetDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxNetDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalExcludedAmount 
        /// </summary>
        [Display(Name = "TotalExcludedAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalExcludedAmount, Id = Index.TotalExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxGrossDistributionAmount 
        /// </summary>
        [Display(Name = "TaxGrossAmt", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxGrossDistributionAmount, Id = Index.TaxGrossDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxGrossDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1 
        /// </summary>
        [Display(Name = "TaxExpenseAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2 
        /// </summary>
        [Display(Name = "TaxExpenseAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3 
        /// </summary>
        [Display(Name = "TaxExpenseAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4 
        /// </summary>
        [Display(Name = "TaxExpenseAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5 
        /// </summary>
        [Display(Name = "TaxExpenseAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1 
        /// </summary>
        [Display(Name = "TaxRecoverableAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2 
        /// </summary>
        [Display(Name = "TaxRecoverableAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3 
        /// </summary>
        [Display(Name = "TaxRecoverableAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4 
        /// </summary>
        [Display(Name = "TaxRecoverableAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5 
        /// </summary>
        [Display(Name = "TaxRecoverableAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5 
        /// </summary>
        [Display(Name = "TaxAllocatedAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAllocatedAmount 
        /// </summary>
        [Display(Name = "TotalTaxAllocatedAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalTaxAllocatedAmount, Id = Index.TotalTaxAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>
        [Display(Name = "TaxReportingAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>
        [Display(Name = "TaxReportingAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>
        [Display(Name = "TaxReportingAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>
        [Display(Name = "TaxReportingAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>
        [Display(Name = "TaxReportingAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed1 
        /// </summary>
        [Display(Name = "TaxReportingExpensed1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingExpensed1, Id = Index.TaxReportingExpensed1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed2 
        /// </summary>
        [Display(Name = "TaxReportingExpensed2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingExpensed2, Id = Index.TaxReportingExpensed2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed3 
        /// </summary>
        [Display(Name = "TaxReportingExpensed3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingExpensed3, Id = Index.TaxReportingExpensed3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed4 
        /// </summary>
        [Display(Name = "TaxReportingExpensed4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingExpensed4, Id = Index.TaxReportingExpensed4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed5 
        /// </summary>
        [Display(Name = "TaxReportingExpensed5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingExpensed5, Id = Index.TaxReportingExpensed5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed5 { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB1RC 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TXRECVB1RC, Id = Index.TXRECVB1RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB1RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB2RC 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TXRECVB2RC, Id = Index.TXRECVB2RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB2RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB3RC 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TXRECVB3RC, Id = Index.TXRECVB3RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB3RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB4RC 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TXRECVB4RC, Id = Index.TXRECVB4RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB4RC { get; set; }

        /// <summary>
        /// Gets or sets TXRECVB5RC 
        /// </summary>
        [Display(Name = "TaxReportingRecoverableAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TXRECVB5RC, Id = Index.TXRECVB5RC, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TXRECVB5RC { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5 
        /// </summary>
        [Display(Name = "TaxReportingAllocatedAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxReportingAllocatedAm 
        /// </summary>
        [Display(Name = "TotalTaxReportingAllocatedAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalTaxReportingAllocatedAm, Id = Index.TotalTaxReportingAllocatedAm, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxReportingAllocatedAm { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxReportingAmount 
        /// </summary>
        [Display(Name = "TotalTaxReportingAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalTaxReportingAmount, Id = Index.TotalTaxReportingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxReportingAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalNetofTax 
        /// </summary>
        [Display(Name = "FunctionalNetofTax", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalNetofTax, Id = Index.FunctionalNetofTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalNetofTax { get; set; }

        /// <summary>
        /// Gets or sets FunctionalGrossDistributionAm 
        /// </summary>
        [Display(Name = "FunctionalGrossDistributionAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalGrossDistributionAm, Id = Index.FunctionalGrossDistributionAm, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalGrossDistributionAm { get; set; }

        /// <summary>
        /// Gets or sets TaxVersion 
        /// </summary>
        [Display(Name = "TaxVersion", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxVersion, Id = Index.TaxVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxVersion { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationReportingMethod 
        /// </summary>
        [Display(Name = "TaxCalculationReportingMethod", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxCalculationReportingMethod, Id = Index.TaxCalculationReportingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxCalculationReportingMethod { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyCode", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRate 
        /// </summary>
        [Display(Name = "TaxReportingRate", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingRate, Id = Index.TaxReportingRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateType", ResourceType = typeof(TaxGroupsResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateDate", ResourceType = typeof(InvoiceResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation 
        /// </summary>
        [Display(Name = "TaxReportingRateOperation", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxReportingRateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount1 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAccount1, Id = Index.TaxExpenseAccount1, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount2 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAccount2, Id = Index.TaxExpenseAccount2, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount3 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAccount3, Id = Index.TaxExpenseAccount3, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount4 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAccount4, Id = Index.TaxExpenseAccount4, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount5 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxExpenseAccount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxExpenseAccount5, Id = Index.TaxExpenseAccount5, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount1 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAccount1, Id = Index.TaxRecoverableAccount1, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount2 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAccount2, Id = Index.TaxRecoverableAccount2, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount3 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAccount3, Id = Index.TaxRecoverableAccount3, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount4 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAccount4, Id = Index.TaxRecoverableAccount4, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount5 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRecoverableAccount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRecoverableAccount5, Id = Index.TaxRecoverableAccount5, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1 
        /// </summary>
        [Display(Name = "TaxRate1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2 
        /// </summary>
        [Display(Name = "TaxRate2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3 
        /// </summary>
        [Display(Name = "TaxRate3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4 
        /// </summary>
        [Display(Name = "TaxRate4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5 
        /// </summary>
        [Display(Name = "TaxRate5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxProcessCommand 
        /// </summary>
        [Display(Name = "TaxProcessCommand", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxProcessCommand, Id = Index.TaxProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxProcessCommand TaxProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorityDescription1, Id = Index.TaxAuthorityDescription1, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorityDescription2, Id = Index.TaxAuthorityDescription2, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorityDescription3, Id = Index.TaxAuthorityDescription3, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorityDescription4, Id = Index.TaxAuthorityDescription4, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription5 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxAuthorityDescription5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAuthorityDescription5, Id = Index.TaxAuthorityDescription5, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription5 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription1, Id = Index.VendorTaxClassDescription1, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription1 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription2, Id = Index.VendorTaxClassDescription2, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription2 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription3, Id = Index.VendorTaxClassDescription3, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription3 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription4, Id = Index.VendorTaxClassDescription4, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription4 { get; set; }

        /// <summary>
        /// Gets or sets VendorTaxClassDescription5 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "VendorTaxClassDescription5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.VendorTaxClassDescription5, Id = Index.VendorTaxClassDescription5, FieldType = EntityFieldType.Char, Size = 60)]
        public string VendorTaxClassDescription5 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClassDescription1 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemTaxClassDescription1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ItemTaxClassDescription1, Id = Index.ItemTaxClassDescription1, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemTaxClassDescription1 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClassDescription2 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemTaxClassDescription2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ItemTaxClassDescription2, Id = Index.ItemTaxClassDescription2, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemTaxClassDescription2 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClassDescription3 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemTaxClassDescription3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ItemTaxClassDescription3, Id = Index.ItemTaxClassDescription3, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemTaxClassDescription3 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClassDescription4 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemTaxClassDescription4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ItemTaxClassDescription4, Id = Index.ItemTaxClassDescription4, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemTaxClassDescription4 { get; set; }

        /// <summary>
        /// Gets or sets ItemTaxClassDescription5 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "ItemTaxClassDescription5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ItemTaxClassDescription5, Id = Index.ItemTaxClassDescription5, FieldType = EntityFieldType.Char, Size = 60)]
        public string ItemTaxClassDescription5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount1 
        /// </summary>
        [Display(Name = "FunctionalTaxAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxAmount1, Id = Index.FunctionalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount2 
        /// </summary>
        [Display(Name = "FunctionalTaxAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxAmount2, Id = Index.FunctionalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount3 
        /// </summary>
        [Display(Name = "FunctionalTaxAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxAmount3, Id = Index.FunctionalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount4 
        /// </summary>
        [Display(Name = "FunctionalTaxAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxAmount4, Id = Index.FunctionalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount5 
        /// </summary>
        [Display(Name = "FunctionalTaxAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxAmount5, Id = Index.FunctionalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount1 
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxBaseAmount1, Id = Index.FunctionalTaxBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount2 
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxBaseAmount2, Id = Index.FunctionalTaxBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount3 
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxBaseAmount3, Id = Index.FunctionalTaxBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount4 
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxBaseAmount4, Id = Index.FunctionalTaxBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount5 
        /// </summary>
        [Display(Name = "FunctionalTaxBaseAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxBaseAmount5, Id = Index.FunctionalTaxBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxTotal 
        /// </summary>
        [Display(Name = "FunctionalTaxTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTaxTotal, Id = Index.FunctionalTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount1 
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalExpensedAmount1, Id = Index.FunctionalExpensedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount2 
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalExpensedAmount2, Id = Index.FunctionalExpensedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount3 
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalExpensedAmount3, Id = Index.FunctionalExpensedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount4 
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalExpensedAmount4, Id = Index.FunctionalExpensedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount5 
        /// </summary>
        [Display(Name = "FunctionalExpensedAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalExpensedAmount5, Id = Index.FunctionalExpensedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount1 
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalRecoverableAmount1, Id = Index.FunctionalRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount2 
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalRecoverableAmount2, Id = Index.FunctionalRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount3 
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalRecoverableAmount3, Id = Index.FunctionalRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount4 
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalRecoverableAmount4, Id = Index.FunctionalRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount5 
        /// </summary>
        [Display(Name = "FunctionalRecoverableAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalRecoverableAmount5, Id = Index.FunctionalRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount1 
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount1", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalAllocatedAmount1, Id = Index.FunctionalAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount2 
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount2", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalAllocatedAmount2, Id = Index.FunctionalAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount3 
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount3", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalAllocatedAmount3, Id = Index.FunctionalAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount4 
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount4", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalAllocatedAmount4, Id = Index.FunctionalAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount5 
        /// </summary>
        [Display(Name = "FunctionalAllocatedAmount5", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalAllocatedAmount5, Id = Index.FunctionalAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTotalTaxAllocated 
        /// </summary>
        [Display(Name = "FunctionalTotalTaxAllocated", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.FunctionalTotalTaxAllocated, Id = Index.FunctionalTotalTaxAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTotalTaxAllocated { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyDescripti 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingCurrencyDescripti", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyDescripti, Id = Index.TaxReportingCurrencyDescripti, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingCurrencyDescripti { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateTypeDescripti  
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxReportingRateTypeDescripti", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingRateTypeDescripti, Id = Index.TaxReportingRateTypeDescripti, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingRateTypeDescripti { get; set; }

        /// <summary>
        /// Sets and Gets Enumerable Response of TaxGroupAuthority
        /// </summary>
        public EnumerableResponse<TaxGroupAuthority> TaxGroupAuthority { get; set; }

        /// <summary>
        /// Gets or Sets CalculateTaxAmount
        /// </summary>
        /// <value>Boolean</value>
        [Display(Name = "TaxCalcAmount", ResourceType = typeof(BKCommonResx))]
        public bool CalculateTaxAmount { get; set; }

        /// <summary>
        /// Gets or Sets CalculateBaseAmount
        /// </summary>
        /// <value>Boolean</value>
        [Display(Name = "TaxBaseCalc", ResourceType = typeof(BKCommonResx))]
        public bool CalculateBaseAmount { get; set; }

        /// <summary>
        /// Gets or sets CalculateTaxReporting
        /// </summary>
        [Display(Name = "TaxReptCalc", ResourceType = typeof(BKCommonResx))]
        public bool CalculateTaxReporting { get; set; }

        /// <summary>
        /// Get or set for MultiCurrency
        /// </summary>
        public bool IsMultiCurrrency { get; set; }

        /// <summary>
        /// Get or set for Taxable Changed
        /// </summary>
        public bool TaxableChanged { get; set; }

        /// <summary>
        /// Get or set for Tax Reporting Currency Code Decimal.
        /// </summary>
        public string TaxReportingCurrencyCodeDecimal { get; set; }

    }
}
