/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;
using FiscalPeriod = Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.FiscalPeriod;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class Tax Tracking
    /// </summary>
	public partial class TaxTracking : ModelBase
	{
  
  		/// <summary>
        /// Gets or sets Sequence  
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))][Key]
 		[ViewField(Name = Fields.Sequence, Id = Index.Sequence, FieldType = EntityFieldType.Decimal, Size = 10)]
 		public decimal Sequence {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
 		public string TaxAuthority {get; set;}
		 
  		/// <summary>
        /// Gets or sets TransactionType 
        /// </summary>        
 		[ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
 		public TransactionType TransactionType {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
 		public string FiscalYear {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>        
 		[ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
 		public FiscalPeriod FiscalPeriod {get; set;}
		 
  		/// <summary>
        /// Gets or sets CustomerOrVendorID 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.CustomerOrVendorID, Id = Index.CustomerOrVendorID, FieldType = EntityFieldType.Char, Size = 12)]
 		public string CustomerOrVendorID {get; set;}
		 
  		/// <summary>
        /// Gets or sets DocumentDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DocumentDate, Id = Index.DocumentDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string DocumentDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets SourceApplication 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.SourceApplication, Id = Index.SourceApplication, FieldType = EntityFieldType.Char, Size = 2)]
 		public string SourceApplication {get; set;}
		 
  		/// <summary>
        /// Gets or sets DocumentType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DocumentType, Id = Index.DocumentType, FieldType = EntityFieldType.Char, Size = 2)]
 		public string DocumentType {get; set;}
		 
  		/// <summary>
        /// Gets or sets DocumentNo 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.DocumentNo, Id = Index.DocumentNo, FieldType = EntityFieldType.Char, Size = 22)]
 		public string DocumentNo {get; set;}
		 
  		/// <summary>
        /// Gets or sets PostingDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.PostingDate, Id = Index.PostingDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string PostingDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets CustOrVendTaxClass 
        /// </summary>        
 		[ViewField(Name = Fields.CustOrVendTaxClass, Id = Index.CustOrVendTaxClass, FieldType = EntityFieldType.Int, Size = 2)]
 		public int CustOrVendTaxClass {get; set;}
		 
  		/// <summary>
        /// Gets or sets CountryCode 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.CountryCode, Id = Index.CountryCode, FieldType = EntityFieldType.Char, Size = 30)]
 		public string CountryCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets ReportDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.ReportDate, Id = Index.ReportDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string ReportDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.Description, Id = Index.Description, FieldType = EntityFieldType.Char, Size = 60)]
 		public string Description {get; set;}
		 
  		/// <summary>
        /// Gets or sets ForeignInvoice 
        /// </summary>
 		[ViewField(Name = Fields.ForeignInvoice, Id = Index.ForeignInvoice, FieldType = EntityFieldType.Bool, Size = 2)]
 		public long ForeignInvoice {get; set;}
		 
  		/// <summary>
        /// Gets or sets HomeCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.HomeCurrencyCode, Id = Index.HomeCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
 		public string HomeCurrencyCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets RateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.RateType, Id = Index.RateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
 		public string RateType {get; set;}
		 
  		/// <summary>
        /// Gets or sets SourceCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.SourceCurrencyCode, Id = Index.SourceCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
 		public string SourceCurrencyCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets RateDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.RateDate, Id = Index.RateDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string RateDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets Rate 
        /// </summary>
 		[ViewField(Name = Fields.Rate, Id = Index.Rate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
 		public decimal Rate {get; set;}
		 
  		/// <summary>
        /// Gets or sets CustomerOrVendorName 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.CustomerOrVendorName, Id = Index.CustomerOrVendorName, FieldType = EntityFieldType.Char, Size = 60)]
 		public string CustomerOrVendorName {get; set;}
		 
  		/// <summary>
        /// Gets or sets DecimalsinSourceCurrency 
        /// </summary>
 		[ViewField(Name = Fields.DecimalsinSourceCurrency, Id = Index.DecimalsinSourceCurrency, FieldType = EntityFieldType.Int, Size = 2)]
 		public int DecimalsinSourceCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets InvoiceAmtinSourceCurrency 
        /// </summary>
 		[ViewField(Name = Fields.InvoiceAmtinSourceCurrency, Id = Index.InvoiceAmtinSourceCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal InvoiceAmtinSourceCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets InvoiceAmtinFuncCurrency 
        /// </summary>        
 		[ViewField(Name = Fields.InvoiceAmtinFuncCurrency, Id = Index.InvoiceAmtinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal InvoiceAmtinFuncCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets Recoverable 
        /// </summary>        
 		[ViewField(Name = Fields.Recoverable, Id = Index.Recoverable, FieldType = EntityFieldType.Bool, Size = 2)]
 		public long Recoverable {get; set;}
		 
  		/// <summary>
        /// Gets or sets ExpenseSeparately 
        /// </summary>        
 		[ViewField(Name = Fields.ExpenseSeparately, Id = Index.ExpenseSeparately, FieldType = EntityFieldType.Bool, Size = 2)]
 		public long ExpenseSeparately {get; set;}
		 
  		/// <summary>
        /// Gets or sets RecoverableRate 
        /// </summary>        
 		[ViewField(Name = Fields.RecoverableRate, Id = Index.RecoverableRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
 		public decimal RecoverableRate {get; set;}
		 
  		/// <summary>
        /// Gets or sets RecovAmtinSourceCurrency 
        /// </summary>        
 		[ViewField(Name = Fields.RecovAmtinSourceCurrency, Id = Index.RecovAmtinSourceCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal RecovAmtinSourceCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets RecovAmtinFuncCurrency 
        /// </summary>        
 		[ViewField(Name = Fields.RecovAmtinFuncCurrency, Id = Index.RecovAmtinFuncCurrency, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal RecovAmtinFuncCurrency {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
 		public string TaxReportingCurrencyCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets DecimalsinTaxReportingCurren 
        /// </summary>        
 		[ViewField(Name = Fields.DecimalsinTaxReportingCurren, Id = Index.DecimalsinTaxReportingCurren, FieldType = EntityFieldType.Int, Size = 2)]
 		public int DecimalsinTaxReportingCurren {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
 		public string TaxReportingRateType {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
 		public string TaxReportingRateDate {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxReportingRate 
        /// </summary>        
 		[ViewField(Name = Fields.TaxReportingRate, Id = Index.TaxReportingRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
 		public decimal TaxReportingRate {get; set;}
		 
  		/// <summary>
        /// Gets or sets RateOperation 
        /// </summary>        
 		[ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
 		public RateOperation RateOperation {get; set;}
		 
  		/// <summary>
        /// Gets or sets TaxReportingRateOperation 
        /// </summary>        
 		[ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
 		public RateOperation TaxReportingRateOperation {get; set;}
		 
  		/// <summary>
        /// Gets or sets RecovAmtinTaxReportingCurr 
        /// </summary>        
 		[ViewField(Name = Fields.RecovAmtinTaxReportingCurr, Id = Index.RecovAmtinTaxReportingCurr, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
 		public decimal RecovAmtinTaxReportingCurr {get; set;}
		
    }
}
