﻿// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Contains list of properties of CurrencyCodes
    /// </summary>
    public partial class CurrencyCodes : ModelBase
    {
        /// <summary>
        /// Gets or sets CurrencyCode 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        public string CurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Symbol 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string Symbol { get; set; }

        /// <summary>
        /// Gets or sets DecimalPlaces 
        /// </summary>
        public DecimalPlaces DecimalPlaces { get; set; }

        /// <summary>
        /// To get the string of DecimalPlaces property
        /// </summary>
        public string DecimalPlacesString
        {
            get { return EnumUtility.GetStringValue(DecimalPlaces); }
        }

        /// <summary>
        /// Gets or sets SymbolPosition 
        /// </summary>
        public SymbolPosition SymbolPosition { get; set; }

        /// <summary>
        /// To get the string of SymbolPosition property
        /// </summary>
        public string SymbolPositionString
        {
            get { return EnumUtility.GetStringValue(SymbolPosition); }
        }

        /// <summary>
        /// Gets or sets ThousandsSeparator 
        /// </summary>
        public ThousandsSeparator ThousandsSeparator { get; set; }

        /// <summary>
        /// To get the string of ThousandsSeparator property
        /// </summary>
        public string ThousandsSeparatorString
        {
            get { return EnumUtility.GetStringValue(ThousandsSeparator); }
        }

        /// <summary>
        /// Gets or sets DecimalSeparator 
        /// </summary>
        public DecimalSeparator DecimalSeparator { get; set; }

        /// <summary>
        /// To get the string of DecimalSeparator property
        /// </summary>
        public string DecimalSeparatorString
        {
            get { return EnumUtility.GetStringValue(DecimalSeparator); }
        }

        /// <summary>
        /// Gets or sets NegativeDisplay 
        /// </summary>
        public NegativeDisplay NegativeDisplay { get; set; }

        /// <summary>
        /// To get the string of NegativeDisplay property
        /// </summary>
        public string NegativeDisplayString
        {
            get { return EnumUtility.GetStringValue(NegativeDisplay); }
        }
    }
}