// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class BankOptions : ModelBase
    {
        /// <summary>
        /// Gets or sets BankOption 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BankOption", ResourceType = typeof (BankOptionsResx))]
        [Key]
        [ViewField(Name = Fields.BankOption, Id = Index.BankOption, FieldType = EntityFieldType.Char, Size = 4)]
        public string BankOption { get; set; }

        /// <summary>
        /// Gets or sets NextPostingSequence 
        /// </summary>
        [Display(Name = "NextPostingSequence", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.NextPostingSequence, Id = Index.NextPostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal NextPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets CreateGLBatches 
        /// </summary>
        [ViewField(Name = Fields.CreateGLBatches, Id = Index.CreateGLBatches, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool CreateGLBatches { get; set; }

        /// <summary>
        /// Gets or sets Consolidate GL Batches 
        /// </summary>
        [ViewField(Name = Fields.ConsolidateGLBatches, Id = Index.ConsolidateGLBatches, FieldType = EntityFieldType.Int, Size = 2)]
        public ConsolidateGLBatches ConsolidateGLBatches { get; set; }

        /// <summary>
        /// Gets or sets CreateGLTransactionsBy 
        /// </summary>
        [ViewField(Name = Fields.CreateGLTransactionsBy, Id = Index.CreateGLTransactionsBy, FieldType = EntityFieldType.Int, Size = 2)]
        public CreateGLTransactionsBy CreateGLTransactionsBy { get; set; }

        /// <summary>
        /// Gets or sets TransferAdjustmentGLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TfradjustmentGlaccountLABEL", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.TransferAdjustmentGLAccount, Id = Index.TransferAdjustmentGLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TransferAdjustmentGLAccount { get; set; }

        /// <summary>
        /// Gets or sets NextBankTransferNumber 
        /// </summary>
        [Display(Name = "TfradjustmentGlaccountLABEL", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.NextBankTransferNumber, Id = Index.NextBankTransferNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextBankTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets SuppressUnmatchedOFXPosting 
        /// </summary>
        public long SuppressUnmatchedOfxPosting { get; set; }

        /// <summary>
        /// Gets or sets ContactName 
        /// </summary>
        [Display(Name = "ContactnameLABEL", ResourceType = typeof (BankOptionsResx))]
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.ContactName, Id = Index.ContactName, FieldType = EntityFieldType.Char, Size = 60)]
        public string ContactName { get; set; }

        /// <summary>
        /// Gets or sets Telephone 
        /// </summary>
        [Display(Name = "TelephoneLABEL", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.Telephone, Id = Index.Telephone, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string Telephone { get; set; }

        /// <summary>
        /// Gets or sets FaxNumber 
        /// </summary>
        [Display(Name = "FaxnumberLABEL", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.FaxNumber, Id = Index.FaxNumber, FieldType = EntityFieldType.Char, Size = 30, Mask = "(%-3C) %-3C-%-24C")]
        public string FaxNumber { get; set; }

        /// <summary>
        /// Gets or sets DefaultBankCode 
        /// </summary>
        [Display(Name = "DefbankcodeLABEL", ResourceType = typeof (BankOptionsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [RegularExpression(@"^[A-Z0-9]+$", ErrorMessageResourceName = "AlphaNumeric",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DefaultBankCode, Id = Index.DefaultBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string DefaultBankCode { get; set; }

        /// <summary>
        /// Gets or sets ClearinFuturePeriodlist 
        /// </summary>
        [Display(Name = "RecoptionClrperiodLABEL", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.ClearinFuturePeriodlist, Id = Index.ClearinFuturePeriodlist, FieldType = EntityFieldType.Int, Size = 2)]
        public ClearinFuturePeriodlist ClearinFuturePeriodlist { get; set; }

        /// <summary>
        /// Gets or sets DepositWriteOffMethod 
        /// </summary>
        [Display(Name = "DepositWriteOffMethod", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.DepositWriteOffMethod, Id = Index.DepositWriteOffMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public DepositWriteOffMethod DepositWriteOffMethod { get; set; }

        /// <summary>
        /// Gets or sets DefaultDistributionCode 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TransferserviceDistcodeLABEL", ResourceType = typeof (BankOptionsResx))]
        [RegularExpression(@"^([A-Z0-9]+)$", ErrorMessageResourceType = typeof (AnnotationsResx),
            ErrorMessageResourceName = "AlphaNumeric")]
        [ViewField(Name = Fields.DefaultDistributionCode, Id = Index.DefaultDistributionCode, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string DefaultDistributionCode { get; set; }

        /// <summary>
        /// Gets or sets Cloud Company GUID
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.BankingCloudCompany, Id = Index.BankingCloudCompany, FieldType = EntityFieldType.Byte, Size = 32)]
        public byte[] BankingCloudCompany { get; set; }

        /// <summary>
        /// Gets or sets DefaultGLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TransferserviceAccountLABEL", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.DefaultGLAccount, Id = Index.DefaultGLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string DefaultGLAccount { get; set; }

        /// <summary>
        /// Gets or sets BankTransferPrefix 
        /// </summary>
        [Display(Name = "BankTransferPrefix", ResourceType = typeof (BankOptionsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.BankTransferPrefix, Id = Index.BankTransferPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string BankTransferPrefix { get; set; }

        /// <summary>
        /// Gets or sets BankTransferLength 
        /// </summary>
        [Display(Name = "BankTransferLength", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.BankTransferLength, Id = Index.BankTransferLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal BankTransferLength { get; set; }

        /// <summary>
        /// Gets or sets BankEntryPrefix 
        /// </summary>
        [Display(Name = "BankEntryPrefix", ResourceType = typeof (BankOptionsResx))]
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.BankEntryPrefix, Id = Index.BankEntryPrefix, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6C")]
        public string BankEntryPrefix { get; set; }

        /// <summary>
        /// Gets or sets BankEntryLength 
        /// </summary>
        [Display(Name = "BankEntryLength", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.BankEntryLength, Id = Index.BankEntryLength, FieldType = EntityFieldType.Decimal, Size = 2)]
        public decimal BankEntryLength { get; set; }

        /// <summary>
        /// Gets or sets NextBankEntryNumber 
        /// </summary>
        [Display(Name = "NextBankEntryNumber", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.NextBankEntryNumber, Id = Index.NextBankEntryNumber, FieldType = EntityFieldType.Decimal, Size = 10)]
        public decimal NextBankEntryNumber { get; set; }

        /// <summary>
        /// Gets or sets NextBankTransferDocSeq 
        /// </summary>
        [Display(Name = "NextBankTransferDocSeq", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.NextBankTransferDocSeq, Id = Index.NextBankTransferDocSeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextBankTransferDocSeq { get; set; }

        /// <summary>
        /// Gets or sets NextBankEntryDocSeq 
        /// </summary>
        [Display(Name = "NextBankEntryDocSeq", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.NextBankEntryDocSeq, Id = Index.NextBankEntryDocSeq, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextBankEntryDocSeq { get; set; }

        /// <summary>
        /// Gets or sets ReconcileList 
        /// </summary>
        [Display(Name = "ReconcileList", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.ReconcileList, Id = Index.ReconcileList, FieldType = EntityFieldType.Int, Size = 2)]
        public ReconcileList ReconcileList { get; set; }

        /// <summary>
        /// Gets or sets NextRunId 
        /// </summary>
        [Display(Name = "NextRunId", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.NextRunId, Id = Index.NextRunId, FieldType = EntityFieldType.Long, Size = 4)]
        public long NextRunId { get; set; }

        /// <summary>
        /// Gets or sets DefaultReconcileDetailSortBy 
        /// </summary>
        [Display(Name = "DetailSortByLABEL", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.DefaultReconcileDetailSortBy, Id = Index.DefaultReconcileDetailSortBy, FieldType = EntityFieldType.Int, Size = 2)]
        public DefaultReconcileDetailSortBy DefaultReconcileDetailSortBy { get; set; }

        /// <summary>
        /// Gets or sets TransferAdjAccountDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "GlaccountdFLD", ResourceType = typeof (BKCommonResx))]
        [ViewField(Name = Fields.TransferAdjAccountDesc, Id = Index.TransferAdjAccountDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransferAdjAccountDesc { get; set; }

        /// <summary>
        /// Gets or sets DefaultDistributionCodeDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "DefaultDistCodeDesc", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.DefaultDistributionCodeDesc, Id = Index.DefaultDistributionCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultDistributionCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets DefaultGLAccountDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "GrdBKTFRHColAcctdescCap", ResourceType = typeof (BKCommonResx))]
        [ViewField(Name = Fields.DefaultGLAccountDescription, Id = Index.DefaultGLAccountDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultGLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets DefaultBankCodeDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "BankCodeDesc", ResourceType = typeof (BankOptionsResx))]
        [ViewField(Name = Fields.DefaultBankCodeDesc, Id = Index.DefaultBankCodeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string DefaultBankCodeDesc { get; set; }

        /// <summary>
        /// Gets or sets DefaultGLDistributionAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [ViewField(Name = Fields.DefaultGLDistributionAccount, Id = Index.DefaultGLDistributionAccount, FieldType = EntityFieldType.Char, Size = 45)]
        public string DefaultGLDistributionAccount { get; set; }

        /// <summary>
        /// Gets or sets DefaultDistCodeError 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DefaultDistCodeError, Id = Index.DefaultDistCodeError, FieldType = EntityFieldType.Bool, Size = 2)]
        public long DefaultDistCodeError { get; set; }

        /// <summary>
        /// Gets or sets DefaultAccountError 
        /// </summary>
        [IgnoreExportImport]
        [ViewField(Name = Fields.DefaultAccountError, Id = Index.DefaultAccountError, FieldType = EntityFieldType.Bool, Size = 2)]
        public long DefaultAccountError { get; set; }
    }
}
