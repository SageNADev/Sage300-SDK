// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using CSModels = Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
	public partial class BankReconciliationPosting : ModelBase
	{
	 
  		/// <summary>
        /// Gets or sets PostingOperation 
        /// </summary>
        
 		[ViewField(Name = Fields.PostingOperation, Id = Index.PostingOperation, FieldType = EntityFieldType.Int, Size = 2)]
 		public PostingOperation PostingOperation {get; set;}
		 
  		/// <summary>
        /// Gets or sets BeginningBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.BeginningBankCode, Id = Index.BeginningBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
 		public string BeginningBankCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets EndingBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.EndingBankCode, Id = Index.EndingBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
 		public string EndingBankCode {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))]
 		[ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%04D")]
 		public string FiscalYear {get; set;}
		 
  		/// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>

        [ViewField(Name = Fields.FiscalPeriod, Id = Index.FiscalPeriod, FieldType = EntityFieldType.Int, Size = 2)]
        public CSModels.FiscalPeriod FiscalPeriod { get; set; }
		
		/// <summary>
        /// Gets or sets ThroughDate 
        /// </summary>
         [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]		
		 [ViewField(Name = Fields.ThroughDate, Id = Index.ThroughDate, FieldType = EntityFieldType.Date, Size = 5)]
		 public DateTime ThroughDate {get; set;}
	    }
}
