// /* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    public partial class BankProcessControl : ModelBase
    {
        /// <summary>
        /// Gets or sets BankProcess 
        /// </summary>
        [ViewField(Name = Fields.BankProcess, Id = Index.BankProcess, FieldType = EntityFieldType.Int, Size = 2)]
        public BankProcess BankProcess { get; set; }

        /// <summary>
        /// Gets or sets ProcessStatus 
        /// </summary>
        [ViewField(Name = Fields.ProcessStatus, Id = Index.ProcessStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public ProcessStatus ProcessStatus { get; set; }
    }
}
