﻿/* Copyright (c) 2024 The Sage Group plc or its licensors.  All rights reserved. */

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Partial class for Employee
    /// </summary>
    public partial class Employee : ModelBase
    {
        /// <summary>
        /// Gets or sets RecordNumber
        /// </summary>
        [Key]
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public long RecordNumber { get; set; }

        /// <summary>
        /// Gets or sets OriginalModule
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "OriginalModule", ResourceType = typeof(SageHRResx))]
        public string OriginalModule { get; set; }

        /// <summary>
        /// Gets or sets EmployeeIDERP
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "EmployeeIDERP", ResourceType = typeof(SageHRResx))]
        public string EmployeeIDERP { get; set; }

        /// <summary>
        /// Gets or sets EmployeeIDSageHR
        /// </summary>
        [StringLength(36, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string EmployeeIDSageHR { get; set; }

        /// <summary>
        /// Gets or sets SageIDEmail
        /// </summary>
        [StringLength(200, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "SageIDEmail", ResourceType = typeof(SageHRResx))]
        public string SageIDEmail { get; set; }

        /// <summary>
        /// Gets or sets InviteToSageHR
        /// </summary>
        public InviteToSageHR InviteToSageHR { get; set; }

        /// <summary>
        /// Gets or sets SyncStatus
        /// </summary>
        public SyncStatus SyncStatus { get; set; }

        /// <summary>
        /// Gets or sets SelectedForUnsyncing
        /// </summary>
        [Display(Name = "SelectedForUnsyncing", ResourceType = typeof(SageHRResx))]
        public SelectedForSyncing SelectedForUnsyncing { get; set; }

        /// <summary>
        /// Gets or sets ProcessCommandCode
        /// </summary>
        public ProcessCommandCode ProcessCommandCode { get; set; }

        /// <summary>
        /// Gets or sets FullName
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FullName", ResourceType = typeof(SageHRResx))]
        public string FullName { get; set; }

        /// <summary>
        /// Gets or sets HireDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime HireDate { get; set; }

        /// <summary>
        /// Gets or sets TerminationDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime TerminationDate { get; set; }

        /// <summary>
        /// Gets or sets Status
        /// </summary>
        public int Status { get; set; }

        /// <summary>
        /// Gets or sets Position
        /// </summary>
        [StringLength(25, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Position { get; set; }

        /// <summary>
        /// Gets or sets FirstName
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FirstName { get; set; }

        /// <summary>
        /// Gets or sets MiddleName
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string MiddleName { get; set; }

        /// <summary>
        /// Gets or sets LastName
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string LastName { get; set; }

        /// <summary>
        /// Gets or sets BirthDate
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime BirthDate { get; set; }

        /// <summary>
        /// Gets or sets AddressLine1
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AddressLine1 { get; set; }

        /// <summary>
        /// Gets or sets AddressLine2
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AddressLine2 { get; set; }

        /// <summary>
        /// Gets or sets StateProvince
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string StateProvince { get; set; }

        /// <summary>
        /// Gets or sets City
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string City { get; set; }

        /// <summary>
        /// Gets or sets ZIPCode
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ZIPCode { get; set; }

        /// <summary>
        /// Gets or sets CountryCode
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CountryCode { get; set; }

        /// <summary>
        /// Gets or sets Phone
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Phone { get; set; }

        /// <summary>
        /// Gets or sets Email
        /// </summary>
        [StringLength(50, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Email { get; set; }

        
    }
}

