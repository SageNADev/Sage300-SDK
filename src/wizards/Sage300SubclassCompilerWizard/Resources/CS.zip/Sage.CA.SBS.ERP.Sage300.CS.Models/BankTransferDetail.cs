/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is Bank Transfers Details Entity
    /// </summary>
    public partial class BankTransferDetail : ModelBase
    {
        /// <summary>
        /// Gets or sets TransferNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.TransferNumber, Id = Index.TransferNumber, FieldType = EntityFieldType.Char, Size = 22, Mask = "%-22C")]
        public string TransferNumber { get; set; }

        /// <summary>
        /// Gets or sets ChargeLine 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [ViewField(Name = Fields.ChargeLine, Id = Index.ChargeLine, FieldType = EntityFieldType.Int, Size = 2)]
        public ChargeLine ChargeLine { get; set; }

        /// <summary>
        /// Gets or sets ChargeTransactionType 
        /// </summary>
        [StringLength(6, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ChargeTransactionType, Id = Index.ChargeTransactionType, FieldType = EntityFieldType.Char, Size = 6, Mask = "%-6N")]
        public string ChargeTransactionType { get; set; }

        /// <summary>
        /// Gets or sets ChargeGOrLAccount 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ChargeGLAccount, Id = Index.ChargeGLAccount, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string ChargeGLAccount { get; set; }

        /// <summary>
        /// Gets or sets ChargeSourceAmount 
        /// </summary>
        [ViewField(Name = Fields.ChargeSourceAmount, Id = Index.ChargeSourceAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChargeSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets ChargeFunctionalAmount 
        /// </summary>
        [ViewField(Name = Fields.ChargeFunctionalAmount, Id = Index.ChargeFunctionalAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal ChargeFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets PostTransferCharge? 
        /// </summary>
        [ViewField(Name = Fields.PostTransferCharge, Id = Index.PostTransferCharge, FieldType = EntityFieldType.Bool, Size = 2)]
        public long PostTransferCharge { get; set; }

        /// <summary>
        /// Gets or sets ChargeBank 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxCalcAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.ChargeBank, Id = Index.ChargeBank, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string ChargeBank { get; set; }

        /// <summary>
        /// Gets or sets ChargeSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ChargeSourceCurrency, Id = Index.ChargeSourceCurrency, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string ChargeSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ExchangeRateType, Id = Index.ExchangeRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string ExchangeRateType { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRateDate 
        /// </summary>
        [ViewField(Name = Fields.ExchangeRateDate, Id = Index.ExchangeRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime ExchangeRateDate { get; set; }

        /// <summary>
        /// Gets or sets ExchangeRate 
        /// </summary>
        [ViewField(Name = Fields.ExchangeRate, Id = Index.ExchangeRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal ExchangeRate { get; set; }

        /// <summary>
        /// Gets or sets RateOperation 
        /// </summary>
        [ViewField(Name = Fields.RateOperation, Id = Index.RateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation RateOperation { get; set; }

        /// <summary>
        /// Gets or sets TransferBankChargeCurrDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.TransferBankChargeCurrDesc, Id = Index.TransferBankChargeCurrDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TransferBankChargeCurrDesc { get; set; }

        /// <summary>
        /// Gets or sets ChargeTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ChargeTypeDescription, Id = Index.ChargeTypeDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ChargeTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets ChargeGLDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ChargeGLDescription, Id = Index.ChargeGLDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string ChargeGLDescription { get; set; }

        /// <summary>
        /// Gets or sets Taxable 
        /// </summary>
        [ViewField(Name = Fields.Taxable, Id = Index.Taxable, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable Taxable { get; set; }

        /// <summary>
        /// Gets or sets TaxAmountCalculation 
        /// </summary>
        [Display(Name = "TaxCalcAmount", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxAmountCalculation, Id = Index.TaxAmountCalculation, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxAmountCalculation { get; set; }

        /// <summary>
        /// Gets or Sets CalculateTaxAmount
        /// </summary>
        /// <value>Boolean</value>
        [Display(Name = "TaxCalcAmount", ResourceType = typeof(BKCommonResx))]
        public bool CalculateTaxAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxGroup 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroup", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxGroup, Id = Index.TaxGroup, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxGroup { get; set; }

        /// <summary>
        /// Gets or sets TaxBaseCalculationMethod 
        /// </summary>
        [Display(Name = "TaxBaseCalc", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxBaseCalculationMethod, Id = Index.TaxBaseCalculationMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxBaseCalculationMethod { get; set; }

        /// <summary>
        /// Gets or Sets CalculateBaseAmount
        /// </summary>
        /// <value>Boolean</value>
        [Display(Name = "TaxBaseCalc", ResourceType = typeof(BKCommonResx))]
        public bool CalculateBaseAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxableAmount 
        /// </summary>
        [ViewField(Name = Fields.TaxableAmount, Id = Index.TaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets NonTaxableAmount 
        /// </summary>
        [ViewField(Name = Fields.NonTaxableAmount, Id = Index.NonTaxableAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal NonTaxableAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxTotal 
        /// </summary>
        [Display(Name = "TaxTotal", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxTotal, Id = Index.TaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxTotal { get; set; }

        /// <summary>
        /// Gets or sets DocumentTotalBeforeTax 
        /// </summary>
        [ViewField(Name = Fields.DocumentTotalBeforeTax, Id = Index.DocumentTotalBeforeTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentTotalBeforeTax { get; set; }

        /// <summary>
        /// Gets or sets DocumentTotalIncludingTax 
        /// </summary>
        [ViewField(Name = Fields.DocumentTotalIncludingTax, Id = Index.DocumentTotalIncludingTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal DocumentTotalIncludingTax { get; set; }

        /// <summary>
        /// Gets or sets TotalIncludedAmount 
        /// </summary>
        [Display(Name = "TaxInclude", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalIncludedAmount, Id = Index.TotalIncludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalIncludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TotalExcludedAmount 
        /// </summary>
        [Display(Name = "TaxExcluded", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalExcludedAmount, Id = Index.TotalExcludedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalExcludedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxNetDistributionAmount 
        /// </summary>
        [Display(Name = "TaxNet", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxNetDistributionAmount, Id = Index.TaxNetDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxNetDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxDistributionAmount 
        /// </summary>
        [ViewField(Name = Fields.TaxDistributionAmount, Id = Index.TaxDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxGrossDistributionAmount 
        /// </summary>

        [ViewField(Name = Fields.TaxGrossDistributionAmount, Id = Index.TaxGrossDistributionAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxGrossDistributionAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount1 
        /// </summary>

        [ViewField(Name = Fields.TaxExpenseAmount1, Id = Index.TaxExpenseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount2 
        /// </summary>

        [ViewField(Name = Fields.TaxExpenseAmount2, Id = Index.TaxExpenseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount3 
        /// </summary>

        [ViewField(Name = Fields.TaxExpenseAmount3, Id = Index.TaxExpenseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount4 
        /// </summary>

        [ViewField(Name = Fields.TaxExpenseAmount4, Id = Index.TaxExpenseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAmount5 
        /// </summary>

        [ViewField(Name = Fields.TaxExpenseAmount5, Id = Index.TaxExpenseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxExpenseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount1 
        /// </summary>

        [ViewField(Name = Fields.TaxRecoverableAmount1, Id = Index.TaxRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount2 
        /// </summary>

        [ViewField(Name = Fields.TaxRecoverableAmount2, Id = Index.TaxRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount3 
        /// </summary>

        [ViewField(Name = Fields.TaxRecoverableAmount3, Id = Index.TaxRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount4 
        /// </summary>

        [ViewField(Name = Fields.TaxRecoverableAmount4, Id = Index.TaxRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAmount5 
        /// </summary>

        [ViewField(Name = Fields.TaxRecoverableAmount5, Id = Index.TaxRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount1 
        /// </summary>

        [ViewField(Name = Fields.TaxAllocatedAmount1, Id = Index.TaxAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount2 
        /// </summary>

        [ViewField(Name = Fields.TaxAllocatedAmount2, Id = Index.TaxAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount3 
        /// </summary>

        [ViewField(Name = Fields.TaxAllocatedAmount3, Id = Index.TaxAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount4 
        /// </summary>

        [ViewField(Name = Fields.TaxAllocatedAmount4, Id = Index.TaxAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxAllocatedAmount5 
        /// </summary>

        [ViewField(Name = Fields.TaxAllocatedAmount5, Id = Index.TaxAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxAllocatedAmount 
        /// </summary>

        [ViewField(Name = Fields.TotalTaxAllocatedAmount, Id = Index.TotalTaxAllocatedAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxAllocatedAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount1 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAmount1, Id = Index.TaxReportingAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount2 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAmount2, Id = Index.TaxReportingAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount3 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAmount3, Id = Index.TaxReportingAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount4 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAmount4, Id = Index.TaxReportingAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAmount5 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAmount5, Id = Index.TaxReportingAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed1 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingExpensed1, Id = Index.TaxReportingExpensed1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed2 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingExpensed2, Id = Index.TaxReportingExpensed2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed3 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingExpensed3, Id = Index.TaxReportingExpensed3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed4 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingExpensed4, Id = Index.TaxReportingExpensed4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingExpensed5 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingExpensed5, Id = Index.TaxReportingExpensed5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingExpensed5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt1 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingRecoverableAmt1, Id = Index.TaxReportingRecoverableAmt1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt2 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingRecoverableAmt2, Id = Index.TaxReportingRecoverableAmt2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt3 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingRecoverableAmt3, Id = Index.TaxReportingRecoverableAmt3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt4 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingRecoverableAmt4, Id = Index.TaxReportingRecoverableAmt4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRecoverableAmt5 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingRecoverableAmt5, Id = Index.TaxReportingRecoverableAmt5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingRecoverableAmt5 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount1 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAllocatedAmount1, Id = Index.TaxReportingAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount2 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAllocatedAmount2, Id = Index.TaxReportingAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount3 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAllocatedAmount3, Id = Index.TaxReportingAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount4 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAllocatedAmount4, Id = Index.TaxReportingAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingAllocatedAmount5 
        /// </summary>

        [ViewField(Name = Fields.TaxReportingAllocatedAmount5, Id = Index.TaxReportingAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TaxReportingAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxReportingAllocAmt 
        /// </summary>

        [ViewField(Name = Fields.TotalTaxReportingAllocAmt, Id = Index.TotalTaxReportingAllocAmt, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxReportingAllocAmt { get; set; }

        /// <summary>
        /// Gets or sets TotalTaxReportingAmount 
        /// </summary>
        [Display(Name = "TaxTotalRC", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TotalTaxReportingAmount, Id = Index.TotalTaxReportingAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal TotalTaxReportingAmount { get; set; }

        /// <summary>
        /// Gets or sets TaxVersion 
        /// </summary>

        [ViewField(Name = Fields.TaxVersion, Id = Index.TaxVersion, FieldType = EntityFieldType.Long, Size = 4)]
        public long TaxVersion { get; set; }

        /// <summary>
        /// Gets or sets TaxCalculationReportingMethod 
        /// </summary>
        [Display(Name = "TaxReptCalc", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxCalculationReportingMethod, Id = Index.TaxCalculationReportingMethod, FieldType = EntityFieldType.Int, Size = 2)]
        public Taxable TaxCalculationReportingMethod { get; set; }

        /// <summary>
        /// Gets or sets CalculateTaxReporting
        /// </summary>
        [Display(Name = "TaxReptCalc", ResourceType = typeof(BKCommonResx))]
        public bool CalculateTaxReporting { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxCurn", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyCode, Id = Index.TaxReportingCurrencyCode, FieldType = EntityFieldType.Char, Size = 3, Mask = "%-3N")]
        public string TaxReportingCurrencyCode { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRate 
        /// </summary>
        [Display(Name = "TaxRate", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingRate, Id = Index.TaxReportingRate, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxReportingRate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRateType", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingRateType, Id = Index.TaxReportingRateType, FieldType = EntityFieldType.Char, Size = 2, Mask = "%-2N")]
        public string TaxReportingRateType { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateDate 
        /// </summary>
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxRateDate", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxReportingRateDate, Id = Index.TaxReportingRateDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime? TaxReportingRateDate { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateOperation 
        /// </summary>
        [ViewField(Name = Fields.TaxReportingRateOperation, Id = Index.TaxReportingRateOperation, FieldType = EntityFieldType.Int, Size = 2)]
        public RateOperation TaxReportingRateOperation { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount1 
        /// </summary>
        [ViewField(Name = Fields.TaxExpenseAccount1, Id = Index.TaxExpenseAccount1, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount2 
        /// </summary>
        [ViewField(Name = Fields.TaxExpenseAccount2, Id = Index.TaxExpenseAccount2, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount3 
        /// </summary>
        [ViewField(Name = Fields.TaxExpenseAccount3, Id = Index.TaxExpenseAccount3, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount4 
        /// </summary>
        [ViewField(Name = Fields.TaxExpenseAccount4, Id = Index.TaxExpenseAccount4, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxExpenseAccount5 
        /// </summary>
        [ViewField(Name = Fields.TaxExpenseAccount5, Id = Index.TaxExpenseAccount5, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxExpenseAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount1 
        /// </summary>
        [ViewField(Name = Fields.TaxRecoverableAccount1, Id = Index.TaxRecoverableAccount1, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount2 
        /// </summary>
        [ViewField(Name = Fields.TaxRecoverableAccount2, Id = Index.TaxRecoverableAccount2, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount3 
        /// </summary>
        [ViewField(Name = Fields.TaxRecoverableAccount3, Id = Index.TaxRecoverableAccount3, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount4 
        /// </summary>
        [ViewField(Name = Fields.TaxRecoverableAccount4, Id = Index.TaxRecoverableAccount4, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRecoverableAccount5 
        /// </summary>
        [ViewField(Name = Fields.TaxRecoverableAccount5, Id = Index.TaxRecoverableAccount5, FieldType = EntityFieldType.Char, Size = 45, Mask = "%-45C")]
        public string TaxRecoverableAccount5 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate1 
        /// </summary>

        [ViewField(Name = Fields.TaxRate1, Id = Index.TaxRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate1 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate2 
        /// </summary>

        [ViewField(Name = Fields.TaxRate2, Id = Index.TaxRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate2 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate3 
        /// </summary>

        [ViewField(Name = Fields.TaxRate3, Id = Index.TaxRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate3 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate4 
        /// </summary>

        [ViewField(Name = Fields.TaxRate4, Id = Index.TaxRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate4 { get; set; }

        /// <summary>
        /// Gets or sets TaxRate5 
        /// </summary>

        [ViewField(Name = Fields.TaxRate5, Id = Index.TaxRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 7)]
        public decimal TaxRate5 { get; set; }

        /// <summary>
        /// Gets or sets TaxGroupDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "TaxGroupDescription", ResourceType = typeof(BKCommonResx))]
        [ViewField(Name = Fields.TaxGroupDescription, Id = Index.TaxGroupDescription, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxGroupDescription { get; set; }

        /// <summary>
        /// Gets or sets TaxProcessCommand 
        /// </summary>

        [ViewField(Name = Fields.TaxProcessCommand, Id = Index.TaxProcessCommand, FieldType = EntityFieldType.Int, Size = 2)]
        public TaxProcessCommand TaxProcessCommand { get; set; }

        /// <summary>
        /// Gets or sets TaxAuthorityDescription1 
        /// </summary>        
        [ViewField(Name = Fields.TaxAuthorityDescription1, Id = Index.TaxAuthorityDescription1, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxAuthorityDescription1 { get; set; }


        /// <summary>
        /// Gets or sets FunctionalTaxAmount1 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxAmount1, Id = Index.FunctionalTaxAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount2 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxAmount2, Id = Index.FunctionalTaxAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount3 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxAmount3, Id = Index.FunctionalTaxAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount4 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxAmount4, Id = Index.FunctionalTaxAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxAmount5 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxAmount5, Id = Index.FunctionalTaxAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount1 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxBaseAmount1, Id = Index.FunctionalTaxBaseAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount2 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxBaseAmount2, Id = Index.FunctionalTaxBaseAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount3 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxBaseAmount3, Id = Index.FunctionalTaxBaseAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount4 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxBaseAmount4, Id = Index.FunctionalTaxBaseAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxBaseAmount5 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxBaseAmount5, Id = Index.FunctionalTaxBaseAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxBaseAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalNetofTax 
        /// </summary>

        [ViewField(Name = Fields.FunctionalNetofTax, Id = Index.FunctionalNetofTax, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalNetofTax { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTaxTotal 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTaxTotal, Id = Index.FunctionalTaxTotal, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTaxTotal { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount1 
        /// </summary>

        [ViewField(Name = Fields.FunctionalExpensedAmount1, Id = Index.FunctionalExpensedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount2 
        /// </summary>

        [ViewField(Name = Fields.FunctionalExpensedAmount2, Id = Index.FunctionalExpensedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount3 
        /// </summary>

        [ViewField(Name = Fields.FunctionalExpensedAmount3, Id = Index.FunctionalExpensedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount4 
        /// </summary>

        [ViewField(Name = Fields.FunctionalExpensedAmount4, Id = Index.FunctionalExpensedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalExpensedAmount5 
        /// </summary>

        [ViewField(Name = Fields.FunctionalExpensedAmount5, Id = Index.FunctionalExpensedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalExpensedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount1 
        /// </summary>

        [ViewField(Name = Fields.FunctionalRecoverableAmount1, Id = Index.FunctionalRecoverableAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount2 
        /// </summary>

        [ViewField(Name = Fields.FunctionalRecoverableAmount2, Id = Index.FunctionalRecoverableAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount3 
        /// </summary>

        [ViewField(Name = Fields.FunctionalRecoverableAmount3, Id = Index.FunctionalRecoverableAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount4 
        /// </summary>

        [ViewField(Name = Fields.FunctionalRecoverableAmount4, Id = Index.FunctionalRecoverableAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalRecoverableAmount5 
        /// </summary>

        [ViewField(Name = Fields.FunctionalRecoverableAmount5, Id = Index.FunctionalRecoverableAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalRecoverableAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount1 
        /// </summary>

        [ViewField(Name = Fields.FunctionalAllocatedAmount1, Id = Index.FunctionalAllocatedAmount1, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount1 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount2 
        /// </summary>

        [ViewField(Name = Fields.FunctionalAllocatedAmount2, Id = Index.FunctionalAllocatedAmount2, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount2 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount3 
        /// </summary>

        [ViewField(Name = Fields.FunctionalAllocatedAmount3, Id = Index.FunctionalAllocatedAmount3, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount3 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount4 
        /// </summary>

        [ViewField(Name = Fields.FunctionalAllocatedAmount4, Id = Index.FunctionalAllocatedAmount4, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount4 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalAllocatedAmount5 
        /// </summary>

        [ViewField(Name = Fields.FunctionalAllocatedAmount5, Id = Index.FunctionalAllocatedAmount5, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalAllocatedAmount5 { get; set; }

        /// <summary>
        /// Gets or sets FunctionalGrossDistribAmount 
        /// </summary>

        [ViewField(Name = Fields.FunctionalGrossDistribAmount, Id = Index.FunctionalGrossDistribAmount, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalGrossDistribAmount { get; set; }

        /// <summary>
        /// Gets or sets FunctionalTotalTaxAllocated 
        /// </summary>

        [ViewField(Name = Fields.FunctionalTotalTaxAllocated, Id = Index.FunctionalTotalTaxAllocated, FieldType = EntityFieldType.Decimal, Size = 10, Precision = 3)]
        public decimal FunctionalTotalTaxAllocated { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "CurrencyCodeDesription", ResourceType = typeof(CurrencyCodesResx))]
        [ViewField(Name = Fields.TaxReportingCurrencyDesc, Id = Index.TaxReportingCurrencyDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingCurrencyDesc { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingRateTypeDesc 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "RateTypeDesc", ResourceType = typeof(CurrencyRateTypesResx))]
        [ViewField(Name = Fields.TaxReportingRateTypeDesc, Id = Index.TaxReportingRateTypeDesc, FieldType = EntityFieldType.Char, Size = 60)]
        public string TaxReportingRateTypeDesc { get; set; }

        /// <summary>
        /// To get integer value for unique id
        /// </summary>
        public long SerialNumber { get; set; }

        /// <summary>
        /// Sets and Gets Enumerable Response of TaxGroupAuthority
        /// </summary>
        public EnumerableResponse<TaxGroupAuthority> TaxGroupAuthority { get; set; }

        /// <summary>
        /// Gets or sets TaxReportingCurrencyCodeDecimal 
        /// </summary>        
        public string TaxReportingCurrencyCodeDecimal { get; set; }
    }
}
