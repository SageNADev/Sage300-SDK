/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
	public partial class TaxRate :ModelBase//: ModelBase
    {

        /// <summary>
        /// Gets or sets TaxAuthority 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        [Display(Name = "TxAuth", ResourceType = typeof (TaxRatesResx))]
        [ViewField(Name = Fields.TaxAuthority, Id = Index.TaxAuthority, FieldType = EntityFieldType.Char, Size = 12, Mask = "%-12N")]
        public string TaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets TransactionType 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "TransactionType", ResourceType = typeof (TaxRatesResx))]
        [ViewField(Name = Fields.TransactionType, Id = Index.TransactionType, FieldType = EntityFieldType.Int, Size = 2)]
        public TransactionType TransactionType { get; set; }

        /// <summary>
        /// Gets or sets BuyerClass 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Key]
        [Display(Name = "BuyerClass", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.BuyerClass, Id = Index.BuyerClass, FieldType = EntityFieldType.Int, Size = 2)]
        public int BuyerClass { get; set; }

        /// <summary>
        /// Gets or sets ItemRate1 
        /// </summary>
        [Display(Name = "ItemRate1", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate1, Id = Index.ItemRate1, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate1 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate2 
        /// </summary>
        [Display(Name = "ItemRate2", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate2, Id = Index.ItemRate2, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate2 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate3 
        /// </summary>
        [Display(Name = "ItemRate3", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate3, Id = Index.ItemRate3, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate3 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate4 
        /// </summary>
        [Display(Name = "ItemRate4", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate4, Id = Index.ItemRate4, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate4 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate5 
        /// </summary>
        [Display(Name = "ItemRate5", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate5, Id = Index.ItemRate5, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate5 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate6 
        /// </summary>
        [Display(Name = "ItemRate6", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate6, Id = Index.ItemRate6, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate6 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate7 
        /// </summary>
        [Display(Name = "ItemRate7", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate7, Id = Index.ItemRate7, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate7 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate8 
        /// </summary>
        [Display(Name = "ItemRate8", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate8, Id = Index.ItemRate8, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate8 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate9 
        /// </summary>
        [Display(Name = "ItemRate9", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate9, Id = Index.ItemRate9, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate9 { get; set; }

        /// <summary>
        /// Gets or sets ItemRate10 
        /// </summary>
        [Display(Name = "ItemRate10", ResourceType = typeof(TaxRatesResx))]
        [ViewField(Name = Fields.ItemRate10, Id = Index.ItemRate10, FieldType = EntityFieldType.Decimal, Size = 8, Precision = 5)]
        public decimal ItemRate10 { get; set; }

        /// <summary>
        /// Gets or sets LastMaintained 
        /// </summary>
        [Display(Name = "LastMaintained", ResourceType = typeof(CommonResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.LastMaintained, Id = Index.LastMaintained, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime LastMaintained { get; set; }









    }
}
