// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    ///  Class Fiscal Calendar
    /// </summary>
    public partial class FiscalCalendar : ModelBase
    {
        /// <summary>
        /// Default Constructor
        /// </summary>
        public FiscalCalendar()
        {
            FiscalStatusList = new List<FiscalStatus>();
        }

        /// <summary>
        /// Gets or sets Fiscal Year 
        /// </summary>
        [Key]
        [RegularExpression(RegularExpressions.OnlyNumericAndEmpty, ErrorMessageResourceName = "NumericValueMessage", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "FiscalYear", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalYear, Id = Index.FiscalYear, FieldType = EntityFieldType.Char, Size = 4, Mask = "%4D")]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets Number of Fiscal Periods 
        /// </summary>
        [Display(Name = "NumFiscalPeriods", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.NumberofFiscalPeriods, Id = Index.NumberofFiscalPeriods, FieldType = EntityFieldType.Int, Size = 2)]
        public NumberofFiscalPeriods NumberofFiscalPeriods { get; set; }

        /// <summary>
        /// Gets or sets Quarter with 4 Periods 
        /// </summary>
        [Display(Name = "Quarterwith4Periods", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Quarterwith4Periods, Id = Index.Quarterwith4Periods, FieldType = EntityFieldType.Int, Size = 2)]
        public Quarterwith4Periods Quarterwith4Periods { get; set; }

        /// <summary>
        /// Gets or sets Active 
        /// </summary>
        [Display(Name = "Active", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Active, Id = Index.Active, FieldType = EntityFieldType.Bool, Size = 2)]
        public bool Active { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period1 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod1StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod1StartDate, Id = Index.FiscalPeriod1StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod1StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period2 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod2StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod2StartDate, Id = Index.FiscalPeriod2StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod2StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period3 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod3StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod3StartDate, Id = Index.FiscalPeriod3StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod3StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period4 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod4StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod4StartDate, Id = Index.FiscalPeriod4StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod4StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period5 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod5StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod5StartDate, Id = Index.FiscalPeriod5StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod5StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period6 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod6StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod6StartDate, Id = Index.FiscalPeriod6StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod6StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period7 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod7StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod7StartDate, Id = Index.FiscalPeriod7StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod7StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period8 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod8StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod8StartDate, Id = Index.FiscalPeriod8StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod8StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period9 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod9StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod9StartDate, Id = Index.FiscalPeriod9StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod9StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period10 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod10StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod10StartDate, Id = Index.FiscalPeriod10StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod10StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period11 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod11StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod11StartDate, Id = Index.FiscalPeriod11StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod11StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period12 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod12StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod12StartDate, Id = Index.FiscalPeriod12StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod12StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period13 StartDate 
        /// </summary>
        [Display(Name = "FiscalPeriod13StartDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod13StartDate, Id = Index.FiscalPeriod13StartDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod13StartDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period1 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod1EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod1EndDate, Id = Index.FiscalPeriod1EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod1EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period2 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod2EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod2EndDate, Id = Index.FiscalPeriod2EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod2EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period3 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod3EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod3EndDate, Id = Index.FiscalPeriod3EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod3EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period4 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod4EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod4EndDate, Id = Index.FiscalPeriod4EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod4EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period5 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod5EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod5EndDate, Id = Index.FiscalPeriod5EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod5EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period6 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod6EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod6EndDate, Id = Index.FiscalPeriod6EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod6EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period7 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod7EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod7EndDate, Id = Index.FiscalPeriod7EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod7EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period8 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod8EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod8EndDate, Id = Index.FiscalPeriod8EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod8EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period9 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod9EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod9EndDate, Id = Index.FiscalPeriod9EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod9EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period10 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod10EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod10EndDate, Id = Index.FiscalPeriod10EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod10EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period11 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod11EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod11EndDate, Id = Index.FiscalPeriod11EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod11EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period12 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod12EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod12EndDate, Id = Index.FiscalPeriod12EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod12EndDate { get; set; }

        /// <summary>
        /// Gets or sets Fiscal Period13 EndDate 
        /// </summary>
        [Display(Name = "FiscalPeriod13EndDate", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.FiscalPeriod13EndDate, Id = Index.FiscalPeriod13EndDate, FieldType = EntityFieldType.Date, Size = 5)]
        public DateTime FiscalPeriod13EndDate { get; set; }

        /// <summary>
        /// Gets or sets Adjustment Period Status 
        /// </summary>
        [Display(Name = "AdjustmentPeriodStatus", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.AdjustmentPeriodStatus, Id = Index.AdjustmentPeriodStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public AdjustmentPeriodStatus AdjustmentPeriodStatus { get; set; }

        /// <summary>
        /// Gets or sets Closing Period Status 
        /// </summary>
        [Display(Name = "ClosingPeriodStatus", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.ClosingPeriodStatus, Id = Index.ClosingPeriodStatus, FieldType = EntityFieldType.Int, Size = 2)]
        public AdjustmentPeriodStatus ClosingPeriodStatus { get; set; }

        /// <summary>
        /// Gets or sets Command 
        /// </summary>
        [Display(Name = "Command", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Command, Id = Index.Command, FieldType = EntityFieldType.Int, Size = 2)]
        public Command Command { get; set; }

        /// <summary>
        /// Gets or sets Application 
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Application, Id = Index.Application, FieldType = EntityFieldType.Char, Size = 2)]
        public string Application { get; set; }

        /// <summary>
        /// Gets or sets Open 
        /// </summary>
        [Display(Name = "Open", ResourceType = typeof(FiscalCalendarResx))]
        [ViewField(Name = Fields.Open, Id = Index.Open, FieldType = EntityFieldType.Char, Size = 30)]
        public string Open { get; set; }

        /// <summary>
        /// List of Fiscal Status
        /// </summary>
        public List<FiscalStatus> FiscalStatusList { get; set; }

        /// <summary>
        /// Gets Adjustment Period Status Text 
        /// </summary>
        [IgnoreExportImport]
        public string AdjustmentPeriodStatusText
        {
            get
            {
                return EnumUtility.GetStringValue(AdjustmentPeriodStatus);
            }
        }

        /// <summary>
        /// Gets Closing Period Status Text
        /// </summary>
        [IgnoreExportImport]
        public string ClosingPeriodStatusText
        {
            get
            {
                return EnumUtility.GetStringValue(ClosingPeriodStatus);
            }
        }

        /// <summary>
        /// Gets Command Text 
        /// </summary>
        [IgnoreExportImport]
        public string CommandText
        {
            get
            {
                return EnumUtility.GetStringValue(Command);
            }
        }

        /// <summary>
        /// Gets Active Text
        /// </summary>
        [IgnoreExportImport]
        [Display(Name = "Status", ResourceType = typeof(CSCommonResx))]
        public string ActiveText
        {
            get
            {
                return EnumUtility.GetStringValue(Active ? ActiveType.Active : ActiveType.Inactive);
            }
        }

        /// <summary>
        /// Gets Fiscal Period ending date
        /// </summary>
        /// <param name="periodId">Fiscal period ID</param>
        /// <returns>DateTime?</returns>
        public DateTime? GetPeriodEndTime(int periodId)
        {
            switch (periodId)
            {
                case 1:
                    return FiscalPeriod1EndDate;
                case 2:
                    return FiscalPeriod2EndDate;
                case 3:
                    return FiscalPeriod3EndDate;
                case 4:
                    return FiscalPeriod4EndDate;
                case 5:
                    return FiscalPeriod5EndDate;
                case 6:
                    return FiscalPeriod6EndDate;
                case 7:
                    return FiscalPeriod7EndDate;
                case 8:
                    return FiscalPeriod8EndDate;
                case 9:
                    return FiscalPeriod9EndDate;
                case 10:
                    return FiscalPeriod10EndDate;
                case 11:
                    return FiscalPeriod11EndDate;
                case 12:
                    return FiscalPeriod12EndDate;
                case 13:
                    return FiscalPeriod13EndDate;
                default:
                    return null;
            }
        }
    }
}
