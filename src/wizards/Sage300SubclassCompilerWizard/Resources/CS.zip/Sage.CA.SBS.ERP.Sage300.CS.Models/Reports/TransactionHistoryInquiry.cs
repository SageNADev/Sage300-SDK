﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System;
using System.ComponentModel.DataAnnotations;
using System.Security.AccessControl;
#endregion Namespace

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Class TransactionHistoryInquiry
    /// </summary>
    public partial class TransactionHistoryInquiry : ReportBase
    {
        /// <summary>
        /// Gets or sets Multi-Currency 
        /// </summary>
        public string Multicurrency { get; set; }

        /// <summary>
        /// Gets or sets ApplicationType 
        /// </summary>
        public SourceApplicationType ApplicationType { get; set; }

        /// <summary>
        /// Get or sets BankCodeDescription
        /// </summary>
        public string BankCodeDescription { get; set; }

        /// <summary>
        /// Get or sets BankAccountNumber
        /// </summary>
        public string BankAccountNumber { get; set; }

        /// <summary>
        /// Get or sets Currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        ///  Gets or sets BankCode 
        /// </summary>  
        [Display(Name = "BankFLD", ResourceType = typeof(BKCommonResx))]     
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string BankCode { get; set; }

        /// <summary>
        ///  Gets or sets DocumentType 
        /// </summary>
        public DocumentType DocumentType { get; set; }

        /// <summary>
        ///  Gets or sets DocumentType 
        /// </summary>
        public SelectDocumentType SelectDocumentType { get; set; }

        /// <summary>
        ///  Gets or sets ReconciliationStatus 
        /// </summary>
        public ReconciliationStatusOptions ReconciliationStatus { get; set; }

        /// <summary>
        ///  Gets or sets FromDate 
        /// </summary>     
        [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        ///  Gets or sets ToDate 
        /// </summary>
        [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToDate { get; set; }

        /// <summary>
        ///  Gets or sets FromRemitId 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromRemitId { get; set; }

        /// <summary>
        ///  Gets or sets ToRemitId 
        /// </summary>
        [StringLength(24, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToRemitId { get; set; }

        /// <summary>
        ///  Gets or sets FromAmount 
        /// </summary>
        public decimal FromAmount { get; set; }

        /// <summary>
        ///  Gets or sets ToAmount 
        /// </summary>
        public decimal ToAmount { get; set; }

        /// <summary>
        /// Property for FromSourceAmount 
        /// </summary>
        public decimal FromSourceAmount { get; set; }

        /// <summary>
        /// Property for ToSourceAmount 
        /// </summary>
        public decimal ToSourceAmount { get; set; }

        /// <summary>
        ///  Gets or sets FromSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromSourceCurrency { get; set; }

        /// <summary>
        ///  Gets or sets ToSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToSourceCurrency { get; set; }

        /// <summary>
        ///  Gets or sets FromPayor 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromPayor { get; set; }

        /// <summary>
        ///  Gets or sets ToPayor 
        /// </summary>
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToPayor { get; set; }

        /// <summary>
        ///  Gets or sets FunctionalCurrency 
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        ///  Gets or sets BankStatementType 
        /// </summary>
        public string BankStatementType { get; set; }

        /// <summary>
        ///  Gets or sets StatementCurrency 
        /// </summary>
        public string StatementCurrency { get; set; }

        /// <summary>
        ///  Gets or sets ShowBankCurrency 
        /// </summary>
        public string ShowBankCurrency { get; set; }

        /// <summary>
        ///  Gets or sets CPAccount 
        /// </summary>
        public string CpAccount { get; set; }

        /// <summary>
        ///  Gets or sets UPAccount 
        /// </summary>
        public string UpAccount { get; set; }
    }
}