﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Deposit Register Model Class
    /// </summary>
    public partial class DepositRegister : ReportBase
    {
        /// <summary>
        ///  Gets or sets From Bank 
        /// </summary>
        [Display(Name = "BankFLD", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string FromBank { get; set; }

        /// <summary>
        ///  Gets or sets To Bank 
        /// </summary>
        [Display(Name = "BankFLD", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ToBank { get; set; }

        /// <summary>
        ///  Gets or sets From Transaction Date 
        /// </summary>
        [Display(Name = "DepdateFLD", ResourceType = typeof (BKCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        ///  Gets or sets To Transaction Date 
        /// </summary>
        [Display(Name = "DepdateFLD", ResourceType = typeof (BKCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat",
            ErrorMessageResourceType = typeof (AnnotationsResx))]
        public DateTime? ToDate { get; set; }

        /// <summary>
        ///  Gets or sets From Application 
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof (BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string FromApplication { get; set; }

        /// <summary>
        ///  Gets or sets To Application 
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof (BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        public string ToApplication { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or Sets Functional Currency Decial 
        /// </summary>
        public decimal FunctionalCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets Print Deposit Detail
        /// </summary>
        [Display(Name = "PrintDepositDetails", ResourceType = typeof (BKCommonResx))]
        public bool PrintDepositDetail { get; set; }

        /// <summary>
        /// Get or set Print dropdown
        /// </summary>
        [Display(Name = "Print", ResourceType = typeof (CommonResx))]
        public Print Print { get; set; }    

        /// <summary>
        /// Get or set Detail
        /// </summary>
        public string Detail { get; set; }

        /// <summary>
        /// Get or set Summary
        /// </summary>
        public string Summary { get; set; }

        /// <summary>
        /// Get or set Sort By dropdown
        /// </summary>
        [Display(Name = "SortBy", ResourceType = typeof(CommonResx))]
        public DepositRegisterSortBy SortBy { get; set; }

        /// <summary>
        /// Gets or sets Deposit Type - All
        /// </summary>
        [Display(Name = "LblAllCap", ResourceType = typeof(BKCommonResx))]
        public bool TypeAll { get; set; }

        /// <summary>
        /// Gets or sets Deposit Type - Check
        /// </summary>
        [Display(Name = "Check", ResourceType = typeof(BKCommonResx))]
        public bool Check { get; set; }

        /// <summary>
        /// Gets or sets Deposit Type - Transfer
        /// </summary>
        [Display(Name = "Transfer", ResourceType = typeof(BKCommonResx))]
        public bool Transfer { get; set; }

        /// <summary>
        /// Gets or sets Deposit Type - CreditCard
        /// </summary>
        [Display(Name = "CreditCard", ResourceType = typeof(BKCommonResx))]
        public bool CreditCard { get; set; }

        /// <summary>
        /// Gets or sets Deposit Type - Cash
        /// </summary>
        [Display(Name = "Cash", ResourceType = typeof(BKCommonResx))]
        public bool Cash { get; set; }

        /// <summary>
        /// Gets or sets Deposit Type - Other
        /// </summary>
        [Display(Name = "Other", ResourceType = typeof(CommonResx))]
        public bool Other { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - All
        /// </summary>
        [Display(Name = "LblAllCap", ResourceType = typeof(BKCommonResx))]
        public bool StatusAll { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Cleared
        /// </summary>
        [Display(Name = "Cleared", ResourceType = typeof(BKCommonResx))]
        public bool Cleared { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Outstanding
        /// </summary>
         [Display(Name = "Outstanding", ResourceType = typeof(BKCommonResx))]
        public bool Outstanding { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Not posted
        /// </summary>
         [Display(Name = "NotPosted", ResourceType = typeof(BKCommonResx))]
        public bool NotPosted { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Cleared with bank error
        /// </summary>
         [Display(Name = "ClearedWithBankError", ResourceType = typeof(BKCommonResx))]
        public bool BankError { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Cleared with write-off
        /// </summary>
        [Display(Name = "ClearedWithWriteOff", ResourceType = typeof(BKCommonResx))]
        public bool WriteOff { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Cleared with Credit Card Charges
        /// </summary>
        [Display(Name = "ClearedWithCreditCardCharges", ResourceType = typeof(BKCommonResx))]
        public bool CreditCardCharge { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Cleared with exchange rate difference
        /// </summary>
        [Display(Name = "ClearedWithExchangeRateDifference", ResourceType = typeof(BKCommonResx))]
        public bool ExchangeRateDiff { get; set; }

        /// <summary>
        /// Gets or sets Reconcilation Status - Reconcile by deposit detail
        /// </summary>
        [Display(Name = "StatusRecByDepDet", ResourceType = typeof(BKCommonResx))]
        public bool RecByDepositDetail { get; set; }
    }
}
