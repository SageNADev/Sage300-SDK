﻿/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */
#region

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Class TransactionListing
    /// </summary>
    public partial class TransactionListing : ReportBase
    {
        /// <summary>
        /// gets or sets value for From Bank 
        /// </summary>
        [Display(Name = "FromBank", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBank { get; set; }

        /// <summary>
        /// gets or sets value for To Bank
        /// </summary>
        [Display(Name = "ToBank", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBank { get; set; }

        /// <summary>
        /// gets or sets value for IsWithDrawal
        /// </summary>
        [Display(Name = "Withdrawal", ResourceType = typeof(TransactionListingReportResx))]
        public bool IsWithDrawal { get; set; }

        /// <summary>
        /// gets or sets value for IsDeposit
        /// </summary>
        [Display(Name = "Deposit", ResourceType = typeof(BKCommonResx))]
        public bool IsDeposit { get; set; }

        /// <summary>
        /// gets or sets value for ReportType
        /// </summary>
        [Display(Name = "ReportType", ResourceType = typeof(TransactionListingReportResx))]
        public ReportType ReportType { get; set; }

        /// <summary>
        /// gets or sets value for CutOffYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CutOffYear { get; set; }

        /// <summary>
        /// gets or sets value for CutOffPeriod
        /// </summary>
         [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string CutOffPeriod { get; set; }

        /// <summary>
        /// gets or sets value for IsPrintDepositDetails  
        /// </summary>
        [Display(Name = "PrintDepositDetails", ResourceType = typeof(BKCommonResx))]
        public bool IsPrintDepositDetails { get; set; }

        /// <summary>
        /// gets or sets value for IsPrintTransactionSummary
        /// </summary>
        [Display(Name = "PrintTransactionSummary", ResourceType = typeof(TransactionListingReportResx))]
        public bool IsPrintTransactionSummary { get; set; }

        /// <summary>
        /// gets or sets value for FunctionalCurrency
        /// </summary>
        public string FunctionalCurrency { get; set; }

    }
}




