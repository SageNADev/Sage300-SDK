﻿/* Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved. */

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.Common.Utilities.Constants;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;
using System;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Class TaxTracking 
    /// </summary>
    public partial class TaxTracking : ReportBase
    {
        /// <summary>
        /// Gets or sets FromTaxAuthority
        /// </summary>
        [Display(Name = "FROMAUTH", ResourceType = typeof(TaxTrackingReportResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric",ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromTaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets ToTaxAuthority
        /// </summary>
        [Display(Name = "TOAUTH", ResourceType = typeof(TaxTrackingReportResx))]
        [StringLength(12, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [RegularExpression(RegularExpressions.OnlyAlphaNumeric, ErrorMessageResourceName = "AlphaNumeric", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToTaxAuthority { get; set; }

        /// <summary>
        /// Gets or sets AsOfYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AsOfYear { get; set; }

        /// <summary>
        /// Gets or sets AsOfPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string AsOfPeriod { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyDec
        /// </summary>
        public string FunctionalCurrencyDec { get; set; }

        /// <summary>
        /// Gets or sets AsOfDate
        /// </summary>
        [Display(Name = "DOCDATE", ResourceType = typeof(TaxTrackingReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? AsOfDate { get; set; }

        /// <summary>
        /// Gets or sets PrintAmountsIn
        /// </summary>
        [Display(Name = "PAI", ResourceType = typeof(TaxTrackingReportResx))]
        public CurrencyType PrintAmountsIn { get; set; }

        /// <summary>
        /// Gets or sets ReportBy
        /// </summary>
        [Display(Name = "REPBY", ResourceType = typeof(TaxTrackingReportResx))]
        public ReportByType ReportBy { get; set; }

        /// <summary>
        /// Gets or sets PrintBy
        /// </summary>
        public PrintByType PrintBy { get; set; }

        /// <summary>
        /// Gets or sets FromItemTaxClass
        /// </summary>
        [Display(Name = "FROMITEM", ResourceType = typeof(TaxTrackingReportResx))]
        public FromItemClass FromItemTaxClass { get; set; }

        /// <summary>
        /// Gets or sets ToItemTaxClass
        /// </summary>
        [Display(Name = "TOITEM", ResourceType = typeof(TaxTrackingReportResx))]
        public FromItemClass ToItemTaxClass { get; set; }

        /// <summary>
        /// Gets or sets TransactionType
        /// </summary>
        [Display(Name = "TransactionType", ResourceType = typeof(TaxTrackingReportResx))]
        public TypeofRecordtoClear TransactionType { get; set; }

        /// <summary>
        /// Gets or sets IsMultiCurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets FromFiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FromFiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets ToFiscalYear
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToFiscalYear { get; set; }

        /// <summary>
        /// Gets or sets ToFiscalPeriod
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToFiscalPeriod { get; set; }

        /// <summary>
        /// Gets or set From Document Date
        /// </summary>
        [Display(Name = "DOCDATE", ResourceType = typeof(TaxTrackingReportResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        /// Gets or set To Documnet Date
        /// </summary>
        [Display(Name = "DOCDATE", ResourceType = typeof(TaxTrackingReportResx))]
        [ValidateDateFormat(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime ToDate { get; set; }
    }
}