﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Withdrawal status Fields
    /// </summary>
   public partial class WithdrawalStatus:ReportBase
    {
       /// <summary>
       /// Gets or Sets MultiCurrency
       /// </summary>
       public  int MultiCurrency { get; set; }

       /// <summary>
       /// Gets or Sets Functional Currency
       /// </summary>
       public string FunctionalCurrency { get; set; }

       /// <summary>
       /// Gets or Sets Functional Currency Decimal
       /// </summary>
       public decimal FunctionalCurrencyDecimal { get; set; }

       /// <summary>
       /// Gets or Sets From Date
       /// </summary>
       [Display(Name = "FromDate", ResourceType = typeof(CommonResx))]
       [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
       public DateTime? FromDate { get; set; }

       /// <summary>
       /// Gets or Sets To Date
       /// </summary>
      [Display(Name = "ToDate", ResourceType = typeof(CommonResx))]
      [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
       public DateTime? ToDate { get; set; }

       /// <summary>
       /// Gets or Sets From Bank
       /// </summary>
       public  string FromBank { get; set; }

       /// <summary>
       /// Gets or Sets To Bank
       /// </summary>
       public  string ToBank { get; set; }

       /// <summary>
       /// Gets or Sets Query
       /// </summary>
       public string Query { get; set; }

       /// <summary>
       /// Gets or Sets Alignment
       /// </summary>
       public bool Alignment { get; set; }

       /// <summary>
       /// Gets or Sets Void
       /// </summary>
       public bool Void { get; set; }

       /// <summary>
       /// Gets or Sets Out Standing
       /// </summary>
       public bool OutStanding { get; set; }

       /// <summary>
       /// Gets or Sets Non Negotiable
       /// </summary>
       public bool NonNegotiable { get; set; }
       /// <summary>
       /// Gets or Sets Continuation
       /// </summary>
       public bool Continuation { get; set; }

       /// <summary>
       /// Gets or Sets for Printed
       /// </summary>
       public bool Printed { get; set; }

       /// <summary>
       /// Gets or Sets  From Application
       /// </summary>
       public string FromApplication { get; set; }

       /// <summary>
       /// Gets or Sets  To Application
       /// </summary>
       public string ToApplication { get; set; }

       /// <summary>
       /// Gets or Sets Not Posted
       /// </summary>
       public bool NotPosted { get; set; }
    }
}
