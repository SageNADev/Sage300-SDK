/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.GL.Models.Enums;
//using Sage.CA.SBS.ERP.Sage300.Common.Models;
using System.ComponentModel.DataAnnotations;

// ReSharper disable once CheckNamespace

namespace Sage.CA.SBS.ERP.Sage300.GL.Models
{
    public partial class FiscalSet : ReportBase
    {
        /// <summary>
        /// Gets or sets AccountNumber 
        /// </summary>
        [StringLength(45, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "AccountNumber", ResourceType = typeof(GLCommonResx))]
        public string AccountNumber { get; set; }

        /// <summary>
        /// Gets or sets Fiscalsetfromyear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "From", ResourceType = typeof(CommonResx))]
        public string Fiscalsetfromyear { get; set; }

        /// <summary>
        /// Gets or sets Fiscalsettoyear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "To", ResourceType = typeof(CommonResx))]
        public string Fiscalsettoyear { get; set; }

        /// <summary>
        /// Gets or sets FiscalsetDesignator 
        /// </summary>
        public FiscalSetDesignator FiscalsetDesignator1 { get; set; }

        private FiscalSetDesignator? _fiscalsetDesignator2 ;

        /// <summary>
        /// Gets or sets FiscalsetDesignator 
        /// </summary>
        public FiscalSetDesignator FiscalsetDesignator2 {
            get
            {
                if (_fiscalsetDesignator2 == null)
                {
                    return FiscalSetDesignator.Budget1;
                }
                return (FiscalSetDesignator)_fiscalsetDesignator2;
            }
            set { _fiscalsetDesignator2 = value; }
        }

        /// <summary>
        /// Gets or sets Currencycode 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Currencycode", ResourceType = typeof(CurrencyCodesResx))]
        public string Currencycode { get; set; }

        /// <summary>
        /// Gets or sets Currencytype 
        /// </summary>
        public FiscalSetCurrencyType Currencytype { get; set; }

        /// <summary>
        /// Gets or sets Sourcecurrencydecimals 
        /// </summary>
        [StringLength(1, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "Sourcecurrencydecimals", ResourceType = typeof(FiscalSetResx))]
        public string Sourcecurrencydecimals { get; set; }

        /// <summary>
        /// Gets or sets Beginningbalance 
        /// </summary>
        public decimal Beginningbalance { get; set; }

        /// <summary>
        /// Gets or sets Period01netamount 
        /// </summary>
        public decimal Period01Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period02netamount 
        /// </summary>
        public decimal Period02Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period03netamount 
        /// </summary>
        public decimal Period03Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period04netamount 
        /// </summary>
        public decimal Period04Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period05netamount 
        /// </summary>
        public decimal Period05Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period06netamount 
        /// </summary>
        public decimal Period06Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period07netamount 
        /// </summary>
        public decimal Period07Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period08netamount 
        /// </summary>
        public decimal Period08Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period09netamount 
        /// </summary>
        public decimal Period09Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period10netamount 
        /// </summary>
        public decimal Period10Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period11netamount 
        /// </summary>
        public decimal Period11Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period12netamount 
        /// </summary>
        public decimal Period12Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period13netamount 
        /// </summary>
        public decimal Period13Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period14netamount 
        /// </summary>
        public decimal Period14Netamount { get; set; }

        /// <summary>
        /// Gets or sets Period15netamount 
        /// </summary>
        public decimal Period15Netamount { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        //[Display(Name = "ReservedDate", ResourceType = typeof(FiscalSetResx))]
        public string ReservedDate { get; set; }

        /// <summary>
        /// Gets or sets Allowspecificcurrenciesswitch 
        /// </summary>
        public FiscalSetAllowSpecificCurrenciesSwitch Allowspecificcurrenciesswitch { get; set; }

        /// <summary>
        /// Gets or sets Processasytdbalancesswitch 
        /// </summary>
        public FiscalSetProcessasytdbalancesSwitch Processasytdbalancesswitch { get; set; }

        /// <summary>
        /// Gets or sets RESERVEDupdateswitch 
        /// </summary>
        public int ReserveDupdateswitch { get; set; }

        /// <summary>
        /// Gets or sets Yeartodateamount 
        /// </summary>
        public decimal Yeartodateamount { get; set; }

        /// <summary>
        /// Gets or sets Period01balanceamount 
        /// </summary>
        public decimal Period01Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period02balanceamount 
        /// </summary>
        public decimal Period02Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period03balanceamount 
        /// </summary>
        public decimal Period03Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period04balanceamount 
        /// </summary>
        public decimal Period04Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period05balanceamount 
        /// </summary>
        public decimal Period05Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period06balanceamount 
        /// </summary>
        public decimal Period06Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period07balanceamount 
        /// </summary>
        public decimal Period07Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period08balanceamount 
        /// </summary>
        public decimal Period08Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period09balanceamount 
        /// </summary>
        public decimal Period09Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period10balanceamount 
        /// </summary>
        public decimal Period10Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period11balanceamount 
        /// </summary>
        public decimal Period11Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period12balanceamount 
        /// </summary>
        public decimal Period12Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period13balanceamount 
        /// </summary>
        public decimal Period13Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period14balanceamount 
        /// </summary>
        public decimal Period14Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Period15balanceamount 
        /// </summary>
        public decimal Period15Balanceamount { get; set; }

        /// <summary>
        /// Gets or sets Replacementswitch 
        /// </summary>
        public FiscalSetReplacementSwitch Replacementswitch { get; set; }

        /// <summary>
        /// Gets or sets Overrideratetypecode 
        /// </summary>
        //[StringLength(2, ErrorMessageResourceName = "MaxLength",ErrorMessageResourceType = typeof(AnnotationsResx))] 
        public string Overrideratetypecode { get; set; }

        /// <summary>
        /// Gets or sets Overriderate 
        /// </summary>
        public decimal Overriderate { get; set; }

        /// <summary>
        /// Gets or sets Activityswitch 
        /// </summary>
        public FiscalSetActivitySwitch Activityswitch { get; set; }

        /// <summary>
        /// Gets or sets Rollupswitch 
        /// </summary>
        public bool Rollupswitch { get; set; }
    }
}