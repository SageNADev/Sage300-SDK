﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;


namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{   
    /// <summary>
    /// Deposit status model class
    /// </summary>
    public partial class DepositStatus : ReportBase
    {
        /// <summary>
        ///  Gets or sets FromDate 
        /// </summary>
        [Display(Name = "DepdateFLD", ResourceType = typeof(BKCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        ///  Gets or sets ToDate 
        /// </summary>
        [Display(Name = "DepdateFLD", ResourceType = typeof(BKCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToDate { get; set; }

        /// <summary>
        ///  Gets or sets FromBank 
        /// </summary>
        [Display(Name = "Bank", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBank { get; set; }

        /// <summary>
        ///  Gets or sets ToBank 
        /// </summary>
        [Display(Name = "Bank", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBank { get; set; }

        /// <summary>
        ///  Gets or sets FromApplication 
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof(BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromApplication { get; set; }

        /// <summary>
        ///  Gets or sets ToApplication 
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof(BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToApplication { get; set; }

        /// <summary>
        /// Gets or sets PrintDepositDetails
        /// </summary>
        [Display(Name = "PrintDepositDetails", ResourceType = typeof(BKCommonResx))]
        public bool PrintDepositDetails { get; set; }

        /// <summary>
        /// Gets or sets NotPosted
        /// </summary>
        [Display(Name = "NotPosted", ResourceType = typeof(BKCommonResx))]
        public bool NotPosted { get; set; }

        /// <summary>
        /// Gets or sets OutStanding
        /// </summary>
        [Display(Name = "Outstanding", ResourceType = typeof(BKCommonResx))]
        public bool OutStanding { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or Sets FunctionalCurrencyDecimals 
        /// </summary>
        public decimal FunctionalCurrencyDecimals { get; set; }

    }
}
