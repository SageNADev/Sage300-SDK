﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Transfer Posting Journal Model
    /// </summary>
    public partial class TransferPostingJournal : ReportBase
    {
        /// <summary>
        /// Gets or sets BeginningPostingSequence 
        /// </summary>
        [Display(Name = "FromPostingSequence", ResourceType = typeof(BKCommonResx))]
        public string FromPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets EndingPostingSequence 
        /// </summary>
        [Display(Name = "ToPostingSequence", ResourceType = typeof(BKCommonResx))]
        public string ToPostingSequence { get; set; }

        /// <summary>
        /// Gets or Sets IncludeTaxInformation
        /// </summary>
        [Display(Name = "IncludeTaxInfo", ResourceType = typeof(BKCommonResx))]
        public bool IsIncludeTaxInformation { get; set; }

        /// <summary>
        /// Gets or Sets Reprint Previously Printed Journals
        /// </summary>
        [Display(Name = "ReprintPreviouslyPrintedJournals", ResourceType = typeof(BKCommonResx))]
        public bool IsReprint { get; set; }

        /// <summary>
        /// gets or sets Multicurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// gets or sets Functional currency decimals
        /// </summary>
        public decimal FunctionalCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets IncludeTaxInformation
        /// </summary>
        public int IncludeTaxInformation { get; set; }

        /// <summary>
        /// Gets or Sets Reprint Previously Printed Journals
        /// </summary>
        public int Reprint { get; set; }

        /// <summary>
        /// Is Posting Journal Available to Print
        /// </summary>
        public bool IsPostingJournalAvailable { get; set; }
    }
}

