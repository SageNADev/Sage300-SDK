﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Bank Reconciliation Class
    /// </summary>
    public partial class BankReconciliation : ReportBase
    {
        /// <summary>
        /// gets or sets From Bank Code
        /// </summary>
        [Display(Name = "FromBank", ResourceType = typeof(BKCommonResx))]
        public string FromBank { get; set; }

        /// <summary>
        /// gets or sets To Bank Code
        /// </summary>
        [Display(Name = "ToBank", ResourceType = typeof(BKCommonResx))]
        public string ToBank { get; set; }

         /// <summary>
        /// gets or set Print Deposit Details
        /// </summary>
        [Display(Name = "PrintDepositDetails", ResourceType = typeof(BKCommonResx))]
        public bool PrintDepositDetails { get; set; }

        /// <summary>
        /// gets or sets IsModuleActive
        /// </summary>
        public bool IsModuleActive { get; set; }

        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        public string FunctionalCurrency { get; set; }
    }
}