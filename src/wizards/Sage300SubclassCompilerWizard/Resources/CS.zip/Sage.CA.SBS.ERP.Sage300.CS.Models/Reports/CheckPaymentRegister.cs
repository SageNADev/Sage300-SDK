﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

#region

using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Customization.Validators;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Reports;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Check/Payment Register Model
    /// </summary>
    public partial class CheckPaymentRegister: ReportBase
    {
        /// <summary>
        ///  Gets or sets FromBankCode 
        /// </summary>
        [Display(Name = "BankFLD", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBankCode { get; set; }

        /// <summary>
        ///  Gets or sets ToBankCode 
        /// </summary>
        [Display(Name = "BankFLD", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBankCode { get; set; }

        /// <summary>
        ///  Gets or sets FromDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PymtDate", ResourceType = typeof(CheckPaymentRegisterReportResx))]
        public DateTime? FromDate { get; set; }

        /// <summary>
        ///  Gets or sets ToDate 
        /// </summary>
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "PymtDate", ResourceType = typeof(CheckPaymentRegisterReportResx))]
        public DateTime? ToDate { get; set; }

        /// <summary>
        ///  Gets or sets FromApplication 
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof(BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromApplication { get; set; }

        /// <summary>
        ///  Gets or sets ToApplication 
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof(BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToApplication { get; set; }

        /// <summary>
        ///  Gets or sets Print 
        /// </summary>
        [Display(Name = "Print", ResourceType = typeof(CommonResx))]
        public Print Print { get; set; }

        /// <summary>
        ///  Gets or sets SortBy 
        /// </summary>
        [Display(Name = "SortBy", ResourceType = typeof(CommonResx))]
        public SortBy SortBy { get; set; }

        /// <summary>
        ///  Gets or sets PrintMissingCheckNumbers 
        /// </summary>
        [Display(Name = "MissingChecks", ResourceType = typeof(CheckPaymentRegisterReportResx))]
        public bool PrintMissingCheckNumbers { get; set; }

        /// <summary>
        ///  Gets or sets PaymentTypes 
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "PaymentType", ResourceType = typeof(CheckPaymentRegisterReportResx))]
        public List<MultiSelect> PaymentTypes { get; set; }

        /// <summary>
        ///  Gets or sets ReconcilationStatuses 
        /// </summary>
        [ValidateListForSelection]
        [Display(Name = "ReconcilationStatus", ResourceType = typeof(CheckPaymentRegisterReportResx))]
        public List<MultiSelect> ReconcilationStatuses { get; set; }

        /// <summary>
        ///  Gets or sets MultiCurrency 
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrencyDecimals 
        /// </summary>
        public decimal FunctionalCurrencyDecimals { get; set; }
    }
}
