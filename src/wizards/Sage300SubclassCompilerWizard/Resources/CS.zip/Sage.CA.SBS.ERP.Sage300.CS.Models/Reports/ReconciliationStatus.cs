﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace

using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    ///Reconciliation Status model.
    /// </summary>
    public partial class ReconciliationStatus : ReportBase
    {
        /// <summary>
        ///  Gets or sets for FromBank
        /// </summary>
        [Display(Name = "Bank", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromBank { get; set; }

        /// <summary>
        ///  Gets or sets for ToBank
        /// </summary>
        [Display(Name = "Bank", ResourceType = typeof(BKCommonResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToBank { get; set; }

        /// <summary>
        ///  Gets or sets for FromTransactionDate
        /// </summary>
        [Display(Name = "DateremitFLD", ResourceType = typeof(BKCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? FromTransactionDate { get; set; }

        /// <summary>
        ///  Gets or sets for ToTransactionDate
        /// </summary>
        [Display(Name = "DateremitFLD", ResourceType = typeof(BKCommonResx))]
        [ValidateDateFormatAllowNull(ErrorMessageResourceName = "DateFormat", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime? ToTransactionDate { get; set; }

        /// <summary>
        ///  Gets or sets for FromApplication
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof(BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FromApplication { get; set; }

        /// <summary>
        ///  Gets or sets for ToApplication
        /// </summary>
        [Display(Name = "Application", ResourceType = typeof(BKCommonResx))]
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string ToApplication { get; set; }

        /// <summary>
        ///  Gets or sets for WithdrawalReconciliationStatus check list
        /// </summary>
        //public WithdrawalReconciliationStatusType WithdrawalReconciliationStatus { get; set; }
        [Display(Name = "RecstatusFLD", ResourceType = typeof(BKCommonResx))]
        public List<MultiSelect> WithdrawalReconciliationStatus { get; set; }

        /// <summary>
        ///  Gets or sets for DepositReconciliationStatusList
        /// </summary>
        //public DepositReconciliationStatus DepositReconciliationStatusList { get; set; }
        [Display(Name = "RecstatusFLD", ResourceType = typeof(BKCommonResx))]
        public List<MultiSelect> DepositReconciliationStatusList { get; set; }

        /// <summary>
        ///  Gets or sets for PrintDepositDetails
        /// </summary>
        [Display(Name = "PrintDepositDetails", ResourceType = typeof(BKCommonResx))]
        public bool PrintDepositDetails { get; set; }

        /// <summary>
        ///  Gets or sets for CheckQuery
        /// </summary>
        public string CheckQuery { get; set; }

        /// <summary>
        ///  Gets or sets for DepositQuery For Fiscal Year
        /// </summary>
        public string DepositQuery { get; set; }

        /// <summary>
        ///  Gets or sets for FunctionalCurrencyDecimals
        /// </summary>
        public decimal FunctionalCurrencyDecimals { get; set; }

        /// <summary>
        ///  Gets or sets for FunctionalCurrency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        ///  Gets or sets for MultiCurrency
        /// </summary>
        public bool MultiCurrency { get; set; }

        /// <summary>
        ///  Gets or sets for IsReconcile
        /// </summary>
        public bool IsReconcile { get; set; }
        /// <summary>
        ///  Gets or sets for IsReverse
        /// </summary>
        public bool IsReverse { get; set; }
        /// <summary>
        ///  Gets or sets for IsEntry
        /// </summary>
        public bool IsEntry { get; set; }
    }
}
