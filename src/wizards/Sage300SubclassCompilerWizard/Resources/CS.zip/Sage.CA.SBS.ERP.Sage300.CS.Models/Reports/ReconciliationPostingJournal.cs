﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;
using System.ComponentModel.DataAnnotations;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Reconciliation Posting Journal Model
    /// </summary>
    public partial class ReconciliationPostingJournal : ReportBase
    {
        /// <summary>
        /// Gets or sets FromPostingSequence 
        /// </summary>
        [Display(Name = "FromPostingSequence", ResourceType = typeof(BKCommonResx))]
        public string FromPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets ToPostingSequence 
        /// </summary>
        [Display(Name = "ToPostingSequence", ResourceType = typeof(BKCommonResx))]
        public string ToPostingSequence { get; set; }

        /// <summary>
        /// Gets or Sets Reprint Previously Printed Journals
        /// </summary>
        [Display(Name = "ReprintPreviouslyPrintedJournals", ResourceType = typeof(BKCommonResx))]
        public bool ReprintPreviouslyPrinted { get; set; }

        /// <summary>
        /// Gets or Sets Print Deposit Details
        /// </summary>
        [Display(Name = "PrintDepositDetails", ResourceType = typeof(BKCommonResx))]
        public bool PrintDepositDetails { get; set; }

        /// <summary>
        /// Gets or Sets Print GLSummary
        /// </summary>
        [Display(Name = "PrintGLSummary", ResourceType = typeof(BKCommonResx))]
        public bool PrintGLSummary { get; set; }

        /// <summary>
        /// gets or sets Functional currency decimals
        /// </summary>
        public decimal FunctionalCurrencyDecimals { get; set; }

        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public bool IsMultiCurrency { get; set; }

        /// <summary>
        /// Gets or sets Functional Currency
        /// </summary>
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// gets or sets IsGLActive
        /// </summary>
        public bool IsGLActive { get; set; }

        /// <summary>
        /// Is Posting Journal Available to Print
        /// </summary>
        public bool IsPostingJournalAvailable { get; set; }
    }
}

