﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 
#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Reports;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Bank Entry Posting Journal Model
    /// </summary>
    public partial class BankEntryPostingJournal : ReportBase
    {
        /// <summary>
        /// Gets or Sets Beginning Posting Sequence 
        /// </summary>
        [Display(Name = "FromPostingSequence", ResourceType = typeof(BKCommonResx))]
        public string FromPostingSequence { get; set; }

        /// <summary>
        /// Gets or Sets Ending Posting Sequence 
        /// </summary>
        [Display(Name = "ToPostingSequence", ResourceType = typeof(BKCommonResx))]
        public string ToPostingSequence { get; set; }

        /// <summary>
        /// Gets or Sets Include Tax Information
        /// </summary>
        [Display(Name = "IncludeTaxInfo", ResourceType = typeof(BKCommonResx))]
        public bool IsIncludeTaxInformation { get; set; }

        /// <summary>
        /// Gets or Sets Reprint Previously Printed Journals
        /// </summary>
        [Display(Name = "ReprintPreviouslyPrintedJournals", ResourceType = typeof(BKCommonResx))]
        public bool IsReprint { get; set; }

        /// <summary>
        /// Gets or sets Multicurrency
        /// </summary>
        public bool IsMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets Functional currency decimal
        /// </summary>
        public decimal FunctionalCurrencyDecimal { get; set; }

        /// <summary>
        /// Gets or sets IsGLActive
        /// </summary>
        public bool IsGLActive { get; set; }
        /// <summary>
        /// Gets or sets MultiCurrency
        /// </summary>
        public string MultiCurrency { get; set; }

        /// <summary>
        /// IsPostingSequenceExist
        /// </summary>
        public bool IsPostingSequenceExist { get; set; }
        
    }
}

