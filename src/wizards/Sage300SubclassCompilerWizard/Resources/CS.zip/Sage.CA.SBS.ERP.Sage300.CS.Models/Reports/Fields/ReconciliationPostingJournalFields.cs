﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Contains list of Reconciliation Posting Journal Fields and Indexes 
    /// </summary>
    public partial class ReconciliationPostingJournal
    {
        /// <summary>
        /// Bank Reconciliation Clearing
        /// </summary>
        public const string EntityName = "BK0103";

        /// <summary>
        /// Contains list of Reconciliation Posting Journal Field Constants
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Field property for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "FROMSEQ";

            /// <summary>
            /// Field property for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "TOSEQ";

            /// <summary>
            /// Field property for ReprintPreviouslyPrinted
            /// </summary>
            public const string ReprintPreviouslyPrinted = "SWREPRINT";

            /// <summary>
            /// Field property for PrintDepositDetails
            /// </summary>
            public const string PrintDepositDetails = "SWPRNDEPDET";

            /// <summary>
            /// Field property for PrintGLSummary
            /// </summary>
            public const string PrintGLSummary = "SWPRNGLSUM";

            /// <summary>
            /// Field property for FunctionalCurrencyDecimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "FUNCDEC";

            /// <summary>
            /// Field property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTICUR";

            /// <summary>
            /// Field property for FunctionalCurrency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            /// <summary>
            /// Field property for IsGLActive
            /// </summary>
            public const string IsGLActive = "SWGLACTIVE";
        }

        /// <summary>
        /// Contains list of Reconciliation Posting Journal Index Constants
        /// </summary>
        public class Index
        {
            /// <summary>
            /// Property Indexer for FunctionalCurrencyDecimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "2";

            /// <summary>
            /// Property Indexer for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "3";

            /// <summary>
            /// Property Indexer for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "4";

            /// <summary>
            /// Property Indexer for ReprintPreviouslyPrinted
            /// </summary>
            public const string ReprintPreviouslyPrinted = "5";

            /// <summary>
            /// Property Indexer for PrintDepositDetails
            /// </summary>
            public const string PrintDepositDetails = "6";

            /// <summary>
            /// Property Indexer for PrintGLSummary
            /// </summary>
            public const string PrintGLSummary = "7";

            /// <summary>
            /// Property Indexer for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "8";

            /// <summary>
            /// Property Indexer for FunctionalCurrency
            /// </summary>
            public const string FunctionalCurrency = "9";

            /// <summary>
            /// Property Indexer for IsGLActive
            /// </summary>
            public const string IsGLActive = "10";
        }
    }
}
