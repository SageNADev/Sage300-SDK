﻿//Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Contain list of Deposit Register report Fields.
    /// </summary>
    public partial class DepositRegister
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string EntityName = "C1627CB0-3F84-4153-8961-C0DB5A0BC219";

        /// <summary>
        /// Deposit Register Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class
            
            /// <summary>
            /// Property for From Bank Code
            /// </summary>
            public const string FromBank = "FROMBANK";

            /// <summary>
            /// Property for To Bank Code
            /// </summary>
            public const string ToBank = "TOBANK";

            /// <summary>
            /// Property for From Transaction Date 
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for To Transaction Date
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for From Application
            /// </summary>
            public const string FromApplication = "FROMAPPL";

            /// <summary>
            /// Property for To Application
            /// </summary>
            public const string ToApplication = "TOAPPL";

            /// <summary>
            /// Property for Multicurrency
            /// </summary>
            public const string IsMultiCurrency = "MULTICUR";

            /// <summary>
            /// Property for Functional Currency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            /// <summary>
            /// Property for Functional Currency Decial
            /// </summary>
            public const string FunctionalCurrencyDecimal = "FUNCDEC";
            
            /// <summary>
            /// Property for Print Deposit Detail
            /// </summary>
            public const string PrintDepositDetail = "SWDEPOSITDETAIL";

            /// <summary>
            /// Property for Print Detail
            /// </summary>
            public const string Detail = "SHOWDTL";

            /// <summary>
            /// Property for Print Summary
            /// </summary>
            public const string Summary = "SHOWSUM";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for Deposit Type All
            /// </summary>
            public const string TypeAll = "SWALLTYPE";

            /// <summary>
            /// Property for Deposit Type Check
            /// </summary>
            public const string Check = "SWCHECK";

            /// <summary>
            /// Property for Deposit Type Transfer
            /// </summary>
            public const string Transfer = "SWTRANSFER";

            /// <summary>
            /// Property for Deposit Type Credit Card
            /// </summary>
            public const string  CreditCard = "SWCREDIT";

            /// <summary>
            /// Property for Deposit Type Cash
            /// </summary>
            public const string Cash = "SWCASH";

            /// <summary>
            /// Property for Deposit Type Other
            /// </summary>
            public const string Other = "SWOTHER";

            /// <summary>
            /// Property for Include Reconciliation Staus All
            /// </summary>
            public const string StatusAll = "SWALLSTAT";

            /// <summary>
            /// Property for Include Reconciliation Staus Cleared
            /// </summary>
            public const string Cleared = "SWCLEARED";

            /// <summary>
            /// Property for Include Reconciliation Staus Oustanding
            /// </summary>
            public const string Outstanding = "SWOUTSTANDNG";

            /// <summary>
            /// Property for Include Reconciliation Staus Not Posted
            /// </summary>
            public const string NotPosted = "SWNOTPOSTED";

            /// <summary>
            /// Property for Include Reconciliation Staus Cleared With Bank Error
            /// </summary>
            public const string BankError = "SWBANKERR";

            /// <summary>
            /// Property for Include Reconciliation Staus Cleared With Write Off
            /// </summary>
            public const string WriteOff  = "SWWRITEOFF";

            /// <summary>
            /// Property for Include Reconciliation Staus Cleared With Credit Card Charges
            /// </summary>
            public const string CreditCardCharge = "SWCCCHARGE";

            /// <summary>
            /// Property for Include Reconciliation Staus Cleared With Exchange Rate Difference
            /// </summary>
            public const string ExchangeRateDiff = "SWRATEDIFF";

            /// <summary>
            /// Property for Include Reconciliation Staus Reconcile By Deposit Detail
            /// </summary>
            public const string RecByDepositDetail = "SWRECBYDEPDET";

            #endregion
        }
    }
}
