﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Contain list of Deposits Status report Fields.
    /// </summary>
    public partial class DepositStatus
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string ViewName = "1AC1BE2F-8894-4730-B4D9-847B9545718D";

        /// <summary>
        /// Deposit Status Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for FromBank
            /// </summary>
            public const string FromBank = "FROMBANK";

            /// <summary>
            /// Property for ToBank
            /// </summary>
            public const string ToBank = "TOBANK";

            /// <summary>
            /// Property for FromApplication
            /// </summary>
            public const string FromApplication = "FROMAPPL";

            /// <summary>
            /// Property for ToApplication
            /// </summary>
            public const string ToApplication = "TOAPPL";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTICUR";

            /// <summary>
            /// Property for FunctionalCurrency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            /// <summary>
            /// Property for FunctionalCurrencyDecimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "FUNCDEC";

            /// <summary>
            /// Property for PrintDepositDetails
            /// </summary>
            public const string PrintDepositDetails = "SWPRNDEPDET";

            /// <summary>
            ///  Property for NotPosted
            /// </summary>
            public const string NotPosted = "SWNOTPOSTED";

            /// <summary>
            /// Property for OutStanding
            /// </summary>
            public const string OutStanding = "SWINTRANSIT";

            #endregion
        }

    }
}
