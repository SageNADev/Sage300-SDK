﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Contains list of Check/Payment Register report fields.
    /// </summary>
    public partial class CheckPaymentRegister
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string EntityName = "{8F47B0AC-5D12-4173-A6D6-FDB36F5680E1}";

        /// <summary>
        /// Check/Payment Register Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTICUR";

            /// <summary>
            /// Property for FunctionalCurrency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            /// <summary>
            /// Property for FunctionalCurrencyDecimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "FUNCDEC";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for FromBankCode
            /// </summary>
            public const string FromBankCode = "FROMBANK";

            /// <summary>
            /// Property for ToBankCode
            /// </summary>
            public const string ToBankCode = "TOBANK";

            /// <summary>
            /// Property for FromApplication
            /// </summary>
            public const string FromApplication = "FROMAPPL";

            /// <summary>
            /// Property for ToApplication
            /// </summary>
            public const string ToApplication = "TOAPPL";

            /// <summary>
            /// Property for PaymentTypeAll
            /// </summary>
            public const string PaymentTypeAll = "SWALLTYPE";

            /// <summary>
            /// Property for PaymentTypeCheck
            /// </summary>
            public const string PaymentTypeCheck = "SWCHECK";

            /// <summary>
            /// Property for PaymentTypeEft
            /// </summary>
            public const string PaymentTypeEft = "SWEFT";

            /// <summary>
            /// Property for PaymentTypeTransfer
            /// </summary>
            public const string PaymentTypeTransfer = "SWTRANSFER";

            /// <summary>
            /// Property for PaymentTypeCreditCard
            /// </summary>
            public const string PaymentTypeCreditCard = "SWCREDIT";

            /// <summary>
            /// Property for PaymentTypeCash
            /// </summary>
            public const string PaymentTypeCash = "SWCASH";

            /// <summary>
            /// Property for PaymentTypeOther
            /// </summary>
            public const string PaymentTypeOther = "SWOTHER";

            /// <summary>
            /// Property for PaymentTypeServiceCharge
            /// </summary>
            public const string PaymentTypeServiceCharge = "SWSRVCCHRG";

            /// <summary>
            /// Property for StatusAll
            /// </summary>
            public const string StatusAll = "SWALLSTAT";

            /// <summary>
            /// Property for StatusAlignment
            /// </summary>
            public const string StatusAlignment = "SWALIGN";

            /// <summary>
            /// Property for StatusContinuation
            /// </summary>
            public const string StatusContinuation = "SWCONTINUEN";

            /// <summary>
            /// Property for StatusVoid
            /// </summary>
            public const string StatusVoid = "SWVOID";

            /// <summary>
            /// Property for StatusPrinted
            /// </summary>
            public const string StatusPrinted = "SWPRINTED";

            /// <summary>
            /// Property for StatusReversed
            /// </summary>
            public const string StatusReversed = "SWREVERSED";

            /// <summary>
            /// Property for StatusOutstanding
            /// </summary>
            public const string StatusOutstanding = "SWOUTSTANDNG";

            /// <summary>
            /// Property for StatusCleared
            /// </summary>
            public const string StatusCleared = "SWCLEARED";

            /// <summary>
            /// Property for StatusBankError
            /// </summary>
            public const string StatusBankError = "SWBANKERR";

            /// <summary>
            /// Property for StatusWriteOff
            /// </summary>
            public const string StatusWriteOff = "SWWRITEOFF";

            /// <summary>
            /// Property for StatusExchRateDifference
            /// </summary>
            public const string StatusExchRateDifference = "SWRATEDIFF";

            /// <summary>
            /// Property for StatusNonNegotiable
            /// </summary>
            public const string StatusNonNegotiable = "SWNONNEGTBL";

            /// <summary>
            /// Property for StatusNotPosted
            /// </summary>
            public const string StatusNotPosted = "SWNOTPOSTED";

            /// <summary>
            /// Property for SortBy
            /// </summary>
            public const string SortBy = "SORTBY";

            /// <summary>
            /// Property for ShowDetail
            /// </summary>
            public const string ShowDetail = "SHOWDTL";

            /// <summary>
            /// Property for ShowSummary
            /// </summary>
            public const string ShowSummary = "SHOWSUM";

            /// <summary>
            /// Property for PrintMissingCheckNumbers
            /// </summary>
            public const string PrintMissingCheckNumbers = "SWMISSING";

            #endregion
        }
    }
}
