﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Contains list of TransferPostingJournal Constants 
    /// </summary>
    public partial class TransferPostingJournal
    {
        /// <summary>
        /// Bank Reconciliation Clearing
        /// </summary>
        public const string EntityName = "BK0103";

        /// <summary>
        /// Contains list of TransferPostingJournal Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field property for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "FROMSEQ";

            /// <summary>
            /// Field property for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "TOSEQ";

            /// <summary>
            /// Field property for IsIncludeTaxInformation
            /// </summary>
            public const string IsIncludeTaxInformation = "INCTAX";

            /// <summary>
            /// Field property for IsReprint
            /// </summary>
            public const string IsReprint = "REPRINT";

            /// <summary>
            /// Field property for IsMulticurrency
            /// </summary>
            public const string IsMulticurrency = "MULTICUR";

            /// <summary>
            /// Field property for FCurrencyDecimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "FUNCDEC";

            #endregion
        }

        /// <summary>
        /// Contains list of TransferPostingJournal Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for IsIncludeTaxInformation
            /// </summary>
            public const string IsIncludeTaxInformation = "2";

            /// <summary>
            /// Property Indexer for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "3";

            /// <summary>
            /// Property Indexer for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "4";

            /// <summary>
            /// Property Indexer for Functional Currency Decimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "5";

            /// <summary>
            /// Property Indexer for IsReprint
            /// </summary>
            public const string IsReprint = "6";

            /// <summary>
            /// Property Indexer for IsMulticurrency
            /// </summary>
            public const string IsMulticurrency = "7";

            #endregion
        }
    }
}
