﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of TransactionHistoryInquiry Constants 
    /// </summary>
    public partial class TransactionHistoryInquiry
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "F1D0D986-C8CF-40F4-83FE-BE77F7BB28A0";

        /// <summary>
        /// Contains list of TransactionHistoryInquiry Fields Constants
        /// </summary>
        public class Fields
        {

            #region Properties
            /// <summary>
            /// Property for Multi-Currency 
            /// </summary>
            public const string Multicurrency = "MULTICUR";
            /// <summary>
            /// Property for ApplicationType 
            /// </summary>
            public const string ApplicationType = "APPL";
            /// <summary>
            /// Property for BankCode 
            /// </summary>
            public const string BankCode = "BANK";
            /// <summary>
            /// Property for DocumentType 
            /// </summary>
            public const string DocumentType = "DOCTYPE";
            /// <summary>
            /// Property for ReconciliationStatus 
            /// </summary>
            public const string ReconciliationStatus = "RECSTAT";
            /// <summary>
            /// Property for FromDate 
            /// </summary>
            public const string FromDate = "FRDATE";
            /// <summary>
            /// Property for ToDate 
            /// </summary>
            public const string ToDate = "TODATE";
            /// <summary>
            /// Property for FromRemitId 
            /// </summary>
            public const string FromRemitId = "FRIDREMIT";
            /// <summary>
            /// Property for ToRemitId 
            /// </summary>
            public const string ToRemitId = "TOIDREMIT";
            /// <summary>
            /// Property for FromAmount 
            /// </summary>
            public const string FromAmount = "FRAMT";
            /// <summary>
            /// Property for ToAmount 
            /// </summary>
            public const string ToAmount = "TOAMT";
            /// <summary>
            /// Property for FromSourceAmount 
            /// </summary>
            public const string FromSourceAmount = "FRSRCAMT";
            /// <summary>
            /// Property for ToSourceAmount 
            /// </summary>
            public const string ToSourceAmount = "TOSRCAMT";
            /// <summary>
            /// Property for FromSourceCurrency 
            /// </summary>
            public const string FromSourceCurrency = "FRSCURN";
            /// <summary>
            /// Property for ToSourceCurrency 
            /// </summary>
            public const string ToSourceCurrency = "TOSCURN";
            /// <summary>
            /// Property for FromPayor 
            /// </summary>
            public const string FromPayor = "FRPAYOR";
            /// <summary>
            /// Property for ToPayor 
            /// </summary>
            public const string ToPayor = "TOPAYOR";
            /// <summary>
            /// Property for FunctionalCurrencyDecimal 
            /// </summary>
            public const string FunctionalCurrency = "FUNCDEC";
            /// <summary>
            /// Property for ShowBankCurrency 
            /// </summary>
            public const string ShowBankCurrency = "SHOWBANKCUR";
            /// <summary>
            /// Property for CPAccount 
            /// </summary>            
            // ReSharper disable once InconsistentNaming
            public const string CPAccount = "SWCPACT";
            /// <summary>
            /// Property for UPAccount 
            /// </summary>            
            // ReSharper disable once InconsistentNaming
            public const string UPAccount = "SWUPACT";

            #endregion
        }

        /// <summary>
        /// Contains list of TransactionHistoryInquiry Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            /// <summary>
            /// Property Indexer for Multicurrency 
            /// </summary>
            public const int Multicurrency = 2;
            /// <summary>
            /// Property Indexer for ApplicationType 
            /// </summary>
            public const int ApplicationType = 3;
            /// <summary>
            /// Property Indexer for BankCode 
            /// </summary>
            public const int BankCode = 4;
            /// <summary>
            /// Property Indexer for DocumentType 
            /// </summary>
            public const int DocumentType = 5;
            /// <summary>
            /// Property Indexer for ReconciliationStatus 
            /// </summary>
            public const int ReconciliationStatus = 6;
            /// <summary>
            /// Property Indexer for FromDate 
            /// </summary>
            public const int FromDate = 7;
            /// <summary>
            /// Property Indexer for ToDate 
            /// </summary>
            public const int ToDate = 8;
            /// <summary>
            /// Property Indexer for FromRemitId 
            /// </summary>
            public const int FromRemitId = 9;
            /// <summary>
            /// Property Indexer for ToRemitId 
            /// </summary>
            public const int ToRemitId = 10;
            /// <summary>
            /// Property Indexer for FromAmount 
            /// </summary>
            public const int FromAmount = 11;
            /// <summary>
            /// Property Indexer for ToAmount 
            /// </summary>
            public const int ToAmount = 12;
            /// <summary>
            /// Property for FromSourceAmount 
            /// </summary>
            public const int FromSourceAmount = 13;
            /// <summary>
            /// Property for ToSourceAmount 
            /// </summary>
            public const int ToSourceAmount = 14;
            /// <summary>
            /// Property for FromSourceCurrency 
            /// </summary>
            public const int FromSourceCurrency = 15;
            /// <summary>
            /// Property for ToSourceCurrency 
            /// </summary>
            public const int ToSourceCurrency = 16;
            /// <summary>
            /// Property for FromPayor 
            /// </summary>
            public const int FromPayor = 17;
            /// <summary>
            /// Property for ToPayor 
            /// </summary>
            public const int ToPayor = 18;
            /// <summary>
            /// Property for FunctionalCurrency 
            /// </summary>
            public const int FunctionalCurrency = 19;
            /// <summary>
            /// Property for CPAccount 
            /// </summary>            
            // ReSharper disable once InconsistentNaming
            public const int CPAccount = 20;
            /// <summary>
            /// Property for UPAccount 
            /// </summary>
            // ReSharper disable once InconsistentNaming
            public const int UPAccount = 21;
            /// <summary>
            /// Property for ShowBankCurrency 
            /// </summary>
            public const int ShowBankCurrency = 22;
            #endregion
        }
    }
}
