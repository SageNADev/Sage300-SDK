﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports 
{
    /// <summary>
    /// 
    /// </summary>
    public partial class TransactionListing
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "9900D99A-099F-43A4-84C1-E7278321D235";

        /// <summary>
        /// Contains list of TransactionListing Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field property for From Bank Code
            /// </summary>
            public const string FromBank = "FROMBANK";

            /// <summary>
            /// Field property for To Bank Code
            /// </summary>
            public const string ToBank = "TOBANK";

            /// <summary>
            ///  Field property for WithDrawal
            /// </summary>
            public const string IsWithDrawal = "SWINCLWITHDRAWAL";

            /// <summary>
            ///  Field property for Deposit
            /// </summary>
            public const string IsDeposit = "SWINCLDEPOSIT";

            /// <summary>
            ///  Field property for ReportType
            /// </summary>
            public const string ReportType = "REPORTTYPE";

            /// <summary>
            ///  Field property for CutOffYear
            /// </summary>
            public const string CutOffYear = "CUTOFFYEAR";

            /// <summary>
            ///  Field property for CutOffPeriod
            /// </summary>
            public const string CutOffPeriod = "CUTOFFPERIOD";

            /// <summary>
            ///  Field property for PrintDepositDetails
            /// </summary>
            public const string IsPrintDepositDetails = "SWPRNDEPDET";

            /// <summary>
            ///  Field property for PrintTransactionSummary
            /// </summary>
            public const string IsPrintTransactionSummary = "SWPRNTRANSUMM";

            /// <summary>
            ///  Field property for Functional Currency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            #endregion
        }

        /// <summary>
        /// Contains list of TransactionListing Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for From Bank Code
            /// </summary>
            public const string FromBank = "2";

            /// <summary>
            /// Property Indexer for To Bank Code
            /// </summary>
            public const string ToBank = "3";

            /// <summary>
            ///  Property Indexer for WithDrawal
            /// </summary>
            public const string IsWithDrawal = "4";

            /// <summary>
            ///  Property Indexer for Deposit
            /// </summary>
            public const string IsDeposit = "5";

            /// <summary>
            ///  Property Indexer for ReportType
            /// </summary>
            public const string ReportType = "6";

            /// <summary>
            ///  Property Indexer for CutOffYear
            /// </summary>
            public const string CutOffYear = "7";

            /// <summary>
            ///  Property Indexer for CutOffPeriod
            /// </summary>
            public const string CutOffPeriod = "8";

            /// <summary>
            ///  Property Indexer for PrintDepositDetails
            /// </summary>
            public const string IsPrintDepositDetails = "9";

            /// <summary>
            ///  Property Indexer for PrintTransactionSummary
            /// </summary>
            public const string IsPrintTransactionSummary = "10";

            /// <summary>
            ///  Property Indexer for Functional Currency
            /// </summary>
            public const string FunctionalCurrency = "11";

            #endregion
        }
    }
}

