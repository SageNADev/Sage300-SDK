﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankEntryPostingJournal Constants 
    /// </summary>
    public partial class BankEntryPostingJournal
    {
        /// <summary>
        /// Entity Name
        /// </summary>
        public const string EntityName = "228650D4-731E-46EF-B4C2-90CBA66F666C";

        /// <summary>
        /// Contains list of BankEntryPostingJournal Field Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field property for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "FROMSEQ";

            /// <summary>
            /// Field property for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "TOSEQ";

            /// <summary>
            /// Field property for Is Include Tax Information
            /// </summary>
            public const string IsIncludeTaxInformation = "INCTAX";

            /// <summary>
            /// Field property for Is Reprint
            /// </summary>
            public const string IsReprint = "REPRINT";

            /// <summary>
            /// Field property for Is Multicurrency
            /// </summary>
            public const string IsMulticurrency = "MULTICUR";

            /// <summary>
            /// Field property for Functional Currency Decimal
            /// </summary>
            public const string FunctionalCurrencyDecimal = "FUNCDEC";

            #endregion
        }

        /// <summary>
        /// Contains list of BankEntryPostingJournal Index Constants
        /// </summary>
        public class Index
        {
            #region Properties
            
            /// <summary>
            /// Property Indexer for From Posting Sequence
            /// </summary>
            public const string FromPostingSequence = "3";

            /// <summary>
            /// Property Indexer for To Posting Sequence
            /// </summary>
            public const string ToPostingSequence = "4";

            /// <summary>
            /// Property Indexer for Is IncludeTaxInformation
            /// </summary>
            public const string IsIncludeTaxInformation = "2";
            
            /// <summary>
            /// Property Indexer for Is Reprint
            /// </summary>
            public const string IsReprint = "6";

            /// <summary>
            /// Property Indexer for Is Multicurrency
            /// </summary>
            public const string IsMulticurrency = "7";

            /// <summary>
            /// Property Indexer for Functional Currency Decimal
            /// </summary>
            public const string FunctionalCurrencyDecimal = "5";

            #endregion
        }
    }
}
