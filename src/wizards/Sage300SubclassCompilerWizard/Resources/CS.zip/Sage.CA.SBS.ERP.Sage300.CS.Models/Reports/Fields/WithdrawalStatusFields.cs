﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Contains list of Withdrawal Status Constants
    /// </summary>
    public partial class WithdrawalStatus
    {
        /// <summary>
        /// View name
        /// </summary>
        public const string ViewName = "BK1450";
        #region Field Names
        /// <summary>
        /// Withdrawal status fields
        /// </summary>
        public class Fields
        {
            /// <summary>
            /// Property for Multi Currency
            /// </summary>
            public const string MultiCurrency = "MULTICUR";

            /// <summary>
            /// Property for Functional Currency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            /// <summary>
            /// Property for Functional Currency Decimal
            /// </summary>
            public const string FunctionalCurrencyDecimal = "FUNCDEC";

            /// <summary>
            /// Property for From Date
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for To Date
            /// </summary>
            public const string ToDate = "TODATE";

            /// <summary>
            /// Property for From Bank
            /// </summary>
            public const string FromBank = "FROMBANK";

            /// <summary>
            /// Property for To Bank
            /// </summary>
            public const string ToBank = "TOBANK";

            /// <summary>
            /// Property for Query
            /// </summary>
            public const string Query = "QUERY";

            /// <summary>
            /// Property for Alignment
            /// </summary>
            public const string Alignment = "SWALIGN";

            /// <summary>
            /// Property for Void
            /// </summary>
            public const string Void = "SWVOID";

            /// <summary>
            /// Property for Out Standing
            /// </summary>
            public const string OutStanding = "SWOUTSTANDNG";

            /// <summary>
            /// Property for Non Negotiable
            /// </summary>
            public const string NonNegotiable = "SWNONNEGTBL";

            /// <summary>
            /// Property for Continuation
            /// </summary>
            public const string Continuation = "SWCONTINUEN";

            /// <summary>
            /// Property for Printed
            /// </summary>
            public const string Printed = "SWPRINTED";

            /// <summary>
            /// Property for From Application
            /// </summary>
            public const string FromApplication = "FROMAPPL";

            /// <summary>
            /// Property for To Application
            /// </summary>
            public const string ToApplication = "TOAPPL";

            /// <summary>
            /// Property for Not Posted
            /// </summary>
            public const string NotPosted = "SWNOTPOSTED";

            #endregion
        }
    }
}
