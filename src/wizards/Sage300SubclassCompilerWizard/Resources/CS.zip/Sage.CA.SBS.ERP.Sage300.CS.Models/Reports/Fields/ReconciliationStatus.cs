﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    ///Contain list of Reconciliation Status report Fields.
    /// </summary>
    public partial class ReconciliationStatus
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string EntityName = "BBE51E44-DF1F-4816-AAA5-7619D718D324";

        /// <summary>
        /// Reconciliation Status Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names - Note:These field names should be same as the name of the properties defined in other partial class

            /// <summary>
            /// Property for FromBank
            /// </summary>
            public const string FromBank = "FROMBANK";
            /// <summary>
            /// Property for ToBank
            /// </summary>
            public const string ToBank = "TOBANK";

            /// <summary>
            /// Property for FromTransactionDate
            /// </summary>
            public const string FromTransactionDate = "FROMDATE";

            /// <summary>
            /// Property for ToTransactionDate
            /// </summary>
            public const string ToTransactionDate = "TODATE";
            /// <summary>
            /// Property for FromApplication
            /// </summary>
            public const string FromApplication = "FROMAPPL";

            /// <summary>
            /// Property for ToApplication
            /// </summary>
            public const string ToApplication = "TOAPPL";

            /// <summary>
            /// Property for WithdrawalReconciliationStatus check list
            /// </summary>
            public const string WithdrawalReconciliationStatus = "CHKLIST";

            /// <summary>
            /// Property for DepositReconciliationStatusList
            /// </summary>
            public const string DepositReconciliationStatusList = "DEPLIST";

            /// <summary>
            /// Property for PrintDepositDetails
            /// </summary>
            public const string PrintDepositDetails = "SWPRNDEPDET";

            /// <summary>
            /// Property for CheckQuery
            /// </summary>
            public const string CheckQuery = "CHKQUERY";
            
            /// <summary>
            /// Property for DepositQuery For Fiscal Year
            /// </summary>
            public const string DepositQuery = "DEPQUERY";
            
            /// <summary>
            /// Property for FunctionalCurrencyDecimals
            /// </summary>
            public const string FunctionalCurrencyDecimals = "FUNCDEC";

            /// <summary>
            /// Property for FunctionalCurrency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            /// <summary>
            /// Property for MultiCurrency
            /// </summary>
            public const string MultiCurrency = "MULTICUR";
            
            #endregion
        }
    }
}
