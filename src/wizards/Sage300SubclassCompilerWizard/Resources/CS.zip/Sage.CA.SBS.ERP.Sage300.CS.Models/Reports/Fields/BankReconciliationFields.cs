﻿// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved.

// ReSharper disable CheckNamespace
namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
// ReSharper restore CheckNamespace
{
    /// <summary>
    /// Contains list of BankReconciliation Constants
    /// </summary>
    public partial class BankReconciliation
    {
        /// <summary>
        /// View Name
        /// </summary>
        public const string ViewName = "AA2115DB-99D9-4C16-94AF-73661356421B";

        /// <summary>
        /// Contains list of BankReconciliation Fields Constants
        /// </summary>
        public class Fields
        {
            #region Properties

            /// <summary>
            /// Field property for From Bank Code
            /// </summary>
            public const string FromBank = "FROMBANK";

            /// <summary>
            /// Field property for To Bank Code
            /// </summary>
            public const string ToBank = "ToBank";

            /// <summary>
            ///  Field property for IsPrintDepositDetails
            /// </summary>
            public const string PrintDepositDetails = "SWPRNDEPDET";

            /// <summary>
            ///  Field property for IsGLActive
            /// </summary>
            public const string IsModuleActive = "SWGLACTIVE";

            /// <summary>
            ///  Field property for Functional Currency
            /// </summary>
            public const string FunctionalCurrency = "FUNCCUR";

            #endregion
        }

        /// <summary>
        /// Contains list of BankReconciliation Index Constants
        /// </summary>
        public class Index
        {
            #region Properties

            /// <summary>
            /// Property Indexer for From Bank Code
            /// </summary>
            public const string FromBank = "2";

            /// <summary>
            /// Property Indexer for To Bank Code
            /// </summary>
            public const string ToBank = "3";

            /// <summary>
            ///  Property Indexer for IsPrintDepositDetails
            /// </summary>
            public const string PrintDepositDetails = "4";

            /// <summary>
            ///  Property Indexer for IsGLActive
            /// </summary>
            public const string IsModuleActive = "5";

            /// <summary>
            ///  Property Indexer for Functional Currency
            /// </summary>
            public const string FunctionalCurrency = "6";

            #endregion
        }
    }
}