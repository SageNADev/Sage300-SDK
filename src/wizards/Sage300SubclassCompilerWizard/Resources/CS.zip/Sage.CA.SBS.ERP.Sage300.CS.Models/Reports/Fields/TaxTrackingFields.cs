﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

namespace Sage.CA.SBS.ERP.Sage300.CS.Models.Reports
{
    /// <summary>
    /// Class TaxTracking
    /// </summary>
    public partial class TaxTracking
    {
        /// <summary>
        /// Unique name
        /// </summary>
        public const string ViewName = "E73341E7-E72D-476B-B825-A5AE7473CF45";

        /// <summary>
        /// Tax Tracking Fields Constants
        /// </summary>
        public class Fields
        {
            #region Field Names

            /// <summary>
            /// Property for FromTaxAuthority
            /// </summary>
            public const string FromTaxAuthority = "FROMAUTH";

            /// <summary>
            /// Property for ToTaxAuthority
            /// </summary>
            public const string ToTaxAuthority = "TOAUTH";

            /// <summary>
            /// Property for AsOfYear
            /// </summary>
            public const string AsOfYear = "ASOFYEAR";

            /// <summary>
            /// Property for TransactionType
            /// </summary>
            public const string TransactionType = "TRANTYPE";

            /// <summary>
            /// Property for AsOfPeriod
            /// </summary>
            public const string AsOfPeriod = "ASOFPRD";

            /// <summary>
            /// Property for FunctionalCurrencyDec
            /// </summary>
            public const string FunctionalCurrencyDec = "FUNCDEC";

            /// <summary>
            /// Property for AsOfDate
            /// </summary>
            public const string AsOfDate = "ASOFDATE";

            /// <summary>
            /// Property for FromItemTaxClass
            /// </summary>
            public const string FromItemTaxClass = "FROMCLASS";

            /// <summary>
            /// Property for ToItemTaxClass
            /// </summary>
            public const string ToItemTaxClass = "TOCLASS";

            /// <summary>
            /// Property for FromFiscalYear
            /// </summary>
            public const string FromFiscalYear = "FROMYEAR";

            /// <summary>
            /// Property for FromFiscalPeriod
            /// </summary>
            public const string FromFiscalPeriod = "FROMPRD";

            /// <summary>
            /// Property for ToFiscalYear
            /// </summary>
            public const string ToFiscalYear = "TOYEAR";

            /// <summary>
            /// Property for ToFiscalPeriod
            /// </summary>
            public const string ToFiscalPeriod = "TOPRD";

            /// <summary>
            /// Property for FromDate
            /// </summary>
            public const string FromDate = "FROMDATE";

            /// <summary>
            /// Property for ToDate
            /// </summary>
            public const string ToDate = "TODATE";

            #endregion
        }

    }
}
