﻿/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

#region Namespace

using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Resources.Forms;

#endregion

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// Class CompanyProfileContact.
    /// </summary>
    public class CompanyProfileContact : ModelBase
    {
        /// <summary>
        /// Gets or sets Name 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "Name", ResourceType = typeof (CompanyProfileResx))]
        public string Name { get; set; }

        /// <summary>
        /// Gets or sets Tax Number 
        /// </summary>
        [StringLength(20, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof (AnnotationsResx))]
        [Display(Name = "TaxNumber", ResourceType = typeof (CompanyProfileResx))]
        public string TaxNumber { get; set; }

        /// <summary>
        /// Gets or sets Business Registration Number 
        /// </summary>
        [StringLength(30, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Display(Name = "BusinessRegistrationNumber", ResourceType = typeof(CompanyProfileResx))]
        public string BusinessRegistrationNumber { get; set; }

        /// <summary>
        /// Gets or sets Format Phone Number 
        /// </summary>
        [Display(Name = "FormatPhone", ResourceType = typeof (CompanyProfileResx))]
        public bool FormatPhoneNo { get; set; }
    }
}