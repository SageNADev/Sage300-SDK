/* Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. */

using System;
using System.ComponentModel.DataAnnotations;
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using FiscalPeriod = Sage.CA.SBS.ERP.Sage300.CS.Models.Enums.FiscalPeriod;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is Bank Transfers Details Entity
    /// </summary>
    public partial class BankTransfers : ModelBase
    {
        /// <summary>
        /// Gets or sets TransferNumber 
        /// </summary>
        //[Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [Key]
        public string TransferNumber { get; set; }

        /// <summary>
        /// Gets or sets Date 
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Gets or sets Description 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Description { get; set; }

        /// <summary>
        /// Gets or sets Reference 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string Reference { get; set; }

        /// <summary>
        /// Gets or sets FiscalYear 
        /// </summary>
        [StringLength(4, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FiscalYear { get; set; }

        /// <summary>
        /// Gets or sets FiscalPeriod 
        /// </summary>

        public FiscalPeriod FiscalPeriod { get; set; }

        /// <summary>
        /// Gets or sets TransferBank 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferBank { get; set; }

        /// <summary>
        /// Gets or sets TransferSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets TransferRateDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime TransferRateDate { get; set; }

        /// <summary>
        /// Gets or sets TransferRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferRateType { get; set; }

        /// <summary>
        /// Gets or sets TransferRateFactor 
        /// </summary>

        public decimal TransferRateFactor { get; set; }

        /// <summary>
        /// Gets or sets TransferRateSpread 
        /// </summary>

        public decimal TransferRateSpread { get; set; }

        /// <summary>
        /// Gets or sets TransferRateOperator 
        /// </summary>

        public TransferRateOperator TransferRateOperator { get; set; }

        /// <summary>
        /// Gets or sets TransferSourceAmount 
        /// </summary>

        public decimal TransferSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets TransferFunctionalAmount 
        /// </summary>

        public decimal TransferFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets DepositBank 
        /// </summary>
        [Required(ErrorMessageResourceName = "Required", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositBank { get; set; }

        /// <summary>
        /// Gets or sets DepositSourceCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositSourceCurrency { get; set; }

        /// <summary>
        /// Gets or sets DepositRateDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime DepositRateDate { get; set; }

        /// <summary>
        /// Gets or sets DepositRateType 
        /// </summary>
        [StringLength(2, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositRateType { get; set; }

        /// <summary>
        /// Gets or sets DepositRateFactor 
        /// </summary>

        public decimal DepositRateFactor { get; set; }

        /// <summary>
        /// Gets or sets DepositRateSpread 
        /// </summary>

        public decimal DepositRateSpread { get; set; }

        /// <summary>
        /// Gets or sets DepositRateOperator 
        /// </summary>

        public TransferRateOperator DepositRateOperator { get; set; }

        /// <summary>
        /// Gets or sets DepositSourceAmount 
        /// </summary>

        public decimal DepositSourceAmount { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalAmount 
        /// </summary>

        public decimal DepositFunctionalAmount { get; set; }

        /// <summary>
        /// Gets or sets PostDate 
        /// </summary>
        //[StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public DateTime PostDate { get; set; }

        /// <summary>
        /// Gets or sets TransferFunctionalFixed? 
        /// </summary>

        public long TransferFunctionalFixed { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalFixed? 
        /// </summary>

        public long DepositFunctionalFixed { get; set; }

        /// <summary>
        /// Gets or sets TransferDepositFixed? 
        /// </summary>

        public long TransferDepositFixed { get; set; }

        /// <summary>
        /// Gets or sets TransferBankDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferBankDescription { get; set; }

        /// <summary>
        /// Gets or sets TransferBankCurrencyDescripti 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferBankCurrencyDescripti { get; set; }

        /// <summary>
        /// Gets or sets TransferCurrencyStatement 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferCurrencyStatement { get; set; }

        /// <summary>
        /// Gets or sets TransferMulticurrency? 
        /// </summary>

        public long TransferMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets DepositBankDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositBankDescription { get; set; }

        /// <summary>
        /// Gets or sets DepositBankCurrencyDescriptio 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositBankCurrencyDescriptio { get; set; }

        /// <summary>
        /// Gets or sets DepositCurrencyStatement 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositCurrencyStatement { get; set; }

        /// <summary>
        /// Gets or sets DepositMulticurrency? 
        /// </summary>

        public long DepositMulticurrency { get; set; }

        /// <summary>
        /// Gets or sets TransferDepositConversion 
        /// </summary>

        public decimal TransferDepositConversion { get; set; }

        /// <summary>
        /// Gets or sets TransferDepositRateOperatio 
        /// </summary>

        public TransferRateOperator TransferDepositRateOperatio { get; set; }

        /// <summary>
        /// Gets or sets FunctionalCurrency 
        /// </summary>
        [StringLength(3, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string FunctionalCurrency { get; set; }

        /// <summary>
        /// Gets or sets DepositFunctionalDefaultAmoun 
        /// </summary>

        public decimal DepositFunctionalDefaultAmoun { get; set; }

        /// <summary>
        /// Gets or sets DepositSourceDefaultAmount 
        /// </summary>

        public decimal DepositSourceDefaultAmount { get; set; }

        /// <summary>
        /// Gets or sets TransferRateTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets DepositRateTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositRateTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets NumericTransferNumber 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string NumericTransferNumber { get; set; }

        /// <summary>
        /// Gets or sets TransferTypeDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferTypeDescription { get; set; }

        /// <summary>
        /// Gets or sets GOrLAccountDescription 
        /// </summary>
        [StringLength(60, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string GorLAccountDescription { get; set; }

        /// <summary>
        /// Gets or sets TransferBankAccount 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string TransferBankAccount { get; set; }

        /// <summary>
        /// Gets or sets DepositBankAccount 
        /// </summary>
        [StringLength(22, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        public string DepositBankAccount { get; set; }


        /// <summary>
        /// Gets or sets List of GL Recurring entries
        /// </summary>
        /// <value>The recurring entries.</value>
        public EnumerableResponse<BankTransfersDetails> BankTransfersDetails { get; set; }


        /// <summary>
        /// Gets or sets Session date
        /// </summary>
        /// <value>The session date.</value>
        public DateTime SessionDate { get; set; }

        /// <summary>
        /// Gets or sets Session Warning Days
        /// </summary>
        /// <value>The session warn days.</value>
        public short SessionWarnDays { get; set; }
    }
}
