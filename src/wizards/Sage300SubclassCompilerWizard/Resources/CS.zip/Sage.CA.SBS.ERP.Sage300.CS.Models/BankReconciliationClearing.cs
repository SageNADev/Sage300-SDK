// Copyright (c) 1994-2014 Sage Software, Inc.  All rights reserved. 

#region Namespace
using Sage.CA.SBS.ERP.Sage300.Common.Models;
using Sage.CA.SBS.ERP.Sage300.Common.Resources;
using Sage.CA.SBS.ERP.Sage300.CS.Models.Enums;
using System.ComponentModel.DataAnnotations;
#endregion


// Added to support ViewField Attributes;
using Sage.CA.SBS.ERP.Sage300.Common.Models.Attributes;

namespace Sage.CA.SBS.ERP.Sage300.CS.Models
{
    /// <summary>
    /// This is BankReconciliationClearing entity
    /// </summary>
    public partial class BankReconciliationClearing : ModelBase
    {

        /// <summary>
        /// Gets or sets Operation 
        /// </summary>
        [ViewField(Name = Fields.Operation, Id = Index.Operation, FieldType = EntityFieldType.Int, Size = 2)]
        public Operation Operation
        {
            get
            {
                return Operation.GetDeferredGOrLPostingSequenceRange;
            }
        }

        /// <summary>
        /// Gets or sets BeginningPostingSequence 
        /// </summary>
        [ViewField(Name = Fields.BeginningPostingSequence, Id = Index.BeginningPostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal BeginningPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets EndingPostingSequence 
        /// </summary>
        [ViewField(Name = Fields.EndingPostingSequence, Id = Index.EndingPostingSequence, FieldType = EntityFieldType.Decimal, Size = 5)]
        public decimal EndingPostingSequence { get; set; }

        /// <summary>
        /// Gets or sets ReportTempFile 
        /// </summary>
        [StringLength(260, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ReportTempFile, Id = Index.ReportTempFile, FieldType = EntityFieldType.Char, Size = 260)]
        public string ReportTempFile { get; set; }

        /// <summary>
        /// Gets or sets BeginningBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.BeginningBankCode, Id = Index.BeginningBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string BeginningBankCode { get; set; }

        /// <summary>
        /// Gets or sets EndingBankCode 
        /// </summary>
        [StringLength(8, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.EndingBankCode, Id = Index.EndingBankCode, FieldType = EntityFieldType.Char, Size = 8, Mask = "%-8N")]
        public string EndingBankCode { get; set; }

        /// <summary>
        /// Gets or sets ThroughDate 
        /// </summary>
        [StringLength(5, ErrorMessageResourceName = "MaxLength", ErrorMessageResourceType = typeof(AnnotationsResx))]
        [ViewField(Name = Fields.ThroughDate, Id = Index.ThroughDate, FieldType = EntityFieldType.Date, Size = 5)]
        public string ThroughDate { get; set; }
    }
}
